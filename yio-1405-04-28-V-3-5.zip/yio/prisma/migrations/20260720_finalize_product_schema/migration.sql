-- Final Product schema cleanup.
-- Run scripts/finalize-product-schema.ts BEFORE applying this migration.
-- This migration intentionally drops legacy columns only after data has been
-- migrated to ProductImage/ProductVideo/ProductColor and salePrice.

ALTER TABLE "Product" DROP COLUMN IF EXISTS "image";
ALTER TABLE "Product" DROP COLUMN IF EXISTS "images";
ALTER TABLE "Product" DROP COLUMN IF EXISTS "videos";
ALTER TABLE "Product" DROP COLUMN IF EXISTS "colors";
ALTER TABLE "Product" DROP COLUMN IF EXISTS "discountPrice";
ALTER TABLE "Product" DROP COLUMN IF EXISTS "discountPercent";
