#!/bin/bash
# ============================================================
# YIO V7 — VPS Deployment Script
# ============================================================
# این اسکریپت را روی سرور VPS اجرا کنید
# پیش‌نیاز: دسترسی root یا sudo
# ============================================================

set -e

# Configuration
PROJECT_DIR="/var/www/yio-v7"
DB_NAME="yio_v7"
DB_USER="yio_user"
DB_PASSWORD=""  # در صورت خالی بودن، به طور خودکار تولید می‌شود
NODE_VERSION="20"

echo "═══════════════════════════════════════════════════"
echo "  YIO V7 — VPS Deployment"
echo "═══════════════════════════════════════════════════"
echo ""

# Check root
if [ "$EUID" -ne 0 ]; then
  echo "⚠️  Please run as root: sudo bash scripts/deploy-vps.sh"
  exit 1
fi

# Generate DB password if not set
if [ -z "$DB_PASSWORD" ]; then
  DB_PASSWORD=$(openssl rand -base64 24 | tr -d '/+=' | head -c 32)
  echo "🔑 Generated DB password: $DB_PASSWORD"
  echo "   (Save this somewhere safe!)"
  echo ""
fi

# Step 1: Install system packages
echo "📦 Step 1: Installing system packages..."
apt update -qq
apt install -y -qq curl git nginx postgresql postgresql-contrib ufw

# Install Node.js
if ! command -v node &> /dev/null; then
  echo "   Installing Node.js $NODE_VERSION..."
  curl -fsSL "https://deb.nodesource.com/setup_$NODE_VERSION.x" | bash -
  apt install -y -qq nodejs
fi

# Install PM2
if ! command -v pm2 &> /dev/null; then
  echo "   Installing PM2..."
  npm install -g pm2
fi

echo "   ✅ Node.js: $(node --version)"
echo "   ✅ npm: $(npm --version)"
echo "   ✅ PM2: $(pm2 --version)"
echo ""

# Step 2: Configure PostgreSQL
echo "🗄️  Step 2: Configuring PostgreSQL..."
systemctl start postgresql
systemctl enable postgresql

sudo -u postgres psql << EOF
CREATE DATABASE $DB_NAME ENCODING 'UTF8' LC_COLLATE 'C' LC_CTYPE 'C' TEMPLATE template0;
CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;
ALTER USER $DB_USER WITH SUPERUSER;
EOF

echo "   ✅ Database: $DB_NAME"
echo "   ✅ User: $DB_USER"
echo ""

# Step 3: Copy project
echo "📁 Step 3: Setting up project..."
mkdir -p "$PROJECT_DIR"

if [ -z "$(ls -A $PROJECT_DIR 2>/dev/null)" ]; then
  echo "   ⚠️  Project directory is empty!"
  echo "   Please copy your project files to: $PROJECT_DIR"
  echo "   Or run: scp -r ./* user@server:$PROJECT_DIR/"
  echo ""
  echo "   After copying, run this script again."
  exit 1
fi

chown -R www-data:www-data "$PROJECT_DIR"
chmod -R 755 "$PROJECT_DIR"
echo "   ✅ Project ready at: $PROJECT_DIR"
echo ""

# Step 4: Configure .env
echo "⚙️  Step 4: Configuring .env..."
cd "$PROJECT_DIR"

JWT_SECRET=$(openssl rand -hex 32)
JWT_REFRESH_SECRET=$(openssl rand -hex 32)

cat > .env << EOF
DATABASE_URL="postgresql://$DB_USER:$DB_PASSWORD@localhost:5432/$DB_NAME?schema=public"
JWT_SECRET=$JWT_SECRET
JWT_REFRESH_SECRET=$JWT_REFRESH_SECRET
DEFAULT_TENANT_ID=1
PORT=4000
NODE_ENV=production
CORS_ORIGINS=https://yio.ir,https://www.yio.ir
NEXT_PUBLIC_API_URL=https://api.yio.ir/api/v1
NEXT_PUBLIC_SITE_URL=https://yio.ir
MELIPAYAMAK_USERNAME=
MELIPAYAMAK_PASSWORD=
MELIPAYAMAK_SENDER_NUMBER=5000270019
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
UPLOAD_DIR=storage/uploads
DOCUMENT_DIR=storage/documents
LOG_LEVEL=info
EOF

# Copy to sub-projects
cp .env apps/api/.env
cp .env packages/repositories/.env

chmod 600 .env apps/api/.env packages/repositories/.env
echo "   ✅ .env configured"
echo ""

# Step 5: Install dependencies
echo "📦 Step 5: Installing npm dependencies..."
npm install --legacy-peer-deps --production=false
echo "   ✅ Dependencies installed"
echo ""

# Step 6: Apply Prisma schema
echo "📊 Step 6: Applying database schema..."
cd packages/repositories
npx prisma generate --schema=prisma/schema.prisma
npx prisma db push --schema=prisma/schema.prisma --accept-data-loss
echo "   ✅ Schema applied"
echo ""

# Step 7: Seed database
echo "🌱 Step 7: Seeding database..."
npx tsx prisma/seed.ts
echo ""

# Step 8: Build
echo "🔨 Step 8: Building project..."
cd "$PROJECT_DIR/apps/api"
npm run build 2>/dev/null || echo "   ⚠️  API build skipped (will use tsx)"

cd "$PROJECT_DIR/apps/shop"
npm run build 2>/dev/null || echo "   ⚠️  Shop build skipped"
echo ""

# Step 9: Configure PM2
echo "🚀 Step 9: Starting with PM2..."
cd "$PROJECT_DIR"
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup systemd -u root --hp /root
echo "   ✅ PM2 configured"
echo ""

# Step 10: Configure Nginx
echo "🌐 Step 10: Configuring Nginx..."
cat > /etc/nginx/sites-available/yio-v7 << 'NGINX'
server {
    listen 80;
    server_name api.yio.ir;

    location / {
        proxy_pass http://127.0.0.1:4000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300;
    }

    client_max_body_size 100M;
}

server {
    listen 80;
    server_name yio.ir www.yio.ir;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    location /uploads/ {
        alias /var/www/yio-v7/storage/uploads/;
        expires 7d;
        add_header Cache-Control "public, immutable";
    }

    client_max_body_size 100M;
}
NGINX

ln -sf /etc/nginx/sites-available/yio-v7 /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx
echo "   ✅ Nginx configured"
echo ""

# Step 11: Configure firewall
echo "🛡️  Step 11: Configuring firewall..."
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable
echo "   ✅ Firewall enabled"
echo ""

# Step 12: Create storage directories
echo "📁 Step 12: Creating storage directories..."
mkdir -p "$PROJECT_DIR/storage/uploads"
mkdir -p "$PROJECT_DIR/storage/documents"
chown -R www-data:www-data "$PROJECT_DIR/storage"
echo "   ✅ Storage directories ready"
echo ""

# Final summary
echo "═══════════════════════════════════════════════════"
echo "  ✅ Deployment Complete!"
echo "═══════════════════════════════════════════════════"
echo ""
echo "📋 Important Information:"
echo "   Database: $DB_NAME"
echo "   DB User: $DB_USER"
echo "   DB Password: $DB_PASSWORD"
echo "   JWT Secret: $JWT_SECRET"
echo ""
echo "🔐 Admin Login:"
echo "   Phone: 09120000000"
echo "   Password: Admin@V7!2026"
echo ""
echo "🌐 URLs:"
echo "   API: http://api.yio.ir/api/v1"
echo "   Docs: http://api.yio.ir/api/docs"
echo "   Shop: http://yio.ir"
echo ""
echo "📝 Next Steps:"
echo "   1. Point your domain DNS to this server's IP"
echo "   2. Install SSL: sudo certbot --nginx -d yio.ir -d www.yio.ir -d api.yio.ir"
echo "   3. Configure SMS (Melipayamak) in .env"
echo "   4. Configure Email (SMTP) in .env"
echo "   5. Change admin password!"
echo ""
echo "🔧 Management Commands:"
echo "   pm2 status              - Check services"
echo "   pm2 logs                - View logs"
echo "   pm2 restart all         - Restart all"
echo "   sudo systemctl status nginx   - Nginx status"
echo "   sudo systemctl status postgresql - DB status"
echo ""
