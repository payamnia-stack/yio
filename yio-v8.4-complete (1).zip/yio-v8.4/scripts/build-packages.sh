#!/bin/bash
# ============================================================
# YIO V7 — Build All Packages
# ============================================================
# این اسکریپت تمام پکیج‌های TypeScript را به JavaScript کامپایل می‌کند
# ============================================================

set -e

PROJECT_ROOT="${1:-/var/www/yio}"

if [ ! -d "$PROJECT_ROOT/packages" ]; then
  echo "❌ مسیر پروژه صحیح نیست: $PROJECT_ROOT"
  echo "استفاده: bash build-packages.sh /path/to/yio"
  exit 1
fi

echo "═══════════════════════════════════════════════════"
echo "  YIO V7 — Build All Packages"
echo "═══════════════════════════════════════════════════"
echo ""

# Build order matters (dependencies)
PACKAGES=("core" "ui" "repositories" "services" "ai")

for pkg in "${PACKAGES[@]}"; do
  echo "📦 Building @yio/$pkg..."
  cd "$PROJECT_ROOT/packages/$pkg"

  # Clean old dist
  rm -rf dist

  # Compile
  npx tsc 2>&1 | tail -5

  if [ -d "dist" ]; then
    echo "   ✅ Built successfully"
    ls dist/*.js 2>/dev/null | head -3
  else
    echo "   ❌ Build failed"
    exit 1
  fi
  echo ""
done

echo "═══════════════════════════════════════════════════"
echo "  ✅ All packages built!"
echo "═══════════════════════════════════════════════════"
echo ""
echo "حالا می‌توانید Next.js را build کنید:"
echo "  cd $PROJECT_ROOT/apps/shop"
echo "  npx next build"
echo ""
