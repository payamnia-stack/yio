#!/bin/bash
# ============================================================
# YIO V7 — Stop PostgreSQL
# ============================================================

PG_DIR="/home/z/my-project/pgsql"
PG_BIN="$PG_DIR/extract/usr/lib/postgresql/16/bin"
PG_DATA="$PG_DIR/data"

export LD_LIBRARY_PATH="$PG_DIR/extract/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH"

echo "🛑 Stopping PostgreSQL..."
"$PG_BIN/pg_ctl" -D "$PG_DATA" stop
echo "✅ PostgreSQL stopped"
