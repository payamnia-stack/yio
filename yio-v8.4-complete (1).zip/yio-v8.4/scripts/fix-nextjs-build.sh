#!/bin/bash
# ============================================================
# YIO V7 — Fix Next.js Build (Package Compilation)
# ============================================================
# این اسکریپت مشکل build پکیج‌های TypeScript را حل می‌کند
# اجرا در مسیر پروژه: /var/www/yio
# ============================================================

set -e

PROJECT_ROOT="${1:-/var/www/yio}"

if [ ! -d "$PROJECT_ROOT/packages" ]; then
  echo "❌ مسیر پروژه صحیح نیست: $PROJECT_ROOT"
  echo "استفاده: bash fix-nextjs-build.sh /path/to/yio"
  exit 1
fi

echo "═══════════════════════════════════════════════════"
echo "  YIO V7 — Fix Next.js Build"
echo "═══════════════════════════════════════════════════"
echo ""

# ============================================================
# Step 1: Update all package.json to point to dist/
# ============================================================
echo "📦 Step 1: Updating package.json files..."

for pkg in core ui services repositories ai; do
  PKG_DIR="$PROJECT_ROOT/packages/$pkg"
  if [ -f "$PKG_DIR/package.json" ]; then
    # Update main and types fields
    sed -i 's|"main": "src/index.ts"|"main": "dist/index.js"|' "$PKG_DIR/package.json"
    sed -i 's|"types": "src/index.ts"|"types": "dist/index.d.ts"|' "$PKG_DIR/package.json"
    echo "   ✅ $pkg/package.json updated"
  fi
done
echo ""

# ============================================================
# Step 2: Update all tsconfig.json to output CommonJS
# ============================================================
echo "⚙️  Step 2: Updating tsconfig.json files..."

for pkg in core ui services repositories ai; do
  PKG_DIR="$PROJECT_ROOT/packages/$pkg"
  if [ -d "$PKG_DIR" ]; then
    cat > "$PKG_DIR/tsconfig.json" << 'EOF'
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "CommonJS",
    "moduleResolution": "node",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true,
    "outDir": "dist",
    "rootDir": "src",
    "jsx": "react-jsx",
    "resolveJsonModule": true,
    "allowSyntheticDefaultImports": true
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist"]
}
EOF
    echo "   ✅ $pkg/tsconfig.json updated"
  fi
done
echo ""

# ============================================================
# Step 3: Update next.config.cjs for all apps
# ============================================================
echo "🌐 Step 3: Updating next.config.cjs files..."

for app in shop crm erp finance admin; do
  APP_DIR="$PROJECT_ROOT/apps/$app"
  if [ -d "$APP_DIR" ]; then
    cat > "$APP_DIR/next.config.cjs" << 'EOF'
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  transpilePackages: ['@yio/ui', '@yio/core', '@yio/services', '@yio/repositories', '@yio/ai'],
  images: {
    domains: ['localhost', 'yio.ir', 'api.yio.ir'],
  },
  env: {
    NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api/v1',
    NEXT_PUBLIC_SITE_URL: process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000',
  },
};

module.exports = nextConfig;
EOF
    echo "   ✅ $app/next.config.cjs updated"
  fi
done
echo ""

# ============================================================
# Step 4: Build all packages
# ============================================================
echo "🔨 Step 4: Building all packages..."

export DATABASE_URL="${DATABASE_URL:-postgresql://postgres:postgres@localhost:5432/yio_v7?schema=public}"

# Build order matters (dependencies)
PACKAGES=("core" "ui" "repositories" "services" "ai")

for pkg in "${PACKAGES[@]}"; do
  echo "   📦 Building @yio/$pkg..."
  cd "$PROJECT_ROOT/packages/$pkg"
  rm -rf dist
  npx tsc 2>&1 | tail -3
  if [ -d "dist" ] && [ "$(ls -A dist 2>/dev/null)" ]; then
    echo "      ✅ Built"
  else
    echo "      ❌ Build failed for $pkg"
    exit 1
  fi
done
echo ""

echo "═══════════════════════════════════════════════════"
echo "  ✅ All fixes applied and packages built!"
echo "═══════════════════════════════════════════════════"
echo ""
echo "حالا می‌توانید Next.js را build کنید:"
echo ""
echo "  cd $PROJECT_ROOT/apps/shop"
echo "  npx next build"
echo ""
echo "و برای سایر پنل‌ها:"
echo "  cd $PROJECT_ROOT/apps/crm"
echo "  npx next build"
echo ""
