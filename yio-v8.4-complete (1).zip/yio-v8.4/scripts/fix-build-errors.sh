#!/bin/bash
# ============================================================
# YIO V7 — Fix Build Errors Patch
# ============================================================
# این اسکریپت خطاهای TypeScript را اصلاح می‌کند
# اجرا در مسیر پروژه: /var/www/yio
# ============================================================

set -e

PROJECT_ROOT="${1:-/var/www/yio}"

if [ ! -d "$PROJECT_ROOT/packages" ]; then
  echo "❌ مسیر پروژه صحیح نیست: $PROJECT_ROOT"
  echo "استفاده: bash fix-build-errors.sh /path/to/yio"
  exit 1
fi

echo "═══════════════════════════════════════════════════"
echo "  YIO V7 — Fix Build Errors"
echo "═══════════════════════════════════════════════════"
echo ""

# ============================================================
# Fix 1: order.repository.ts - remove deletedAt
# ============================================================
echo "🔧 Fix 1: order.repository.ts"
FILE="$PROJECT_ROOT/packages/repositories/src/order.repository.ts"
if [ -f "$FILE" ]; then
  sed -i 's|where: { userId, tenantId: ctx.tenantId, deletedAt: null },|where: { userId, tenantId: ctx.tenantId },|' "$FILE"
  echo "   ✅ Fixed"
else
  echo "   ⚠️  File not found"
fi

# ============================================================
# Fix 2: document-engine.ts - null to undefined
# ============================================================
echo "🔧 Fix 2: document-engine.ts"
FILE="$PROJECT_ROOT/packages/services/src/engines/document-engine.ts"
if [ -f "$FILE" ]; then
  sed -i 's|uploadedBy: document.uploadedBy,$|uploadedBy: document.uploadedBy || undefined,|' "$FILE"
  echo "   ✅ Fixed"
else
  echo "   ⚠️  File not found"
fi

# ============================================================
# Fix 3: order-engine.ts - remove tenantId from OrderItem
# ============================================================
echo "🔧 Fix 3: order-engine.ts"
FILE="$PROJECT_ROOT/packages/services/src/engines/order-engine.ts"
if [ -f "$FILE" ]; then
  sed -i 's|data: { ...item, orderId: order.id, tenantId: ctx.tenantId },|data: { ...item, orderId: order.id },|' "$FILE"
  echo "   ✅ Fixed"
else
  echo "   ⚠️  File not found"
fi

# ============================================================
# Fix 4: permission-engine.ts - readonly array
# ============================================================
echo "🔧 Fix 4: permission-engine.ts"
FILE="$PROJECT_ROOT/packages/services/src/engines/permission-engine.ts"
if [ -f "$FILE" ]; then
  sed -i 's|return ROLES\[role\].permissions as string\[\];|return [...ROLES[role].permissions];|' "$FILE"
  sed -i 's|permissions: role.permissions as string\[\],|permissions: [...role.permissions],|' "$FILE"
  sed -i 's|const rolePerms = ROLES\[params.userRole as RoleName\].permissions as string\[\];|const rolePerms = [...ROLES[params.userRole as RoleName].permissions];|' "$FILE"
  echo "   ✅ Fixed"
else
  echo "   ⚠️  File not found"
fi

# ============================================================
# Fix 5: production-engine.ts - remove tenantId from Routing/WorkOrderStep
# ============================================================
echo "🔧 Fix 5: production-engine.ts"
FILE="$PROJECT_ROOT/packages/services/src/engines/production-engine.ts"
if [ -f "$FILE" ]; then
  # Remove tenantId from Routing where clause
  sed -i 's|where: { productId: input.productId, isActive: true, tenantId: ctx.tenantId },|where: { productId: input.productId, isActive: true },|' "$FILE"
  # Add `as any` to routing
  sed -i 's|include: { steps: { where: { isActive: true }, orderBy: { stepOrder: '"'"'asc'"'"' } } },$|include: { steps: { where: { isActive: true }, orderBy: { stepOrder: '"'"'asc'"'"' } } },\n    }) as any;|' "$FILE"
  # Update the if condition to check for steps
  sed -i 's|if (routing \&\& routing.steps.length > 0) {|if (routing \&\& routing.steps \&\& routing.steps.length > 0) {|' "$FILE"
  # Remove tenantId from WorkOrderStep create
  sed -i '/quantityReject: 0,/{n;/tenantId: ctx.tenantId,/d}' "$FILE"
  # Remove tenantId from WorkOrderStep findFirst
  sed -i 's|where: { workOrderId, stepOrder, tenantId: ctx.tenantId },|where: { workOrderId, stepOrder },|' "$FILE"
  echo "   ✅ Fixed"
else
  echo "   ⚠️  File not found"
fi

echo ""
echo "═══════════════════════════════════════════════════"
echo "  ✅ All fixes applied!"
echo "═══════════════════════════════════════════════════"
echo ""
echo "حالا build را مجدداً اجرا کنید:"
echo ""
echo "  cd $PROJECT_ROOT/apps/api"
echo "  npx tsc --outDir dist"
echo ""
echo "اگر خطاها برطرف شده‌اند، ادامه دهید:"
echo "  cd $PROJECT_ROOT/apps/shop"
echo "  npx next build"
echo ""
