#!/bin/bash
# ============================================================
# YIO V7 — Start Shop Panel (Local Development)
# ============================================================

set -e

PROJECT_ROOT="/home/z/my-project/site/yio-v7"
cd "$PROJECT_ROOT/apps/shop"

export NEXT_PUBLIC_API_URL="${NEXT_PUBLIC_API_URL:-http://localhost:4000/api/v1}"
export NEXT_PUBLIC_SITE_URL="${NEXT_PUBLIC_SITE_URL:-http://localhost:3000}"

echo "🚀 Starting YIO Shop Panel..."
echo "   URL: http://localhost:3000"
echo "   API: $NEXT_PUBLIC_API_URL"
echo ""

pkill -f "next dev.*3000" 2>/dev/null || true
sleep 1

npx next dev -p 3000
