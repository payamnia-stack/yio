#!/bin/bash
# ============================================================
# YIO V7 — Start PostgreSQL (Local Development)
# ============================================================

set -e

PG_DIR="/home/z/my-project/pgsql"
PG_BIN="$PG_DIR/extract/usr/lib/postgresql/16/bin"
PG_DATA="$PG_DIR/data"
PG_LOG="$PG_DIR/server.log"

export LD_LIBRARY_PATH="$PG_DIR/extract/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH"

if "$PG_BIN/pg_ctl" -D "$PG_DATA" status 2>/dev/null | grep -q "running"; then
  echo "✅ PostgreSQL already running"
  exit 0
fi

echo "🚀 Starting PostgreSQL..."
"$PG_BIN/pg_ctl" -D "$PG_DATA" -l "$PG_LOG" start
sleep 2

if "$PG_BIN/pg_ctl" -D "$PG_DATA" status 2>/dev/null | grep -q "running"; then
  echo "✅ PostgreSQL started"
  echo "   Connection: postgresql://postgres:yio_v7_password@localhost:5432/yio_v7"
else
  echo "❌ Failed to start PostgreSQL"
  tail -10 "$PG_LOG"
  exit 1
fi
