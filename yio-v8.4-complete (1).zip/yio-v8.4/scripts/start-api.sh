#!/bin/bash
# ============================================================
# YIO V7 — Start API Server (Local Development)
# ============================================================

set -e

PROJECT_ROOT="/home/z/my-project/site/yio-v7"
PG_DIR="/home/z/my-project/pgsql"

export LD_LIBRARY_PATH="$PG_DIR/extract/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH"
export DATABASE_URL="postgresql://postgres:yio_v7_password@localhost:5432/yio_v7?schema=public"
export JWT_SECRET="${JWT_SECRET:-dev-jwt-secret-change-in-production-2026}"
export JWT_REFRESH_SECRET="${JWT_REFRESH_SECRET:-dev-refresh-secret-change-in-production-2026}"
export NODE_ENV="${NODE_ENV:-development}"
export PORT="${PORT:-4000}"

cd "$PROJECT_ROOT/apps/api"

# Check if PostgreSQL is running
if ! "$PG_DIR/extract/usr/lib/postgresql/16/bin/pg_ctl" -D "$PG_DIR/data" status 2>/dev/null | grep -q "running"; then
  echo "⚠️  PostgreSQL is not running. Starting it..."
  bash "$PROJECT_ROOT/scripts/start-postgres.sh"
  sleep 2
fi

echo "🚀 Starting YIO V7 API Server..."
echo "   Port: $PORT"
echo "   API:  http://localhost:$PORT/api/v1"
echo "   Docs: http://localhost:$PORT/api/docs"
echo ""

pkill -f "tsx.*src/server.ts" 2>/dev/null || true
sleep 1

npx tsx src/server.ts
