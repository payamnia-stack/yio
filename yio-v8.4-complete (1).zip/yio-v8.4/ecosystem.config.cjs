// ============================================================
// YIO V7 — PM2 Ecosystem Configuration
// ============================================================
// راه‌اندازی همه سرویس‌ها با PM2
//
// Usage:
//   pm2 start ecosystem.config.cjs
//   pm2 status
//   pm2 logs
//   pm2 stop all
//   pm2 delete all
// ============================================================

module.exports = {
  apps: [
    // ===== API Server =====
    {
      name: 'yio-v7-api',
      script: 'apps/api/dist/server.js',
      cwd: '/var/www/yio-v7',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      env: {
        NODE_ENV: 'production',
        PORT: 4000,
      },
      error_file: '/var/log/yio-v7/api-error.log',
      out_file: '/var/log/yio-v7/api-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
    },

    // ===== Web Frontend (Next.js) =====
    {
      name: 'yio-v7-web',
      script: 'apps/web/dist/server.js',
      cwd: '/var/www/yio-v7',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
      error_file: '/var/log/yio-v7/web-error.log',
      out_file: '/var/log/yio-v7/web-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
    },

    // ===== Background Worker (for events, notifications, scheduled tasks) =====
    {
      name: 'yio-v7-worker',
      script: 'apps/worker/dist/index.js',
      cwd: '/var/www/yio-v7',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'production',
      },
      error_file: '/var/log/yio-v7/worker-error.log',
      out_file: '/var/log/yio-v7/worker-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
    },
  ],
};
