# YIO V8.2 → V8.3

## What changed

- Product media is exposed through `ProductImage` and `ProductVideo`.
- Product colors are exposed through `ProductColor`.
- Product price/stock is exposed through `ProductVariant`.
- A variant can reference a `ProductColor` and one active variant can be marked `isDefault`.
- Price history can reference the exact variant.
- ABAC policy names are unique per tenant instead of globally.
- Repository updates/deletes enforce tenant ownership before mutation.
- Product stock operations prefer the default active variant and keep the legacy Product mirror synchronized during the compatibility window.
- Order creation in the API is routed through `OrderUseCase` instead of accepting client-supplied totals.
- Shop homepage loads published products from the API and renders relational images/variants.

## Migration order

1. Take a PostgreSQL backup.
2. Run `001-product-relations.sql`.
3. Deploy the V8.3 application.
4. Verify product images, colors, variants, prices and stock.
5. Only after all consumers are migrated, run `002-final-drop-legacy-product-columns.sql`.
6. Then update `schema.prisma` to remove the compatibility fields from `Product`.

The main V8.3 package intentionally keeps the old columns in the Prisma schema for a safe rolling deployment. The final SQL is destructive and should never be run before step 5.
