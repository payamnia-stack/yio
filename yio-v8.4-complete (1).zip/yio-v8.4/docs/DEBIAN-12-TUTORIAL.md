# آموزش کامل راه‌اندازی YIO V7 روی Debian 12

> راهنمای گام به گام از صفر تا production

## 📋 فهرست

1. [پیش‌نیازها](#1-پیشنیازها)
2. [آماده‌سازی سرور Debian 12](#2-آمادهسازی-سرور-debian-12)
3. [نصب Node.js و npm](#3-نصب-nodejs-و-npm)
4. [نصب PostgreSQL](#4-نصب-postgresql)
5. [نصب PM2](#5-نصب-pm2)
6. [نصب Nginx](#6-نصب-nginx)
7. [استقرار پروژه YIO V7](#7-استقرار-پروژه-yio-v7)
8. [پیکربندی دیتابیس](#8-پیکربندی-دیتابیس)
9. [Build و راه‌اندازی](#9-build-و-راهاندازی)
10. [پیکربندی Nginx Reverse Proxy](#10-پیکربندی-nginx-reverse-proxy)
11. [نصب SSL/HTTPS](#11-نصب-sslhttps)
12. [مدیریت با PM2](#12-مدیریت-با-pm2)
13. [بک‌آپ و بازیابی](#13-بکآپ-و-بازیابی)
14. [رفع اشکال](#14-رفع-اشکال)
15. [راهنمای استفاده](#15-راهنمای-استفاده)

---

## 1. پیش‌نیازها

### مشخصات سرور پیشنهادی

| منبع | حداقل | پیشنهادی |
|------|-------|----------|
| CPU | 1 core | 2 core |
| RAM | 1 GB | 2 GB |
| Disk | 10 GB | 20 GB SSD |
| OS | Debian 12 | Debian 12 |
| دسترسی | root یا sudo | root |

### نرم‌افزارهای مورد نیاز

- Debian 12 (Bookworm)
- Node.js 20 LTS
- PostgreSQL 15+
- PM2
- Nginx

---

## 2. آماده‌سازی سرور Debian 12

### مرحله ۱: اتصال به سرور

```bash
# از طریق SSH
ssh root@your-server-ip

# یا با sudo user
ssh username@your-server-ip
sudo -i
```

### مرحله ۲: آپدیت سیستم

```bash
# آپدیت لیست پکیج‌ها
apt update

# آپدیت همه پکیج‌ها
apt upgrade -y

# نصب پکیج‌های پایه
apt install -y curl wget git unzip software-properties-common apt-transport-https ca-certificates gnupg lsb-release
```

### مرحله ۳: تنظیم TimeZone

```bash
# تنظیم timezone (برای ایران)
timedatectl set-timezone Asia/Tehran

# بررسی
timedatectl
```

### مرحله ۴: تنظیم Swap (در صورت کمبود RAM)

```bash
# اگر RAM کمتر از 2GB است، swap اضافه کنید
fallocate -l 2G /swapfile
chmod 600 /swapfile
mkswap /swapfile
swapon /swapfile

# دائمی کردن
echo '/swapfile none swap sw 0 0' >> /etc/fstab

# بررسی
free -h
```

### مرحله ۵: پیکربندی Firewall

```bash
# نصب UFW
apt install -y ufw

# اجازه دسترسی SSH
ufw allow OpenSSH

# اجازه دسترسی HTTP و HTTPS
ufw allow 'Nginx Full'

# فعال‌سازی firewall
ufw --force enable

# بررسی وضعیت
ufw status verbose
```

---

## 3. نصب Node.js و npm

### روش ۱: نصب از NodeSource (توصیه می‌شود)

```bash
# دانلود اسکریپت نصب Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -

# نصب Node.js
apt install -y nodejs

# بررسی نصب
node --version
# خروجی: v20.x.x

npm --version
# خروجی: 10.x.x
```

### روش ۲: نصب از مخزن Debian

```bash
apt install -y nodejs npm
```

> ⚠️ **توجه**: نسخه‌های مخزن Debian ممکن است قدیمی باشند. روش ۱ توصیه می‌شود.

### تنظیم npm (اختیاری)

```bash
# تنظیم npm برای نصب global بدون sudo
mkdir ~/.npm-global
npm config set prefix '~/.npm-global'

# اضافه کردن به PATH
echo 'export PATH=~/.npm-global/bin:$PATH' >> ~/.bashrc
source ~/.bashrc

# بررسی
npm config get prefix
```

---

## 4. نصب PostgreSQL

### مرحله ۱: نصب PostgreSQL

```bash
# نصب PostgreSQL 15
apt install -y postgresql postgresql-contrib

# بررسی نصب
psql --version
# خروجی: psql (PostgreSQL) 15.x

# بررسی سرویس
systemctl status postgresql
```

### مرحله ۲: راه‌اندازی خودکار

```bash
# فعال‌سازی راه‌اندازی خودکار هنگام بوت
systemctl enable postgresql

# شروع سرویس
systemctl start postgresql
```

### مرحله ۳: تنظیم رمز postgres

```bash
# ورود به PostgreSQL
su - postgres
psql

# در محیط psql:
\password postgres
# رمز جدید را وارد کنید (مثلاً: YioSecurePass2026!)

# خروج
\q
exit
```

### مرحله ۴: ایجاد دیتابیس و کاربر

```bash
# ورود به PostgreSQL
su - postgres
psql

# ایجاد کاربر
CREATE USER yio_user WITH PASSWORD 'YioSecurePass2026!';

# ایجاد دیتابیس
CREATE DATABASE yio_v7 ENCODING 'UTF8' LC_COLLATE 'C' LC_CTYPE 'C' TEMPLATE template0;

# اعطای دسترسی
GRANT ALL PRIVILEGES ON DATABASE yio_v7 TO yio_user;
ALTER USER yio_user WITH SUPERUSER;

# خروج
\q
exit
```

### مرحله ۵: پیکربندی اتصال远程 (اختیاری)

> ⚠️ **هشدار**: فقط اگر نیاز به اتصال از خارج سرور دارید این مرحله را انجام دهید.

```bash
# ویرایش فایل pg_hba.conf
nano /etc/postgresql/15/main/pg_hba.conf

# اضافه کردن خط (در انتهای فایل):
# host    all    yio_user    0.0.0.0/0    md5

# ویرایش postgresql.conf
nano /etc/postgresql/15/main/postgresql.conf

# پیدا و تغییر:
# listen_addresses = '*'

# ریستارت PostgreSQL
systemctl restart postgresql
```

### مرحله ۶: تست اتصال

```bash
# تست اتصال با کاربر جدید
psql -U yio_user -d yio_v7 -h localhost -W
# رمز: YioSecurePass2026!

# در محیط psql:
SELECT version();
\q
```

---

## 5. نصب PM2

### مرحله ۱: نصب PM2

```bash
# نصب global
npm install -g pm2

# بررسی
pm2 --version
```

### مرحله ۲: پیکربندی راه‌اندازی خودکار

```bash
# تولید اسکریپت راه‌اندازی
pm2 startup systemd

# خروجی شبیه این خواهد بود:
# [PM2] To setup the Startup Script, copy/paste the following command:
# sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup ...

# آن دستور را اجرا کنید
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u root --hp /root

# ذخیره تنظیمات فعلی
pm2 save
```

---

## 6. نصب Nginx

```bash
# نصب Nginx
apt install -y nginx

# فعال‌سازی راه‌اندازی خودکار
systemctl enable nginx

# شروع سرویس
systemctl start nginx

# بررسی وضعیت
systemctl status nginx
```

---

## 7. استقرار پروژه YIO V7

### مرحله ۱: ایجاد دایرکتوری پروژه

```bash
# ایجاد دایرکتوری
mkdir -p /var/www/yio-v7

# رفتن به دایرکتوری
cd /var/www/yio-v7
```

### مرحله ۲: کپی فایل‌های پروژه

#### روش الف: آپلود فایل ZIP

```bash
# از طریق SCP از کامپیوتر شخصی
scp yio-v7.zip root@your-server-ip:/var/www/yio-v7/

# در سرور:
cd /var/www/yio-v7
unzip yio-v7.zip
mv yio-v7/* .
mv yio-v7/.* . 2>/dev/null
rmdir yio-v7
rm yio-v7.zip
```

#### روش ب: کلون از Git

```bash
git clone https://github.com/your-repo/yio-v7.git .
```

### مرحله ۳: تنظیم مالکیت

```bash
# تنظیم مالکیت
chown -R www-data:www-data /var/www/yio-v7
chmod -R 755 /var/www/yio-v7

# اضافه کردن کاربر فعلی به گروه www-data
usermod -aG www-data $USER
```

### مرحله ۴: نصب وابستگی‌ها

```bash
cd /var/www/yio-v7

# نصب وابستگی‌ها
npm install --legacy-peer-deps

# بررسی نصب
ls node_modules/@yio/
# باید ببینید: admin ai api core crm erp finance mobile repositories services shop ui
```

---

## 8. پیکربندی دیتابیس

### مرحله ۱: ایجاد فایل `.env`

```bash
cd /var/www/yio-v7
cp .env.example .env
nano .env
```

### محتوای فایل `.env`:

```env
# ============================================================
# Database
# ============================================================
DATABASE_URL="postgresql://yio_user:YioSecurePass2026!@localhost:5432/yio_v7?schema=public"

# ============================================================
# JWT Secrets (تولید با: openssl rand -hex 32)
# ============================================================
JWT_SECRET=your-generated-jwt-secret-here
JWT_REFRESH_SECRET=your-generated-refresh-secret-here

# ============================================================
# Multi-Tenant
# ============================================================
DEFAULT_TENANT_ID=1

# ============================================================
# API Server
# ============================================================
PORT=4000
NODE_ENV=production

# ============================================================
# CORS
# ============================================================
CORS_ORIGINS=https://yio.ir,https://www.yio.ir

# ============================================================
# Next.js (Shop)
# ============================================================
NEXT_PUBLIC_API_URL=https://api.yio.ir/api/v1
NEXT_PUBLIC_SITE_URL=https://yio.ir

# ============================================================
# SMS (Melipayamak)
# ============================================================
MELIPAYAMAK_USERNAME=your_melipayamak_username
MELIPAYAMAK_PASSWORD=your_melipayamak_password
MELIPAYAMAK_SENDER_NUMBER=5000270019

# ============================================================
# Email (SMTP)
# ============================================================
SMTP_HOST=smtp.yio.ir
SMTP_PORT=587
SMTP_USER=info@yio.ir
SMTP_PASSWORD=your_email_password

# ============================================================
# File Storage
# ============================================================
UPLOAD_DIR=storage/uploads
DOCUMENT_DIR=storage/documents
MAX_FILE_SIZE=104857600

# ============================================================
# Rate Limiting
# ============================================================
RATE_LIMIT_GENERAL=100
RATE_LIMIT_AUTH=5
RATE_LIMIT_WRITE=30

# ============================================================
# Logging
# ============================================================
LOG_LEVEL=info
```

### تولید JWT Secrets:

```bash
# تولید JWT Secret
openssl rand -hex 32
# خروجی: a1b2c3d4e5... (64 کاراکتر)

# تولید Refresh Secret
openssl rand -hex 32
# خروجی: f6g7h8i9j0...
```

### مرحله ۲: کپی `.env` به زیرپروژه‌ها

```bash
# کپی به apps/api
cp .env apps/api/.env

# کپی به packages/repositories
cp .env packages/repositories/.env

# تنظیم دسترسی (مهم برای امنیت)
chmod 600 .env apps/api/.env packages/repositories/.env
```

### مرحله ۳: اعمال Schema به دیتابیس

```bash
cd /var/www/yio-v7/packages/repositories

# تولید Prisma Client
npx prisma generate --schema=prisma/schema.prisma

# اعمال Schema به دیتابیس
npx prisma db push --schema=prisma/schema.prisma --accept-data-loss

# خروجی مورد انتظار:
# 🚀 Your database is now in sync with your Prisma schema.
```

### مرحله ۴: Seed دیتابیس

```bash
# اجرای seed
npx tsx prisma/seed.ts

# خروجی:
# ✅ Seed completed successfully!
# Default Admin Credentials:
#   Phone:    09120000000
#   Password: Admin@V7!2026
```

### مرحله ۵: تست اتصال دیتابیس

```bash
# تست با psql
psql -U yio_user -d yio_v7 -h localhost -W

# در psql:
\dt
# باید لیست جدول‌ها را ببینید

SELECT count(*) FROM "Tenant";
# باید 1 برگرداند

SELECT count(*) FROM "User";
# باید 1 برگرداند

\q
```

---

## 9. Build و راه‌اندازی

### مرحله ۱: ایجاد دایرکتوری‌های storage

```bash
cd /var/www/yio-v7
mkdir -p storage/uploads storage/documents
chown -R www-data:www-data storage
chmod -R 755 storage
```

### مرحله ۲: Build API

```bash
cd /var/www/yio-v7/apps/api

# Build TypeScript
npx tsc --outDir dist

# یا اجرای مستقیم با tsx (در production از build استفاده کنید)
```

### مرحله ۳: Build Shop (Next.js)

```bash
cd /var/www/yio-v7/apps/shop

# Build Next.js
npx next build

# تست اجرا
npx next start -p 3000
# Ctrl+C برای توقف
```

### مرحله ۴: پیکربندی PM2

```bash
cd /var/www/yio-v7

# ویرایش ecosystem.config.cjs
nano ecosystem.config.cjs
```

محتوای فایل:
```javascript
module.exports = {
  apps: [
    {
      name: 'yio-v7-api',
      script: 'apps/api/dist/server.js',
      cwd: '/var/www/yio-v7',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      env: {
        NODE_ENV: 'production',
        PORT: 4000,
      },
      error_file: '/var/log/yio-v7/api-error.log',
      out_file: '/var/log/yio-v7/api-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
    },
    {
      name: 'yio-v7-shop',
      script: 'node_modules/.bin/next',
      args: 'start -p 3000',
      cwd: '/var/www/yio-v7/apps/shop',
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: '1G',
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
      },
      error_file: '/var/log/yio-v7/shop-error.log',
      out_file: '/var/log/yio-v7/shop-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
    },
  ],
};
```

### مرحله ۵: ایجاد دایرکتوری لاگ

```bash
mkdir -p /var/log/yio-v7
chown -R www-data:www-data /var/log/yio-v7
```

### مرحله ۶: شروع با PM2

```bash
cd /var/www/yio-v7

# شروع سرویس‌ها
pm2 start ecosystem.config.cjs

# بررسی وضعیت
pm2 status

# خروجی:
# ┌────────────┬────┬──────┬──────┬────────┬─────────┐
# │ App name   │ id │ mode │ pid  │ status │ restart │
# ├────────────┼────┼──────┼──────┼────────┼─────────┤
# │ yio-v7-api │ 0  │ fork │ 1234 │ online │ 0       │
# │ yio-v7-shop│ 1  │ fork │ 1235 │ online │ 0       │
# └────────────┴────┴──────┴──────┴────────┴─────────┘

# ذخیره تنظیمات
pm2 save
```

### مرحله ۷: تست سرویس‌ها

```bash
# تست API
curl http://localhost:4000/health
# خروجی: {"status":"ok","service":"yio-v7-api",...}

# تست Login
curl -X POST http://localhost:4000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"phone":"09120000000","password":"Admin@V7!2026"}'

# تست Shop
curl http://localhost:3000
# باید HTML برگرداند
```

---

## 10. پیکربندی Nginx Reverse Proxy

### مرحله ۱: ایجاد فایل کانفیگ

```bash
nano /etc/nginx/sites-available/yio-v7
```

### محتوای فایل:

```nginx
# ============================================================
# YIO V7 — API Server
# ============================================================
server {
    listen 80;
    server_name api.yio.ir;

    # Redirect to HTTPS
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name api.yio.ir;

    # SSL (بعداً با Certbot تنظیم می‌شود)
    # ssl_certificate /etc/letsencrypt/live/api.yio.ir/fullchain.pem;
    # ssl_certificate_key /etc/letsencrypt/live/api.yio.ir/privkey.pem;

    # Limits
    client_max_body_size 100M;

    # API Proxy
    location / {
        proxy_pass http://127.0.0.1:4000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300;
        proxy_send_timeout 300;
    }

    # Static files (uploads)
    location /uploads/ {
        alias /var/www/yio-v7/storage/uploads/;
        expires 7d;
        add_header Cache-Control "public, immutable";
        add_header X-Content-Type-Options "nosniff";
    }

    # Rate limiting
    limit_req_zone $binary_remote_addr zone=api_limit:10m rate=10r/s;
    limit_req zone=api_limit burst=20 nodelay;
}

# ============================================================
# YIO V7 — Shop (فروشگاه)
# ============================================================
server {
    listen 80;
    server_name yio.ir www.yio.ir;

    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yio.ir www.yio.ir;

    # SSL
    # ssl_certificate /etc/letsencrypt/live/yio.ir/fullchain.pem;
    # ssl_certificate_key /etc/letsencrypt/live/yio.ir/privkey.pem;

    client_max_body_size 100M;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # Next.js static files
    location /_next/static/ {
        proxy_pass http://127.0.0.1:3000;
        expires 365d;
        add_header Cache-Control "public, immutable";
    }
}
```

### مرحله ۲: فعال‌سازی سایت

```bash
# ایجاد symlink
ln -sf /etc/nginx/sites-available/yio-v7 /etc/nginx/sites-enabled/

# حذف سایت پیش‌فرض
rm -f /etc/nginx/sites-enabled/default

# تست کانفیگ
nginx -t
# خروجی: nginx: configuration file /etc/nginx/nginx.conf test is successful

# ریستارت Nginx
systemctl reload nginx
```

### مرحله ۳: تنظیم DNS

در پنل DNS دامنه خود، رکوردهای زیر را اضافه کنید:

```
A    yio.ir           → IP سرور
A    www.yio.ir       → IP سرور
A    api.yio.ir       → IP سرور
```

---

## 11. نصب SSL/HTTPS

### مرحله ۱: نصب Certbot

```bash
apt install -y certbot python3-certbot-nginx
```

### مرحله ۲: دریافت گواهی SSL

```bash
# دریافت گواهی برای همه دامنه‌ها
certbot --nginx -d yio.ir -d www.yio.ir -d api.yio.ir

# پاسخ به سوالات:
# - ایمیل: your@email.com
# - موافقت با قوانین: A
# - اشتراک ایمیل: N
# - Redirect HTTP to HTTPS: 2 (Yes)
```

### مرحله ۳: بررسی تمدید خودکار

```bash
# تست تمدید
certbot renew --dry-run

# تمدید خودکار در crontab
crontab -e
# اضافه کنید:
0 3 * * * certbot renew --quiet --post-hook "systemctl reload nginx"
```

---

## 12. مدیریت با PM2

### دستورات اصلی

```bash
# مشاهده وضعیت
pm2 status

# مشاهده لاگ‌ها
pm2 logs                    # همه
pm2 logs yio-v7-api         # فقط API
pm2 logs yio-v7-shop        # فقط Shop

# ریستارت
pm2 restart yio-v7-api
pm2 restart yio-v7-shop
pm2 restart all

# توقف
pm2 stop yio-v7-api
pm2 stop all

# حذف
pm2 delete yio-v7-api
pm2 delete all

# مانیتورینگ زنده
pm2 monit
```

### پیکربندی Log Rotation

```bash
# نصب pm2-logrotate
pm2 install pm2-logrotate

# پیکربندی
pm2 set pm2-logrotate:max_size 10M
pm2 set pm2-logrotate:retain 30
pm2 set pm2-logrotate:compress true
pm2 set pm2-logrotate:dateFormat YYYY-MM-DD_HH-mm-ss
pm2 set pm2-logrotate:workerInterval 30
pm2 set pm2-logrotate:rotateInterval '0 0 * * *'
```

### آپدیت پروژه

```bash
cd /var/www/yio-v7

# ۱. توقف سرویس‌ها
pm2 stop all

# ۲. بک‌آپ دیتابیس
pg_dump -U yio_user -d yio_v7 > /backup/yio_v7_$(date +%Y%m%d).sql

# ۳. آپدیت کد
git pull origin main
# یا کپی فایل‌های جدید

# ۴. نصب وابستگی‌های جدید
npm install --legacy-peer-deps

# ۵. اعمال تغییرات Schema
cd packages/repositories
npx prisma generate
npx prisma db push --accept-data-loss

# ۶. Build
cd /var/www/yio-v7
npm run build

# ۷. ریستارت
pm2 restart all
```

---

## 13. بک‌آپ و بازیابی

### بک‌آپ دستی

```bash
# ایجاد دایرکتوری بک‌آپ
mkdir -p /backup

# بک‌آپ دیتابیس
pg_dump -U yio_user -d yio_v7 > /backup/yio_v7_$(date +%Y%m%d_%H%M%S).sql

# بک‌آپ فایل‌های آپلود شده
tar -czf /backup/uploads_$(date +%Y%m%d).tar.gz /var/www/yio-v7/storage/uploads/

# بک‌آپ فایل .env
cp /var/www/yio-v7/.env /backup/env_backup_$(date +%Y%m%d)

# لیست بک‌آپ‌ها
ls -la /backup/
```

### بک‌آپ خودکار (Cron)

```bash
# ایجاد اسکریپت بک‌آپ
nano /backup/backup.sh
```

محتوای فایل:
```bash
#!/bin/bash
BACKUP_DIR="/backup"
DB_USER="yio_user"
DB_NAME="yio_v7"
DATE=$(date +%Y%m%d_%H%M%S)

# بک‌آپ دیتابیس
pg_dump -U $DB_USER -d $DB_NAME > $BACKUP_DIR/db_$DATE.sql

# بک‌آپ uploads
tar -czf $BACKUP_DIR/uploads_$DATE.tar.gz /var/www/yio-v7/storage/uploads/

# حذف بک‌آپ‌های قدیمی‌تر از ۷ روز
find $BACKUP_DIR -name "*.sql" -mtime +7 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +7 -delete

echo "Backup completed: $DATE"
```

```bash
# اجرایی کردن
chmod +x /backup/backup.sh

# تنظیم cron
crontab -e

# اضافه کنید (هر روز ساعت ۲ نصفه شب):
0 2 * * * /backup/backup.sh >> /var/log/backup.log 2>&1
```

### بازیابی

```bash
# ۱. توقف سرویس‌ها
pm2 stop all

# ۲. بازیابی دیتابیس
psql -U yio_user -d yio_v7 < /backup/db_20260727_020000.sql

# ۳. بازیابی فایل‌ها
tar -xzf /backup/uploads_20260727.tar.gz -C /

# ۴. شروع سرویس‌ها
pm2 start all
```

---

## 14. رفع اشکال

### مشکل: PostgreSQL اجرا نمی‌شود

```bash
# بررسی وضعیت
systemctl status postgresql

# مشاهده لاگ
journalctl -u postgresql -n 50

# شروع مجدد
systemctl restart postgresql

# بررسی پورت
ss -tlnp | grep 5432
```

### مشکل: API در دسترس نیست

```bash
# بررسی PM2
pm2 status
pm2 logs yio-v7-api --lines 50

# بررسی پورت
ss -tlnp | grep 4000

# ریستارت
pm2 restart yio-v7-api

# تست مستقیم
curl http://localhost:4000/health
```

### مشکل: خطای اتصال دیتابیس

```bash
# تست اتصال
psql -U yio_user -d yio_v7 -h localhost -W

# بررسی DATABASE_URL
cat /var/www/yio-v7/.env | grep DATABASE_URL

# بررسی لاگ PostgreSQL
tail -50 /var/log/postgresql/postgresql-15-main.log
```

### مشکل: Nginx خطای 502 Bad Gateway

```bash
# بررسی اینکه API در حال اجراست
curl http://localhost:4000/health

# بررسی Nginx
nginx -t
systemctl status nginx

# بررسی لاگ Nginx
tail -50 /var/log/nginx/error.log

# ریستارت
systemctl restart nginx
```

### مشکل: خطای Permission Denied

```bash
# تنظیم مجدد مالکیت
chown -R www-data:www-data /var/www/yio-v7
chmod -R 755 /var/www/yio-v7

# تنظیم دسترسی storage
chown -R www-data:www-data /var/www/yio-v7/storage
chmod -R 775 /var/www/yio-v7/storage
```

### مشکل: حافظه کم (Out of Memory)

```bash
# بررسی حافظه
free -h

# افزودن swap
fallocate -l 2G /swapfile
chmod 600 /swapfile
mkswap /swapfile
swapon /swapfile

# تنظیم PM2 برای restart خودکار
pm2 restart all --max-memory-restart 1G
```

---

## 15. راهنمای استفاده

### ورود به سیستم

پس از راه‌اندازی، به آدرس‌های زیر بروید:

| پنل | آدرس | کاربرد |
|-----|------|--------|
| فروشگاه | https://yio.ir | فروش آنلاین |
| CRM | https://crm.yio.ir | مدیریت فروش |
| ERP | https://erp.yio.ir | مدیریت تولید |
| مالی | https://finance.yio.ir | حسابداری |
| مدیریت | https://admin.yio.ir | مدیریت سیستم |
| API Docs | https://api.yio.ir/api/docs | مستندات API |

### ورود مدیر

- **موبایل**: `09120000000`
- **رمز عبور**: `Admin@V7!2026`

> ⚠️ **مهم**: پس از اولین ورود، رمز عبور را تغییر دهید!

### ایجاد محصول جدید

#### از طریق API:

```bash
# ۱. دریافت توکن
TOKEN=$(curl -s -X POST https://api.yio.ir/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"phone":"09120000000","password":"Admin@V7!2026"}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['data']['accessToken'])")

# ۲. ایجاد محصول
curl -X POST https://api.yio.ir/api/v1/products \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "مایل چوبی ۵۰ تایی",
    "brand": "YIO",
    "category": "wooden-building-blocks",
    "price": 250000,
    "image": "/uploads/products/sample.webp",
    "stockQuantity": 100,
    "isPublished": true,
    "woodType": "فینلاندی"
  }'
```

#### از طریق پنل CRM:

1. به https://crm.yio.ir بروید
2. وارد شوید
3. از منو: محصولات → افزودن محصول
4. اطلاعات را پر کنید
5. روی «انتشار» کلیک کنید

### ثبت سفارش آزمایشی

```bash
# ایجاد سفارش
curl -X POST https://api.yio.ir/api/v1/orders \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "items": [
      {"productId": 1, "quantity": 2}
    ],
    "shippingAddress": "تهران، خیابان ولیعصر، پلاک ۱",
    "shippingCity": "تهران",
    "recipientName": "محمد محمدی",
    "recipientPhone": "09120000001",
    "paymentMethod": "cod"
  }'
```

### مشاهده داشبورد

```bash
# داشبورد آنالیز
curl https://api.yio.ir/api/v1/analytics/dashboard \
  -H "Authorization: Bearer $TOKEN"
```

### استفاده از هوش مصنوعی

#### پیش‌بینی فروش:

```bash
# پیش‌بینی ۳۰ روز آینده
curl "https://api.yio.ir/api/v1/ai/sales-forecast?periods=30" \
  -H "Authorization: Bearer $TOKEN"
```

#### چت با پشتیبان هوشمند:

```bash
# شروع گفتگو
SESSION=$(curl -s -X POST https://api.yio.ir/api/v1/ai/chat/start \
  -H "Authorization: Bearer $TOKEN" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['data']['id'])")

# ارسال پیام
curl -X POST https://api.yio.ir/api/v1/ai/chat/send \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d "{\"sessionId\":\"$SESSION\",\"message\":\"وضعیت سفارشم چیه؟\"}"
```

#### تحلیل مشتریان:

```bash
# تحلیل کامل
curl https://api.yio.ir/api/v1/ai/customer-insights \
  -H "Authorization: Bearer $TOKEN"

# پیشنهاد محصول برای کاربر فعلی
curl https://api.yio.ir/api/v1/ai/recommendations \
  -H "Authorization: Bearer $TOKEN"
```

### مدیریت کاربران

```bash
# لیست کاربران
curl https://api.yio.ir/api/v1/users \
  -H "Authorization: Bearer $TOKEN"

# ایجاد کاربر جدید
curl -X POST https://api.yio.ir/api/v1/users \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "phone": "09120000001",
    "name": "کاربر جدید",
    "email": "user@example.com",
    "level": 0
  }'
```

### گزارش‌گیری

```bash
# گزارش فروش
curl "https://api.yio.ir/api/v1/analytics/sales-report?from=2026-07-01&to=2026-07-31" \
  -H "Authorization: Bearer $TOKEN"

# گزارش تولید
curl "https://api.yio.ir/api/v1/analytics/production-report?from=2026-07-01&to=2026-07-31" \
  -H "Authorization: Bearer $TOKEN"

# ترازنامه مالی
curl "https://api.yio.ir/api/v1/accounting/trial-balance?from=2026-07-01&to=2026-07-31" \
  -H "Authorization: Bearer $TOKEN"
```

---

## 📞 پشتیبانی

در صورت بروز مشکل:

1. لاگ‌ها را بررسی کنید: `pm2 logs`
2. مستندات API: `https://api.yio.ir/api/docs`
3. Health Check: `https://api.yio.ir/health`

### چک‌لیست نهایی

- [ ] PostgreSQL نصب و پیکربندی شده
- [ ] Node.js و npm نصب شده
- [ ] PM2 نصب و پیکربندی شده
- [ ] Nginx نصب و پیکربندی شده
- [ ] پروژه استقرار یافته
- [ ] فایل `.env` پیکربندی شده
- [ ] Schema دیتابیس اعمال شده
- [ ] Seed اجرا شده
- [ ] Build انجام شده
- [ ] PM2 سرویس‌ها در حال اجرا
- [ ] Nginx reverse proxy پیکربندی شده
- [ ] SSL نصب شده
- [ ] Firewall فعال شده
- [ ] بک‌آپ خودکار تنظیم شده
- [ ] رمز مدیر تغییر کرده

---

**نسخه سند**: 7.0.0  
**تاریخ**: 2026-07-27  
**سیستم‌عامل**: Debian 12 (Bookworm)
