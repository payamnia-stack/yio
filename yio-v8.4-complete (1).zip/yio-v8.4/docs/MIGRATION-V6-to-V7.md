# راهنمای مهاجرت از V6 به V7 (فاز ۲)

> این سند مهاجرت کامل از YIO V-6 (V-5-5 + CRM V-6-2) به YIO V-7 را پوشش می‌دهد.

## 📊 خلاصه تغییرات Schema

### آمار کلی
| شاخص | V-6 | V-7 | تغییر |
|------|-----|-----|-------|
| تعداد موجودیت‌ها (Models) | 38 | **78** | +40 |
| تعداد موتورهای تجاری | 0 | **10** | +10 |
| پشتیبانی Multi-Tenant | ❌ | ✅ | جدید |
| Soft Delete سیستماتیک | ❌ | ✅ | جدید |
| Audit Log خودکار | ❌ | ✅ | جدید |
| RBAC کامل | ❌ | ✅ (9 role, 35+ permission) | جدید |
| Event Bus | ❌ | ✅ | جدید |
| Rule Engine (داینامیک) | ❌ | ✅ | جدید |
| Workflow Engine | ❌ | ✅ | جدید |

### موجودیت‌های جدید در V-7 (اضافه شده در فاز ۲)
1. **System**: Tenant, AuditLog, Rule, WorkflowDefinition, WorkflowStepDefinition, WorkflowInstance
2. **Product**: ProductDesign (نسخه‌بندی), BOM, BOMItem, Routing, RoutingStep, WorkStation, CostFormula, PriceHistory, DiscountRule
3. **Production**: WorkOrder, WorkOrderStep, ProductionBatch, ProductTraceability, QualityCheck, WasteRecord, Prototype, CustomOrder
4. **Inventory**: Warehouse, WoodStock, DryingSession, PaintStock, InventoryTransaction
5. **Machine**: Machine, MachineMaintenance, Tool
6. **Purchasing**: Supplier, PurchaseOrder, PurchaseOrderItem
7. **HR**: Employee
8. **Finance**: AccountingEntry, AnalyticsSnapshot
9. **Shipping**: Shipment
10. **V6 Compat**: CouponUsage, WholesaleOrder, RateLimitEntry, Block, Newsletter, PBPage, PBTemplate, RecentlyViewed, CustomerPhoto, ReturnRequest, PriceDropAlert

---

## 📋 مراحل مهاجرت

### مرحله ۱: پشتیبان‌گیری (الزامی)

```bash
# پشتیبان دیتابیس V-6
pg_dump -U postgres -Fc yio > /backup/yio-v6-backup-$(date +%Y%m%d).sql

# پشتیبان کد V-6
cp -r /var/www/yio /backup/yio-v6-backup-$(date +%Y%m%d)

# بررسی سلامت پشتیبان
pg_restore -l /backup/yio-v6-backup-$(date +%Y%m%d).sql | head
```

### مرحله ۲: نصب V-7

```bash
cd /var/www
# کپی پوشه yio-v7 از فایل دریافت شده
cp -r /path/to/yio-v7 /var/www/yio-v7
cd /var/www/yio-v7

# نصب وابستگی‌ها
npm install

# نصب ابزارهای اضافی (در صورت نیاز)
npm install -g tsx pm2
```

### مرحله ۳: تنظیم فایل `.env`

در `packages/repositories/.env`:
```env
# توجه: بدون کوتیشن!
DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/yio_v7
```

در ریشه پروژه `/var/www/yio-v7/.env`:
```env
# Multi-Tenant
DEFAULT_TENANT_ID=1

# SMS (Melipayamak)
MELIPAYAMAK_USERNAME=your_username
MELIPAYAMAK_PASSWORD=your_password
MELIPAYAMAK_SENDER_NUMBER=5000270019

# Email
SMTP_HOST=smtp.yio.ir
SMTP_PORT=587
SMTP_USER=info@yio.ir
SMTP_PASSWORD=your_email_password

# App
NEXT_PUBLIC_SITE_URL=https://yio.ir
NEXT_PUBLIC_API_URL=https://api.yio.ir
JWT_SECRET=your-super-secret-jwt-key-change-me
SESSION_SECRET=your-session-secret-change-me
```

### مرحله ۴: ساخت دیتابیس V-7

```bash
# ورود به PostgreSQL
sudo -u postgres psql

# در psql:
CREATE DATABASE yio_v7 ENCODING 'UTF8' LC_COLLATE 'fa_IR.UTF-8' LC_CTYPE 'fa_IR.UTF-8' TEMPLATE template0;
CREATE USER yio_user WITH PASSWORD 'your_strong_password';
GRANT ALL PRIVILEGES ON DATABASE yio_v7 TO yio_user;
\q
```

### مرحله ۵: اعمال Schema V-7

```bash
cd /var/www/yio-v7/packages/repositories

# تولید Prisma Client
npm run db:generate

# اعمال Schema به دیتابیس (جداول را ایجاد می‌کند)
npm run db:push

# بررسی صحت Schema
npm run db:validate
```

### مرحله ۶: اجرای مهاجرت داده‌ها

#### گزینه الف: مهاجرت خودکار (پیشنهادی)

```bash
cd /var/www/yio-v7/packages/repositories

# ابتدا در حالت dry-run تست کنید
npm run db:migrate:dry-run

# اگر همه چیز OK بود، مهاجرت واقعی را اجرا کنید
npm run db:migrate
```

#### گزینه ب: مهاجرت دستی

```bash
# 1) ابتدا دیتابیس V-6 را به V-7 کپی کنید
pg_dump -U postgres yio | psql -U postgres yio_v7

# 2) سپس اسکریپت SQL مهاجرت را اجرا کنید
psql -U postgres -d yio_v7 -f packages/repositories/prisma/migrations/v6-to-v7-migration.sql
```

### مرحله ۷: اجرای Seed (داده‌های پیش‌فرض)

```bash
cd /var/www/yio-v7/packages/repositories
npm run db:seed
```

این دستور موارد زیر را ایجاد می‌کند:
- ✅ Tenant پیش‌فرض (id=1, yio.ir)
- ✅ کاربر مدیر (phone: `09120000000`, password: `Admin@V7!2026`)
- ✅ 10 تنظیمات پایه سایت
- ✅ 3 روش پرداخت
- ✅ 5 انبار
- ✅ 5 دستگاه
- ✅ 4 تأمین‌کننده
- ✅ 5 دسته‌بندی
- ✅ 4 نوع چوب
- ✅ 5 قانون تجاری
- ✅ 1 گردش کار با 10 مرحله
- ✅ 4 سؤال متداول

### مرحله ۸: Build و راه‌اندازی

```bash
cd /var/www/yio-v7

# Build تمام پکیج‌ها
npm run build

# تنظیم PM2
cat > ecosystem.config.cjs <<EOF
module.exports = {
  apps: [{
    name: 'yio-v7',
    script: 'apps/web/server.js',
    cwd: '/var/www/yio-v7',
    instances: 1,
    autorestart: true,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      PORT: 3000,
    }
  }]
};
EOF

pm2 start ecosystem.config.cjs
pm2 save
```

### مرحله ۹: تنظیم Nginx (در صورت نیاز)

```nginx
server {
    listen 80;
    server_name yio.ir www.yio.ir;

    # صفحه اصلی (فروشگاه)
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_cache_bypass \$http_upgrade;
    }

    # فایل‌های آپلود شده
    location /internal-uploads/ {
        internal;
        alias /var/www/yio-v7/storage/uploads/;
    }

    location /api/uploads/ {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header X-Accel-Redirect /internal-uploads/;
    }
}
```

### مرحله ۱۰: تست و تأیید

```bash
# تست اتصال دیتابیس
cd /var/www/yio-v7/packages/repositories
npx prisma studio --schema=prisma/schema.prisma

# تست لاگین مدیر
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"phone":"09120000000","password":"Admin@V7!2026"}'

# بررسی Tenant
psql -U postgres -d yio_v7 -c "SELECT id, name, domain, \"isActive\" FROM \"Tenant\";"

# بررسی شمارش جداول اصلی
psql -U postgres -d yio_v7 -c "
SELECT 'users' as tbl, COUNT(*) FROM \"User\"
UNION ALL
SELECT 'products', COUNT(*) FROM \"Product\"
UNION ALL
SELECT 'orders', COUNT(*) FROM \"Order\"
UNION ALL
SELECT 'work_orders', COUNT(*) FROM \"WorkOrder\"
UNION ALL
SELECT 'rules', COUNT(*) FROM \"Rule\"
UNION ALL
SELECT 'workflows', COUNT(*) FROM \"WorkflowDefinition\";
"
```

---

## 🔄 جدول مهاجرت داده‌ها (Mapping)

| جدول V-6 | جدول V-7 | نحوه مهاجرت |
|----------|----------|-------------|
| `User` | `User` + `tenantId=1` | مستقیم |
| `Product` | `Product` + `tenantId=1` | مستقیم |
| `Order` | `Order` + `tenantId=1` | مستقیم |
| `OrderItem` | `OrderItem` | مستقیم |
| `ProductImage` | `ProductImage` | مستقیم |
| `ProductVideo` | `ProductVideo` | مستقیم |
| `ProductColor` | `ProductColor` | مستقیم |
| `ProductVariant` | `ProductVariant` | مستقیم |
| `Customer` | `Customer` + `tenantId=1` | از `User` مشتق می‌شود |
| `AdminSession` | `AdminSession` + `tenantId=1` | مستقیم |
| `Session` | `Session` + `tenantId=1` | مستقیم |
| `PaymentMethod` | `PaymentMethod` | مستقیم |
| `RateLimitEntry` | `RateLimitEntry` | مستقیم |
| `Coupon` | `Coupon` | مستقیم |
| `CouponUsage` | `CouponUsage` | مستقیم |
| `WholesaleOrder` | `WholesaleOrder` + `tenantId=1` | مستقیم |
| `ContactMessage` | `ContactMessage` | مستقیم |
| `FAQ` | `FAQ` | مستقیم |
| `NotificationRequest` | `NotificationRequest` | مستقیم |
| `Address` | `Address` | مستقیم |
| `Wishlist` | `Wishlist` | مستقیم |
| `Review` | `Review` | مستقیم |
| `SiteSetting` | `SiteSetting` + `tenantId=1` | مستقیم |
| `Category` | `Category` | مستقیم |
| `Page` | `Page` | مستقیم |
| `Block` | `Block` | مستقیم |
| `BlogPost` | `BlogPost` | مستقیم |
| `Newsletter` | `Newsletter` | مستقیم |
| `LoyaltyPoint` | `LoyaltyPoint` | مستقیم |
| `PBPage` | `PBPage` | مستقیم |
| `PBTemplate` | `PBTemplate` | مستقیم |
| `IncomingEmail` | `IncomingEmail` | مستقیم |
| `Wallet` | `Wallet` | مستقیم |
| `WalletTransaction` | `WalletTransaction` | مستقیم |
| `UserNotification` | `UserNotification` + `tenantId=1` | مستقیم |
| `RecentlyViewed` | `RecentlyViewed` | مستقیم |
| `CustomerPhoto` | `CustomerPhoto` | مستقیم |
| `ReturnRequest` | `ReturnRequest` + `tenantId=1` | مستقیم |
| `PriceDropAlert` | `PriceDropAlert` | مستقیم |

---

## 🆕 جداول جدید در V-7 (بدون معادل در V-6)

این جداول در دیتابیس جدید ساخته می‌شوند و داده‌های پیش‌فرض از طریق seed پر می‌شوند:

| جدول | توضیح |
|------|-------|
| `Tenant` | Multi-Tenant: هر Tenant یک دامنه/سازمان است |
| `AuditLog` | لاگ خودکار تغییرات (کِی، کِی، چه چیزی تغییر کرد) |
| `Rule` | قوانین پویای تجاری (در دیتابیس) |
| `WorkflowDefinition` | تعریف گردش کار برای موجودیت‌ها |
| `WorkflowStepDefinition` | مراحل هر گردش کار |
| `WorkflowInstance` | اجرای یک گردش کار روی یک موجودیت |
| `Employee` | نیروی انسانی (ارتباط با User) |
| `Warehouse` | انبارها (چوب، رنگ، WIP، محصول تمام‌شده) |
| `WoodStock` | موجودی چوب با مشخصات کامل |
| `DryingSession` | جلسات خشک‌کردن چوب |
| `PaintStock` | موجودی رنگ |
| `InventoryTransaction` | تراکنش‌های انبار (in/out/transfer) |
| `Machine` | ماشین‌آلات (CNC، اره، لیزر، پرس، سمباده) |
| `MachineMaintenance` | نگهداری و تعمیرات ماشین‌آلات |
| `Tool` | ابزار مصرفی (تیغچه، مته، فرز) |
| `Supplier` | تأمین‌کنندگان با رتبه‌بندی |
| `PurchaseOrder` | سفارش خرید |
| `PurchaseOrderItem` | اقلام سفارش خرید |
| `WorkOrder` | دستور کار تولید |
| `WorkOrderStep` | مراحل اجرای دستور کار |
| `ProductionBatch` | بچ تولید |
| `ProductTraceability` | ردیابی کامل (Wood → Machine → Operator → Customer) |
| `QualityCheck` | کنترل کیفیت (pass/fail/rework) |
| `WasteRecord` | ثبت ضایعات |
| `ProductDesign` | نسخه‌بندی طراحی محصول (CAD/CNC/Laser) |
| `BOM` | Bill of Materials (مواد اولیه محصول) |
| `BOMItem` | اقلام BOM |
| `Routing` | مسیر تولید محصول |
| `RoutingStep` | مراحل مسیر تولید |
| `WorkStation` | ایستگاه‌های کاری |
| `CostFormula` | فرمول قیمت تمام شده (10 مولفه) |
| `PriceHistory` | تاریخچه تغییرات قیمت |
| `DiscountRule` | قوانین تخفیف پویا |
| `Shipment` | محموله‌های ارسالی |
| `CustomOrder` | سفارش‌های سفارشی |
| `Prototype` | نمونه‌های اولیه محصول |
| `Document` | اسناد محصول/دستور کار |
| `AccountingEntry` | سند حسابداری (debit/credit) |
| `AnalyticsSnapshot` | مقادیر آنالیز در زمان خاص |

---

## ⚠️ نکات مهم

### 1) همیشه قبل از مهاجرت پشتیبان بگیرید!
```bash
pg_dump -U postgres -Fc yio > /backup/yio-v6-backup-$(date +%Y%m%d).sql
```

### 2) `tenantId` به همه جداول اصلی اضافه شده
- جداول Multi-Tenant: User, Product, Order, WorkOrder, Warehouse, Supplier, Employee, Machine, PurchaseOrder, AuditLog, SiteSetting, UserNotification, Rule, WorkflowDefinition, WorkflowInstance, WoodStock, PaintStock, InventoryTransaction, WholesaleOrder, ReturnRequest, DiscountRule, AccountingEntry, AnalyticsSnapshot
- جداول Global (بدون tenantId): Category, FAQ, Page, Block, BlogPost, PaymentMethod, Coupon, Newsletter, ContactMessage, IncomingEmail, NotificationRequest, ProductImage, ProductVideo, ProductColor, ProductVariant, OrderItem, Address, Wishlist, Review, Wallet, WalletTransaction, LoyaltyPoint, RecentlyViewed, CustomerPhoto, PriceDropAlert, RateLimitEntry, PBPage, PBTemplate, ProductDesign, BOM, BOMItem, Routing, RoutingStep, WorkStation, WorkOrderStep, ProductionBatch, ProductTraceability, QualityCheck, WasteRecord, DryingSession, MachineMaintenance, Tool, Shipment, CustomOrder, Prototype, PurchaseOrderItem, Document, CostFormula, PriceHistory, WorkflowStepDefinition, CouponUsage

### 3) Soft Delete با `deletedAt`
- فقط جدول `User` و `Product` دارای `deletedAt` هستند (در V-7 برای جلوگیری از حذف فیزیکی)
- در Repository Layer فیلتر خودکار `deletedAt IS NULL` اعمال می‌شود

### 4) تغییر رمز مدیر پیش‌فرض
پس از مهاجرت، حتماً رمز مدیر را تغییر دهید:
```bash
# لاگین با phone: 09120000000 و password: Admin@V7!2026
# سپس از پنل مدیریت → تنظیمات → تغییر رمز
```

### 5) نصب tsx برای اجرای اسکریپت‌های TypeScript
```bash
npm install -g tsx
# یا محلی:
cd /var/www/yio-v7 && npm install tsx --save-dev
```

---

## 🧪 تست پس از مهاجرت

### 1) تست اتصال
```bash
curl http://localhost:3000/api/health
# انتظار: {"status":"ok","version":"7.0.0"}
```

### 2) تست لاگین مدیر
```bash
TOKEN=$(curl -s -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"phone":"09120000000","password":"Admin@V7!2026"}' | jq -r '.token')

echo "Token: $TOKEN"
```

### 3) تست Tenant
```bash
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:3000/api/admin/tenants
```

### 4) تست RBAC
```bash
# تلاش برای دسترسی بدون permission
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:3000/api/admin/audit-logs
# انتظار: 200 با لیست لاگ‌ها (چون مدیر level=3 دسترسی کامل دارد)
```

### 5) بررسی داده‌ها
```sql
-- بررسی تطابق داده‌های V-6 با V-7
SELECT
  (SELECT COUNT(*) FROM "User") AS users_v7,
  (SELECT COUNT(*) FROM "Product") AS products_v7,
  (SELECT COUNT(*) FROM "Order") AS orders_v7,
  (SELECT COUNT(*) FROM "AuditLog" WHERE action = 'V6_TO_V7_MIGRATION') AS migration_log;
```

---

## 🔄 Rollback (در صورت بروز مشکل)

```bash
# 1) خاموش کردن V-7
pm2 stop yio-v7

# 2) بازگرداندن کد V-6
cd /var/www
mv yio-v7 yio-v7-failed
mv /backup/yio-v6-backup-YYYYMMDD yio

# 3) بازگرداندن دیتابیس V-6
psql -U postgres -c "DROP DATABASE IF EXISTS yio_v7;"
psql -U postgres -c "DROP DATABASE IF EXISTS yio;"
psql -U postgres -c "CREATE DATABASE yio;"
pg_restore -U postgres -d yio /backup/yio-v6-backup-YYYYMMDD.sql

# 4) راه‌اندازی مجدد V-6
cd /var/www/yio
pm2 start ecosystem.config.cjs
```

---

## 📞 پشتیبانی

در صورت بروز مشکل:
1. لاگ‌ها را بررسی کنید: `pm2 logs yio-v7`
2. لاگ مهاجرت را بررسی کنید: `psql -c "SELECT * FROM \"AuditLog\" WHERE action = 'V6_TO_V7_MIGRATION';"`
3. اسکریپت migrate را در حالت dry-run اجرا کنید: `npm run db:migrate:dry-run`
4. اطمینان حاصل کنید نسخه‌های وابستگی‌ها مطابق `package.json` هستند

---

**نسخه سند**: 7.0.0-phase2  
**تاریخ آخرین به‌روزرسانی**: 2026-07-27  
**وضعیت**: فاز ۲ تکمیل شد
