# YIO V8 — Migration Guide (V7 → V8)

این سند توضیح می‌دهد که چه تغییراتی در V8 انجام شده و چگونه از V7 به V8 مهاجرت کنید.

---

## خلاصه تغییرات

V8 یک **جهش معماری** است که ۱۰ بهبود اصلی نسبت به V7 دارد:

| # | بهبود | وضعیت در V7 | وضعیت در V8 |
|---|-------|-------------|-------------|
| 1 | Repository Interface | وابستگی مستقیم به Concrete Class | اینترفیس `IOrderRepository`, `IProductRepository` و ... |
| 2 | Unit of Work + Transaction Manager | ❌ وجود نداشت | ✅ `PrismaUnitOfWork`, `PrismaTransactionManager` |
| 3 | Event Store | فقط EventBus | ✅ `PrismaEventStore` + جدول `EventStoreRecord` |
| 4 | CQRS (Commands / Queries) | همه چیز داخل Engine | ✅ `CommandBus`, `QueryBus` + Handlers |
| 5 | Typed Domain Events | نام Event به‌صورت String | ✅ `Events` const + `EventName` type |
| 6 | Unit Tests | ❌ نبود | ✅ Vitest setup + ۷ فایل تست |
| 7 | Central Audit Log | AuditLog ساده | ✅ `AuditLogger` غنی‌شده با userRole/operation/metadata/userAgent/requestId |
| 8 | DI Container | Constructor Injection دستی | ✅ `Container` سبک با Singleton/Transient/Scoped |
| 9 | Rule Engine توسعه‌پذیر | فقط Rule داینامیک از DB | ✅ `RuleRegistry` + کلاس‌های Rule مستقل |
| 10 | Cache Layer (Redis) | ❌ وجود نداشت | ✅ `InMemoryCache`, `RedisCache`, `@cached` decorator |
| ۱۰b | ABAC Permission | فقط RBAC | ✅ `PermissionChecker.checkAccess` با Attributeها |

---

## ۱) Migration Database

ابتدا migration SQL را اجرا کنید:

```bash
# اجرای migration
psql $DATABASE_URL -f packages/repositories/prisma/migrations/v7-to-v8-migration.sql

# یا از طریق prisma migrate
cd packages/repositories
npx prisma db push --schema=prisma/schema.prisma
npx prisma generate --schema=prisma/schema.prisma
```

### تغییرات Schema

- **AuditLog**: فیلدهای جدید `userRole`, `operation`, `metadata`, `userAgent`, `requestId` اضافه شد
- **EventStoreRecord** (جدید): ذخیره تمام Domain Eventها برای Audit و Replay
- **AbacPolicy** (جدید): سیاست‌های ABAC داینامیک (قابل ویرایش از پنل ادمین)

---

## ۲) Bootstrap Container در API Server

در `apps/api/src/server.ts`، قبل از `app.listen`، Container را bootstrap کنید:

```typescript
import { bootstrapContainer } from './bootstrap';
import { TOKENS } from '@yio/core';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const container = await bootstrapContainer(prisma, {
  useRedis: process.env.REDIS_URL !== undefined,
});

// ذخیره در app برای استفاده در routes
app.locals.container = container;
```

---

## ۳) Migration موتورها (Engine Migration)

### الگوی قدیمی V7:

```typescript
// V7 — وابستگی مستقیم به کلاس Concrete
export class OrderEngine {
  constructor(
    private orderRepo: OrderRepository,    // ← مستقیم
    private eventBus: IEventBus,
  ) {
    this.eventBus.subscribe('product.published', this.onProductPublished.bind(this));  // ← رشته خام
  }

  async createOrder(input, ctx) {
    const product = await this.orderRepo['prisma'].product.findUnique(...);  // ← دسترسی مستقیم به prisma
    // ...
    await this.eventBus.publish(new OrderCreatedEvent(...));  // ← بدون تراکنش
  }
}
```

### الگوی جدید V8:

```typescript
// V8 — وابستگی به اینترفیس + UoW + Audit
export class OrderEngine {
  constructor(
    private orderRepo: IOrderRepository,        // ← اینترفیس
    private productRepo: IProductRepository,    // ← اینترفیس
    private inventoryRepo: IInventoryRepository, // ← اینترفیس
    private eventBus: IEventBus,
    private txManager: ITransactionManager,      // ← جدید
    private ruleEngine: IRuleEngine,             // ← جدید
    private auditLogger: IAuditLogger,           // ← جدید
    private logger: ILogger = console,
  ) {
    // ← نام Event تایپ‌شده
    this.eventBus.subscribe(Events.ProductPublished, this.onProductPublished.bind(this));
  }

  async createOrder(input, ctx) {
    const product = await this.productRepo.findById(input.productId, ctx);  // ← از طریق اینترفیس
    // ...
    await this.txManager.run(async (tx) => {
      // همه عملیات در یک تراکنش
      await this.orderRepo.createWithItems(order, items, ctx, tx);
      await this.productRepo.reserveStock(items, ctx, tx);
      tx.collectEvent(new OrderCreatedEvent(...));  // ← Event پس از commit publish می‌شود
      tx.collectAudit({ ... });                       // ← Audit هم در همان تراکنش
    });
  }
}
```

---

## ۴) Migration Eventها (Typed Events)

### الگوی قدیمی V7:

```typescript
// V7 — رشته خام (بدون تایپ چک)
eventBus.subscribe('order.created', handler);
eventBus.subscribe('order.creatd', handler);  // ❌ هیچ خطایی نمی‌گیرد!
```

### الگوی جدید V8:

```typescript
// V8 — تایپ‌شده (خطای تایپی در Compile Time گرفته می‌شود)
import { Events } from '@yio/core';

eventBus.subscribe(Events.OrderCreated, handler);
eventBus.subscribe(Events.OrderCreatd, handler);  // ❌ TS Error: not assignable to EventName
```

### افزودن Event جدید:

۱. در `packages/core/src/events/domain-events.ts` کلاس Event را اضافه کنید:

```typescript
export class OrderRefundedEvent extends DomainEvent {
  get eventName() { return 'order.refunded'; }
  constructor(
    public readonly orderId: number,
    public readonly amount: number,
    public readonly tenantId: number,
  ) { super(); }
}
```

۲. در `packages/core/src/events/registry.ts` آن را ثبت کنید:

```typescript
export const Events = {
  // ...
  OrderRefunded: 'order.refunded',
} as const;

// در بخش register:
register(Events.OrderRefunded, OrderRefundedEvent);
```

---

## ۵) Migration به CQRS

### الگوی قدیمی V7:

```typescript
// V7 — مستقیم Engine را صدا می‌زدیم
const result = await orderEngine.createOrder(input, ctx);
const orders = await orderRepo.findByStatus('pending', ctx);
```

### الگوی جدید V8:

```typescript
// V8 — از طریق Command Bus و Query Bus
import { CreateOrderCommand, ListOrdersQuery } from '@yio/services';

// Write → Command
const result = await commandBus.execute(
  new CreateOrderCommand(input),
  ctx,
);

// Read → Query (با Cache خودکار)
const orders = await queryBus.executeCached(
  new ListOrdersQuery('pending', 1, 20),
  ctx,
);
```

---

## ۶) Migration Ruleها

### الگوی قدیمی V7:

Ruleها فقط از دیتابیس خوانده می‌شدند — نه قابل تست، نه تایپ‌شده.

### الگوی جدید V8:

```typescript
// V8 — Rule استاتیک به‌صورت کلاس مستقل
import { BaseRule, rulePass, ruleFail } from '@yio/services';
import { IRuleContext, IRuleResult } from '@yio/core';

export class MaxOrderQuantityRule extends BaseRule {
  readonly name = 'order.max_quantity';
  readonly appliesTo = 'order.create';
  readonly priority = 10;

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    for (const item of rc.data?.items || []) {
      if (item.quantity > 99) {
        return ruleFail(`تعداد سفارش نمی‌تواند بیشتر از ۹۹ باشد`);
      }
    }
    return rulePass();
  }
}

// ثبت در bootstrap:
ruleRegistry.register(new MaxOrderQuantityRule());
```

Ruleهای داینامیک (DB) همچنان پشتیبانی می‌شوند — Rule Engine هر دو منبع را با هم ارزیابی می‌کند.

---

## ۷) Migration به Cache Layer

### افزودن Cache به Query:

```typescript
import { cached } from '@yio/services';

class OrderRepository {
  @cached(
    (ctx: Context, id: number) => `order:${ctx.tenantId}:${id}`,
    60, // TTL: 60 seconds
  )
  async findById(id: number, ctx: Context) {
    return this.prisma.order.findFirst({ where: { id, tenantId: ctx.tenantId } });
  }
}
```

### Invalidating Cache:

```typescript
// بعد از آپدیت یک محصول، cache آن را پاک کن
await cache.invalidate(`product:${ctx.tenantId}:*`);
```

---

## ۸) Migration به ABAC

### الگوی قدیمی V7 (RBAC):

```typescript
// فقط Role بررسی می‌شد
if (!permissionChecker.hasPermission('order.view', ctx)) {
  throw new Error('Unauthorized');
}
```

### الگوی جدید V8 (ABAC):

```typescript
// RBAC + ABAC
const decision = permissionChecker.checkAccess(
  'order.view',
  ctx,
  {
    entityOwnerId: order.userId,  // attribute: ownership
    entityStatus: order.status,    // attribute: status
    ownershipLevel: 'self',
  },
);

if (!decision.allowed) {
  throw new Error(`Unauthorized: ${decision.deniedReason}`);
}

console.log(`Access granted by policy: ${decision.matchedPolicy}`);
```

---

## ۹) اجرای تست‌ها

```bash
# نصب وابستگی‌ها
npm install

# اجرای همه تست‌ها
npm test

# اجرای تست‌ها با watch mode
npm run test:watch

# اجرای تست با coverage
npx vitest run --coverage
```

### تست‌های موجود:

- `packages/core/__tests__/events-registry.test.ts` — Typed Events Registry
- `packages/services/__tests__/order-engine.test.ts` — OrderEngine کامل
- `packages/services/__tests__/permission-engine.test.ts` — RBAC + ABAC
- `packages/services/__tests__/rule-engine.test.ts` — Rule Registry + Rule Engine
- `packages/services/__tests__/cache.test.ts` — InMemoryCache
- `packages/services/__tests__/di-container.test.ts` — DI Container
- `packages/services/__tests__/event-bus.test.ts` — EventBus + EventStore
- `packages/services/__tests__/cqrs.test.ts` — Command/Query Bus
- `packages/services/__tests__/accounting-engine.test.ts` — Accounting Engine
- `packages/services/__tests__/workflow-engine.test.ts` — Workflow Engine

---

## ۱۰) Checklist مهاجرت

- [ ] اجرای migration SQL روی دیتابیس
- [ ] اجرای `prisma generate`
- [ ] آپدیت `apps/api/src/server.ts` برای bootstrap کردن Container
- [ ] آپدیت API routes برای استفاده از `commandBus.execute` / `queryBus.executeCached`
- [ ] آپدیت هر Engine که `eventBus.subscribe('string')` دارد به `Events.XxxYyy`
- [ ] آپدیت Engineها برای گرفتن اینترفیس‌ها (مثلاً `IOrderRepository`) به‌جای کلاس Concrete
- [ ] افزودن `txManager.run(async (tx) => { ... })` به عملیات چندمرحله‌ای
- [ ] افزودن `tx.collectEvent` / `tx.collectAudit` در UoW
- [ ] نوشتن Ruleهای استاتیک برای هر دامنه
- [ ] تنظیم `REDIS_URL` در production
- [ ] اجرای تست‌ها و رفع خطاها

---

## ۱۱) ساختار پوشه‌های جدید V8

```
packages/
├── core/
│   └── src/
│       ├── events/
│       │   ├── domain-events.ts    ← تعریف کلاس‌های Event
│       │   ├── registry.ts         ← NEW: رجیستری تایپ‌شده
│       │   └── index.ts
│       ├── interfaces/
│       │   └── index.ts            ← آپدیت: IUnitOfWork, IEventStore, ICache, ICommandBus, ...
│       ├── di/
│       │   ├── tokens.ts           ← NEW: DI Tokens
│       │   └── index.ts
│       ├── cqrs/
│       │   ├── base.ts             ← NEW: BaseCommand, BaseQuery
│       │   └── index.ts
│       └── ...
├── services/
│   └── src/
│       ├── event-bus/
│       │   └── event-bus.ts        ← آپدیت: Typed + EventStore integration
│       ├── event-store/            ← NEW
│       │   ├── prisma-event-store.ts
│       │   └── index.ts
│       ├── unit-of-work/           ← NEW
│       │   ├── prisma-unit-of-work.ts
│       │   └── index.ts
│       ├── audit/                  ← NEW
│       │   ├── audit-logger.ts
│       │   └── index.ts
│       ├── cache/                  ← NEW
│       │   ├── cache.ts            (InMemoryCache + RedisCache)
│       │   └── index.ts
│       ├── di/                     ← NEW
│       │   ├── container.ts
│       │   └── index.ts
│       ├── cqrs/                   ← NEW
│       │   ├── command-bus.ts
│       │   ├── query-bus.ts
│       │   ├── commands/
│       │   ├── queries/
│       │   ├── handlers/
│       │   └── index.ts
│       ├── rule-engine/            ← NEW
│       │   ├── registry.ts         (RuleRegistry + BaseRule)
│       │   └── index.ts
│       ├── rules/                  ← NEW: Concrete Rule classes
│       │   ├── order-rules.ts
│       │   ├── inventory-rules.ts
│       │   ├── accounting-rules.ts
│       │   └── index.ts
│       ├── engines/
│       │   ├── order-engine.ts     ← آپدیت: استفاده از UoW, IRepo, Rule, Audit
│       │   ├── permission-engine.ts ← آپدیت: ABAC
│       │   └── ...                 (بقیه: آپدیت برای Typed Events)
│       └── __tests__/              ← NEW: Unit Tests
│           ├── order-engine.test.ts
│           ├── permission-engine.test.ts
│           ├── rule-engine.test.ts
│           ├── cache.test.ts
│           ├── di-container.test.ts
│           ├── event-bus.test.ts
│           ├── cqrs.test.ts
│           ├── accounting-engine.test.ts
│           └── workflow-engine.test.ts
└── repositories/
    └── prisma/
        ├── schema.prisma           ← آپدیت: AuditLog enriched + EventStoreRecord + AbacPolicy
        └── migrations/
            └── v7-to-v8-migration.sql ← NEW
```

---

## ۱۲) نکات و هشدارها

### ⚠️ نکته ۱:_backward compatibility_

V8 backward compatible با V7 نیست — چند تغییر Breaking دارد:
- `IEventBus.subscribe` دیگر رشته خام قبول نمی‌کند (فقط `EventName`).
- `OrderEngine` constructor signature تغییر کرده (۸ پارامتر دارد).
- `OrderRepository.createWithItems` متد جدید است.

### ⚠️ نکته ۲: Performance

- `EventStoreRecord` در هر `publish` یک INSERT می‌زند. در production با بار بالا، **batch insert** یا **async worker** پیشنهاد می‌شود.
- `Cache.attachCache` در `QueryBus` TTL پیش‌فرض ۶۰ ثانیه دارد. برای Queryهای حساس به تازگی داده، آن را کمتر کنید.

### ⚠️ نکته ۳: Security

- `AbacPolicy.conditionExpr` در دیتابیس یک JavaScript expression است. هنگام ارزیابی، **هرگز** از `eval` استفاده نکنید — از یک expression evaluator امن مثل `expr-eval` استفاده کنید.
- در حال حاضر، Policyهای استاتیک در کد (default policies) امن هستند. Policyهای DB-based باید در فاز بعدی با expression evaluator امن پیاده‌سازی شوند.

### ⚠️ نکته ۴: Rollback

اگر نیاز به rollback به V7 بود:

```bash
psql $DATABASE_URL -c "DROP TABLE IF EXISTS \"EventStoreRecord\";"
psql $DATABASE_URL -c "DROP TABLE IF EXISTS \"AbacPolicy\";"
psql $DATABASE_URL -c "ALTER TABLE \"AuditLog\" DROP COLUMN IF EXISTS \"userRole\";"
# ...
```

سپس کد V7 را deploy کنید. (داده‌های V8 در جداول V7 compatible نیست.)

---

## ۱۳) Roadmap بعد از V8

مواردی که در V8 ناقص هستند و باید در V9 اضافه شوند:

- [ ] **Saga Pattern**: برای orchestration تراکنش‌های توزیع‌شده
- [ ] **Read Models پروجکشن‌شده**: برای CQRS کامل (Queryها از read-optimized projection بخوانند)
- [ ] **Outbox Pattern**: برای reliable event publishing در محیط‌های توزیع‌شده
- [ ] **Rate Limiting per Engine**: محدودیت نرخ فراخوانی برای هر Engine
- [ ] **OpenTelemetry**: distributed tracing کامل
- [ ] **Multi-Region**: پشتیبانی از deployment در چند منطقه
- [ ] **GraphQL Gateway**: برای آپدیفت mobile و web clients
- [ ] **Workflow Designer UI**: پنل برای طراحی workflow به‌صورت بصری
- [ ] **Real-time Subscriptions**: WebSocket برای push updates به clients
