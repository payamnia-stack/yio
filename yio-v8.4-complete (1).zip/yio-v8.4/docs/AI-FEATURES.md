# YIO V7 — AI Features (Phase 6)

> ۵ موتور هوش مصنوعی برای تحلیل، پیش‌بینی و خودکارسازی

## 📊 خلاصه موتورهای AI

| موتور | عملکرد | مسیر API |
|-------|--------|---------|
| **Sales Forecasting** | پیش‌بینی فروش با ۴ روش آماری | `/api/v1/ai/sales-forecast` |
| **Smart Chat** | چت‌بات پشتیبانی مشتری | `/api/v1/ai/chat/*` |
| **Product Description** | تولید خودکار توضیحات SEO | `/api/v1/ai/product-description/*` |
| **Customer Insights** | تحلیل RFM، LTV، Churn | `/api/v1/ai/customer-insights` |
| **Anomaly Detection** | تشخیص تقلب و ناهنجاری | `/api/v1/ai/anomalies/*` |

## 🤖 1. Sales Forecasting Engine

### روش‌های پیش‌بینی

| روش | توضیح | مناسب برای |
|-----|-------|-----------|
| `moving_average` | میانگین متحرک | داده‌های پایدار بدون trend |
| `exponential` | هموارسازی نمایی | داده‌های با نویز |
| `linear` | رگرسیون خطی | داده‌های با trend قوی |
| `seasonal` | تجزیه فصلی | داده‌های با الگوی هفتگی |
| `auto` | انتخاب خودکار | پیش‌فرض |

### API Usage

```bash
# پیش‌بینی فروش ۳۰ روز آینده
curl -X GET "http://localhost:4000/api/v1/ai/sales-forecast?periods=30&method=auto" \
  -H "Authorization: Bearer $TOKEN"

# پیش‌بینی تقاضای محصول خاص
curl -X GET "http://localhost:4000/api/v1/ai/sales-forecast/product/5?periods=14" \
  -H "Authorization: Bearer $TOKEN"

# تشخیص ناهنجاری فروش
curl -X GET "http://localhost:4000/api/v1/ai/sales-forecast/anomalies?days=30" \
  -H "Authorization: Bearer $TOKEN"
```

### نمونه پاسخ

```json
{
  "success": true,
  "data": {
    "forecast": [
      { "date": "2026-07-28", "value": 2850000, "lower": 2100000, "upper": 3600000 }
    ],
    "method": "exponential",
    "accuracy": 87.5,
    "trend": "up",
    "trendPercent": 12,
    "seasonality": { "detected": true, "period": 7, "strength": 0.65 },
    "summary": {
      "totalForecast": 85500000,
      "averageDaily": 2850000,
      "peakDay": "2026-08-03",
      "peakValue": 4200000
    }
  }
}
```

## 💬 2. Smart Chat Engine

### قابلیت‌ها

- **Intent Detection**: ۱۱ intent قابل تشخیص
- **Knowledge Base**: پاسخ به سوالات متداول
- **Order Status**:查询 وضعیت سفارش کاربر
- **Product Search**: جستجوی محصول با کلمات کلیدی
- **Handoff**: انتقال به اپراتور انسانی
- **Session Management**: مدیریت جلسات با TTL

### Intents

| Intent | الگوهای نمونه |
|--------|-------------|
| `greeting` | سلام، hi، hello |
| `order_status` | وضعیت سفارش، پیگیری |
| `product_search` | میخوام، دنبال، جستجو |
| `shipping_info` | ارسال، حمل، هزینه ارسال |
| `return_request` | مرجوعی، برگرداندن |
| `payment_help` | پرداخت، فاکتور |
| `complaint` | شکایت، ناراضی، مشکل |
| `human_agent` | اپراتور، انسان |
| `goodbye` | خداحافظ، مرسی |

### API Usage

```bash
# شروع گفتگو
curl -X POST http://localhost:4000/api/v1/ai/chat/start \
  -H "Authorization: Bearer $TOKEN"

# ارسال پیام
curl -X POST http://localhost:4000/api/v1/ai/chat/send \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"sessionId":"chat_xxx","message":"وضعیت سفارشم چیه؟"}'

# آمار چت
curl http://localhost:4000/api/v1/ai/chat/stats \
  -H "Authorization: Bearer $TOKEN"
```

## 📝 3. Product Description Generator

### قابلیت‌ها

- تولید خودکار توضیحات بر اساس دسته‌بندی
- ۴ لحن: formal، casual، playful، technical
- استخراج ویژگی‌ها از BOM و Routing
- تولید Meta Tags برای SEO
- تولید Keywords و Slug
- تولید دسته‌جمعی

### API Usage

```bash
# تولید توضیحات برای یک محصول
curl -X POST http://localhost:4000/api/v1/ai/product-description/generate \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "productId": 5,
    "tone": "casual",
    "language": "fa",
    "seoOptimized": true
  }'

# به‌روزرسانی خودکار محصول
curl -X POST http://localhost:4000/api/v1/ai/product-description/update/5 \
  -H "Authorization: Bearer $TOKEN"

# تولید دسته‌جمعی
curl -X POST http://localhost:4000/api/v1/ai/product-description/generate-bulk \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"category":"wooden-toys"}'
```

## 👥 4. Customer Insights Analyzer

### قابلیت‌ها

- **RFM Analysis**: Recency، Frequency، Monetary
- **Customer Segmentation**: ۷ بخش خودکار
- **LTV Calculation**: Customer Lifetime Value
- **Churn Prediction**: پیش‌بینی ریزش
- **Recommendation Engine**: پیشنهاد محصول

### Customer Segments

| Segment | توضیح | رنگ |
|---------|-------|-----|
| **VIP** | مشتریان ارزشمند | بنفش |
| **وفادار** | خرید منظم | سبز |
| **فعال** | فعال اخیر | آبی |
| **جدید** | تازه عضو | نارنجی |
| **در معرض ریزش** | احتمال ریزش | قرمز |
| **غیرفعال** | مدت طولانی بدون خرید | خاکستری |
| **یک‌بار خریدار** | فقط یک خرید | فیروزه‌ای |

### API Usage

```bash
# تحلیل کامل مشتریان
curl http://localhost:4000/api/v1/ai/customer-insights \
  -H "Authorization: Bearer $TOKEN"

# پروفایل یک مشتری
curl http://localhost:4000/api/v1/ai/customer-insights/15 \
  -H "Authorization: Bearer $TOKEN"

# پیشنهاد محصول برای کاربر فعلی
curl http://localhost:4000/api/v1/ai/recommendations?limit=5 \
  -H "Authorization: Bearer $TOKEN"
```

## 🚨 5. Anomaly Detection Engine

### قابلیت‌ها

- **Order Anomaly**: مبلغ غیرعادی، تعداد اقلام زیاد، کاربر جدید با سفارش بزرگ
- **User Anomaly**: ورود از IP/موقعیت‌های متعدد
- **Inventory Anomaly**: موجودی منفی، تراکنش‌های غیرعادی
- **Statistical Detection**: Z-score، IQR
- **Auto-logging**: ثبت در AuditLog
- **Event Publishing**: انتشار رویداد برای واکنش

### Severity Levels

| Level | توضیح | اقدام |
|-------|-------|-------|
| `low` | ناهنجاری خفیف | ثبت |
| `medium` | نیاز به بررسی | اعلان |
| `high` | بحرانی | اقدام فوری |

### API Usage

```bash
# دریافت ناهنجاری‌های اخیر
curl http://localhost:4000/api/v1/ai/anomalies?limit=20&severity=high \
  -H "Authorization: Bearer $TOKEN"

# اسکن کامل (cron job)
curl -X POST http://localhost:4000/api/v1/ai/anomalies/scan \
  -H "Authorization: Bearer $TOKEN"

# بررسی سفارش خاص
curl -X POST http://localhost:4000/api/v1/ai/anomalies/check-order/123 \
  -H "Authorization: Bearer $TOKEN"
```

## 📱 Mobile App (React Native + Expo)

### ساختار

```
apps/mobile/
├── src/
│   ├── App.tsx                  # Main app with navigation
│   ├── screens/
│   │   ├── HomeScreen.tsx       # صفحه اصلی
│   │   ├── ProductsScreen.tsx   # لیست محصولات
│   │   ├── ProductDetailScreen.tsx
│   │   ├── CartScreen.tsx       # سبد خرید
│   │   ├── AccountScreen.tsx    # حساب کاربری
│   │   ├── LoginScreen.tsx      # ورود
│   │   ├── OrdersScreen.tsx     # سفارش‌های من
│   │   └── ChatScreen.tsx       # چت پشتیبانی AI
│   ├── services/
│   │   └── api.ts               # API client با auto-refresh
│   └── hooks/
├── app.json                     # Expo config
├── package.json
└── tsconfig.json
```

### Features

- ✅ **Bottom Tab Navigation**: خانه، محصولات، سبد، حساب
- ✅ **Native Stack Navigation**: برای صفحات جزئیات
- ✅ **SecureStore**: ذخیره امن توکن
- ✅ **Auto Token Refresh**: تمدید خودکار توکن
- ✅ **AI Chat**: چت با پشتیبانی هوشمند
- ✅ **Product Recommendations**: پیشنهاد محصول شخصی‌سازی شده
- ✅ **Push Notifications** (آماده پشتیبانی)
- ✅ **Camera Integration** (آماده بارکدخوانی)
- ✅ **Offline Support** (آماده پیاده‌سازی)
- ✅ **Haptics**: بازخورد لمسی

### Build & Deploy

```bash
# Development
cd apps/mobile
npm install
npx expo start

# Build for Android
eas build -p android

# Build for iOS
eas build -p ios

# Submit to stores
eas submit -p android
eas submit -p ios
```

## 🔗 Integration Points

### Event Bus Integration

تمام موتورهای AI با Event Bus یکپارچه هستند:

```
order.created → AnomalyDetection.checkOrder()
user.registered → CustomerInsights.updateSegment()
inventory.stock_updated → AnomalyDetection.checkInventory()
sales.forecast_generated → NotificationEngine.notifyAdmin()
churn.risk_detected → NotificationEngine.alertSalesTeam()
```

### Webhook Integration

رویدادهای AI از طریق Webhookها قابل اشتراک هستند:

```bash
# ثبت webhook برای رویدادهای AI
curl -X POST http://localhost:4000/api/v1/webhooks/register \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "url": "https://your-app.com/webhook",
    "events": [
      "ai.sales_anomaly_detected",
      "ai.churn_risk_detected",
      "ai.anomaly_detected",
      "ai.chat_handoff"
    ]
  }'
```

## 📊 Performance

| Engine | میانگین زمان پاسخ | Memory |
|--------|------------------|--------|
| Sales Forecasting | 200ms | ~5MB |
| Smart Chat | 50ms | ~10MB |
| Product Description | 100ms | ~2MB |
| Customer Insights | 500ms (1000 users) | ~20MB |
| Anomaly Detection | 100ms | ~5MB |

## 🚀 Roadmap (Phase 7+)

- **LLM Integration**: اتصال به GPT/Claude برای چت پیشرفته‌تر
- **Image Recognition**: تشخیص محصول از عکس
- **Voice Search**: جستجوی صوتی
- **Auto-translation**: ترجمه خودکار توضیحات
- **Predictive Maintenance**: پیش‌بینی نگهداری ماشین‌آلات
- **Smart Pricing**: قیمت‌گذاری پویا با AI

---

**نسخه**: 7.0.0-phase6  
**تعداد موتورهای AI**: 5  
**تعداد مسیرهای AI API**: 15  
**وضعیت**: فاز ۶ تکمیل شد ✅
