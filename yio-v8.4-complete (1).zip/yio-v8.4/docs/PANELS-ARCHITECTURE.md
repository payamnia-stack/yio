# YIO V7 — پنل‌های مستقل (Phase 5)

> ۵ پنل مستقل Next.js با تمایز بصری و عملکردی

## 📊 خلاصه پنل‌ها

| پنل | مسیر | رنگ تم | پورت | هدف |
|-----|------|--------|------|-----|
| **Shop** | `apps/shop` | نارنجی چوب | 3000 | فروشگاه عمومی |
| **CRM** | `apps/crm` | آبی اعتماد | 3001 | مدیریت فروش و مشتریان |
| **ERP** | `apps/erp` | سبز تولید | 3002 | مدیریت تولید و انبار |
| **Finance** | `apps/finance` | بنفش مالی | 3003 | مدیریت مالی و حسابداری |
| **Admin** | `apps/admin` | خاکستری تیره | 3004 | مدیریت سیستم |

## 🎨 Design System مشترک

### پکیج `@yio/ui`

تمام پنل‌ها از یک کتابخانه کامپوننت مشترک استفاده می‌کنند:

```
packages/ui/
├── src/
│   ├── theme/
│   │   └── index.ts          # پالت رنگ، تایپوگرافی، spacing
│   ├── components/
│   │   ├── index.tsx         # Button, Card, Input, Modal, Table, etc.
│   │   └── panel-layout.tsx  # چیدمان مشترک پنل‌ها (Sidebar + Header)
│   ├── hooks/
│   │   └── index.ts          # useAuth, useToast, useDebounce, etc.
│   ├── utils/
│   │   └── index.ts          # فرمت‌بندی فارسی، اعتبارسنجی، helpers
│   └── index.ts              # Entry point
```

### Theme System

هر پنل یک `PanelTheme` دارد که شامل:

```typescript
interface ThemeConfig {
  primary: string;        // رنگ اصلی
  primaryLight: string;   // روشن
  primaryDark: string;    // تیره
  bg: string;             // پس‌زمینه
  surface: string;        // سطح کارت‌ها
  text: string;           // متن اصلی
  textMuted: string;      // متن کم‌رنگ
  border: string;         // خطوط
  sidebarBg: string;      // پس‌زمینه sidebar
  sidebarActive: string;  // آیتم فعال
  sidebarText: string;    // متن sidebar
}
```

### کامپوننت‌های مشترک

- **Button**: ۶ variant (primary, secondary, outline, ghost, danger, success)
- **Card**: با hover effect و padding قابل تنظیم
- **Badge** / **StatusBadge**: با پشتیبانی از وضعیت‌های فارسی
- **Input**: با label، error، icon
- **Modal**: ۴ سایز
- **Table**: با columns قابل تنظیم و onRowClick
- **Pagination**: خودکار
- **KpiCard**: برای داشبوردها با trend indicator
- **Alert**: ۴ نوع (info, success, warning, danger)
- **EmptyState**: حالت خالی
- **Spinner**: ۳ سایز

### Hooks مشترک

- `useAuth()`: مدیریت احراز هویت
- `useToast()`: اعلان‌های موقت
- `useDebounce()`: debounce مقادیر
- `useAsync()`: مدیریت async operations
- `useFetch()`: wrapper برای fetch
- `useLocalStorage()`: ذخیره در localStorage
- `useMediaQuery()`: responsive
- `usePagination()`: مدیریت pagination

### Utilities مشترک

- `toPersianDigits()`, `toEnglishDigits()`: تبدیل اعداد
- `formatCurrency()`: فرمت ریال
- `formatDate()`, `formatRelative()`: فرمت تاریخ شمسی
- `validatePhone()`, `validateEmail()`, `validateNationalCode()`: اعتبارسنجی
- `buildQueryString()`: ساخت query string
- `groupBy()`, `uniqueBy()`: helpers آرایه
- `debounce()`, `throttle()`: محدودسازی فراخوانی

## 🏪 Shop Panel

### ساختار

```
apps/shop/
├── src/
│   ├── components/
│   │   └── Layout.tsx        # ShopLayout + ProductCard
│   └── pages/
│       ├── index.tsx         # صفحه اصلی
│       ├── products/         # لیست و جزئیات محصولات
│       ├── cart.tsx          # سبد خرید
│       ├── account/          # حساب کاربری
│       ├── orders/           # سفارش‌های من
│       ├── blog/             # بلاگ
│       └── contact.tsx       # تماس با ما
├── package.json
├── tsconfig.json
└── next.config.cjs
```

### صفحات اصلی

1. **خانه**: Hero + دسته‌بندی‌ها + محصولات ویژه + مزایا
2. **محصولات**: لیست با فیلتر، مرتب‌سازی، pagination
3. **جزئیات محصول**: گالری، اطلاعات، نظرات، محصولات مرتبط
4. **سبد خرید**: لیست اقلام، تخفیف، محاسبه هزینه
5. **پرداخت**: آدرس، روش پرداخت، تأیید نهایی
6. **حساب من**: پروفایل، سفارش‌ها، آدرس‌ها، علاقه‌مندی‌ها

### تم بصری

- رنگ اصلی: `#d4730a` (نارنجی چوب)
- پس‌زمینه: سفید
- فونت: Vazirmatn
- جهت: RTL
- استایل: مدرن، تمیز، دوستانه

## 💼 CRM Panel

### ساختار

```
apps/crm/
├── src/
│   ├── components/
│   └── pages/
│       ├── index.tsx                 # داشبورد فروش
│       ├── orders/                   # مدیریت سفارشات
│       ├── customers/                # مدیریت مشتریان
│       ├── products/                 # مدیریت محصولات
│       ├── marketing/                # بازاریابی
│       │   ├── campaigns.tsx
│       │   ├── coupons.tsx
│       │   └── newsletter.tsx
│       ├── reports/                  # گزارش‌ها
│       └── settings.tsx              # تنظیمات
├── package.json
└── tsconfig.json
```

### صفحات اصلی

1. **داشبورد**: KPIهای فروش، سفارش‌های اخیر، برترین مشتریان
2. **سفارشات**: لیست با فیلتر وضعیت، تأیید/ارسال/لغو
3. **مشتریان**: پروفایل کامل، تاریخچه خرید، اعتبارات
4. **محصولات**: انتشار/لغو انتشار، قیمت‌گذاری، موجودی
5. **بازاریابی**: کمپین‌ها، کدهای تخفیف، خبرنامه
6. **گزارش‌ها**: فروش، تبدیل، رفتار مشتری

### تم بصری

- رنگ اصلی: `#3b82f6` (آبی)
- Sidebar: تیره (`#1e293b`)
- استایل: حرفه‌ای، قابل اعتماد

## 🏭 ERP Panel

### ساختار

```
apps/erp/
├── src/
│   ├── components/
│   └── pages/
│       ├── index.tsx                 # داشبورد تولید
│       ├── work-orders/              # دستورات کار
│       ├── production/               # خط تولید
│       │   ├── line.tsx
│       │   ├── quality.tsx
│       │   └── waste.tsx
│       ├── inventory/                # انبار
│       │   ├── wood.tsx
│       │   ├── paint.tsx
│       │   ├── finished.tsx
│       │   └── packaging.tsx
│       ├── purchasing/               # خرید
│       │   ├── orders.tsx
│       │   └── suppliers.tsx
│       ├── machines.tsx              # ماشین‌آلات
│       ├── employees.tsx             # نیروی انسانی
│       └── reports.tsx               # گزارش‌ها
├── package.json
└── tsconfig.json
```

### صفحات اصلی

1. **داشبورد**: دستورات کار فعال، تولید امروز، هشدار کم‌موجودی
2. **دستورات کار**: ایجاد، ویرایش، شروع/تکمیل تولید
3. **خط تولید**: مراحل تولید، تخصیص اپراتور
4. **کنترل کیفیت**: ثبت نتایج، ضایعات
5. **انبار**: موجودی چوب، رنگ، محصول تمام‌شده
6. **خرید**: سفارش خرید، تأمین‌کنندگان
7. **ماشین‌آلات**: وضعیت، نگهداری
8. **نیروی انسانی**: کارمندان، شیفت‌ها

### تم بصری

- رنگ اصلی: `#10b981` (سبز)
- Sidebar: تیره سبز (`#064e3b`)
- استایل: صنعتی، کاربردی

## 💰 Finance Panel

### ساختار

```
apps/finance/
├── src/
│   ├── components/
│   └── pages/
│       ├── index.tsx                 # داشبورد مالی
│       ├── journal-entries.tsx       # اسناد حسابداری
│       ├── revenue.tsx               # درآمد
│       ├── expenses.tsx              # هزینه‌ها
│       ├── payments/                 # پرداخت‌ها
│       │   ├── receivable.tsx
│       │   └── payable.tsx
│       ├── reports/                  # گزارش‌ها
│       │   ├── trial-balance.tsx
│       │   ├── profit-loss.tsx
│       │   └── balance-sheet.tsx
│       └── settings.tsx
├── package.json
└── tsconfig.json
```

### صفحات اصلی

1. **داشبورد**: درآمد، هزینه، سود، موجودی نقدی
2. **اسناد حسابداری**: ثبت، ویرایش، گزارش
3. **فروش و درآمد**: فاورها، دریافت‌ها
4. **هزینه‌ها**: ثبت هزینه، دسته‌بندی
5. **گزارش‌ها**:
   - ترازنامه (Trial Balance)
   - سود و زیان (P&L)
   - ترازنامه مالی (Balance Sheet)
   - جریان نقدی (Cash Flow)

### تم بصری

- رنگ اصلی: `#8b5cf6` (بنفش)
- Sidebar: تیره بنفش (`#4c1d95`)
- استایل: ممتاز، جدی

## ⚙️ Admin Panel

### ساختار

```
apps/admin/
├── src/
│   ├── components/
│   └── pages/
│       ├── index.tsx                 # داشبورد مدیریت
│       ├── users/                    # کاربران
│       │   ├── list.tsx
│       │   ├── roles.tsx
│       │   └── permissions.tsx
│       ├── tenants.tsx               # Tenantها
│       ├── products.tsx              # محصولات
│       ├── pages/                    # صفحات
│       │   ├── custom.tsx
│       │   ├── blog.tsx
│       │   └── faq.tsx
│       ├── settings/                 # تنظیمات
│       │   ├── site.tsx
│       │   ├── payments.tsx
│       │   └── themes.tsx
│       ├── logs/                     # لاگ‌ها
│       │   ├── audit.tsx
│       │   ├── errors.tsx
│       │   └── webhooks.tsx
│       └── support/                  # پشتیبانی
│           ├── messages.tsx
│           └── tickets.tsx
├── package.json
└── tsconfig.json
```

### صفحات اصلی

1. **داشبورد**: آمار سیستم، وضعیت سرویس‌ها
2. **کاربران**: مدیریت کامل، نقش‌ها، دسترسی‌ها
3. **Tenantها**: Multi-tenant management
4. **محصولات**: مدیریت کامل محصولات
5. **صفحات**: صفحات سفارشی، بلاگ، FAQ
6. **تنظیمات**: تنظیمات سایت، پرداخت، قالب
7. **لاگ‌ها**: Audit log، خطاها، Webhookها
8. **پشتیبانی**: پیام‌ها، تیکت‌ها

### تم بصری

- رنگ اصلی: `#374151` (خاکستری تیره)
- Sidebar: مشکی (`#111827`)
- استایل: رسمی، مرجع

## 🔗 اتصال به API

هر پنل از طریق API Client SDK به سرور متصل می‌شود:

```typescript
// apps/crm/src/lib/api.ts
import { createApiClient } from '@yio/api/client';

export const api = createApiClient({
  baseURL: process.env.NEXT_PUBLIC_API_URL,
  accessToken: localStorage.getItem('yio_access_token'),
  refreshToken: localStorage.getItem('yio_refresh_token'),
  onTokenExpired: async () => {
    // تمدید خودکار توکن
    const refreshToken = localStorage.getItem('yio_refresh_token');
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken }),
    });
    const { data } = await res.json();
    localStorage.setItem('yio_access_token', data.accessToken);
  },
});
```

## 🚀 استقرار

### Nginx Reverse Proxy

```nginx
# Shop (yio.ir)
server {
    listen 443 ssl;
    server_name yio.ir www.yio.ir;
    location / { proxy_pass http://127.0.0.1:3000; }
}

# CRM (crm.yio.ir)
server {
    listen 443 ssl;
    server_name crm.yio.ir;
    location / { proxy_pass http://127.0.0.1:3001; }
}

# ERP (erp.yio.ir)
server {
    listen 443 ssl;
    server_name erp.yio.ir;
    location / { proxy_pass http://127.0.0.1:3002; }
}

# Finance (finance.yio.ir)
server {
    listen 443 ssl;
    server_name finance.yio.ir;
    location / { proxy_pass http://127.0.0.1:3003; }
}

# Admin (admin.yio.ir)
server {
    listen 443 ssl;
    server_name admin.yio.ir;
    location / { proxy_pass http://127.0.0.1:3004; }
}

# API (api.yio.ir)
server {
    listen 443 ssl;
    server_name api.yio.ir;
    location / { proxy_pass http://127.0.0.1:4000; }
}
```

### PM2

```bash
# Build همه پنل‌ها
cd /var/www/yio-v7
npm run build

# شروع همه سرویس‌ها
pm2 start ecosystem.config.cjs

# وضعیت
pm2 status

# لاگ‌ها
pm2 logs
```

## 📱 Responsive Design

تمام پنل‌ها responsive هستند:

- **Desktop** (≥1024px): Sidebar کامل، grid چندستونی
- **Tablet** (768-1023px): Sidebar قابل جمع، grid دوستونی
- **Mobile** (<768px): Sidebar به صورت drawer، grid تک‌ستونی

## 🎯 فاز بعدی (Phase 6)

- اپلیکیشن موبایل (React Native + Expo)
- اعلان‌های Push
- حالت Offline
- یکپارچه‌سازی با دوربین (برای بارکدخوانی)
- AI features (پیش‌بینی فروش، توصیف محصول خودکار)

---

**نسخه**: 7.0.0-phase5  
**تعداد پنل‌ها**: 5  
**تعداد کامپوننت‌های مشترک**: 15+  
**وضعیت**: فاز ۵ تکمیل شد ✅
