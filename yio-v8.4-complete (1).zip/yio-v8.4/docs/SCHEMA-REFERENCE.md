# YIO V-7 — Domain Model Reference (فاز ۲)

> مرجع کامل 78 موجودیت دامنه YIO V-7

## 📊 آمار کلی

- **تعداد موجودیت‌ها**: 78 model
- **بسته‌بندی**: 11 دامنه تجاری (domain)
- **الگوی طراحی**: DDD + Clean Architecture + Multi-Tenant
- **پشتیبانی**: Soft Delete (User, Product), Audit Log, RBAC

---

## 🏗️ دامنه‌های تجاری (Business Domains)

### ۱) دامنه سیستم (System Domain)

| Model | توضیح | Multi-Tenant | Soft Delete |
|-------|-------|:------------:|:-----------:|
| `Tenant` | سازمان/دامنه (هر Tenant یک سازمان است) | - | - |
| `User` | کاربر (مشتری/کارمند/مدیر) | ✅ | ✅ |
| `Session` | نشست کاربر | ✅ | - |
| `AdminSession` | نشست مدیر | ✅ | - |
| `AuditLog` | لاگ خودکار تغییرات | ✅ | - |
| `SiteSetting` | تنظیمات سایت (KV) | ✅ | - |
| `UserNotification` | اعلان‌های کاربر | ✅ | - |
| `Rule` | قوانین پویای تجاری | ✅ | - |
| `RateLimitEntry` | محدودیت نرخ درخواست | - | - |

### ۲) دامنه محصول (Product Domain)

| Model | توضیح | Multi-Tenant | Soft Delete |
|-------|-------|:------------:|:-----------:|
| `Product` | محصول | ✅ | ✅ |
| `ProductImage` | تصاویر محصول | - | - |
| `ProductVideo` | ویدیوهای محصول | - | - |
| `ProductColor` | رنگ‌های محصول | - | - |
| `ProductVariant` | واریانت‌های محصول (SKU) | - | - |
| `ProductDesign` | نسخه‌بندی طراحی (CAD/CNC/Laser) | - | - |
| `BOM` | Bill of Materials (مواد اولیه) | - | - |
| `BOMItem` | اقلام BOM | - | - |
| `Routing` | مسیر تولید محصول | - | - |
| `RoutingStep` | مراحل مسیر تولید | - | - |
| `WorkStation` | ایستگاه‌های کاری | - | - |
| `CostFormula` | فرمول قیمت تمام شده (10 مولفه) | - | - |
| `PriceHistory` | تاریخچه قیمت | - | - |
| `DiscountRule` | قوانین تخفیف پویا | ✅ | - |
| `Category` | دسته‌بندی | - | - |
| `Document` | اسناد محصول/دستور کار | - | - |

### ۳) دامنه تولید (Production Domain)

| Model | توضیح | Multi-Tenant | Soft Delete |
|-------|-------|:------------:|:-----------:|
| `WorkOrder` | دستور کار تولید | ✅ | - |
| `WorkOrderStep` | مراحل اجرای دستور کار | - | - |
| `ProductionBatch` | بچ تولید | - | - |
| `ProductTraceability` | ردیابی کامل محصول | - | - |
| `QualityCheck` | کنترل کیفیت | - | - |
| `WasteRecord` | ثبت ضایعات | - | - |
| `Prototype` | نمونه اولیه | - | - |
| `CustomOrder` | سفارش سفارشی | - | - |

### ۴) دامنه انبار (Inventory Domain)

| Model | توضیح | Multi-Tenant | Soft Delete |
|-------|-------|:------------:|:-----------:|
| `Warehouse` | انبار (چوب/رنگ/WIP/محصول/بسته‌بندی) | ✅ | - |
| `WoodStock` | موجودی چوب | ✅ | - |
| `DryingSession` | جلسه خشک‌کردن چوب | - | - |
| `PaintStock` | موجودی رنگ | ✅ | - |
| `InventoryTransaction` | تراکنش انبار (in/out/transfer) | ✅ | - |

### ۵) دامنه ماشین‌آلات (Machine Domain)

| Model | توضیح | Multi-Tenant | Soft Delete |
|-------|-------|:------------:|:-----------:|
| `Machine` | ماشین (CNC/اره/لیزر/پرس/سمباده) | ✅ | - |
| `MachineMaintenance` | نگهداری و تعمیرات | - | - |
| `Tool` | ابزار مصرفی (تیغچه/مته/فرز) | - | - |

### ۶) دامنه فروش (Sales Domain)

| Model | توضیح | Multi-Tenant | Soft Delete |
|-------|-------|:------------:|:-----------:|
| `Customer` | مشتری | ✅ | - |
| `Order` | سفارش فروش | ✅ | - |
| `OrderItem` | اقلام سفارش | - | - |
| `Shipment` | محموله ارسالی | - | - |
| `Review` | نظرات کاربران | - | - |
| `Wishlist` | لیست علاقه‌مندی | - | - |
| `Address` | آدرس کاربر | - | - |
| `RecentlyViewed` | بازدیدهای اخیر | - | - |
| `CustomerPhoto` | عکس‌های مشتری از محصول | - | - |
| `ReturnRequest` | درخواست مرجوعی | ✅ | - |
| `PriceDropAlert` | هشدار کاهش قیمت | - | - |
| `WholesaleOrder` | سفارش عمده | ✅ | - |

### ۷) دامنه خرید (Purchasing Domain)

| Model | توضیح | Multi-Tenant | Soft Delete |
|-------|-------|:------------:|:-----------:|
| `Supplier` | تأمین‌کننده | ✅ | - |
| `PurchaseOrder` | سفارش خرید | ✅ | - |
| `PurchaseOrderItem` | اقلام سفارش خرید | - | - |

### ۸) دامنه منابع انسانی (HR Domain)

| Model | توضیح | Multi-Tenant | Soft Delete |
|-------|-------|:------------:|:-----------:|
| `Employee` | کارمند | ✅ | - |

### ۹) دامنه مالی (Finance Domain)

| Model | توضیح | Multi-Tenant | Soft Delete |
|-------|-------|:------------:|:-----------:|
| `Wallet` | کیف پول کاربر | - | - |
| `WalletTransaction` | تراکنش‌های کیف پول | - | - |
| `LoyaltyPoint` | امتیازات وفاداری | - | - |
| `CostFormula` | فرمول قیمت تمام شده | - | - |
| `AccountingEntry` | سند حسابداری | ✅ | - |

### ۱۰) دامنه گردش کار (Workflow Domain)

| Model | توضیح | Multi-Tenant | Soft Delete |
|-------|-------|:------------:|:-----------:|
| `WorkflowDefinition` | تعریف گردش کار | ✅ | - |
| `WorkflowStepDefinition` | مراحل تعریف | - | - |
| `WorkflowInstance` | اجرای گردش کار | ✅ | - |

### ۱۱) دامنه محتوا و آنالیز (Content & Analytics)

| Model | توضیح | Multi-Tenant | Soft Delete |
|-------|-------|:------------:|:-----------:|
| `Page` | صفحه سفارشی | - | - |
| `Block` | بلوک صفحه | - | - |
| `BlogPost` | مقاله بلاگ | - | - |
| `FAQ` | سؤال متداول | - | - |
| `ContactMessage` | پیام تماس | - | - |
| `Newsletter` | خبرنامه | - | - |
| `PBPage` | صفحه Page Builder | - | - |
| `PBTemplate` | قالب Page Builder | - | - |
| `IncomingEmail` | ایمیل دریافتی | - | - |
| `NotificationRequest` | درخواست اعلان | - | - |
| `PaymentMethod` | روش پرداخت | - | - |
| `Coupon` | کد تخفیف | - | - |
| `CouponUsage` | استفاده از کد تخفیف | - | - |
| `AnalyticsSnapshot` | مقادیر آنالیز | ✅ | - |

---

## 🔗 روابط کلیدی (Key Relations)

```
Tenant ─┬─ User ─┬─ Session
        │        ├─ Address
        │        ├─ Wallet ─── WalletTransaction
        │        ├─ LoyaltyPoint
        │        ├─ Wishlist
        │        ├─ Review
        │        ├─ UserNotification
        │        └─ Employee
        │
        ├─ Product ─┬─ ProductImage
        │           ├─ ProductVideo
        │           ├─ ProductColor
        │           ├─ ProductVariant
        │           ├─ ProductDesign (نسخه‌بندی)
        │           ├─ BOM ─── BOMItem
        │           ├─ Routing ─── RoutingStep
        │           ├─ WorkOrder ─┬─ WorkOrderStep
        │           │              ├─ QualityCheck
        │           │              ├─ WasteRecord
        │           │              └─ ProductionBatch
        │           ├─ ProductTraceability
        │           ├─ CostFormula
        │           ├─ PriceHistory
        │           └─ Document
        │
        ├─ Order ─┬─ OrderItem ─── Product
        │         ├─ Shipment
        │         ├─ WorkOrder
        │         └─ WorkflowInstance
        │
        ├─ Customer ─── Order
        │
        ├─ Warehouse ─┬─ WoodStock ─── DryingSession
        │             └─ PaintStock
        │
        ├─ Supplier ─── PurchaseOrder ─── PurchaseOrderItem
        │
        ├─ Machine ─┬─ MachineMaintenance
        │           ├─ Tool
        │           └─ RoutingStep
        │
        ├─ Rule (قوانین پویا)
        │
        ├─ WorkflowDefinition ─┬─ WorkflowStepDefinition
        │                       └─ WorkflowInstance
        │
        ├─ AuditLog
        │
        └─ SiteSetting
```

---

## 🛡️ RBAC Permissions (مرور سریع)

9 نقش اصلی و 35+ دسترسی:

| Role | سطح | توضیح |
|------|------|-------|
| `super_admin` | 3 | دسترسی کامل (مدیر سیستم) |
| `admin` | 3 | مدیریت کل پلتفرم |
| `sales_manager` | 2 | مدیریت فروش |
| `sales_agent` | 2 |代理 فروش |
| `production_manager` | 2 | مدیر تولید |
| `production_operator` | 1 | اپراتور تولید |
| `warehouse_operator` | 1 | اپراتور انبار |
| `qc_inspector` | 1 | بازرس کیفیت |
| `customer` | 0 | مشتری |

---

## 📐 Enums (به صورت String در DB)

### Product.status
- `draft` | `review` | `approved` | `rejected` (ProductDesign)
- `pending` | `confirmed` | `shipping` | `delivered` | `cancelled` (Order)

### Production
- `planned` | `in_progress` | `paused` | `completed` | `cancelled` (WorkOrder)
- `pending` | `in_progress` | `completed` | `skipped` (WorkOrderStep)
- `pass` | `fail` | `rework` (QualityCheck)

### Inventory
- `in_stock` | `reserved` | `used` | `drying` (WoodStock)
- `in_stock` | `low` | `expired` | `used` (PaintStock)
- `in` | `out` | `transfer` | `reserve` | `release` (InventoryTransaction)
- `raw` | `finished` | `wip` | `packaging` (Warehouse.type)

### Machine
- `active` | `maintenance` | `broken` | `retired` (Machine.status)
- `cnc` | `saw` | `laser` | `press` | `compressor` | `sander` (Machine.type)

### Pricing
- `percentage` | `fixed` | `bogo` | `wholesale` (DiscountRule.type)

### Finance
- `debit` | `credit` (AccountingEntry.type)

### Workflow
- `active` | `completed` | `cancelled` (WorkflowInstance.status)

---

## 🎯 فاز بعدی (Phase 3)

در فاز ۳، موارد زیر تکمیل خواهند شد:
1. ✅ 5 موتور باقی‌مانده (Pricing, Accounting, Workflow, Analytics, Document)
2. استانداردسازی REST API (CRUD برای هر موجودیت)
3. Migration از SQL به Prisma Migrate (به جای db push)
4. Webhook handlers برای Event Bus

---

**نسخه**: 7.0.0-phase2  
**تعداد موجودیت‌ها**: 78  
**وضعیت**: فاز ۲ تکمیل شد ✅
