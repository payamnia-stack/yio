# YIO V7 — REST API Documentation

> پلتفرم کامل تجارت الکترونیک و تولید YIO با ۱۰ موتور تجاری

## 📋 خلاصه

| شاخص | مقدار |
|------|-------|
| نسخه API | `v1` |
| Base URL | `http://localhost:4000/api/v1` |
| احراز هویت | JWT Bearer Token |
| فرمت پاسخ | JSON |
| محدودیت نرخ | 100 درخواست / ۱۵ دقیقه |
| مستندات | `http://localhost:4000/api/docs` (Swagger UI) |

## 🚀 شروع سریع

### ۱) نصب وابستگی‌ها

```bash
cd /var/www/yio-v7
npm install
```

### ۲) تنظیم متغیرهای محیطی

```bash
cp .env.example .env
# مقادیر DATABASE_URL، JWT_SECRET و ... را ویرایش کنید
```

### ۳) راه‌اندازی دیتابیس

```bash
cd packages/repositories
npm run db:generate
npm run db:push
npm run db:seed
```

### ۴) Build و راه‌اندازی

```bash
# Build API
cd apps/api
npm run build

# اجرا با PM2
cd /var/www/yio-v7
pm2 start ecosystem.config.cjs
pm2 status
```

### ۵) تست

```bash
# Health check
curl http://localhost:4000/health

# ورود مدیر
curl -X POST http://localhost:4000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"phone":"09120000000","password":"Admin@V7!2026"}'

# دریافت محصولات
curl http://localhost:4000/api/v1/products
```

## 📊 آمار API

| بخش | تعداد مسیرها |
|------|-------------|
| Auth | ۷ |
| Users | ۷ |
| Products | ۸ |
| Orders | ۷ |
| Work Orders (Production) | ۶ |
| Inventory | ۸ |
| Pricing | ۵ |
| Accounting | ۸ |
| Workflow | ۵ |
| Analytics | ۶ |
| Documents | ۷ |
| Rules | ۶ |
| Notifications | ۴ |
| Suppliers | ۵ |
| Purchase Orders | ۵ |
| Machines | ۴ |
| Employees | ۴ |
| Audit Logs | ۱ |
| Tenants | ۲ |
| Webhooks | ۵ |
| **مجموع** | **۱۱۴ مسیر** |

## 🔐 احراز هویت

### ورود

```http
POST /api/v1/auth/login
Content-Type: application/json

{
  "phone": "09120000000",
  "password": "Admin@V7!2026"
}
```

### پاسخ

```json
{
  "success": true,
  "data": {
    "accessToken": "eyJhbGc...",
    "refreshToken": "eyJhbGc...",
    "user": {
      "id": 1,
      "phone": "09120000000",
      "name": "مدیر سیستم",
      "level": 3,
      "isWholesale": false
    }
  }
}
```

### استفاده از توکن

```http
GET /api/v1/products
Authorization: Bearer eyJhbGc...
```

### تمدید توکن

```http
POST /api/v1/auth/refresh
Content-Type: application/json

{
  "refreshToken": "eyJhbGc..."
}
```

## 📋 نقش‌ها و دسترسی‌ها

| Role | سطح | دسترسی |
|------|-----|--------|
| `customer` | 0 | مشاهده محصولات، سفارش خود، پروفایل |
| `staff` | 2 | مدیریت محصولات، سفارشات، انبار |
| `admin` | 3 | دسترسی کامل به همه بخش‌ها |
| `super_admin` | 3 | دسترسی به Tenantها |

## 🛡️ ساختار پاسخ

### پاسخ موفق

```json
{
  "success": true,
  "data": { ... },
  "pagination": {
    "page": 1,
    "pageSize": 20,
    "total": 100,
    "totalPages": 5
  }
}
```

### پاسخ خطا

```json
{
  "success": false,
  "error": {
    "code": "BUSINESS_ERROR",
    "message": "توضیح خطا",
    "field": "fieldName"
  }
}
```

### کدهای وضعیت HTTP

| کد | توضیح |
|----|-------|
| 200 | موفق (GET, PUT, PATCH, DELETE) |
| 201 | ایجاد موفق (POST) |
| 400 | خطای اعتبارسنجی |
| 401 | عدم احراز هویت |
| 403 | عدم دسترسی |
| 404 | یافت نشد |
| 409 | تکراری |
| 422 | خطای اعتبارسنجی داده‌ها |
| 429 | محدودیت نرخ |
| 500 | خطای سرور |

## 📖 مسیرهای اصلی

### محصولات

| Method | Path | توضیح |
|--------|------|-------|
| GET | `/products` | لیست محصولات |
| GET | `/products/:id` | دریافت محصول |
| POST | `/products` | ایجاد محصول |
| PUT | `/products/:id` | به‌روزرسانی |
| DELETE | `/products/:id` | حذف |
| POST | `/products/:id/publish` | انتشار |
| PATCH | `/products/:id/stock` | به‌روزرسانی موجودی |

### سفارشات

| Method | Path | توضیح |
|--------|------|-------|
| GET | `/orders` | لیست سفارشات |
| GET | `/orders/:id` | دریافت سفارش |
| POST | `/orders` | ایجاد سفارش |
| POST | `/orders/:id/confirm` | تأیید |
| POST | `/orders/:id/ship` | ارسال |
| POST | `/orders/:id/deliver` | تحویل |
| POST | `/orders/:id/cancel` | لغو |

### قیمت‌گذاری

| Method | Path | توضیح |
|--------|------|-------|
| POST | `/pricing/calculate` | محاسبه قیمت نهایی |
| GET | `/pricing/cost/:productId` | محاسبه قیمت تمام شده |
| POST | `/pricing/update-price` | تغییر قیمت |
| POST | `/pricing/bulk-discount` | تخفیف گروهی |

### حسابداری

| Method | Path | توضیح |
|--------|------|-------|
| POST | `/accounting/journal-entry` | ثبت سند |
| POST | `/accounting/record-sale` | ثبت فروش |
| GET | `/accounting/trial-balance` | ترازنامه |
| GET | `/accounting/profit-loss` | سود و زیان |
| GET | `/accounting/balance-sheet` | تراز نامه مالی |

### گردش کار

| Method | Path | توضیح |
|--------|------|-------|
| POST | `/workflow/start` | شروع |
| POST | `/workflow/advance` | پیشروی |
| POST | `/workflow/cancel` | لغو |
| GET | `/workflow/status/:entityType/:entityId` | وضعیت |

### آنالیز

| Method | Path | توضیح |
|--------|------|-------|
| GET | `/analytics/dashboard` | داشبورد |
| POST | `/analytics/record-kpis` | ثبت KPIها |
| GET | `/analytics/sales-report` | گزارش فروش |
| GET | `/analytics/production-report` | گزارش تولید |

### اسناد

| Method | Path | توضیح |
|--------|------|-------|
| POST | `/documents/upload` | آپلود (multipart) |
| GET | `/documents/:id` | دریافت |
| DELETE | `/documents/:id` | حذف |
| POST | `/documents/:id/sign` | امضای دیجیتال |
| POST | `/documents/:id/share` | اشتراک‌گذاری |
| GET | `/documents/search` | جستجو |

## 🔗 Webhookها

### ثبت Webhook

```http
POST /api/v1/webhooks/register
Authorization: Bearer <token>
Content-Type: application/json

{
  "url": "https://your-app.com/webhook",
  "events": ["order.created", "order.delivered"],
  "secret": "your-webhook-secret"
}
```

### رویدادهای قابل اشتراک

۴۲ رویداد در ۹ دسته:
- محصول (۴)
- سفارش (۵)
- تولید (۴)
- انبار (۳)
- کیفیت (۲)
- ماشین (۲)
- کاربر (۲)
- خرید (۲)
- قیمت‌گذاری (۴)
- حسابداری (۴)
- گردش کار (۵)
- آنالیز (۳)
- سند (۴)

### تأیید امضای Webhook

```javascript
const crypto = require('crypto');

function verifySignature(payload, signature, secret) {
  const expected = crypto
    .createHmac('sha256', secret)
    .update(payload)
    .digest('hex');
  return `sha256=${expected}` === signature;
}
```

## 🛠️ Client SDK

```typescript
import { createApiClient } from '@yio/api/client';

const client = createApiClient({
  baseURL: 'https://api.yio.ir/api/v1',
  accessToken: 'eyJhbGc...',
  refreshToken: 'eyJhbGc...',
  onTokenExpired: async () => {
    // تمدید خودکار توکن
  },
});

// استفاده
const products = await client.products.list({ page: 1, pageSize: 20 });
const order = await client.orders.create({ ... });
const dashboard = await client.analytics.dashboard();
```

## 📊 ساختار پروژه

```
apps/api/
├── src/
│   ├── server.ts                # Express app entry
│   ├── client.ts                # TypeScript SDK
│   ├── controllers/
│   │   ├── auth-controller.ts   # Auth endpoints
│   │   └── crud-factory.ts      # Generic CRUD factory
│   ├── middleware/
│   │   ├── auth.ts              # JWT + RBAC
│   │   ├── rate-limit.ts        # Rate limiting
│   │   ├── error-handler.ts     # Error handling
│   │   └── tenant-audit.ts      # Tenant + Audit log
│   ├── routes/
│   │   ├── index.ts             # All 114 routes
│   │   └── webhooks.ts          # Webhook management
│   └── docs/
│       └── openapi.ts           # Swagger/OpenAPI spec
├── package.json
└── tsconfig.json
```

## 🚢 استقرار

### Nginx Reverse Proxy

```nginx
server {
    listen 443 ssl http2;
    server_name api.yio.ir;

    ssl_certificate /etc/letsencrypt/live/api.yio.ir/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.yio.ir/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:4000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300;
    }

    # File uploads
    client_max_body_size 100M;
}
```

### PM2 Commands

```bash
pm2 start ecosystem.config.cjs     # شروع همه سرویس‌ها
pm2 status                          # وضعیت
pm2 logs yio-v7-api                 # لاگ API
pm2 restart yio-v7-api              # ریستارت
pm2 reload yio-v7-api               # reload بدون قطعی
pm2 monit                           # مانیتورینگ
```

## 📞 پشتیبانی

- **مستندات Swagger**: `/api/docs`
- **Health Check**: `/health`
- **Issues**: `info@yio.ir`

---

**نسخه**: 7.0.0-phase4  
**تعداد مسیرها**: 114  
**تعداد موتورهای متصل**: 10  
**وضعیت**: فاز ۴ تکمیل شد ✅
