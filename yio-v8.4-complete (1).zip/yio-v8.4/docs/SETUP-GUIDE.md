# راهنمای راه‌اندازی YIO V7

> راهنمای کامل راه‌اندازی محلی و سرور (VPS)

## 📋 پیش‌نیازها

| نیازمندی | نسخه | توضیح |
|----------|------|-------|
| Node.js | ≥ 18.0 | JavaScript Runtime |
| npm | ≥ 9.0 | Package Manager |
| PostgreSQL | ≥ 14 | دیتابیس |

---

## 🖥️ راه‌اندازی محلی (Local Development)

### روش سریع (یک دستور)

```bash
cd /home/z/my-project/site/yio-v7
bash scripts/setup-local.sh
```

این اسکریپت به طور خودکار:
1. ✅ PostgreSQL 16 را دانلود و نصب می‌کند (بدون نیاز به root)
2. ✅ دیتابیس `yio_v7` را ایجاد می‌کند
3. ✅ وابستگی‌های npm را نصب می‌کند
4. ✅ Schema را با Prisma اعمال می‌کند
5. ✅ داده‌های seed را وارد می‌کند
6. ✅ فایل‌های `.env` را پیکربندی می‌کند

### روش دستی (گام به گام)

#### ۱) شروع PostgreSQL

```bash
cd /home/z/my-project/site/yio-v7
bash scripts/start-postgres.sh
```

خروجی مورد انتظار:
```
🚀 Starting PostgreSQL...
✅ PostgreSQL started
   Connection: postgresql://postgres:yio_v7_password@localhost:5432/yio_v7
```

#### ۲) شروع API سرور

```bash
bash scripts/start-api.sh
```

خروجی مورد انتظار:
```
🚀 Starting YIO V7 API Server...
   Port: 4000
   API:  http://localhost:4000/api/v1
   Docs: http://localhost:4000/api/docs
```

#### ۳) شروع پنل فروشگاه

در یک ترمینال جدید:
```bash
bash scripts/start-shop.sh
```

خروجی مورد انتظار:
```
🚀 Starting YIO Shop Panel...
   URL: http://localhost:3000
```

#### ۴) تست سیستم

مرورگر را باز کنید:
- 🏪 **فروشگاه**: http://localhost:3000
- 📚 **مستندات API**: http://localhost:4000/api/docs
- ❤️ **Health Check**: http://localhost:4000/health

### ورود به سیستم

| فیلد | مقدار |
|------|-------|
| شماره موبایل | `09120000000` |
| رمز عبور | `Admin@V7!2026` |

### دستورات مفید

```bash
# مدیریت PostgreSQL
bash scripts/start-postgres.sh    # شروع
bash scripts/stop-postgres.sh     # توقف

# مدیریت API
bash scripts/start-api.sh         # شروع API

# مدیریت Shop
bash scripts/start-shop.sh        # شروع فروشگاه

# Prisma Studio (مشاهده دیتابیس)
cd packages/repositories
npx prisma studio --schema=prisma/schema.prisma

# ریست دیتابیس
cd packages/repositories
npx prisma db push --schema=prisma/schema.prisma --accept-data-loss
npx tsx prisma/seed.ts

# تست API با curl
curl -X POST http://localhost:4000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"phone":"09120000000","password":"Admin@V7!2026"}'
```

---

## 🌐 راه‌اندازی روی VPS

### پیش‌نیازهای VPS

- **OS**: Debian 12 / Ubuntu 22.04 یا بالاتر
- **RAM**: حداقل 1GB (توصیه: 2GB)
- **Disk**: حداقل 10GB
- **Access**: root یا sudo user

### مرحله ۱: نصب پیش‌نیازها

```bash
# آپدیت سیستم
sudo apt update && sudo apt upgrade -y

# نصب Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# نصب PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# نصب PM2
sudo npm install -g pm2

# نصب Nginx
sudo apt install -y nginx

# نصب Git
sudo apt install -y git
```

### مرحله ۲: کپی پروژه

```bash
# ایجاد دایرکتوری
sudo mkdir -p /var/www/yio-v7
sudo chown $USER:$USER /var/www/yio-v7

# کپی پروژه (از فایل zip یا git)
cd /var/www/yio-v7
# اگر فایل zip دارید:
unzip yio-v7.zip -d .
# یا از git:
# git clone https://github.com/your-repo/yio-v7.git .
```

### مرحله ۳: پیکربندی دیتابیس

```bash
# ورود به PostgreSQL
sudo -u postgres psql

# در محیط psql:
CREATE DATABASE yio_v7 ENCODING 'UTF8' LC_COLLATE 'fa_IR.UTF-8' LC_CTYPE 'fa_IR.UTF-8' TEMPLATE template0;
CREATE USER yio_user WITH PASSWORD 'your_strong_password_here';
GRANT ALL PRIVILEGES ON DATABASE yio_v7 TO yio_user;
ALTER USER yio_user WITH SUPERUSER;
\q
```

### مرحله ۴: پیکربندی فایل `.env`

```bash
cd /var/www/yio-v7
cp .env.example .env
nano .env
```

محتوای `.env`:
```env
# Database
DATABASE_URL="postgresql://yio_user:your_strong_password_here@localhost:5432/yio_v7?schema=public"

# JWT Secrets (تولید رشته تصادفی طولانی!)
JWT_SECRET=$(openssl rand -hex 32)
JWT_REFRESH_SECRET=$(openssl rand -hex 32)

# Multi-Tenant
DEFAULT_TENANT_ID=1

# API
PORT=4000
NODE_ENV=production

# CORS
CORS_ORIGINS=https://yio.ir,https://www.yio.ir

# SMS (Melipayamak)
MELIPAYAMAK_USERNAME=your_username
MELIPAYAMAK_PASSWORD=your_password
MELIPAYAMAK_SENDER_NUMBER=5000270019

# Email
SMTP_HOST=smtp.yio.ir
SMTP_PORT=587
SMTP_USER=info@yio.ir
SMTP_PASSWORD=your_email_password
```

### مرحله ۵: نصب وابستگی‌ها و Build

```bash
cd /var/www/yio-v7

# نصب وابستگی‌ها
npm install --legacy-peer-deps

# اعمال Schema به دیتابیس
cd packages/repositories
npx prisma generate --schema=prisma/schema.prisma
npx prisma db push --schema=prisma/schema.prisma --accept-data-loss

# Seed دیتابیس
npx tsx prisma/seed.ts

# Build API
cd /var/www/yio-v7/apps/api
npm run build

# Build Shop
cd /var/www/yio-v7/apps/shop
npm run build
```

### مرحله ۶: پیکربندی PM2

```bash
cd /var/www/yio-v7

# اصلاح ecosystem.config.cjs (در صورت نیاز)
nano ecosystem.config.cjs

# شروع سرویس‌ها
pm2 start ecosystem.config.cjs

# ذخیره تنظیمات برای راه‌اندازی خودکار
pm2 save
pm2 startup
# دستور نمایش داده شده را اجرا کنید
```

### مرحله ۷: پیکربندی Nginx

```bash
sudo nano /etc/nginx/sites-available/yio-v7
```

محتوای فایل:
```nginx
# API Server
server {
    listen 80;
    server_name api.yio.ir;

    location / {
        proxy_pass http://127.0.0.1:4000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 300;
    }

    client_max_body_size 100M;
}

# Shop (فروشگاه)
server {
    listen 80;
    server_name yio.ir www.yio.ir;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # فایل‌های آپلود شده
    location /uploads/ {
        alias /var/www/yio-v7/storage/uploads/;
        expires 7d;
        add_header Cache-Control "public, immutable";
    }

    client_max_body_size 100M;
}
```

فعال‌سازی:
```bash
sudo ln -s /etc/nginx/sites-available/yio-v7 /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx
```

### مرحله ۸: نصب SSL (HTTPS)

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d yio.ir -d www.yio.ir -d api.yio.ir
```

### مرحله ۹: تست نهایی

```bash
# تست Health Check
curl http://localhost:4000/health

# تست Login
curl -X POST http://localhost:4000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"phone":"09120000000","password":"Admin@V7!2026"}'

# تست از خارج
curl https://api.yio.ir/health
```

---

## 🔧 مدیریت سرور

### دستورات PM2

```bash
pm2 status                    # وضعیت سرویس‌ها
pm2 logs yio-v7-api           # لاگ API
pm2 logs yio-v7-web           # لاگ Shop
pm2 restart yio-v7-api        # ریستارت API
pm2 reload yio-v7-api         # reload بدون قطعی
pm2 stop all                  # توقف همه
pm2 restart all               # ریستارت همه
pm2 monit                     # مانیتورینگ زنده
```

### بک‌آپ دیتابیس

```bash
# بک‌آپ手动
pg_dump -U yio_user -d yio_v7 > /backup/yio_v7_$(date +%Y%m%d).sql

# بک‌آپ خودکار (cron)
crontab -e
# اضافه کنید:
0 2 * * * pg_dump -U yio_user -d yio_v7 > /backup/yio_v7_$(date +\%Y\%m\%d).sql

# بازیابی
psql -U yio_user -d yio_v7 < /backup/yio_v7_20260727.sql
```

### آپدیت پروژه

```bash
cd /var/www/yio-v7

# بک‌آپ
pm2 stop all
pg_dump -U yio_user -d yio_v7 > /backup/before_update.sql

# آپدیت کد
git pull origin main
# یا کپی فایل‌های جدید

# نصب وابستگی‌های جدید
npm install --legacy-peer-deps

# اعمال تغییرات Schema
cd packages/repositories
npx prisma generate
npx prisma db push --accept-data-loss

# Build مجدد
cd /var/www/yio-v7
npm run build

# ریستارت
pm2 restart all
```

### مشاهده لاگ‌ها

```bash
# لاگ‌های PM2
pm2 logs

# لاگ‌های Nginx
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log

# لاگ‌های PostgreSQL
sudo tail -f /var/log/postgresql/postgresql-16-main.log
```

---

## 🚨 رفع اشکال

### مشکل: PostgreSQL اجرا نمی‌شود

```bash
# بررسی وضعیت
sudo systemctl status postgresql

# شروع مجدد
sudo systemctl restart postgresql

# بررسی لاگ
sudo tail -20 /var/log/postgresql/postgresql-16-main.log
```

### مشکل: API سرور در دسترس نیست

```bash
# بررسی PM2
pm2 status

# بررسی لاگ
pm2 logs yio-v7-api --lines 50

# بررسی پورت
sudo netstat -tlnp | grep :4000

# ریستارت
pm2 restart yio-v7-api
```

### مشکل: خطای اتصال به دیتابیس

```bash
# تست اتصال
psql -U yio_user -d yio_v7 -h localhost

# بررسی DATABASE_URL
cat /var/www/yio-v7/.env | grep DATABASE_URL

# بررسی Firewall
sudo ufw status
```

### مشکل: Nginx خطای 502

```bash
# بررسی اینکه API در حال اجراست
curl http://localhost:4000/health

# بررسی Nginx config
sudo nginx -t

# ریستارت Nginx
sudo systemctl restart nginx
```

---

## 📞 پشتیبانی

در صورت بروز مشکل:

1. لاگ‌ها را بررسی کنید: `pm2 logs`
2. مستندات API: `https://api.yio.ir/api/docs`
3. Health Check: `https://api.yio.ir/health`

---

**نسخه سند**: 7.0.0  
**آخرین به‌روزرسانی**: 2026-07-27
