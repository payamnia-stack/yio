// ============================================================
// YIO V7 — Sales Forecasting Engine
// ============================================================
// پیش‌بینی فروش با استفاده از:
//   - Moving Average
//   - Exponential Smoothing
//   - Linear Trend
//   - Seasonal Decomposition
//   - Confidence intervals
// ============================================================

import { Context, BusinessError, OperationResult } from '@yio/core';
import { PrismaClient } from '@prisma/client';
import { IEventBus } from '@yio/core';
import { SalesForecastGeneratedEvent, SalesAnomalyDetectedEvent } from '../types';

export interface SalesDataPoint {
  date: Date;
  value: number;
  orders: number;
}

export interface ForecastResult {
  forecast: Array<{
    date: string;
    value: number;
    lower: number;  // confidence interval lower
    upper: number;  // confidence interval upper
  }>;
  method: string;
  accuracy: number; // MAPE (Mean Absolute Percentage Error)
  trend: 'up' | 'down' | 'stable';
  trendPercent: number;
  seasonality: {
    detected: boolean;
    period?: number; // days
    strength?: number; // 0-1
  };
  summary: {
    totalForecast: number;
    averageDaily: number;
    peakDay: string;
    peakValue: number;
  };
}

export interface ForecastOptions {
  method?: 'auto' | 'moving_average' | 'exponential' | 'linear' | 'seasonal';
  periods?: number; // تعداد روزهای پیش‌بینی (پیش‌فرض: 30)
  confidenceLevel?: number; // 0.95 = 95%
  productId?: number; // برای پیش‌بینی محصول خاص
  categoryId?: string;
}

export class SalesForecastingEngine {
  constructor(
    private prisma: PrismaClient,
    private eventBus: IEventBus,
  ) {}

  // ============================================================
  // 1) پیش‌بینی فروش
  // ============================================================
  async forecast(ctx: Context, options: ForecastOptions = {}): Promise<ForecastResult> {
    const {
      method = 'auto',
      periods = 30,
      confidenceLevel = 0.95,
      productId,
      categoryId,
    } = options;

    // 1. دریافت داده‌های تاریخی (حداقل ۹۰ روز)
    const historicalData = await this.getHistoricalData(ctx, productId, categoryId, 90);

    if (historicalData.length < 7) {
      throw new BusinessError(
        'داده‌های کافی برای پیش‌بینی وجود ندارد (حداقل ۷ روز نیاز است)',
        'INSUFFICIENT_DATA',
      );
    }

    // 2. تشخیص خودکار روش
    let selectedMethod: 'moving_average' | 'exponential' | 'linear' | 'seasonal' = 'exponential';
    if (method === 'auto') {
      selectedMethod = this.selectBestMethod(historicalData) as any;
    } else {
      selectedMethod = method as any;
    }

    // 3. اجرای پیش‌بینی
    let forecastValues: number[];
    let accuracy: number;

    switch (selectedMethod) {
      case 'moving_average':
        ({ forecast: forecastValues, accuracy } = this.movingAverage(historicalData, periods));
        break;
      case 'exponential':
        ({ forecast: forecastValues, accuracy } = this.exponentialSmoothing(historicalData, periods));
        break;
      case 'linear':
        ({ forecast: forecastValues, accuracy } = this.linearRegression(historicalData, periods));
        break;
      case 'seasonal':
        ({ forecast: forecastValues, accuracy } = this.seasonalDecomposition(historicalData, periods));
        break;
      default:
        ({ forecast: forecastValues, accuracy } = this.exponentialSmoothing(historicalData, periods));
    }

    // 4. محاسبه confidence interval
    const { lower, upper } = this.calculateConfidenceInterval(
      forecastValues,
      historicalData,
      confidenceLevel,
    );

    // 5. تشخیص trend
    const trend = this.detectTrend(historicalData);

    // 6. تشخیص seasonality
    const seasonality = this.detectSeasonality(historicalData);

    // 7. ساخت خروجی
    const forecast = forecastValues.map((value, i) => {
      const date = new Date();
      date.setDate(date.getDate() + i + 1);
      return {
        date: date.toISOString().slice(0, 10),
        value: Math.max(0, Math.round(value)),
        lower: Math.max(0, Math.round(lower[i])),
        upper: Math.max(0, Math.round(upper[i])),
      };
    });

    const totalForecast = forecast.reduce((s, f) => s + f.value, 0);
    const averageDaily = Math.round(totalForecast / periods);
    const peakIdx = forecast.indexOf(forecast.reduce((max, f) => f.value > max.value ? f : max, forecast[0]));

    const result: ForecastResult = {
      forecast,
      method: selectedMethod,
      accuracy,
      trend: trend.direction,
      trendPercent: trend.percent,
      seasonality,
      summary: {
        totalForecast,
        averageDaily,
        peakDay: forecast[peakIdx]?.date || '',
        peakValue: forecast[peakIdx]?.value || 0,
      },
    };

    // 8. Publish event
    await this.eventBus.publish(new SalesForecastGeneratedEvent(
      totalForecast,
      periods,
      selectedMethod,
      ctx.tenantId,
    ));

    return result;
  }

  // ============================================================
  // 2) دریافت داده‌های تاریخی
  // ============================================================
  private async getHistoricalData(
    ctx: Context,
    productId: number | undefined,
    categoryId: string | undefined,
    days: number,
  ): Promise<SalesDataPoint[]> {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    const where: any = {
      tenantId: ctx.tenantId,
      createdAt: { gte: startDate },
      status: { not: 'cancelled' },
    };

    if (productId) {
      where.items = { some: { productId } };
    }

    if (categoryId) {
      where.items = {
        some: {
          product: { category: categoryId },
        },
      };
    }

    const orders = await this.prisma.order.findMany({
      where,
      select: {
        finalAmount: true,
        createdAt: true,
      },
      orderBy: { createdAt: 'asc' },
    });

    // گروه‌بندی بر اساس روز
    const dailyMap = new Map<string, { value: number; orders: number }>();
    for (const order of orders) {
      const day = order.createdAt.toISOString().slice(0, 10);
      if (!dailyMap.has(day)) {
        dailyMap.set(day, { value: 0, orders: 0 });
      }
      const dayData = dailyMap.get(day)!;
      dayData.value += order.finalAmount;
      dayData.orders += 1;
    }

    // پر کردن روزهای خالی
    const result: SalesDataPoint[] = [];
    const today = new Date();
    for (let i = days - 1; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dayStr = date.toISOString().slice(0, 10);
      const data = dailyMap.get(dayStr) || { value: 0, orders: 0 };
      result.push({
        date,
        value: data.value,
        orders: data.orders,
      });
    }

    return result;
  }

  // ============================================================
  // 3) Moving Average
  // ============================================================
  private movingAverage(data: SalesDataPoint[], periods: number) {
    const windowSize = Math.min(7, Math.floor(data.length / 3));
    const values = data.map(d => d.value);

    // محاسبه میانگین متحرک
    const ma: number[] = [];
    for (let i = 0; i < values.length; i++) {
      const start = Math.max(0, i - windowSize + 1);
      const window = values.slice(start, i + 1);
      ma.push(window.reduce((s, v) => s + v, 0) / window.length);
    }

    // پیش‌بینی: استفاده از آخرین میانگین
    const lastMA = ma[ma.length - 1];
    const forecast = Array(periods).fill(lastMA);

    // محاسبه دقت (MAPE)
    const accuracy = this.calculateMAPE(values, ma);

    return { forecast, accuracy };
  }

  // ============================================================
  // 4) Exponential Smoothing
  // ============================================================
  private exponentialSmoothing(data: SalesDataPoint[], periods: number) {
    const values = data.map(d => d.value);
    const alpha = 0.3; // smoothing factor

    // محاسبه exponential smoothing
    const smoothed: number[] = [values[0]];
    for (let i = 1; i < values.length; i++) {
      smoothed.push(alpha * values[i] + (1 - alpha) * smoothed[i - 1]);
    }

    // پیش‌بینی: استفاده از آخرین مقدار smooth شده
    const lastSmoothed = smoothed[smoothed.length - 1];
    const forecast = Array(periods).fill(lastSmoothed);

    const accuracy = this.calculateMAPE(values, smoothed);

    return { forecast, accuracy };
  }

  // ============================================================
  // 5) Linear Regression
  // ============================================================
  private linearRegression(data: SalesDataPoint[], periods: number) {
    const values = data.map(d => d.value);
    const n = values.length;

    // محاسبه ضرایب رگرسیون
    const x = Array.from({ length: n }, (_, i) => i);
    const xMean = x.reduce((s, v) => s + v, 0) / n;
    const yMean = values.reduce((s, v) => s + v, 0) / n;

    let numerator = 0;
    let denominator = 0;
    for (let i = 0; i < n; i++) {
      numerator += (x[i] - xMean) * (values[i] - yMean);
      denominator += (x[i] - xMean) ** 2;
    }

    const slope = denominator === 0 ? 0 : numerator / denominator;
    const intercept = yMean - slope * xMean;

    // پیش‌بینی
    const forecast: number[] = [];
    for (let i = 0; i < periods; i++) {
      forecast.push(slope * (n + i) + intercept);
    }

    // محاسبه دقت
    const predicted = x.map(xi => slope * xi + intercept);
    const accuracy = this.calculateMAPE(values, predicted);

    return { forecast, accuracy };
  }

  // ============================================================
  // 6) Seasonal Decomposition
  // ============================================================
  private seasonalDecomposition(data: SalesDataPoint[], periods: number) {
    const values = data.map(d => d.value);
    const n = values.length;

    // تشخیص دوره فصلی (هفتگی = 7)
    const seasonLength = 7;

    if (n < seasonLength * 2) {
      // اگر داده کافی نیست، به exponential برمی‌گردیم
      return this.exponentialSmoothing(data, periods);
    }

    // محاسبه میانگین متحرک برای trend
    const trend: number[] = [];
    for (let i = 0; i < n; i++) {
      const start = Math.max(0, i - Math.floor(seasonLength / 2));
      const end = Math.min(n, i + Math.ceil(seasonLength / 2));
      const window = values.slice(start, end);
      trend.push(window.reduce((s, v) => s + v, 0) / window.length);
    }

    // محاسبه seasonal component
    const seasonal: number[] = [];
    for (let i = 0; i < n; i++) {
      const detrended = values[i] - trend[i];
      seasonal.push(detrended);
    }

    // میانگین seasonal برای هر موقعیت
    const seasonalAvg: number[] = [];
    for (let i = 0; i < seasonLength; i++) {
      const indices: number[] = [];
      for (let j = i; j < n; j += seasonLength) {
        indices.push(j);
      }
      const avg = indices.reduce((s, idx) => s + seasonal[idx], 0) / indices.length;
      seasonalAvg.push(avg);
    }

    // پیش‌بینی: trend (linear) + seasonal
    const x = Array.from({ length: n }, (_, i) => i);
    const xMean = x.reduce((s, v) => s + v, 0) / n;
    const yMean = trend.reduce((s, v) => s + v, 0) / n;

    let numerator = 0;
    let denominator = 0;
    for (let i = 0; i < n; i++) {
      numerator += (x[i] - xMean) * (trend[i] - yMean);
      denominator += (x[i] - xMean) ** 2;
    }

    const slope = denominator === 0 ? 0 : numerator / denominator;
    const intercept = yMean - slope * xMean;

    const forecast: number[] = [];
    for (let i = 0; i < periods; i++) {
      const trendValue = slope * (n + i) + intercept;
      const seasonalValue = seasonalAvg[(n + i) % seasonLength];
      forecast.push(trendValue + seasonalValue);
    }

    // دقت
    const predicted = x.map(xi => slope * xi + intercept + seasonalAvg[xi % seasonLength]);
    const accuracy = this.calculateMAPE(values, predicted);

    return { forecast, accuracy };
  }

  // ============================================================
  // 7) انتخاب بهترین روش
  // ============================================================
  private selectBestMethod(data: SalesDataPoint[]): string {
    const n = data.length;

    // اگر کمتر از ۱۴ روز، exponential
    if (n < 14) return 'exponential';

    // اگر seasonality قوی وجود دارد، seasonal
    const seasonality = this.detectSeasonality(data);
    if (seasonality.detected && seasonality.strength && seasonality.strength > 0.5) {
      return 'seasonal';
    }

    // بررسی trend قوی
    const trend = this.detectTrend(data);
    if (Math.abs(trend.percent) > 10) {
      return 'linear';
    }

    // پیش‌فرض: exponential
    return 'exponential';
  }

  // ============================================================
  // 8) تشخیص Trend
  // ============================================================
  private detectTrend(data: SalesDataPoint[]): { direction: 'up' | 'down' | 'stable'; percent: number } {
    const values = data.map(d => d.value);
    const n = values.length;

    // مقایسه نیمه اول با نیمه دوم
    const half = Math.floor(n / 2);
    const firstHalfAvg = values.slice(0, half).reduce((s, v) => s + v, 0) / half;
    const secondHalfAvg = values.slice(half).reduce((s, v) => s + v, 0) / (n - half);

    if (firstHalfAvg === 0) {
      return { direction: 'stable', percent: 0 };
    }

    const percent = ((secondHalfAvg - firstHalfAvg) / firstHalfAvg) * 100;

    if (Math.abs(percent) < 5) {
      return { direction: 'stable', percent };
    }

    return {
      direction: percent > 0 ? 'up' : 'down',
      percent: Math.round(percent),
    };
  }

  // ============================================================
  // 9) تشخیص Seasonality
  // ============================================================
  private detectSeasonality(data: SalesDataPoint[]): {
    detected: boolean;
    period?: number;
    strength?: number;
  } {
    const values = data.map(d => d.value);
    const n = values.length;

    if (n < 14) {
      return { detected: false };
    }

    // محاسبه autocorrelation با lag=7 (هفتگی)
    const lag = 7;
    const mean = values.reduce((s, v) => s + v, 0) / n;

    let numerator = 0;
    let denominator = 0;
    for (let i = 0; i < n - lag; i++) {
      numerator += (values[i] - mean) * (values[i + lag] - mean);
    }
    for (let i = 0; i < n; i++) {
      denominator += (values[i] - mean) ** 2;
    }

    const autocorrelation = denominator === 0 ? 0 : numerator / denominator;

    return {
      detected: autocorrelation > 0.3,
      period: 7,
      strength: Math.max(0, Math.min(1, autocorrelation)),
    };
  }

  // ============================================================
  // 10) محاسبه Confidence Interval
  // ============================================================
  private calculateConfidenceInterval(
    forecast: number[],
    historical: SalesDataPoint[],
    confidenceLevel: number,
  ): { lower: number[]; upper: number[] } {
    // محاسبه انحراف معیار خطا
    const values = historical.map(d => d.value);
    const mean = values.reduce((s, v) => s + v, 0) / values.length;
    const variance = values.reduce((s, v) => s + (v - mean) ** 2, 0) / values.length;
    const stdDev = Math.sqrt(variance);

    // z-score برای confidence level
    const zScores: Record<number, number> = {
      0.90: 1.645,
      0.95: 1.96,
      0.99: 2.576,
    };
    const z = zScores[confidenceLevel] || 1.96;

    const margin = z * stdDev;

    const lower = forecast.map(v => v - margin);
    const upper = forecast.map(v => v + margin);

    return { lower, upper };
  }

  // ============================================================
  // 11) محاسبه MAPE (Mean Absolute Percentage Error)
  // ============================================================
  private calculateMAPE(actual: number[], predicted: number[]): number {
    let sum = 0;
    let count = 0;
    for (let i = 0; i < actual.length; i++) {
      if (actual[i] !== 0) {
        sum += Math.abs((actual[i] - predicted[i]) / actual[i]);
        count++;
      }
    }
    const mape = count === 0 ? 1 : (sum / count) * 100;
    // دقت = 100 - MAPE
    return Math.max(0, Math.min(100, 100 - mape));
  }

  // ============================================================
  // 12) تشخیص ناهنجاری (Anomaly Detection)
  // ============================================================
  async detectAnomalies(ctx: Context, days = 30): Promise<Array<{
    date: string;
    value: number;
    expected: number;
    deviation: number;
    severity: 'low' | 'medium' | 'high';
  }>> {
    const data = await this.getHistoricalData(ctx, undefined, undefined, days);
    const values = data.map(d => d.value);

    const mean = values.reduce((s, v) => s + v, 0) / values.length;
    const variance = values.reduce((s, v) => s + (v - mean) ** 2, 0) / values.length;
    const stdDev = Math.sqrt(variance);

    const anomalies: any[] = [];

    for (const point of data) {
      const deviation = stdDev === 0 ? 0 : Math.abs(point.value - mean) / stdDev;

      if (deviation > 2) {
        const severity = deviation > 3 ? 'high' : deviation > 2.5 ? 'medium' : 'low';

        anomalies.push({
          date: point.date.toISOString().slice(0, 10),
          value: point.value,
          expected: Math.round(mean),
          deviation: Math.round(deviation * 100) / 100,
          severity,
        });

        if (severity === 'high') {
          await this.eventBus.publish(new SalesAnomalyDetectedEvent(
            point.date.toISOString().slice(0, 10),
            point.value,
            Math.round(mean),
            ctx.tenantId,
          ));
        }
      }
    }

    return anomalies;
  }

  // ============================================================
  // 13) پیش‌بینی تقاضای محصول
  // ============================================================
  async forecastProductDemand(productId: number, ctx: Context, periods = 14): Promise<{
    productId: number;
    forecast: Array<{ date: string; demand: number }>;
    confidence: number;
    recommendation: string;
  }> {
    const result = await this.forecast(ctx, { productId, periods, method: 'auto' });

    const totalDemand = result.summary.totalForecast;
    let recommendation: string;

    // دریافت موجودی فعلی
    const product = await this.prisma.product.findFirst({
      where: { id: productId, tenantId: ctx.tenantId },
      select: { stockQuantity: true, title: true },
    });

    if (!product) {
      throw new BusinessError('محصول یافت نشد', 'NOT_FOUND');
    }

    if (product.stockQuantity > totalDemand * 1.5) {
      recommendation = `موجودی کافی است (${product.stockQuantity} واحد در برابر تقاضای ${totalDemand} واحد)`;
    } else if (product.stockQuantity < totalDemand * 0.5) {
      recommendation = `تأمین اضطراری: موجودی فعلی ${product.stockQuantity}، تقاضای پیش‌بینی شده ${totalDemand}`;
    } else {
      recommendation = `برنامه‌ریزی برای تأمین: موجودی ${product.stockQuantity}، تقاضای ${totalDemand}`;
    }

    return {
      productId,
      forecast: result.forecast.map(f => ({ date: f.date, demand: f.value })),
      confidence: result.accuracy,
      recommendation,
    };
  }
}
