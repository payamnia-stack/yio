// ============================================================
// YIO V7 — Anomaly Detection Engine
// ============================================================
// تشخیص ناهنجاری و تقلب با:
//   - Statistical anomaly detection (Z-score, IQR)
//   - Fraud detection (unusual order patterns)
//   - Inventory anomaly detection
//   - Payment anomaly detection
//   - Login anomaly detection
// ============================================================

import { Context, BusinessError, OperationResult } from '@yio/core';
import { PrismaClient } from '@prisma/client';
import { IEventBus } from '@yio/core';
import { AnomalyDetectedEvent } from '../types';

export interface Anomaly {
  id: string;
  type: string;
  entityType: string;
  entityId: number;
  description: string;
  severity: 'low' | 'medium' | 'high';
  detectedAt: Date;
  data: Record<string, any>;
  suggestedAction: string;
}

export class AnomalyDetectionEngine {
  private recentAnomalies: Anomaly[] = [];
  private readonly MAX_RECENT = 100;

  constructor(
    private prisma: PrismaClient,
    private eventBus: IEventBus,
  ) {
    // Subscribe to events for real-time detection
    this.eventBus.subscribe('order.created', this.onOrderCreated.bind(this));
    this.eventBus.subscribe('user.registered', this.onUserRegistered.bind(this));
    this.eventBus.subscribe('inventory.stock_updated', this.onStockUpdated.bind(this));
  }

  // ============================================================
  // 1) تشخیص ناهنجاری سفارش (Fraud Detection)
  // ============================================================
  async detectOrderAnomaly(orderId: number, ctx: Context): Promise<Anomaly | null> {
    const order = await this.prisma.order.findFirst({
      where: { id: orderId, tenantId: ctx.tenantId },
      include: { items: true, user: true },
    });

    if (!order) return null;

    const anomalies: Anomaly[] = [];

    // 1. مبلغ غیرعادی بالا
    const avgOrderAmount = await this.getAverageOrderAmount(ctx);
    if (avgOrderAmount > 0 && order.finalAmount > avgOrderAmount * 5) {
      anomalies.push({
        id: `order_high_amount_${orderId}`,
        type: 'unusual_high_amount',
        entityType: 'order',
        entityId: orderId,
        description: `سفارش با مبلغ غیرعادی بالا: ${order.finalAmount.toLocaleString('fa-IR')} (میانگین: ${avgOrderAmount.toLocaleString('fa-IR')})`,
        severity: 'medium',
        detectedAt: new Date(),
        data: { amount: order.finalAmount, average: avgOrderAmount },
        suggestedAction: 'بررسی دستی قبل از تأیید',
      });
    }

    // 2. تعداد اقلام زیاد
    if (order.items.length > 20) {
      anomalies.push({
        id: `order_many_items_${orderId}`,
        type: 'unusual_many_items',
        entityType: 'order',
        entityId: orderId,
        description: `سفارش با تعداد اقلام زیاد: ${order.items.length}`,
        severity: 'low',
        detectedAt: new Date(),
        data: { itemCount: order.items.length },
        suggestedAction: 'بررسی موجودی',
      });
    }

    // 3. کاربر جدید با سفارش بزرگ
    if (order.user) {
      const userAgeDays = (Date.now() - order.user.createdAt.getTime()) / (1000 * 60 * 60 * 24);
      if (userAgeDays < 1 && order.finalAmount > 1000000) {
        anomalies.push({
          id: `new_user_big_order_${orderId}`,
          type: 'new_user_big_order',
          entityType: 'order',
          entityId: orderId,
          description: `کاربر جدید (کمتر از ۲۴ ساعت) با سفارش بزرگ`,
          severity: 'high',
          detectedAt: new Date(),
          data: { userAgeDays: Math.floor(userAgeDays), amount: order.finalAmount },
          suggestedAction: 'تأیید تلفنی قبل از ارسال',
        });
      }
    }

    // 4. آدرس ارسال متفاوت از آدرس کاربر
    // (در عمل باید با آدرس‌های قبلی کاربر مقایسه شود)

    // 5. سفارش‌های متعدد در زمان کوتاه
    if (order.userId) {
      const recentOrders = await this.prisma.order.count({
        where: {
          userId: order.userId,
          tenantId: ctx.tenantId,
          createdAt: { gte: new Date(Date.now() - 60 * 60 * 1000) }, // 1 ساعت
        },
      });
      if (recentOrders > 3) {
        anomalies.push({
          id: `multiple_orders_${orderId}`,
          type: 'multiple_quick_orders',
          entityType: 'order',
          entityId: orderId,
          description: `${recentOrders} سفارش در ۱ ساعت گذشته`,
          severity: 'high',
          detectedAt: new Date(),
          data: { recentOrderCount: recentOrders },
          suggestedAction: 'بررسی فعالیت مشکوک',
        });
      }
    }

    // ثبت و انتشار ناهنجاری‌ها
    for (const anomaly of anomalies) {
      this.recordAnomaly(anomaly, ctx);
    }

    return anomalies[0] || null;
  }

  // ============================================================
  // 2) تشخیص ناهنجاری کاربر
  // ============================================================
  async detectUserAnomaly(userId: number, ctx: Context): Promise<Anomaly[]> {
    const anomalies: Anomaly[] = [];

    const user = await this.prisma.user.findFirst({
      where: { id: userId, tenantId: ctx.tenantId },
      include: {
        sessions: { orderBy: { createdAt: 'desc' }, take: 10 },
        orders: { orderBy: { createdAt: 'desc' }, take: 5 },
      },
    });

    if (!user) return anomalies;

    // 1. ورود از IP های متعدد
    const uniqueIPs = new Set(user.sessions.map(s => s.ip).filter(Boolean));
    if (uniqueIPs.size > 5) {
      anomalies.push({
        id: `user_multiple_ips_${userId}`,
        type: 'multiple_ips',
        entityType: 'user',
        entityId: userId,
        description: `ورود از ${uniqueIPs.size} IP مختلف`,
        severity: 'medium',
        detectedAt: new Date(),
        data: { ipCount: uniqueIPs.size },
        suggestedAction: 'بررسی امنیتی',
      });
    }

    // 2. ورود از موقعیت‌های متفاوت
    const uniqueLocations = new Set(user.sessions.map(s => s.location).filter(Boolean));
    if (uniqueLocations.size > 3) {
      anomalies.push({
        id: `user_multiple_locations_${userId}`,
        type: 'multiple_locations',
        entityType: 'user',
        entityId: userId,
        description: `ورود از ${uniqueLocations.size} موقعیت مختلف`,
        severity: 'low',
        detectedAt: new Date(),
        data: { locationCount: uniqueLocations.size },
        suggestedAction: 'تأیید هویت دو مرحله‌ای',
      });
    }

    for (const anomaly of anomalies) {
      this.recordAnomaly(anomaly, ctx);
    }

    return anomalies;
  }

  // ============================================================
  // 3) تشخیص ناهنجاری موجودی
  // ============================================================
  async detectInventoryAnomaly(ctx: Context): Promise<Anomaly[]> {
    const anomalies: Anomaly[] = [];

    // 1. کاهش ناگهانی موجودی
    const products = await this.prisma.product.findMany({
      where: { tenantId: ctx.tenantId, inStock: true },
      select: { id: true, title: true, stockQuantity: true, price: true },
    });

    for (const product of products) {
      // موجودی منفی (خطای سیستم)
      if (product.stockQuantity < 0) {
        anomalies.push({
          id: `negative_stock_${product.id}`,
          type: 'negative_stock',
          entityType: 'product',
          entityId: product.id,
          description: `موجودی منفی برای محصول "${product.title}": ${product.stockQuantity}`,
          severity: 'high',
          detectedAt: new Date(),
          data: { stockQuantity: product.stockQuantity },
          suggestedAction: 'اصلاح فوری موجودی',
        });
      }

      // موجودی صفر اما inStock = true
      if (product.stockQuantity === 0) {
        anomalies.push({
          id: `zero_stock_instock_${product.id}`,
          type: 'zero_stock_instock',
          entityType: 'product',
          entityId: product.id,
          description: `محصول "${product.title}" موجودی صفر اما قابل فروش است`,
          severity: 'medium',
          detectedAt: new Date(),
          data: { stockQuantity: 0 },
          suggestedAction: 'به‌روزرسانی وضعیت inStock',
        });
      }
    }

    // 2. تراکنش‌های انبار غیرعادی
    const recentTransactions = await this.prisma.inventoryTransaction.findMany({
      where: {
        tenantId: ctx.tenantId,
        createdAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) },
      },
    });

    // گروه‌بندی بر اساس نوع و محاسبه Z-score
    const typeMap = new Map<string, number[]>();
    for (const tx of recentTransactions) {
      if (!typeMap.has(tx.type)) typeMap.set(tx.type, []);
      typeMap.get(tx.type)!.push(tx.quantity);
    }

    for (const [type, quantities] of typeMap) {
      if (quantities.length < 5) continue;

      const mean = quantities.reduce((s, q) => s + q, 0) / quantities.length;
      const stdDev = Math.sqrt(quantities.reduce((s, q) => s + (q - mean) ** 2, 0) / quantities.length);

      for (const tx of recentTransactions.filter(t => t.type === type)) {
        if (stdDev > 0) {
          const zScore = Math.abs(tx.quantity - mean) / stdDev;
          if (zScore > 3) {
            anomalies.push({
              id: `inventory_anomaly_${tx.id}`,
              type: 'unusual_inventory_transaction',
              entityType: 'inventory_transaction',
              entityId: tx.id,
              description: `تراکنش انبار غیرعادی: ${tx.quantity} (${type}) — Z-score: ${zScore.toFixed(2)}`,
              severity: zScore > 4 ? 'high' : 'medium',
              detectedAt: new Date(),
              data: { quantity: tx.quantity, type, zScore, mean, stdDev },
              suggestedAction: 'بررسی دستی',
            });
          }
        }
      }
    }

    for (const anomaly of anomalies) {
      this.recordAnomaly(anomaly, ctx);
    }

    return anomalies;
  }

  // ============================================================
  // 4) میانگین مبلغ سفارش
  // ============================================================
  private async getAverageOrderAmount(ctx: Context): Promise<number> {
    const result = await this.prisma.order.aggregate({
      where: {
        tenantId: ctx.tenantId,
        status: { not: 'cancelled' },
        createdAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
      },
      _avg: { finalAmount: true },
    });
    return result._avg.finalAmount || 0;
  }

  // ============================================================
  // 5) ثبت ناهنجاری
  // ============================================================
  private async recordAnomaly(anomaly: Anomaly, ctx: Context): Promise<void> {
    this.recentAnomalies.unshift(anomaly);
    if (this.recentAnomalies.length > this.MAX_RECENT) {
      this.recentAnomalies = this.recentAnomalies.slice(0, this.MAX_RECENT);
    }

    // ثبت در AuditLog
    await this.prisma.auditLog.create({
      data: {
        tenantId: ctx.tenantId,
        action: `ANOMALY_DETECTED:${anomaly.type}`,
        entityType: anomaly.entityType,
        entityId: anomaly.entityId,
        changes: JSON.stringify({
          description: anomaly.description,
          severity: anomaly.severity,
          data: anomaly.data,
          suggestedAction: anomaly.suggestedAction,
        }),
        timestamp: anomaly.detectedAt,
      },
    });

    // انتشار event
    await this.eventBus.publish(new AnomalyDetectedEvent(
      anomaly.type,
      anomaly.entityType,
      anomaly.entityId,
      anomaly.description,
      anomaly.severity,
      ctx.tenantId,
    ));
  }

  // ============================================================
  // 6) دریافت ناهنجاری‌های اخیر
  // ============================================================
  getRecentAnomalies(limit = 20, severity?: 'low' | 'medium' | 'high'): Anomaly[] {
    let result = this.recentAnomalies;
    if (severity) {
      result = result.filter(a => a.severity === severity);
    }
    return result.slice(0, limit);
  }

  // ============================================================
  // 7) Event Handlers
  // ============================================================
  private async onOrderCreated(event: any): Promise<void> {
    if (event.orderId && event.tenantId) {
      const ctx: Context = { tenantId: event.tenantId };
      await this.detectOrderAnomaly(event.orderId, ctx).catch(console.error);
    }
  }

  private async onUserRegistered(event: any): Promise<void> {
    if (event.userId && event.tenantId) {
      const ctx: Context = { tenantId: event.tenantId };
      // برای کاربران جدید، ناهنجاری خاصی نیست
    }
  }

  private async onStockUpdated(event: any): Promise<void> {
    if (event.tenantId) {
      const ctx: Context = { tenantId: event.tenantId };
      // در عمل باید batch اجرا شود
    }
  }

  // ============================================================
  // 8) اسکن کامل (برای cron job)
  // ============================================================
  async runFullScan(ctx: Context): Promise<OperationResult> {
    const inventoryAnomalies = await this.detectInventoryAnomaly(ctx);

    // اسکن سفارشات اخیر
    const recentOrders = await this.prisma.order.findMany({
      where: {
        tenantId: ctx.tenantId,
        createdAt: { gte: new Date(Date.now() - 60 * 60 * 1000) },
      },
      select: { id: true },
    });

    let orderAnomalyCount = 0;
    for (const order of recentOrders) {
      const anomaly = await this.detectOrderAnomaly(order.id, ctx);
      if (anomaly) orderAnomalyCount++;
    }

    return {
      success: true,
      message: `اسکن کامل انجام شد`,
      data: {
        inventoryAnomalies: inventoryAnomalies.length,
        orderAnomalies: orderAnomalyCount,
        totalScanned: recentOrders.length,
      },
    };
  }
}
