// ============================================================
// YIO V7 — Product Description Generator
// ============================================================
// تولید خودکار توضیحات محصول برای SEO با:
//   - قالب‌های از پیش تعریف‌شده بر اساس دسته‌بندی
//   - استخراج ویژگی‌ها از BOM و Routing
//   - تولید meta tags
//   - ترجمه خودکار
// ============================================================

import { Context, BusinessError, OperationResult } from '@yio/core';
import { PrismaClient } from '@prisma/client';
import { IEventBus } from '@yio/core';
import { ProductDescriptionGeneratedEvent } from '../types';

export interface ProductDescriptionInput {
  productId: number;
  tone?: 'formal' | 'casual' | 'playful' | 'technical';
  language?: 'fa' | 'en';
  includeFeatures?: boolean;
  includeBenefits?: boolean;
  includeSpecs?: boolean;
  seoOptimized?: boolean;
}

export interface GeneratedDescription {
  productId: number;
  title: string;
  shortDescription: string;
  fullDescription: string;
  features: string[];
  benefits: string[];
  metaTitle: string;
  metaDescription: string;
  keywords: string[];
  slug: string;
}

export class ProductDescriptionGenerator {
  private readonly CATEGORY_TEMPLATES: Record<string, {
    titlePattern: string;
    intro: string;
    features: string[];
    benefits: string[];
    keywords: string[];
  }> = {
    'wooden-toys': {
      titlePattern: '{title} — اسباب‌بازی چوبی دست‌ساز YIO',
      intro: 'اسباب‌بازی چوبی {title} با طراحی زیبا و کیفیت بالا، انتخابی عالی برای رشد خلاقیت کودکان است.',
      features: ['طراحی ایمن و بدون لبه‌های تیز', 'رنگ‌های غیرسمی و ضدآب', 'چوب طبیعی با کیفیت بالا'],
      benefits: ['توسعه مهارت‌های حرکتی ظریف', 'تحریک خلاقیت و تخیل', 'مقاوم و بادوام'],
      keywords: ['اسباب‌بازی چوبی', 'دست‌ساز', 'ایمن', 'کودک', 'یادگیری'],
    },
    'wooden-building-blocks': {
      titlePattern: '{title} — مایل سنگریزه‌ای چوبی',
      intro: 'مایل سنگریزه‌ای {title} برای ساخت سازه‌های متنوع و توسعه مهارت‌های مهندسی کودکان.',
      features: ['تعداد قطعات متنوع', 'نگهدارنده چوبی', 'قطعات صیقلی و ایمن'],
      benefits: ['توسعه تفکر فضایی', 'یادگیری رنگ‌ها و اشکال', 'همکاری گروهی'],
      keywords: ['مایل', 'سنگریزه‌ای', 'چوبی', 'ساخت', 'مهندسی'],
    },
    'wooden-puzzles': {
      titlePattern: '{title} — پازل چوبی آموزشی',
      intro: 'پازل چوبی {title} برای چالش ذهنی و تفکر منطقی کودکان طراحی شده است.',
      features: ['قطعات مقاوم و بادوام', 'تصاویر جذاب', 'سطح صاف و صیقلی'],
      benefits: ['توسعه حل مسئله', 'افزایش تمرکز', 'یادگیری حیوانات/اعداد'],
      keywords: ['پازل', 'چوبی', 'آموزشی', 'ذهنی', 'منطقی'],
    },
    'educational': {
      titlePattern: '{title} — وسیله آموزشی چوبی',
      intro: 'وسیله آموزشی {title} برای یادگیری تعاملی و لذت‌بخش کودکان.',
      features: ['طراحی آموزشی', 'مواد طبیعی', 'مناسب سن کودک'],
      benefits: ['یادگیری از طریق بازی', 'توسعه شناختی', 'تقویت حافظه'],
      keywords: ['آموزشی', 'یادگیری', 'چوبی', 'کودک', 'توسعه'],
    },
    'wooden-decor': {
      titlePattern: '{title} — دکوراسیون چوبی دست‌ساز',
      intro: 'دکوراسیون چوبی {title} برای زیباسازی فضای خانه یا محل کار.',
      features: ['طراحی منحصر به فرد', 'چوب طبیعی', 'پوشش ضدخش'],
      benefits: ['افزودن زیبایی به فضا', 'هیجان لمس طبیعت', 'هدیه‌ای خاص'],
      keywords: ['دکوراسیون', 'چوبی', 'دست‌ساز', 'هنر', 'داخلی'],
    },
  };

  constructor(
    private prisma: PrismaClient,
    private eventBus: IEventBus,
  ) {}

  // ============================================================
  // 1) تولید توضیحات محصول
  // ============================================================
  async generate(input: ProductDescriptionInput, ctx: Context): Promise<GeneratedDescription> {
    const {
      productId,
      tone = 'casual',
      language = 'fa',
      includeFeatures = true,
      includeBenefits = true,
      includeSpecs = true,
      seoOptimized = true,
    } = input;

    // 1. دریافت محصول با اطلاعات کامل
    const product = await this.prisma.product.findFirst({
      where: { id: productId, tenantId: ctx.tenantId },
      include: {
        bom: { include: { items: true } },
        routings: { include: { steps: true } },
        productColors: true,
        productVariants: true,
        costFormula: true,
      },
    });

    if (!product) {
      throw new BusinessError('محصول یافت نشد', 'NOT_FOUND');
    }

    // 2. انتخاب قالب بر اساس دسته‌بندی
    const template = this.CATEGORY_TEMPLATES[product.category] || this.CATEGORY_TEMPLATES['wooden-toys'];

    // 3. تولید عنوان
    const title = template.titlePattern.replace('{title}', product.title);

    // 4. تولید توضیح کوتاه
    const shortDescription = this.generateShortDescription(product, template, tone);

    // 5. تولید توضیح کامل
    const fullDescription = this.generateFullDescription(product, template, {
      tone,
      includeFeatures,
      includeBenefits,
      includeSpecs,
    });

    // 6. تولید ویژگی‌ها
    const features = this.generateFeatures(product, template);

    // 7. تولید مزایا
    const benefits = template.benefits.slice();

    // 8. تولید meta tags
    const metaTitle = seoOptimized ? this.generateMetaTitle(product, template) : title;
    const metaDescription = seoOptimized ? this.generateMetaDescription(product, template) : shortDescription;
    const keywords = seoOptimized ? this.generateKeywords(product, template) : [];

    // 9. تولید slug
    const slug = this.generateSlug(product.title);

    const result: GeneratedDescription = {
      productId,
      title,
      shortDescription,
      fullDescription,
      features,
      benefits,
      metaTitle,
      metaDescription,
      keywords,
      slug,
    };

    // Publish event
    await this.eventBus.publish(new ProductDescriptionGeneratedEvent(
      productId,
      result.title,
      ctx.tenantId,
    ));

    return result;
  }

  // ============================================================
  // 2) تولید توضیح کوتاه
  // ============================================================
  private generateShortDescription(product: any, template: any, tone: string): string {
    let intro = template.intro.replace('{title}', product.title);

    // اضافه کردن ویژگی‌های کلیدی
    const keyFeatures: string[] = [];

    if (product.woodType) {
      keyFeatures.push(`چوب ${product.woodType}`);
    }

    if (product.productColors?.length > 0) {
      const colors = product.productColors.map((c: any) => c.name).slice(0, 3).join('، ');
      keyFeatures.push(`رنگ‌های ${colors}`);
    }

    if (keyFeatures.length > 0) {
      intro += ` با ${keyFeatures.join(' و ')}.`;
    }

    // تنظیم لحن
    if (tone === 'playful') {
      intro = intro.replace('است.', 'است! 🎉');
    } else if (tone === 'formal') {
      intro = intro.replace('!', '.');
    }

    return intro;
  }

  // ============================================================
  // 3) تولید توضیح کامل
  // ============================================================
  private generateFullDescription(
    product: any,
    template: any,
    options: { tone: string; includeFeatures: boolean; includeBenefits: boolean; includeSpecs: boolean },
  ): string {
    const sections: string[] = [];

    // مقدمه
    sections.push(template.intro.replace('{title}', product.title));

    // ویژگی‌ها
    if (options.includeFeatures) {
      const features = this.generateFeatures(product, template);
      sections.push('\nویژگی‌ها:\n' + features.map((f: string) => `✅ ${f}`).join('\n'));
    }

    // مزایا
    if (options.includeBenefits) {
      sections.push('\nمزایا:\n' + template.benefits.map((b: string) => `🎯 ${b}`).join('\n'));
    }

    // مشخصات فنی
    if (options.includeSpecs) {
      const specs: string[] = [];

      if (product.woodType) specs.push(`نوع چوب: ${product.woodType}`);
      if (product.brand) specs.push(`برند: ${product.brand}`);
      if (product.category) specs.push(`دسته‌بندی: ${product.category}`);
      specs.push(`موجودی: ${product.stockQuantity} عدد`);
      specs.push(`قیمت: ${product.price.toLocaleString('fa-IR')} ریال`);

      if (product.productVariants?.length > 0) {
        specs.push(`واریانت‌ها: ${product.productVariants.length} مدل`);
      }

      if (product.bom?.items?.length > 0) {
        const materials = product.bom.items.map((i: any) => i.materialName).slice(0, 5).join('، ');
        specs.push(`مواد تشکیل‌دهنده: ${materials}`);
      }

      sections.push('\nمشخصات فنی:\n' + specs.map(s => `📋 ${s}`).join('\n'));
    }

    // فراخوان به اقدام
    if (options.tone === 'playful') {
      sections.push('\n🛒 همین حالا سفارش بده و از بازی لذت ببر!');
    } else {
      sections.push('\nبرای سفارش، محصول را به سبد خرید اضافه کنید.');
    }

    return sections.join('\n');
  }

  // ============================================================
  // 4) تولید ویژگی‌ها
  // ============================================================
  private generateFeatures(product: any, template: any): string[] {
    const features: string[] = [...template.features];

    // اضافه کردن ویژگی‌های اختصاصی محصول
    if (product.woodType) {
      features.push(`ساخت شده از چوب ${product.woodType}`);
    }

    if (product.fastDelivery) {
      features.push('ارسال سریع');
    }

    if (product.isSpecial) {
      features.push('محصول ویژه');
    }

    if (product.productColors?.length > 0) {
      features.push(`در ${product.productColors.length} رنگ متنوع`);
    }

    if (product.bom?.items?.length > 0) {
      features.push(`${product.bom.items.length} ماده اولیه با کیفیت`);
    }

    if (product.routings?.[0]?.steps?.length > 0) {
      features.push(`تولید در ${product.routings[0].steps.length} مرحله`);
    }

    return features.slice(0, 8); // حداکثر ۸ ویژگی
  }

  // ============================================================
  // 5) تولید Meta Title
  // ============================================================
  private generateMetaTitle(product: any, template: any): string {
    let title = `${product.title} | ${product.brand} YIO`;
    if (product.category) {
      title += ` | ${product.category}`;
    }
    return title.slice(0, 60); // حداکثر ۶۰ کاراکتر
  }

  // ============================================================
  // 6) تولید Meta Description
  // ============================================================
  private generateMetaDescription(product: any, template: any): string {
    let desc = `خرید ${product.title} با قیمت ${product.price.toLocaleString('fa-IR')} ریال. `;
    desc += template.intro.replace('{title}', product.title).slice(0, 100);
    desc += ' ارسال سریع، ضمانت کیفیت.';

    return desc.slice(0, 160); // حداکثر ۱۶۰ کاراکتر
  }

  // ============================================================
  // 7) تولید Keywords
  // ============================================================
  private generateKeywords(product: any, template: any): string[] {
    const keywords = new Set<string>(template.keywords);

    keywords.add(product.title);
    keywords.add(product.brand);
    if (product.woodType) keywords.add(`چوب ${product.woodType}`);
    if (product.category) keywords.add(product.category);

    // اضافه کردن کلمات عنوان
    const titleWords = product.title.split(/\s+/).filter((w: string) => w.length > 2);
    titleWords.forEach((w: string) => keywords.add(w));

    return Array.from(keywords).slice(0, 15);
  }

  // ============================================================
  // 8) تولید Slug
  // ============================================================
  private generateSlug(title: string): string {
    return title
      .toLowerCase()
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .slice(0, 50);
  }

  // ============================================================
  // 9) به‌روزرسانی خودکار محصول
  // ============================================================
  async updateProductDescription(productId: number, ctx: Context): Promise<OperationResult> {
    const generated = await this.generate({ productId }, ctx);

    await this.prisma.product.update({
      where: { id: productId },
      data: {
        description: generated.fullDescription,
      },
    });

    return {
      success: true,
      message: 'توضیحات محصول به‌روزرسانی شد',
      data: generated,
    };
  }

  // ============================================================
  // 10) تولید دسته‌جمعی
  // ============================================================
  async generateBulk(ctx: Context, category?: string): Promise<OperationResult> {
    const where: any = { tenantId: ctx.tenantId, isPublished: true };
    if (category) where.category = category;

    const products = await this.prisma.product.findMany({
      where,
      select: { id: true },
    });

    let updated = 0;
    for (const product of products) {
      try {
        await this.updateProductDescription(product.id, ctx);
        updated++;
      } catch (e) {
        console.error(`Failed to update product ${product.id}:`, e);
      }
    }

    return {
      success: true,
      message: `${updated} از ${products.length} محصول به‌روزرسانی شد`,
      data: { updated, total: products.length },
    };
  }
}
