// ============================================================
// YIO V7 — Smart Chat Engine
// ============================================================
// چت‌بات هوشمند پشتیبانی مشتری با:
//   - Intent detection
//   - Context management
//   - Knowledge base search
//   - Order/Product queries
//   - Handoff to human agent
//   - Multi-language support (Persian primary)
// ============================================================

import { Context, BusinessError, OperationResult } from '@yio/core';
import { PrismaClient } from '@prisma/client';
import { IEventBus } from '@yio/core';
import { ChatMessageSentEvent, ChatHandoffEvent } from '../types';

// ===== Types =====
export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  metadata?: Record<string, any>;
}

export interface ChatSession {
  id: string;
  userId?: number;
  tenantId: number;
  messages: ChatMessage[];
  context: ChatContext;
  status: 'active' | 'handoff' | 'closed';
  createdAt: Date;
  updatedAt: Date;
}

export interface ChatContext {
  intent?: string;
  currentTopic?: string;
  mentionedProducts: number[];
  mentionedOrders: number[];
  userPhone?: string;
  userName?: string;
  awaitingHumanAgent: boolean;
  satisfactionScore?: number;
}

export interface ChatResponse {
  message: string;
  intent: string;
  confidence: number;
  actions?: Array<{
    type: 'show_product' | 'show_order' | 'show_category' | 'handoff' | 'show_faq';
    data: any;
  }>;
  quickReplies?: string[];
  shouldHandoff: boolean;
}

// ===== Intent Definitions =====
export const INTENTS = {
  GREETING: 'greeting',
  ORDER_STATUS: 'order_status',
  PRODUCT_SEARCH: 'product_search',
  PRODUCT_INFO: 'product_info',
  SHIPPING_INFO: 'shipping_info',
  RETURN_REQUEST: 'return_request',
  PAYMENT_HELP: 'payment_help',
  COMPLAINT: 'complaint',
  FAQ: 'faq',
  HUMAN_AGENT: 'human_agent',
  GOODBYE: 'goodbye',
  UNKNOWN: 'unknown',
} as const;

const INTENT_PATTERNS: Record<string, string[]> = {
  [INTENTS.GREETING]: ['سلام', 'درود', 'hi', 'hello', 'hey', 'خوبی', 'چطوری'],
  [INTENTS.ORDER_STATUS]: ['سفارش', 'وضعیت سفارش', 'کجاست سفارش', 'order status', 'tracking', 'پیگیری', 'ارسال'],
  [INTENTS.PRODUCT_SEARCH]: ['میخوام', 'می‌خوام', 'دنبال', 'looking for', 'search', 'جستجو', 'محصول', 'قیمت'],
  [INTENTS.PRODUCT_INFO]: ['جزئیات', 'مشخصات', 'توضیحات', 'product info', 'details', 'جنس', 'ماده'],
  [INTENTS.SHIPPING_INFO]: ['ارسال', 'حمل', 'shipping', 'delivery', 'هزینه ارسال', 'زمان ارسال'],
  [INTENTS.RETURN_REQUEST]: ['مرجوعی', 'برگردونم', 'return', 'refund', 'پس گرفتن', 'تعویض'],
  [INTENTS.PAYMENT_HELP]: ['پرداخت', 'payment', 'پول', 'فکتور', 'صورتحساب', 'اقساط'],
  [INTENTS.COMPLAINT]: ['شکایت', 'ناراضی', 'complaint', 'مشکل', 'خراب', 'بد', 'عصبانی'],
  [INTENTS.FAQ]: ['سوال', 'question', 'how', 'چطور', 'چگونه', 'آیا', 'چه'],
  [INTENTS.HUMAN_AGENT]: ['اپراتور', 'انسان', 'human', 'agent', 'پشتیبان', 'واقعی'],
  [INTENTS.GOODBYE]: ['خداحافظ', 'bye', 'goodbye', 'مرسی', 'ممنون', 'تشکر', 'خدانگهدار'],
};

export class SmartChatEngine {
  private sessions: Map<string, ChatSession> = new Map();
  private knowledgeBase: Map<string, string> = new Map();
  private readonly SESSION_TTL = 30 * 60 * 1000; // 30 minutes

  constructor(
    private prisma: PrismaClient,
    private eventBus: IEventBus,
  ) {
    this.initializeKnowledgeBase();
    this.startCleanupInterval();
  }

  // ============================================================
  // 1) شروع گفتگو
  // ============================================================
  async startSession(ctx: Context, userId?: number): Promise<ChatSession> {
    const sessionId = `chat_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    const session: ChatSession = {
      id: sessionId,
      userId,
      tenantId: ctx.tenantId,
      messages: [],
      context: {
        mentionedProducts: [],
        mentionedOrders: [],
        awaitingHumanAgent: false,
      },
      status: 'active',
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // پیام خوش‌آمدگویی
    const greeting: ChatMessage = {
      role: 'assistant',
      content: 'سلام! به فروشگاه YIO خوش آمدید. چطور می‌توانم کمکتان کنم؟',
      timestamp: new Date(),
    };
    session.messages.push(greeting);

    this.sessions.set(sessionId, session);
    return session;
  }

  // ============================================================
  // 2) ارسال پیام و دریافت پاسخ
  // ============================================================
  async sendMessage(sessionId: string, userMessage: string, ctx: Context): Promise<ChatResponse> {
    const session = this.sessions.get(sessionId);
    if (!session) {
      throw new BusinessError('جلسه چت یافت نشد', 'NOT_FOUND', undefined, 404);
    }

    if (session.status === 'closed') {
      throw new BusinessError('این جلسه چت بسته شده است', 'SESSION_CLOSED');
    }

    // اگر در حال انتقال به اپراتور است
    if (session.context.awaitingHumanAgent) {
      return {
        message: 'پیام شما در صف انتظار اپراتور است. لطفاً کمی صبر کنید.',
        intent: INTENTS.HUMAN_AGENT,
        confidence: 1,
        shouldHandoff: true,
      };
    }

    // ذخیره پیام کاربر
    session.messages.push({
      role: 'user',
      content: userMessage,
      timestamp: new Date(),
    });

    // تشخیص intent
    const intent = this.detectIntent(userMessage);

    // تولید پاسخ
    const response = await this.generateResponse(session, intent, userMessage, ctx);

    // ذخیره پاسخ
    session.messages.push({
      role: 'assistant',
      content: response.message,
      timestamp: new Date(),
      metadata: { intent: response.intent, confidence: response.confidence },
    });

    // به‌روزرسانی context
    session.context.intent = response.intent;
    session.updatedAt = new Date();

    // Publish event
    await this.eventBus.publish(new ChatMessageSentEvent(
      sessionId,
      userMessage,
      response.message,
      ctx.tenantId,
    ));

    return response;
  }

  // ============================================================
  // 3) تشخیص Intent
  // ============================================================
  private detectIntent(message: string): { intent: string; confidence: number } {
    const normalized = message.toLowerCase().trim();

    let bestIntent: string = INTENTS.UNKNOWN;
    let bestScore = 0;

    for (const [intent, patterns] of Object.entries(INTENT_PATTERNS)) {
      let score = 0;
      for (const pattern of patterns) {
        if (normalized.includes(pattern.toLowerCase())) {
          score += pattern.length / normalized.length;
        }
      }
      if (score > bestScore) {
        bestScore = score;
        bestIntent = intent;
      }
    }

    const confidence = Math.min(1, bestScore);

    return { intent: bestIntent, confidence };
  }

  // ============================================================
  // 4) تولید پاسخ
  // ============================================================
  private async generateResponse(
    session: ChatSession,
    intentResult: { intent: string; confidence: number },
    userMessage: string,
    ctx: Context,
  ): Promise<ChatResponse> {
    const { intent, confidence } = intentResult;

    // اگر اطمینان کم است
    if (confidence < 0.1) {
      return {
        message: 'متوجه نشدم. می‌توانید بیشتر توضیح دهید؟ یا برای صحبت با اپراتور انسانی بگویید «اپراتور».',
        intent: INTENTS.UNKNOWN,
        confidence,
        quickReplies: ['وضعیت سفارش', 'جستجوی محصول', 'صحبت با اپراتور'],
        shouldHandoff: false,
      };
    }

    switch (intent) {
      case INTENTS.GREETING:
        return {
          message: 'سلام! خوشحال شوم می‌توانم کمکتان کنم. چه چیزی نیاز دارید؟',
          intent,
          confidence,
          quickReplies: ['وضعیت سفارش', 'جستجوی محصول', 'هزینه ارسال'],
          shouldHandoff: false,
        };

      case INTENTS.GOODBYE:
        return {
          message: 'خدانگهدار! امیدوارم دوباره بیایید.',
          intent,
          confidence,
          shouldHandoff: false,
        };

      case INTENTS.ORDER_STATUS:
        return await this.handleOrderStatus(session, userMessage, ctx);

      case INTENTS.PRODUCT_SEARCH:
        return await this.handleProductSearch(userMessage, ctx);

      case INTENTS.PRODUCT_INFO:
        return await this.handleProductInfo(session, userMessage, ctx);

      case INTENTS.SHIPPING_INFO:
        return await this.handleShippingInfo(ctx);

      case INTENTS.RETURN_REQUEST:
        return {
          message: 'برای درخواست مرجوعی، لطفاً شماره سفارش را وارد کنید. مهلت مرجوعی ۷ روز است.',
          intent,
          confidence,
          quickReplies: ['شماره سفارشم یادم نیست', 'صحبت با اپراتور'],
          shouldHandoff: false,
        };

      case INTENTS.PAYMENT_HELP:
        return {
          message: 'روش‌های پرداخت:\n• پرداخت در محل (COD)\n• کارت به کارت\n• درگاه آنلاین (زرین‌پال)\n\nکدام روش را ترجیح می‌دهید؟',
          intent,
          confidence,
          quickReplies: ['پرداخت در محل', 'کارت به کارت', 'درگاه آنلاین'],
          shouldHandoff: false,
        };

      case INTENTS.COMPLAINT:
        session.context.awaitingHumanAgent = true;
        await this.eventBus.publish(new ChatHandoffEvent(session.id, session.userId, 'complaint', ctx.tenantId));
        return {
          message: 'از نارضایتی شما متأسفم. در حال اتصال شما به اپراتور انسانی هستم. لطفاً کمی صبر کنید.',
          intent,
          confidence,
          shouldHandoff: true,
          actions: [{ type: 'handoff', data: { reason: 'complaint' } }],
        };

      case INTENTS.FAQ:
        return await this.handleFAQ(userMessage);

      case INTENTS.HUMAN_AGENT:
        session.context.awaitingHumanAgent = true;
        await this.eventBus.publish(new ChatHandoffEvent(session.id, session.userId, 'user_request', ctx.tenantId));
        return {
          message: 'در حال اتصال شما به اپراتور انسانی. لطفاً صبر کنید...',
          intent,
          confidence,
          shouldHandoff: true,
          actions: [{ type: 'handoff', data: { reason: 'user_request' } }],
        };

      default:
        return {
          message: 'ببخشید متوجه نشدم. می‌توانید سوالتان را به شکل دیگری بپرسید؟',
          intent: INTENTS.UNKNOWN,
          confidence,
          quickReplies: ['وضعیت سفارش', 'جستجوی محصول', 'صحبت با اپراتور'],
          shouldHandoff: false,
        };
    }
  }

  // ============================================================
  // 5) Handler: وضعیت سفارش
  // ============================================================
  private async handleOrderStatus(session: ChatSession, userMessage: string, ctx: Context): Promise<ChatResponse> {
    if (!session.userId) {
      return {
        message: 'برای بررسی وضعیت سفارش، لطفاً وارد حساب کاربری خود شوید.',
        intent: INTENTS.ORDER_STATUS,
        confidence: 0.9,
        actions: [{ type: 'handoff', data: { reason: 'auth_required' } }],
        shouldHandoff: false,
      };
    }

    const orders = await this.prisma.order.findMany({
      where: { tenantId: ctx.tenantId, userId: session.userId },
      include: { items: true },
      orderBy: { createdAt: 'desc' },
      take: 3,
    });

    if (orders.length === 0) {
      return {
        message: 'شما سفارشی در سیستم ندارید.',
        intent: INTENTS.ORDER_STATUS,
        confidence: 0.9,
        shouldHandoff: false,
      };
    }

    const order = orders[0];
    const statusMap: Record<string, string> = {
      pending: 'در انتظار تأیید',
      confirmed: 'تأیید شده',
      shipping: 'در حال ارسال',
      delivered: 'تحویل داده شده',
      cancelled: 'لغو شده',
    };

    return {
      message: `آخرین سفارش شما:\n\n📦 سفارش #${order.orderNumber}\n📅 تاریخ: ${order.createdAt.toLocaleDateString('fa-IR')}\n💰 مبلغ: ${order.finalAmount.toLocaleString('fa-IR')} ریال\n✅ وضعیت: ${statusMap[order.status] || order.status}${order.trackingCode ? `\n🚚 کد رهگیری: ${order.trackingCode}` : ''}`,
      intent: INTENTS.ORDER_STATUS,
      confidence: 0.95,
      actions: [{ type: 'show_order', data: { orderId: order.id } }],
      quickReplies: ['سفارش‌های دیگر', 'صحبت با اپراتور'],
      shouldHandoff: false,
    };
  }

  // ============================================================
  // 6) Handler: جستجوی محصول
  // ============================================================
  private async handleProductSearch(userMessage: string, ctx: Context): Promise<ChatResponse> {
    // استخراج کلمات کلیدی
    const keywords = userMessage
      .replace(/^(میخوام|می‌خوام|دنبال|looking for|search)/i, '')
      .trim();

    if (!keywords) {
      return {
        message: 'چه محصولی را جستجو کنم؟ مثلاً بگویید «مایل چوبی می‌خوام».',
        intent: INTENTS.PRODUCT_SEARCH,
        confidence: 0.7,
        shouldHandoff: false,
      };
    }

    const products = await this.prisma.product.findMany({
      where: {
        tenantId: ctx.tenantId,
        isPublished: true,
        OR: [
          { title: { contains: keywords, mode: 'insensitive' } },
          { category: { contains: keywords, mode: 'insensitive' } },
          { woodType: { contains: keywords, mode: 'insensitive' } },
        ],
      },
      take: 5,
    });

    if (products.length === 0) {
      return {
        message: `محصولی با کلمه «${keywords}» یافت نشد. می‌توانید کلمه دیگری امتحان کنید.`,
        intent: INTENTS.PRODUCT_SEARCH,
        confidence: 0.8,
        shouldHandoff: false,
      };
    }

    const productLines = products.map(p =>
      `• ${p.title} — ${p.price.toLocaleString('fa-IR')} ریال`
    ).join('\n');

    return {
      message: `این محصولات را پیدا کردم:\n\n${productLines}\n\nکدام را می‌خواهید؟`,
      intent: INTENTS.PRODUCT_SEARCH,
      confidence: 0.9,
      actions: products.map(p => ({ type: 'show_product', data: { productId: p.id } })),
      quickReplies: products.slice(0, 3).map(p => p.title.slice(0, 30)),
      shouldHandoff: false,
    };
  }

  // ============================================================
  // 7) Handler: اطلاعات محصول
  // ============================================================
  private async handleProductInfo(session: ChatSession, userMessage: string, ctx: Context): Promise<ChatResponse> {
    if (session.context.mentionedProducts.length === 0) {
      return {
        message: 'کدام محصول را می‌خواهید؟ لطفاً نام یا کد محصول را بگویید.',
        intent: INTENTS.PRODUCT_INFO,
        confidence: 0.7,
        shouldHandoff: false,
      };
    }

    const productId = session.context.mentionedProducts[session.context.mentionedProducts.length - 1];
    const product = await this.prisma.product.findFirst({
      where: { id: productId, tenantId: ctx.tenantId },
    });

    if (!product) {
      return {
        message: 'محصول یافت نشد.',
        intent: INTENTS.PRODUCT_INFO,
        confidence: 0.8,
        shouldHandoff: false,
      };
    }

    return {
      message: `📦 ${product.title}\n\n💰 قیمت: ${product.price.toLocaleString('fa-IR')} ریال\n📦 موجودی: ${product.stockQuantity} عدد\n⭐ امتیاز: ${product.rating}/۵\n\n${product.description || ''}`,
      intent: INTENTS.PRODUCT_INFO,
      confidence: 0.95,
      actions: [{ type: 'show_product', data: { productId: product.id } }],
      quickReplies: ['افزودن به سبد', 'محصولات مشابه', 'صحبت با اپراتور'],
      shouldHandoff: false,
    };
  }

  // ============================================================
  // 8) Handler: اطلاعات ارسال
  // ============================================================
  private async handleShippingInfo(ctx: Context): Promise<ChatResponse> {
    const thresholdSetting = await this.prisma.siteSetting.findUnique({
      where: { tenantId_key: { tenantId: ctx.tenantId, key: 'free_shipping_threshold' } },
    });
    const costSetting = await this.prisma.siteSetting.findUnique({
      where: { tenantId_key: { tenantId: ctx.tenantId, key: 'default_shipping_cost' } },
    });

    const threshold = thresholdSetting ? parseInt(thresholdSetting.value, 10) : 500000;
    const cost = costSetting ? parseInt(costSetting.value, 10) : 89000;

    return {
      message: `🚚 اطلاعات ارسال:\n\n• تهران: ۱-۲ روز کاری\n• شهرستان: ۳-۵ روز کاری\n• هزینه ارسال: ${cost.toLocaleString('fa-IR')} ریال\n• ارسال رایگان برای سفارش‌های بالای ${threshold.toLocaleString('fa-IR')} ریال`,
      intent: INTENTS.SHIPPING_INFO,
      confidence: 0.95,
      quickReplies: ['پیگیری سفارش', 'هزینه ارسال شهرستان', 'صحبت با اپراتور'],
      shouldHandoff: false,
    };
  }

  // ============================================================
  // 9) Handler: سوالات متداول
  // ============================================================
  private async handleFAQ(userMessage: string): Promise<ChatResponse> {
    // جستجو در knowledge base
    let bestMatch: { question: string; answer: string; score: number } | null = null;

    for (const [question, answer] of this.knowledgeBase) {
      const score = this.calculateSimilarity(userMessage, question);
      if (!bestMatch || score > bestMatch.score) {
        bestMatch = { question, answer, score };
      }
    }

    if (bestMatch && bestMatch.score > 0.3) {
      return {
        message: bestMatch.answer,
        intent: INTENTS.FAQ,
        confidence: bestMatch.score,
        quickReplies: ['سوال دیگری دارم', 'صحبت با اپراتور'],
        shouldHandoff: false,
      };
    }

    // جستجو در FAQ دیتابیس
    const faqs = await this.prisma.fAQ.findMany({
      where: { isActive: true },
      take: 20,
    });

    for (const faq of faqs) {
      const score = this.calculateSimilarity(userMessage, faq.question);
      if (!bestMatch || score > bestMatch.score) {
        bestMatch = { question: faq.question, answer: faq.answer, score };
      }
    }

    if (bestMatch && bestMatch.score > 0.3) {
      return {
        message: bestMatch.answer,
        intent: INTENTS.FAQ,
        confidence: bestMatch.score,
        quickReplies: ['سوال دیگری دارم', 'صحبت با اپراتور'],
        shouldHandoff: false,
      };
    }

    return {
      message: 'سوال شما را در پایگاه دانش پیدا نکردم. می‌توانید با اپراتور صحبت کنید.',
      intent: INTENTS.FAQ,
      confidence: 0.5,
      quickReplies: ['صحبت با اپراتور', 'سوال دیگری'],
      shouldHandoff: false,
    };
  }

  // ============================================================
  // 10) محاسبه شباهت (ساده)
  // ============================================================
  private calculateSimilarity(s1: string, s2: string): number {
    const words1 = s1.toLowerCase().split(/\s+/);
    const words2 = s2.toLowerCase().split(/\s+/);
    const intersection = words1.filter(w => words2.includes(w));
    return intersection.length / Math.max(words1.length, words2.length);
  }

  // ============================================================
  // 11) Initialize Knowledge Base
  // ============================================================
  private initializeKnowledgeBase(): void {
    const kb: Record<string, string> = {
      'ضمانت': 'تمام محصولات چوبی YIO دارای ضمانت ۶ ماهه تعویض هستند.',
      'بازگشت': 'شما ۷ روز فرصت دارید محصول را مرجوع کنید.',
      'پرداخت اقساطی': 'پرداخت اقساطی برای سفارش‌های بالای ۲ میلیون ریال ممکن است.',
      'تخفیف عمده': 'مشتریان عمده (level 2+) از تخفیف ویژه برخوردار می‌شوند.',
      'زمان ارسال': 'در تهران ۱-۲ روز کاری و در شهرستان‌ها ۳-۵ روز کاری.',
      'بسته‌بندی': 'محصولات در بسته‌بندی مقاومی ارسال می‌شوند تا آسیب نبینند.',
      'مشاوره': 'برای مشاوره می‌توانید با ۰۲۱-۰۰۰۰۰۰۰۰ تماس بگیرید.',
    };

    for (const [question, answer] of Object.entries(kb)) {
      this.knowledgeBase.set(question, answer);
    }
  }

  // ============================================================
  // 12) Cleanup expired sessions
  // ============================================================
  private startCleanupInterval(): void {
    setInterval(() => {
      const now = Date.now();
      for (const [id, session] of this.sessions) {
        if (now - session.updatedAt.getTime() > this.SESSION_TTL) {
          this.sessions.delete(id);
        }
      }
    }, 5 * 60 * 1000); // هر ۵ دقیقه
  }

  // ============================================================
  // 13) دریافت تاریخچه گفتگو
  // ============================================================
  getSession(sessionId: string): ChatSession | null {
    return this.sessions.get(sessionId) || null;
  }

  // ============================================================
  // 14) بستن جلسه
  // ============================================================
  async closeSession(sessionId: string, satisfactionScore?: number): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (session) {
      session.status = 'closed';
      session.context.satisfactionScore = satisfactionScore;
      // در عمل باید در دیتابیس ذخیره شود
    }
  }

  // ============================================================
  // 15) دریافت آمار چت
  // ============================================================
  getStats(): {
    activeSessions: number;
    totalSessions: number;
    averageMessages: number;
    handoffRate: number;
  } {
    const sessions = Array.from(this.sessions.values());
    const activeSessions = sessions.filter(s => s.status === 'active').length;
    const handoffSessions = sessions.filter(s => s.context.awaitingHumanAgent).length;
    const totalMessages = sessions.reduce((s, sess) => s + sess.messages.length, 0);

    return {
      activeSessions,
      totalSessions: sessions.length,
      averageMessages: sessions.length > 0 ? Math.round(totalMessages / sessions.length) : 0,
      handoffRate: sessions.length > 0 ? Math.round((handoffSessions / sessions.length) * 100) : 0,
    };
  }
}
