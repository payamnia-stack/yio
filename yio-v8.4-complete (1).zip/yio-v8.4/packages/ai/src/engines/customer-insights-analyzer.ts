// ============================================================
// YIO V7 — Customer Insights Analyzer
// ============================================================
// تحلیل رفتار مشتریان با:
//   - RFM Analysis (Recency, Frequency, Monetary)
//   - Customer Segmentation
//   - Churn Prediction
//   - Customer Lifetime Value (LTV)
//   - Recommendation engine
// ============================================================

import { Context, BusinessError, OperationResult } from '@yio/core';
import { PrismaClient } from '@prisma/client';
import { IEventBus } from '@yio/core';
import { CustomerSegmentUpdatedEvent, ChurnRiskDetectedEvent } from '../types';

// ===== Types =====
export interface CustomerInsights {
  totalCustomers: number;
  activeCustomers: number;
  newCustomersThisMonth: number;
  averageLTV: number;
  churnRate: number;
  segments: CustomerSegment[];
  topCustomers: Array<{
    userId: number;
    name: string;
    phone: string;
    ltv: number;
    orders: number;
    lastOrder: Date;
    segment: string;
  }>;
  recommendations: string[];
}

export interface CustomerSegment {
  name: string;
  description: string;
  count: number;
  percentage: number;
  averageLTV: number;
  averageOrders: number;
  color: string;
}

export interface CustomerProfile {
  userId: number;
  name: string;
  phone: string;
  segment: string;
  rfmScore: { recency: number; frequency: number; monetary: number; total: number };
  ltv: number;
  churnRisk: 'low' | 'medium' | 'high';
  churnProbability: number;
  recommendations: string[];
  nextBestAction: string;
}

export class CustomerInsightsAnalyzer {
  constructor(
    private prisma: PrismaClient,
    private eventBus: IEventBus,
  ) {}

  // ============================================================
  // 1) تحلیل کامل مشتریان
  // ============================================================
  async analyze(ctx: Context): Promise<CustomerInsights> {
    // 1. دریافت همه کاربران (مشتریان)
    const users = await this.prisma.user.findMany({
      where: { tenantId: ctx.tenantId, level: 0 },
      select: {
        id: true,
        name: true,
        phone: true,
        createdAt: true,
        orders: {
          where: { status: { not: 'cancelled' } },
          select: {
            id: true,
            finalAmount: true,
            createdAt: true,
          },
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (users.length === 0) {
      return {
        totalCustomers: 0,
        activeCustomers: 0,
        newCustomersThisMonth: 0,
        averageLTV: 0,
        churnRate: 0,
        segments: [],
        topCustomers: [],
        recommendations: ['هنوز مشتری‌ای ثبت نشده است'],
      };
    }

    // 2. محاسبه RFM برای هر مشتری
    const rfmScores = users.map(user => this.calculateRFM(user));

    // 3. دسته‌بندی
    const segments = this.segmentCustomers(users, rfmScores);

    // 4. محاسبه LTV
    const ltvScores = users.map(user => this.calculateLTV(user));

    // 5. محاسبه Churn Rate
    const churnRate = this.calculateChurnRate(users);

    // 6. مشتریان برتر
    const topCustomers = this.getTopCustomers(users, rfmScores, ltvScores, 10);

    // 7. توصیه‌ها
    const recommendations = this.generateRecommendations(segments, churnRate, ltvScores);

    // محاسبه آمار کلی
    const now = new Date();
    const monthAgo = new Date();
    monthAgo.setMonth(monthAgo.getMonth() - 1);
    const activeCustomers = users.filter(u =>
      u.orders.some(o => o.createdAt > monthAgo)
    ).length;
    const newCustomersThisMonth = users.filter(u => u.createdAt > monthAgo).length;
    const averageLTV = ltvScores.reduce((s, l) => s + l, 0) / ltvScores.length;

    return {
      totalCustomers: users.length,
      activeCustomers,
      newCustomersThisMonth,
      averageLTV: Math.round(averageLTV),
      churnRate,
      segments,
      topCustomers,
      recommendations,
    };
  }

  // ============================================================
  // 2) محاسبه RFM
  // ============================================================
  private calculateRFM(user: any): { userId: number; recency: number; frequency: number; monetary: number; total: number } {
    const orders = user.orders || [];

    if (orders.length === 0) {
      return { userId: user.id, recency: 0, frequency: 0, monetary: 0, total: 0 };
    }

    // Recency: روزهای گذشته از آخرین خرید
    const lastOrder = orders[0];
    const recencyDays = Math.floor((Date.now() - lastOrder.createdAt.getTime()) / (1000 * 60 * 60 * 24));
    const recencyScore = Math.max(1, Math.min(5, 5 - Math.floor(recencyDays / 30)));

    // Frequency: تعداد سفارش‌ها
    const frequencyScore = Math.min(5, Math.ceil(orders.length / 2));

    // Monetary: مجموع خرید
    const totalSpent = orders.reduce((s: number, o: any) => s + o.finalAmount, 0);
    const monetaryScore = Math.min(5, Math.ceil(totalSpent / 1000000)); // هر میلیون = ۱ امتیاز

    return {
      userId: user.id,
      recency: recencyScore,
      frequency: frequencyScore,
      monetary: monetaryScore,
      total: recencyScore + frequencyScore + monetaryScore,
    };
  }

  // ============================================================
  // 3) دسته‌بندی مشتریان (Segmentation)
  // ============================================================
  private segmentCustomers(users: any[], rfmScores: any[]): CustomerSegment[] {
    const segmentMap = new Map<string, any[]>();

    for (let i = 0; i < users.length; i++) {
      const rfm = rfmScores[i];
      const segment = this.getSegmentName(rfm);

      if (!segmentMap.has(segment.name)) {
        segmentMap.set(segment.name, []);
      }
      segmentMap.get(segment.name)!.push({ user: users[i], rfm });
    }

    const segments: CustomerSegment[] = [];
    const segmentColors: Record<string, string> = {
      'VIP': '#8b5cf6',
      'وفادار': '#10b981',
      'فعال': '#3b82f6',
      'جدید': '#f59e0b',
      'در معرض ریزش': '#ef4444',
      'غیرفعال': '#6b7280',
      'یک‌بار خریدار': '#06b6d4',
    };

    for (const [name, customers] of segmentMap) {
      const avgLTV = customers.reduce((s, c) => {
        const totalSpent = c.user.orders?.reduce((sum: number, o: any) => sum + o.finalAmount, 0) || 0;
        return s + totalSpent;
      }, 0) / customers.length;

      const avgOrders = customers.reduce((s, c) => s + (c.user.orders?.length || 0), 0) / customers.length;

      const description = this.getSegmentDescription(name);

      segments.push({
        name,
        description,
        count: customers.length,
        percentage: Math.round((customers.length / users.length) * 100),
        averageLTV: Math.round(avgLTV),
        averageOrders: Math.round(avgOrders * 10) / 10,
        color: segmentColors[name] || '#6b7280',
      });
    }

    // مرتب‌سازی بر اساس تعداد
    segments.sort((a, b) => b.count - a.count);

    return segments;
  }

  private getSegmentName(rfm: any): { name: string } {
    const { recency, frequency, monetary } = rfm;

    if (recency >= 4 && frequency >= 4 && monetary >= 4) return { name: 'VIP' };
    if (recency >= 3 && frequency >= 3) return { name: 'وفادار' };
    if (recency >= 4 && frequency >= 2) return { name: 'فعال' };
    if (recency <= 2 && frequency >= 3) return { name: 'در معرض ریزش' };
    if (frequency === 1) return { name: 'یک‌بار خریدار' };
    if (recency <= 1) return { name: 'غیرفعال' };
    return { name: 'جدید' };
  }

  private getSegmentDescription(name: string): string {
    const descriptions: Record<string, string> = {
      'VIP': 'مشتریان ارزشمند با خرید مکرر و بالا',
      'وفادار': 'مشتریان وفادار با خرید منظم',
      'فعال': 'مشتریان فعال اخیر',
      'جدید': 'مشتریان جدید که نیاز به نگهداری دارند',
      'در معرض ریزش': 'مشتریانی که احتمال از دست دادن آنها وجود دارد',
      'غیرفعال': 'مشتریانی که مدت زیادی است خرید نکرده‌اند',
      'یک‌بار خریدار': 'مشتریانی که فقط یک بار خرید کرده‌اند',
    };
    return descriptions[name] || 'سایر';
  }

  // ============================================================
  // 4) محاسبه LTV (Customer Lifetime Value)
  // ============================================================
  private calculateLTV(user: any): number {
    const orders = user.orders || [];
    if (orders.length === 0) return 0;

    const totalSpent = orders.reduce((s: number, o: any) => s + o.finalAmount, 0);

    // محاسبه مدت زمان عضویت به ماه
    const memberMonths = Math.max(1, (Date.now() - user.createdAt.getTime()) / (1000 * 60 * 60 * 24 * 30));

    // میانگین خرید ماهانه
    const monthlyAvg = totalSpent / memberMonths;

    // LTV = میانگین ماهانه × مدت زمان انتظاری (۲۴ ماه)
    return Math.round(monthlyAvg * 24);
  }

  // ============================================================
  // 5) محاسبه Churn Rate
  // ============================================================
  private calculateChurnRate(users: any[]): number {
    if (users.length === 0) return 0;

    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);

    // مشتریانی که در ۳ ماه گذشته خرید داشته‌اند
    const activeInLast3Months = users.filter(u =>
      u.orders?.some((o: any) => o.createdAt > threeMonthsAgo)
    ).length;

    // مشتریانی که قبلاً فعال بودند اما در ۳ ماه گذشته خرید نکرده‌اند
    const churned = users.filter(u => {
      const hasOldOrders = u.orders?.some((o: any) => o.createdAt < threeMonthsAgo);
      const hasRecentOrders = u.orders?.some((o: any) => o.createdAt > threeMonthsAgo);
      return hasOldOrders && !hasRecentOrders;
    }).length;

    const totalActive = activeInLast3Months + churned;
    if (totalActive === 0) return 0;

    return Math.round((churned / totalActive) * 100);
  }

  // ============================================================
  // 6) دریافت مشتریان برتر
  // ============================================================
  private getTopCustomers(users: any[], rfmScores: any[], ltvScores: number[], limit: number): any[] {
    const combined = users.map((user, i) => ({
      userId: user.id,
      name: user.name || user.phone,
      phone: user.phone,
      ltv: ltvScores[i],
      orders: user.orders?.length || 0,
      lastOrder: user.orders?.[0]?.createdAt || user.createdAt,
      segment: this.getSegmentName(rfmScores[i]).name,
      rfmTotal: rfmScores[i].total,
    }));

    combined.sort((a, b) => b.ltv - a.ltv);

    return combined.slice(0, limit);
  }

  // ============================================================
  // 7) تولید توصیه‌ها
  // ============================================================
  private generateRecommendations(segments: CustomerSegment[], churnRate: number, ltvScores: number[]): string[] {
    const recommendations: string[] = [];

    // توصیه بر اساس نرخ ریزش
    if (churnRate > 30) {
      recommendations.push(`نرخ ریزش ${churnRate}٪ بالاست — کمپین بازگرداندن مشتریان لازم است`);
    } else if (churnRate < 10) {
      recommendations.push(`نرخ ریزش ${churnRate}٪ پایین است — وضعیت خوب`);
    }

    // توصیه بر اساس بخش‌ها
    for (const segment of segments) {
      switch (segment.name) {
        case 'در معرض ریزش':
          recommendations.push(`${segment.count} مشتری در معرض ریزش — تخفیف ویژه ارسال کنید`);
          break;
        case 'یک‌بار خریدار':
          recommendations.push(`${segment.count} مشتری یک‌بار خریدار — کمپین تشویق به خرید مجدد`);
          break;
        case 'VIP':
          recommendations.push(`${segment.count} مشتری VIP — برنامه وفاداری راه بیندازید`);
          break;
        case 'غیرفعال':
          recommendations.push(`${segment.count} مشتری غیرفعال — نظرسنجی خروج ارسال کنید`);
          break;
      }
    }

    // توصیه LTV
    const avgLTV = ltvScores.reduce((s, l) => s + l, 0) / ltvScores.length;
    if (avgLTV < 500000) {
      recommendations.push('LTV متوسط پایین است — استراتژی افزایش سبد خرید لازم است');
    }

    if (recommendations.length === 0) {
      recommendations.push('وضعیت مشتریان سالم است — به استراتژی فعلی ادامه دهید');
    }

    return recommendations;
  }

  // ============================================================
  // 8) پروفایل کامل یک مشتری
  // ============================================================
  async getCustomerProfile(userId: number, ctx: Context): Promise<CustomerProfile> {
    const user = await this.prisma.user.findFirst({
      where: { id: userId, tenantId: ctx.tenantId },
      include: {
        orders: {
          where: { status: { not: 'cancelled' } },
          select: { id: true, finalAmount: true, createdAt: true },
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!user) {
      throw new BusinessError('مشتری یافت نشد', 'NOT_FOUND');
    }

    const rfm = this.calculateRFM(user);
    const ltv = this.calculateLTV(user);
    const segment = this.getSegmentName(rfm).name;
    const churnProbability = this.calculateChurnProbability(user, rfm);
    const churnRisk = churnProbability > 0.6 ? 'high' : churnProbability > 0.3 ? 'medium' : 'low';

    const recommendations = this.generateCustomerRecommendations(segment, churnProbability, ltv);
    const nextBestAction = this.getNextBestAction(segment, churnProbability, ltv);

    if (churnRisk === 'high') {
      await this.eventBus.publish(new ChurnRiskDetectedEvent(
        userId,
        churnProbability,
        ctx.tenantId,
      ));
    }

    return {
      userId,
      name: user.name || user.phone,
      phone: user.phone,
      segment,
      rfmScore: rfm,
      ltv,
      churnRisk,
      churnProbability: Math.round(churnProbability * 100) / 100,
      recommendations,
      nextBestAction,
    };
  }

  // ============================================================
  // 9) محاسبه احتمال ریزش
  // ============================================================
  private calculateChurnProbability(user: any, rfm: any): number {
    const orders = user.orders || [];

    if (orders.length === 0) return 0.5;

    // محاسبه روزهای گذشته از آخرین خرید
    const lastOrder = orders[0];
    const daysSinceLastOrder = (Date.now() - lastOrder.createdAt.getTime()) / (1000 * 60 * 60 * 24);

    // مدل ساده: هرچه زمان بیشتری بگذرد و فرکانس کمتر باشد، احتمال ریزش بالاتر
    let probability = 0;

    // عامل زمان
    if (daysSinceLastOrder > 90) probability += 0.5;
    else if (daysSinceLastOrder > 60) probability += 0.3;
    else if (daysSinceLastOrder > 30) probability += 0.1;

    // عامل فرکانس
    if (orders.length === 1) probability += 0.2;
    else if (orders.length < 3) probability += 0.1;

    // عامل کاهش خرید
    if (orders.length >= 2) {
      const avgInterval = (orders[0].createdAt.getTime() - orders[orders.length - 1].createdAt.getTime()) / orders.length;
      const sinceLast = Date.now() - orders[0].createdAt.getTime();
      if (sinceLast > avgInterval * 1.5) probability += 0.2;
    }

    return Math.min(1, probability);
  }

  // ============================================================
  // 10) تولید توصیه‌های فردی
  // ============================================================
  private generateCustomerRecommendations(segment: string, churnProb: number, ltv: number): string[] {
    const recs: string[] = [];

    if (segment === 'VIP') {
      recs.push('ارسال کد تخفیف ویژه VIP');
      recs.push('دعوت به برنامه وفاداری');
    } else if (segment === 'وفادار') {
      recs.push('پیشنهاد محصولات مرتبط');
      recs.push('دعوت به ارسال نظر');
    } else if (segment === 'در معرض ریزش') {
      recs.push('ارسال ایمیل/پیامک ویژه');
      recs.push('تماس تلفنی برای بازگرداندن');
    } else if (segment === 'یک‌بار خریدار') {
      recs.push('ارسال کد تخفیف خرید دوم');
      recs.push('معرفی محصولات محبوب');
    } else if (segment === 'غیرفعال') {
      recs.push('نظرسنجی برای علل عدم خرید');
      recs.push('کمپین ویژه بازگشت');
    }

    if (ltv > 5000000) {
      recs.push('پیشنهاد ارتقا به مشتری عمده');
    }

    return recs;
  }

  // ============================================================
  // 11) Next Best Action
  // ============================================================
  private getNextBestAction(segment: string, churnProb: number, ltv: number): string {
    if (churnProb > 0.6) return 'تماس فوری برای حفظ مشتری';
    if (segment === 'VIP') return 'پیشنهاد محصول جدید قبل از عموم';
    if (segment === 'وفادار') return 'ارسال کد تشکر';
    if (segment === 'یک‌بار خریدار') return 'ارسال کد تخفیف خرید دوم';
    if (segment === 'جدید') return 'ارسال راهنمای استفاده';
    if (segment === 'غیرفعال') return 'ارسال نظرسنجی';
    return 'پیشنهاد محصول مرتبط';
  }

  // ============================================================
  // 12) موتور توصیه محصول (Recommendation)
  // ============================================================
  async recommendProducts(userId: number, ctx: Context, limit = 5): Promise<Array<{
    productId: number;
    title: string;
    reason: string;
    score: number;
  }>> {
    // دریافت تاریخچه خرید کاربر
    const userOrders = await this.prisma.order.findMany({
      where: { userId, tenantId: ctx.tenantId, status: { not: 'cancelled' } },
      include: { items: { select: { productId: true, productTitle: true } } },
    });

    const purchasedProductIds = new Set<number>();
    const purchasedCategories = new Map<string, number>();

    for (const order of userOrders) {
      for (const item of order.items) {
        purchasedProductIds.add(item.productId);
      }
    }

    // دریافت دسته‌بندی‌های خریداری شده
    if (purchasedProductIds.size > 0) {
      const products = await this.prisma.product.findMany({
        where: { id: { in: Array.from(purchasedProductIds) } },
        select: { category: true },
      });
      for (const p of products) {
        purchasedCategories.set(p.category, (purchasedCategories.get(p.category) || 0) + 1);
      }
    }

    // پیدا کردن محصولات پیشنهادی
    const where: any = {
      tenantId: ctx.tenantId,
      isPublished: true,
      inStock: true,
      id: { notIn: Array.from(purchasedProductIds) },
    };

    if (purchasedCategories.size > 0) {
      where.category = { in: Array.from(purchasedCategories.keys()) };
    }

    const candidateProducts = await this.prisma.product.findMany({
      where,
      select: {
        id: true,
        title: true,
        category: true,
        rating: true,
        ratingCount: true,
        price: true,
        salePrice: true,
      },
      take: 50,
    });

    // امتیازدهی به محصولات
    const scored = candidateProducts.map(p => {
      let score = 0;
      let reason = '';

      // امتیاز بر اساس دسته‌بندی خریداری شده
      const catCount = purchasedCategories.get(p.category) || 0;
      if (catCount > 0) {
        score += catCount * 30;
        reason = 'بر اساس خریدهای قبلی شما';
      }

      // امتیاز بر اساس امتیاز محصول
      score += p.rating * 10;

      // امتیاز بر اساس تعداد نظرات
      score += Math.min(20, p.ratingCount);

      // امتیاز بر اساس تخفیف
      if (p.salePrice && p.salePrice < p.price) {
        score += 15;
        if (!reason) reason = 'در تخفیف ویژه';
      }

      if (!reason) reason = 'محصول محبوب';

      return {
        productId: p.id,
        title: p.title,
        reason,
        score: Math.round(score),
      };
    });

    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, limit);
  }
}
