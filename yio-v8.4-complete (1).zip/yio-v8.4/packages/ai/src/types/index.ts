// ============================================================
// YIO V7 — AI Domain Events
// ============================================================

import { DomainEvent } from '@yio/core';

// ===== Sales Forecasting Events =====
export class SalesForecastGeneratedEvent extends DomainEvent {
  get eventName() { return 'ai.sales_forecast_generated'; }
  constructor(
    public readonly totalForecast: number,
    public readonly periods: number,
    public readonly method: string,
    public readonly tenantId: number,
  ) { super(); }
}

export class SalesAnomalyDetectedEvent extends DomainEvent {
  get eventName() { return 'ai.sales_anomaly_detected'; }
  constructor(
    public readonly date: string,
    public readonly actualValue: number,
    public readonly expectedValue: number,
    public readonly tenantId: number,
  ) { super(); }
}

// ===== Smart Chat Events =====
export class ChatMessageSentEvent extends DomainEvent {
  get eventName() { return 'ai.chat_message_sent'; }
  constructor(
    public readonly sessionId: string,
    public readonly userMessage: string,
    public readonly botResponse: string,
    public readonly tenantId: number,
  ) { super(); }
}

export class ChatHandoffEvent extends DomainEvent {
  get eventName() { return 'ai.chat_handoff'; }
  constructor(
    public readonly sessionId: string,
    public readonly userId: number | undefined,
    public readonly reason: string,
    public readonly tenantId: number,
  ) { super(); }
}

// ===== Product Description Events =====
export class ProductDescriptionGeneratedEvent extends DomainEvent {
  get eventName() { return 'ai.product_description_generated'; }
  constructor(
    public readonly productId: number,
    public readonly generatedTitle: string,
    public readonly tenantId: number,
  ) { super(); }
}

// ===== Customer Insights Events =====
export class CustomerSegmentUpdatedEvent extends DomainEvent {
  get eventName() { return 'ai.customer_segment_updated'; }
  constructor(
    public readonly userId: number,
    public readonly oldSegment: string,
    public readonly newSegment: string,
    public readonly tenantId: number,
  ) { super(); }
}

export class ChurnRiskDetectedEvent extends DomainEvent {
  get eventName() { return 'ai.churn_risk_detected'; }
  constructor(
    public readonly userId: number,
    public readonly churnProbability: number,
    public readonly tenantId: number,
  ) { super(); }
}

// ===== Anomaly Detection Events =====
export class AnomalyDetectedEvent extends DomainEvent {
  get eventName() { return 'ai.anomaly_detected'; }
  constructor(
    public readonly type: string,
    public readonly entityType: string,
    public readonly entityId: number,
    public readonly description: string,
    public readonly severity: 'low' | 'medium' | 'high',
    public readonly tenantId: number,
  ) { super(); }
}
