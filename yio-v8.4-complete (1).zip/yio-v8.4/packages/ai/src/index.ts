// ============================================================
// YIO V7 — AI Package Entry Point
// ============================================================

// Engines
export { SalesForecastingEngine } from './engines/sales-forecasting-engine';
export type { ForecastResult, ForecastOptions, SalesDataPoint } from './engines/sales-forecasting-engine';

export { SmartChatEngine, INTENTS } from './engines/smart-chat-engine';
export type { ChatMessage, ChatSession, ChatContext, ChatResponse } from './engines/smart-chat-engine';

export { ProductDescriptionGenerator } from './engines/product-description-generator';
export type { ProductDescriptionInput, GeneratedDescription } from './engines/product-description-generator';

export { CustomerInsightsAnalyzer } from './engines/customer-insights-analyzer';
export type { CustomerInsights, CustomerSegment, CustomerProfile } from './engines/customer-insights-analyzer';

export { AnomalyDetectionEngine } from './engines/anomaly-detection-engine';
export type { Anomaly } from './engines/anomaly-detection-engine';

// Events
export * from './types';
