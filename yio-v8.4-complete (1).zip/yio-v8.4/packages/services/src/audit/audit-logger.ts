// ============================================================
// YIO V8 — Audit Logger (Central)
// ============================================================
// Audit Logger مرکزی که تمام عملیات write در سیستم را ثبت می‌کند.
// شامل: Who / When / What / Old / New / IP / Browser / Tenant / Request.
//
// در V8 این سرویس:
//   - در API middleware به‌صورت خودکار فراخوانی می‌شود.
//   - در Engineها از طریق tx.collectAudit در UoW فراخوانی می‌شود.
//   - برای گزارش‌گیری audit قابل query است.
// ============================================================

import { PrismaClient } from '@prisma/client';
import {
  IAuditLogger,
  IAuditLogRepository,
  AuditEntry,
  Context,
  PaginatedResult,
} from '@yio/core';

// ============================================================
// Repository (Prisma)
// ============================================================
export class PrismaAuditLogRepository implements IAuditLogRepository {
  private memoryFallback: AuditEntry[] = [];
  private useFallback: boolean;

  constructor(private prisma: PrismaClient) {
    this.useFallback = !(prisma as any).auditLog;
  }

  async append(entry: Record<string, any>): Promise<void> {
    if (this.useFallback) {
      this.memoryFallback.push(entry as AuditEntry);
      return;
    }
    await (this.prisma as any).auditLog.create({
      data: {
        tenantId: entry.tenantId,
        userId: entry.userId ?? null,
        userRole: entry.userRole ?? null,
        action: entry.action,
        entityType: entry.entityType,
        entityId: typeof entry.entityId === 'number' ? entry.entityId : 0,
        operation: entry.operation ?? 'update',
        changes: entry.changes ? JSON.stringify(entry.changes) : null,
        metadata: entry.metadata ? JSON.stringify(entry.metadata) : null,
        ip: entry.ip ?? null,
        userAgent: entry.userAgent ?? null,
        requestId: entry.requestId ?? null,
        timestamp: entry.timestamp ?? new Date(),
      },
    });
  }

  async query(
    filter: Record<string, any>,
    ctx: Context,
    page: number = 1,
    pageSize: number = 50,
  ): Promise<PaginatedResult<any>> {
    if (this.useFallback) {
      const filtered = this.memoryFallback.filter((e) => {
        if (e.tenantId !== ctx.tenantId) return false;
        if (filter.userId && e.userId !== filter.userId) return false;
        if (filter.entityType && e.entityType !== filter.entityType) return false;
        if (filter.entityId && e.entityId !== filter.entityId) return false;
        if (filter.action && e.action !== filter.action) return false;
        return true;
      });
      return {
        data: filtered,
        pagination: { page, pageSize, total: filtered.length, totalPages: 1 },
      };
    }

    const where: any = { tenantId: ctx.tenantId };
    if (filter.userId) where.userId = filter.userId;
    if (filter.entityType) where.entityType = filter.entityType;
    if (filter.entityId) where.entityId = filter.entityId;
    if (filter.action) where.action = filter.action;
    if (filter.from || filter.to) {
      where.timestamp = {};
      if (filter.from) where.timestamp.gte = filter.from;
      if (filter.to) where.timestamp.lte = filter.to;
    }

    const [data, total] = await Promise.all([
      (this.prisma as any).auditLog.findMany({
        where,
        orderBy: { timestamp: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      (this.prisma as any).auditLog.count({ where }),
    ]);

    return {
      data,
      pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
    };
  }
}

// ============================================================
// Audit Logger Service
// ============================================================
export class AuditLogger implements IAuditLogger {
  constructor(private repo: IAuditLogRepository) {}

  async log(entry: AuditEntry): Promise<void> {
    if (!entry.timestamp) entry.timestamp = new Date();
    await this.repo.append(entry);
  }

  async logChange(
    entityType: string,
    entityId: number | string,
    oldValues: Record<string, any>,
    newValues: Record<string, any>,
    ctx: Context,
    action?: string,
  ): Promise<void> {
    const changes: Record<string, { old: any; new: any }> = {};
    const allKeys = new Set([...Object.keys(oldValues), ...Object.keys(newValues)]);
    for (const key of allKeys) {
      const oldVal = oldValues[key];
      const newVal = newValues[key];
      if (JSON.stringify(oldVal) !== JSON.stringify(newVal)) {
        changes[key] = { old: oldVal, new: newVal };
      }
    }

    await this.log({
      tenantId: ctx.tenantId,
      userId: ctx.userId,
      userRole: ctx.userRole,
      action: action || `${entityType.toLowerCase()}.update`,
      entityType,
      entityId,
      operation: 'update',
      changes,
      ip: ctx.ip,
      userAgent: ctx.userAgent,
      requestId: ctx.requestId,
      timestamp: new Date(),
    });
  }

  query(
    filter: {
      tenantId?: number;
      userId?: number;
      entityType?: string;
      entityId?: number | string;
      action?: string;
      from?: Date;
      to?: Date;
    },
    page: number = 1,
    pageSize: number = 50,
  ): Promise<PaginatedResult<AuditEntry>> {
    const ctx: Context = { tenantId: filter.tenantId ?? 0 };
    return this.repo.query(filter, ctx, page, pageSize);
  }
}
