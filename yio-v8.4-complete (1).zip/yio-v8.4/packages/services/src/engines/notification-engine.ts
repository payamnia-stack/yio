// ============================================================
// YIO V7 — Notification Engine
// ============================================================
// موتور اعلان‌ها — SMS، ایمیل، push و in-app
// ============================================================

import { Context, Events } from '@yio/core';
import { PrismaClient } from '@prisma/client';
import { IEventBus } from '@yio/core';

export type NotificationChannel = 'sms' | 'email' | 'push' | 'in_app';
export type NotificationType = 'order' | 'payment' | 'shipping' | 'production' | 'system' | 'low_stock' | 'quality';

export interface NotificationInput {
  userId?: number;
  phone?: string;
  email?: string;
  channel: NotificationChannel;
  type: NotificationType;
  title: string;
  message: string;
  data?: Record<string, any>;
}

export class NotificationEngine {
  constructor(
    private prisma: PrismaClient,
    private eventBus: IEventBus,
  ) {
    // ثبت handlerهای Event
    this.eventBus.subscribe(Events.OrderCreated, this.onOrderCreated.bind(this));
    this.eventBus.subscribe(Events.OrderShipped, this.onOrderShipped.bind(this));
    this.eventBus.subscribe(Events.OrderDelivered, this.onOrderDelivered.bind(this));
    this.eventBus.subscribe(Events.ProductionCompleted, this.onProductionCompleted.bind(this));
    this.eventBus.subscribe(Events.LowStockAlert, this.onLowStock.bind(this));
    this.eventBus.subscribe(Events.QualityCheckFailed, this.onQualityFailed.bind(this));
    this.eventBus.subscribe(Events.MachineMaintenanceDue, this.onMachineMaintenance.bind(this));
  }

  // ===== ارسال اعلان =====
  async send(input: NotificationInput, ctx: Context): Promise<{ success: boolean }> {
    // ذخیره در دیتابیس
    const notification = await this.prisma.userNotification.create({
      data: {
        userId: input.userId,
        type: input.type,
        title: input.title,
        message: input.message,
        data: input.data ? JSON.stringify(input.data) : null,
        isRead: false,
        tenantId: ctx.tenantId,
      },
    }).catch(() => null);

    // ارسال بر اساس کانال
    switch (input.channel) {
      case 'sms':
        return this.sendSms(input, ctx);
      case 'email':
        return this.sendEmail(input, ctx);
      case 'push':
        return this.sendPush(input, ctx);
      case 'in_app':
        // فقط در دیتابیس ذخیره شد
        return { success: true };
    }
  }

  // ===== SMS =====
  private async sendSms(input: NotificationInput, ctx: Context): Promise<{ success: boolean }> {
    if (!input.phone) return { success: false };

    // خواندن تنظیمات SMS از دیتابیس
    const settings = await this.prisma.siteSetting.findMany({
      where: { category: 'sms', tenantId: ctx.tenantId },
    });
    const config: Record<string, string> = {};
    settings.forEach(s => config[s.key] = s.value);

    if (config.sms_enabled !== 'true') {
      console.log(`[NotificationEngine] SMS disabled — To: ${input.phone}, Msg: ${input.message}`);
      return { success: false };
    }

    try {
      const normalizedPhone = input.phone.startsWith('0') ? input.phone.substring(1) : input.phone;

      if (config.sms_provider === 'melipayamak') {
        const credentials = config.sms_api_key.split('|');
        const response = await fetch('https://rest.payamak-panel.com/api/SendSMS/SendSMS', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            username: credentials[0] || '',
            password: credentials[1] || '',
            to: normalizedPhone,
            from: config.sms_sender_number,
            text: input.message,
          }),
        });
        return { success: response.ok };
      }

      return { success: false };
    } catch (e) {
      console.error('[NotificationEngine] SMS error:', e);
      return { success: false };
    }
  }

  // ===== Email =====
  private async sendEmail(input: NotificationInput, ctx: Context): Promise<{ success: boolean }> {
    if (!input.email) return { success: false };

    // در نسخه کامل از nodemailer استفاده می‌شود
    console.log(`[NotificationEngine] Email — To: ${input.email}, Subject: ${input.title}`);
    return { success: true };
  }

  // ===== Push =====
  private async sendPush(input: NotificationInput, ctx: Context): Promise<{ success: boolean }> {
    // در نسخه کامل از FCM استفاده می‌شود
    console.log(`[NotificationEngine] Push — To: ${input.userId}, Title: ${input.title}`);
    return { success: true };
  }

  // ===== Event Handlers =====
  private async onOrderCreated(event: any): Promise<void> {
    console.log(`[NotificationEngine] Order ${event.orderId} created — sending SMS`);
    // ارسال SMS تأیید سفارش به مشتری
  }

  private async onOrderShipped(event: any): Promise<void> {
    console.log(`[NotificationEngine] Order ${event.orderId} shipped — sending tracking SMS`);
  }

  private async onOrderDelivered(event: any): Promise<void> {
    console.log(`[NotificationEngine] Order ${event.orderId} delivered — sending thank you SMS`);
  }

  private async onProductionCompleted(event: any): Promise<void> {
    console.log(`[NotificationEngine] WorkOrder ${event.workOrderId} completed — notifying manager`);
  }

  private async onLowStock(event: any): Promise<void> {
    console.log(`[NotificationEngine] Low stock alert: ${event.itemName} (${event.currentQuantity})`);
    // ارسال اعلان به مدیر انبار
  }

  private async onQualityFailed(event: any): Promise<void> {
    console.log(`[NotificationEngine] Quality check failed on WO ${event.workOrderId}`);
  }

  private async onMachineMaintenance(event: any): Promise<void> {
    console.log(`[NotificationEngine] Machine ${event.machineName} needs maintenance`);
  }
}
