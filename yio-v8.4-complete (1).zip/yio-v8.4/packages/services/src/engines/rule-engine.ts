// ============================================================
// YIO V8 — Rule Engine (Upgraded — Pluggable)
// ============================================================
// در V8 Rule Engine دو منبع Rule دارد:
//   1) Ruleهای استاتیک (کلاس‌ها که در Registry ثبت می‌شوند)
//   2) Ruleهای داینامیک (دیتابیس، مثل V7)
//
// هر دو منبع با هم ارزیابی می‌شوند.
// ============================================================

import {
  Context,
  OperationResult,
  IRuleEngine,
  IRuleRegistry,
  IRuleContext,
  IRuleResult,
} from '@yio/core';
import { PrismaClient } from '@prisma/client';

// ===== Dynamic Rule (from DB, like V7) =====
interface DynamicRule {
  key: string;
  name: string;
  type: 'validation' | 'pricing' | 'workflow' | 'notification' | 'access';
  engine: string;
  condition: {
    field: string;
    operator: '>=' | '<=' | '==' | '!=' | '>' | '<' | 'in' | 'not_in' | 'contains';
    value: any;
  };
  action: {
    type: 'reject' | 'warn' | 'approve' | 'notify' | 'adjust';
    message?: string;
    value?: any;
  };
  priority: number;
  isActive: boolean;
}

export class RuleEngine implements IRuleEngine {
  private dynamicRuleCache: Map<string, DynamicRule[]> = new Map();
  private cacheExpiry: number = 5 * 60 * 1000;
  private lastCacheUpdate: number = 0;

  constructor(
    private prisma: PrismaClient,
    private registry: IRuleRegistry,
  ) {}

  // ============================================================
  // اعتبارسنجی — استاتیک + داینامیک
  // ============================================================
  async validate(action: string, data: any, ctx: Context): Promise<OperationResult> {
    const warnings: string[] = [];

    // ۱) ارزیابی Ruleهای استاتیک (از Registry)
    // V8.1: data واقعی برای isApplicable پاس داده می‌شود
    const staticRules = this.registry.getRulesForAction(action, ctx, data);
    for (const rule of staticRules) {
      const rc: IRuleContext = { action, data, ctx };
      const result: IRuleResult = await rule.evaluate(rc);

      // V8.1: logic درست — severity تعیین می‌کند که warn/info/error چه باشد
      // (نه فیلد passed که فقط برای error/true است)
      if (result.severity === 'error' && !result.passed) {
        return {
          success: false,
          message: result.message || `قانون «${rule.name}» نقض شد`,
        };
      }
      if (result.severity === 'warn') {
        // هم passed=true و هم passed=false ممکن است warning باشند
        warnings.push(result.message || `هشدار: ${rule.name}`);
      }

      // اعمال adjustments روی data
      if (result.adjustedData) {
        Object.assign(data, result.adjustedData);
      }
    }

    // ۲) ارزیابی Ruleهای داینامیک (از دیتابیس)
    const dynamicRules = await this.getDynamicRules(action, ctx);
    for (const rule of dynamicRules.sort((a, b) => a.priority - b.priority)) {
      const passed = this.evaluate(rule.condition, data);

      if (!passed) {
        switch (rule.action.type) {
          case 'reject':
            return {
              success: false,
              message: rule.action.message || `قانون «${rule.name}» نقض شد`,
            };
          case 'warn':
            warnings.push(rule.action.message || `هشدار: ${rule.name}`);
            break;
          case 'adjust':
            if (rule.action.value !== undefined) {
              data[rule.condition.field] = rule.action.value;
            }
            break;
        }
      }
    }

    return {
      success: true,
      warnings: warnings.length > 0 ? warnings : undefined,
    };
  }

  // ============================================================
  // ارزیابی یک شرط (برای استفاده external)
  // ============================================================
  evaluate(condition: DynamicRule['condition'], data: any): boolean {
    const value = this.resolveField(condition.field, data);
    switch (condition.operator) {
      case '>=': return value >= condition.value;
      case '<=': return value <= condition.value;
      case '==': return value === condition.value;
      case '!=': return value !== condition.value;
      case '>': return value > condition.value;
      case '<': return value < condition.value;
      case 'in': return Array.isArray(condition.value) && condition.value.includes(value);
      case 'not_in': return Array.isArray(condition.value) && !condition.value.includes(value);
      case 'contains':
        return typeof value === 'string' && value.includes(condition.value);
      default: return true;
    }
  }

  // ============================================================
  // Dynamic Rules (DB-backed, like V7)
  // ============================================================
  private async getDynamicRules(action: string, ctx: Context): Promise<DynamicRule[]> {
    const cacheKey = `${ctx.tenantId}:${action}`;
    if (Date.now() - this.lastCacheUpdate < this.cacheExpiry && this.dynamicRuleCache.has(cacheKey)) {
      return this.dynamicRuleCache.get(cacheKey)!;
    }

    const dbRules = await this.prisma.siteSetting.findMany({
      where: {
        tenantId: ctx.tenantId,
        category: 'rule',
        key: { startsWith: `rule.${action}.` },
      },
    });

    const rules: DynamicRule[] = dbRules
      .map((r) => {
        try {
          return JSON.parse(r.value) as DynamicRule;
        } catch {
          return null;
        }
      })
      .filter((r): r is DynamicRule => r !== null && r.isActive);

    this.dynamicRuleCache.set(cacheKey, rules);
    this.lastCacheUpdate = Date.now();
    return rules;
  }

  private resolveField(field: string, data: any): any {
    const parts = field.split('.');
    let value = data;
    for (const part of parts) {
      if (value == null) return undefined;
      value = value[part];
    }
    return value;
  }

  // ============================================================
  // Management API
  // ============================================================
  async createRule(rule: DynamicRule, ctx: Context): Promise<void> {
    await this.prisma.siteSetting.create({
      data: {
        key: `rule.${rule.engine}.${rule.key}`,
        value: JSON.stringify(rule),
        category: 'rule',
        tenantId: ctx.tenantId,
      },
    });
    this.dynamicRuleCache.clear();
  }

  async disableRule(ruleKey: string, engine: string, ctx: Context): Promise<void> {
    const key = `rule.${engine}.${ruleKey}`;
    const setting = await this.prisma.siteSetting.findFirst({
      where: { key, tenantId: ctx.tenantId },
    });
    if (setting) {
      const rule = JSON.parse(setting.value) as DynamicRule;
      rule.isActive = false;
      await this.prisma.siteSetting.update({
        where: { id: setting.id },
        data: { value: JSON.stringify(rule) },
      });
      this.dynamicRuleCache.clear();
    }
  }

  clearCache(): void {
    this.dynamicRuleCache.clear();
    this.lastCacheUpdate = 0;
  }
}
