// ============================================================
// YIO V8.2 — Permission Engine (RBAC + ABAC)
// ============================================================
// در V8.2، RBAC ساده به ABAC ارتقاء یافته است. علاوه بر Role،
// Attributeهای محیطی هم بررسی می‌شوند:
//   - Department
//   - Branch
//   - Ownership (self / team / department / company / all)
//   - Time window
//   - Entity Status
//
// V8.2 Fix: IPermissionChecker حذف شده — فقط IAbacPermissionChecker باقی مانده
// ============================================================

import {
  Context,
  IAbacPermissionChecker,
  AbacAttribute,
  AbacPolicy,
  AbacDecision,
} from '@yio/core';

// ===== Permission Definitions (همان V7) =====
export const PERMISSIONS = {
  'product.create': 'ایجاد محصول',
  'product.edit': 'ویرایش محصول',
  'product.delete': 'حذف محصول',
  'product.publish': 'انتشار محصول به سایت',
  'product.unpublish': 'لغو انتشار محصول',
  'product.view': 'مشاهده محصول',

  'order.view': 'مشاهده سفارش',
  'order.create': 'ثبت سفارش',
  'order.confirm': 'تأیید سفارش',
  'order.cancel': 'لغو سفارش',
  'order.ship': 'ارسال سفارش',
  'order.pay': 'ثبت پرداخت سفارش',

  'production.view': 'مشاهده تولید',
  'production.create': 'ایجاد دستور تولید',
  'production.start': 'شروع تولید',
  'production.pause': 'توقف تولید',
  'production.complete': 'تکمیل تولید',

  'inventory.view': 'مشاهده انبار',
  'inventory.adjust': 'ورود/خروج کالا',
  'inventory.transfer': 'انتقال بین انبارها',

  'quality.view': 'مشاهده کنترل کیفیت',
  'quality.check': 'ثبت نتیجه بازرسی',

  'waste.view': 'مشاهده ضایعات',
  'waste.record': 'ثبت ضایعات',

  'purchase.view': 'مشاهده خرید',
  'purchase.create': 'ایجاد سفارش خرید',
  'purchase.approve': 'تأیید خرید',

  'finance.view': 'مشاهده مالی',
  'finance.invoice': 'صدور فاکتور',
  'finance.payment': 'ثبت پرداخت',

  'hr.view': 'مشاهده پرسنل',
  'hr.manage': 'مدیریت پرسنل',

  'reports.view': 'مشاهده گزارش‌ها',
  'reports.export': 'خروجی گزارش',

  'settings.view': 'مشاهده تنظیمات',
  'settings.manage': 'مدیریت تنظیمات',
  'settings.modules': 'مدیریت ماژول‌ها',

  'admin.full': 'دسترسی کامل',
} as const;

export type Permission = keyof typeof PERMISSIONS;

// ===== Role Definitions =====
export const ROLES = {
  ceo: {
    name: 'مدیرعامل',
    permissions: ['admin.full'],
    description: 'دسترسی کامل به همه بخش‌ها',
  },
  production_manager: {
    name: 'مدیر تولید',
    permissions: [
      'product.create', 'product.edit', 'product.publish', 'product.view',
      'production.view', 'production.create', 'production.start', 'production.pause', 'production.complete',
      'inventory.view', 'inventory.adjust',
      'quality.view', 'quality.check',
      'waste.view', 'waste.record',
      'reports.view', 'reports.export',
    ],
    description: 'مدیریت تولید، انبار، کیفیت و ضایعات',
  },
  sales_manager: {
    name: 'مدیر فروش',
    permissions: [
      'product.view', 'product.publish', 'product.unpublish',
      'order.view', 'order.create', 'order.confirm', 'order.cancel', 'order.ship',
      'reports.view', 'reports.export',
    ],
    description: 'مدیریت فروش، سفارشات و گزارش‌ها',
  },
  warehouse: {
    name: 'انباردار',
    permissions: [
      'inventory.view', 'inventory.adjust', 'inventory.transfer',
      'product.view',
    ],
    description: 'مدیریت انبار و موجودی',
  },
  operator: {
    name: 'اپراتور',
    permissions: [
      'production.view',
      'quality.view', 'quality.check',
    ],
    description: 'مشاهده تولید و ثبت کیفیت (فقط رکوردهای خودش)',
  },
  designer: {
    name: 'طراح',
    permissions: [
      'product.create', 'product.edit', 'product.view',
    ],
    description: 'ایجاد و ویرایش محصولات و طراحی',
  },
  finance: {
    name: 'مالی',
    permissions: [
      'finance.view', 'finance.invoice', 'finance.payment',
      'order.view', 'order.pay',
      'reports.view', 'reports.export',
    ],
    description: 'مدیریت مالی، فاکتور و پرداخت',
  },
  support: {
    name: 'پشتیبانی',
    permissions: [
      'order.view',
      'reports.view',
    ],
    description: 'مشاهده سفارشات و پشتیبانی مشتریان',
  },
  customer: {
    name: 'مشتری',
    permissions: [
      'order.create', 'order.view',
    ],
    description: 'ثبت سفارش و مشاهده سفارشات خود',
  },
} as const;

export type RoleName = keyof typeof ROLES;

// ============================================================
// ABAC Permission Checker
// ============================================================
export class PermissionChecker implements IAbacPermissionChecker {
  private policies: AbacPolicy[] = [];
  private defaultDeny: boolean = true;

  constructor() {
    // سیاست‌های پیش‌فرض ABAC
    this.registerDefaultPolicies();
  }

  // ============================================================
  // RBAC (Backward Compatible با V7)
  // ============================================================
  hasPermission(permission: string, ctx: Context): boolean {
    if (ctx.permissions?.includes('admin.full')) return true;
    if (ctx.permissions?.includes(permission)) return true;
    return false;
  }

  hasRole(role: string, ctx: Context): boolean {
    return ctx.userRole === role || ctx.permissions?.includes('admin.full') === true;
  }

  checkOwnership(entityOwnerId: number, ctx: Context): boolean {
    if (ctx.permissions?.includes('admin.full')) return true;
    if (ctx.userRole === 'production_manager' || ctx.userRole === 'sales_manager') return true;
    return ctx.userId === entityOwnerId;
  }

  getRolePermissions(role: RoleName): string[] {
    return [...ROLES[role].permissions];
  }

  getAllRoles(): Array<{ key: string; name: string; permissions: string[]; description: string }> {
    return Object.entries(ROLES).map(([key, role]) => ({
      key,
      name: role.name,
      permissions: [...role.permissions],
      description: role.description,
    }));
  }

  // ============================================================
  // ABAC (New in V8)
  // ============================================================

  /**
   * بررسی دسترسی کامل با RBAC + ABAC.
   *  1) اول RBAC بررسی می‌شود (نقش + permission).
   *  2) سپس Policyهای ABAC با ترتیب priority ارزیابی می‌شوند.
   *  3) اولین Policy که match کند، effect آن برمی‌گردد.
   *  4) اگر هیچ Policyای match نکرد، defaultDeny برقرار می‌شود.
   */
  checkAccess(
    permission: string,
    ctx: Context,
    attributes: Partial<AbacAttribute> = {},
  ): AbacDecision {
    const evaluatedAt = new Date();

    // ۱) Admin full → allow
    if (ctx.permissions?.includes('admin.full')) {
      return { allowed: true, matchedPolicy: 'admin.full', evaluatedAt };
    }

    // ۲) RBAC check
    if (!this.hasPermission(permission, ctx)) {
      return {
        allowed: false,
        deniedReason: `RBAC: user does not have permission "${permission}"`,
        evaluatedAt,
      };
    }

    // ۳) ساخت AbacAttribute از ctx + attributes
    const attr: AbacAttribute = {
      userId: ctx.userId,
      role: ctx.userRole,
      department: ctx.department,
      branch: ctx.branchId ? String(ctx.branchId) : undefined,
      ...attributes,
    };

    // ۴) ارزیابی Policyهای ABAC (مرتب بر اساس priority)
    const sorted = [...this.policies].sort((a, b) => a.priority - b.priority);
    for (const policy of sorted) {
      if (policy.resource !== '*' && policy.resource !== permission.split('.')[0]) {
        continue;
      }
      if (policy.action !== '*' && policy.action !== permission.split('.').slice(1).join('.')) {
        continue;
      }

      // بررسی requiredRoles
      if (policy.requiredRoles && policy.requiredRoles.length > 0) {
        if (!attr.role || !policy.requiredRoles.includes(attr.role)) {
          continue;
        }
      }

      // بررسی attributes
      if (policy.attributes) {
        const attrMatch = Object.entries(policy.attributes).every(([key, value]) => {
          return attr[key as keyof AbacAttribute] === value;
        });
        if (!attrMatch) continue;
      }

      // بررسی condition
      if (policy.condition && !policy.condition(attr)) {
        continue;
      }

      // Policy matched!
      if (policy.effect === 'deny') {
        return {
          allowed: false,
          matchedPolicy: policy.name,
          deniedReason: `ABAC policy "${policy.name}" denied access`,
          evaluatedAt,
        };
      }
      return { allowed: true, matchedPolicy: policy.name, evaluatedAt };
    }

    // ۵) No policy matched → default
    if (this.defaultDeny) {
      return {
        allowed: false,
        deniedReason: 'No ABAC policy matched (default deny)',
        evaluatedAt,
      };
    }
    return { allowed: true, evaluatedAt };
  }

  // ============================================================
  // Policy Management
  // ============================================================
  registerPolicy(policy: AbacPolicy): void {
    this.policies.push(policy);
    console.log(`[PermissionEngine] 📥 Registered ABAC policy: ${policy.name}`);
  }

  listPolicies(): AbacPolicy[] {
    return [...this.policies].sort((a, b) => a.priority - b.priority);
  }

  /** روشن/خاموش کردن default deny (برای test) */
  setDefaultDeny(value: boolean): void {
    this.defaultDeny = value;
  }

  // ============================================================
  // Default ABAC Policies
  // ============================================================
  private registerDefaultPolicies(): void {
    // Policy 1: Operators only see their own QC records (except managers)
    this.registerPolicy({
      name: 'qc_self_only',
      resource: 'quality',
      action: 'check',
      requiredRoles: ['operator'],
      priority: 10,
      effect: 'allow',
      condition: (attr) => {
        return attr.ownershipLevel === 'self' || attr.ownershipLevel === undefined;
      },
    });

    // Policy 2: Working hours restriction for sensitive actions
    this.registerPolicy({
      name: 'finance_working_hours',
      resource: 'finance',
      action: '*',
      requiredRoles: ['finance'],
      priority: 20,
      effect: 'allow',
      condition: (_attr) => {
        const hour = new Date().getHours();
        return hour >= 7 && hour <= 23;
      },
    });

    // Policy 3: Sales managers can only access their branch's orders
    this.registerPolicy({
      name: 'sales_branch_isolation',
      resource: 'order',
      action: 'view',
      requiredRoles: ['sales_manager'],
      attributes: { ownershipLevel: 'department' },
      priority: 30,
      effect: 'allow',
    });

    // Policy 4: Customers can only access their own orders
    this.registerPolicy({
      name: 'customer_self_orders',
      resource: 'order',
      action: 'view',
      requiredRoles: ['customer'],
      priority: 5,
      effect: 'allow',
      condition: (attr) => attr.entityOwnerId === attr.userId,
    });

    // Policy 5: Allow deny for cancelled orders (cannot be modified)
    this.registerPolicy({
      name: 'no_modify_cancelled_orders',
      resource: 'order',
      action: '*',
      priority: 1,
      effect: 'deny',
      condition: (attr) => attr.entityStatus === 'cancelled',
    });
  }
}

// ============================================================
// Helpers (Backward Compatible با V7)
// ============================================================
export function requirePermission(permission: string) {
  return function (target: any, propertyKey: string, descriptor: PropertyDescriptor) {
    const originalMethod = descriptor.value;
    descriptor.value = async function (...args: any[]) {
      const ctx: Context = args[args.length - 1];
      const checker = new PermissionChecker();
      if (!checker.hasPermission(permission, ctx)) {
        throw new Error(`دسترسی غیرمجاز: ${permission}`);
      }
      return originalMethod.apply(this, args);
    };
  };
}

export function buildContext(params: {
  tenantId: number;
  userId?: number;
  userRole?: string;
  permissions?: string[];
  ip?: string;
  userAgent?: string;
  requestId?: string;
  branchId?: number;
  department?: string;
}): Context {
  let permissions = params.permissions || [];
  if (params.userRole && ROLES[params.userRole as RoleName]) {
    const rolePerms = [...ROLES[params.userRole as RoleName].permissions];
    permissions = [...new Set([...permissions, ...rolePerms])];
  }
  return {
    tenantId: params.tenantId,
    userId: params.userId,
    userRole: params.userRole,
    permissions,
    ip: params.ip,
    userAgent: params.userAgent,
    requestId: params.requestId,
    branchId: params.branchId,
    department: params.department,
  };
}
