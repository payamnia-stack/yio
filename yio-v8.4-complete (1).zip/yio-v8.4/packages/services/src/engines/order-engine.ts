// ============================================================
// YIO V8.2 — Order Engine (Refactored)
// ============================================================
// در V8.2 این Engine به‌جای وابستگی مستقیم به:
//   - OrderRepository (Concrete class)
//   - String event names
//   - Prisma Client دستی
//   - Console (به‌عنوان default logger)
// از انتزاعات زیر استفاده می‌کند:
//   - IOrderRepository (Interface — قابل تعویض)
//   - IProductRepository (Interface)
//   - ITransactionManager (Unit of Work)
//   - Events typed registry (تایپ‌شده)
//   - IRuleEngine (پیش از create، Ruleها ارزیابی می‌شوند)
//   - IAuditLogger (تغییرات به‌صورت خودکار Audit می‌شوند)
//   - IEventBus (با Event Store integration + publishAll)
//   - ILogger (در V8.2، NoopLogger به‌جای console)
//
// V8.2 Fix: import noopLogger از @yio/core (به‌جای استفاده از console)
// ============================================================

import {
  Context,
  BusinessError,
  OperationResult,
  Events,
  OrderCreatedEvent,
  OrderConfirmedEvent,
  OrderShippedEvent,
  OrderDeliveredEvent,
  OrderCancelledEvent,
  OrderPaidEvent,
  ProductPublishedEvent,
  IOrderRepository,
  IProductRepository,
  IEventBus,
  ITransactionManager,
  IRuleEngine,
  IAuditLogger,
  IInventoryRepository,
  ILogger,
  noopLogger,
} from '@yio/core';

export class OrderEngine {
  /**
   * @param logger در V8.1، دیگر `console` به‌عنوان default استفاده نمی‌شود.
   *                اگر ارائه نشود، NoopLogger (silent) استفاده می‌شود.
   *                در production، باید یک Logger واقعی (PinoLogger) تزریق شود.
   */
  constructor(
    private orderRepo: IOrderRepository,
    private productRepo: IProductRepository,
    private inventoryRepo: IInventoryRepository,
    private eventBus: IEventBus,
    private txManager: ITransactionManager,
    private ruleEngine: IRuleEngine,
    private auditLogger: IAuditLogger,
    private logger: ILogger = noopLogger,
  ) {
    // Subscribe با نام تایپ‌شده (بدون رشته خام)
    this.eventBus.subscribe(Events.ProductPublished, this.onProductPublished.bind(this));
    this.eventBus.subscribe(Events.OrderCancelled, this.onOrderCancelledInternal.bind(this));
  }

  // ============================================================
  // ایجاد سفارش — الگوی کامل با UoW + Rules + Audit + Events
  // ============================================================
  async createOrder(
    input: {
      customerId?: number;
      userId?: number;
      items: Array<{ productId: number; quantity: number; color?: string }>;
      shippingAddress: string;
      shippingCity?: string;
      postalCode?: string;
      recipientName: string;
      recipientPhone: string;
      paymentMethod: string;
      notes?: string;
    },
    ctx: Context,
  ): Promise<{ orderId: number; orderNumber: string }> {
    // ۱) اعتبارسنجی اولیه
    if (!input.items || input.items.length === 0) {
      throw new BusinessError('اقلام سفارش خالی است', 'VALIDATION_ERROR', 'items');
    }

    // ۲) محاسبه مبلغ و آماده‌سازی اقلام
    let totalAmount = 0;
    const orderItems: any[] = [];

    for (const item of input.items) {
      const product = await this.productRepo.findById(item.productId, ctx);
      if (!product || !product.inStock) {
        throw new BusinessError('محصول مورد نظر موجود نیست', 'BUSINESS_ERROR', 'items');
      }
      if (product.stockQuantity > 0 && item.quantity > product.stockQuantity) {
        throw new BusinessError(
          `موجودی محصول «${product.title}» کافی نیست. حداکثر ${product.stockQuantity} عدد.`,
          'BUSINESS_ERROR',
          'items',
        );
      }
      const price = product.discountPrice || product.price;
      const qty = Math.max(1, Math.min(99, item.quantity));
      totalAmount += price * qty;
      orderItems.push({
        productId: product.id,
        productTitle: product.title,
        productImage: product.image,
        price,
        quantity: qty,
        color: item.color,
      });
    }

    // ۳) محاسبه هزینه ارسال
    const shippingCost = totalAmount > 500000 ? 0 : 89000;
    const finalAmount = totalAmount + shippingCost;

    // ۴) ارزیابی Ruleها قبل از ایجاد (pre-create validation)
    const ruleResult = await this.ruleEngine.validate(
      'order.create',
      {
        ...input,
        totalAmount,
        finalAmount,
        items: orderItems,
      },
      ctx,
    );
    if (!ruleResult.success) {
      throw new BusinessError(ruleResult.message || 'قوانین سفارش نقض شد', 'BUSINESS_ERROR');
    }

    // ۵) اجرای عملیات اصلی در یک Transaction (Unit of Work)
    // اگر هر مرحله fail شود، کل تراکنش rollback می‌شود.
    const result = await this.txManager.run(async (tx) => {
      // ۵.۱) تولید شماره سفارش
      const orderNumber = await this.orderRepo.generateOrderNumber(ctx);

      // ۵.۲) ایجاد سفارش + اقلام (در همان tx)
      const created = await this.orderRepo.createWithItems(
        {
          orderNumber,
          customerId: input.customerId,
          userId: input.userId,
          status: 'pending',
          totalAmount,
          shippingCost,
          finalAmount,
          paymentMethod: input.paymentMethod,
          paymentStatus: 'unpaid',
          shippingAddress: input.shippingAddress,
          shippingCity: input.shippingCity,
          recipientName: input.recipientName,
          recipientPhone: input.recipientPhone,
          notes: input.notes,
        },
        orderItems,
        ctx,
        tx,
      );

      // ۵.۳) رزرو موجودی (در همان tx — اگر fail شود، rollback)
      await this.productRepo.reserveStock(
        orderItems.map((i) => ({ productId: i.productId, quantity: i.quantity })),
        ctx,
        tx,
      );

      // ۵.۴) ثبت Inventory Transaction (در همان tx)
      await this.inventoryRepo.recordTransaction(
        {
          itemType: 'product',
          type: 'reservation',
          reason: `رزرو برای سفارش ${orderNumber}`,
          orderId: created.id,
          items: orderItems.map((i) => ({ productId: i.productId, quantity: i.quantity })),
        },
        ctx,
      );

      // ۵.۵) جمع‌آوری Event برای انتشار پس از commit
      tx.collectEvent(
        new OrderCreatedEvent(
          created.id,
          input.customerId || input.userId,
          finalAmount,
          ctx.tenantId,
        ),
      );

      // ۵.۶) جمع‌آوری Audit entry
      tx.collectAudit({
        tenantId: ctx.tenantId,
        userId: ctx.userId,
        userRole: ctx.userRole,
        action: 'order.create',
        entityType: 'Order',
        entityId: created.id,
        operation: 'create',
        metadata: { orderNumber, totalAmount, finalAmount, itemCount: orderItems.length },
        ip: ctx.ip,
        userAgent: ctx.userAgent,
        requestId: ctx.requestId,
        timestamp: new Date(),
      });

      return created;
    });

    // ۶) پس از commit موفق، Eventها publish و Auditها نوشته می‌شوند
    // (در TransactionManager.run مدیریت شده)

    this.logger.info(`[OrderEngine] Order ${result.orderNumber} created (id=${result.id})`);
    return { orderId: result.id, orderNumber: result.orderNumber };
  }

  // ============================================================
  // تأیید سفارش
  // ============================================================
  async confirmOrder(orderId: number, ctx: Context): Promise<OperationResult> {
    const order = await this.orderRepo.findById(orderId, ctx);
    if (!order) throw new BusinessError('سفارش یافت نشد', 'NOT_FOUND');

    if (order.status !== 'pending') {
      throw new BusinessError('سفارش در وضعیت مناسبی برای تأیید نیست', 'BUSINESS_ERROR');
    }

    // در یک tx کوچک
    await this.txManager.run(async (tx) => {
      const oldStatus = order.status;
      await this.orderRepo.updateStatus(orderId, 'confirmed', ctx);

      tx.collectEvent(new OrderConfirmedEvent(orderId, ctx.tenantId));
      tx.collectAudit({
        tenantId: ctx.tenantId,
        userId: ctx.userId,
        action: 'order.confirm',
        entityType: 'Order',
        entityId: orderId,
        operation: 'update',
        changes: { status: { old: oldStatus, new: 'confirmed' } },
        ip: ctx.ip,
        userAgent: ctx.userAgent,
        timestamp: new Date(),
      });
    });

    return { success: true, message: 'سفارش تأیید شد' };
  }

  // ============================================================
  // ارسال سفارش
  // ============================================================
  async shipOrder(orderId: number, trackingCode: string, ctx: Context): Promise<OperationResult> {
    const order = await this.orderRepo.findById(orderId, ctx);
    if (!order) throw new BusinessError('سفارش یافت نشد', 'NOT_FOUND');
    if (order.status !== 'confirmed') {
      throw new BusinessError('سفارش باید ابتدا تأیید شود', 'BUSINESS_ERROR');
    }

    await this.txManager.run(async (tx) => {
      await this.orderRepo.updateTracking(orderId, trackingCode, ctx);
      tx.collectEvent(new OrderShippedEvent(orderId, trackingCode, ctx.tenantId));
      tx.collectAudit({
        tenantId: ctx.tenantId,
        userId: ctx.userId,
        action: 'order.ship',
        entityType: 'Order',
        entityId: orderId,
        operation: 'update',
        changes: { status: { old: 'confirmed', new: 'shipping' }, trackingCode: { old: null, new: trackingCode } },
        ip: ctx.ip,
        userAgent: ctx.userAgent,
        timestamp: new Date(),
      });
    });

    return { success: true, message: 'سفارش ارسال شد' };
  }

  // ============================================================
  // تحویل سفارش
  // ============================================================
  async deliverOrder(orderId: number, ctx: Context): Promise<OperationResult> {
    await this.txManager.run(async (tx) => {
      await this.orderRepo.updateStatus(orderId, 'delivered', ctx);
      tx.collectEvent(new OrderDeliveredEvent(orderId, ctx.tenantId));
      tx.collectAudit({
        tenantId: ctx.tenantId,
        userId: ctx.userId,
        action: 'order.deliver',
        entityType: 'Order',
        entityId: orderId,
        operation: 'update',
        ip: ctx.ip,
        timestamp: new Date(),
      });
    });
    return { success: true, message: 'سفارش تحویل داده شد' };
  }

  // ============================================================
  // لغو سفارش
  // ============================================================
  async cancelOrder(orderId: number, reason: string, ctx: Context): Promise<OperationResult> {
    const order = await this.orderRepo.findById(orderId, ctx);
    if (!order) throw new BusinessError('سفارش یافت نشد', 'NOT_FOUND');
    if (order.status === 'delivered' || order.status === 'cancelled') {
      throw new BusinessError('امکان لغو این سفارش وجود ندارد', 'BUSINESS_ERROR');
    }

    await this.txManager.run(async (tx) => {
      await this.orderRepo.updateStatus(orderId, 'cancelled', ctx);
      tx.collectEvent(new OrderCancelledEvent(orderId, reason, ctx.tenantId));
      tx.collectAudit({
        tenantId: ctx.tenantId,
        userId: ctx.userId,
        action: 'order.cancel',
        entityType: 'Order',
        entityId: orderId,
        operation: 'update',
        changes: { status: { old: order.status, new: 'cancelled' }, reason: { old: null, new: reason } },
        ip: ctx.ip,
        timestamp: new Date(),
      });
    });

    return { success: true, message: 'سفارش لغو شد' };
  }

  // ============================================================
  // پرداخت سفارش (جدید در V8)
  // ============================================================
  async payOrder(
    orderId: number,
    amount: number,
    paymentMethod: string,
    ctx: Context,
  ): Promise<OperationResult> {
    const order = await this.orderRepo.findById(orderId, ctx);
    if (!order) throw new BusinessError('سفارش یافت نشد', 'NOT_FOUND');
    if (order.paymentStatus === 'paid') {
      throw new BusinessError('سفارش قبلاً پرداخت شده', 'BUSINESS_ERROR');
    }

    await this.txManager.run(async (tx) => {
      await this.orderRepo.update(orderId, { paymentStatus: 'paid' }, ctx);
      tx.collectEvent(
        new OrderPaidEvent(orderId, amount, paymentMethod, ctx.tenantId),
      );
      tx.collectAudit({
        tenantId: ctx.tenantId,
        userId: ctx.userId,
        action: 'order.pay',
        entityType: 'Order',
        entityId: orderId,
        operation: 'update',
        changes: {
          paymentStatus: { old: order.paymentStatus, new: 'paid' },
          amount: { old: 0, new: amount },
        },
        ip: ctx.ip,
        timestamp: new Date(),
      });
    });

    return { success: true, message: 'پرداخت سفارش ثبت شد' };
  }

  // ============================================================
  // Event Handlers
  // ============================================================
  private async onProductPublished(event: ProductPublishedEvent): Promise<void> {
    this.logger.info(
      `[OrderEngine] Product ${event.productId} published — available for orders`,
    );
  }

  private async onOrderCancelledInternal(event: OrderCancelledEvent): Promise<void> {
    // آزادسازی رزرو موجودی در صورت لغو سفارش
    const ctx: Context = { tenantId: event.tenantId };
    this.logger.info(
      `[OrderEngine] Order ${event.orderId} cancelled — releasing stock reservation`,
    );
    // در یک پیاده‌سازی کامل، اقلام سفارش خوانده شده و موجودی آزاد می‌شود
    // اینجا فقط log می‌کنیم چون نیاز به Order Items دارد
  }
}
