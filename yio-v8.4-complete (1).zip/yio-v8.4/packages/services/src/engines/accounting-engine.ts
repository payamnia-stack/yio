// ============================================================
// YIO V7 — Accounting Engine
// ============================================================
// موتور حسابداری — دفتر دو طرفه، حساب‌ها، ترازنامه،
// سود و زیان، مدیریت بدهی/بستانکاری، اسناد حسابداری
// ============================================================

import { Context, BusinessError, OperationResult, Events } from '@yio/core';
import { PrismaClient } from '@prisma/client';
import { IEventBus } from '@yio/core';
import {
  AccountingEntryCreatedEvent,
  PaymentReceivedEvent,
  PaymentMadeEvent,
  InvoiceIssuedEvent,
} from '@yio/core';

// ===== Chart of Accounts (ساختار حساب‌ها) =====
export const ACCOUNT_TYPES = {
  ASSET: 'asset',           // دارایی
  LIABILITY: 'liability',   // بدهی
  EQUITY: 'equity',         // سرمایه
  REVENUE: 'revenue',       // درآمد
  EXPENSE: 'expense',       // هزینه
} as const;

export const DEFAULT_ACCOUNTS = {
  // دارایی‌ها (Asset)
  cash: { code: '1001', name: 'صندوق نقدی', type: ACCOUNT_TYPES.ASSET },
  bank: { code: '1002', name: 'حساب بانکی', type: ACCOUNT_TYPES.ASSET },
  accounts_receivable: { code: '1010', name: 'حساب‌های دریافتنی', type: ACCOUNT_TYPES.ASSET },
  inventory: { code: '1020', name: 'موجودی انبار', type: ACCOUNT_TYPES.ASSET },
  finished_goods: { code: '1021', name: 'محصولات تمام‌شده', type: ACCOUNT_TYPES.ASSET },
  raw_materials: { code: '1022', name: 'مواد اولیه', type: ACCOUNT_TYPES.ASSET },
  work_in_progress: { code: '1023', name: 'محصولات در جریان ساخت', type: ACCOUNT_TYPES.ASSET },

  // بدهی‌ها (Liability)
  accounts_payable: { code: '2010', name: 'حساب‌های پرداختنی', type: ACCOUNT_TYPES.LIABILITY },
  tax_payable: { code: '2020', name: 'مالیات پرداختنی', type: ACCOUNT_TYPES.LIABILITY },
  customer_advance: { code: '2030', name: 'پیش‌دریافت از مشتری', type: ACCOUNT_TYPES.LIABILITY },

  // سرمایه (Equity)
  owner_capital: { code: '3001', name: 'سرمایه مالک', type: ACCOUNT_TYPES.EQUITY },
  retained_earnings: { code: '3002', name: 'سود انباشته', type: ACCOUNT_TYPES.EQUITY },

  // درآمد (Revenue)
  sales_revenue: { code: '4001', name: 'فروش محصولات', type: ACCOUNT_TYPES.REVENUE },
  service_revenue: { code: '4002', name: 'درآمد خدمات', type: ACCOUNT_TYPES.REVENUE },
  shipping_revenue: { code: '4003', name: 'درآمد ارسال', type: ACCOUNT_TYPES.REVENUE },
  other_income: { code: '4004', name: 'سایر درآمدها', type: ACCOUNT_TYPES.REVENUE },

  // هزینه (Expense)
  cogs: { code: '5001', name: 'بهای تمام‌شده فروش', type: ACCOUNT_TYPES.EXPENSE },
  material_expense: { code: '5010', name: 'هزینه مواد اولیه', type: ACCOUNT_TYPES.EXPENSE },
  labor_expense: { code: '5020', name: 'هزینه نیروی کار', type: ACCOUNT_TYPES.EXPENSE },
  energy_expense: { code: '5030', name: 'هزینه انرژی', type: ACCOUNT_TYPES.EXPENSE },
  depreciation_expense: { code: '5040', name: 'هزینه استهلاک', type: ACCOUNT_TYPES.EXPENSE },
  packaging_expense: { code: '5050', name: 'هزینه بسته‌بندی', type: ACCOUNT_TYPES.EXPENSE },
  transport_expense: { code: '5060', name: 'هزینه حمل', type: ACCOUNT_TYPES.EXPENSE },
  commission_expense: { code: '5070', name: 'هزینه کمیسیون', type: ACCOUNT_TYPES.EXPENSE },
  tax_expense: { code: '5080', name: 'هزینه مالیات', type: ACCOUNT_TYPES.EXPENSE },
  salary_expense: { code: '5090', name: 'هزینه حقوق', type: ACCOUNT_TYPES.EXPENSE },
  marketing_expense: { code: '5100', name: 'هزینه بازاریابی', type: ACCOUNT_TYPES.EXPENSE },
  misc_expense: { code: '5999', name: 'سایر هزینه‌ها', type: ACCOUNT_TYPES.EXPENSE },
} as const;

// ===== Journal Entry =====
export interface JournalEntry {
  entryNumber: string;
  description: string;
  reference?: string;
  entityType?: string;
  entityId?: number;
  lines: JournalLine[];
  entryDate: Date;
}

export interface JournalLine {
  account: string;       // account code (e.g. '1001')
  accountName: string;
  type: 'debit' | 'credit';
  amount: number;
  description?: string;
}

// ===== Financial Reports =====
export interface TrialBalanceItem {
  account: string;
  accountName: string;
  type: string;
  debit: number;
  credit: number;
  balance: number;
}

export interface ProfitLossReport {
  revenue: { account: string; name: string; amount: number }[];
  expenses: { account: string; name: string; amount: number }[];
  totalRevenue: number;
  totalExpenses: number;
  netProfit: number;
  period: { from: Date; to: Date };
}

export interface BalanceSheetReport {
  assets: { account: string; name: string; amount: number }[];
  liabilities: { account: string; name: string; amount: number }[];
  equity: { account: string; name: string; amount: number }[];
  totalAssets: number;
  totalLiabilities: number;
  totalEquity: number;
  asOf: Date;
}

export class AccountingEngine {
  private entryNumberSeq: number = 0;

  constructor(
    private prisma: PrismaClient,
    private eventBus: IEventBus,
  ) {
    // Subscribe to events that generate accounting entries
    this.eventBus.subscribe(Events.OrderDelivered, this.onOrderDelivered.bind(this));
    this.eventBus.subscribe(Events.OrderCancelled, this.onOrderCancelled.bind(this));
    this.eventBus.subscribe(Events.PurchaseOrderReceived, this.onPurchaseReceived.bind(this));
    this.eventBus.subscribe(Events.ProductionCompleted, this.onProductionCompleted.bind(this));
  }

  // ============================================================
  // 1) ایجاد سند حسابداری (Journal Entry)
  // ============================================================
  async createJournalEntry(entry: JournalEntry, ctx: Context): Promise<{
    entryId: number;
    entryNumber: string;
  }> {
    // 1. اعتبارسنجی: مجموع debit باید برابر credit باشد
    const totalDebit = entry.lines
      .filter(l => l.type === 'debit')
      .reduce((sum, l) => sum + l.amount, 0);
    const totalCredit = entry.lines
      .filter(l => l.type === 'credit')
      .reduce((sum, l) => sum + l.amount, 0);

    if (totalDebit !== totalCredit) {
      throw new BusinessError(
        `ترازنامه: جمع بدهکار (${totalDebit}) با جمع بستانکار (${totalCredit}) برابر نیست`,
        'VALIDATION_ERROR',
        'lines',
      );
    }

    if (entry.lines.length < 2) {
      throw new BusinessError('هر سند باید حداقل ۲ سطر داشته باشد', 'VALIDATION_ERROR', 'lines');
    }

    // 2. تولید شماره سند
    const entryNumber = await this.generateEntryNumber(ctx);

    // 3. ذخیره سطرها در AccountingEntry
    const createdEntries: number[] = [];
    for (const line of entry.lines) {
      const acc = await this.prisma.accountingEntry.create({
        data: {
          tenantId: ctx.tenantId,
          entryNumber: `${entryNumber}/${createdEntries.length + 1}`,
          type: line.type,
          account: line.account,
          description: line.description || entry.description,
          amount: line.amount,
          reference: entry.reference,
          entityType: entry.entityType,
          entityId: entry.entityId,
          entryDate: entry.entryDate,
        },
      });
      createdEntries.push(acc.id);
    }

    // 4. Publish event
    await this.eventBus.publish(new AccountingEntryCreatedEvent(
      entryNumber,
      totalDebit,
      ctx.tenantId,
    ));

    return { entryId: createdEntries[0], entryNumber };
  }

  // ============================================================
  // 2) ثبت فروش (Sales Invoice)
  // ============================================================
  async recordSale(input: {
    orderId: number;
    customerId?: number;
    amount: number;
    taxAmount?: number;
    shippingCost?: number;
    paymentMethod: string;
    isCash?: boolean;
  }, ctx: Context): Promise<OperationResult> {
    const { orderId, amount, taxAmount = 0, shippingCost = 0, isCash = false } = input;

    // سند حسابداری فروش:
    //debit: cash/bank یا accounts_receivable (مبلغ نهایی)
    // credit: sales_revenue (مبلغ فروش), tax_payable (مالیات), shipping_revenue (هزینه ارسال)

    const totalDebit = amount + taxAmount + shippingCost;
    const lines: JournalLine[] = [
      {
        account: isCash ? DEFAULT_ACCOUNTS.cash.code : DEFAULT_ACCOUNTS.accounts_receivable.code,
        accountName: isCash ? DEFAULT_ACCOUNTS.cash.name : DEFAULT_ACCOUNTS.accounts_receivable.name,
        type: 'debit',
        amount: totalDebit,
        description: `فروش سفارش #${orderId}`,
      },
      {
        account: DEFAULT_ACCOUNTS.sales_revenue.code,
        accountName: DEFAULT_ACCOUNTS.sales_revenue.name,
        type: 'credit',
        amount: amount,
        description: `درآمد فروش`,
      },
    ];

    if (taxAmount > 0) {
      lines.push({
        account: DEFAULT_ACCOUNTS.tax_payable.code,
        accountName: DEFAULT_ACCOUNTS.tax_payable.name,
        type: 'credit',
        amount: taxAmount,
        description: `مالیات بر ارزش افزوده`,
      });
    }

    if (shippingCost > 0) {
      lines.push({
        account: DEFAULT_ACCOUNTS.shipping_revenue.code,
        accountName: DEFAULT_ACCOUNTS.shipping_revenue.name,
        type: 'credit',
        amount: shippingCost,
        description: `درآمد ارسال`,
      });
    }

    const { entryNumber } = await this.createJournalEntry({
      entryNumber: '',
      description: `ثبت فروش سفارش #${orderId}`,
      reference: `ORDER-${orderId}`,
      entityType: 'sales_order',
      entityId: orderId,
      lines,
      entryDate: new Date(),
    }, ctx);

    await this.eventBus.publish(new InvoiceIssuedEvent(orderId, totalDebit, ctx.tenantId));

    return {
      success: true,
      message: `سند فروش با شماره ${entryNumber} ثبت شد`,
      data: { entryNumber, amount: totalDebit },
    };
  }

  // ============================================================
  // 3) ثبت دریافت وجه (Payment Received)
  // ============================================================
  async recordPaymentReceived(input: {
    orderId: number;
    amount: number;
    paymentMethod: string;
    isCash?: boolean;
  }, ctx: Context): Promise<OperationResult> {
    const lines: JournalLine[] = [
      {
        account: input.isCash ? DEFAULT_ACCOUNTS.cash.code : DEFAULT_ACCOUNTS.bank.code,
        accountName: input.isCash ? DEFAULT_ACCOUNTS.cash.name : DEFAULT_ACCOUNTS.bank.name,
        type: 'debit',
        amount: input.amount,
        description: `دریافت وجه از سفارش #${input.orderId}`,
      },
      {
        account: DEFAULT_ACCOUNTS.accounts_receivable.code,
        accountName: DEFAULT_ACCOUNTS.accounts_receivable.name,
        type: 'credit',
        amount: input.amount,
        description: `تسویه حساب سفارش #${input.orderId}`,
      },
    ];

    const { entryNumber } = await this.createJournalEntry({
      entryNumber: '',
      description: `دریافت وجه سفارش #${input.orderId}`,
      reference: `PAYMENT-ORDER-${input.orderId}`,
      entityType: 'sales_order',
      entityId: input.orderId,
      lines,
      entryDate: new Date(),
    }, ctx);

    await this.eventBus.publish(new PaymentReceivedEvent(input.orderId, input.amount, ctx.tenantId));

    return {
      success: true,
      message: `دریافت وجه ${input.amount.toLocaleString('fa-IR')} ریال ثبت شد`,
      data: { entryNumber },
    };
  }

  // ============================================================
  // 4) ثبت پرداخت (Payment Made)
  // ============================================================
  async recordPaymentMade(input: {
    purchaseOrderId?: number;
    supplierId?: number;
    amount: number;
    description: string;
    isCash?: boolean;
  }, ctx: Context): Promise<OperationResult> {
    const lines: JournalLine[] = [
      {
        account: input.supplierId
          ? DEFAULT_ACCOUNTS.accounts_payable.code
          : DEFAULT_ACCOUNTS.misc_expense.code,
        accountName: input.supplierId
          ? DEFAULT_ACCOUNTS.accounts_payable.name
          : DEFAULT_ACCOUNTS.misc_expense.name,
        type: 'debit',
        amount: input.amount,
        description: input.description,
      },
      {
        account: input.isCash ? DEFAULT_ACCOUNTS.cash.code : DEFAULT_ACCOUNTS.bank.code,
        accountName: input.isCash ? DEFAULT_ACCOUNTS.cash.name : DEFAULT_ACCOUNTS.bank.name,
        type: 'credit',
        amount: input.amount,
        description: `پرداخت ${input.description}`,
      },
    ];

    const { entryNumber } = await this.createJournalEntry({
      entryNumber: '',
      description: input.description,
      reference: input.purchaseOrderId ? `PO-${input.purchaseOrderId}` : undefined,
      entityType: 'purchase_order',
      entityId: input.purchaseOrderId,
      lines,
      entryDate: new Date(),
    }, ctx);

    if (input.purchaseOrderId) {
      await this.eventBus.publish(new PaymentMadeEvent(
        input.purchaseOrderId,
        input.amount,
        ctx.tenantId,
      ));
    }

    return {
      success: true,
      message: `پرداخت ${input.amount.toLocaleString('fa-IR')} ریال ثبت شد`,
      data: { entryNumber },
    };
  }

  // ============================================================
  // 5) ثبت هزینه (Expense)
  // ============================================================
  async recordExpense(input: {
    account: string; // expense account code
    amount: number;
    description: string;
    isCash?: boolean;
    entityType?: string;
    entityId?: number;
  }, ctx: Context): Promise<OperationResult> {
    const accountInfo = Object.values(DEFAULT_ACCOUNTS).find(a => a.code === input.account);
    if (!accountInfo || accountInfo.type !== ACCOUNT_TYPES.EXPENSE) {
      throw new BusinessError('حساب هزینه معتبر نیست', 'VALIDATION_ERROR', 'account');
    }

    const lines: JournalLine[] = [
      {
        account: input.account,
        accountName: accountInfo.name,
        type: 'debit',
        amount: input.amount,
        description: input.description,
      },
      {
        account: input.isCash ? DEFAULT_ACCOUNTS.cash.code : DEFAULT_ACCOUNTS.bank.code,
        accountName: input.isCash ? DEFAULT_ACCOUNTS.cash.name : DEFAULT_ACCOUNTS.bank.name,
        type: 'credit',
        amount: input.amount,
        description: `پرداخت: ${input.description}`,
      },
    ];

    const { entryNumber } = await this.createJournalEntry({
      entryNumber: '',
      description: input.description,
      entityType: input.entityType,
      entityId: input.entityId,
      lines,
      entryDate: new Date(),
    }, ctx);

    return {
      success: true,
      message: `هزینه ${input.amount.toLocaleString('fa-IR')} ریال ثبت شد`,
      data: { entryNumber },
    };
  }

  // ============================================================
  // 6) گزارش ترازنامه (Trial Balance)
  // ============================================================
  async getTrialBalance(from: Date, to: Date, ctx: Context): Promise<TrialBalanceItem[]> {
    const entries = await this.prisma.accountingEntry.findMany({
      where: {
        tenantId: ctx.tenantId,
        entryDate: { gte: from, lte: to },
      },
      orderBy: { account: 'asc' },
    });

    const grouped = new Map<string, TrialBalanceItem>();

    for (const entry of entries) {
      const key = entry.account;
      if (!grouped.has(key)) {
        const accountInfo = Object.values(DEFAULT_ACCOUNTS).find(a => a.code === entry.account);
        grouped.set(key, {
          account: entry.account,
          accountName: accountInfo?.name || entry.account,
          type: accountInfo?.type || 'unknown',
          debit: 0,
          credit: 0,
          balance: 0,
        });
      }

      const item = grouped.get(key)!;
      if (entry.type === 'debit') {
        item.debit += entry.amount;
      } else {
        item.credit += entry.amount;
      }
      // محاسبه مانده بر اساس نوع حساب
      if (item.type === ACCOUNT_TYPES.ASSET || item.type === ACCOUNT_TYPES.EXPENSE) {
        item.balance = item.debit - item.credit;
      } else {
        item.balance = item.credit - item.debit;
      }
    }

    return Array.from(grouped.values());
  }

  // ============================================================
  // 7) گزارش سود و زیان (Profit & Loss)
  // ============================================================
  async getProfitLoss(from: Date, to: Date, ctx: Context): Promise<ProfitLossReport> {
    const trialBalance = await this.getTrialBalance(from, to, ctx);

    const revenue = trialBalance
      .filter(item => item.type === ACCOUNT_TYPES.REVENUE)
      .map(item => ({
        account: item.account,
        name: item.accountName,
        amount: item.balance,
      }));

    const expenses = trialBalance
      .filter(item => item.type === ACCOUNT_TYPES.EXPENSE)
      .map(item => ({
        account: item.account,
        name: item.accountName,
        amount: item.balance,
      }));

    const totalRevenue = revenue.reduce((sum, r) => sum + r.amount, 0);
    const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);

    return {
      revenue,
      expenses,
      totalRevenue,
      totalExpenses,
      netProfit: totalRevenue - totalExpenses,
      period: { from, to },
    };
  }

  // ============================================================
  // 8) گزارش ترازنامه (Balance Sheet)
  // ============================================================
  async getBalanceSheet(asOf: Date, ctx: Context): Promise<BalanceSheetReport> {
    const trialBalance = await this.getTrialBalance(new Date(0), asOf, ctx);

    const assets = trialBalance
      .filter(item => item.type === ACCOUNT_TYPES.ASSET)
      .map(item => ({ account: item.account, name: item.accountName, amount: item.balance }));

    const liabilities = trialBalance
      .filter(item => item.type === ACCOUNT_TYPES.LIABILITY)
      .map(item => ({ account: item.account, name: item.accountName, amount: item.balance }));

    const equity = trialBalance
      .filter(item => item.type === ACCOUNT_TYPES.EQUITY)
      .map(item => ({ account: item.account, name: item.accountName, amount: item.balance }));

    const totalAssets = assets.reduce((sum, a) => sum + a.amount, 0);
    const totalLiabilities = liabilities.reduce((sum, l) => sum + l.amount, 0);
    const totalEquity = equity.reduce((sum, e) => sum + e.amount, 0);

    return {
      assets,
      liabilities,
      equity,
      totalAssets,
      totalLiabilities,
      totalEquity,
      asOf,
    };
  }

  // ============================================================
  // 9) مانده حساب مشتری
  // ============================================================
  async getCustomerBalance(customerId: number, ctx: Context): Promise<{
    totalDebit: number;
    totalCredit: number;
    balance: number;
  }> {
    const entries = await this.prisma.accountingEntry.findMany({
      where: {
        tenantId: ctx.tenantId,
        entityType: 'sales_order',
        entityId: customerId, // در عمل باید بر اساس customerId فیلتر شود
        account: DEFAULT_ACCOUNTS.accounts_receivable.code,
      },
    });

    const totalDebit = entries.filter(e => e.type === 'debit').reduce((s, e) => s + e.amount, 0);
    const totalCredit = entries.filter(e => e.type === 'credit').reduce((s, e) => s + e.amount, 0);

    return {
      totalDebit,
      totalCredit,
      balance: totalDebit - totalCredit,
    };
  }

  // ============================================================
  // 10) Helpers
  // ============================================================
  private async generateEntryNumber(ctx: Context): Promise<string> {
    const today = new Date();
    const dateStr = today.toISOString().slice(0, 10).replace(/-/g, '');
    const count = await this.prisma.accountingEntry.count({
      where: {
        tenantId: ctx.tenantId,
        entryNumber: { startsWith: `JE-${dateStr}-` },
      },
    });
    return `JE-${dateStr}-${String(count + 1).padStart(4, '0')}`;
  }

  // ============================================================
  // 11) Event Handlers
  // ============================================================
  private async onOrderDelivered(event: any): Promise<void> {
    // ثبت خودکار درآمد فروش پس از تحویل سفارش
    console.log(`[AccountingEngine] Order ${event.orderId} delivered — sales revenue should be recorded`);
  }

  private async onOrderCancelled(event: any): Promise<void> {
    // ثبت معکوس فروش
    console.log(`[AccountingEngine] Order ${event.orderId} cancelled — reversal entry needed`);
  }

  private async onPurchaseReceived(event: any): Promise<void> {
    // ثبت موجودی مواد اولیه
    console.log(`[AccountingEngine] Purchase ${event.poId} received — inventory entry needed`);
  }

  private async onProductionCompleted(event: any): Promise<void> {
    // انتقال از WIP به Finished Goods
    console.log(`[AccountingEngine] Production ${event.workOrderId} completed — WIP to FG transfer needed`);
  }
}
