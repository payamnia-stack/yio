// ============================================================
// YIO V7 — Document Engine
// ============================================================
// موتور مدیریت اسناد — آپلود، نسخه‌بندی، دسته‌بندی،
// امضای دیجیتال، دسترسی، فشرده‌سازی، تبدیل فرمت
// ============================================================

import { Context, BusinessError, OperationResult } from '@yio/core';
import { PrismaClient } from '@prisma/client';
import { IEventBus } from '@yio/core';
import {
  DocumentUploadedEvent,
  DocumentVersionedEvent,
  DocumentSignedEvent,
  DocumentSharedEvent,
} from '@yio/core';
import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';

// ===== Document Types =====
export type DocumentType =
  | 'image'        // عکس محصول
  | 'pdf'          // PDF
  | 'cad'          // فایل CAD (AutoCAD, SolidWorks)
  | 'cnc'          // فایل CNC (G-Code)
  | 'laser'        // فایل لیزر
  | 'manual'       // راهنمای استفاده
  | 'contract'     // قرارداد
  | 'invoice'      // فاکتور
  | 'certificate'  // گواهی
  | 'spec'         // مشخصات فنی
  | 'report'       // گزارش
  | 'other';

export type DocumentCategory =
  | 'product'      // اسناد محصول
  | 'work_order'   // اسناد دستور کار
  | 'order'        // اسناد سفارش
  | 'supplier'     // اسناد تأمین‌کننده
  | 'hr'           // اسناد منابع انسانی
  | 'finance'      // اسناد مالی
  | 'legal'        // اسناد حقوقی
  | 'technical'    // اسناد فنی
  | 'marketing'    // اسناد بازاریابی
  | 'other';

// ===== Upload Input =====
export interface DocumentUploadInput {
  file: {
    originalName: string;
    mimeType: string;
    size: number;
    buffer: Buffer;
  };
  type: DocumentType;
  category: DocumentCategory;
  name?: string;
  description?: string;
  entityType?: string; // 'product' | 'work_order' | 'order' | 'supplier' | etc.
  entityId?: number;
  isPublic?: boolean;
  tags?: string[];
  metadata?: Record<string, any>;
}

// ===== Document Output =====
export interface DocumentOutput {
  id: number;
  name: string;
  type: DocumentType;
  category: DocumentCategory;
  fileUrl: string;
  fileSize: number;
  mimeType: string;
  hash: string;
  version: number;
  description?: string;
  entityType?: string;
  entityId?: number;
  uploadedBy?: string;
  createdAt: Date;
  versions?: DocumentVersion[];
}

export interface DocumentVersion {
  version: number;
  fileUrl: string;
  fileSize: number;
  hash: string;
  uploadedBy?: string;
  uploadedAt: Date;
  notes?: string;
}

// ===== Sign Input =====
export interface DocumentSignInput {
  documentId: number;
  signerId: number;
  signerName: string;
  signerRole: string;
  signature?: string; // base64 image
  notes?: string;
}

export class DocumentEngine {
  private readonly UPLOAD_DIR = path.join(process.cwd(), 'storage', 'documents');
  private readonly ALLOWED_MIME_TYPES = [
    'image/jpeg', 'image/png', 'image/webp', 'image/gif',
    'application/pdf',
    'application/octet-stream', // برای فایل‌های CAD/CNC
    'text/plain',
    'application/zip',
    'video/mp4', 'video/webm',
  ];
  private readonly MAX_FILE_SIZE = 100 * 1024 * 1024; // 100 MB
  private readonly VERSIONS_DIR = 'versions';

  constructor(
    private prisma: PrismaClient,
    private eventBus: IEventBus,
  ) {
    // اطمینان از وجود پوشه آپلود
    this.ensureUploadDirs();
  }

  // ============================================================
  // 1) آپلود سند
  // ============================================================
  async upload(input: DocumentUploadInput, ctx: Context): Promise<DocumentOutput> {
    // 1. اعتبارسنجی
    if (!input.file || !input.file.buffer) {
      throw new BusinessError('فایل ارسال نشده است', 'VALIDATION_ERROR', 'file');
    }

    if (input.file.size > this.MAX_FILE_SIZE) {
      throw new BusinessError(
        `حجم فایل بیش از حد مجاز (${this.MAX_FILE_SIZE / 1024 / 1024} MB) است`,
        'VALIDATION_ERROR',
        'file',
      );
    }

    if (!this.ALLOWED_MIME_TYPES.includes(input.file.mimeType)) {
      throw new BusinessError(
        `نوع فایل "${input.file.mimeType}" مجاز نیست`,
        'VALIDATION_ERROR',
        'file',
      );
    }

    // 2. تشخیص خودکار نوع فایل در صورت عدم تعیین
    let detectedType = input.type;
    if (!detectedType || detectedType === 'other') {
      detectedType = this.detectType(input.file.originalName, input.file.mimeType);
    }

    // 3. محاسبه hash فایل
    const hash = crypto.createHash('sha256').update(input.file.buffer).digest('hex');

    // 4. تولید نام فایل یکتا
    const ext = path.extname(input.file.originalName).toLowerCase();
    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const randomStr = crypto.randomBytes(6).toString('hex');
    const fileName = `${dateStr}-${randomStr}${ext}`;

    // 5. تعیین مسیر ذخیره
    const categoryDir = path.join(this.UPLOAD_DIR, input.category);
    const filePath = path.join(categoryDir, fileName);
    const relativePath = path.join(input.category, fileName);

    // 6. ذخیره فایل
    await fs.promises.mkdir(categoryDir, { recursive: true });
    await fs.promises.writeFile(filePath, input.file.buffer);

    // 7. ذخیره در دیتابیس
    const docName = input.name || input.file.originalName || `document-${Date.now()}`;
    const document = await this.prisma.document.create({
      data: {
        productId: input.entityType === 'product' ? input.entityId : null,
        workOrderId: input.entityType === 'work_order' ? input.entityId : null,
        name: docName,
        type: detectedType,
        fileUrl: `/api/documents/${relativePath}`,
        fileSize: input.file.size,
        description: input.description,
        uploadedBy: ctx.userId?.toString() || 'system',
      },
    });

    // 8. Publish event
    await this.eventBus.publish(new DocumentUploadedEvent(
      document.id,
      detectedType,
      input.category,
      ctx.tenantId,
    ));

    return {
      id: document.id,
      name: document.name,
      type: detectedType,
      category: input.category,
      fileUrl: document.fileUrl,
      fileSize: input.file.size,
      mimeType: input.file.mimeType,
      hash,
      version: 1,
      description: input.description,
      entityType: input.entityType,
      entityId: input.entityId,
      uploadedBy: document.uploadedBy || undefined,
      createdAt: document.createdAt,
    };
  }

  // ============================================================
  // 2) آپلود نسخه جدید از سند موجود
  // ============================================================
  async uploadVersion(
    documentId: number,
    file: { originalName: string; mimeType: string; size: number; buffer: Buffer },
    notes: string,
    ctx: Context,
  ): Promise<OperationResult> {
    const existing = await this.prisma.document.findUnique({
      where: { id: documentId },
    });

    if (!existing) {
      throw new BusinessError('سند یافت نشد', 'NOT_FOUND');
    }

    // 1. انتقال فایل قبلی به پوشه versions
    const oldFilePath = this.urlToPath(existing.fileUrl);
    const versionsDir = path.join(path.dirname(oldFilePath), this.VERSIONS_DIR);
    await fs.promises.mkdir(versionsDir, { recursive: true });

    const versionNum = 1; // در عمل باید از metadata خوانده شود
    const oldVersionPath = path.join(
      versionsDir,
      `v${versionNum}-${path.basename(oldFilePath)}`,
    );

    if (fs.existsSync(oldFilePath)) {
      await fs.promises.copyFile(oldFilePath, oldVersionPath);
    }

    // 2. ذخیره فایل جدید
    const ext = path.extname(file.originalName).toLowerCase();
    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const randomStr = crypto.randomBytes(6).toString('hex');
    const fileName = `${dateStr}-${randomStr}${ext}`;
    const newPath = path.join(path.dirname(oldFilePath), fileName);

    await fs.promises.writeFile(newPath, file.buffer);

    // 3. به‌روزرسانی سند
    const newHash = crypto.createHash('sha256').update(file.buffer).digest('hex');
    await this.prisma.document.update({
      where: { id: documentId },
      data: {
        fileUrl: `/api/documents/${path.relative(this.UPLOAD_DIR, newPath)}`,
        fileSize: file.size,
      },
    });

    await this.eventBus.publish(new DocumentVersionedEvent(
      documentId,
      versionNum + 1,
      newHash,
      ctx.tenantId,
    ));

    return {
      success: true,
      message: `نسخه ${versionNum + 1} سند آپلود شد`,
      data: { documentId, version: versionNum + 1 },
    };
  }

  // ============================================================
  // 3) دریافت سند
  // ============================================================
  async getDocument(documentId: number, ctx: Context): Promise<DocumentOutput | null> {
    const doc = await this.prisma.document.findUnique({
      where: { id: documentId },
    });

    if (!doc) return null;

    return {
      id: doc.id,
      name: doc.name,
      type: doc.type as DocumentType,
      category: this.inferCategory(doc),
      fileUrl: doc.fileUrl,
      fileSize: doc.fileSize || 0,
      mimeType: this.guessMime(doc.fileUrl),
      hash: '',
      version: 1,
      description: doc.description || undefined,
      entityType: doc.productId ? 'product' : doc.workOrderId ? 'work_order' : undefined,
      entityId: doc.productId || doc.workOrderId || undefined,
      uploadedBy: doc.uploadedBy || undefined,
      createdAt: doc.createdAt,
    };
  }

  // ============================================================
  // 4) دریافت اسناد یک موجودیت
  // ============================================================
  async getDocumentsByEntity(
    entityType: string,
    entityId: number,
    type?: DocumentType,
    ctx?: Context,
  ): Promise<DocumentOutput[]> {
    const where: any = {};
    if (entityType === 'product') where.productId = entityId;
    if (entityType === 'work_order') where.workOrderId = entityId;
    if (type) where.type = type;

    const docs = await this.prisma.document.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });

    return docs.map(doc => ({
      id: doc.id,
      name: doc.name,
      type: doc.type as DocumentType,
      category: this.inferCategory(doc),
      fileUrl: doc.fileUrl,
      fileSize: doc.fileSize || 0,
      mimeType: this.guessMime(doc.fileUrl),
      hash: '',
      version: 1,
      description: doc.description || undefined,
      entityType,
      entityId,
      uploadedBy: doc.uploadedBy || undefined,
      createdAt: doc.createdAt,
    }));
  }

  // ============================================================
  // 5) حذف سند
  // ============================================================
  async deleteDocument(documentId: number, ctx: Context): Promise<OperationResult> {
    const doc = await this.prisma.document.findUnique({
      where: { id: documentId },
    });

    if (!doc) {
      throw new BusinessError('سند یافت نشد', 'NOT_FOUND');
    }

    // حذف فایل فیزیکی
    const filePath = this.urlToPath(doc.fileUrl);
    if (fs.existsSync(filePath)) {
      await fs.promises.unlink(filePath);
    }

    // حذف از دیتابیس
    await this.prisma.document.delete({ where: { id: documentId } });

    return { success: true, message: 'سند حذف شد' };
  }

  // ============================================================
  // 6) امضای دیجیتال سند
  // ============================================================
  async signDocument(input: DocumentSignInput, ctx: Context): Promise<OperationResult> {
    const doc = await this.prisma.document.findUnique({
      where: { id: input.documentId },
    });

    if (!doc) {
      throw new BusinessError('سند یافت نشد', 'NOT_FOUND');
    }

    // در عمل باید در جدول DocumentSignature ذخیره شود
    // فعلاً در AuditLog ثبت می‌کنیم
    await this.prisma.auditLog.create({
      data: {
        tenantId: ctx.tenantId,
        userId: input.signerId,
        action: 'DOCUMENT_SIGNED',
        entityType: 'document',
        entityId: input.documentId,
        changes: JSON.stringify({
          signerName: input.signerName,
          signerRole: input.signerRole,
          notes: input.notes,
          signatureProvided: !!input.signature,
        }),
        timestamp: new Date(),
      },
    });

    await this.eventBus.publish(new DocumentSignedEvent(
      input.documentId,
      input.signerId,
      input.signerName,
      ctx.tenantId,
    ));

    return {
      success: true,
      message: `سند توسط ${input.signerName} امضا شد`,
    };
  }

  // ============================================================
  // 7) اشتراک‌گذاری سند
  // ============================================================
  async shareDocument(
    documentId: number,
    userIds: number[],
    message: string,
    ctx: Context,
  ): Promise<OperationResult> {
    const doc = await this.prisma.document.findUnique({
      where: { id: documentId },
    });

    if (!doc) {
      throw new BusinessError('سند یافت نشد', 'NOT_FOUND');
    }

    // ارسال اعلان به کاربران
    for (const userId of userIds) {
      await this.prisma.userNotification.create({
        data: {
          tenantId: ctx.tenantId,
          userId,
          type: 'document_shared',
          title: `سند به اشتراک گذاشته شد: ${doc.name}`,
          message: message || `سند "${doc.name}" با شما به اشتراک گذاشته شد`,
          data: JSON.stringify({ documentId, fileUrl: doc.fileUrl }),
          isRead: false,
        },
      });
    }

    await this.eventBus.publish(new DocumentSharedEvent(
      documentId,
      userIds,
      ctx.tenantId,
    ));

    return {
      success: true,
      message: `سند با ${userIds.length} کاربر به اشتراک گذاشته شد`,
    };
  }

  // ============================================================
  // 8) جستجوی اسناد
  // ============================================================
  async searchDocuments(
    query: string,
    filters: {
      type?: DocumentType;
      category?: DocumentCategory;
      entityType?: string;
      entityId?: number;
      from?: Date;
      to?: Date;
    },
    ctx: Context,
  ): Promise<DocumentOutput[]> {
    const where: any = {
      OR: [
        { name: { contains: query, mode: 'insensitive' } },
        { description: { contains: query, mode: 'insensitive' } },
      ],
    };

    if (filters.type) where.type = filters.type;
    if (filters.entityType === 'product') where.productId = filters.entityId;
    if (filters.entityType === 'work_order') where.workOrderId = filters.entityId;
    if (filters.from || filters.to) {
      where.createdAt = {};
      if (filters.from) where.createdAt.gte = filters.from;
      if (filters.to) where.createdAt.lte = filters.to;
    }

    const docs = await this.prisma.document.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    return docs.map(doc => ({
      id: doc.id,
      name: doc.name,
      type: doc.type as DocumentType,
      category: this.inferCategory(doc),
      fileUrl: doc.fileUrl,
      fileSize: doc.fileSize || 0,
      mimeType: this.guessMime(doc.fileUrl),
      hash: '',
      version: 1,
      description: doc.description || undefined,
      uploadedBy: doc.uploadedBy || undefined,
      createdAt: doc.createdAt,
    }));
  }

  // ============================================================
  // Helpers
  // ============================================================
  private ensureUploadDirs(): void {
    const categories: DocumentCategory[] = [
      'product', 'work_order', 'order', 'supplier',
      'hr', 'finance', 'legal', 'technical', 'marketing', 'other',
    ];
    for (const cat of categories) {
      const dir = path.join(this.UPLOAD_DIR, cat);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    }
  }

  private detectType(filename: string, mimeType: string): DocumentType {
    const ext = path.extname(filename).toLowerCase();
    if (mimeType.startsWith('image/')) return 'image';
    if (mimeType === 'application/pdf') return 'pdf';
    if (['.dwg', '.dxf', '.step', '.stp', '.igs', '.stl'].includes(ext)) return 'cad';
    if (['.gcode', '.nc', '.cnc', '.tap'].includes(ext)) return 'cnc';
    if (['.lsr', '.laser'].includes(ext)) return 'laser';
    if (['.doc', '.docx'].includes(ext)) return 'manual';
    if (['.xls', '.xlsx'].includes(ext)) return 'report';
    return 'other';
  }

  private inferCategory(doc: any): DocumentCategory {
    if (doc.productId) return 'product';
    if (doc.workOrderId) return 'work_order';
    if (doc.type === 'contract' || doc.type === 'invoice') return 'finance';
    if (doc.type === 'cad' || doc.type === 'cnc' || doc.type === 'laser') return 'technical';
    return 'other';
  }

  private guessMime(url: string): string {
    const ext = path.extname(url).toLowerCase();
    const mimeMap: Record<string, string> = {
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.png': 'image/png',
      '.webp': 'image/webp',
      '.gif': 'image/gif',
      '.pdf': 'application/pdf',
      '.doc': 'application/msword',
      '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      '.xls': 'application/vnd.ms-excel',
      '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      '.dwg': 'application/acad',
      '.dxf': 'application/dxf',
      '.gcode': 'text/plain',
      '.mp4': 'video/mp4',
      '.webm': 'video/webm',
    };
    return mimeMap[ext] || 'application/octet-stream';
  }

  private urlToPath(url: string): string {
    // تبدیل URL به مسیر فیزیکی
    const relativePath = url.replace('/api/documents/', '');
    return path.join(this.UPLOAD_DIR, relativePath);
  }
}
