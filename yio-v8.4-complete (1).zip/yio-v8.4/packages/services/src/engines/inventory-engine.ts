// ============================================================
// YIO V8 — Inventory Engine (Upgraded — Typed Events)
// ============================================================
// موتور مدیریت انبار — ورود/خروج، رزرو، هشدار موجودی
// در V8، نام Eventها به‌جای رشته خام از Events const تایپ‌شده استفاده می‌کنند.
// ============================================================

import { Context, BusinessError, OperationResult, Events } from '@yio/core';
import { PrismaClient } from '@prisma/client';
import { IEventBus } from '@yio/core';
import {
  StockUpdatedEvent,
  LowStockAlertEvent,
  StockReservedEvent,
  OrderCreatedEvent,
  OrderCancelledEvent,
} from '@yio/core';

export class InventoryEngine {
  constructor(
    private prisma: PrismaClient,
    private eventBus: IEventBus,
  ) {
    // ← در V8 نام Event تایپ‌شده است (Events.OrderCreated به‌جای 'order.created')
    this.eventBus.subscribe(Events.OrderCreated, this.onOrderCreated.bind(this));
    this.eventBus.subscribe(Events.OrderCancelled, this.onOrderCancelled.bind(this));
  }

  // ===== ثبت ورود کالا =====
  async stockIn(input: {
    itemType: 'wood' | 'paint' | 'material' | 'product';
    itemId: number;
    quantity: number;
    reason?: string;
    supplierId?: number;
    purchaseOrderId?: number;
  }, ctx: Context): Promise<OperationResult> {
    if (input.quantity <= 0) {
      throw new BusinessError('تعداد باید بزرگتر از صفر باشد', 'VALIDATION_ERROR');
    }

    // آپدیت موجودی
    const newQuantity = await this.updateStock(input.itemType, input.itemId, input.quantity, ctx);

    // ثبت تراکنش
    await this.prisma.inventoryTransaction.create({
      data: {
        itemType: input.itemType,
        itemId: input.itemId,
        type: 'in',
        quantity: input.quantity,
        reason: input.reason || 'ورود کالا',
        supplierId: input.supplierId,
        purchaseOrderId: input.purchaseOrderId,
        tenantId: ctx.tenantId,
      },
    });

    await this.eventBus.publish(new StockUpdatedEvent(
      input.itemType, input.itemId, input.quantity, newQuantity, ctx.tenantId,
    ));

    return { success: true, message: `${input.quantity} واحد وارد انبار شد` };
  }

  // ===== ثبت خروج کالا =====
  async stockOut(input: {
    itemType: 'wood' | 'paint' | 'material' | 'product';
    itemId: number;
    quantity: number;
    reason?: string;
    workOrderId?: number;
  }, ctx: Context): Promise<OperationResult> {
    if (input.quantity <= 0) {
      throw new BusinessError('تعداد باید بزرگتر از صفر باشد', 'VALIDATION_ERROR');
    }

    // بررسی موجودی
    const currentStock = await this.getStock(input.itemType, input.itemId, ctx);
    if (currentStock < input.quantity) {
      throw new BusinessError(`موجودی کافی نیست. موجودی فعلی: ${currentStock}`, 'BUSINESS_ERROR');
    }

    // کاهش موجودی
    const newQuantity = await this.updateStock(input.itemType, input.itemId, -input.quantity, ctx);

    // ثبت تراکنش
    await this.prisma.inventoryTransaction.create({
      data: {
        itemType: input.itemType,
        itemId: input.itemId,
        type: 'out',
        quantity: input.quantity,
        reason: input.reason || 'خروج کالا',
        workOrderId: input.workOrderId,
        tenantId: ctx.tenantId,
      },
    });

    await this.eventBus.publish(new StockUpdatedEvent(
      input.itemType, input.itemId, -input.quantity, newQuantity, ctx.tenantId,
    ));

    // بررسی آستانه هشدار
    await this.checkLowStock(input.itemType, input.itemId, newQuantity, ctx);

    return { success: true, message: `${input.quantity} واحد از انبار خارج شد` };
  }

  // ===== رزرو موجودی =====
  async reserveStock(items: Array<{ productId: number; quantity: number }>, orderId: number, ctx: Context): Promise<OperationResult> {
    for (const item of items) {
      const product = await this.prisma.product.findFirst({
        where: { id: item.productId, tenantId: ctx.tenantId },
      });

      if (!product || product.stockQuantity < item.quantity) {
        throw new BusinessError(`موجودی محصول کافی نیست`, 'BUSINESS_ERROR');
      }

      // کاهش موقت موجودی (رزرو)
      await this.prisma.product.update({
        where: { id: item.productId },
        data: { stockQuantity: { decrement: item.quantity } },
      });

      await this.eventBus.publish(new StockReservedEvent(
        item.productId, item.quantity, orderId, ctx.tenantId,
      ));
    }

    return { success: true, message: 'موجودی رزرو شد' };
  }

  // ===== آزادسازی رزرو =====
  async releaseReservedStock(items: Array<{ productId: number; quantity: number }>, ctx: Context): Promise<OperationResult> {
    for (const item of items) {
      const product = await this.prisma.product.findFirst({ where: { id: item.productId, tenantId: ctx.tenantId } });
      if (!product) throw new BusinessError('محصول یافت نشد', 'NOT_FOUND');
      await this.prisma.product.update({
        where: { id: item.productId },
        data: { stockQuantity: { increment: item.quantity }, inStock: true },
      });
    }
    return { success: true, message: 'رزرو آزاد شد' };
  }

  // ===== دریافت موجودی فعلی =====
  async getStock(itemType: string, itemId: number, ctx: Context): Promise<number> {
    if (itemType === 'product') {
      const p = await this.prisma.product.findFirst({ where: { id: itemId, tenantId: ctx.tenantId } });
      return p?.stockQuantity || 0;
    }
    if (itemType === 'wood') {
      const w = await this.prisma.woodStock.findFirst({ where: { id: itemId, tenantId: ctx.tenantId } });
      return w?.quantity || 0;
    }
    if (itemType === 'paint') {
      const p = await this.prisma.paintStock.findFirst({ where: { id: itemId, tenantId: ctx.tenantId } });
      return p?.quantity || 0;
    }
    return 0;
  }

  // ===== آپدیت موجودی =====
  private async updateStock(itemType: string, itemId: number, change: number, ctx: Context): Promise<number> {
    let newQuantity = 0;

    if (itemType === 'product') {
      const existing = await this.prisma.product.findFirst({ where: { id: itemId, tenantId: ctx.tenantId } });
      if (!existing) throw new BusinessError('محصول یافت نشد', 'NOT_FOUND');
      const updated = await this.prisma.product.update({
        where: { id: itemId },
        data: {
          stockQuantity: { increment: change },
          inStock: true,
        },
      });
      newQuantity = updated.stockQuantity;
      // آپدیت inStock
      await this.prisma.product.update({
        where: { id: itemId },
        data: { inStock: newQuantity > 0 },
      });
    } else if (itemType === 'wood') {
      const updated = await this.prisma.woodStock.update({
        where: { id: itemId },
        data: { quantity: { increment: change } },
      });
      newQuantity = updated.quantity;
    } else if (itemType === 'paint') {
      const updated = await this.prisma.paintStock.update({
        where: { id: itemId },
        data: { quantity: { increment: change } },
      });
      newQuantity = updated.quantity;
    }

    return newQuantity;
  }

  // ===== بررسی آستانه هشدار =====
  private async checkLowStock(itemType: string, itemId: number, currentQuantity: number, ctx: Context): Promise<void> {
    const thresholds: Record<string, number> = {
      product: 5,
      wood: 3,
      paint: 2,
    };

    const threshold = thresholds[itemType] || 5;
    if (currentQuantity <= threshold) {
      let itemName = '';
      if (itemType === 'product') {
        const p = await this.prisma.product.findFirst({ where: { id: itemId, tenantId: ctx.tenantId } });
        itemName = p?.title || '';
      }

      await this.eventBus.publish(new LowStockAlertEvent(
        itemType, itemId, itemName, currentQuantity, threshold, ctx.tenantId,
      ));
    }
  }

  // ===== Event Handlers =====
  private async onOrderCreated(event: OrderCreatedEvent): Promise<void> {
    console.log(`[InventoryEngine] Order ${event.orderId} created — reserving stock`);
    // رزرو موجودی در اینجا انجام می‌شود
  }

  private async onOrderCancelled(event: OrderCancelledEvent): Promise<void> {
    console.log(`[InventoryEngine] Order ${event.orderId} cancelled — releasing reserved stock (${event.reason})`);
    // آزادسازی رزرو در اینجا انجام می‌شود
  }
}
