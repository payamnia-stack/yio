// ============================================================
// YIO V7 — Production Engine
// ============================================================
// موتور مدیریت تولید — دستورات، بچ، مسیر تولید
// ============================================================

import { Context, BusinessError, OperationResult, Events } from '@yio/core';
import { PrismaClient } from '@prisma/client';
import { IEventBus } from '@yio/core';
import {
  WorkOrderCreatedEvent,
  ProductionStartedEvent,
  ProductionCompletedEvent,
  ProductionStepCompletedEvent,
} from '@yio/core';

export class ProductionEngine {
  constructor(
    private prisma: PrismaClient,
    private eventBus: IEventBus,
  ) {
    // وقتی سفارش تأیید می‌شود، بررسی کن آیا نیاز به تولید است
    this.eventBus.subscribe(Events.OrderConfirmed, this.onOrderConfirmed.bind(this));
  }

  // ===== ایجاد دستور تولید =====
  async createWorkOrder(input: {
    productId: number;
    quantity: number;
    orderId?: number;
    priority?: 'low' | 'normal' | 'high' | 'urgent';
    expectedDate?: Date;
    assignedTo?: string;
    notes?: string;
  }, ctx: Context): Promise<{ workOrderId: number; woNumber: string }> {
    if (input.quantity <= 0) {
      throw new BusinessError('تعداد باید بزرگتر از صفر باشد', 'VALIDATION_ERROR', 'quantity');
    }

    // تولید شماره دستور
    const count = await this.prisma.workOrder.count({ where: { tenantId: ctx.tenantId } });
    const woNumber = `WO-${new Date().getFullYear()}-${String(count + 1).padStart(4, '0')}`;

    const wo = await this.prisma.workOrder.create({
      data: {
        woNumber,
        productId: input.productId,
        orderId: input.orderId,
        quantity: input.quantity,
        priority: input.priority || 'normal',
        status: 'planned',
        expectedDate: input.expectedDate,
        assignedTo: input.assignedTo,
        notes: input.notes,
        tenantId: ctx.tenantId,
      },
    });

    // ایجاد مراحل تولید از روی Routing
    const routing = await this.prisma.routing.findFirst({
      where: { productId: input.productId, isActive: true },
      include: { steps: { where: { isActive: true }, orderBy: { stepOrder: 'asc' } } },
    }) as any;

    if (routing && routing.steps && routing.steps.length > 0) {
      for (const step of routing.steps) {
        await this.prisma.workOrderStep.create({
          data: {
            workOrderId: wo.id,
            routingStepId: step.id,
            workStationId: step.workStationId,
            machineId: step.machineId,
            stepOrder: step.stepOrder,
            name: step.name,
            status: 'pending',
            quantityDone: 0,
            quantityReject: 0,
          },
        });
      }
    }

    await this.eventBus.publish(new WorkOrderCreatedEvent(
      wo.id, input.productId, input.quantity, ctx.tenantId,
    ));

    return { workOrderId: wo.id, woNumber };
  }

  // ===== شروع تولید =====
  async startProduction(workOrderId: number, ctx: Context): Promise<OperationResult> {
    const wo = await this.prisma.workOrder.findFirst({
      where: { id: workOrderId, tenantId: ctx.tenantId },
    });
    if (!wo) throw new BusinessError('دستور تولید یافت نشد', 'NOT_FOUND');
    if (wo.status !== 'planned') throw new BusinessError('دستور در وضعیت شروع نیست', 'BUSINESS_ERROR');

    await this.prisma.workOrder.update({
      where: { id: workOrderId },
      data: { status: 'in_progress', startDate: new Date() },
    });

    // اولین مرحله را فعال کن
    const firstStep = await this.prisma.workOrderStep.findFirst({
      where: { workOrderId, stepOrder: 1 },
    });
    if (firstStep) {
      await this.prisma.workOrderStep.update({
        where: { id: firstStep.id },
        data: { status: 'in_progress', startTime: new Date() },
      });
    }

    await this.eventBus.publish(new ProductionStartedEvent(workOrderId, ctx.tenantId));
    return { success: true, message: 'تولید شروع شد' };
  }

  // ===== تکمیل یک مرحله =====
  async completeStep(workOrderId: number, stepOrder: number, input: {
    quantityDone: number;
    quantityReject?: number;
    operatorId?: number;
    operatorName?: string;
    notes?: string;
  }, ctx: Context): Promise<OperationResult> {
    const step = await this.prisma.workOrderStep.findFirst({
      where: { workOrderId, stepOrder },
    });
    if (!step) throw new BusinessError('مرحله یافت نشد', 'NOT_FOUND');
    if (step.status !== 'in_progress') throw new BusinessError('مرحله در حال اجرا نیست', 'BUSINESS_ERROR');

    await this.prisma.workOrderStep.update({
      where: { id: step.id },
      data: {
        status: 'completed',
        endTime: new Date(),
        actualTime: step.startTime ? Math.floor((Date.now() - step.startTime.getTime()) / 60000) : null,
        quantityDone: input.quantityDone,
        quantityReject: input.quantityReject || 0,
        operatorId: input.operatorId,
        operatorName: input.operatorName,
        notes: input.notes,
      },
    });

    await this.eventBus.publish(new ProductionStepCompletedEvent(
      workOrderId, step.name, ctx.tenantId,
    ));

    // فعال‌سازی مرحله بعدی
    const nextStep = await this.prisma.workOrderStep.findFirst({
      where: { workOrderId, stepOrder: stepOrder + 1 },
    });
    if (nextStep) {
      await this.prisma.workOrderStep.update({
        where: { id: nextStep.id },
        data: { status: 'in_progress', startTime: new Date() },
      });
      return { success: true, message: `مرحله «${step.name}» تکمیل شد. مرحله بعدی: ${nextStep.name}` };
    }

    // اگر مرحله آخر بود، تولید را تکمیل کن
    return this.completeProduction(workOrderId, input.quantityDone, ctx);
  }

  // ===== تکمیل تولید =====
  async completeProduction(workOrderId: number, producedQuantity: number, ctx: Context): Promise<OperationResult> {
    await this.prisma.workOrder.update({
      where: { id: workOrderId },
      data: { status: 'completed', endDate: new Date() },
    });

    // افزایش موجودی محصول
    const wo = await this.prisma.workOrder.findFirst({
      where: { id: workOrderId, tenantId: ctx.tenantId },
    });
    if (wo) {
      const product = await this.prisma.product.findFirst({ where: { id: wo.productId, tenantId: ctx.tenantId } });
      if (product) {
        const newStock = product.stockQuantity + producedQuantity;
        await this.prisma.product.update({
          where: { id: wo.productId },
          data: { stockQuantity: newStock, inStock: newStock > 0 },
        });
      }
    }

    await this.eventBus.publish(new ProductionCompletedEvent(workOrderId, producedQuantity, ctx.tenantId));
    return { success: true, message: 'تولید تکمیل شد و موجودی به‌روزرسانی شد' };
  }

  // ===== توقف موقت =====
  async pauseProduction(workOrderId: number, reason: string, ctx: Context): Promise<OperationResult> {
    await this.prisma.workOrder.update({
      where: { id: workOrderId },
      data: { status: 'paused', notes: reason },
    });
    return { success: true, message: 'تولید متوقف شد' };
  }

  // ===== Event Handler: سفارش تأیید شد =====
  private async onOrderConfirmed(event: any): Promise<void> {
    // بررسی آیا محصولات سفارش نیاز به تولید دارند
    console.log(`[ProductionEngine] Order ${event.orderId} confirmed — checking production needs`);
    // در اینجا می‌توان بررسی کرد که آیا موجودی کافی است یا نیاز به دستور تولید جدید
  }
}
