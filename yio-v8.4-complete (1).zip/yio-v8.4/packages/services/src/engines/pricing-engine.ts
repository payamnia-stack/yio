// ============================================================
// YIO V7 — Pricing Engine
// ============================================================
// موتور قیمت‌گذاری — محاسبه قیمت تمام شده، قیمت پیشنهادی،
// تخفیف‌های پویا، قیمت‌گذاری عمده‌فروشان، تاریخچه قیمت
// ============================================================

import { Context, BusinessError, OperationResult, Events } from '@yio/core';
import { PrismaClient } from '@prisma/client';
import { IEventBus, IRuleEngine } from '@yio/core';
import {
  PriceCalculatedEvent,
  PriceChangedEvent,
  DiscountAppliedEvent,
  CostUpdatedEvent,
} from '@yio/core';

// ===== Cost Components =====
export interface CostBreakdown {
  materialCost: number;
  laborCost: number;
  energyCost: number;
  depreciationCost: number;
  packagingCost: number;
  wasteCost: number;
  transportCost: number;
  commissionCost: number;
  taxCost: number;
  totalCost: number;
  profitMargin: number; // percentage (0.2 = 20%)
  suggestedPrice: number;
}

// ===== Pricing Input =====
export interface PricingInput {
  productId: number;
  quantity: number;
  customerId?: number;
  isWholesale?: boolean;
  couponCode?: string;
  customOptions?: {
    woodType?: string;
    color?: string;
    engraving?: string;
    packaging?: string;
    priceAdjustment?: number;
  };
}

// ===== Pricing Result =====
export interface PricingResult {
  basePrice: number;
  unitPrice: number;
  quantity: number;
  subtotal: number;
  discountRate: number;
  discountAmount: number;
  couponDiscount: number;
  shippingCost: number;
  taxAmount: number;
  totalAmount: number;
  finalAmount: number;
  costBreakdown?: CostBreakdown;
  appliedRules: string[];
}

export class PricingEngine {
  private priceCache: Map<string, { result: PricingResult; expires: number }> = new Map();
  private readonly CACHE_TTL = 60 * 1000; // 1 minute

  constructor(
    private prisma: PrismaClient,
    private eventBus: IEventBus,
    private ruleEngine?: IRuleEngine,
  ) {
    // Subscribe to events that may affect pricing
    this.eventBus.subscribe(Events.StockUpdated, this.onStockUpdated.bind(this));
    this.eventBus.subscribe(Events.ProductPublished, this.onProductPublished.bind(this));
  }

  // ============================================================
  // 1) محاسبه قیمت برای یک محصول/کمیت
  // ============================================================
  async calculatePrice(input: PricingInput, ctx: Context): Promise<PricingResult> {
    const cacheKey = `price:${ctx.tenantId}:${input.productId}:${input.quantity}:${input.isWholesale}:${input.couponCode || ''}`;
    const cached = this.priceCache.get(cacheKey);
    if (cached && cached.expires > Date.now()) {
      return cached.result;
    }

    // 1. دریافت محصول
    const product = await this.prisma.product.findFirst({
      where: { id: input.productId, tenantId: ctx.tenantId },
      include: { costFormula: true },
    });

    if (!product) {
      throw new BusinessError('محصول یافت نشد', 'NOT_FOUND', 'productId');
    }

    if (!product.isPublished) {
      throw new BusinessError('محصول منتشر نشده است', 'BUSINESS_ERROR', 'productId');
    }

    // 2. قیمت پایه (با توجه به تخفیف فعلی محصول)
    const basePrice = product.discountPrice || product.salePrice || product.price;
    const quantity = Math.max(1, Math.min(999, input.quantity));
    const subtotal = basePrice * quantity;

    // 3. اعمال تخفیف‌های پویا (DiscountRule)
    const { discountRate, discountAmount, appliedRules } = await this.calculateDynamicDiscount(
      product,
      quantity,
      input,
      ctx,
    );

    // 4. اعمال تخفیف عمده‌فروشی
    let wholesaleDiscount = 0;
    if (input.isWholesale) {
      const customer = input.customerId
        ? await this.prisma.user.findUnique({ where: { id: input.customerId } })
        : null;
      if (customer?.isWholesale) {
        wholesaleDiscount = Math.floor(subtotal * (customer.wholesaleDiscount / 100));
      }
    }

    // 5. اعمال کد تخفیف
    const couponDiscount = input.couponCode
      ? await this.applyCoupon(input.couponCode, subtotal, ctx)
      : 0;

    // 6. محاسبه هزینه ارسال
    const shippingCost = await this.calculateShipping(subtotal - discountAmount - wholesaleDiscount - couponDiscount, ctx);

    // 7. محاسبه مالیات
    const taxAmount = await this.calculateTax(subtotal - discountAmount - wholesaleDiscount - couponDiscount, ctx);

    // 8. تنظیمات سفارشی (CustomOrder)
    let customAdjustment = 0;
    if (input.customOptions?.priceAdjustment) {
      customAdjustment = input.customOptions.priceAdjustment;
    }

    // 9. محاسبه نهایی
    const totalAmount = subtotal - discountAmount - wholesaleDiscount - couponDiscount + customAdjustment;
    const finalAmount = totalAmount + shippingCost + taxAmount;

    const result: PricingResult = {
      basePrice: product.price,
      unitPrice: basePrice,
      quantity,
      subtotal,
      discountRate,
      discountAmount: discountAmount + wholesaleDiscount,
      couponDiscount,
      shippingCost,
      taxAmount,
      totalAmount,
      finalAmount: Math.max(0, finalAmount),
      appliedRules,
    };

    // Cache result
    this.priceCache.set(cacheKey, { result, expires: Date.now() + this.CACHE_TTL });

    // Publish event
    await this.eventBus.publish(new PriceCalculatedEvent(
      input.productId,
      result.finalAmount,
      ctx.tenantId,
    ));

    return result;
  }

  // ============================================================
  // 2) محاسبه قیمت تمام شده (CostFormula)
  // ============================================================
  async calculateCost(productId: number, ctx: Context): Promise<CostBreakdown> {
    const product = await this.prisma.product.findFirst({
      where: { id: productId, tenantId: ctx.tenantId },
      include: {
        bom: { include: { items: true } },
        routings: { include: { steps: true } },
        costFormula: true,
      },
    });

    if (!product) {
      throw new BusinessError('محصول یافت نشد', 'NOT_FOUND', 'productId');
    }

    // 1. هزینه مواد اولیه (از BOM)
    let materialCost = 0;
    if (product.bom?.items) {
      for (const item of product.bom.items) {
        materialCost += item.totalCost || (item.unitCost || 0) * item.quantity;
      }
    }

    // 2. هزینه نیروی کار (از RoutingStep × hourlyRate)
    let laborCost = 0;
    let totalTime = 0;
    if (product.routings?.[0]?.steps) {
      for (const step of product.routings[0].steps) {
        laborCost += step.cost || 0;
        totalTime += step.standardTime || 0;
      }
    }

    // 3. هزینه انرژی (تقریبی: 10% هزینه نیروی کار)
    const energyCost = Math.floor(laborCost * 0.1);

    // 4. استهلاک ماشین‌آلات (تقریبی: 5% هزینه مواد)
    const depreciationCost = Math.floor(materialCost * 0.05);

    // 5. هزینه بسته‌بندی (پیش‌فرض: 50,000 ریال)
    const packagingCost = 50000;

    // 6. هزینه ضایعات (تقریبی: 8% هزینه مواد)
    const wasteCost = Math.floor(materialCost * 0.08);

    // 7. هزینه حمل (پیش‌فرض: 30,000 ریال)
    const transportCost = 30000;

    // 8. کمیسیون فروش (5%)
    const commissionCost = Math.floor(product.price * 0.05);

    // 9. مالیات (9% VAT)
    const taxCost = Math.floor(product.price * 0.09);

    // 10. مجموع هزینه‌ها
    const totalCost =
      materialCost +
      laborCost +
      energyCost +
      depreciationCost +
      packagingCost +
      wasteCost +
      transportCost +
      commissionCost +
      taxCost;

    // 11. حاشیه سود پیشنهادی (20%)
    const profitMargin = 0.2;
    const suggestedPrice = Math.floor(totalCost * (1 + profitMargin));

    const breakdown: CostBreakdown = {
      materialCost,
      laborCost,
      energyCost,
      depreciationCost,
      packagingCost,
      wasteCost,
      transportCost,
      commissionCost,
      taxCost,
      totalCost,
      profitMargin,
      suggestedPrice,
    };

    // ذخیره/به‌روزرسانی CostFormula
    await this.prisma.costFormula.upsert({
      where: { productId: product.id },
      update: { ...breakdown, updatedAt: new Date() },
      create: { productId: product.id, ...breakdown },
    });

    // Publish event
    await this.eventBus.publish(new CostUpdatedEvent(productId, totalCost, ctx.tenantId));

    return breakdown;
  }

  // ============================================================
  // 3) به‌روزرسانی قیمت محصول
  // ============================================================
  async updateProductPrice(
    productId: number,
    newPrice: number,
    reason: string,
    ctx: Context,
  ): Promise<OperationResult> {
    if (newPrice < 0) {
      throw new BusinessError('قیمت نمی‌تواند منفی باشد', 'VALIDATION_ERROR', 'price');
    }

    const product = await this.prisma.product.findFirst({
      where: { id: productId, tenantId: ctx.tenantId },
    });

    if (!product) {
      throw new BusinessError('محصول یافت نشد', 'NOT_FOUND');
    }

    const oldPrice = product.price;

    // ثبت در PriceHistory
    await this.prisma.priceHistory.create({
      data: {
        productId,
        oldPrice,
        newPrice,
        reason,
        changedBy: ctx.userId?.toString() || 'system',
      },
    });

    // به‌روزرسانی قیمت محصول
    await this.prisma.product.update({
      where: { id: productId },
      data: { price: newPrice },
    });

    // پاک کردن cache قیمت
    this.invalidatePriceCache(productId);

    // Publish event
    await this.eventBus.publish(new PriceChangedEvent(
      productId,
      oldPrice,
      newPrice,
      reason,
      ctx.tenantId,
    ));

    return {
      success: true,
      message: `قیمت محصول از ${oldPrice.toLocaleString('fa-IR')} به ${newPrice.toLocaleString('fa-IR')} تغییر یافت`,
    };
  }

  // ============================================================
  // 4) اعمال تخفیف گروهی
  // ============================================================
  async applyBulkDiscount(
    productIds: number[],
    discountPercent: number,
    startDate: Date,
    endDate: Date,
    ctx: Context,
  ): Promise<OperationResult> {
    if (discountPercent < 0 || discountPercent > 100) {
      throw new BusinessError('درصد تخفیف باید بین 0 و 100 باشد', 'VALIDATION_ERROR', 'discountPercent');
    }

    // ایجاد قانون تخفیف
    const rule = await this.prisma.discountRule.create({
      data: {
        tenantId: ctx.tenantId,
        name: `تخفیف گروهی ${discountPercent}% (${productIds.length} محصول)`,
        type: 'percentage',
        value: discountPercent,
        minQuantity: 1,
        startDate,
        endDate,
        isActive: true,
      },
    });

    // اعمال تخفیف روی محصولات
    const now = new Date();
    if (startDate <= now && now <= endDate) {
      for (const productId of productIds) {
        const product = await this.prisma.product.findFirst({ where: { id: productId, tenantId: ctx.tenantId }, include: { productVariants: { where: { isActive: true }, orderBy: [{ isDefault: 'desc' }, { id: 'asc' }], take: 1 } } });
        if (product) {
          const discountPrice = Math.floor(product.price * (1 - discountPercent / 100));
          await this.prisma.product.update({
            where: { id: productId },
            data: { discountPrice, discountPercent },
          });
          const variant = product.productVariants?.[0];
          if (variant) {
            await this.prisma.productVariant.update({
              where: { id: variant.id },
              data: { salePrice: discountPrice },
            });
          }
          this.invalidatePriceCache(productId);
        }
      }
    }

    return {
      success: true,
      message: `تخفیف ${discountPercent}% روی ${productIds.length} محصول اعمال شد`,
      data: { ruleId: rule.id },
    };
  }

  // ============================================================
  // 5) تخفیف‌های پویا (DiscountRule)
  // ============================================================
  private async calculateDynamicDiscount(
    product: any,
    quantity: number,
    input: PricingInput,
    ctx: Context,
  ): Promise<{ discountRate: number; discountAmount: number; appliedRules: string[] }> {
    const rules = await this.prisma.discountRule.findMany({
      where: {
        tenantId: ctx.tenantId,
        isActive: true,
        startDate: { lte: new Date() },
        OR: [
          { endDate: null },
          { endDate: { gte: new Date() } },
        ],
      },
      orderBy: { value: 'desc' },
    });

    let bestDiscountRate = 0;
    let bestDiscountAmount = 0;
    const appliedRules: string[] = [];

    const basePrice = product.discountPrice || product.salePrice || product.price;
    const subtotal = basePrice * quantity;

    for (const rule of rules) {
      let applies = false;

      // بررسی شرایط
      if (quantity >= rule.minQuantity) applies = true;
      if (rule.minAmount && subtotal >= rule.minAmount) applies = true;
      if (input.isWholesale && rule.type === 'wholesale') applies = true;

      if (applies) {
        let discount = 0;
        if (rule.type === 'percentage') {
          discount = Math.floor(subtotal * (rule.value / 100));
        } else if (rule.type === 'fixed') {
          discount = rule.value;
        } else if (rule.type === 'bogo' && quantity >= 2) {
          // Buy One Get One: هر محصول دوم رایگان
          const freeCount = Math.floor(quantity / 2);
          discount = basePrice * freeCount;
        }

        if (discount > bestDiscountAmount) {
          bestDiscountAmount = discount;
          bestDiscountRate = rule.value;
          appliedRules.length = 0;
          appliedRules.push(rule.name);
        }
      }
    }

    if (bestDiscountAmount > 0) {
      await this.eventBus.publish(new DiscountAppliedEvent(
        product.id,
        bestDiscountRate,
        bestDiscountAmount,
        ctx.tenantId,
      ));
    }

    return {
      discountRate: bestDiscountRate,
      discountAmount: bestDiscountAmount,
      appliedRules,
    };
  }

  // ============================================================
  // 6) اعمال کد تخفیف (Coupon)
  // ============================================================
  private async applyCoupon(code: string, subtotal: number, ctx: Context): Promise<number> {
    const coupon = await this.prisma.coupon.findFirst({
      where: {
        code,
        isActive: true,
        startsAt: { lte: new Date() },
        endsAt: { gte: new Date() },
        OR: [
          { usageLimit: null },
          { usedCount: { lt: 1000000 } }, // در عمل با usageLimit مقایسه می‌شود
        ],
      },
    });

    if (!coupon) return 0;

    // بررسی محدودیت استفاده
    if (coupon.usageLimit && coupon.usedCount >= coupon.usageLimit) {
      return 0;
    }

    // بررسی حداقل مبلغ
    if (coupon.minAmount && subtotal < coupon.minAmount) {
      return 0;
    }

    let discount = 0;
    if (coupon.type === 'percentage') {
      discount = Math.floor(subtotal * (coupon.value / 100));
      if (coupon.maxDiscount) {
        discount = Math.min(discount, coupon.maxDiscount);
      }
    } else if (coupon.type === 'fixed') {
      discount = Math.min(coupon.value, subtotal);
    } else if (coupon.type === 'free_shipping') {
      // در محاسبه shippingCost اعمال می‌شود
      return 0;
    }

    return discount;
  }

  // ============================================================
  // 7) محاسبه هزینه ارسال
  // ============================================================
  private async calculateShipping(subtotal: number, ctx: Context): Promise<number> {
    const setting = await this.prisma.siteSetting.findUnique({
      where: { tenantId_key: { tenantId: ctx.tenantId, key: 'free_shipping_threshold' } },
    });

    const threshold = setting ? parseInt(setting.value, 10) : 500000;

    if (subtotal >= threshold) {
      return 0;
    }

    const defaultCost = await this.prisma.siteSetting.findUnique({
      where: { tenantId_key: { tenantId: ctx.tenantId, key: 'default_shipping_cost' } },
    });

    return defaultCost ? parseInt(defaultCost.value, 10) : 89000;
  }

  // ============================================================
  // 8) محاسبه مالیات
  // ============================================================
  private async calculateTax(taxableAmount: number, ctx: Context): Promise<number> {
    const setting = await this.prisma.siteSetting.findUnique({
      where: { tenantId_key: { tenantId: ctx.tenantId, key: 'tax_percent' } },
    });

    const taxPercent = setting ? parseFloat(setting.value) : 0;
    return Math.floor(taxableAmount * (taxPercent / 100));
  }

  // ============================================================
  // 9) Helpers
  // ============================================================
  private invalidatePriceCache(productId?: number): void {
    if (productId) {
      for (const key of this.priceCache.keys()) {
        if (key.includes(`:${productId}:`)) {
          this.priceCache.delete(key);
        }
      }
    } else {
      this.priceCache.clear();
    }
  }

  // ============================================================
  // 10) Event Handlers
  // ============================================================
  private async onStockUpdated(event: any): Promise<void> {
    // اگر موجودی کم شد، ممکن است نیاز به افزایش قیمت باشد
    if (event.change < 0) {
      this.invalidatePriceCache();
    }
  }

  private async onProductPublished(event: any): Promise<void> {
    // محصول جدید منتشر شد — cache را پاک کن
    this.invalidatePriceCache(event.productId);
  }
}
