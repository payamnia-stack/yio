// ============================================================
// YIO V7 — Analytics Engine
// ============================================================
// موتور آنالیز و گزارش‌گیری — جمع‌آوری metricها،
// تولید snapshot روزانه/هفتگی/ماهانه، داشبوردهای زنده،
// KPIهای تجاری، پیش‌بینی‌های ساده
// ============================================================

import { Context, BusinessError, OperationResult, Events } from '@yio/core';
import { PrismaClient } from '@prisma/client';
import { IEventBus } from '@yio/core';
import {
  AnalyticsSnapshotRecordedEvent,
  DashboardUpdatedEvent,
  KPIAlertEvent,
} from '@yio/core';

// ===== Metric Types =====
export type MetricType = 'counter' | 'gauge' | 'histogram' | 'timer';

export interface MetricDefinition {
  name: string;
  displayName: string;
  type: MetricType;
  unit?: string;
  description?: string;
  dimensions?: string[]; // e.g. ['productId', 'categoryId']
}

// ===== KPI Definitions =====
export const KPIS = {
  // Sales KPIs
  total_sales_today: { name: 'total_sales_today', displayName: 'فروش امروز', type: 'counter', unit: 'ریال' },
  total_sales_week: { name: 'total_sales_week', displayName: 'فروش این هفته', type: 'counter', unit: 'ریال' },
  total_sales_month: { name: 'total_sales_month', displayName: 'فروش این ماه', type: 'counter', unit: 'ریال' },
  orders_today: { name: 'orders_today', displayName: 'سفارش‌های امروز', type: 'counter', unit: 'عدد' },
  average_order_value: { name: 'average_order_value', displayName: 'متوسط ارزش سفارش', type: 'gauge', unit: 'ریال' },
  conversion_rate: { name: 'conversion_rate', displayName: 'نرخ تبدیل', type: 'gauge', unit: '٪' },

  // Production KPIs
  active_work_orders: { name: 'active_work_orders', displayName: 'دستورات کار فعال', type: 'gauge', unit: 'عدد' },
  completed_work_orders_today: { name: 'completed_work_orders_today', displayName: 'تولید امروز', type: 'counter', unit: 'عدد' },
  production_efficiency: { name: 'production_efficiency', displayName: 'بازدهی تولید', type: 'gauge', unit: '٪' },
  waste_rate: { name: 'waste_rate', displayName: 'نرخ ضایعات', type: 'gauge', unit: '٪' },
  on_time_delivery: { name: 'on_time_delivery', displayName: 'تحویل به‌موقع', type: 'gauge', unit: '٪' },

  // Inventory KPIs
  total_inventory_value: { name: 'total_inventory_value', displayName: 'ارزش موجودی انبار', type: 'gauge', unit: 'ریال' },
  low_stock_items: { name: 'low_stock_items', displayName: 'اقلام کم‌موجودی', type: 'gauge', unit: 'عدد' },
  stock_turnover: { name: 'stock_turnover', displayName: 'نرخ گردش موجودی', type: 'gauge', unit: 'در ماه' },

  // Customer KPIs
  total_customers: { name: 'total_customers', displayName: 'تعداد مشتریان', type: 'gauge', unit: 'نفر' },
  new_customers_today: { name: 'new_customers_today', displayName: 'مشتریان جدید امروز', type: 'counter', unit: 'نفر' },
  returning_customers: { name: 'returning_customers', displayName: 'مشتریان برگشتی', type: 'gauge', unit: '٪' },
  customer_satisfaction: { name: 'customer_satisfaction', displayName: 'رضایت مشتری', type: 'gauge', unit: '٪' },

  // Financial KPIs
  total_revenue_month: { name: 'total_revenue_month', displayName: 'درآمد ماه جاری', type: 'counter', unit: 'ریال' },
  total_expenses_month: { name: 'total_expenses_month', displayName: 'هزینه‌های ماه جاری', type: 'counter', unit: 'ریال' },
  net_profit_month: { name: 'net_profit_month', displayName: 'سود خالص ماه', type: 'gauge', unit: 'ریال' },
  cash_balance: { name: 'cash_balance', displayName: 'موجودی نقدی', type: 'gauge', unit: 'ریال' },

  // Quality KPIs
  quality_pass_rate: { name: 'quality_pass_rate', displayName: 'نرخ قبولی کیفیت', type: 'gauge', unit: '٪' },
  defect_rate: { name: 'defect_rate', displayName: 'نرخ نقص', type: 'gauge', unit: '٪' },
} as const;

// ===== Snapshot =====
export interface AnalyticsSnapshotData {
  metric: string;
  value: number;
  dimensions?: Record<string, any>;
  recordedAt: Date;
}

// ===== Dashboard =====
export interface DashboardData {
  kpis: Record<string, { value: number; displayName: string; unit?: string; trend?: number }>;
  charts: {
    salesTrend: Array<{ date: string; value: number }>;
    topProducts: Array<{ productId: number; title: string; sales: number; revenue: number }>;
    productionStatus: Record<string, number>;
    inventoryByWarehouse: Array<{ warehouseId: number; name: string; value: number }>;
  };
  alerts: Array<{ metric: string; message: string; severity: 'info' | 'warning' | 'critical' }>;
  generatedAt: Date;
}

export class AnalyticsEngine {
  private snapshotCache: Map<string, { data: DashboardData; expires: number }> = new Map();
  private readonly CACHE_TTL = 60 * 1000; // 1 minute
  private readonly ALERT_THRESHOLDS = {
    low_stock_items: { warning: 5, critical: 10 },
    waste_rate: { warning: 8, critical: 15 },
    defect_rate: { warning: 5, critical: 10 },
    customer_satisfaction: { warning: 80, critical: 70, inverted: true },
    on_time_delivery: { warning: 90, critical: 80, inverted: true },
  };

  constructor(
    private prisma: PrismaClient,
    private eventBus: IEventBus,
  ) {
    // Subscribe to all events for real-time metric updates
    this.eventBus.subscribe(Events.OrderCreated, this.onOrderCreated.bind(this));
    this.eventBus.subscribe(Events.OrderDelivered, this.onOrderDelivered.bind(this));
    this.eventBus.subscribe(Events.ProductionCompleted, this.onProductionCompleted.bind(this));
    this.eventBus.subscribe(Events.QualityCheckPassed, this.onQualityPassed.bind(this));
    this.eventBus.subscribe(Events.QualityCheckFailed, this.onQualityFailed.bind(this));
    this.eventBus.subscribe(Events.LowStockAlert, this.onLowStock.bind(this));
    this.eventBus.subscribe(Events.UserRegistered, this.onUserRegistered.bind(this));
  }

  // ============================================================
  // 1) ثبت Metric (Snapshot)
  // ============================================================
  async recordMetric(
    metric: string,
    value: number,
    dimensions: Record<string, any> = {},
    ctx: Context,
  ): Promise<void> {
    await this.prisma.analyticsSnapshot.create({
      data: {
        tenantId: ctx.tenantId,
        metric,
        value,
        dimensions: JSON.stringify(dimensions),
        recordedAt: new Date(),
      },
    });

    await this.eventBus.publish(new AnalyticsSnapshotRecordedEvent(metric, value, ctx.tenantId));
  }

  // ============================================================
  // 2) دریافت آخرین مقدار یک Metric
  // ============================================================
  async getLatestMetric(metric: string, ctx: Context): Promise<number | null> {
    const snapshot = await this.prisma.analyticsSnapshot.findFirst({
      where: { tenantId: ctx.tenantId, metric },
      orderBy: { recordedAt: 'desc' },
    });
    return snapshot?.value || null;
  }

  // ============================================================
  // 3) دریافت سری زمانی یک Metric
  // ============================================================
  async getMetricTimeSeries(
    metric: string,
    from: Date,
    to: Date,
    ctx: Context,
  ): Promise<Array<{ date: Date; value: number }>> {
    const snapshots = await this.prisma.analyticsSnapshot.findMany({
      where: {
        tenantId: ctx.tenantId,
        metric,
        recordedAt: { gte: from, lte: to },
      },
      orderBy: { recordedAt: 'asc' },
    });

    return snapshots.map(s => ({ date: s.recordedAt, value: s.value }));
  }

  // ============================================================
  // 4) محاسبه و ثبت KPIهای روزانه
  // ============================================================
  async recordDailyKPIs(ctx: Context): Promise<OperationResult> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // 1. Sales KPIs
    const todayOrders = await this.prisma.order.findMany({
      where: {
        tenantId: ctx.tenantId,
        createdAt: { gte: today, lt: tomorrow },
        status: { not: 'cancelled' },
      },
      include: { items: true },
    });

    const totalSalesToday = todayOrders.reduce((s, o) => s + o.finalAmount, 0);
    const avgOrderValue = todayOrders.length > 0 ? Math.floor(totalSalesToday / todayOrders.length) : 0;

    await this.recordMetric('total_sales_today', totalSalesToday, {}, ctx);
    await this.recordMetric('orders_today', todayOrders.length, {}, ctx);
    await this.recordMetric('average_order_value', avgOrderValue, {}, ctx);

    // 2. Production KPIs
    const activeWorkOrders = await this.prisma.workOrder.count({
      where: {
        tenantId: ctx.tenantId,
        status: { in: ['planned', 'in_progress'] },
      },
    });

    const completedToday = await this.prisma.workOrder.count({
      where: {
        tenantId: ctx.tenantId,
        status: 'completed',
        endDate: { gte: today, lt: tomorrow },
      },
    });

    await this.recordMetric('active_work_orders', activeWorkOrders, {}, ctx);
    await this.recordMetric('completed_work_orders_today', completedToday, {}, ctx);

    // 3. Inventory KPIs
    const lowStockProducts = await this.prisma.product.count({
      where: { tenantId: ctx.tenantId, stockQuantity: { lte: 10 }, inStock: true },
    });
    await this.recordMetric('low_stock_items', lowStockProducts, {}, ctx);

    // محاسبه ارزش موجودی
    const products = await this.prisma.product.findMany({
      where: { tenantId: ctx.tenantId },
      select: { stockQuantity: true, price: true },
    });
    const totalInventoryValue = products.reduce((s, p) => s + p.stockQuantity * p.price, 0);
    await this.recordMetric('total_inventory_value', totalInventoryValue, {}, ctx);

    // 4. Customer KPIs
    const totalCustomers = await this.prisma.user.count({
      where: { tenantId: ctx.tenantId, level: 0 },
    });
    const newCustomersToday = await this.prisma.user.count({
      where: {
        tenantId: ctx.tenantId,
        level: 0,
        createdAt: { gte: today, lt: tomorrow },
      },
    });
    await this.recordMetric('total_customers', totalCustomers, {}, ctx);
    await this.recordMetric('new_customers_today', newCustomersToday, {}, ctx);

    // 5. Quality KPIs
    const todayQualityChecks = await this.prisma.qualityCheck.findMany({
      where: { checkedAt: { gte: today, lt: tomorrow } },
    });
    const passCount = todayQualityChecks.filter(q => q.result === 'pass').length;
    const passRate = todayQualityChecks.length > 0
      ? Math.floor((passCount / todayQualityChecks.length) * 100)
      : 100;
    await this.recordMetric('quality_pass_rate', passRate, {}, ctx);

    // 6. بررسی هشدارها
    await this.checkAlerts(ctx);

    return {
      success: true,
      message: 'KPIهای روزانه ثبت شد',
      data: {
        totalSalesToday,
        ordersToday: todayOrders.length,
        activeWorkOrders,
        lowStockItems: lowStockProducts,
      },
    };
  }

  // ============================================================
  // 5) دریافت داشبورد کامل
  // ============================================================
  async getDashboard(ctx: Context): Promise<DashboardData> {
    const cacheKey = `dashboard:${ctx.tenantId}`;
    const cached = this.snapshotCache.get(cacheKey);
    if (cached && cached.expires > Date.now()) {
      return cached.data;
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // 1. محاسبه KPIها
    const kpis: DashboardData['kpis'] = {};

    // Sales
    const todayOrders = await this.prisma.order.findMany({
      where: {
        tenantId: ctx.tenantId,
        createdAt: { gte: today, lt: tomorrow },
        status: { not: 'cancelled' },
      },
    });
    const totalSalesToday = todayOrders.reduce((s, o) => s + o.finalAmount, 0);
    kpis.total_sales_today = { value: totalSalesToday, displayName: 'فروش امروز', unit: 'ریال' };
    kpis.orders_today = { value: todayOrders.length, displayName: 'سفارش‌های امروز', unit: 'عدد' };
    kpis.average_order_value = {
      value: todayOrders.length > 0 ? Math.floor(totalSalesToday / todayOrders.length) : 0,
      displayName: 'متوسط ارزش سفارش',
      unit: 'ریال',
    };

    // هفته جاری
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    const weekOrders = await this.prisma.order.findMany({
      where: {
        tenantId: ctx.tenantId,
        createdAt: { gte: weekAgo },
        status: { not: 'cancelled' },
      },
    });
    kpis.total_sales_week = {
      value: weekOrders.reduce((s, o) => s + o.finalAmount, 0),
      displayName: 'فروش این هفته',
      unit: 'ریال',
    };

    // ماه جاری
    const monthAgo = new Date();
    monthAgo.setDate(monthAgo.getDate() - 30);
    const monthOrders = await this.prisma.order.findMany({
      where: {
        tenantId: ctx.tenantId,
        createdAt: { gte: monthAgo },
        status: { not: 'cancelled' },
      },
    });
    kpis.total_sales_month = {
      value: monthOrders.reduce((s, o) => s + o.finalAmount, 0),
      displayName: 'فروش این ماه',
      unit: 'ریال',
    };

    // Production
    const activeWorkOrders = await this.prisma.workOrder.count({
      where: { tenantId: ctx.tenantId, status: { in: ['planned', 'in_progress'] } },
    });
    kpis.active_work_orders = { value: activeWorkOrders, displayName: 'دستورات کار فعال', unit: 'عدد' };

    // Customers
    const totalCustomers = await this.prisma.user.count({
      where: { tenantId: ctx.tenantId, level: 0 },
    });
    kpis.total_customers = { value: totalCustomers, displayName: 'تعداد مشتریان', unit: 'نفر' };

    // Inventory
    const lowStock = await this.prisma.product.count({
      where: { tenantId: ctx.tenantId, stockQuantity: { lte: 10 }, inStock: true },
    });
    kpis.low_stock_items = { value: lowStock, displayName: 'اقلام کم‌موجودی', unit: 'عدد' };

    // 2. نمودار روند فروش (7 روز اخیر)
    const salesTrend: Array<{ date: string; value: number }> = [];
    for (let i = 6; i >= 0; i--) {
      const dayStart = new Date();
      dayStart.setDate(dayStart.getDate() - i);
      dayStart.setHours(0, 0, 0, 0);
      const dayEnd = new Date(dayStart);
      dayEnd.setDate(dayEnd.getDate() + 1);

      const dayOrders = await this.prisma.order.findMany({
        where: {
          tenantId: ctx.tenantId,
          createdAt: { gte: dayStart, lt: dayEnd },
          status: { not: 'cancelled' },
        },
      });
      const dayTotal = dayOrders.reduce((s, o) => s + o.finalAmount, 0);
      salesTrend.push({
        date: dayStart.toISOString().slice(0, 10),
        value: dayTotal,
      });
    }

    // 3. پرفروش‌ترین محصولات
    const topProductsRaw = await this.prisma.orderItem.groupBy({
      by: ['productId', 'productTitle'],
      _sum: { quantity: true, price: true },
      _count: true,
      orderBy: { _sum: { quantity: 'desc' } },
      take: 5,
    });

    const topProducts = topProductsRaw.map(p => ({
      productId: p.productId,
      title: p.productTitle,
      sales: p._sum.quantity || 0,
      revenue: (p._sum.price || 0) * (p._sum.quantity || 0),
    }));

    // 4. وضعیت تولید
    const workOrdersByStatus = await this.prisma.workOrder.groupBy({
      by: ['status'],
      _count: true,
      where: { tenantId: ctx.tenantId },
    });
    const productionStatus: Record<string, number> = {};
    for (const w of workOrdersByStatus) {
      productionStatus[w.status] = w._count;
    }

    // 5. موجودی بر اساس انبار
    const warehouses = await this.prisma.warehouse.findMany({
      where: { tenantId: ctx.tenantId },
      include: {
        woodStocks: { select: { quantity: true, pricePerUnit: true } },
        paintStocks: { select: { quantity: true, purchasePrice: true } },
      },
    });
    const inventoryByWarehouse = warehouses.map(w => {
      const woodValue = w.woodStocks.reduce((s, ws) => s + ws.quantity * (ws.pricePerUnit || 0), 0);
      const paintValue = w.paintStocks.reduce((s, ps) => s + ps.quantity * (ps.purchasePrice || 0), 0);
      return {
        warehouseId: w.id,
        name: w.name,
        value: woodValue + paintValue,
      };
    });

    // 6. هشدارها
    const alerts = await this.generateAlerts(kpis, ctx);

    const dashboard: DashboardData = {
      kpis,
      charts: {
        salesTrend,
        topProducts,
        productionStatus,
        inventoryByWarehouse,
      },
      alerts,
      generatedAt: new Date(),
    };

    // Cache
    this.snapshotCache.set(cacheKey, { data: dashboard, expires: Date.now() + this.CACHE_TTL });

    await this.eventBus.publish(new DashboardUpdatedEvent(ctx.tenantId));

    return dashboard;
  }

  // ============================================================
  // 6) بررسی هشدارها
  // ============================================================
  private async checkAlerts(ctx: Context): Promise<void> {
    const alerts: Array<{ metric: string; message: string; severity: 'info' | 'warning' | 'critical' }> = [];

    for (const [metric, threshold] of Object.entries(this.ALERT_THRESHOLDS)) {
      const value = await this.getLatestMetric(metric, ctx);
      if (value === null) continue;

      const t = threshold as any;
      const isInverted = t.inverted === true;
      const warningLevel = isInverted ? value < t.warning : value >= t.warning;
      const criticalLevel = isInverted ? value < t.critical : value >= t.critical;

      if (criticalLevel) {
        alerts.push({
          metric,
          message: `KPI "${metric}" در سطح بحرانی: ${value}`,
          severity: 'critical',
        });
      } else if (warningLevel) {
        alerts.push({
          metric,
          message: `KPI "${metric}" هشدار: ${value}`,
          severity: 'warning',
        });
      }

      if (criticalLevel || warningLevel) {
        await this.eventBus.publish(new KPIAlertEvent(metric, value, criticalLevel ? 'critical' : 'warning', ctx.tenantId));
      }
    }
  }

  // ============================================================
  // 7) تولید هشدارهای داشبورد
  // ============================================================
  private async generateAlerts(kpis: DashboardData['kpis'], ctx: Context): Promise<DashboardData['alerts']> {
    const alerts: DashboardData['alerts'] = [];

    if (kpis.low_stock_items && kpis.low_stock_items.value >= 5) {
      alerts.push({
        metric: 'low_stock_items',
        message: `${kpis.low_stock_items.value} محصول کم‌موجودی هستند`,
        severity: kpis.low_stock_items.value >= 10 ? 'critical' : 'warning',
      });
    }

    // محصولات ناموجود
    const outOfStock = await this.prisma.product.count({
      where: { tenantId: ctx.tenantId, inStock: false },
    });
    if (outOfStock > 0) {
      alerts.push({
        metric: 'out_of_stock',
        message: `${outOfStock} محصول ناموجود`,
        severity: outOfStock > 5 ? 'critical' : 'warning',
      });
    }

    // دستورات کار معوق
    const overdueWorkOrders = await this.prisma.workOrder.count({
      where: {
        tenantId: ctx.tenantId,
        expectedDate: { lt: new Date() },
        status: { in: ['planned', 'in_progress'] },
      },
    });
    if (overdueWorkOrders > 0) {
      alerts.push({
        metric: 'overdue_work_orders',
        message: `${overdueWorkOrders} دستور کار تأخیر دارد`,
        severity: overdueWorkOrders > 3 ? 'critical' : 'warning',
      });
    }

    // ماشین‌آلات نیازمند تعمیر
    const brokenMachines = await this.prisma.machine.count({
      where: { tenantId: ctx.tenantId, status: 'broken' },
    });
    if (brokenMachines > 0) {
      alerts.push({
        metric: 'broken_machines',
        message: `${brokenMachines} ماشین خراب است`,
        severity: 'critical',
      });
    }

    return alerts;
  }

  // ============================================================
  // 8) گزارش فروش
  // ============================================================
  async getSalesReport(from: Date, to: Date, ctx: Context): Promise<{
    totalSales: number;
    totalOrders: number;
    averageOrderValue: number;
    topProducts: Array<{ productId: number; title: string; quantity: number; revenue: number }>;
    salesByDay: Array<{ date: string; total: number; orders: number }>;
  }> {
    const orders = await this.prisma.order.findMany({
      where: {
        tenantId: ctx.tenantId,
        createdAt: { gte: from, lte: to },
        status: { not: 'cancelled' },
      },
      include: { items: true },
    });

    const totalSales = orders.reduce((s, o) => s + o.finalAmount, 0);
    const totalOrders = orders.length;
    const averageOrderValue = totalOrders > 0 ? Math.floor(totalSales / totalOrders) : 0;

    // گروه‌بندی بر اساس محصول
    const productMap = new Map<number, { title: string; quantity: number; revenue: number }>();
    for (const order of orders) {
      for (const item of order.items) {
        if (!productMap.has(item.productId)) {
          productMap.set(item.productId, { title: item.productTitle, quantity: 0, revenue: 0 });
        }
        const p = productMap.get(item.productId)!;
        p.quantity += item.quantity;
        p.revenue += item.price * item.quantity;
      }
    }
    const topProducts = Array.from(productMap.entries())
      .map(([productId, data]) => ({ productId, ...data }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10);

    // گروه‌بندی بر اساس روز
    const dayMap = new Map<string, { total: number; orders: number }>();
    for (const order of orders) {
      const day = order.createdAt.toISOString().slice(0, 10);
      if (!dayMap.has(day)) {
        dayMap.set(day, { total: 0, orders: 0 });
      }
      const d = dayMap.get(day)!;
      d.total += order.finalAmount;
      d.orders += 1;
    }
    const salesByDay = Array.from(dayMap.entries())
      .map(([date, data]) => ({ date, ...data }))
      .sort((a, b) => a.date.localeCompare(b.date));

    return {
      totalSales,
      totalOrders,
      averageOrderValue,
      topProducts,
      salesByDay,
    };
  }

  // ============================================================
  // 9) گزارش تولید
  // ============================================================
  async getProductionReport(from: Date, to: Date, ctx: Context): Promise<{
    totalWorkOrders: number;
    completed: number;
    inProgress: number;
    planned: number;
    cancelled: number;
    averageCompletionTime: number;
    wasteRate: number;
    defectRate: number;
  }> {
    const workOrders = await this.prisma.workOrder.findMany({
      where: {
        tenantId: ctx.tenantId,
        createdAt: { gte: from, lte: to },
      },
      include: { wasteRecords: true, qualityChecks: true },
    });

    const completed = workOrders.filter(w => w.status === 'completed').length;
    const inProgress = workOrders.filter(w => w.status === 'in_progress').length;
    const planned = workOrders.filter(w => w.status === 'planned').length;
    const cancelled = workOrders.filter(w => w.status === 'cancelled').length;

    const completedWOs = workOrders.filter(w => w.status === 'completed' && w.endDate);
    const avgTime = completedWOs.length > 0
      ? completedWOs.reduce((s, w) => {
          const duration = (w.endDate!.getTime() - w.createdAt.getTime()) / (1000 * 60 * 60);
          return s + duration;
        }, 0) / completedWOs.length
      : 0;

    const totalWaste = workOrders.reduce((s, w) => s + w.wasteRecords.length, 0);
    const totalChecks = workOrders.reduce((s, w) => s + w.qualityChecks.length, 0);
    const failedChecks = workOrders.reduce(
      (s, w) => s + w.qualityChecks.filter(q => q.result === 'fail').length, 0
    );

    return {
      totalWorkOrders: workOrders.length,
      completed,
      inProgress,
      planned,
      cancelled,
      averageCompletionTime: Math.floor(avgTime),
      wasteRate: workOrders.length > 0 ? Math.floor((totalWaste / workOrders.length) * 100) : 0,
      defectRate: totalChecks > 0 ? Math.floor((failedChecks / totalChecks) * 100) : 0,
    };
  }

  // ============================================================
  // Event Handlers
  // ============================================================
  private async onOrderCreated(event: any): Promise<void> {
    // Real-time: به‌روزرسانی counter سفارشات امروز
  }

  private async onOrderDelivered(event: any): Promise<void> {
    // Real-time: به‌روزرسانی فروش تکمیل‌شده
  }

  private async onProductionCompleted(event: any): Promise<void> {
    // Real-time: به‌روزرسانی counter تولید امروز
  }

  private async onQualityPassed(event: any): Promise<void> {
    // Real-time: به‌روزرسانی نرخ قبولی کیفیت
  }

  private async onQualityFailed(event: any): Promise<void> {
    // Real-time: به‌روزرسانی نرخ نقص
    // پاک کردن cache داشبورد
    this.snapshotCache.clear();
  }

  private async onLowStock(event: any): Promise<void> {
    // هشدار موجودی کم
    this.snapshotCache.clear();
  }

  private async onUserRegistered(event: any): Promise<void> {
    // Real-time: به‌روزرسانی counter مشتریان جدید
  }
}
