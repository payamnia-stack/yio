// ============================================================
// YIO V8 — Event Store (Prisma Implementation)
// ============================================================
// Event Store تمام Eventهای منتشرشده را به‌صورت immutable ذخیره
// می‌کند. این کار امکان:
//   - Audit کامل از تاریخچه تغییرات
//   - Event Sourcing (rebuild state از Eventها)
//   - Replay برای دیباگ
//   - Time-travel debugging
// را فراهم می‌کند.
// ============================================================

import { PrismaClient } from '@prisma/client';
import {
  IEventStore,
  IEventStoreRepository,
  DomainEvent,
  Context,
  EventName,
  getEventName,
  getEventClass,
} from '@yio/core';

// ============================================================
// Serialization Helpers
// ============================================================
// Eventها به‌صورت JSON در دیتابیس ذخیره می‌شوند. برای حفظ نوع
// هنگام بازخوانی، نوع (className) هم ذخیره می‌شود.

interface StoredEvent {
  id?: number;
  eventId: string;
  eventName: EventName;
  aggregateType: string;     // e.g. 'Order', 'Product'
  aggregateId: number | string;
  payload: string;            // JSON
  metadata: string;           // JSON (tenantId, userId, ip, ...)
  tenantId: number;
  occurredAt: Date;
}

function inferAggregate(event: DomainEvent): { type: string; id: number | string } {
  // سعی می‌کنیم از روی properties آن را infer کنیم
  const anyEvt = event as any;
  if (anyEvt.orderId !== undefined) return { type: 'Order', id: anyEvt.orderId };
  if (anyEvt.productId !== undefined) return { type: 'Product', id: anyEvt.productId };
  if (anyEvt.workOrderId !== undefined) return { type: 'WorkOrder', id: anyEvt.workOrderId };
  if (anyEvt.poId !== undefined) return { type: 'PurchaseOrder', id: anyEvt.poId };
  if (anyEvt.userId !== undefined) return { type: 'User', id: anyEvt.userId };
  if (anyEvt.machineId !== undefined) return { type: 'Machine', id: anyEvt.machineId };
  if (anyEvt.documentId !== undefined) return { type: 'Document', id: anyEvt.documentId };
  return { type: 'Unknown', id: 0 };
}

// ============================================================
// Event Store Repository (Raw SQL)
// ============================================================
// در V8 مدل EventStoreRecord در Prisma schema اضافه شده است.
// اگر موجود نبود (مثلاً در test)، این پیاده‌سازی به‌صورت In-Memory
// fallback می‌کند.

export class PrismaEventStoreRepository implements IEventStoreRepository {
  private memoryFallback: StoredEvent[] = [];
  private useFallback: boolean;

  constructor(private prisma: PrismaClient) {
    this.useFallback = !(prisma as any).eventStoreRecord;
  }

  async append(raw: Record<string, any>): Promise<void> {
    if (this.useFallback) {
      this.memoryFallback.push(raw as StoredEvent);
      return;
    }
    await (this.prisma as any).eventStoreRecord.create({ data: raw });
  }

  async getByAggregate(
    aggregateType: string,
    aggregateId: number,
    ctx: Context,
  ): Promise<any[]> {
    if (this.useFallback) {
      return this.memoryFallback.filter(
        (e) => e.aggregateType === aggregateType && e.aggregateId === aggregateId && e.tenantId === ctx.tenantId,
      );
    }
    return (this.prisma as any).eventStoreRecord.findMany({
      where: { aggregateType, aggregateId, tenantId: ctx.tenantId },
      orderBy: { occurredAt: 'asc' },
    });
  }

  async getByTenant(
    tenantId: number,
    from: Date,
    to: Date,
    page: number = 1,
    pageSize: number = 50,
  ): Promise<any[]> {
    if (this.useFallback) {
      return this.memoryFallback.filter(
        (e) => e.tenantId === tenantId && e.occurredAt >= from && e.occurredAt <= to,
      );
    }
    return (this.prisma as any).eventStoreRecord.findMany({
      where: { tenantId, occurredAt: { gte: from, lte: to } },
      orderBy: { occurredAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    });
  }
}

// ============================================================
// Event Store (High-level API)
// ============================================================
export class PrismaEventStore implements IEventStore {
  constructor(
    private repo: IEventStoreRepository,
  ) {}

  async append(event: DomainEvent): Promise<void> {
    const eventName = getEventName(event);
    const aggregate = inferAggregate(event);
    const anyEvt = event as any;

    const stored: StoredEvent = {
      eventId: event.eventId,
      eventName,
      aggregateType: aggregate.type,
      aggregateId: aggregate.id,
      payload: JSON.stringify(event),
      metadata: JSON.stringify({
        tenantId: anyEvt.tenantId,
        userId: anyEvt.userId,
        ip: anyEvt.ip,
        userAgent: anyEvt.userAgent,
        requestId: anyEvt.requestId,
      }),
      tenantId: anyEvt.tenantId ?? 0,
      occurredAt: event.timestamp,
    };

    await this.repo.append({
      eventId: stored.eventId,
      eventName: stored.eventName,
      aggregateType: stored.aggregateType,
      aggregateId: stored.aggregateId as number,
      payload: stored.payload,
      metadata: stored.metadata,
      tenantId: stored.tenantId,
      occurredAt: stored.occurredAt,
    });
  }

  async getByAggregate(aggregateType: string, aggregateId: number, ctx: Context): Promise<DomainEvent[]> {
    const records = await this.repo.getByAggregate(aggregateType, aggregateId, ctx);
    return records.map((r) => this.deserialize(r));
  }

  async getByTenant(
    tenantId: number,
    from: Date,
    to: Date,
    page: number = 1,
    pageSize: number = 50,
  ): Promise<{ events: DomainEvent[]; total: number }> {
    const records = await this.repo.getByTenant(tenantId, from, to, page, pageSize);
    const events = records.map((r) => this.deserialize(r));
    return { events, total: events.length };
  }

  async getByType(
    eventType: EventName,
    from: Date,
    to: Date,
    page: number = 1,
    pageSize: number = 50,
  ): Promise<{ events: DomainEvent[]; total: number }> {
    // این متد نیاز به کوئری فیلتر بر اساس eventName دارد
    // در Prisma با مدل eventStoreRecord قابل پیاده‌سازی است
    const records = await (this.repo as PrismaEventStoreRepository).getByTenant?.(0, from, to, page, pageSize) || [];
    const filtered = (records as any[]).filter((r) => r.eventName === eventType);
    const events = filtered.map((r) => this.deserialize(r));
    return { events, total: events.length };
  }

  // ============================================================
  // Deserialization — بازسازی Event از JSON با حفظ نوع
  // ============================================================
  private deserialize(record: any): DomainEvent {
    const eventName = record.eventName as EventName;
    const payload = typeof record.payload === 'string'
      ? JSON.parse(record.payload)
      : record.payload;

    const ctor = getEventClass(eventName);
    if (!ctor) {
      // fallback: اگر کلاس ثبت نشده، یک Event generic برمی‌گردانیم
      const fallback = new (class extends DomainEvent {
        get eventName() { return eventName; }
      })();
      Object.assign(fallback, payload);
      return fallback;
    }

    // реконструکت instance با constructor argumentها
    // چون همه Eventها از DomainEvent ارث‌بری می‌کنند و constructor
    // فقط propertyها را set می‌کند، می‌توانیم با Object.assign کار کنیم.
    const instance = Object.create(ctor.prototype);
    Object.assign(instance, payload);
    return instance as DomainEvent;
  }
}
