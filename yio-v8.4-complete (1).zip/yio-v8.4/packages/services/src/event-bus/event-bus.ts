// ============================================================
// YIO V8.1 — Event Bus (Upgraded — Typed + publishAll + Event Store)
// ============================================================
// در V8.1:
//   1) متد subscribe فقط EventName (تایپ‌شده) قبول می‌کند.
//   2) publish() برای تک Event.
//   3) publishAll() برای batch publishing (مهم برای Aggregateها که چند
//      Domain Event تولید می‌کنند).
//   4) هر Event به Event Store ارسال می‌شود (در صورت تنظیم).
//   5) قابلیت replay از Event Store.
// ============================================================

import {
  IEventBus,
  DomainEvent,
  EventName,
  IEventStore,
  EventHandler,
  ILogger,
} from '@yio/core';

export class InMemoryEventBus implements IEventBus {
  private handlers: Map<EventName, EventHandler[]> = new Map();
  private loggedEvents: Array<{ event: DomainEvent; timestamp: Date }> = [];
  private maxLogSize: number = 1000;
  private eventStore: IEventStore | null = null;
  private logger: ILogger;

  constructor(logger?: ILogger) {
    // در V8.1، logger به‌جای console مستقیم استفاده می‌شود
    this.logger = logger || {
      info: (m: string) => console.log(m),
      warn: (m: string) => console.warn(m),
      error: (m: string) => console.error(m),
      debug: (m: string) => console.debug(m),
    };
  }

  /** اتصال به Event Store برای ذخیره دائمی Eventها */
  attachEventStore(store: IEventStore): void {
    this.eventStore = store;
  }

  // ============================================================
  // publish — انتشار یک Event
  // ============================================================
  async publish<E extends DomainEvent>(event: E): Promise<void> {
    await this.publishInternal(event);
  }

  // ============================================================
  // publishAll — V8.1 — انتشار batch از Eventها
  // ============================================================
  // این متد برای Aggregateهایی که چند Domain Event تولید می‌کنند
  // طراحی شده است. مثلاً یک Order ممکن است:
  //   - OrderCreatedEvent
  //   - OrderConfirmedEvent  (auto-confirmed)
  //   - InvoiceIssuedEvent
  //   - PaymentReceivedEvent
  // همه را در یک عملیات تولید کند.
  //
  // مزایا:
  //   ✅ همه eventها در یک batch به Event Store append می‌شوند (یک راند DB)
  //   ✅ handlerها به ترتیب اجرا می‌شوند
  //   ✅ اگر یکی fail شود، بقیه همچنان اجرا می‌شوند (allSettled)
  //   ✅ عملکرد بهتر (یک log به‌جای N log)
  async publishAll<E extends DomainEvent>(events: E[]): Promise<void> {
    if (events.length === 0) return;

    this.logger.info(`[EventBus] 📤 Publishing ${events.length} events in batch`);

    // ۱) لاگ همه eventها در buffer حافظه
    const now = new Date();
    for (const event of events) {
      this.loggedEvents.push({ event, timestamp: now });
    }
    while (this.loggedEvents.length > this.maxLogSize) {
      this.loggedEvents.shift();
    }

    // ۲) ذخیره همه در Event Store به‌صورت batch (یک transaction)
    if (this.eventStore) {
      try {
        // در حال حاضر EventStore.append یکی‌یکی ذخیره می‌کند.
        // در V8.2 می‌توان appendBatch اضافه کرد. فعلاً به ترتیب صدا می‌زنیم.
        for (const event of events) {
          await this.eventStore.append(event);
        }
      } catch (err) {
        this.logger.error(`[EventBus] ❌ Failed to append batch to EventStore: ${err}`);
      }
    }

    // ۳) اجرای handlerها به ترتیب event، و parallel handlerها برای هر event
    for (const event of events) {
      const eventName = event.eventName as EventName;
      const handlers = this.handlers.get(eventName);
      if (!handlers || handlers.length === 0) continue;

      this.logger.info(`[EventBus] 📤 ${eventName} (${event.eventId})`);

      const results = await Promise.allSettled(
        handlers.map((handler) => handler(event as any)),
      );

      results.forEach((result, index) => {
        if (result.status === 'rejected') {
          this.logger.error(
            `[EventBus] ❌ Handler #${index} failed for ${eventName}: ${result.reason}`,
          );
        }
      });
    }
  }

  subscribe<E extends DomainEvent>(eventName: EventName, handler: EventHandler<E>): void {
    if (!this.handlers.has(eventName)) {
      this.handlers.set(eventName, []);
    }
    this.handlers.get(eventName)!.push(handler as EventHandler);
    this.logger.info(`[EventBus] 📥 Subscribed to ${eventName}`);
  }

  unsubscribe(eventName: EventName, handler: EventHandler): void {
    const handlers = this.handlers.get(eventName);
    if (!handlers) return;

    const index = handlers.indexOf(handler);
    if (index > -1) {
      handlers.splice(index, 1);
      this.logger.info(`[EventBus] 🚫 Unsubscribed from ${eventName}`);
    }
  }

  // ============================================================
  // Helpers برای دیباگ
  // ============================================================
  getRecentEvents(count: number = 10): Array<{ event: DomainEvent; timestamp: Date }> {
    return this.loggedEvents.slice(-count);
  }

  getSubscriptions(): Map<EventName, number> {
    const result = new Map<EventName, number>();
    this.handlers.forEach((handlers, eventName) => {
      result.set(eventName, handlers.length);
    });
    return result;
  }

  // ============================================================
  // Internal — publish logic (shared between publish and publishAll)
  // ============================================================
  private async publishInternal<E extends DomainEvent>(event: E): Promise<void> {
    const eventName = event.eventName as EventName;

    // لاگ در buffer حافظه
    this.loggedEvents.push({ event, timestamp: new Date() });
    if (this.loggedEvents.length > this.maxLogSize) {
      this.loggedEvents.shift();
    }

    this.logger.info(`[EventBus] 📤 ${eventName} (${event.eventId})`);

    // ذخیره در Event Store
    if (this.eventStore) {
      try {
        await this.eventStore.append(event);
      } catch (err) {
        this.logger.error(`[EventBus] ❌ Failed to append event to store: ${err}`);
      }
    }

    // دریافت handlerها
    const handlers = this.handlers.get(eventName);
    if (!handlers || handlers.length === 0) {
      return;
    }

    // اجرای handlerها به‌صورت ناهمگام
    const results = await Promise.allSettled(
      handlers.map((handler) => handler(event as any)),
    );

    results.forEach((result, index) => {
      if (result.status === 'rejected') {
        this.logger.error(
          `[EventBus] ❌ Handler #${index} failed for ${eventName}: ${result.reason}`,
        );
      }
    });
  }
}

// ===== Singleton Instance =====
let eventBusInstance: InMemoryEventBus | null = null;

export function getEventBus(): InMemoryEventBus {
  if (!eventBusInstance) {
    eventBusInstance = new InMemoryEventBus();
  }
  return eventBusInstance;
}

export function resetEventBus(): void {
  eventBusInstance = null;
}
