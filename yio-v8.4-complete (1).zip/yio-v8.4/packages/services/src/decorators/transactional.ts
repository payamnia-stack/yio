// ============================================================
// YIO V8.1 — @Transactional Decorator
// ============================================================
// این decorator به‌طور خودکار یک متد را داخل یک Unit of Work
// اجرا می‌کند. اگر متد throw کند، rollback خودکار انجام می‌شود.
//
// مزایا:
//   ✅ فراموش کردن txManager.run() غیرممکن می‌شود
//   ✅ کد تمیزتر — هر UseCase فقط منطق business را دارد
//   ✅ Transaction Context به‌صورت خودکار به آخرین آرگومان تابع پاس داده می‌شود
//
// نحوه استفاده:
//
//   class OrderUseCase {
//     @Transactional()
//     async createOrder(input: CreateOrderInput, ctx: Context, tx: ITransactionContext) {
//       // داخل این متد، tx به‌صورت خودکار تزریق می‌شود
//       await this.orderRepo.createWithItems(order, items, ctx, tx);
//       await this.productRepo.reserveStock(items, ctx, tx);
//       tx.collectEvent(new OrderCreatedEvent(...));
//     }
//   }
//
// پیش‌نیازها:
//   - کلاس باید یک پراپرتی txManager داشته باشد
//   - آخرین آرگومان متد باید ITransactionContext باشد
// ============================================================

import {
  ITransactionManager,
  ITransactionContext,
  Context,
} from '@yio/core';

// ============================================================
// Metadata Key — برای ذخیره metadata روی کلاس
// ============================================================
const TRANSACTIONAL_METADATA = '__transactional_methods__';

interface TransactionalOptions {
  /**
   * اگر true باشد (default)، در صورت وجود tx فعال از parent استفاده می‌کند.
   * اگر false باشد، همیشه یک tx جدید ایجاد می‌کند (REQUIRES_NEW).
   */
  joinExisting?: boolean;
  /**
   * timeout بر حسب میلی‌ثانیه (default: 30000)
   */
  timeout?: number;
}

// ============================================================
// Decorator Factory
// ============================================================
export function Transactional(options: TransactionalOptions = {}) {
  const { joinExisting = true, timeout = 30000 } = options;

  return function (
    target: any,
    propertyKey: string,
    descriptor: PropertyDescriptor,
  ): PropertyDescriptor {
    const originalMethod = descriptor.value;

    // بازنویسی متد
    descriptor.value = async function (...args: any[]) {
      // پیدا کردن txManager روی instance
      const txManager: ITransactionManager | undefined = (this as any).txManager
        || (this as any)._txManager
        || (this as any).transactionManager;

      if (!txManager) {
        throw new Error(
          `@Transactional on "${propertyKey}" requires "txManager" property on the class. ` +
          `Make sure to inject ITransactionManager into the constructor and assign it as "this.txManager".`,
        );
      }

      // اگر joinExisting=true و آرگومان آخر ITransactionContext باشد، از آن استفاده کن
      // (این قابلیت به nested calls اجازه می‌دهد در همان tx اجرا شوند)
      if (joinExisting && args.length > 0) {
        const lastArg = args[args.length - 1];
        if (lastArg && typeof lastArg === 'object' && 'transactionId' in lastArg && 'collectEvent' in lastArg) {
          // tx والد وجود دارد — مستقیم در آن اجرا کن
          return originalMethod.apply(this, args);
        }
      }

      // Timeout wrapper
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => {
          reject(new Error(`Transactional method "${propertyKey}" timed out after ${timeout}ms`));
        }, timeout);
      });

      const runPromise = txManager.run(async (tx: ITransactionContext) => {
        // tx را به‌عنوان آخرین آرگومان به متد اصلی پاس بده
        return originalMethod.apply(this, [...args, tx]);
      });

      return Promise.race([runPromise, timeoutPromise]);
    };

    // ذخیره metadata برای reflection
    if (!target.constructor[TRANSACTIONAL_METADATA]) {
      target.constructor[TRANSACTIONAL_METADATA] = [];
    }
    target.constructor[TRANSACTIONAL_METADATA].push({
      method: propertyKey,
      options: { joinExisting, timeout },
    });

    // برگرداندن descriptor برای حفظ enumerate / configurable
    return descriptor;
  };
}

// ============================================================
// Helper: لیست تمام متدهای @Transactional روی یک کلاس
// ============================================================
export function getTransactionalMethods(targetClass: any): Array<{
  method: string;
  options: TransactionalOptions;
}> {
  return targetClass[TRANSACTIONAL_METADATA] || [];
}

// ============================================================
// Base UseCase Class — راحتی برای ساخت UseCaseهای transactional
// ============================================================
/**
 * تمام UseCaseها باید از این کلاس ارث‌بری کنند.
 * این کلاس txManager را به‌صورت خودکار در دسترس قرار می‌دهد
 * تا @Transactional بتواند از آن استفاده کند.
 *
 * استفاده:
 *
 *   export class OrderUseCase extends BaseUseCase {
 *     constructor(
 *       private orderRepo: IOrderRepository,
 *       txManager: ITransactionManager,
 *     ) {
 *       super(txManager);
 *     }
 *
 *     @Transactional()
 *     async createOrder(input, ctx, tx) {
 *       // ...
 *     }
 *   }
 */
export abstract class BaseUseCase {
  protected txManager: ITransactionManager;

  constructor(txManager: ITransactionManager) {
    this.txManager = txManager;
  }
}
