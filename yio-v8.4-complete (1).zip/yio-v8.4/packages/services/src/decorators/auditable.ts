// ============================================================
// YIO V8.1 — @Auditable Decorator
// ============================================================
// این decorator به‌طور خودکار Audit Log را برای یک متد تولید می‌کند.
// به‌جای اینکه هر Handler خودش tx.collectAudit صدا بزند، این کار
// توسط decorator انجام می‌شود — اصل Single Responsibility حفظ می‌شود.
//
// نحوه استفاده:
//
//   class OrderUseCase {
//     @Auditable({
//       entityType: 'Order',
//       action: 'order.create',
//       operation: 'create',
//       // گرفتن entityId از خروجی متد
//       getEntityId: (result) => result.orderId,
//       // گرفتن changes (اختیاری)
//       getChanges: (input, result) => ({ ... }),
//     })
//     async createOrder(input, ctx, tx) {
//       // فقط منطق business
//       return { orderId: 1, orderNumber: 'YIO-1' };
//     }
//   }
//
// نکته: @Auditable باید داخل @Transactional استفاده شود (یا متد باید
// tx را به‌عنوان آخرین آرگومان بپذیرد).
// ============================================================

import {
  IAuditLogger,
  ITransactionContext,
  Context,
  AuditEntry,
} from '@yio/core';

// ============================================================
// Options
// ============================================================
interface AuditableOptions {
  /** نوع موجودیت (مثلاً 'Order', 'Product') */
  entityType: string;
  /** action برای audit log (مثلاً 'order.create') */
  action: string;
  /** نوع operation */
  operation?: 'create' | 'update' | 'delete' | 'read' | 'login' | 'logout' | 'export' | 'config';
  /**
   * تابعی برای گرفتن entityId از خروجی متد.
   * اگر ارائه نشود، متد باید entityId را در خروجی برگرداند.
   */
  getEntityId?: (result: any) => number | string;
  /**
   * تابعی برای گرفتن changes (old/new values).
   * پارامترها: (input, oldValues?, result?)
   */
  getChanges?: (input: any, oldValues: any, result: any) => Record<string, { old: any; new: any }>;
  /**
   * تابعی برای گرفتن metadata اضافی.
   */
  getMetadata?: (input: any, result: any) => Record<string, any>;
  /**
   * اگر true باشد، در صورت throw شدن متد، یک audit از نوع 'failed' هم ثبت می‌کند.
   * Default: true
   */
  logFailures?: boolean;
}

// ============================================================
// Decorator Factory
// ============================================================
export function Auditable(options: AuditableOptions) {
  const {
    entityType,
    action,
    operation = 'update',
    getEntityId,
    getChanges,
    getMetadata,
    logFailures = true,
  } = options;

  return function (
    target: any,
    propertyKey: string,
    descriptor: PropertyDescriptor,
  ): PropertyDescriptor {
    const originalMethod = descriptor.value;

    descriptor.value = async function (...args: any[]): Promise<any> {
      // پیدا کردن auditLogger روی instance
      const auditLogger: IAuditLogger | undefined = (this as any).auditLogger
        || (this as any)._auditLogger
        || (this as any).audit;

      // پیدا کردن txManager (برای collectAudit)
      const txManager: any = (this as any).txManager;

      // آخرین آرگومان همیشه Context است (قرارداد پروژه)
      const ctx: Context | undefined = args.length >= 1 ? args[args.length - 2] : undefined;
      const tx: ITransactionContext | undefined = args.length >= 1
        ? args[args.length - 1]
        : undefined;

      // input (آرگومان اول، به جز ctx)
      const input = args[0];

      // برای تغییرات قدیمی — fetch oldValues before executing
      let oldValues: any = {};
      if (getChanges && (this as any).getEntityForAudit) {
        try {
          oldValues = await (this as any).getEntityForAudit(input, ctx);
        } catch {
          // اگر fetch old values ناموفق بود، نادیده بگیر
        }
      }

      let result: any;
      let error: any;

      try {
        result = await originalMethod.apply(this, args);
        return result;
      } catch (err) {
        error = err;
        if (logFailures && auditLogger) {
          // ثبت Audit برای عملیات ناموفق
          await auditLogger.log({
            tenantId: ctx?.tenantId || 0,
            userId: ctx?.userId,
            userRole: ctx?.userRole,
            action: `${action}.failed`,
            entityType,
            entityId: 0,
            operation,
            metadata: {
              error: (err as Error).message,
              input: sanitizeForAudit(input),
            },
            ip: ctx?.ip,
            userAgent: ctx?.userAgent,
            requestId: ctx?.requestId,
            timestamp: new Date(),
          });
        }
        throw err;
      } finally {
        // ثبت Audit موفق فقط اگر خطا نباشد
        if (!error && (auditLogger || tx)) {
          const entityId = getEntityId ? getEntityId(result) : (result?.id ?? result?.entityId ?? 0);
          const changes = getChanges ? getChanges(input, oldValues, result) : undefined;
          const metadata = getMetadata ? getMetadata(input, result) : undefined;

          const auditEntry: AuditEntry = {
            tenantId: ctx?.tenantId || 0,
            userId: ctx?.userId,
            userRole: ctx?.userRole,
            action,
            entityType,
            entityId,
            operation,
            changes,
            metadata,
            ip: ctx?.ip,
            userAgent: ctx?.userAgent,
            requestId: ctx?.requestId,
            timestamp: new Date(),
          };

          // اگر tx موجود است، آن را در tx collect کن (تا با commit، audit هم persist شود)
          if (tx && typeof tx.collectAudit === 'function') {
            tx.collectAudit(auditEntry);
          } else if (auditLogger) {
            // در غیر این صورت، مستقیم در auditLogger بنویس
            await auditLogger.log(auditEntry);
          }
        }
      }
    };

    return descriptor;
  };
}

// ============================================================
// Helper: پاکسازی input برای audit (حذف فیلدهای حساس)
// ============================================================
function sanitizeForAudit(input: any): any {
  if (!input || typeof input !== 'object') return input;
  const sanitized = { ...input };
  // حذف فیلدهای حساس
  delete sanitized.password;
  delete sanitized.token;
  delete sanitized.creditCard;
  delete sanitized.cvv;
  return sanitized;
}

// ============================================================
// Helper: گرفتن آرگومان Context از لیست آرگومان‌ها
// ============================================================
function extractContext(args: any[]): Context | undefined {
  // Context معمولاً آخرین یا یکی از آخرین آرگومان‌هاست
  for (let i = args.length - 1; i >= 0; i--) {
    const arg = args[i];
    if (arg && typeof arg === 'object' && 'tenantId' in arg && !('transactionId' in arg)) {
      return arg as Context;
    }
  }
  return undefined;
}
