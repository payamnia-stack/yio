// ============================================================
// YIO V8.2 — Rules Barrel (Fixed — no duplicate exports)
// ============================================================
// در V8.1، export * از چند فایل باعث تضاد نام‌ها می‌شد (مثلاً
// WholesaleDiscountRule در هر دو فایل order-rules و discount-rules
// موجود بود). در V8.2، export صریح انجام می‌شود تا تضاد نباشد.
// ============================================================

// V8.0 Rules — explicit exports
export {
  MaxOrderQuantityRule,
  MinimumOrderAmountRule,
  WorkingHoursRule,
  BlacklistedCustomerRule,
  ORDER_RULES,
} from './order-rules';

export {
  NegativeStockRule as NegativeStockRuleV8,
  StockThresholdRule as StockThresholdRuleV8,
  INVENTORY_RULES,
} from './inventory-rules';

export * from './accounting-rules';

// V8.1 Granular Rules
export * from './discount-rules';
export * from './inventory-rules-v81';
export * from './credit-rules';
export * from './shipping-rules';
export * from './duplicate-order-rules';

import { IRuleRegistry } from '@yio/core';
import { ORDER_RULES } from './order-rules';
import { INVENTORY_RULES } from './inventory-rules';
import { ACCOUNTING_RULES } from './accounting-rules';
import { DISCOUNT_RULES } from './discount-rules';
import { INVENTORY_RULES_V81 } from './inventory-rules-v81';
import { CREDIT_RULES } from './credit-rules';
import { SHIPPING_RULES } from './shipping-rules';
import { DUPLICATE_ORDER_RULES } from './duplicate-order-rules';

/**
 * ثبت همه Ruleهای پیش‌فرض V8.0 در Registry
 * (برای backward compatibility)
 */
export function registerAllDefaultRules(registry: IRuleRegistry): void {
  for (const rule of [...ORDER_RULES, ...INVENTORY_RULES, ...ACCOUNTING_RULES]) {
    if (!registry.list().some((r) => r.name === rule.name)) {
      registry.register(rule);
    }
  }
}

/**
 * V8.1 — ثبت تمام Ruleهای granular (V8.0 + V8.1)
 */
export function registerAllGranularRules(registry: IRuleRegistry): void {
  const allRules = [
    ...ORDER_RULES,
    ...INVENTORY_RULES,
    ...ACCOUNTING_RULES,
    ...DISCOUNT_RULES,
    ...INVENTORY_RULES_V81,
    ...CREDIT_RULES,
    ...SHIPPING_RULES,
    ...DUPLICATE_ORDER_RULES,
  ];

  for (const rule of allRules) {
    if (!registry.list().some((r) => r.name === rule.name)) {
      registry.register(rule);
    }
  }
}

/**
 * V8.1 — فقط Ruleهای granular جدید
 */
export function registerV81Rules(registry: IRuleRegistry): void {
  const v81Rules = [
    ...DISCOUNT_RULES,
    ...INVENTORY_RULES_V81,
    ...CREDIT_RULES,
    ...SHIPPING_RULES,
    ...DUPLICATE_ORDER_RULES,
  ];

  for (const rule of v81Rules) {
    if (!registry.list().some((r) => r.name === rule.name)) {
      registry.register(rule);
    }
  }
}
