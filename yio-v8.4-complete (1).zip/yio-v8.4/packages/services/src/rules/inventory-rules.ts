// ============================================================
// YIO V8 — Concrete Rules (Inventory Domain)
// ============================================================
import { BaseRule, rulePass, ruleFail } from '../rule-engine/registry';
import { IRuleContext, IRuleResult } from '@yio/core';

export class NegativeStockRule extends BaseRule {
  readonly name = 'inventory.negative_stock';
  readonly appliesTo = 'inventory.stock_out';
  readonly priority = 5;

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const quantity: number = rc.data?.quantity || 0;
    const currentStock: number = rc.data?.currentStock || 0;
    if (quantity > currentStock) {
      return ruleFail(
        `موجودی کافی نیست. درخواست: ${quantity}، موجودی فعلی: ${currentStock}`,
      );
    }
    return rulePass();
  }
}

export class StockThresholdRule extends BaseRule {
  readonly name = 'inventory.low_stock_threshold';
  readonly appliesTo = 'inventory.stock_out';
  readonly priority = 50;

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const newStock: number = rc.data?.newStock ?? 0;
    const threshold: number = rc.data?.threshold ?? 10;
    if (newStock < threshold) {
      return rulePass(`⚠️ موجودی به آستانه هشدار رسیده است (${newStock} < ${threshold}).`);
    }
    return rulePass();
  }
}

export const INVENTORY_RULES = [new NegativeStockRule(), new StockThresholdRule()];
