// ============================================================
// YIO V8.1 — Shipping Rules
// ============================================================
// این Ruleها برای محاسبه و اعتبارسنجی ارسال استفاده می‌شوند:
//   - ShippingZoneRule        (منطقه مجاز برای ارسال)
//   - FreeShippingThresholdRule (حداقل مبلغ برای ارسال رایگان)
//   - ShippingWeightLimitRule (حداکثر وزن بسته)
//   - RemoteAreaSurchargeRule  (هزینه اضافی مناطق دور)
// ============================================================

import { BaseRule, rulePass, ruleFail, ruleWarn } from '../rule-engine/registry';
import { IRuleContext, IRuleResult } from '@yio/core';

// ============================================================
// Free Shipping Threshold — حداقل مبلغ برای ارسال رایگان
// ============================================================
export class FreeShippingThresholdRule extends BaseRule {
  readonly name = 'shipping.free_threshold';
  readonly appliesTo = 'order.create';
  readonly priority = 60;

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const totalAmount: number = rc.data?.totalAmount || 0;
    const threshold: number = rc.data?.freeShippingThreshold || 500000;

    if (totalAmount >= threshold) {
      return ruleWarn(
        `🎉 ارسال رایگان اعمال شد (سفارش بالای ${threshold.toLocaleString('fa-IR')} تومان).`,
        { shippingCost: 0, shippingType: 'free' },
      );
    }
    return rulePass();
  }
}

// ============================================================
// Shipping Zone — منطقه مجاز برای ارسال
// ============================================================
export class ShippingZoneRule extends BaseRule {
  readonly name = 'shipping.zone_check';
  readonly appliesTo = 'order.create';
  readonly priority = 15;

  // استان‌های غیرقابل ارسال (مثال)
  private readonly blockedProvinces: string[] = [];

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const shippingCity: string = rc.data?.shippingCity || '';
    const shippingProvince: string = rc.data?.shippingProvince || '';

    if (this.blockedProvinces.includes(shippingProvince)) {
      return ruleFail(
        `ارسال به استان «${shippingProvince}» در حال حاضر مقدور نیست.`,
      );
    }

    if (!shippingCity && rc.data?.shippingAddress) {
      return ruleWarn('شهر گیرنده مشخص نشده — ممکن است تأخیر در ارسال رخ دهد.');
    }

    return rulePass();
  }
}

// ============================================================
// Shipping Weight Limit — حداکثر وزن بسته
// ============================================================
export class ShippingWeightLimitRule extends BaseRule {
  readonly name = 'shipping.weight_limit';
  readonly appliesTo = 'order.create';
  readonly priority = 18;

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const items: any[] = rc.data?.items || [];
    const totalWeight: number = items.reduce(
      (sum, i) => sum + (i.weight || 0) * (i.quantity || 1),
      0,
    );
    const maxWeight: number = rc.data?.maxShippingWeight || 30000; // 30kg default

    if (totalWeight > maxWeight) {
      return ruleFail(
        `وزن کل سفارش (${totalWeight}g) از حداکثر مجاز (${maxWeight}g) بیشتر است. ` +
        `لطفاً سفارش را به چند بسته تقسیم کنید.`,
      );
    }
    return rulePass();
  }
}

// ============================================================
// Remote Area Surcharge — هزینه اضافی مناطق دور
// ============================================================
export class RemoteAreaSurchargeRule extends BaseRule {
  readonly name = 'shipping.remote_surcharge';
  readonly appliesTo = 'order.create';
  readonly priority = 65;

  private readonly remoteProvinces: string[] = [
    'سیستان و بلوچستان',
    'هرمزگان',
    'خراسان جنوبی',
  ];

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const shippingProvince: string = rc.data?.shippingProvince || '';

    if (this.remoteProvinces.includes(shippingProvince)) {
      const surcharge = 50000; // ۵۰ هزار تومان اضافه
      return ruleWarn(
        `📍 هزینه اضافی ارسال به منطقه دور (${shippingProvince}): ${surcharge.toLocaleString('fa-IR')} تومان.`,
        { shippingSurcharge: surcharge, shippingType: 'remote' },
      );
    }
    return rulePass();
  }
}

export const SHIPPING_RULES = [
  new FreeShippingThresholdRule(),
  new ShippingZoneRule(),
  new ShippingWeightLimitRule(),
  new RemoteAreaSurchargeRule(),
];
