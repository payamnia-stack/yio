// ============================================================
// YIO V8.1 — Granular Inventory Rules
// ============================================================
// این Ruleها برای actionهای inventory.* استفاده می‌شوند:
//   - NegativeStockRule      (جلوگیری از خروج بیش از موجودی)
//   - StockThresholdRule     (هشدار آستانه پایین)
//   - ReservationExpiryRule  (انقضای رزرو پس از ۲۴ ساعت)
//   - WarehouseCapacityRule  (ظرفیت انبار)
// ============================================================

import { BaseRule, rulePass, ruleFail, ruleWarn } from '../rule-engine/registry';
import { IRuleContext, IRuleResult } from '@yio/core';

// ============================================================
// Negative Stock — جلوگیری از خروج بیش از موجودی
// ============================================================
export class NegativeStockRule extends BaseRule {
  readonly name = 'inventory.negative_stock';
  readonly appliesTo = 'inventory.stock_out';
  readonly priority = 5;

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const quantity: number = rc.data?.quantity || 0;
    const currentStock: number = rc.data?.currentStock || 0;

    if (quantity > currentStock) {
      return ruleFail(
        `موجودی کافی نیست. درخواست: ${quantity}، موجودی فعلی: ${currentStock}`,
      );
    }
    return rulePass();
  }
}

// ============================================================
// Stock Threshold — هشدار آستانه پایین
// ============================================================
export class StockThresholdRule extends BaseRule {
  readonly name = 'inventory.low_stock_threshold';
  readonly appliesTo = 'inventory.stock_out';
  readonly priority = 50;

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const newStock: number = rc.data?.newStock ?? 0;
    const threshold: number = rc.data?.threshold ?? 10;

    if (newStock < threshold) {
      return ruleWarn(
        `⚠️ موجودی به آستانه هشدار رسید (${newStock} < ${threshold}).`,
      );
    }
    return rulePass();
  }
}

// ============================================================
// Reservation Expiry — انقضای رزرو پس از ۲۴ ساعت
// ============================================================
export class ReservationExpiryRule extends BaseRule {
  readonly name = 'inventory.reservation_expiry';
  readonly appliesTo = 'inventory.reserve';
  readonly priority = 10;

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const reservationDuration: number = rc.data?.durationHours || 24;

    if (reservationDuration > 24) {
      return ruleFail(
        `مدت رزرو نمی‌تواند بیشتر از ۲۴ ساعت باشد (درخواست: ${reservationDuration} ساعت).`,
      );
    }
    return rulePass();
  }
}

// ============================================================
// Warehouse Capacity — ظرفیت انبار
// ============================================================
export class WarehouseCapacityRule extends BaseRule {
  readonly name = 'inventory.warehouse_capacity';
  readonly appliesTo = 'inventory.stock_in';
  readonly priority = 15;

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const incomingQty: number = rc.data?.quantity || 0;
    const currentQty: number = rc.data?.currentStock || 0;
    const maxCapacity: number = rc.data?.maxCapacity || 10000;

    if (currentQty + incomingQty > maxCapacity) {
      return ruleFail(
        `ظرفیت انبار کافی نیست. ظرفیت: ${maxCapacity}، موجود: ${currentQty}، ورودی: ${incomingQty}.`,
      );
    }
    return rulePass();
  }
}

export const INVENTORY_RULES_V81 = [
  new NegativeStockRule(),
  new StockThresholdRule(),
  new ReservationExpiryRule(),
  new WarehouseCapacityRule(),
];
