// ============================================================
// YIO V8.1 — Duplicate Order Detection Rules
// ============================================================
// جلوگیری از ثبت سفارش تکراری (معمولاً به دلیل double-click کاربر
// یا retry شبکه):
//   - DuplicateOrderWithinWindowRule  (همان سفارش در ۵ دقیقه اخیر)
//   - IdenticalItemsDuplicateRule     (همان اقلام و همان آدرس)
// ============================================================

import { BaseRule, rulePass, ruleFail, ruleWarn } from '../rule-engine/registry';
import { IRuleContext, IRuleResult } from '@yio/core';

// ============================================================
// Duplicate Order Within Window
// جلوگیری از ثبت سفارش تکراری در یک بازه زمانی کوتاه
// ============================================================
export class DuplicateOrderWithinWindowRule extends BaseRule {
  readonly name = 'order.duplicate_within_window';
  readonly appliesTo = 'order.create';
  readonly priority = 2; // خیلی مهم — قبل از بقیه بررسی شود

  // پنجره زمانی برای تشخیص duplicate (دقیقه)
  private readonly windowMinutes: number = 5;

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const lastOrderAt: Date | undefined = rc.data?.customerLastOrderAt;
    if (!lastOrderAt) return rulePass();

    const now = new Date();
    const diffMs = now.getTime() - new Date(lastOrderAt).getTime();
    const diffMinutes = diffMs / (1000 * 60);

    if (diffMinutes < this.windowMinutes) {
      // اگر در ۵ دقیقه اخیر سفارش ثبت شده، بررسی دقیق‌تر انجام بده
      const lastOrderItems: any[] = rc.data?.customerLastOrderItems || [];
      const currentItems: any[] = rc.data?.items || [];

      // اگر اقلام کاملاً یکسان هستند → تکرار قطعی
      if (this.itemsEqual(lastOrderItems, currentItems)) {
        return ruleFail(
          `سفارش مشابهی در ${Math.ceil(diffMinutes)} دقیقه اخیر ثبت شده است. ` +
          `برای جلوگیری از ثبت تکراری، لطفاً ${this.windowMinutes - Math.ceil(diffMinutes)} دقیقه دیگر صبر کنید ` +
          `یا سفارش قبلی را ویرایش کنید.`,
        );
      }
      return ruleWarn(
        `⚠️ سفارش جدید در کمتر از ${this.windowMinutes} دقیقه پس از سفارش قبلی ثبت می‌شود. ` +
        `لطفاً از صحت اطلاعات اطمینان حاصل کنید.`,
      );
    }

    return rulePass();
  }

  private itemsEqual(a: any[], b: any[]): boolean {
    if (a.length !== b.length) return false;
    const aIds = a.map((i) => `${i.productId}:${i.quantity}`).sort();
    const bIds = b.map((i) => `${i.productId}:${i.quantity}`).sort();
    return aIds.every((v, i) => v === bIds[i]);
  }
}

// ============================================================
// Identical Items Duplicate — بررسی دقیق‌تر اقلام یکسان
// ============================================================
export class IdenticalItemsDuplicateRule extends BaseRule {
  readonly name = 'order.identical_items_duplicate';
  readonly appliesTo = 'order.create';
  readonly priority = 3;

  isApplicable(rc: IRuleContext): boolean {
    // فقط وقتی active می‌شود که اطلاعات سفارش قبلی وجود داشته باشد
    return !!rc.data?.customerLastOrderItems;
  }

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const lastItems: any[] = rc.data?.customerLastOrderItems || [];
    const currentItems: any[] = rc.data?.items || [];

    if (lastItems.length === 0) return rulePass();

    // اگر اقلام و آدرس کاملاً یکسان باشد → احتمالاً تکرار
    const sameShippingAddress =
      rc.data?.shippingAddress === rc.data?.customerLastOrderAddress;

    const sameItems =
      lastItems.length === currentItems.length &&
      lastItems.every((li) =>
        currentItems.some(
          (ci) =>
            ci.productId === li.productId &&
            ci.quantity === li.quantity &&
            ci.color === li.color,
        ),
      );

    if (sameItems && sameShippingAddress) {
      return ruleWarn(
        '⚠️ این سفارش با سفارش قبلی شما (اقلام + آدرس) کاملاً یکسان است. ' +
        'آیا از ثبت آن مطمئن هستید؟',
      );
    }

    return rulePass();
  }
}

export const DUPLICATE_ORDER_RULES = [
  new DuplicateOrderWithinWindowRule(),
  new IdenticalItemsDuplicateRule(),
];
