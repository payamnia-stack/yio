// ============================================================
// YIO V8 — Concrete Rule Implementations (Order Domain)
// ============================================================
// این فایل چند Rule واقعی برای Order domain تعریف می‌کند. هر Rule
// یک کلاس مستقل است که در Registry ثبت می‌شود.
// ============================================================

import {
  BaseRule,
  rulePass,
  ruleFail,
  ruleWarn,
} from '../rule-engine/registry';
import { IRuleContext, IRuleResult } from '@yio/core';

// ============================================================
// Maximum Order Quantity per Item (Anti-abuse)
// ============================================================
export class MaxOrderQuantityRule extends BaseRule {
  readonly name = 'order.max_quantity';
  readonly appliesTo = 'order.create';
  readonly priority = 10;

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const items = rc.data?.items || [];
    for (const item of items) {
      if (item.quantity > 99) {
        return ruleFail(
          `تعداد سفارش برای هر کالا نمی‌تواند بیشتر از ۹۹ باشد (محصول ${item.productId}).`,
        );
      }
    }
    return rulePass();
  }
}

// ============================================================
// Minimum Order Amount (Business Rule)
// ============================================================
export class MinimumOrderAmountRule extends BaseRule {
  readonly name = 'order.minimum_amount';
  readonly appliesTo = 'order.create';
  readonly priority = 20;

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const totalAmount: number = rc.data?.totalAmount || 0;
    const minimum = rc.ctx?.tenantId === 1 ? 100000 : 50000; // configurable

    if (totalAmount < minimum) {
      return ruleFail(
        `حداقل مبلغ سفارش ${minimum.toLocaleString('fa-IR')} تومان است.`,
      );
    }
    return rulePass();
  }
}

// ============================================================
// Working Hours Rule (order.create only in business hours)
// ============================================================
export class WorkingHoursRule extends BaseRule {
  readonly name = 'order.working_hours';
  readonly appliesTo = 'order.create';
  readonly priority = 5;

  isApplicable(rc: IRuleContext): boolean {
    // فقط برای tenantهای خاص (با flag) فعال است
    return rc.data?.enforceWorkingHours === true;
  }

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const hour = new Date().getHours();
    if (hour < 8 || hour > 22) {
      return ruleWarn(
        'سفارش در خارج از ساعات کاری ثبت شده است. بررسی در ساعت کاری بعدی انجام خواهد شد.',
      );
    }
    return rulePass();
  }
}

// ============================================================
// Wholesale Customer Discount Rule
// ============================================================
export class WholesaleDiscountRule extends BaseRule {
  readonly name = 'order.wholesale_discount';
  readonly appliesTo = 'order.create';
  readonly priority = 30;

  isApplicable(rc: IRuleContext): boolean {
    return rc.data?.customerIsWholesale === true;
  }

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const discountRate = rc.data?.wholesaleDiscountRate || 0;
    if (discountRate > 0) {
      const totalAmount = rc.data?.totalAmount || 0;
      const discount = Math.floor((totalAmount * discountRate) / 100);
      return ruleWarn(
        `تخفیف عمده‌فروشی ${discountRate}% اعمال شد (${discount.toLocaleString('fa-IR')} تومان).`,
        { discountAmount: discount, finalAmount: totalAmount - discount },
      );
    }
    return rulePass();
  }
}

// ============================================================
// Blacklisted Customer Rule
// ============================================================
export class BlacklistedCustomerRule extends BaseRule {
  readonly name = 'order.blacklisted_customer';
  readonly appliesTo = 'order.create';
  readonly priority = 1; // مهم‌ترین — اول بررسی شود

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    if (rc.data?.customerIsBlacklisted) {
      return ruleFail('این مشتری در لیست سیاه قرار دارد و امکان ثبت سفارش ندارد.');
    }
    return rulePass();
  }
}

// ============================================================
// Export all rules for easy registration
// ============================================================
export const ORDER_RULES = [
  new MaxOrderQuantityRule(),
  new MinimumOrderAmountRule(),
  new WorkingHoursRule(),
  new WholesaleDiscountRule(),
  new BlacklistedCustomerRule(),
];
