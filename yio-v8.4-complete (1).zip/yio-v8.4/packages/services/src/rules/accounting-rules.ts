// ============================================================
// YIO V8 — Concrete Rules (Accounting Domain)
// ============================================================
import { BaseRule, rulePass, ruleFail } from '../rule-engine/registry';
import { IRuleContext, IRuleResult } from '@yio/core';

export class BalancedJournalEntryRule extends BaseRule {
  readonly name = 'accounting.balanced_entry';
  readonly appliesTo = 'accounting.create_entry';
  readonly priority = 1;

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const lines: any[] = rc.data?.lines || [];
    if (lines.length === 0) {
      return ruleFail('سند حسابداری باید حداقل یک ردیف داشته باشد.');
    }

    const debit = lines.filter((l) => l.type === 'debit').reduce((s, l) => s + l.amount, 0);
    const credit = lines.filter((l) => l.type === 'credit').reduce((s, l) => s + l.amount, 0);

    if (debit !== credit) {
      return ruleFail(
        `سند متوازن نیست. بدهکار: ${debit}، بستانکار: ${credit} (اختلاف: ${Math.abs(debit - credit)}).`,
      );
    }
    return rulePass();
  }
}

export class NegativeAmountRule extends BaseRule {
  readonly name = 'accounting.negative_amount';
  readonly appliesTo = 'accounting.create_entry';
  readonly priority = 5;

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const lines: any[] = rc.data?.lines || [];
    for (const line of lines) {
      if (line.amount < 0) {
        return ruleFail(`مبلغ در ردیف حساب ${line.account} نمی‌تواند منفی باشد.`);
      }
      if (line.amount === 0) {
        return ruleFail(`مبلغ در ردیف حساب ${line.account} صفر است.`);
      }
    }
    return rulePass();
  }
}

export const ACCOUNTING_RULES = [new BalancedJournalEntryRule(), new NegativeAmountRule()];
