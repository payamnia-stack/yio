// ============================================================
// YIO V8.1 — Granular Discount Rules
// ============================================================
// در V8.1، Ruleها به‌صورت جزئی‌تر و تک‌مسئولیتی طراحی شده‌اند.
// این فایل چند نوع Discount Rule را تعریف می‌کند:
//   - WholesaleDiscountRule    (تخفیف عمده‌فروشی)
//   - LoyaltyDiscountRule      (تخفیف وفاداری مشتری)
//   - BulkQuantityDiscountRule (تخفیف خرید عمده)
//   - CouponDiscountRule       (تخفیف کد تخفیف)
// ============================================================

import { BaseRule, rulePass, ruleWarn, ruleFail } from '../rule-engine/registry';
import { IRuleContext, IRuleResult } from '@yio/core';

// ============================================================
// Wholesale Discount — تخفیف مشتریان عمده‌فروش
// ============================================================
export class WholesaleDiscountRule extends BaseRule {
  readonly name = 'discount.wholesale';
  readonly appliesTo = 'order.create';
  readonly priority = 30;

  isApplicable(rc: IRuleContext): boolean {
    return rc.data?.customerIsWholesale === true;
  }

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const discountRate: number = rc.data?.wholesaleDiscountRate || 0;
    if (discountRate <= 0) return rulePass();

    const totalAmount: number = rc.data?.totalAmount || 0;
    const discount = Math.floor((totalAmount * discountRate) / 100);

    return ruleWarn(
      `تخفیف عمده‌فروشی ${discountRate}% اعمال شد (${discount.toLocaleString('fa-IR')} تومان).`,
      { discountAmount: discount, finalAmount: totalAmount - discount, discountType: 'wholesale' },
    );
  }
}

// ============================================================
// Loyalty Discount — تخفیف بر اساس وفاداری مشتری
// ============================================================
export class LoyaltyDiscountRule extends BaseRule {
  readonly name = 'discount.loyalty';
  readonly appliesTo = 'order.create';
  readonly priority = 35;

  isApplicable(rc: IRuleContext): boolean {
    const level: number = rc.data?.customerLevel || 0;
    return level >= 3; // فقط مشتریان سطح ۳ به بالا
  }

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const level: number = rc.data?.customerLevel || 0;
    const totalAmount: number = rc.data?.totalAmount || 0;

    // جدول تخفیف بر اساس level
    const discountTable: Record<number, number> = {
      3: 5,   // سطح ۳: ۵٪
      4: 8,   // سطح ۴: ۸٪
      5: 12,  // سطح ۵: ۱۲٪
    };

    const rate = discountTable[level] || 0;
    if (rate === 0) return rulePass();

    const discount = Math.floor((totalAmount * rate) / 100);
    return ruleWarn(
      `تخفیف وفاداری ${rate}% (سطح ${level}) اعمال شد (${discount.toLocaleString('fa-IR')} تومان).`,
      { discountAmount: discount, finalAmount: totalAmount - discount, discountType: 'loyalty' },
    );
  }
}

// ============================================================
// Bulk Quantity Discount — تخفیف خرید تعداد زیاد
// ============================================================
export class BulkQuantityDiscountRule extends BaseRule {
  readonly name = 'discount.bulk_quantity';
  readonly appliesTo = 'order.create';
  readonly priority = 40;

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const items: any[] = rc.data?.items || [];
    const totalQty = items.reduce((sum, i) => sum + (i.quantity || 0), 0);

    // اگر تعداد کل > 20 → ۳٪ تخفیف
    if (totalQty >= 20) {
      const totalAmount: number = rc.data?.totalAmount || 0;
      const discount = Math.floor((totalAmount * 3) / 100);
      return ruleWarn(
        `تخفیف خرید عمده (۳٪ برای ${totalQty} کالا) اعمال شد (${discount.toLocaleString('fa-IR')} تومان).`,
        { discountAmount: discount, finalAmount: totalAmount - discount, discountType: 'bulk' },
      );
    }
    return rulePass();
  }
}

// ============================================================
// Coupon Discount — اعتبارسنجی کد تخفیف
// ============================================================
export class CouponDiscountRule extends BaseRule {
  readonly name = 'discount.coupon';
  readonly appliesTo = 'order.create';
  readonly priority = 50;

  isApplicable(rc: IRuleContext): boolean {
    return !!rc.data?.couponCode;
  }

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const couponCode: string = rc.data?.couponCode;
    const validCodes: Record<string, { rate: number; minAmount: number }> = {
      'YIO10': { rate: 10, minAmount: 200000 },
      'YIO20': { rate: 20, minAmount: 500000 },
    };

    const coupon = validCodes[couponCode];
    if (!coupon) {
      return ruleFail(`کد تخفیف «${couponCode}» معتبر نیست.`);
    }

    const totalAmount: number = rc.data?.totalAmount || 0;
    if (totalAmount < coupon.minAmount) {
      return ruleFail(
        `برای استفاده از کد «${couponCode}» حداقل مبلغ سفارش باید ${coupon.minAmount.toLocaleString('fa-IR')} تومان باشد.`,
      );
    }

    const discount = Math.floor((totalAmount * coupon.rate) / 100);
    return ruleWarn(
      `کد تخفیف ${couponCode} اعمال شد (${coupon.rate}% = ${discount.toLocaleString('fa-IR')} تومان).`,
      { discountAmount: discount, finalAmount: totalAmount - discount, discountType: 'coupon' },
    );
  }
}

export const DISCOUNT_RULES = [
  new WholesaleDiscountRule(),
  new LoyaltyDiscountRule(),
  new BulkQuantityDiscountRule(),
  new CouponDiscountRule(),
];
