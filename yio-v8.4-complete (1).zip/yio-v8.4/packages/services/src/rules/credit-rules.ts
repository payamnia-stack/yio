// ============================================================
// YIO V8.1 — Credit / Payment Rules
// ============================================================
// این Ruleها برای مدیریت اعتبار و پرداخت استفاده می‌شوند:
//   - CreditLimitRule        (سقف اعتبار مشتری)
//   - OutstandingBalanceRule (مانده بدهی معوق)
//   - InstallmentLimitRule   (سقف اقساط)
// ============================================================

import { BaseRule, rulePass, ruleFail, ruleWarn } from '../rule-engine/registry';
import { IRuleContext, IRuleResult } from '@yio/core';

// ============================================================
// Credit Limit — سقف اعتبار مشتری
// ============================================================
export class CreditLimitRule extends BaseRule {
  readonly name = 'credit.limit_check';
  readonly appliesTo = 'order.create';
  readonly priority = 25;

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const finalAmount: number = rc.data?.finalAmount || rc.data?.totalAmount || 0;
    const creditLimit: number = rc.data?.customerCreditLimit || 0;
    const outstandingBalance: number = rc.data?.customerOutstandingBalance || 0;
    const paymentMethod: string = rc.data?.paymentMethod || 'cod';

    // فقط برای پرداخت اعتباری (نه نقدی)
    if (paymentMethod !== 'credit') return rulePass();

    const availableCredit = creditLimit - outstandingBalance;
    if (finalAmount > availableCredit) {
      return ruleFail(
        `سقف اعتبار کافی نیست. سقف: ${creditLimit.toLocaleString('fa-IR')}، ` +
        `مانده بدهی: ${outstandingBalance.toLocaleString('fa-IR')}، ` +
        `مبلغ سفارش: ${finalAmount.toLocaleString('fa-IR')}، ` +
        `اعتبار قابل استفاده: ${availableCredit.toLocaleString('fa-IR')}.`,
      );
    }
    return rulePass();
  }
}

// ============================================================
// Outstanding Balance — مانده بدهی معوق
// ============================================================
export class OutstandingBalanceRule extends BaseRule {
  readonly name = 'credit.outstanding_balance';
  readonly appliesTo = 'order.create';
  readonly priority = 22;

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const overdueAmount: number = rc.data?.customerOverdueAmount || 0;
    const overdueLimit: number = 500000; // ۵۰۰ هزار تومان

    if (overdueAmount > overdueLimit) {
      return ruleFail(
        `امکان ثبت سفارش جدید وجود ندارد. مانده بدهی معوق شما: ` +
        `${overdueAmount.toLocaleString('fa-IR')} تومان (بیش از سقف مجاز ${overdueLimit.toLocaleString('fa-IR')}).`,
      );
    }
    if (overdueAmount > 0) {
      return ruleWarn(
        `⚠️ شما ${overdueAmount.toLocaleString('fa-IR')} تومان بدهی معوق دارید. ` +
        `لطفاً در اسرع وقت تسویه کنید.`,
      );
    }
    return rulePass();
  }
}

// ============================================================
// Installment Limit — سقف تعداد اقساط فعال
// ============================================================
export class InstallmentLimitRule extends BaseRule {
  readonly name = 'credit.installment_limit';
  readonly appliesTo = 'order.create';
  readonly priority = 28;

  isApplicable(rc: IRuleContext): boolean {
    return rc.data?.paymentMethod === 'installment';
  }

  async evaluate(rc: IRuleContext): Promise<IRuleResult> {
    const activeInstallments: number = rc.data?.customerActiveInstallments || 0;
    const maxInstallments: number = rc.data?.maxActiveInstallments || 3;

    if (activeInstallments >= maxInstallments) {
      return ruleFail(
        `تعداد اقساط فعال شما به سقف رسیده است (${activeInstallments}/${maxInstallments}). ` +
        `امکان ثبت سفارش اقساطی جدید وجود ندارد.`,
      );
    }
    return rulePass();
  }
}

export const CREDIT_RULES = [
  new CreditLimitRule(),
  new OutstandingBalanceRule(),
  new InstallmentLimitRule(),
];
