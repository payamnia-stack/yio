// ============================================================
// YIO V8 — Rule Registry (Extensible)
// ============================================================
// در V8، Rule Engine به‌صورت یک Registry از کلاس‌های مستقل Rule
// طراحی شده است. هر Rule اینترفیس IRule را پیاده‌سازی می‌کند.
// این کار امکان افزودن Rule جدید را بدون تغییر RuleEngine فراهم می‌کند.
// ============================================================

import {
  IRule,
  IRuleRegistry,
  IRuleContext,
  IRuleResult,
  Context,
} from '@yio/core';

export class RuleRegistry implements IRuleRegistry {
  private rules: Map<string, IRule> = new Map();

  register(rule: IRule): void {
    if (this.rules.has(rule.name)) {
      throw new Error(`Rule "${rule.name}" is already registered.`);
    }
    this.rules.set(rule.name, rule);
    console.log(`[RuleRegistry] 📥 Registered rule: ${rule.name} (action: ${rule.appliesTo})`);
  }

  unregister(ruleName: string): void {
    this.rules.delete(ruleName);
  }

  /**
   * V8.1: getRulesForAction حالا `data` واقعی را برای بررسی isApplicable دریافت می‌کند.
   * در V8.0، data={} خالی ارسال می‌شد که باعث می‌شد Ruleهایی که به data وابسته‌اند
   * (مثل CouponRule, WorkingHoursRule) هرگز فعال نشوند.
   */
  getRulesForAction(action: string, ctx: Context, data?: any): IRule[] {
    const matched: IRule[] = [];
    for (const rule of this.rules.values()) {
      const rc: IRuleContext = { action, data: data || {}, ctx, engine: undefined };
      if (rule.appliesTo === action || rule.appliesTo === '*' || action.startsWith(rule.appliesTo)) {
        if (rule.isApplicable(rc)) {
          matched.push(rule);
        }
      }
    }
    // مرتب‌سازی بر اساس priority (کم‌ترین اول)
    return matched.sort((a, b) => a.priority - b.priority);
  }

  list(): IRule[] {
    return Array.from(this.rules.values()).sort((a, b) => a.priority - b.priority);
  }
}

// ============================================================
// Base Rule Class — راحتی برای پیاده‌سازی Ruleهای جدید
// ============================================================
export abstract class BaseRule implements IRule {
  abstract readonly name: string;
  abstract readonly appliesTo: string;
  readonly priority: number = 100;

  isApplicable(_rc: IRuleContext): boolean {
    return true;
  }

  abstract evaluate(rc: IRuleContext): Promise<IRuleResult>;
}

// ============================================================
// Result Helpers
// ============================================================
export function rulePass(message?: string): IRuleResult {
  return { passed: true, severity: 'info', message };
}

export function ruleWarn(message: string, adjustedData?: any): IRuleResult {
  return { passed: true, severity: 'warn', message, adjustedData };
}

export function ruleFail(message: string): IRuleResult {
  return { passed: false, severity: 'error', message };
}
