// ============================================================
// YIO V8 — DI Container (Lightweight, No External Dep)
// ============================================================
// یک Container سبک بدون نیاز به کتابخانه خارجی مثل tsyringe یا
// inversify. این Container:
//   - Singleton / Transient / Scoped lifetimes
//   - Factory-based binding
//   - instance pre-binding برای performance
//   - Scope برای Request-scoped services (مثل Context)
// ============================================================

import { IContainer, Lifetime } from '@yio/core';

interface Binding<T> {
  factory: (c: IContainer) => T | Promise<T>;
  lifetime: Lifetime;
  instance?: T;       // برای Singleton بعد از instantiation
  resolved?: boolean; // آیا قبلاً ساخته شده؟
}

export class Container implements IContainer {
  private bindings: Map<string, Binding<any>> = new Map();
  private instances: Map<string, any> = new Map();
  private parent: IContainer | null = null;

  constructor(parent?: IContainer) {
    this.parent = parent || null;
  }

  // ============================================================
  // Bindings
  // ============================================================
  bind<T>(
    token: string,
    factory: (c: IContainer) => T | Promise<T>,
    lifetime: Lifetime = 'transient',
  ): void {
    this.bindings.set(token, { factory, lifetime });
  }

  bindInstance<T>(token: string, instance: T): void {
    this.bindings.set(token, {
      factory: () => instance,
      lifetime: 'singleton',
      instance,
      resolved: true,
    });
  }

  // ============================================================
  // Resolve
  // ============================================================
  async resolve<T>(token: string): Promise<T> {
    // ۱) اگر در scope خودمان هست
    const localBinding = this.bindings.get(token);
    if (localBinding) {
      return this.resolveFromBindingAsync<T>(localBinding, token);
    }

    // ۲) اگر در parent هست
    if (this.parent) {
      return this.parent.resolve<T>(token);
    }

    throw new Error(
      `No binding registered for token "${token}". ` +
      `Make sure to register it in bootstrap (apps/api/src/bootstrap.ts).`,
    );
  }

  resolveSync<T>(token: string): T {
    const localBinding = this.bindings.get(token);
    if (!localBinding) {
      if (this.parent) {
        return (this.parent as Container).resolveSync<T>(token);
      }
      throw new Error(`No binding registered for token "${token}" (sync).`);
    }

    if (localBinding.lifetime === 'singleton' && localBinding.resolved && localBinding.instance !== undefined) {
      return localBinding.instance as T;
    }

    if (localBinding.lifetime === 'transient' || localBinding.lifetime === 'scoped') {
      const maybe = localBinding.factory(this);
      if (maybe instanceof Promise) {
        throw new Error(
          `Cannot resolve "${token}" synchronously because its factory is async. ` +
          `Use resolve<T>() instead of resolveSync<T>().`,
        );
      }
      return maybe as T;
    }

    throw new Error(
      `Cannot resolve singleton "${token}" synchronously because it has not been instantiated yet. ` +
      `Call resolve<T>() once at startup.`,
    );
  }

  private async resolveFromBindingAsync<T>(binding: Binding<any>, token: string): Promise<T> {
    if (binding.lifetime === 'singleton') {
      if (binding.resolved && binding.instance !== undefined) {
        return binding.instance as T;
      }
      const instance = await binding.factory(this);
      binding.instance = instance;
      binding.resolved = true;
      return instance as T;
    }

    // transient یا scoped: همیشه factory جدید فراخوانی کن
    const instance = await binding.factory(this);
    return instance as T;
  }

  has(token: string): boolean {
    if (this.bindings.has(token)) return true;
    if (this.parent) return this.parent.has(token);
    return false;
  }

  // ============================================================
  // Scopes
  // ============================================================
  createScope(): IContainer {
    const scope = new Container(this);
    // در scope، bindingهای transient خود scope می‌شوند
    // (parent's singletons از parent به ارث می‌رسند)
    return scope;
  }

  // ============================================================
  // Helpers
  // ============================================================
  reset(): void {
    this.bindings.clear();
    this.instances.clear();
  }

  listBindings(): string[] {
    return Array.from(this.bindings.keys());
  }
}

// ============================================================
// Singleton Root Container
// ============================================================
let rootContainer: Container | null = null;

export function getContainer(): Container {
  if (!rootContainer) {
    rootContainer = new Container();
  }
  return rootContainer;
}

export function setContainer(c: Container): void {
  rootContainer = c;
}

export function resetContainer(): void {
  if (rootContainer) {
    rootContainer.reset();
  }
  rootContainer = null;
}
