// ============================================================
// YIO V8 — Service Layer Entry Point
// ============================================================
// در V8 علاوه بر ۱۰ Engine، زیرساخت‌های زیر اضافه شده:
//   - Unit of Work (PrismaUnitOfWork / PrismaTransactionManager)
//   - Event Store (PrismaEventStore)
//   - Audit Logger (AuditLogger / PrismaAuditLogRepository)
//   - Cache Layer (InMemoryCache / RedisCache)
//   - DI Container (Container)
//   - CQRS (CommandBus / QueryBus)
//   - Rule Registry + Concrete Rules
// ============================================================

// Event Bus (V8 — Typed)
export { InMemoryEventBus, getEventBus, resetEventBus } from './event-bus/event-bus';

// ===== V8 Infrastructure =====

// Unit of Work + Transaction Manager
export {
  PrismaUnitOfWork,
  PrismaTransactionContext,
  PrismaTransactionManager,
} from './unit-of-work';

// Event Store
export {
  PrismaEventStore,
  PrismaEventStoreRepository,
} from './event-store';

// Audit Logger
export {
  AuditLogger,
  PrismaAuditLogRepository,
} from './audit';

// Cache Layer
export {
  InMemoryCache,
  RedisCache,
  createCache,
  cached,
  setGlobalCache,
  getGlobalCache,
} from './cache';

// DI Container
export {
  Container,
  getContainer,
  setContainer,
  resetContainer,
} from './di';

// V8.1 — Logger Implementations
export {
  ConsoleLogger,
  NoopLogger,
  PinoLogger,
  createLogger,
} from './logger';

// V8.1 — Decorators (@Transactional / @Auditable)
export {
  Transactional,
  BaseUseCase,
  getTransactionalMethods,
  Auditable,
} from './decorators';

// V8.1 — UseCases (showcase of decorator usage)
export { OrderUseCase } from './usecases';
export type { CreateOrderInput, CreateOrderResult } from './usecases';

// CQRS
export {
  CommandBus,
  QueryBus,
  OrderCommandHandlers,
  OrderQueryHandlers,
  CreateOrderCommand,
  ConfirmOrderCommand,
  ShipOrderCommand,
  CancelOrderCommand,
  DeliverOrderCommand,
  PayOrderCommand,
  GetOrderByIdQuery,
  ListOrdersQuery,
  GetUserOrdersQuery,
  GetOrderStatsQuery,
  SearchOrdersQuery,
} from './cqrs';

// Rule Registry + Concrete Rules
export {
  RuleRegistry,
  BaseRule,
  rulePass,
  ruleFail,
  ruleWarn,
} from './rule-engine';
export {
  ORDER_RULES,
  INVENTORY_RULES,
  ACCOUNTING_RULES,
  registerAllDefaultRules,
  // V8.1 Granular Rules
  DISCOUNT_RULES,
  INVENTORY_RULES_V81,
  CREDIT_RULES,
  SHIPPING_RULES,
  DUPLICATE_ORDER_RULES,
  registerAllGranularRules,
  registerV81Rules,
} from './rules';

// ===== 10 Business Engines =====

// 1) Order Engine (V8 — Refactored)
export { OrderEngine } from './engines/order-engine';

// 2) Production Engine
export { ProductionEngine } from './engines/production-engine';

// 3) Inventory Engine
export { InventoryEngine } from './engines/inventory-engine';

// 4) Pricing Engine
export {
  PricingEngine,
  type CostBreakdown,
  type PricingInput,
  type PricingResult,
} from './engines/pricing-engine';

// 5) Accounting Engine
export {
  AccountingEngine,
  ACCOUNT_TYPES,
  DEFAULT_ACCOUNTS,
  type JournalEntry,
  type JournalLine,
  type TrialBalanceItem,
  type ProfitLossReport,
  type BalanceSheetReport,
} from './engines/accounting-engine';

// 6) Workflow Engine
export {
  WorkflowEngine,
  DEFAULT_WORKFLOWS,
  type WorkflowState,
  type WorkflowCondition,
  type WorkflowContext,
  type WorkflowHistoryEntry,
} from './engines/workflow-engine';

// 7) Notification Engine
export {
  NotificationEngine,
  type NotificationInput,
  type NotificationChannel,
  type NotificationType,
} from './engines/notification-engine';

// 8) Permission Engine (V8 — RBAC + ABAC)
export {
  PermissionChecker,
  PERMISSIONS,
  ROLES,
  requirePermission,
  buildContext,
  type Permission,
  type RoleName,
} from './engines/permission-engine';

// 9) Rule Engine (V8 — Extensible)
export { RuleEngine } from './engines/rule-engine';

// 10) Analytics Engine
export {
  AnalyticsEngine,
  KPIS,
  type MetricDefinition,
  type DashboardData,
  type AnalyticsSnapshotData,
} from './engines/analytics-engine';

// 11) Document Engine
export {
  DocumentEngine,
  type DocumentType,
  type DocumentCategory,
  type DocumentUploadInput,
  type DocumentOutput,
  type DocumentVersion,
  type DocumentSignInput,
} from './engines/document-engine';
