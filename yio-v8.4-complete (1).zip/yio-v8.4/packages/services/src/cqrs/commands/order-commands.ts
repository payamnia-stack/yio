// ============================================================
// YIO V8 — Order Commands
// ============================================================
import { BaseCommand } from '@yio/core';

export class CreateOrderCommand extends BaseCommand {
  readonly commandName = 'CreateOrderCommand';

  constructor(
    public readonly input: {
      customerId?: number;
      userId?: number;
      items: Array<{ productId: number; quantity: number; color?: string }>;
      shippingAddress: string;
      shippingCity?: string;
      postalCode?: string;
      recipientName: string;
      recipientPhone: string;
      paymentMethod: string;
      notes?: string;
    },
  ) {
    super();
  }
}

export class ConfirmOrderCommand extends BaseCommand {
  readonly commandName = 'ConfirmOrderCommand';
  constructor(public readonly orderId: number) {
    super();
  }
}

export class ShipOrderCommand extends BaseCommand {
  readonly commandName = 'ShipOrderCommand';
  constructor(
    public readonly orderId: number,
    public readonly trackingCode: string,
  ) {
    super();
  }
}

export class CancelOrderCommand extends BaseCommand {
  readonly commandName = 'CancelOrderCommand';
  constructor(
    public readonly orderId: number,
    public readonly reason: string,
  ) {
    super();
  }
}

export class DeliverOrderCommand extends BaseCommand {
  readonly commandName = 'DeliverOrderCommand';
  constructor(public readonly orderId: number) {
    super();
  }
}

export class PayOrderCommand extends BaseCommand {
  readonly commandName = 'PayOrderCommand';
  constructor(
    public readonly orderId: number,
    public readonly amount: number,
    public readonly paymentMethod: string,
  ) {
    super();
  }
}
