// ============================================================
// YIO V8 — Command Bus Implementation
// ============================================================
import {
  ICommandBus,
  ICommand,
  ICommandHandler,
  ICommandResult,
  Context,
} from '@yio/core';

export class CommandBus implements ICommandBus {
  private handlers: Map<string, ICommandHandler<any>> = new Map();

  register<C extends ICommand>(commandName: string, handler: ICommandHandler<C>): void {
    if (this.handlers.has(commandName)) {
      throw new Error(`Command "${commandName}" already has a handler registered.`);
    }
    this.handlers.set(commandName, handler);
    console.log(`[CommandBus] 📥 Registered handler for ${commandName}`);
  }

  async execute<C extends ICommand>(command: C, ctx: Context): Promise<ICommandResult> {
    const handler = this.handlers.get(command.commandName);
    if (!handler) {
      return {
        success: false,
        message: `No handler registered for command "${command.commandName}".`,
      };
    }
    const start = Date.now();
    try {
      const result = await handler(command, ctx);
      const duration = Date.now() - start;
      if (duration > 500) {
        console.warn(`[CommandBus] ⚠️ Slow command: ${command.commandName} took ${duration}ms`);
      }
      return result;
    } catch (err: any) {
      console.error(`[CommandBus] ❌ Command ${command.commandName} failed:`, err);
      return {
        success: false,
        message: err.message || 'Unknown error',
      };
    }
  }

  list(): string[] {
    return Array.from(this.handlers.keys());
  }
}
