// ============================================================
// YIO V8 — Order Query Handlers
// ============================================================
// Query Handlerها برای خواندن داده استفاده می‌شوند.
// این Handlerها به Repository یا ReadModel وصل می‌شوند و می‌توانند
// از Cache استفاده کنند.
// ============================================================

import {
  IQueryHandler,
  Context,
  IContainer,
  TOKENS,
} from '@yio/core';
import {
  GetOrderByIdQuery,
  ListOrdersQuery,
  GetUserOrdersQuery,
  GetOrderStatsQuery,
  SearchOrdersQuery,
} from '../queries/order-queries';

export class OrderQueryHandlers {
  constructor(private container: IContainer) {}

  // ============================================================
  // GetOrderByIdQuery
  // ============================================================
  getOrderById: IQueryHandler<GetOrderByIdQuery> = async (query, ctx) => {
    const orderRepo = await this.container.resolve<any>(TOKENS.OrderRepository);
    return orderRepo.findById(query.orderId, ctx);
  };

  // ============================================================
  // ListOrdersQuery
  // ============================================================
  listOrders: IQueryHandler<ListOrdersQuery> = async (query, ctx) => {
    const orderRepo = await this.container.resolve<any>(TOKENS.OrderRepository);
    if (query.status) {
      return orderRepo.findByStatus(query.status, ctx, query.page, query.pageSize);
    }
    return orderRepo.findMany(
      { pagination: { page: query.page, pageSize: query.pageSize } },
      ctx,
    );
  };

  // ============================================================
  // GetUserOrdersQuery
  // ============================================================
  getUserOrders: IQueryHandler<GetUserOrdersQuery> = async (query, ctx) => {
    const orderRepo = await this.container.resolve<any>(TOKENS.OrderRepository);
    return orderRepo.findUserOrders(query.userId, ctx);
  };

  // ============================================================
  // GetOrderStatsQuery
  // ============================================================
  getOrderStats: IQueryHandler<GetOrderStatsQuery> = async (_query, ctx) => {
    const orderRepo = await this.container.resolve<any>(TOKENS.OrderRepository);
    const totalOrders = await orderRepo.count({}, ctx);
    const pending = await orderRepo.count({ status: 'pending' }, ctx);
    const confirmed = await orderRepo.count({ status: 'confirmed' }, ctx);
    const shipped = await orderRepo.count({ status: 'shipping' }, ctx);
    const delivered = await orderRepo.count({ status: 'delivered' }, ctx);
    const cancelled = await orderRepo.count({ status: 'cancelled' }, ctx);
    return { totalOrders, pending, confirmed, shipped, delivered, cancelled };
  };

  // ============================================================
  // SearchOrdersQuery
  // ============================================================
  searchOrders: IQueryHandler<SearchOrdersQuery> = async (query, ctx) => {
    const orderRepo = await this.container.resolve<any>(TOKENS.OrderRepository);
    return orderRepo.findMany(
      {
        search: query.term,
        pagination: { page: query.page, pageSize: query.pageSize },
      },
      ctx,
    );
  };
}
