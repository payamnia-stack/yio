// ============================================================
// YIO V8 — Order Command Handlers
// ============================================================
// این Handlerها کد business را در OrderEngine فراخوانی می‌کنند.
// در آینده می‌توان آن را کاملاً به Handler منتقل کرد و OrderEngine
// را به‌عنوان dependency استفاده کرد.
// ============================================================

import {
  ICommandHandler,
  ICommandResult,
  Context,
  ok,
  fail,
  IContainer,
  TOKENS,
} from '@yio/core';
import {
  CreateOrderCommand,
  ConfirmOrderCommand,
  ShipOrderCommand,
  CancelOrderCommand,
  DeliverOrderCommand,
  PayOrderCommand,
} from '../commands/order-commands';

export class OrderCommandHandlers {
  constructor(private container: IContainer) {}

  // ============================================================
  // CreateOrderCommand
  // ============================================================
  createOrder: ICommandHandler<CreateOrderCommand> = async (
    cmd,
    ctx,
  ): Promise<ICommandResult> => {
    const orderEngine = await this.container.resolve<any>(TOKENS.OrderEngine);
    try {
      const result = await orderEngine.createOrder(cmd.input, ctx);
      return ok(result, 'سفارش با موفقیت ایجاد شد');
    } catch (err: any) {
      return fail(err.message);
    }
  };

  // ============================================================
  // ConfirmOrderCommand
  // ============================================================
  confirmOrder: ICommandHandler<ConfirmOrderCommand> = async (
    cmd,
    ctx,
  ): Promise<ICommandResult> => {
    const orderEngine = await this.container.resolve<any>(TOKENS.OrderEngine);
    try {
      const result = await orderEngine.confirmOrder(cmd.orderId, ctx);
      return ok(result.data, result.message);
    } catch (err: any) {
      return fail(err.message);
    }
  };

  // ============================================================
  // ShipOrderCommand
  // ============================================================
  shipOrder: ICommandHandler<ShipOrderCommand> = async (
    cmd,
    ctx,
  ): Promise<ICommandResult> => {
    const orderEngine = await this.container.resolve<any>(TOKENS.OrderEngine);
    try {
      const result = await orderEngine.shipOrder(cmd.orderId, cmd.trackingCode, ctx);
      return ok(result.data, result.message);
    } catch (err: any) {
      return fail(err.message);
    }
  };

  // ============================================================
  // CancelOrderCommand
  // ============================================================
  cancelOrder: ICommandHandler<CancelOrderCommand> = async (
    cmd,
    ctx,
  ): Promise<ICommandResult> => {
    const orderEngine = await this.container.resolve<any>(TOKENS.OrderEngine);
    try {
      const result = await orderEngine.cancelOrder(cmd.orderId, cmd.reason, ctx);
      return ok(result.data, result.message);
    } catch (err: any) {
      return fail(err.message);
    }
  };

  // ============================================================
  // DeliverOrderCommand
  // ============================================================
  deliverOrder: ICommandHandler<DeliverOrderCommand> = async (
    cmd,
    ctx,
  ): Promise<ICommandResult> => {
    const orderEngine = await this.container.resolve<any>(TOKENS.OrderEngine);
    try {
      const result = await orderEngine.deliverOrder(cmd.orderId, ctx);
      return ok(result.data, result.message);
    } catch (err: any) {
      return fail(err.message);
    }
  };

  // ============================================================
  // PayOrderCommand
  // ============================================================
  payOrder: ICommandHandler<PayOrderCommand> = async (
    cmd,
    ctx,
  ): Promise<ICommandResult> => {
    const orderEngine = await this.container.resolve<any>(TOKENS.OrderEngine);
    try {
      const result = await orderEngine.payOrder(cmd.orderId, cmd.amount, cmd.paymentMethod, ctx);
      return ok(result.data, result.message);
    } catch (err: any) {
      return fail(err.message);
    }
  };
}
