// ============================================================
// YIO V8 — Order Queries
// ============================================================
import { BaseQuery } from '@yio/core';

export class GetOrderByIdQuery extends BaseQuery {
  readonly queryName = 'GetOrderByIdQuery';
  constructor(public readonly orderId: number) {
    super();
  }
}

export class ListOrdersQuery extends BaseQuery {
  readonly queryName = 'ListOrdersQuery';
  constructor(
    public readonly status?: string,
    public readonly page: number = 1,
    public readonly pageSize: number = 20,
  ) {
    super();
  }
}

export class GetUserOrdersQuery extends BaseQuery {
  readonly queryName = 'GetUserOrdersQuery';
  constructor(
    public readonly userId: number,
    public readonly page: number = 1,
    public readonly pageSize: number = 20,
  ) {
    super();
  }
}

export class GetOrderStatsQuery extends BaseQuery {
  readonly queryName = 'GetOrderStatsQuery';
  constructor(
    public readonly from?: Date,
    public readonly to?: Date,
  ) {
    super();
  }
}

export class SearchOrdersQuery extends BaseQuery {
  readonly queryName = 'SearchOrdersQuery';
  constructor(
    public readonly term: string,
    public readonly page: number = 1,
    public readonly pageSize: number = 20,
  ) {
    super();
  }
}
