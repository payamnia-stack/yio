// ============================================================
// YIO V8 — Query Bus Implementation
// ============================================================
// Query Bus از Command Bus جدا است. این جداسازی امکان استفاده از
// Cache و Read Replica را برای Queryها فراهم می‌کند.
// ============================================================

import {
  IQueryBus,
  IQuery,
  IQueryHandler,
  Context,
  ICache,
} from '@yio/core';

export class QueryBus implements IQueryBus {
  private handlers: Map<string, IQueryHandler<any>> = new Map();
  private cache: ICache | null = null;
  private defaultTtl: number = 60; // seconds

  /** اتصال Cache برای Queryهای قابل cache شدن */
  attachCache(cache: ICache, defaultTtl: number = 60): void {
    this.cache = cache;
    this.defaultTtl = defaultTtl;
  }

  register<Q extends IQuery>(queryName: string, handler: IQueryHandler<Q>): void {
    if (this.handlers.has(queryName)) {
      throw new Error(`Query "${queryName}" already has a handler registered.`);
    }
    this.handlers.set(queryName, handler);
    console.log(`[QueryBus] 📥 Registered handler for ${queryName}`);
  }

  async execute<Q extends IQuery>(query: Q, ctx: Context): Promise<any> {
    const handler = this.handlers.get(query.queryName);
    if (!handler) {
      throw new Error(`No handler registered for query "${query.queryName}".`);
    }

    const start = Date.now();
    const result = await handler(query, ctx);
    const duration = Date.now() - start;
    if (duration > 1000) {
      console.warn(`[QueryBus] ⚠️ Slow query: ${query.queryName} took ${duration}ms`);
    }
    return result;
  }

  /**
   * اجرای Query با کش کردن نتیجه.
   * کلید cache از queryName + ctx.tenantId + hash پارامترها ساخته می‌شود.
   */
  async executeCached<Q extends IQuery>(query: Q, ctx: Context, ttl?: number): Promise<any> {
    if (!this.cache) {
      return this.execute(query, ctx);
    }
    const key = this.buildCacheKey(query, ctx);
    return this.cache.getOrSet(key, ttl || this.defaultTtl, () => this.execute(query, ctx));
  }

  /** invalidate cache برای یک نوع Query */
  async invalidate(queryName: string, ctx: Context): Promise<void> {
    if (!this.cache) return;
    const pattern = `query:${queryName}:${ctx.tenantId}:*`;
    await this.cache.invalidate(pattern);
  }

  private buildCacheKey(query: IQuery, ctx: Context): string {
    const payloadHash = this.hash(JSON.stringify(query));
    return `query:${query.queryName}:${ctx.tenantId}:${payloadHash}`;
  }

  private hash(str: string): string {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash |= 0;
    }
    return hash.toString(36);
  }

  list(): string[] {
    return Array.from(this.handlers.keys());
  }
}
