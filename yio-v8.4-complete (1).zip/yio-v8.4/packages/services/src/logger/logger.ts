// ============================================================
// YIO V8.1 — Logger Implementations
// ============================================================
// در V8، Console به‌عنوان default logger استفاده می‌شد که در production
// مناسب نیست. در V8.1 سه پیاده‌سازی ارائه شده:
//
//   1) ConsoleLogger — برای dev و test
//   2) PinoLogger    — برای production (ساختار یافته JSON)
//   3) NoopLogger    — برای test (silent)
//
// هر سه اینترفیس ILogger را پیاده‌سازی می‌کنند تا قابل تعویض باشند.
// انتخاب از طریق DI Container انجام می‌شود.
// ============================================================

import { ILogger } from '@yio/core';

// ============================================================
// Console Logger — Dev / Test
// ============================================================
// این پیاده‌سازی console را wrap می‌کند تا:
//   - timestamp اضافه شود
//   - meta به‌صورت JSON نمایش داده شود
//   - level با رنگ متمایز شود (در dev)
//
// توجه: مستقیم از `console` استفاده نکنید — همیشه از ILogger استفاده کنید.
export class ConsoleLogger implements ILogger {
  private level: 'debug' | 'info' | 'warn' | 'error';

  constructor(level: 'debug' | 'info' | 'warn' | 'error' = 'info') {
    this.level = level;
  }

  info(message: string, meta?: any): void {
    if (this.shouldLog('info')) {
      console.log(`[INFO ${this.timestamp()}] ${message}`, this.formatMeta(meta));
    }
  }

  warn(message: string, meta?: any): void {
    if (this.shouldLog('warn')) {
      console.warn(`[WARN ${this.timestamp()}] ${message}`, this.formatMeta(meta));
    }
  }

  error(message: string, meta?: any): void {
    if (this.shouldLog('error')) {
      console.error(`[ERROR ${this.timestamp()}] ${message}`, this.formatMeta(meta));
    }
  }

  debug(message: string, meta?: any): void {
    if (this.shouldLog('debug')) {
      console.debug(`[DEBUG ${this.timestamp()}] ${message}`, this.formatMeta(meta));
    }
  }

  private shouldLog(level: 'debug' | 'info' | 'warn' | 'error'): boolean {
    const order = ['debug', 'info', 'warn', 'error'];
    return order.indexOf(level) >= order.indexOf(this.level);
  }

  private timestamp(): string {
    return new Date().toISOString();
  }

  private formatMeta(meta?: any): string {
    if (!meta) return '';
    if (Object.keys(meta).length === 0) return '';
    return ' ' + JSON.stringify(meta);
  }
}

// ============================================================
// Noop Logger — Test (Silent)
// ============================================================
// برای test environment که نمی‌خواهیم خروجی لاگ داشته باشیم.
export class NoopLogger implements ILogger {
  info(): void {}
  warn(): void {}
  error(): void {}
  debug(): void {}
}

// ============================================================
// Pino Logger — Production
// ============================================================
// این پیاده‌سازی از pino استفاده می‌کند که سریع‌ترین logger برای Node.js است.
// خروجی به‌صورت JSON ساختار یافته است که توسط ELK / Datadog / Loki قابل
// ingest کردن است.
//
// برای استفاده:
//   const logger = new PinoLogger({ level: 'info', service: 'yio-api' });
//   container.bindInstance(TOKENS.Logger, logger);
export class PinoLogger implements ILogger {
  private pino: any;
  private level: string;

  constructor(opts: { level?: string; service?: string; pretty?: boolean } = {}) {
    this.level = opts.level || process.env.LOG_LEVEL || 'info';
    try {
      // Lazy-load pino برای جلوگیری از وابستگی اجباری در dev
      const pino = require('pino');
      this.pino = pino({
        level: this.level,
        base: { service: opts.service || 'yio-api' },
        ...(opts.pretty
          ? {
              transport: {
                target: 'pino-pretty',
                options: { colorize: true, translateTime: 'SYS:standard' },
              },
            }
          : {}),
      });
    } catch {
      // اگر pino نصب نبود، fallback به ConsoleLogger
      console.warn('[PinoLogger] pino not installed, falling back to ConsoleLogger');
      this.pino = null;
    }
  }

  info(message: string, meta?: any): void {
    if (this.pino) {
      this.pino.info(meta || {}, message);
    } else {
      console.log(`[INFO] ${message}`, meta || '');
    }
  }

  warn(message: string, meta?: any): void {
    if (this.pino) {
      this.pino.warn(meta || {}, message);
    } else {
      console.warn(`[WARN] ${message}`, meta || '');
    }
  }

  error(message: string, meta?: any): void {
    if (this.pino) {
      this.pino.error(meta || {}, message);
    } else {
      console.error(`[ERROR] ${message}`, meta || '');
    }
  }

  debug(message: string, meta?: any): void {
    if (this.pino) {
      this.pino.debug(meta || {}, message);
    } else {
      console.debug(`[DEBUG] ${message}`, meta || '');
    }
  }
}

// ============================================================
// Logger Factory — انتخاب خودکار بر اساس محیط
// ============================================================
export function createLogger(): ILogger {
  const env = process.env.NODE_ENV || 'development';

  if (env === 'test') {
    return new NoopLogger();
  }

  if (env === 'production') {
    // در production، از PinoLogger استفاده کن
    // اگر pino نصب نبود، PinoLogger خودش fallback می‌کند
    return new PinoLogger({
      level: process.env.LOG_LEVEL || 'info',
      service: process.env.SERVICE_NAME || 'yio-api',
      pretty: false,
    });
  }

  // dev
  return new ConsoleLogger('debug');
}
