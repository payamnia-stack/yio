// ============================================================
// YIO V8 — Cache Layer (Improvement #10)
// ============================================================
// دو پیاده‌سازی:
//   1) InMemoryCache — برای dev و test
//   2) RedisCache   — برای production
// هر دو اینترفیس ICache را پیاده‌سازی می‌کنند تا قابل تعویض باشند.
// ============================================================

import { ICache } from '@yio/core';

// ============================================================
// In-Memory Cache (LRU-style)
// ============================================================
interface CacheEntry<T> {
  value: T;
  expiresAt: number | null; // epoch millis, null = no expiry
  lastAccessed: number; // monotonic counter (not timestamp — for accurate LRU)
}

export class InMemoryCache implements ICache {
  private store: Map<string, CacheEntry<any>> = new Map();
  private maxSize: number;
  private accessCounter: number = 0;

  constructor(maxSize: number = 1000) {
    this.maxSize = maxSize;
  }

  async get<T>(key: string): Promise<T | null> {
    const entry = this.store.get(key);
    if (!entry) return null;

    if (entry.expiresAt !== null && Date.now() > entry.expiresAt) {
      this.store.delete(key);
      return null;
    }

    entry.lastAccessed = ++this.accessCounter;
    return entry.value as T;
  }

  async set<T>(key: string, value: T, ttl?: number): Promise<void> {
    // اگر تعداد از maxSize بیشتر شد، LRU را حذف کن
    if (this.store.size >= this.maxSize && !this.store.has(key)) {
      this.evictLRU();
    }

    this.store.set(key, {
      value,
      expiresAt: ttl ? Date.now() + ttl * 1000 : null,
      lastAccessed: ++this.accessCounter,
    });
  }

  async delete(key: string): Promise<void> {
    this.store.delete(key);
  }

  async invalidate(pattern: string): Promise<void> {
    // پشتیبانی از wildcard *
    const regex = this.patternToRegex(pattern);
    for (const key of Array.from(this.store.keys())) {
      if (regex.test(key)) {
        this.store.delete(key);
      }
    }
  }

  async getOrSet<T>(key: string, ttl: number, factory: () => Promise<T>): Promise<T> {
    const existing = await this.get<T>(key);
    if (existing !== null) return existing;

    const value = await factory();
    await this.set(key, value, ttl);
    return value;
  }

  async flush(): Promise<void> {
    this.store.clear();
  }

  private evictLRU(): void {
    let oldestKey: string | null = null;
    let oldestTime = Infinity;
    for (const [key, entry] of this.store.entries()) {
      if (entry.lastAccessed < oldestTime) {
        oldestTime = entry.lastAccessed;
        oldestKey = key;
      }
    }
    if (oldestKey) this.store.delete(oldestKey);
  }

  private patternToRegex(pattern: string): RegExp {
    const escaped = pattern
      .replace(/[.+^${}()|[\]\\]/g, '\\$&')
      .replace(/\*/g, '.*');
    return new RegExp(`^${escaped}$`);
  }
}

// ============================================================
// Redis Cache (Production)
// ============================================================
// در production، در صورت تنظیم REDIS_URL، از Redis استفاده می‌شود.
// این کلاس از ioredis استفاده می‌کند (lazy import برای جلوگیری از
// وابستگی اجباری در dev).
export class RedisCache implements ICache {
  private client: any = null;
  private connected: boolean = false;
  private url: string;

  constructor(url: string = process.env.REDIS_URL || 'redis://localhost:6379') {
    this.url = url;
  }

  private async getClient(): Promise<any> {
    if (this.client && this.connected) return this.client;
    // Lazy-load ioredis
    try {
      const IORedis = (await import('ioredis')).default;
      this.client = new IORedis(this.url, {
        maxRetriesPerRequest: 3,
        enableOfflineQueue: true,
      });
      this.client.on('connect', () => {
        this.connected = true;
        console.log('[RedisCache] ✅ Connected');
      });
      this.client.on('error', (err: any) => {
        console.error('[RedisCache] ❌ Error:', err.message);
      });
      return this.client;
    } catch (err) {
      console.warn('[RedisCache] ioredis not installed, falling back to in-memory');
      throw err;
    }
  }

  async get<T>(key: string): Promise<T | null> {
    try {
      const client = await this.getClient();
      const value = await client.get(key);
      if (!value) return null;
      return JSON.parse(value) as T;
    } catch {
      return null;
    }
  }

  async set<T>(key: string, value: T, ttl?: number): Promise<void> {
    try {
      const client = await this.getClient();
      const serialized = JSON.stringify(value);
      if (ttl) {
        await client.set(key, serialized, 'EX', ttl);
      } else {
        await client.set(key, serialized);
      }
    } catch (err) {
      console.warn(`[RedisCache] set failed for ${key}:`, err);
    }
  }

  async delete(key: string): Promise<void> {
    try {
      const client = await this.getClient();
      await client.del(key);
    } catch (err) {
      console.warn(`[RedisCache] delete failed for ${key}:`, err);
    }
  }

  async invalidate(pattern: string): Promise<void> {
    try {
      const client = await this.getClient();
      // SCAN برای الگو (به‌جای KEYS که blocking است)
      const regex = new RegExp(pattern.replace(/\*/g, '.*'));
      let cursor = '0';
      do {
        const [nextCursor, keys] = await client.scan(
          cursor, 'MATCH', pattern, 'COUNT', 100,
        );
        cursor = nextCursor;
        if (keys.length > 0) {
          await client.del(...keys);
        }
      } while (cursor !== '0');
      // regex فعلاً فقط برای log استفاده می‌شود (در آینده برای pattern strict)
      void regex;
    } catch (err) {
      console.warn(`[RedisCache] invalidate failed for ${pattern}:`, err);
    }
  }

  async getOrSet<T>(key: string, ttl: number, factory: () => Promise<T>): Promise<T> {
    const existing = await this.get<T>(key);
    if (existing !== null) return existing;
    const value = await factory();
    await this.set(key, value, ttl);
    return value;
  }

  async flush(): Promise<void> {
    try {
      const client = await this.getClient();
      await client.flushdb();
    } catch (err) {
      console.warn('[RedisCache] flush failed:', err);
    }
  }
}

// ============================================================
// Cache Factory
// ============================================================
export function createCache(): ICache {
  if (process.env.REDIS_URL && process.env.REDIS_URL !== '') {
    return new RedisCache();
  }
  return new InMemoryCache();
}

// ============================================================
// Cache Decorator (Helper برای متدهای Query)
// ============================================================
// این decorator نتیجه متد را در cache ذخیره می‌کند.
// استفاده:
//   @cached('products:list', 60)
//   async listProducts(...) { ... }
//
// توجه: این decorator نیاز به یک global cache instance دارد.
// در bootstrap تنظیم می‌شود: setGlobalCache(cache)
let _globalCache: ICache | null = null;

export function setGlobalCache(cache: ICache): void {
  _globalCache = cache;
}

export function getGlobalCache(): ICache | null {
  return _globalCache;
}

export function cached(keyBuilder: (...args: any[]) => string, ttl: number) {
  return function (target: any, propertyKey: string, descriptor: PropertyDescriptor) {
    const originalMethod = descriptor.value;

    descriptor.value = async function (...args: any[]): Promise<any> {
      if (!_globalCache) {
        return originalMethod.apply(this, args);
      }
      const key = keyBuilder(...args);
      return _globalCache.getOrSet(key, ttl, () => originalMethod.apply(this, args));
    };

    return descriptor;
  };
}
