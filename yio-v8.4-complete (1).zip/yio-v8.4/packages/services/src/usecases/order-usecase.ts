// ============================================================
// YIO V8.1 — Order UseCase (with @Transactional + @Auditable)
// ============================================================
// این UseCase نشان می‌دهد که چگونه با Decoratorها می‌توان کد تمیزتر
// و safer نوشت. به‌جای اینکه هر متد txManager.run و tx.collectAudit
// را دستی صدا بزند، این کارها توسط Decorator انجام می‌شود.
//
// مزایا:
//   ✅ فراموش کردن txManager.run() غیرممکن می‌شود
//   ✅ Audit خودکار برای همه متدهای @Auditable
//   ✅ متد فقط business logic دارد (نه infrastructure concern)
//   ✅ Nested calls در همان tx اجرا می‌شوند (joinExisting)
// ============================================================

import {
  Context,
  BusinessError,
  IOrderRepository,
  IProductRepository,
  IInventoryRepository,
  IEventBus,
  ITransactionManager,
  IRuleEngine,
  IAuditLogger,
  ILogger,
  noopLogger,
  ITransactionContext,
  Events,
  OrderCreatedEvent,
  OrderConfirmedEvent,
  OrderCancelledEvent,
  OrderPaidEvent,
  DomainEvent,
} from '@yio/core';
import { BaseUseCase, Transactional, Auditable } from '../decorators';

// ============================================================
// Input Types
// ============================================================
export interface CreateOrderInput {
  customerId?: number;
  userId?: number;
  items: Array<{ productId: number; quantity: number; color?: string }>;
  shippingAddress: string;
  shippingCity?: string;
  shippingProvince?: string;
  postalCode?: string;
  recipientName: string;
  recipientPhone: string;
  paymentMethod: string;
  notes?: string;
}

export interface CreateOrderResult {
  orderId: number;
  orderNumber: string;
  totalAmount: number;
  finalAmount: number;
}

// ============================================================
// Order UseCase
// ============================================================
export class OrderUseCase extends BaseUseCase {
  constructor(
    private orderRepo: IOrderRepository,
    private productRepo: IProductRepository,
    private inventoryRepo: IInventoryRepository,
    private eventBus: IEventBus,
    private ruleEngine: IRuleEngine,
    private auditLogger: IAuditLogger,
    txManager: ITransactionManager,
    private logger: ILogger = noopLogger,
  ) {
    super(txManager); // برای @Transactional
  }

  // ============================================================
  // Create Order
  // ============================================================
  // توجه به ترتیب decoratorها:
  //   1. @Transactional (outermost) — باز می‌کند tx را
  //   2. @Auditable (inner) — audit log را اضافه می‌کند
  // ترتیب مهم است چون Audit باید داخل Transaction ثبت شود.
  @Transactional()
  @Auditable({
    entityType: 'Order',
    action: 'order.create',
    operation: 'create',
    getEntityId: (result: CreateOrderResult) => result.orderId,
    getMetadata: (input: CreateOrderInput, result: CreateOrderResult) => ({
      orderNumber: result.orderNumber,
      totalAmount: result.totalAmount,
      itemCount: input.items.length,
    }),
  })
  async createOrder(
    input: CreateOrderInput,
    ctx: Context,
    tx?: ITransactionContext,
  ): Promise<CreateOrderResult> {
    // ۱) اعتبارسنجی اولیه
    if (!input.items || input.items.length === 0) {
      throw new BusinessError('اقلام سفارش خالی است', 'VALIDATION_ERROR', 'items');
    }

    // ۲) محاسبه مبلغ
    let totalAmount = 0;
    const orderItems: any[] = [];

    for (const item of input.items) {
      const product = await this.productRepo.findById(item.productId, ctx, tx);
      if (!product || !product.inStock) {
        throw new BusinessError('محصول مورد نظر موجود نیست', 'BUSINESS_ERROR', 'items');
      }
      if (product.stockQuantity > 0 && item.quantity > product.stockQuantity) {
        throw new BusinessError(
          `موجودی محصول «${product.title}» کافی نیست. حداکثر ${product.stockQuantity} عدد.`,
          'BUSINESS_ERROR',
          'items',
        );
      }
      const price = product.discountPrice || product.price;
      const qty = Math.max(1, Math.min(99, item.quantity));
      totalAmount += price * qty;
      orderItems.push({
        productId: product.id,
        productTitle: product.title,
        productImage: product.image,
        price,
        quantity: qty,
        color: item.color,
      });
    }

    // ۳) محاسبه هزینه ارسال
    const shippingCost = totalAmount > 500000 ? 0 : 89000;
    const finalAmount = totalAmount + shippingCost;

    // ۴) ارزیابی Ruleها
    const ruleResult = await this.ruleEngine.validate(
      'order.create',
      { ...input, totalAmount, finalAmount, items: orderItems },
      ctx,
    );
    if (!ruleResult.success) {
      throw new BusinessError(ruleResult.message || 'قوانین سفارش نقض شد', 'BUSINESS_ERROR');
    }

    // ۵) تولید شماره سفارش
    const orderNumber = await this.orderRepo.generateOrderNumber(ctx);

    // ۶) ایجاد سفارش + اقلام
    const created = await this.orderRepo.createWithItems(
      {
        orderNumber,
        customerId: input.customerId,
        userId: input.userId,
        status: 'pending',
        totalAmount,
        shippingCost,
        finalAmount,
        paymentMethod: input.paymentMethod,
        paymentStatus: 'unpaid',
        shippingAddress: input.shippingAddress,
        shippingCity: input.shippingCity,
        recipientName: input.recipientName,
        recipientPhone: input.recipientPhone,
        notes: input.notes,
      },
      orderItems,
      ctx,
      tx,
    );

    // ۷) رزرو موجودی
    await this.productRepo.reserveStock(
      orderItems.map((i) => ({ productId: i.productId, quantity: i.quantity })),
      ctx,
      tx,
    );

    // ۸) ثبت Inventory Transaction
    await this.inventoryRepo.recordTransaction(
      {
        itemType: 'product',
        type: 'reservation',
        reason: `رزرو برای سفارش ${orderNumber}`,
        orderId: created.id,
        items: orderItems.map((i) => ({ productId: i.productId, quantity: i.quantity })),
      },
      ctx,
    );

    // ۹) V8.1: جمع‌آوری Eventها به‌صورت batch (یک فراخوانی collectEvents)
    const events: DomainEvent[] = [
      new OrderCreatedEvent(
        created.id,
        input.customerId || input.userId,
        finalAmount,
        ctx.tenantId,
      ),
    ];
    tx?.collectEvents(events);

    this.logger.info(`[OrderUseCase] Order ${orderNumber} created (id=${created.id})`);

    return {
      orderId: created.id,
      orderNumber: created.orderNumber,
      totalAmount,
      finalAmount,
    };
  }

  // ============================================================
  // Confirm Order
  // ============================================================
  @Transactional()
  @Auditable({
    entityType: 'Order',
    action: 'order.confirm',
    operation: 'update',
    getEntityId: (result: any) => result.orderId || 0,
  })
  async confirmOrder(
    orderId: number,
    ctx: Context,
    tx?: ITransactionContext,
  ): Promise<{ success: boolean; orderId: number }> {
    const order = await this.orderRepo.findById(orderId, ctx, tx);
    if (!order) throw new BusinessError('سفارش یافت نشد', 'NOT_FOUND');
    if (order.status !== 'pending') {
      throw new BusinessError('سفارش در وضعیت مناسبی برای تأیید نیست', 'BUSINESS_ERROR');
    }

    await this.orderRepo.updateStatus(orderId, 'confirmed', ctx, tx);
    tx?.collectEvent(new OrderConfirmedEvent(orderId, ctx.tenantId));

    return { success: true, orderId };
  }

  // ============================================================
  // Cancel Order
  // ============================================================
  @Transactional()
  @Auditable({
    entityType: 'Order',
    action: 'order.cancel',
    operation: 'update',
  })
  async cancelOrder(
    orderId: number,
    reason: string,
    ctx: Context,
    tx?: ITransactionContext,
  ): Promise<{ success: boolean }> {
    const order = await this.orderRepo.findById(orderId, ctx, tx);
    if (!order) throw new BusinessError('سفارش یافت نشد', 'NOT_FOUND');
    if (order.status === 'delivered' || order.status === 'cancelled') {
      throw new BusinessError('امکان لغو این سفارش وجود ندارد', 'BUSINESS_ERROR');
    }

    await this.orderRepo.updateStatus(orderId, 'cancelled', ctx, tx);
    tx?.collectEvent(new OrderCancelledEvent(orderId, reason, ctx.tenantId));

    return { success: true };
  }

  // ============================================================
  // Pay Order
  // ============================================================
  @Transactional()
  @Auditable({
    entityType: 'Order',
    action: 'order.pay',
    operation: 'update',
  })
  async payOrder(
    orderId: number,
    amount: number,
    paymentMethod: string,
    ctx: Context,
    tx?: ITransactionContext,
  ): Promise<{ success: boolean }> {
    const order = await this.orderRepo.findById(orderId, ctx, tx);
    if (!order) throw new BusinessError('سفارش یافت نشد', 'NOT_FOUND');
    if (order.paymentStatus === 'paid') {
      throw new BusinessError('سفارش قبلاً پرداخت شده', 'BUSINESS_ERROR');
    }

    await this.orderRepo.update(orderId, { paymentStatus: 'paid' }, ctx, tx);

    // V8.1: collect multiple events in batch
    const events: DomainEvent[] = [
      new OrderPaidEvent(orderId, amount, paymentMethod, ctx.tenantId),
    ];
    tx?.collectEvents(events);

    return { success: true };
  }
}
