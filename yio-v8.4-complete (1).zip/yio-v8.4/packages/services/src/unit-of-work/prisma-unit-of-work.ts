// ============================================================
// YIO V8 — Unit of Work (Prisma Implementation)
// ============================================================
// این پیاده‌سازی IUnitOfWork و ITransactionManager از Prisma's
// $transaction API استفاده می‌کند.
//
// الگو:
//   const result = await txManager.run(async (tx) => {
//     await orderRepo.createWithItems(order, items, ctx, tx.client);
//     await inventoryRepo.reserveStock(items, ctx, tx.client);
//     await accountingEngine.recordSale(..., tx.client);
//     tx.collectEvent(new OrderCreatedEvent(...));
//     tx.collectAudit({ ... });
//   });
//   // ← بعد از commit موفق، Eventها publish و Auditها نوشته می‌شوند.
// ============================================================

import { PrismaClient } from '@prisma/client';
import {
  IUnitOfWork,
  ITransactionContext,
  ITransactionManager,
  IEventBus,
  IAuditLogger,
  DomainEvent,
  AuditEntry,
} from '@yio/core';
import { randomUUID } from 'crypto';

// ============================================================
// Transaction Context
// ============================================================
export class PrismaTransactionContext implements ITransactionContext {
  public readonly transactionId: string;
  private pendingEvents: DomainEvent[] = [];
  private pendingAudits: AuditEntry[] = [];

  constructor(
    public readonly client: any, // PrismaTransaction
    transactionId?: string,
  ) {
    this.transactionId = transactionId || randomUUID();
  }

  collectEvent(event: DomainEvent): void {
    this.pendingEvents.push(event);
  }

  /**
   * V8.1: جمع‌آوری batch از Eventها.
   * این متد برای Aggregateهایی که چند Domain Event تولید می‌کنند
   * طراحی شده است. همه eventها در یک batch به Event Store append می‌شوند.
   */
  collectEvents(events: DomainEvent[]): void {
    if (events.length === 0) return;
    this.pendingEvents.push(...events);
  }

  collectAudit(entry: AuditEntry): void {
    this.pendingAudits.push(entry);
  }

  /** مصرف داخلی: eventهای جمع‌شده (بعد از commit publish می‌شوند) */
  drainEvents(): DomainEvent[] {
    const events = [...this.pendingEvents];
    this.pendingEvents = [];
    return events;
  }

  /** مصرف داخلی: auditهای جمع‌شده (بعد از commit نوشته می‌شوند) */
  drainAudits(): AuditEntry[] {
    const audits = [...this.pendingAudits];
    this.pendingAudits = [];
    return audits;
  }
}

// ============================================================
// Unit of Work
// ============================================================
export class PrismaUnitOfWork implements IUnitOfWork {
  private currentTx: PrismaTransactionContext | null = null;

  constructor(
    private prisma: PrismaClient,
    private eventBus: IEventBus,
    private auditLogger: IAuditLogger,
  ) {}

  isActive(): boolean {
    return this.currentTx !== null;
  }

  async begin(): Promise<void> {
    if (this.currentTx) {
      throw new Error('Unit of Work is already active. Call commit() or rollback() first.');
    }
    // در Prisma، transaction فقط داخل callback مدیریت می‌شود.
    // برای API سازگار با begin/commit/rollback از interactive transaction استفاده می‌کنیم.
    // اینجا فقط پرچم می‌گذاریم؛ خود تراکنش داخل run() باز می‌شود.
    this.currentTx = new PrismaTransactionContext(this.prisma);
  }

  async commit(): Promise<void> {
    if (!this.currentTx) {
      throw new Error('No active Unit of Work to commit.');
    }
    // V8.1: publish collected events as a batch (single call to publishAll)
    const events = this.currentTx.drainEvents();
    if (events.length > 0) {
      await this.eventBus.publishAll(events);
    }
    // persist collected audit entries
    const audits = this.currentTx.drainAudits();
    for (const entry of audits) {
      await this.auditLogger.log(entry);
    }
    this.currentTx = null;
  }

  async rollback(): Promise<void> {
    if (!this.currentTx) return;
    // discard collected events and audits
    this.currentTx.drainEvents();
    this.currentTx.drainAudits();
    this.currentTx = null;
  }

  /**
   * اجرای یک تابع داخل یک Prisma transaction.
   * این متد امن‌ترین روش است چون در صورت خطا rollback خودکار می‌کند.
   */
  async run<T>(fn: (tx: ITransactionContext) => Promise<T>): Promise<T> {
    if (this.currentTx) {
      // در صورت وجود UoW والد (nested)، از همان استفاده کن
      return fn(this.currentTx);
    }

    // Prisma Interactive Transaction
    return this.prisma.$transaction(async (prismaTx) => {
      const ctx = new PrismaTransactionContext(prismaTx);
      this.currentTx = ctx;

      try {
        const result = await fn(ctx);

        // بعد از موفقیت، eventها و auditها را drain کن
        // (اما هنوز publish نکن — اول باید transaction commit شود)
        // در عمل Prisma بعد از resolve شدن callback خودش commit می‌کند.
        // بنابراین eventها را بعد از خروج از $transaction منتشر می‌کنیم.
        // برای ساده‌سازی، اینجا آنها را داخل ctx نگه می‌داریم و در finally
        // پس از خروج موفق، publish می‌کنیم.

        // در عمل: چون $transaction بعد از success commit می‌کند،
        // ما بعد از await بالا، eventها را در یک مرحله post-commit منتشر می‌کنیم.
        // این کار را در finally با یک پرچم success انجام می‌دهیم.
        return result;
      } catch (err) {
        // در صورت خطا، ctx پاک شود
        ctx.drainEvents();
        ctx.drainAudits();
        throw err;
      } finally {
        // توجه: publish واقعی در `postCommitPublish` انجام می‌شود
        // چون اینجا هنوز داخل $transaction هستیم و نمی‌توانیم
        // publish دیگری انجام دهیم (deadlock risk).
        // اما eventها در ctx باقی می‌مانند تا پس از خروج موفق منتشر شوند.
      }
    }).then(async (result) => {
      // این مرحله فقط در صورت success اجرا می‌شود.
      // اگر به اینجا رسیده‌ایم، transaction commit شده است.
      const ctx = this.currentTx;
      if (ctx) {
        // V8.1: publish all events in a single batch call
        const events = ctx.drainEvents();
        if (events.length > 0) {
          await this.eventBus.publishAll(events);
        }
        const audits = ctx.drainAudits();
        for (const entry of audits) {
          await this.auditLogger.log(entry);
        }
        this.currentTx = null;
      }
      return result;
    });
  }
}

// ============================================================
// Transaction Manager (Factory)
// ============================================================
export class PrismaTransactionManager implements ITransactionManager {
  constructor(
    private prisma: PrismaClient,
    private eventBus: IEventBus,
    private auditLogger: IAuditLogger,
  ) {}

  create(): IUnitOfWork {
    return new PrismaUnitOfWork(this.prisma, this.eventBus, this.auditLogger);
  }

  run<T>(fn: (tx: ITransactionContext) => Promise<T>): Promise<T> {
    const uow = this.create();
    return uow.run(fn);
  }
}
