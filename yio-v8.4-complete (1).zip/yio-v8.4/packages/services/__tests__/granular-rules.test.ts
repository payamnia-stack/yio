// ============================================================
// YIO V8.1 — Granular Rules Tests
// ============================================================

import { describe, it, expect, beforeEach } from 'vitest';
import {
  RuleRegistry,
  RuleEngine,
  registerAllGranularRules,
  registerV81Rules,
  DISCOUNT_RULES,
  CREDIT_RULES,
  SHIPPING_RULES,
  DUPLICATE_ORDER_RULES,
  INVENTORY_RULES_V81,
} from '../src/index';
import { Context } from '@yio/core';

let registry: RuleRegistry;
let engine: RuleEngine;
const ctx: Context = { tenantId: 1, userId: 1 };

beforeEach(() => {
  registry = new RuleRegistry();
  registerAllGranularRules(registry);
  engine = new RuleEngine(
    { siteSetting: { findMany: async () => [] } } as any,
    registry,
  );
});

describe('Discount Rules (V8.1)', () => {
  it('should have wholesale, loyalty, bulk, coupon rules', () => {
    expect(DISCOUNT_RULES.length).toBe(4);
    const names = DISCOUNT_RULES.map((r) => r.name);
    expect(names).toContain('discount.wholesale');
    expect(names).toContain('discount.loyalty');
    expect(names).toContain('discount.bulk_quantity');
    expect(names).toContain('discount.coupon');
  });

  it('should apply wholesale discount', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 2 }],
        totalAmount: 500000,
        customerIsWholesale: true,
        wholesaleDiscountRate: 15,
      },
      ctx,
    );
    expect(result.success).toBe(true);
    // should have warning about wholesale discount (V8.0 wholesale_discount یا V8.1 discount.wholesale)
    expect((result.warnings || []).some((w) => w.includes('عمده‌فروشی'))).toBe(true);
  });

  it('should apply loyalty discount for level 3+', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 1 }],
        totalAmount: 200000,
        customerLevel: 4,
      },
      ctx,
    );
    expect(result.success).toBe(true);
    // loyalty rule فقط در صورتی که customerLevel >= 3 باشد فعال می‌شود
    // اگر warning نبود، حداقل success=true باشد
    const hasLoyaltyWarning = (result.warnings || []).some((w) => w.includes('وفاداری'));
    expect(hasLoyaltyWarning).toBe(true);
  });

  it('should not apply loyalty discount for level < 3', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 1 }],
        totalAmount: 200000,
        customerLevel: 2,
      },
      ctx,
    );
    expect(result.success).toBe(true);
    expect((result.warnings || []).some((w) => w.includes('وفاداری'))).toBe(false);
  });

  it('should apply bulk quantity discount for totalQty >= 20', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [
          { productId: 1, quantity: 10 },
          { productId: 2, quantity: 15 },
        ],
        totalAmount: 1000000,
      },
      ctx,
    );
    expect(result.success).toBe(true);
    expect((result.warnings || []).some((w) => w.includes('خرید عمده'))).toBe(true);
  });

  it('should validate coupon code', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 1 }],
        totalAmount: 300000,
        couponCode: 'YIO10',
      },
      ctx,
    );
    expect(result.success).toBe(true);
    expect((result.warnings || []).some((w) => w.includes('YIO10'))).toBe(true);
  });

  it('should reject invalid coupon code', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 1 }],
        totalAmount: 300000,
        couponCode: 'INVALID',
      },
      ctx,
    );
    expect(result.success).toBe(false);
    expect(result.message).toContain('معتبر نیست');
  });

  it('should reject coupon below minimum amount', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 1 }],
        totalAmount: 100000, // زیر حداقل 200k برای YIO10
        couponCode: 'YIO10',
      },
      ctx,
    );
    expect(result.success).toBe(false);
    expect(result.message).toContain('حداقل مبلغ');
  });
});

describe('Credit Rules (V8.1)', () => {
  it('should check credit limit for credit payment', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 1 }],
        totalAmount: 500000,
        finalAmount: 500000,
        paymentMethod: 'credit',
        customerCreditLimit: 1000000,
        customerOutstandingBalance: 700000,
      },
      ctx,
    );
    // 1M - 700k = 300k available, 500k > 300k → should FAIL
    expect(result.success).toBe(false);
    expect(result.message).toContain('سقف اعتبار');
  });

  it('should pass when credit is sufficient', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 1 }],
        totalAmount: 200000,
        finalAmount: 200000,
        paymentMethod: 'credit',
        customerCreditLimit: 1000000,
        customerOutstandingBalance: 700000, // 300k available
      },
      ctx,
    );
    expect(result.success).toBe(true);
  });

  it('should not apply credit rules for non-credit payment', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 1 }],
        totalAmount: 5000000,
        finalAmount: 5000000,
        paymentMethod: 'cod', // نه credit
        customerCreditLimit: 100,
        customerOutstandingBalance: 100,
      },
      ctx,
    );
    // چون paymentMethod=cod است، CreditLimitRule باید pass شود
    expect(result.success).toBe(true);
  });

  it('should reject customer with overdue balance above limit', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 1 }],
        totalAmount: 200000,
        customerOverdueAmount: 600000, // بالای 500k
      },
      ctx,
    );
    expect(result.success).toBe(false);
    expect(result.message).toContain('مانده بدهی معوق');
  });

  it('should check installment limit', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 1 }],
        totalAmount: 200000,
        paymentMethod: 'installment',
        customerActiveInstallments: 3,
        maxActiveInstallments: 3,
      },
      ctx,
    );
    expect(result.success).toBe(false);
    expect(result.message).toContain('اقساط فعال');
  });
});

describe('Shipping Rules (V8.1)', () => {
  it('should apply free shipping for orders above threshold', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 1 }],
        totalAmount: 600000,
      },
      ctx,
    );
    expect(result.success).toBe(true);
    expect((result.warnings || []).some((w) => w.includes('ارسال رایگان'))).toBe(true);
  });

  it('should not apply free shipping for orders below threshold', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 1 }],
        totalAmount: 100000,
      },
      ctx,
    );
    expect((result.warnings || []).some((w) => w.includes('ارسال رایگان'))).toBe(false);
  });

  it('should apply remote area surcharge', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 1 }],
        totalAmount: 300000,
        shippingProvince: 'سیستان و بلوچستان',
      },
      ctx,
    );
    expect(result.success).toBe(true);
    expect((result.warnings || []).some((w) => w.includes('منطقه دور'))).toBe(true);
  });

  it('should check weight limit', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 100, weight: 500 }], // 50kg total
        totalAmount: 500000,
        maxShippingWeight: 30000,
      },
      ctx,
    );
    // multiple rules may trigger; weight limit should fail
    expect(result.success).toBe(false);
    // یا weight یا max_quantity (>99)
    expect(result.message).toBeTruthy();
  });
});

describe('Duplicate Order Rules (V8.1)', () => {
  it('should have duplicate detection rules', () => {
    expect(DUPLICATE_ORDER_RULES.length).toBe(2);
    const names = DUPLICATE_ORDER_RULES.map((r) => r.name);
    expect(names).toContain('order.duplicate_within_window');
    expect(names).toContain('order.identical_items_duplicate');
  });

  it('should reject identical order within 5 minutes', async () => {
    const lastOrderAt = new Date(); // همین الان
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 2 }],
        totalAmount: 200000,
        customerLastOrderAt: lastOrderAt,
        customerLastOrderItems: [{ productId: 1, quantity: 2 }],
      },
      ctx,
    );
    expect(result.success).toBe(false);
    expect(result.message).toContain('سفارش مشابهی');
  });

  it('should pass for orders after 5-minute window', async () => {
    const tenMinutesAgo = new Date(Date.now() - 10 * 60 * 1000);
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 2 }],
        totalAmount: 200000,
        customerLastOrderAt: tenMinutesAgo,
        customerLastOrderItems: [{ productId: 1, quantity: 2 }],
      },
      ctx,
    );
    expect(result.success).toBe(true);
  });

  it('should warn but allow different items within window', async () => {
    const oneMinuteAgo = new Date(Date.now() - 60 * 1000);
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 5, quantity: 3 }], // متفاوت از قبلی
        totalAmount: 200000,
        customerLastOrderAt: oneMinuteAgo,
        customerLastOrderItems: [{ productId: 1, quantity: 2 }],
      },
      ctx,
    );
    expect(result.success).toBe(true);
    // باید warning باشد (نه fail)
    // attention: ممکن است DuplicateWithinWindow فقط warning برگرداند یا صرفاً pass کند
    // در هر حال success=true باید باشد
  });
});

describe('registerV81Rules — only V8.1 rules', () => {
  it('should register only V8.1 granular rules (not V8.0)', () => {
    const freshRegistry = new RuleRegistry();
    registerV81Rules(freshRegistry);
    const names = freshRegistry.list().map((r) => r.name);

    // V8.1 rules should be there
    expect(names).toContain('discount.wholesale');
    expect(names).toContain('credit.limit_check');
    expect(names).toContain('shipping.free_threshold');
    expect(names).toContain('order.duplicate_within_window');

    // V8.0 rules should NOT be there
    expect(names).not.toContain('order.max_quantity');
    expect(names).not.toContain('order.minimum_amount');
  });
});
