// ============================================================
// YIO V8.1 — Integration Tests
// ============================================================
// این تست‌ها چندین کامپوننت را با هم تست می‌کنند (نه فقط یک کلاس).
// مثلاً:
//   - OrderEngine + TransactionManager + EventBus + AuditLogger
//   - BaseRepository + Prisma (با In-Memory mock)
//   - UseCase + @Transactional + @Auditable
//
// تفاوت با Unit Test:
//   - Unit: فقط یک کلاس با mock dependencies
//   - Integration: چند کلاس واقعی با هم، با stub برای infrastructure بیرونی
// ============================================================

import { describe, it, expect, beforeEach } from 'vitest';
import {
  OrderEngine,
  InMemoryEventBus,
  RuleRegistry,
  RuleEngine,
  AuditLogger,
  registerAllGranularRules,
  OrderUseCase,
  BaseUseCase,
  Transactional,
  Auditable,
  NoopLogger,
} from '../../src/index';
import {
  Context,
  Events,
  OrderCreatedEvent,
  IOrderRepository,
  IProductRepository,
  IInventoryRepository,
  ITransactionManager,
  ITransactionContext,
  DomainEvent,
  AuditEntry,
  PaginatedResult,
  BusinessError,
  noopLogger,
  ILogger,
} from '@yio/core';

// ============================================================
// Fake Repository Implementations (شبیه Prisma اما In-Memory)
// ============================================================
class FakeOrderRepository implements IOrderRepository {
  public orders: Map<number, any> = new Map();
  private nextId = 1;

  async findById(id: number, _ctx: Context, _tx?: ITransactionContext) {
    return this.orders.get(id) || null;
  }
  async findMany(_opts: any, _ctx: Context): Promise<PaginatedResult<any>> {
    return { data: Array.from(this.orders.values()), pagination: { page: 1, pageSize: 10, total: this.orders.size, totalPages: 1 } };
  }
  async create(data: any, ctx: Context) {
    const id = this.nextId++;
    const order = { ...data, id, tenantId: ctx.tenantId, createdAt: new Date(), updatedAt: new Date() };
    this.orders.set(id, order);
    return order;
  }
  async update(id: number, data: any, _ctx: Context, _tx?: ITransactionContext) {
    const order = this.orders.get(id);
    if (!order) throw new Error('Order not found');
    Object.assign(order, data);
    return order;
  }
  async softDelete(id: number, _ctx: Context, _tx?: ITransactionContext) {
    this.orders.delete(id);
  }
  async count(_where: any, _ctx: Context, _tx?: ITransactionContext) {
    return this.orders.size;
  }
  async findByStatus(status: string, ctx: Context, _page = 1, _pageSize = 10) {
    const data = Array.from(this.orders.values()).filter((o) => o.status === status);
    return { data, pagination: { page: 1, pageSize: 10, total: data.length, totalPages: 1 } };
  }
  async findUserOrders(userId: number, _ctx: Context) {
    return Array.from(this.orders.values()).filter((o) => o.userId === userId);
  }
  async updateStatus(id: number, status: string, _ctx: Context, _tx?: ITransactionContext) {
    const order = this.orders.get(id);
    if (order) order.status = status;
  }
  async updateTracking(id: number, trackingCode: string, _ctx: Context, _tx?: ITransactionContext) {
    const order = this.orders.get(id);
    if (order) {
      order.trackingCode = trackingCode;
      order.status = 'shipping';
    }
  }
  async generateOrderNumber(_ctx: Context) {
    return `YIO-INT-${this.nextId}`;
  }
  async createWithItems(order: any, items: any[], ctx: Context, _tx?: ITransactionContext) {
    const id = this.nextId++;
    const fullOrder = { ...order, id, tenantId: ctx.tenantId };
    this.orders.set(id, { ...fullOrder, items });
    return { id, orderNumber: order.orderNumber };
  }
}

class FakeProductRepository implements IProductRepository {
  public products: Map<number, any> = new Map();
  async findById(id: number, _ctx: Context, _tx?: ITransactionContext) {
    return this.products.get(id) || null;
  }
  async findMany(_opts: any, _ctx: Context): Promise<PaginatedResult<any>> {
    return { data: Array.from(this.products.values()), pagination: { page: 1, pageSize: 10, total: 0, totalPages: 1 } };
  }
  async create(data: any, ctx: Context) {
    const id = (this.products.size || 0) + 1;
    const p = { ...data, id, tenantId: ctx.tenantId };
    this.products.set(id, p);
    return p;
  }
  async update(id: number, data: any, _ctx: Context, _tx?: ITransactionContext) {
    const p = this.products.get(id);
    if (p) Object.assign(p, data);
    return p;
  }
  async softDelete(id: number, _ctx: Context, _tx?: ITransactionContext) {
    this.products.delete(id);
  }
  async count(_where: any, _ctx: Context, _tx?: ITransactionContext) {
    return this.products.size;
  }
  async findPublished(_ctx: Context, _opts?: any) {
    return { data: Array.from(this.products.values()).filter((p) => p.isPublished), pagination: { page: 1, pageSize: 10, total: 0, totalPages: 1 } };
  }
  async publish(id: number, _ctx: Context, _tx?: ITransactionContext) {
    const p = this.products.get(id);
    if (p) { p.isPublished = true; p.publishedAt = new Date(); }
  }
  async unpublish(id: number, _ctx: Context, _tx?: ITransactionContext) {
    const p = this.products.get(id);
    if (p) { p.isPublished = false; p.publishedAt = null; }
  }
  async updateStock(id: number, delta: number, _ctx: Context, _tx?: ITransactionContext) {
    const p = this.products.get(id);
    if (p) {
      p.stockQuantity += delta;
      p.inStock = p.stockQuantity > 0;
      return p.stockQuantity;
    }
    return 0;
  }
  async reserveStock(items: any[], _ctx: Context, _tx?: ITransactionContext) {
    for (const item of items) {
      const p = this.products.get(item.productId);
      if (!p || p.stockQuantity < item.quantity) {
        throw new Error('Insufficient stock');
      }
      p.stockQuantity -= item.quantity;
    }
  }
  async releaseStock(items: any[], _ctx: Context, _tx?: ITransactionContext) {
    for (const item of items) {
      const p = this.products.get(item.productId);
      if (p) p.stockQuantity += item.quantity;
    }
  }
}

class FakeInventoryRepository implements IInventoryRepository {
  public transactions: any[] = [];
  async getStock(_itemType: string, _itemId: number, _ctx: Context) { return 0; }
  async adjustStock(_itemType: string, _itemId: number, delta: number, _ctx: Context) { return delta; }
  async recordTransaction(tx: any, _ctx: Context) { this.transactions.push(tx); }
}

// ============================================================
// Fake Transaction Manager — که واقعاً rollback را شبیه‌سازی می‌کند
// ============================================================
class FakeTransactionManager implements ITransactionManager {
  public committedEvents: DomainEvent[] = [];
  public committedAudits: AuditEntry[] = [];
  public rollbackCount = 0;
  public commitCount = 0;
  public lastTxEvents: DomainEvent[] = []; // events قبل از commit

  create() {
    return {
      isActive: () => false,
      begin: async () => {},
      commit: async () => { this.commitCount++; },
      rollback: async () => { this.rollbackCount++; },
      run: async <T>(fn: (tx: ITransactionContext) => Promise<T>): Promise<T> => {
        const ctx: ITransactionContext = {
          transactionId: `tx-${Date.now()}-${Math.random()}`,
          client: {},
          collectEvent: (e: DomainEvent) => { this.lastTxEvents.push(e); },
          collectEvents: (es: DomainEvent[]) => { this.lastTxEvents.push(...es); },
          collectAudit: (a: AuditEntry) => {},
        };
        try {
          const result = await fn(ctx);
          // simulate commit — events flow through
          this.committedEvents.push(...this.lastTxEvents);
          this.lastTxEvents = [];
          this.commitCount++;
          return result;
        } catch (err) {
          // simulate rollback — events discarded
          this.lastTxEvents = [];
          this.rollbackCount++;
          throw err;
        }
      },
    } as any;
  }

  async run<T>(fn: (tx: ITransactionContext) => Promise<T>): Promise<T> {
    return this.create().run(fn);
  }
}

// ============================================================
// Setup
// ============================================================
let orderRepo: FakeOrderRepository;
let productRepo: FakeProductRepository;
let inventoryRepo: FakeInventoryRepository;
let eventBus: InMemoryEventBus;
let txManager: FakeTransactionManager;
let ruleEngine: RuleEngine;
let auditLogger: AuditLogger;
let engine: OrderEngine;
let useCase: OrderUseCase;

const ctx: Context = {
  tenantId: 1,
  userId: 10,
  userRole: 'customer',
  permissions: ['order.create'],
  ip: '127.0.0.1',
  userAgent: 'integration-test',
  requestId: 'req-int-1',
};

beforeEach(() => {
  orderRepo = new FakeOrderRepository();
  productRepo = new FakeProductRepository();
  inventoryRepo = new FakeInventoryRepository();
  eventBus = new InMemoryEventBus(new NoopLogger());
  txManager = new FakeTransactionManager();

  const ruleRegistry = new RuleRegistry();
  registerAllGranularRules(ruleRegistry);
  ruleEngine = new RuleEngine(
    { siteSetting: { findMany: async () => [] } } as any,
    ruleRegistry,
  );

  auditLogger = new AuditLogger({
    append: async () => {},
    query: async () => ({ data: [], pagination: { page: 1, pageSize: 10, total: 0, totalPages: 1 } }),
  } as any);

  engine = new OrderEngine(
    orderRepo, productRepo, inventoryRepo, eventBus, txManager,
    ruleEngine, auditLogger, new NoopLogger(),
  );

  useCase = new OrderUseCase(
    orderRepo, productRepo, inventoryRepo, eventBus,
    ruleEngine, auditLogger, txManager, new NoopLogger(),
  );

  // seed a product
  productRepo.products.set(1, {
    id: 1, title: 'میز چوبی', price: 100000, discountPrice: null,
    stockQuantity: 50, inStock: true, image: 'test.jpg', tenantId: 1,
  });
});

// ============================================================
// Tests
// ============================================================
describe('Integration: OrderEngine + UoW + EventBus + Audit', () => {
  it('should create order with full transaction flow', async () => {
    const result = await engine.createOrder(
      {
        userId: 10,
        items: [{ productId: 1, quantity: 5 }],
        shippingAddress: 'Tehran',
        recipientName: 'Ali',
        recipientPhone: '09120000000',
        paymentMethod: 'cod',
      },
      ctx,
    );

    expect(result.orderId).toBeGreaterThan(0);

    // تراکنش commit شده
    expect(txManager.commitCount).toBeGreaterThan(0);

    // Event جمع‌آوری شده
    expect(txManager.committedEvents.length).toBeGreaterThanOrEqual(1);
    expect(txManager.committedEvents[0].eventName).toBe(Events.OrderCreated);

    // موجودی رزرو شده (کاهش یافته)
    const product = productRepo.products.get(1)!;
    expect(product.stockQuantity).toBe(45); // 50 - 5
  });

  it('should rollback transaction on failure', async () => {
    // محصول بدون موجودی کافی
    productRepo.products.set(2, {
      id: 2, title: 'صندلی', price: 50000, discountPrice: null,
      stockQuantity: 1, inStock: true, image: 'chair.jpg', tenantId: 1,
    });

    // تلاش برای سفارش با quantity > stock
    // این validation قبل از tx رخ می‌دهد (در محاسبه مبلغ)
    await expect(
      engine.createOrder(
        {
          userId: 10,
          items: [{ productId: 2, quantity: 10 }],
          shippingAddress: 'Tehran',
          recipientName: 'Ali',
          recipientPhone: '09120000000',
          paymentMethod: 'cod',
        },
        ctx,
      ),
    ).rejects.toThrow();

    // هیچ event نباید commit شده باشد
    expect(txManager.committedEvents.length).toBe(0);

    // موجودی محصول نباید تغییر کرده باشد (rollback شده یا اصلاً tx باز نشده)
    const product = productRepo.products.get(2)!;
    expect(product.stockQuantity).toBe(1);
  });

  it('should evaluate granular rules (DiscountRule, etc.)', async () => {
    // coupon معتبر
    const result = await engine.createOrder(
      {
        userId: 10,
        items: [{ productId: 1, quantity: 3 }], // 3 * 100k = 300k
        shippingAddress: 'Tehran',
        recipientName: 'Ali',
        recipientPhone: '09120000000',
        paymentMethod: 'cod',
        // couponCode: 'YIO10'  // این فیلد در input تعریف نشده، فقط rule test
      } as any,
      ctx,
    );

    // باید با موفقیت ایجاد شود (Ruleها pass شده‌اند)
    expect(result.orderId).toBeGreaterThan(0);
  });

  it('should fail when blacklisted customer tries to order', async () => {
    // RuleEngine باید BlacklistedCustomerRule را اجرا کند
    // این Rule در order.create action فعال است
    // برای تست، باید data.customerIsBlacklisted = true پاس داده شود
    // اما در OrderEngine این فیلد از input خوانده نمی‌شود
    // این تست صرفاً نشان می‌دهد که rule engine فراخوانی می‌شود
    const result = await engine.createOrder(
      {
        userId: 10,
        items: [{ productId: 1, quantity: 1 }],
        shippingAddress: 'Tehran',
        recipientName: 'Ali',
        recipientPhone: '09120000000',
        paymentMethod: 'cod',
      },
      ctx,
    );
    expect(result.orderId).toBeGreaterThan(0);
  });
});

describe('Integration: OrderUseCase with @Transactional + @Auditable', () => {
  it('should run createOrder inside transaction automatically', async () => {
    const result = await useCase.createOrder(
      {
        userId: 10,
        items: [{ productId: 1, quantity: 3 }],
        shippingAddress: 'Tehran',
        recipientName: 'Ali',
        recipientPhone: '09120000000',
        paymentMethod: 'cod',
      },
      ctx,
    );

    expect(result.orderId).toBeGreaterThan(0);
    expect(result.orderNumber).toMatch(/^YIO-INT-\d+$/);
    expect(result.totalAmount).toBe(300000);
    expect(result.finalAmount).toBe(389000); // 300k + 89k shipping

    // @Transactional باید txManager.run را صدا زده باشد
    expect(txManager.commitCount).toBeGreaterThan(0);

    // @Auditable باید audit لاگ ثبت کرده باشد
    // (در FakeTransactionManager، auditها در collectAudit ذخیره نمی‌شوند
    // چون tx.collectAudit no-op است؛ اما @Auditable باید کار کرده باشد)

    // موجودی باید کاهش یافته باشد
    const product = productRepo.products.get(1)!;
    expect(product.stockQuantity).toBe(47); // 50 - 3
  });

  it('should rollback on failure (decorator preserves transaction semantics)', async () => {
    await expect(
      useCase.createOrder(
        {
          userId: 10,
          items: [{ productId: 999, quantity: 1 }], // محصول ناموجود
          shippingAddress: 'Tehran',
          recipientName: 'Ali',
          recipientPhone: '09120000000',
          paymentMethod: 'cod',
        },
        ctx,
      ),
    ).rejects.toThrow();

    expect(txManager.rollbackCount).toBeGreaterThan(0);
  });

  it('should support nested @Transactional calls (join existing tx)', async () => {
    // تست nested call: یک UseCase متد دیگر UseCase را صدا بزند
    // باید در همان tx اجرا شود

    // ابتدا یک سفارش بساز
    const createResult = await useCase.createOrder(
      {
        userId: 10,
        items: [{ productId: 1, quantity: 2 }],
        shippingAddress: 'Tehran',
        recipientName: 'Ali',
        recipientPhone: '09120000000',
        paymentMethod: 'cod',
      },
      ctx,
    );

    // سپس آن را تأیید کن
    const confirmResult = await useCase.confirmOrder(createResult.orderId, ctx);
    expect(confirmResult.success).toBe(true);

    const order = await orderRepo.findById(createResult.orderId, ctx);
    expect(order.status).toBe('confirmed');
  });

  it('should pay order and emit OrderPaid event', async () => {
    // ابتدا سفارش بساز
    const createResult = await useCase.createOrder(
      {
        userId: 10,
        items: [{ productId: 1, quantity: 1 }],
        shippingAddress: 'Tehran',
        recipientName: 'Ali',
        recipientPhone: '09120000000',
        paymentMethod: 'cod',
      },
      ctx,
    );

    // ایندکس events قبلی را بگیر
    const eventsBefore = txManager.committedEvents.length;

    // پرداخت کن
    const payResult = await useCase.payOrder(
      createResult.orderId,
      389000,
      'online',
      ctx,
    );
    expect(payResult.success).toBe(true);

    // OrderPaid event باید emit شده باشد
    const newEvents = txManager.committedEvents.slice(eventsBefore);
    const hasPaidEvent = newEvents.some((e) => e.eventName === Events.OrderPaid);
    expect(hasPaidEvent).toBe(true);

    // سفارش باید paid شده باشد
    const order = await orderRepo.findById(createResult.orderId, ctx);
    expect(order.paymentStatus).toBe('paid');
  });
});

describe('Integration: EventBus.publishAll (batch publishing)', () => {
  it('should publish multiple events in a single batch', async () => {
    let receivedCount = 0;
    eventBus.subscribe(Events.OrderCreated, async () => { receivedCount++; });
    eventBus.subscribe(Events.OrderPaid, async () => { receivedCount++; });

    const events = [
      new OrderCreatedEvent(1, 100, 500000, 1),
      new (class extends (await import('@yio/core')).OrderPaidEvent {
        // ساخت یک instance برای تست
      })(1, 500000, 'online', 1),
    ];

    await eventBus.publishAll(events);

    // هر دو event باید received شده باشند
    expect(receivedCount).toBe(2);
  });

  it('should handle empty batch gracefully', async () => {
    await eventBus.publishAll([]);
    // نباید throw کند
  });

  it('should continue processing if one handler fails', async () => {
    let goodHandlerCalled = false;
    eventBus.subscribe(Events.OrderCreated, async () => {
      throw new Error('intentional failure');
    });
    eventBus.subscribe(Events.OrderCreated, async () => {
      goodHandlerCalled = true;
    });

    await eventBus.publishAll([
      new OrderCreatedEvent(1, 100, 500000, 1),
    ]);

    expect(goodHandlerCalled).toBe(true);
  });
});
