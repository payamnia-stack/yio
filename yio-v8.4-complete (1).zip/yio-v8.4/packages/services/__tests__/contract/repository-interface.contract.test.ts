// ============================================================
// YIO V8.1 — Contract Tests
// ============================================================
// Contract Test بررسی می‌کند که آیا یک پیاده‌سازی (Implementation)
// واقعاً با اینترفیس (Interface) مطابقت دارد یا نه.
//
// تفاوت با Unit و Integration:
//   - Unit: یک کلاس با mock
//   - Integration: چند کلاس با هم
//   - Contract: بررسی این که XxxRepository واقعاً تمام متدهای
//     IOrderRepository را پیاده‌سازی کرده است (شامل signature)
//
// این تست‌ها برای اطمینان از اینکه اگر فردا پیاده‌سازی Prisma را
// با Mongo جایگزین کردید، interface contract همچنان برقرار است.
// ============================================================

import { describe, it, expect } from 'vitest';
import { OrderRepository, ProductRepository } from '@yio/repositories';
import {
  IOrderRepository,
  IProductRepository,
  IBaseRepository,
  IEventBus,
  IEventStore,
  IUnitOfWork,
  ITransactionManager,
  IAuditLogger,
  ICache,
  ICommandBus,
  IQueryBus,
  IContainer,
  IRuleEngine,
  IRuleRegistry,
  IAbacPermissionChecker,
  DomainEvent,
  EventName,
} from '@yio/core';
import {
  InMemoryEventBus,
  PrismaEventStore,
  PrismaEventStoreRepository,
  PrismaTransactionManager,
  PrismaUnitOfWork,
  AuditLogger,
  PrismaAuditLogRepository,
  InMemoryCache,
  CommandBus,
  QueryBus,
  Container,
  RuleRegistry,
  RuleEngine,
  PermissionChecker,
} from '../../src/index';

// ============================================================
// Helper: بررسی اینکه یک شیء تمام متدهای اینترفیس را دارد
// ============================================================
function assertImplements<T>(obj: any, requiredMethods: string[]): void {
  for (const method of requiredMethods) {
    it(`should implement ${method}`, () => {
      expect(typeof obj[method]).toBe('function');
    });
  }
}

// ============================================================
// Helper: ساخت یک fake PrismaClient با modelهای مورد نیاز
// ============================================================
function createFakePrisma(): any {
  // مدل‌های fake با متدهای delegate که در BaseRepository استفاده می‌شوند
  const fakeModel = {
    findFirst: async () => null,
    findMany: async () => [],
    findUnique: async () => null,
    create: async () => ({}),
    createMany: async () => ({ count: 0 }),
    update: async () => ({}),
    updateMany: async () => ({ count: 0 }),
    delete: async () => ({}),
    deleteMany: async () => ({ count: 0 }),
    count: async () => 0,
  };

  return {
    order: { ...fakeModel },
    orderItem: { ...fakeModel, createMany: async () => ({ count: 0 }) },
    product: { ...fakeModel },
    woodStock: { ...fakeModel },
    paintStock: { ...fakeModel },
    inventoryTransaction: { ...fakeModel, create: async () => ({}) },
    auditLog: { ...fakeModel, create: async () => ({}), findMany: async () => [], count: async () => 0 },
    eventStoreRecord: { ...fakeModel, create: async () => ({}), findMany: async () => [] },
    siteSetting: { ...fakeModel, findMany: async () => [] },
    $transaction: async (fn: any) => fn({ ...fakeModel }),
  };
}

// ============================================================
// Contract: IOrderRepository ↔ OrderRepository
// ============================================================
describe('Contract: OrderRepository implements IOrderRepository', () => {
  const repo = new OrderRepository(createFakePrisma());
  const requiredMethods: (keyof IOrderRepository)[] = [
    'findById', 'findMany', 'create', 'update', 'softDelete', 'count',
    'findByStatus', 'findUserOrders', 'updateStatus',
    'updateTracking', 'generateOrderNumber', 'createWithItems',
  ];

  for (const method of requiredMethods) {
    it(`should have method: ${method}`, () => {
      expect(typeof (repo as any)[method]).toBe('function');
    });
  }
});

// ============================================================
// Contract: IProductRepository ↔ ProductRepository
// ============================================================
describe('Contract: ProductRepository implements IProductRepository', () => {
  const repo = new ProductRepository(createFakePrisma());
  const requiredMethods: (keyof IProductRepository)[] = [
    'findById', 'findMany', 'create', 'update', 'softDelete', 'count',
    'findPublished', 'publish', 'unpublish', 'updateStock',
    'reserveStock', 'releaseStock',
  ];

  for (const method of requiredMethods) {
    it(`should have method: ${method}`, () => {
      expect(typeof (repo as any)[method]).toBe('function');
    });
  }
});

// ============================================================
// Contract: IEventBus ↔ InMemoryEventBus
// ============================================================
describe('Contract: InMemoryEventBus implements IEventBus', () => {
  const bus = new InMemoryEventBus();
  const requiredMethods: (keyof IEventBus)[] = [
    'publish', 'publishAll', 'subscribe', 'unsubscribe',
  ];

  for (const method of requiredMethods) {
    it(`should have method: ${method}`, () => {
      expect(typeof (bus as any)[method]).toBe('function');
    });
  }

  it('subscribe should only accept EventName type (compile-time check)', () => {
    // این تست در compile time انجام می‌شود — اگر تایپ‌ها درست باشند،
    // این کد باید compile شود.
    const eventName: EventName = 'order.created' as EventName;
    bus.subscribe(eventName, async () => {});
    expect(true).toBe(true);
  });
});

// ============================================================
// Contract: IEventStore ↔ PrismaEventStore
// ============================================================
describe('Contract: PrismaEventStore implements IEventStore', () => {
  const repo = new PrismaEventStoreRepository(createFakePrisma());
  const store = new PrismaEventStore(repo);
  const requiredMethods: (keyof IEventStore)[] = [
    'append', 'getByAggregate', 'getByTenant', 'getByType',
  ];

  for (const method of requiredMethods) {
    it(`should have method: ${method}`, () => {
      expect(typeof (store as any)[method]).toBe('function');
    });
  }
});

// ============================================================
// Contract: IUnitOfWork ↔ PrismaUnitOfWork
// ============================================================
describe('Contract: PrismaUnitOfWork implements IUnitOfWork', () => {
  const uow = new PrismaUnitOfWork(
    createFakePrisma(),
    new InMemoryEventBus(),
    new AuditLogger({ append: async () => {} } as any),
  );
  const requiredMethods: (keyof IUnitOfWork)[] = [
    'begin', 'commit', 'rollback', 'run', 'isActive',
  ];

  for (const method of requiredMethods) {
    it(`should have method: ${method}`, () => {
      expect(typeof (uow as any)[method]).toBe('function');
    });
  }
});

// ============================================================
// Contract: ITransactionManager ↔ PrismaTransactionManager
// ============================================================
describe('Contract: PrismaTransactionManager implements ITransactionManager', () => {
  const tm = new PrismaTransactionManager(
    createFakePrisma(),
    new InMemoryEventBus(),
    new AuditLogger({ append: async () => {} } as any),
  );
  const requiredMethods: (keyof ITransactionManager)[] = ['create', 'run'];

  for (const method of requiredMethods) {
    it(`should have method: ${method}`, () => {
      expect(typeof (tm as any)[method]).toBe('function');
    });
  }
});

// ============================================================
// Contract: IAuditLogger ↔ AuditLogger
// ============================================================
describe('Contract: AuditLogger implements IAuditLogger', () => {
  const logger = new AuditLogger({ append: async () => {} } as any);
  const requiredMethods: (keyof IAuditLogger)[] = ['log', 'logChange', 'query'];

  for (const method of requiredMethods) {
    it(`should have method: ${method}`, () => {
      expect(typeof (logger as any)[method]).toBe('function');
    });
  }
});

// ============================================================
// Contract: ICache ↔ InMemoryCache
// ============================================================
describe('Contract: InMemoryCache implements ICache', () => {
  const cache = new InMemoryCache();
  const requiredMethods: (keyof ICache)[] = [
    'get', 'set', 'delete', 'invalidate', 'getOrSet', 'flush',
  ];

  for (const method of requiredMethods) {
    it(`should have method: ${method}`, () => {
      expect(typeof (cache as any)[method]).toBe('function');
    });
  }
});

// ============================================================
// Contract: ICommandBus ↔ CommandBus
// ============================================================
describe('Contract: CommandBus implements ICommandBus', () => {
  const bus = new CommandBus();
  const requiredMethods: (keyof ICommandBus)[] = ['register', 'execute'];

  for (const method of requiredMethods) {
    it(`should have method: ${method}`, () => {
      expect(typeof (bus as any)[method]).toBe('function');
    });
  }
});

// ============================================================
// Contract: IQueryBus ↔ QueryBus
// ============================================================
describe('Contract: QueryBus implements IQueryBus', () => {
  const bus = new QueryBus();
  const requiredMethods: (keyof IQueryBus)[] = ['register', 'execute'];

  for (const method of requiredMethods) {
    it(`should have method: ${method}`, () => {
      expect(typeof (bus as any)[method]).toBe('function');
    });
  }
});

// ============================================================
// Contract: IContainer ↔ Container
// ============================================================
describe('Contract: Container implements IContainer', () => {
  const container = new Container();
  const requiredMethods: (keyof IContainer)[] = [
    'bind', 'bindInstance', 'resolve', 'resolveSync', 'has', 'createScope', 'reset',
  ];

  for (const method of requiredMethods) {
    it(`should have method: ${method}`, () => {
      expect(typeof (container as any)[method]).toBe('function');
    });
  }
});

// ============================================================
// Contract: IRuleRegistry ↔ RuleRegistry
// ============================================================
describe('Contract: RuleRegistry implements IRuleRegistry', () => {
  const registry = new RuleRegistry();
  const requiredMethods: (keyof IRuleRegistry)[] = [
    'register', 'unregister', 'getRulesForAction', 'list',
  ];

  for (const method of requiredMethods) {
    it(`should have method: ${method}`, () => {
      expect(typeof (registry as any)[method]).toBe('function');
    });
  }
});

// ============================================================
// Contract: IRuleEngine ↔ RuleEngine
// ============================================================
describe('Contract: RuleEngine implements IRuleEngine', () => {
  const engine = new RuleEngine(createFakePrisma(), new RuleRegistry());
  const requiredMethods: (keyof IRuleEngine)[] = ['validate', 'evaluate'];

  for (const method of requiredMethods) {
    it(`should have method: ${method}`, () => {
      expect(typeof (engine as any)[method]).toBe('function');
    });
  }
});

// ============================================================
// Contract: IAbacPermissionChecker ↔ PermissionChecker
// ============================================================
describe('Contract: PermissionChecker implements IAbacPermissionChecker', () => {
  const checker = new PermissionChecker();
  const requiredMethods: (keyof IAbacPermissionChecker)[] = [
    'hasPermission', 'hasRole', 'checkAccess', 'registerPolicy', 'listPolicies',
  ];

  for (const method of requiredMethods) {
    it(`should have method: ${method}`, () => {
      expect(typeof (checker as any)[method]).toBe('function');
    });
  }
});
