// ============================================================
// YIO V8 — Workflow Engine Tests
// ============================================================

import { describe, it, expect, beforeEach } from 'vitest';
import { WorkflowEngine, DEFAULT_WORKFLOWS } from '../src/engines/workflow-engine';
import { InMemoryEventBus } from '../src/event-bus/event-bus';
import { Context, Events } from '@yio/core';

const ctx: Context = { tenantId: 1, userId: 1 };

describe('Workflow Engine (V8)', () => {
  describe('Default Workflows', () => {
    it('should define sales_order workflow', () => {
      expect(DEFAULT_WORKFLOWS.sales_order).toBeDefined();
      expect(DEFAULT_WORKFLOWS.sales_order.length).toBeGreaterThan(5);
    });

    it('should have ordered steps', () => {
      const steps = DEFAULT_WORKFLOWS.sales_order;
      for (let i = 0; i < steps.length - 1; i++) {
        expect(steps[i].order).toBeLessThanOrEqual(steps[i + 1].order);
      }
    });

    it('should have SLA on operational steps (except final "تکمیل")', () => {
      const steps = DEFAULT_WORKFLOWS.sales_order;
      const operationalSteps = steps.filter((s) => s.role !== 'system');
      for (const step of operationalSteps) {
        expect(step.slaHours).toBeDefined();
        expect(step.slaHours).toBeGreaterThan(0);
      }
    });

    it('should have decision branches on relevant steps', () => {
      const decisions = DEFAULT_WORKFLOWS.sales_order.filter((s) => s.isDecision);
      expect(decisions.length).toBeGreaterThan(0);
      for (const d of decisions) {
        expect(d.branches).toBeDefined();
        expect(Object.keys(d.branches!).length).toBeGreaterThan(0);
      }
    });
  });

  describe('Workflow Event Subscriptions', () => {
    it('should subscribe to all order lifecycle events (typed)', () => {
      const prismaMock: any = {
        workflowInstance: { findFirst: async () => null, create: async () => ({}), update: async () => ({}) },
      };
      const eventBus = new InMemoryEventBus();
      const engine = new WorkflowEngine(prismaMock, eventBus);

      const subs = eventBus.getSubscriptions();
      expect(subs.get(Events.OrderCreated)).toBeGreaterThanOrEqual(1);
      expect(subs.get(Events.OrderConfirmed)).toBeGreaterThanOrEqual(1);
      expect(subs.get(Events.OrderShipped)).toBeGreaterThanOrEqual(1);
      expect(subs.get(Events.OrderDelivered)).toBeGreaterThanOrEqual(1);
      expect(subs.get(Events.OrderCancelled)).toBeGreaterThanOrEqual(1);
    });
  });
});
