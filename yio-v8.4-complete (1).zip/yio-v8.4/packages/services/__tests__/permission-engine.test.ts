// ============================================================
// YIO V8 — Permission Engine (ABAC) Unit Tests
// ============================================================

import { describe, it, expect, beforeEach } from 'vitest';
import { PermissionChecker, ROLES } from '../src/engines/permission-engine';
import { Context } from '@yio/core';

let checker: PermissionChecker;

const adminCtx: Context = {
  tenantId: 1,
  userId: 1,
  userRole: 'ceo',
  permissions: ['admin.full'],
  ip: '127.0.0.1',
};

const salesManagerCtx: Context = {
  tenantId: 1,
  userId: 2,
  userRole: 'sales_manager',
  permissions: [...ROLES.sales_manager.permissions],
  ip: '127.0.0.1',
};

const customerCtx: Context = {
  tenantId: 1,
  userId: 100,
  userRole: 'customer',
  permissions: [...ROLES.customer.permissions],
  ip: '127.0.0.1',
};

const operatorCtx: Context = {
  tenantId: 1,
  userId: 50,
  userRole: 'operator',
  permissions: [...ROLES.operator.permissions],
  ip: '127.0.0.1',
};

beforeEach(() => {
  checker = new PermissionChecker();
});

describe('PermissionChecker (V8 — RBAC + ABAC)', () => {
  describe('RBAC', () => {
    it('should allow admin to do anything', () => {
      expect(checker.hasPermission('order.create', adminCtx)).toBe(true);
      expect(checker.hasPermission('product.delete', adminCtx)).toBe(true);
      expect(checker.hasPermission('settings.manage', adminCtx)).toBe(true);
    });

    it('should allow sales manager to confirm orders', () => {
      expect(checker.hasPermission('order.confirm', salesManagerCtx)).toBe(true);
      expect(checker.hasPermission('order.create', salesManagerCtx)).toBe(true);
    });

    it('should deny customer from confirming orders', () => {
      expect(checker.hasPermission('order.confirm', customerCtx)).toBe(false);
      expect(checker.hasPermission('order.create', customerCtx)).toBe(true);
    });

    it('should deny operator from inventory access', () => {
      expect(checker.hasPermission('inventory.adjust', operatorCtx)).toBe(false);
      expect(checker.hasPermission('quality.check', operatorCtx)).toBe(true);
    });
  });

  describe('ABAC — checkAccess', () => {
    it('should allow admin full access', () => {
      const decision = checker.checkAccess('order.create', adminCtx);
      expect(decision.allowed).toBe(true);
      expect(decision.matchedPolicy).toBe('admin.full');
    });

    it('should deny if RBAC permission missing', () => {
      const decision = checker.checkAccess('admin.full', customerCtx);
      expect(decision.allowed).toBe(false);
      expect(decision.deniedReason).toContain('RBAC');
    });

    it('should allow customer to view own orders (ABAC self)', () => {
      const decision = checker.checkAccess('order.view', customerCtx, {
        entityOwnerId: 100,
        userId: 100,
      });
      expect(decision.allowed).toBe(true);
      expect(decision.matchedPolicy).toBe('customer_self_orders');
    });

    it('should deny customer from viewing other customer orders (ABAC self)', () => {
      const decision = checker.checkAccess('order.view', customerCtx, {
        entityOwnerId: 999, // سفارش کاربر دیگری
        userId: 100,
      });
      // به‌طور پیش‌فرض deny می‌شود چون policy customer_self_orders شرط entityOwnerId===userId را ندارد
      expect(decision.allowed).toBe(false);
    });

    it('should deny modifications on cancelled orders (ABAC)', () => {
      const decision = checker.checkAccess('order.confirm', salesManagerCtx, {
        entityStatus: 'cancelled',
      });
      expect(decision.allowed).toBe(false);
      expect(decision.matchedPolicy).toBe('no_modify_cancelled_orders');
    });

    it('should respect working hours for finance actions', () => {
      // این تست بستگی به ساعت اجرا دارد؛ فعلاً فقط بررسی می‌کنیم که
      // policy اجرا می‌شود.
      const decision = checker.checkAccess('finance.payment', {
        tenantId: 1,
        userId: 5,
        userRole: 'finance',
        permissions: [...ROLES.finance.permissions],
      });
      // اگر بین ۷ تا ۲۳ باشیم → allow، وگرنه deny
      const hour = new Date().getHours();
      const expected = hour >= 7 && hour <= 23;
      expect(decision.allowed).toBe(expected);
    });

    it('should list registered policies', () => {
      const policies = checker.listPolicies();
      expect(policies.length).toBeGreaterThan(0);
      expect(policies.some((p) => p.name === 'admin.full')).toBe(false); // admin.full کلاس جدا است
      expect(policies.some((p) => p.name === 'customer_self_orders')).toBe(true);
    });
  });

  describe('checkOwnership', () => {
    it('admin can access anything', () => {
      expect(checker.checkOwnership(999, adminCtx)).toBe(true);
    });

    it('sales manager can access all orders', () => {
      expect(checker.checkOwnership(999, salesManagerCtx)).toBe(true);
    });

    it('customer can only access own records', () => {
      expect(checker.checkOwnership(100, customerCtx)).toBe(true);
      expect(checker.checkOwnership(999, customerCtx)).toBe(false);
    });
  });

  describe('Role Management', () => {
    it('should return permissions for a role', () => {
      const perms = checker.getRolePermissions('sales_manager');
      expect(perms).toContain('order.confirm');
      expect(perms).toContain('order.cancel');
    });

    it('should list all roles', () => {
      const roles = checker.getAllRoles();
      expect(roles.length).toBeGreaterThan(5);
      expect(roles.find((r) => r.key === 'ceo')).toBeDefined();
    });

    it('should register a new custom policy', () => {
      const initialCount = checker.listPolicies().length;
      checker.registerPolicy({
        name: 'test_custom_policy',
        resource: 'product',
        action: 'delete',
        requiredRoles: ['designer'],
        priority: 100,
        effect: 'allow',
      });
      expect(checker.listPolicies().length).toBe(initialCount + 1);
    });
  });
});
