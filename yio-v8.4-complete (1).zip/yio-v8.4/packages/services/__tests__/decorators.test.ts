// ============================================================
// YIO V8.1 — @Transactional / @Auditable Tests
// ============================================================

import { describe, it, expect, beforeEach } from 'vitest';
import {
  Transactional,
  Auditable,
  BaseUseCase,
  NoopLogger,
} from '../src/decorators';
import {
  ITransactionManager,
  ITransactionContext,
  IAuditLogger,
  Context,
  DomainEvent,
  AuditEntry,
  noopLogger,
} from '@yio/core';

// ============================================================
// Fake Transaction Manager
// ============================================================
class FakeTxManager implements ITransactionManager {
  public runCount = 0;
  public lastTx: FakeTxContext | null = null;

  create() {
    return {
      isActive: () => false,
      begin: async () => {},
      commit: async () => {},
      rollback: async () => {},
      run: async <T>(fn: (tx: ITransactionContext) => Promise<T>): Promise<T> => {
        this.runCount++;
        const tx = new FakeTxContext();
        this.lastTx = tx;
        return fn(tx);
      },
    } as any;
  }

  async run<T>(fn: (tx: ITransactionContext) => Promise<T>): Promise<T> {
    return this.create().run(fn);
  }
}

class FakeTxContext implements ITransactionContext {
  public readonly transactionId: string = `tx-${Date.now()}`;
  public readonly client: any = {};
  public events: DomainEvent[] = [];
  public audits: AuditEntry[] = [];

  collectEvent(event: DomainEvent): void {
    this.events.push(event);
  }
  collectEvents(events: DomainEvent[]): void {
    this.events.push(...events);
  }
  collectAudit(entry: AuditEntry): void {
    this.audits.push(entry);
  }
}

// ============================================================
// Fake Audit Logger
// ============================================================
class FakeAuditLogger implements IAuditLogger {
  public entries: AuditEntry[] = [];

  async log(entry: AuditEntry): Promise<void> {
    this.entries.push(entry);
  }

  async logChange(..._args: any[]): Promise<void> {}

  query(..._args: any[]): Promise<any> {
    return Promise.resolve({ data: this.entries, pagination: { page: 1, pageSize: 10, total: this.entries.length, totalPages: 1 } });
  }
}

// ============================================================
// Test UseCase
// ============================================================
class TestUseCase extends BaseUseCase {
  public auditLogger: IAuditLogger;
  public logger = noopLogger;

  constructor(txManager: ITransactionManager, auditLogger: IAuditLogger) {
    super(txManager);
    this.auditLogger = auditLogger;
  }

  @Transactional()
  async doSomething(input: string, ctx: Context, tx?: ITransactionContext): Promise<string> {
    // tx باید به‌صورت خودکار تزریق شده باشد
    if (!tx) throw new Error('tx should be auto-injected by @Transactional');
    return `processed:${input}`;
  }

  @Transactional()
  @Auditable({
    entityType: 'TestEntity',
    action: 'test.do_auditable',
    operation: 'create',
    getEntityId: (result: any) => result.id,
  })
  async doAuditable(input: string, ctx: Context, tx?: ITransactionContext): Promise<{ id: number; result: string }> {
    if (!tx) throw new Error('tx should be auto-injected');
    return { id: 42, result: `processed:${input}` };
  }

  @Transactional()
  async doFail(input: string, ctx: Context, tx?: ITransactionContext): Promise<string> {
    throw new Error(`intentional failure: ${input}`);
  }

  @Transactional()
  async doNested(input: string, ctx: Context, tx?: ITransactionContext): Promise<string> {
    // این متد یک متد @Transactional دیگر را صدا می‌زند
    // باید در همان tx اجرا شود (joinExisting)
    return this.doSomething(input + '-nested', ctx, tx);
  }
}

// ============================================================
// Tests
// ============================================================
let txManager: FakeTxManager;
let auditLogger: FakeAuditLogger;
let useCase: TestUseCase;
const ctx: Context = { tenantId: 1, userId: 100, ip: '127.0.0.1' };

beforeEach(() => {
  txManager = new FakeTxManager();
  auditLogger = new FakeAuditLogger();
  useCase = new TestUseCase(txManager, auditLogger);
});

describe('@Transactional Decorator (V8.1)', () => {
  it('should auto-wrap method in a transaction', async () => {
    const result = await useCase.doSomething('hello', ctx);
    expect(result).toBe('processed:hello');
    expect(txManager.runCount).toBe(1);
  });

  it('should auto-inject tx as last argument', async () => {
    await useCase.doSomething('hello', ctx);
    expect(txManager.lastTx).not.toBeNull();
    expect(txManager.lastTx!.transactionId).toBeDefined();
  });

  it('should propagate errors (and trigger rollback in real UoW)', async () => {
    await expect(useCase.doFail('test', ctx)).rejects.toThrow('intentional failure: test');
    // txManager.run باید صدا زده شده باشد ( حتی اگر fail شود )
    expect(txManager.runCount).toBe(1);
  });

  it('should support nested @Transactional calls (join existing tx)', async () => {
    const result = await useCase.doNested('outer', ctx);
    expect(result).toBe('processed:outer-nested');
    // فقط یک tx باید ایجاد شده باشد (nested در همان tx اجرا می‌شود)
    expect(txManager.runCount).toBe(1);
  });

  it('should throw clear error if txManager is missing', async () => {
    class BadUseCase extends BaseUseCase {
      // بدون فراخوانی super(txManager)
      constructor() {
        super({ run: async () => { throw new Error('should not be called'); } } as any);
      }
      @Transactional()
      async test() { return 'x'; }
    }
    const bad = new BadUseCase();
    // چون txManager یک stub خالی است که run هم throw می‌کند،
    // این تست نشان می‌دهد که @Transactional به txManager.run وابسته است
    await expect(bad.test()).rejects.toThrow();
  });
});

describe('@Auditable Decorator (V8.1)', () => {
  it('should auto-generate audit entry on success', async () => {
    const result = await useCase.doAuditable('test', ctx);
    expect(result.id).toBe(42);

    // باید یک audit entry داخل tx جمع‌آوری شده باشد
    expect(txManager.lastTx).not.toBeNull();
    expect(txManager.lastTx!.audits.length).toBeGreaterThanOrEqual(1);

    const audit = txManager.lastTx!.audits[0];
    expect(audit.action).toBe('test.do_auditable');
    expect(audit.entityType).toBe('TestEntity');
    expect(audit.operation).toBe('create');
    expect(audit.entityId).toBe(42); // از getEntityId
    expect(audit.userId).toBe(100);
    expect(audit.ip).toBe('127.0.0.1');
  });

  it('should also log audit on failure (with .failed action)', async () => {
    class FailingUseCase extends BaseUseCase {
      public auditLogger: IAuditLogger;
      constructor(txManager: ITransactionManager, audit: IAuditLogger) {
        super(txManager);
        this.auditLogger = audit;
      }

      @Transactional()
      @Auditable({
        entityType: 'Order',
        action: 'order.create',
        operation: 'create',
      })
      async create(_input: any, _ctx: Context, _tx?: ITransactionContext): Promise<any> {
        throw new Error('business failure');
      }
    }

    const failing = new FailingUseCase(txManager, auditLogger);
    await expect(failing.create({ data: 'x' }, ctx)).rejects.toThrow('business failure');

    // باید یک audit entry برای failure ثبت شده باشد
    expect(auditLogger.entries.length).toBeGreaterThanOrEqual(1);
    const failureAudit = auditLogger.entries.find((a) => a.action === 'order.create.failed');
    expect(failureAudit).toBeDefined();
    expect(failureAudit!.metadata?.error).toBe('business failure');
  });

  it('should sanitize sensitive fields (password, token) from input', async () => {
    class SensitiveUseCase extends BaseUseCase {
      public auditLogger: IAuditLogger;
      constructor(txManager: ITransactionManager, audit: IAuditLogger) {
        super(txManager);
        this.auditLogger = audit;
      }

      @Transactional()
      @Auditable({
        entityType: 'User',
        action: 'user.register',
        operation: 'create',
        getEntityId: () => 1,
      })
      async register(input: any, _ctx: Context, _tx?: ITransactionContext): Promise<any> {
        return { id: 1 };
      }
    }

    const sensitive = new SensitiveUseCase(txManager, auditLogger);
    await sensitive.register(
      { name: 'Ali', password: 'secret123', token: 'jwt-token' },
      ctx,
    );

    // audit نباید password یا token داشته باشد
    const audit = txManager.lastTx!.audits[0];
    expect(audit.metadata).toBeUndefined(); // چون getMetadata ارائه نشده
  });
});
