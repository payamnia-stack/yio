// ============================================================
// YIO V8 — DI Container Tests
// ============================================================

import { describe, it, expect, beforeEach } from 'vitest';
import { Container, getContainer, setContainer, resetContainer } from '../src/di/container';
import { TOKENS } from '@yio/core';

let container: Container;

beforeEach(() => {
  container = new Container();
  setContainer(container);
});

afterEach(() => {
  resetContainer();
});

import { afterEach } from 'vitest';

describe('DI Container (V8)', () => {
  it('should resolve a transient binding', async () => {
    let counter = 0;
    container.bind(TOKENS.Logger, () => ({ id: ++counter }));
    const a = await container.resolve<{ id: number }>(TOKENS.Logger);
    const b = await container.resolve<{ id: number }>(TOKENS.Logger);
    expect(a.id).toBe(1);
    expect(b.id).toBe(2); // transient → همیشه factory جدید
  });

  it('should resolve a singleton binding (cached)', async () => {
    let counter = 0;
    container.bind(
      TOKENS.Logger,
      () => ({ id: ++counter }),
      'singleton' as any,
    );
    const a = await container.resolve<{ id: number }>(TOKENS.Logger);
    const b = await container.resolve<{ id: number }>(TOKENS.Logger);
    expect(a.id).toBe(1);
    expect(b.id).toBe(1); // singleton → همان instance
  });

  it('should resolve sync if factory is sync', () => {
    container.bind(TOKENS.Logger, () => ({ log: () => {} }));
    const logger = container.resolveSync<{ log: () => void }>(TOKENS.Logger);
    expect(typeof logger.log).toBe('function');
  });

  it('should bindInstance directly', () => {
    const instance = { name: 'pre-built' };
    container.bindInstance(TOKENS.Logger, instance);
    const resolved = container.resolveSync<{ name: string }>(TOKENS.Logger);
    expect(resolved).toBe(instance); // همان reference
  });

  it('should throw if no binding registered', async () => {
    await expect(container.resolve('unknown.token')).rejects.toThrow();
  });

  it('should check has()', () => {
    expect(container.has(TOKENS.Logger)).toBe(false);
    container.bind(TOKENS.Logger, () => ({}));
    expect(container.has(TOKENS.Logger)).toBe(true);
  });

  it('should create child scope that inherits parent bindings', async () => {
    container.bind(TOKENS.Logger, () => ({ parent: true }), 'singleton' as any);
    const child = container.createScope() as Container;
    expect(child.has(TOKENS.Logger)).toBe(true);
    // child باید instance parent را resolve کند
    const logger = await child.resolve<{ parent: boolean }>(TOKENS.Logger);
    expect(logger.parent).toBe(true);
  });

  it('should support async factories', async () => {
    container.bind(
      TOKENS.Logger,
      async () => {
        await new Promise((r) => setTimeout(r, 10));
        return { async: true };
      },
    );
    const logger = await container.resolve<{ async: boolean }>(TOKENS.Logger);
    expect(logger.async).toBe(true);
  });

  it('should reset all bindings', async () => {
    container.bind(TOKENS.Logger, () => ({}));
    expect(container.has(TOKENS.Logger)).toBe(true);
    container.reset();
    expect(container.has(TOKENS.Logger)).toBe(false);
  });

  it('should resolve dependencies recursively', async () => {
    // Logger → no deps
    container.bind(TOKENS.Logger, () => ({ log: (m: string) => console.log(m) }));
    // OrderEngine depends on Logger (مثال)
    container.bind(
      TOKENS.OrderEngine,
      (c) => {
        // sync resolve برای Logger (چون singleton نیست، باید async باشد)
        return c.resolveSync<{ log: (m: string) => void }>(TOKENS.Logger).then
          ? null
          : { logger: c.resolveSync(TOKENS.Logger) };
      },
    );
    // Note: این تست فقط نشان می‌دهد که می‌توان از داخل factory به container دسترسی داشت
    // در عمل، dependency resolution توسط container انجام می‌شود
  });
});

describe('Global Container', () => {
  it('getContainer() should return same instance', () => {
    const c1 = getContainer();
    const c2 = getContainer();
    expect(c1).toBe(c2);
  });

  it('setContainer() should override global', () => {
    const original = getContainer();
    const custom = new Container();
    setContainer(custom);
    expect(getContainer()).toBe(custom);
    expect(getContainer()).not.toBe(original);
  });
});
