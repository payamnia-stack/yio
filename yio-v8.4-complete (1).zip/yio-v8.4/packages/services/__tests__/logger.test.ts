// ============================================================
// YIO V8.1 — Logger Tests
// ============================================================

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { ConsoleLogger, NoopLogger, PinoLogger, createLogger } from '../src/logger/logger';

describe('ConsoleLogger (V8.1)', () => {
  let logger: ConsoleLogger;
  let consoleLogSpy: any;
  let consoleWarnSpy: any;
  let consoleErrorSpy: any;
  let consoleDebugSpy: any;

  beforeEach(() => {
    logger = new ConsoleLogger('debug');
    consoleLogSpy = vi.spyOn(console, 'log').mockImplementation(() => {});
    consoleWarnSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});
    consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
    consoleDebugSpy = vi.spyOn(console, 'debug').mockImplementation(() => {});
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('should log info with timestamp', () => {
    logger.info('test message');
    expect(consoleLogSpy).toHaveBeenCalled();
    const args = consoleLogSpy.mock.calls[0];
    expect(args[0]).toContain('[INFO');
    expect(args[0]).toContain('test message');
  });

  it('should log warn', () => {
    logger.warn('warning message');
    expect(consoleWarnSpy).toHaveBeenCalled();
  });

  it('should log error', () => {
    logger.error('error message');
    expect(consoleErrorSpy).toHaveBeenCalled();
  });

  it('should log debug only when level is debug', () => {
    logger.debug('debug message');
    expect(consoleDebugSpy).toHaveBeenCalled();
  });

  it('should respect log level (info level should not log debug)', () => {
    const infoLogger = new ConsoleLogger('info');
    infoLogger.debug('should not be logged');
    expect(consoleDebugSpy).not.toHaveBeenCalled();
  });

  it('should format metadata as JSON', () => {
    logger.info('with meta', { userId: 123, action: 'test' });
    expect(consoleLogSpy).toHaveBeenCalled();
    const args = consoleLogSpy.mock.calls[0];
    // کل خروجی (شامل message + meta) باید در args باشد
    const fullOutput = args.join(' ');
    expect(fullOutput).toContain('"userId":123');
    expect(fullOutput).toContain('"action":"test"');
  });

  it('should not format empty metadata', () => {
    logger.info('no meta', {});
    expect(consoleLogSpy).toHaveBeenCalled();
    const args = consoleLogSpy.mock.calls[0];
    const fullOutput = args.join(' ');
    // نباید JSON خالی داشته باشد
    expect(fullOutput).not.toContain('{}');
  });
});

describe('NoopLogger (V8.1)', () => {
  let logger: NoopLogger;

  beforeEach(() => {
    logger = new NoopLogger();
  });

  it('should not throw on any log call', () => {
    expect(() => logger.info('x')).not.toThrow();
    expect(() => logger.warn('x')).not.toThrow();
    expect(() => logger.error('x')).not.toThrow();
    expect(() => logger.debug('x')).not.toThrow();
  });

  it('should be silent (no output)', () => {
    const consoleSpy = vi.spyOn(console, 'log').mockImplementation(() => {});
    logger.info('silent');
    expect(consoleSpy).not.toHaveBeenCalled();
    consoleSpy.mockRestore();
  });
});

describe('PinoLogger (V8.1)', () => {
  it('should fallback to ConsoleLogger if pino not installed', () => {
    // PinoLogger خودش fallback می‌کند
    const logger = new PinoLogger();
    expect(logger).toBeDefined();
    // نباید throw کند حتی اگر pino نباشد
    expect(() => logger.info('test')).not.toThrow();
  });

  it('should accept custom options', () => {
    const logger = new PinoLogger({
      level: 'warn',
      service: 'test-service',
    });
    expect(logger).toBeDefined();
  });
});

describe('createLogger Factory (V8.1)', () => {
  afterEach(() => {
    vi.restoreAllMocks();
    delete process.env.NODE_ENV;
    delete process.env.LOG_LEVEL;
  });

  it('should return NoopLogger in test environment', () => {
    process.env.NODE_ENV = 'test';
    const logger = createLogger();
    expect(logger).toBeInstanceOf(NoopLogger);
  });

  it('should return ConsoleLogger in development', () => {
    process.env.NODE_ENV = 'development';
    const logger = createLogger();
    expect(logger).toBeInstanceOf(ConsoleLogger);
  });

  it('should return PinoLogger in production', () => {
    process.env.NODE_ENV = 'production';
    const logger = createLogger();
    // ممکن است PinoLogger یا fallback باشد (اگر pino نصب نباشد)
    // در هر دو حالت، نباید console.default باشد
    expect(logger).toBeDefined();
  });
});
