// ============================================================
// YIO V8 — Rule Engine Tests
// ============================================================

import { describe, it, expect, beforeEach } from 'vitest';
import {
  RuleRegistry,
  RuleEngine,
  ORDER_RULES,
  ACCOUNTING_RULES,
  registerAllDefaultRules,
  BaseRule,
  rulePass,
  ruleFail,
} from '../src/index';
import { Context, IRuleContext, IRuleResult } from '@yio/core';

let registry: RuleRegistry;
let engine: RuleEngine;
const ctx: Context = { tenantId: 1, userId: 1 };

beforeEach(() => {
  registry = new RuleRegistry();
  registerAllDefaultRules(registry);
  // Mock prisma برای Rule Engine (Dynamic Rules)
  engine = new RuleEngine(
    { siteSetting: { findMany: async () => [] } } as any,
    registry,
  );
});

describe('RuleRegistry (V8)', () => {
  it('should register a rule', () => {
    const initialCount = registry.list().length;
    class CustomRule extends BaseRule {
      readonly name = 'test.custom';
      readonly appliesTo = 'test.action';
      readonly priority = 100;
      async evaluate() { return rulePass(); }
    }
    registry.register(new CustomRule());
    expect(registry.list().length).toBe(initialCount + 1);
  });

  it('should not allow duplicate rule names', () => {
    class Rule1 extends BaseRule {
      readonly name = 'test.duplicate';
      readonly appliesTo = 'test';
      async evaluate() { return rulePass(); }
    }
    class Rule2 extends BaseRule {
      readonly name = 'test.duplicate';
      readonly appliesTo = 'test';
      async evaluate() { return rulePass(); }
    }
    registry.register(new Rule1());
    expect(() => registry.register(new Rule2())).toThrow();
  });

  it('should return rules sorted by priority', () => {
    const rules = registry.getRulesForAction('order.create', ctx);
    expect(rules.length).toBeGreaterThan(0);
    for (let i = 0; i < rules.length - 1; i++) {
      expect(rules[i].priority).toBeLessThanOrEqual(rules[i + 1].priority);
    }
  });

  it('should unregister a rule', () => {
    const countBefore = registry.list().length;
    const firstName = registry.list()[0].name;
    registry.unregister(firstName);
    expect(registry.list().length).toBe(countBefore - 1);
  });
});

describe('RuleEngine (V8)', () => {
  it('should pass when all rules pass', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 5 }],
        totalAmount: 200000,
      },
      ctx,
    );
    expect(result.success).toBe(true);
  });

  it('should fail when MaxOrderQuantityRule rejects (qty > 99)', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 150 }],
        totalAmount: 200000,
      },
      ctx,
    );
    // engine در خودش quantity را با Math.min(99) محدود می‌کند،
    // اما Rule مستقل است و اگر qty > 99 باشد باید fail کند
    expect(result.success).toBe(false);
    expect(result.message).toContain('۹۹');
  });

  it('should fail when MinimumOrderAmountRule rejects (amount < 100k)', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 1 }],
        totalAmount: 50000, // زیر حداقل برای tenant=1
      },
      { ...ctx, tenantId: 1 },
    );
    expect(result.success).toBe(false);
    expect(result.message).toContain('حداقل مبلغ سفارش');
  });

  it('should fail when customer is blacklisted', async () => {
    const result = await engine.validate(
      'order.create',
      {
        items: [{ productId: 1, quantity: 2 }],
        totalAmount: 200000,
        customerIsBlacklisted: true,
      },
      ctx,
    );
    expect(result.success).toBe(false);
    expect(result.message).toContain('لیست سیاه');
  });

  it('should evaluate accounting balanced entry rule', async () => {
    const result = await engine.validate(
      'accounting.create_entry',
      {
        lines: [
          { account: '1001', type: 'debit', amount: 1000 },
          { account: '4001', type: 'credit', amount: 1000 },
        ],
      },
      ctx,
    );
    expect(result.success).toBe(true);
  });

  it('should reject unbalanced accounting entry', async () => {
    const result = await engine.validate(
      'accounting.create_entry',
      {
        lines: [
          { account: '1001', type: 'debit', amount: 1000 },
          { account: '4001', type: 'credit', amount: 500 },
        ],
      },
      ctx,
    );
    expect(result.success).toBe(false);
    expect(result.message).toContain('سند متوازن نیست');
  });
});

describe('Order Rules', () => {
  it('should have all expected order rules', () => {
    expect(ORDER_RULES.length).toBeGreaterThanOrEqual(5);
    const names = ORDER_RULES.map((r) => r.name);
    expect(names).toContain('order.max_quantity');
    expect(names).toContain('order.minimum_amount');
    expect(names).toContain('order.working_hours');
    expect(names).toContain('order.wholesale_discount');
    expect(names).toContain('order.blacklisted_customer');
  });
});

describe('Accounting Rules', () => {
  it('should have balanced entry and negative amount rules', () => {
    expect(ACCOUNTING_RULES.length).toBeGreaterThanOrEqual(2);
    const names = ACCOUNTING_RULES.map((r) => r.name);
    expect(names).toContain('accounting.balanced_entry');
    expect(names).toContain('accounting.negative_amount');
  });
});
