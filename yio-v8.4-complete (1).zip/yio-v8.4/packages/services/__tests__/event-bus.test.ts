// ============================================================
// YIO V8 — EventBus + EventStore Tests
// ============================================================

import { describe, it, expect, beforeEach } from 'vitest';
import { InMemoryEventBus } from '../src/event-bus/event-bus';
import { PrismaEventStore, PrismaEventStoreRepository } from '../src/event-store/prisma-event-store';
import {
  Events,
  OrderCreatedEvent,
  OrderCancelledEvent,
  Context,
} from '@yio/core';

let bus: InMemoryEventBus;

beforeEach(() => {
  bus = new InMemoryEventBus();
});

describe('InMemoryEventBus (V8 — Typed)', () => {
  it('should publish and receive events', async () => {
    let received: OrderCreatedEvent | null = null;
    bus.subscribe(Events.OrderCreated, async (e: OrderCreatedEvent) => {
      received = e;
    });

    const event = new OrderCreatedEvent(1, 100, 500000, 1);
    await bus.publish(event);

    expect(received).not.toBeNull();
    expect(received!.orderId).toBe(1);
    expect(received!.customerId).toBe(100);
    expect(received!.totalAmount).toBe(500000);
  });

  it('should support multiple handlers per event', async () => {
    let count = 0;
    bus.subscribe(Events.OrderCreated, async () => { count++; });
    bus.subscribe(Events.OrderCreated, async () => { count++; });

    await bus.publish(new OrderCreatedEvent(1, 100, 500000, 1));
    expect(count).toBe(2);
  });

  it('should not fail if no handlers registered', async () => {
    // این نباید throw کند
    await bus.publish(new OrderCancelledEvent(999, 'test', 1));
  });

  it('should handle handler errors gracefully', async () => {
    let goodHandlerCalled = false;
    bus.subscribe(Events.OrderCreated, async () => {
      throw new Error('handler failure');
    });
    bus.subscribe(Events.OrderCreated, async () => {
      goodHandlerCalled = true;
    });

    await bus.publish(new OrderCreatedEvent(1, 100, 500000, 1));
    // handler دوم باید اجرا شود حتی اگر اولی fail شود
    expect(goodHandlerCalled).toBe(true);
  });

  it('should unsubscribe handler', async () => {
    let count = 0;
    const handler = async () => { count++; };
    bus.subscribe(Events.OrderCreated, handler);
    bus.unsubscribe(Events.OrderCreated, handler);

    await bus.publish(new OrderCreatedEvent(1, 100, 500000, 1));
    expect(count).toBe(0);
  });

  it('should keep recent events log', async () => {
    await bus.publish(new OrderCreatedEvent(1, 100, 500000, 1));
    await bus.publish(new OrderCancelledEvent(1, 'test', 1));

    const recent = bus.getRecentEvents(5);
    expect(recent.length).toBe(2);
  });

  it('should list subscriptions', async () => {
    bus.subscribe(Events.OrderCreated, async () => {});
    bus.subscribe(Events.OrderCreated, async () => {});
    bus.subscribe(Events.OrderCancelled, async () => {});

    const subs = bus.getSubscriptions();
    expect(subs.get(Events.OrderCreated)).toBe(2);
    expect(subs.get(Events.OrderCancelled)).toBe(1);
  });
});

describe('EventStore Integration', () => {
  it('should append events to EventStore', async () => {
    // استفاده از InMemory fallback (بدون Prisma)
    const repo = new PrismaEventStoreRepository({} as any);
    const store = new PrismaEventStore(repo);

    bus.attachEventStore(store);

    await bus.publish(new OrderCreatedEvent(1, 100, 500000, 1));

    const ctx: Context = { tenantId: 1 };
    const events = await store.getByAggregate('Order', 1, ctx);
    expect(events.length).toBe(1);
    expect(events[0].eventName).toBe(Events.OrderCreated);
  });

  it('should preserve event type on deserialization', async () => {
    const repo = new PrismaEventStoreRepository({} as any);
    const store = new PrismaEventStore(repo);

    await store.append(new OrderCreatedEvent(42, 100, 500000, 1));

    const ctx: Context = { tenantId: 1 };
    const events = await store.getByAggregate('Order', 42, ctx);
    expect(events.length).toBe(1);
    expect(events[0]).toBeInstanceOf(OrderCreatedEvent);
    expect((events[0] as OrderCreatedEvent).orderId).toBe(42);
  });
});
