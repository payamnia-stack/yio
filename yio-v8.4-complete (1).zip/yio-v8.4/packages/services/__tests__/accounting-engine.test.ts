// ============================================================
// YIO V8 — Accounting Engine Tests
// ============================================================

import { describe, it, expect, beforeEach } from 'vitest';
import { AccountingEngine, ACCOUNT_TYPES, DEFAULT_ACCOUNTS } from '../src/engines/accounting-engine';
import { InMemoryEventBus } from '../src/event-bus/event-bus';
import { Context, Events } from '@yio/core';

const ctx: Context = { tenantId: 1, userId: 1 };

describe('Accounting Engine (V8)', () => {
  describe('Account Types', () => {
    it('should define all 5 account types', () => {
      expect(ACCOUNT_TYPES.ASSET).toBe('asset');
      expect(ACCOUNT_TYPES.LIABILITY).toBe('liability');
      expect(ACCOUNT_TYPES.EQUITY).toBe('equity');
      expect(ACCOUNT_TYPES.REVENUE).toBe('revenue');
      expect(ACCOUNT_TYPES.EXPENSE).toBe('expense');
    });
  });

  describe('Default Chart of Accounts', () => {
    it('should define cash account', () => {
      expect(DEFAULT_ACCOUNTS.cash.code).toBe('1001');
      expect(DEFAULT_ACCOUNTS.cash.type).toBe(ACCOUNT_TYPES.ASSET);
    });

    it('should define sales revenue account', () => {
      expect(DEFAULT_ACCOUNTS.sales_revenue.code).toBe('4001');
      expect(DEFAULT_ACCOUNTS.sales_revenue.type).toBe(ACCOUNT_TYPES.REVENUE);
    });

    it('should define accounts payable', () => {
      expect(DEFAULT_ACCOUNTS.accounts_payable.code).toBe('2010');
      expect(DEFAULT_ACCOUNTS.accounts_payable.type).toBe(ACCOUNT_TYPES.LIABILITY);
    });

    it('should define all expense accounts', () => {
      expect(DEFAULT_ACCOUNTS.cogs.code).toBe('5001');
      expect(DEFAULT_ACCOUNTS.material_expense.code).toBe('5010');
      expect(DEFAULT_ACCOUNTS.labor_expense.code).toBe('5020');
      expect(DEFAULT_ACCOUNTS.salary_expense.code).toBe('5090');
    });
  });
});

describe('Accounting Event Subscriptions', () => {
  it('should subscribe to order.delivered event (typed)', () => {
    // این تست فقط تأیید می‌کند که AccountingEngine بدون خطا instantiate می‌شود
    // و به درستی subscribe می‌کند.
    const prismaMock: any = {
      accountingEntry: { create: async () => ({}), findMany: async () => [] },
      $transaction: async (fn: any) => fn({}),
    };
    const eventBus = new InMemoryEventBus();
    const engine = new AccountingEngine(prismaMock, eventBus);

    // AccountingEngine باید به Events.OrderDelivered, Events.OrderCancelled و ... subscribe کرده باشد
    const subs = eventBus.getSubscriptions();
    expect(subs.get(Events.OrderDelivered)).toBeGreaterThanOrEqual(1);
    expect(subs.get(Events.OrderCancelled)).toBeGreaterThanOrEqual(1);
    expect(subs.get(Events.PurchaseOrderReceived)).toBeGreaterThanOrEqual(1);
    expect(subs.get(Events.ProductionCompleted)).toBeGreaterThanOrEqual(1);
  });
});
