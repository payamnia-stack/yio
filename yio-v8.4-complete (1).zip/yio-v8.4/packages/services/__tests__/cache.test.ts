// ============================================================
// YIO V8 — Cache Layer Tests
// ============================================================

import { describe, it, expect, beforeEach } from 'vitest';
import { InMemoryCache } from '../src/cache/cache';

let cache: InMemoryCache;

beforeEach(() => {
  cache = new InMemoryCache(100);
});

describe('InMemoryCache (V8)', () => {
  it('should set and get a value', async () => {
    await cache.set('key1', { name: 'YIO' });
    const value = await cache.get<{ name: string }>('key1');
    expect(value).toEqual({ name: 'YIO' });
  });

  it('should return null for missing key', async () => {
    const value = await cache.get('nonexistent');
    expect(value).toBeNull();
  });

  it('should respect TTL', async () => {
    await cache.set('temp', 'value', 1); // 1 second TTL
    expect(await cache.get('temp')).toBe('value');
    // wait 1.1 seconds
    await new Promise((resolve) => setTimeout(resolve, 1100));
    expect(await cache.get('temp')).toBeNull();
  });

  it('should delete a key', async () => {
    await cache.set('delete-me', 'value');
    await cache.delete('delete-me');
    expect(await cache.get('delete-me')).toBeNull();
  });

  it('should invalidate by pattern', async () => {
    await cache.set('products:1', 'a');
    await cache.set('products:2', 'b');
    await cache.set('orders:1', 'c');
    await cache.invalidate('products:*');
    expect(await cache.get('products:1')).toBeNull();
    expect(await cache.get('products:2')).toBeNull();
    expect(await cache.get('orders:1')).toBe('c');
  });

  it('should use getOrSet on cache miss', async () => {
    let factoryCalled = 0;
    const result1 = await cache.getOrSet('compute-me', 60, async () => {
      factoryCalled++;
      return { computed: true };
    });
    expect(result1).toEqual({ computed: true });
    expect(factoryCalled).toBe(1);

    // دومین بار نباید factory فراخوانی شود
    const result2 = await cache.getOrSet('compute-me', 60, async () => {
      factoryCalled++;
      return { computed: true };
    });
    expect(factoryCalled).toBe(1);
  });

  it('should evict LRU when over capacity', async () => {
    const smallCache = new InMemoryCache(2);
    await smallCache.set('a', 1);
    await smallCache.set('b', 2);
    // access 'a' to update lastAccessed
    await smallCache.get('a');
    // insert 'c' — should evict 'b' (least recently used)
    await smallCache.set('c', 3);
    expect(await smallCache.get('a')).toBe(1);
    expect(await smallCache.get('b')).toBeNull();
    expect(await smallCache.get('c')).toBe(3);
  });

  it('should flush all keys', async () => {
    await cache.set('a', 1);
    await cache.set('b', 2);
    await cache.flush();
    expect(await cache.get('a')).toBeNull();
    expect(await cache.get('b')).toBeNull();
  });
});
