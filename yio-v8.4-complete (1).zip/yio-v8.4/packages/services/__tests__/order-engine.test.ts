// ============================================================
// YIO V8 — OrderEngine Unit Tests
// ============================================================
// این تست‌ها با vitest یا jest اجرا می‌شوند.
// برای اجرا: npx vitest run
// یا: npx jest
// ============================================================

import { describe, it, expect, beforeEach, vi } from 'vitest';
import {
  OrderEngine,
  InMemoryEventBus,
  RuleRegistry,
  RuleEngine,
  AuditLogger,
  PrismaAuditLogRepository,
  registerAllDefaultRules,
} from '../src/index';
import {
  Context,
  Events,
  OrderCreatedEvent,
  IOrderRepository,
  IProductRepository,
  IInventoryRepository,
  ITransactionManager,
  ITransactionContext,
  DomainEvent,
  AuditEntry,
  PaginatedResult,
  BusinessError,
} from '@yio/core';

// ============================================================
// Mock Implementations (In-Memory)
// ============================================================
// این mockها برای تست بدون نیاز به دیتابیس واقعی استفاده می‌شوند.

class MockOrderRepository implements IOrderRepository {
  public orders: Map<number, any> = new Map();
  private nextId = 1;

  async findById(id: number, _ctx: Context) {
    return this.orders.get(id) || null;
  }
  async findMany(_opts: any, _ctx: Context): Promise<PaginatedResult<any>> {
    return { data: Array.from(this.orders.values()), pagination: { page: 1, pageSize: 10, total: this.orders.size, totalPages: 1 } };
  }
  async create(data: any, ctx: Context) {
    const id = this.nextId++;
    const order = { ...data, id, tenantId: ctx.tenantId, createdAt: new Date(), updatedAt: new Date() };
    this.orders.set(id, order);
    return order;
  }
  async update(id: number, data: any, _ctx: Context) {
    const order = this.orders.get(id);
    if (!order) throw new Error('Order not found');
    Object.assign(order, data);
    return order;
  }
  async softDelete(id: number, _ctx: Context) {
    this.orders.delete(id);
  }
  async count(_where: any, _ctx: Context) {
    return this.orders.size;
  }
  async findByStatus(status: string, ctx: Context, page = 1, pageSize = 10) {
    const data = Array.from(this.orders.values()).filter((o) => o.status === status);
    return { data, pagination: { page, pageSize, total: data.length, totalPages: 1 } };
  }
  async findUserOrders(userId: number, _ctx: Context) {
    return Array.from(this.orders.values()).filter((o) => o.userId === userId);
  }
  async updateStatus(id: number, status: string, _ctx: Context) {
    const order = this.orders.get(id);
    if (order) order.status = status;
  }
  async updateTracking(id: number, trackingCode: string, _ctx: Context) {
    const order = this.orders.get(id);
    if (order) {
      order.trackingCode = trackingCode;
      order.status = 'shipping';
    }
  }
  async generateOrderNumber(_ctx: Context) {
    return `YIO-TEST-${this.nextId}`;
  }
  async createWithItems(order: any, items: any[], ctx: Context, _tx?: ITransactionContext) {
    const id = this.nextId++;
    const fullOrder = { ...order, id, tenantId: ctx.tenantId };
    this.orders.set(id, { ...fullOrder, items });
    return { id, orderNumber: order.orderNumber };
  }
}

class MockProductRepository implements IProductRepository {
  public products: Map<number, any> = new Map();
  async findById(id: number, _ctx: Context) {
    return this.products.get(id) || null;
  }
  async findMany(_opts: any, _ctx: Context): Promise<PaginatedResult<any>> {
    return { data: Array.from(this.products.values()), pagination: { page: 1, pageSize: 10, total: 0, totalPages: 1 } };
  }
  async create(data: any, ctx: Context) {
    const id = (this.products.size || 0) + 1;
    const p = { ...data, id, tenantId: ctx.tenantId };
    this.products.set(id, p);
    return p;
  }
  async update(id: number, data: any, _ctx: Context) {
    const p = this.products.get(id);
    if (p) Object.assign(p, data);
    return p;
  }
  async softDelete(id: number, _ctx: Context) {
    this.products.delete(id);
  }
  async count(_where: any, _ctx: Context) {
    return this.products.size;
  }
  async findPublished(_ctx: Context, _opts?: any) {
    return { data: Array.from(this.products.values()).filter((p) => p.isPublished), pagination: { page: 1, pageSize: 10, total: 0, totalPages: 1 } };
  }
  async publish(id: number, _ctx: Context) {
    const p = this.products.get(id);
    if (p) { p.isPublished = true; p.publishedAt = new Date(); }
  }
  async unpublish(id: number, _ctx: Context) {
    const p = this.products.get(id);
    if (p) { p.isPublished = false; p.publishedAt = null; }
  }
  async updateStock(id: number, delta: number, _ctx: Context) {
    const p = this.products.get(id);
    if (p) {
      p.stockQuantity += delta;
      p.inStock = p.stockQuantity > 0;
      return p.stockQuantity;
    }
    return 0;
  }
  async reserveStock(items: any[], _ctx: Context, _tx?: ITransactionContext) {
    for (const item of items) {
      const p = this.products.get(item.productId);
      if (!p || p.stockQuantity < item.quantity) {
        throw new Error('Insufficient stock');
      }
      p.stockQuantity -= item.quantity;
    }
  }
  async releaseStock(items: any[], _ctx: Context, _tx?: ITransactionContext) {
    for (const item of items) {
      const p = this.products.get(item.productId);
      if (p) p.stockQuantity += item.quantity;
    }
  }
}

class MockInventoryRepository implements IInventoryRepository {
  public transactions: any[] = [];
  async getStock(_itemType: string, _itemId: number, _ctx: Context) {
    return 0;
  }
  async adjustStock(_itemType: string, _itemId: number, delta: number, _ctx: Context) {
    return delta;
  }
  async recordTransaction(tx: any, _ctx: Context) {
    this.transactions.push(tx);
  }
}

// ============================================================
// Mock Transaction Manager (Fake UoW)
// ============================================================
class MockTransactionManager implements ITransactionManager {
  public events: DomainEvent[] = [];
  public audits: AuditEntry[] = [];
  public committedCount = 0;
  public rolledBackCount = 0;

  create() {
    return {
      isActive: () => false,
      begin: async () => {},
      commit: async () => { this.committedCount++; },
      rollback: async () => { this.rolledBackCount++; },
      run: async <T>(fn: (tx: ITransactionContext) => Promise<T>): Promise<T> => {
        const ctx: ITransactionContext = {
          transactionId: `tx-${Date.now()}`,
          client: {},
          collectEvent: (e: DomainEvent) => { this.events.push(e); },
          collectAudit: (a: AuditEntry) => { this.audits.push(a); },
        };
        try {
          const result = await fn(ctx);
          this.committedCount++;
          // publish collected events
          return result;
        } catch (err) {
          this.rolledBackCount++;
          throw err;
        }
      },
    } as any;
  }

  async run<T>(fn: (tx: ITransactionContext) => Promise<T>): Promise<T> {
    return this.create().run(fn);
  }
}

// ============================================================
// Test Setup
// ============================================================
let engine: OrderEngine;
let orderRepo: MockOrderRepository;
let productRepo: MockProductRepository;
let inventoryRepo: MockInventoryRepository;
let eventBus: InMemoryEventBus;
let txManager: MockTransactionManager;
let ruleEngine: RuleEngine;
let auditLogger: AuditLogger;

const ctx: Context = {
  tenantId: 1,
  userId: 10,
  userRole: 'customer',
  permissions: ['order.create', 'order.view'],
  ip: '127.0.0.1',
  userAgent: 'test-agent',
  requestId: 'req-1',
};

beforeEach(() => {
  orderRepo = new MockOrderRepository();
  productRepo = new MockProductRepository();
  inventoryRepo = new MockInventoryRepository();
  eventBus = new InMemoryEventBus();
  txManager = new MockTransactionManager();

  const ruleRegistry = new RuleRegistry();
  registerAllDefaultRules(ruleRegistry);
  // RuleEngine نیاز به prisma دارد، اما برای تست mock می‌کنیم
  ruleEngine = new RuleEngine({ siteSetting: { findMany: async () => [] } } as any, ruleRegistry);

  // Audit Logger با fallback InMemory
  auditLogger = new AuditLogger({
    append: async (e: any) => {},
    query: async () => ({ data: [], pagination: { page: 1, pageSize: 10, total: 0, totalPages: 1 } }),
  } as any);

  engine = new OrderEngine(
    orderRepo,
    productRepo,
    inventoryRepo,
    eventBus,
    txManager,
    ruleEngine,
    auditLogger,
    console,
  );

  // seed یک محصول برای تست
  productRepo.products.set(1, {
    id: 1,
    title: 'میز چوبی',
    price: 100000,
    discountPrice: null,
    stockQuantity: 10,
    inStock: true,
    image: 'test.jpg',
    tenantId: 1,
  });
});

// ============================================================
// Tests
// ============================================================
describe('OrderEngine (V8)', () => {
  describe('createOrder', () => {
    it('should create an order successfully', async () => {
      const result = await engine.createOrder(
        {
          userId: 10,
          items: [{ productId: 1, quantity: 2 }],
          shippingAddress: 'Tehran',
          recipientName: 'Ali',
          recipientPhone: '09120000000',
          paymentMethod: 'cod',
        },
        ctx,
      );

      expect(result.orderId).toBeGreaterThan(0);
      expect(result.orderNumber).toMatch(/^YIO-TEST-\d+$/);

      // تراکنش باید یک بار commit شده باشد
      expect(txManager.committedCount).toBe(1);

      // Event باید جمع‌آوری شده باشد
      expect(txManager.events.length).toBe(1);
      expect(txManager.events[0].eventName).toBe(Events.OrderCreated);

      // Audit entry باید ثبت شده باشد
      expect(txManager.audits.length).toBe(1);
      expect(txManager.audits[0].action).toBe('order.create');

      // موجودی باید رزرو شده باشد (کاهش یابد)
      const product = productRepo.products.get(1)!;
      expect(product.stockQuantity).toBe(8);
    });

    it('should reject empty items', async () => {
      await expect(
        engine.createOrder(
          {
            userId: 10,
            items: [],
            shippingAddress: 'Tehran',
            recipientName: 'Ali',
            recipientPhone: '09120000000',
            paymentMethod: 'cod',
          },
          ctx,
        ),
      ).rejects.toThrow(BusinessError);
    });

    it('should reject when product not found', async () => {
      await expect(
        engine.createOrder(
          {
            userId: 10,
            items: [{ productId: 999, quantity: 1 }],
            shippingAddress: 'Tehran',
            recipientName: 'Ali',
            recipientPhone: '09120000000',
            paymentMethod: 'cod',
          },
          ctx,
        ),
      ).rejects.toThrow('محصول مورد نظر موجود نیست');
    });

    it('should reject when quantity exceeds stock', async () => {
      await expect(
        engine.createOrder(
          {
            userId: 10,
            items: [{ productId: 1, quantity: 100 }],
            shippingAddress: 'Tehran',
            recipientName: 'Ali',
            recipientPhone: '09120000000',
            paymentMethod: 'cod',
          },
          ctx,
        ),
      ).rejects.toThrow('موجودی محصول');
    });

    it('should respect MaxOrderQuantityRule (qty > 99)', async () => {
      // محصول با موجودی زیاد برای تست Rule
      productRepo.products.set(2, {
        id: 2,
        title: 'صندلی',
        price: 100000,
        discountPrice: null,
        stockQuantity: 200,
        inStock: true,
        image: 'chair.jpg',
        tenantId: 1,
      });

      // qty=100 → باید توسط MaxOrderQuantityRule رد شود
      // (با min(99) در engine، qty به 99 تبدیل می‌شود؛ پس برای تست واقعی qty باید در Rule بررسی شود)
      // در نسخه فعلی engine، qty با Math.min(99) محدود می‌شود، پس Rule همیشه pass می‌شود
      // این تست صرفاً نشان می‌دهد که Rule Engine فراخوانی می‌شود
      const result = await engine.createOrder(
        {
          userId: 10,
          items: [{ productId: 2, quantity: 150 }], // → تبدیل به 99
          shippingAddress: 'Tehran',
          recipientName: 'Ali',
          recipientPhone: '09120000000',
          paymentMethod: 'cod',
        },
        ctx,
      );
      expect(result.orderId).toBeGreaterThan(0);
    });
  });

  describe('confirmOrder', () => {
    it('should confirm a pending order', async () => {
      const created = await engine.createOrder(
        {
          userId: 10,
          items: [{ productId: 1, quantity: 1 }],
          shippingAddress: 'Tehran',
          recipientName: 'Ali',
          recipientPhone: '09120000000',
          paymentMethod: 'cod',
        },
        ctx,
      );

      const result = await engine.confirmOrder(created.orderId, ctx);
      expect(result.success).toBe(true);

      const order = await orderRepo.findById(created.orderId, ctx);
      expect(order.status).toBe('confirmed');

      // Audit entry باید ثبت شده باشد
      const confirmAudits = txManager.audits.filter((a) => a.action === 'order.confirm');
      expect(confirmAudits.length).toBe(1);
      expect(confirmAudits[0].changes?.status?.new).toBe('confirmed');
    });

    it('should reject confirming non-pending order', async () => {
      // ابتدا سفارش را confirmed کن
      const created = await engine.createOrder(
        {
          userId: 10,
          items: [{ productId: 1, quantity: 1 }],
          shippingAddress: 'Tehran',
          recipientName: 'Ali',
          recipientPhone: '09120000000',
          paymentMethod: 'cod',
        },
        ctx,
      );
      await engine.confirmOrder(created.orderId, ctx);

      // حالا تلاش برای confirm دوباره → باید fail شود
      await expect(engine.confirmOrder(created.orderId, ctx)).rejects.toThrow(
        'سفارش در وضعیت مناسبی برای تأیید نیست',
      );
    });
  });

  describe('cancelOrder', () => {
    it('should cancel a pending order', async () => {
      const created = await engine.createOrder(
        {
          userId: 10,
          items: [{ productId: 1, quantity: 1 }],
          shippingAddress: 'Tehran',
          recipientName: 'Ali',
          recipientPhone: '09120000000',
          paymentMethod: 'cod',
        },
        ctx,
      );

      const result = await engine.cancelOrder(created.orderId, 'تست لغو', ctx);
      expect(result.success).toBe(true);

      const order = await orderRepo.findById(created.orderId, ctx);
      expect(order.status).toBe('cancelled');
    });

    it('should not cancel a delivered order', async () => {
      const created = await engine.createOrder(
        {
          userId: 10,
          items: [{ productId: 1, quantity: 1 }],
          shippingAddress: 'Tehran',
          recipientName: 'Ali',
          recipientPhone: '09120000000',
          paymentMethod: 'cod',
        },
        ctx,
      );
      // تحویل دادن سفارش
      await engine.confirmOrder(created.orderId, ctx);
      await engine.deliverOrder(created.orderId, ctx);

      await expect(
        engine.cancelOrder(created.orderId, 'تست', ctx),
      ).rejects.toThrow('امکان لغو این سفارش وجود ندارد');
    });
  });

  describe('payOrder', () => {
    it('should mark order as paid', async () => {
      const created = await engine.createOrder(
        {
          userId: 10,
          items: [{ productId: 1, quantity: 1 }],
          shippingAddress: 'Tehran',
          recipientName: 'Ali',
          recipientPhone: '09120000000',
          paymentMethod: 'cod',
        },
        ctx,
      );

      const result = await engine.payOrder(created.orderId, 100000, 'online', ctx);
      expect(result.success).toBe(true);

      const order = await orderRepo.findById(created.orderId, ctx);
      expect(order.paymentStatus).toBe('paid');
    });
  });

  describe('Event Bus Integration', () => {
    it('should publish OrderCreated event after commit', async () => {
      // ثبت یک handler برای تست
      let receivedEvent: OrderCreatedEvent | null = null;
      eventBus.subscribe(Events.OrderCreated, async (event: OrderCreatedEvent) => {
        receivedEvent = event;
      });

      const result = await engine.createOrder(
        {
          userId: 10,
          items: [{ productId: 1, quantity: 2 }],
          shippingAddress: 'Tehran',
          recipientName: 'Ali',
          recipientPhone: '09120000000',
          paymentMethod: 'cod',
        },
        ctx,
      );

      // در mock txManager، eventها در txManager.events جمع می‌شوند
      // اما در real implementation، publish در TransactionManager.run اتفاق می‌افتد
      expect(txManager.events[0].eventName).toBe(Events.OrderCreated);
      expect((txManager.events[0] as OrderCreatedEvent).orderId).toBe(result.orderId);
    });
  });

  describe('Audit Trail', () => {
    it('should generate audit entry on create', async () => {
      await engine.createOrder(
        {
          userId: 10,
          items: [{ productId: 1, quantity: 2 }],
          shippingAddress: 'Tehran',
          recipientName: 'Ali',
          recipientPhone: '09120000000',
          paymentMethod: 'cod',
        },
        ctx,
      );

      const audit = txManager.audits.find((a) => a.action === 'order.create');
      expect(audit).toBeDefined();
      expect(audit?.userId).toBe(10);
      expect(audit?.ip).toBe('127.0.0.1');
      expect(audit?.userAgent).toBe('test-agent');
      expect(audit?.operation).toBe('create');
    });
  });
});
