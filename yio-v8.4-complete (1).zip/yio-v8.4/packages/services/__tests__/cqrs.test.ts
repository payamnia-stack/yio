// ============================================================
// YIO V8 — CQRS Tests
// ============================================================

import { describe, it, expect, beforeEach } from 'vitest';
import {
  CommandBus,
  QueryBus,
  OrderCommandHandlers,
  OrderQueryHandlers,
  CreateOrderCommand,
  ConfirmOrderCommand,
  ShipOrderCommand,
  CancelOrderCommand,
  DeliverOrderCommand,
  PayOrderCommand,
  GetOrderByIdQuery,
  ListOrdersQuery,
  GetUserOrdersQuery,
  GetOrderStatsQuery,
  SearchOrdersQuery,
} from '../src/cqrs';
import { Container } from '../src/di/container';
import {
  ok,
  fail,
  TOKENS,
  Context,
  IOrderRepository,
  BaseCommand,
  BaseQuery,
} from '@yio/core';

let commandBus: CommandBus;
let queryBus: QueryBus;

const ctx: Context = {
  tenantId: 1,
  userId: 10,
  permissions: ['order.create'],
};

beforeEach(() => {
  commandBus = new CommandBus();
  queryBus = new QueryBus();
});

describe('CommandBus (V8)', () => {
  it('should register and execute a command', async () => {
    commandBus.register('TestCommand', async (cmd, _ctx) => {
      return ok({ echo: (cmd as any).payload });
    });

    class TestCommand extends BaseCommand {
      readonly commandName = 'TestCommand';
      constructor(public readonly payload: string) { super(); }
    }

    const result = await commandBus.execute(new TestCommand('hello'), ctx);
    expect(result.success).toBe(true);
    expect(result.data.echo).toBe('hello');
  });

  it('should fail when no handler registered', async () => {
    class UnknownCommand extends BaseCommand {
      readonly commandName = 'UnknownCommand';
    }
    const result = await commandBus.execute(new UnknownCommand(), ctx);
    expect(result.success).toBe(false);
    expect(result.message).toContain('No handler');
  });

  it('should catch handler errors and return failure', async () => {
    commandBus.register('FailingCommand', async () => {
      throw new Error('handler crashed');
    });

    class FailingCommand extends BaseCommand {
      readonly commandName = 'FailingCommand';
    }

    const result = await commandBus.execute(new FailingCommand(), ctx);
    expect(result.success).toBe(false);
    expect(result.message).toBe('handler crashed');
  });

  it('should warn on slow commands (>500ms)', async () => {
    const originalWarn = console.warn;
    let warned = false;
    console.warn = (...args: any[]) => {
      if (args[0]?.includes?.('Slow command')) warned = true;
    };

    commandBus.register('SlowCommand', async () => {
      await new Promise((r) => setTimeout(r, 600));
      return ok();
    });

    class SlowCommand extends BaseCommand {
      readonly commandName = 'SlowCommand';
    }

    await commandBus.execute(new SlowCommand(), ctx);
    expect(warned).toBe(true);
    console.warn = originalWarn;
  });

  it('should list registered commands', () => {
    commandBus.register('Cmd1', async () => ok());
    commandBus.register('Cmd2', async () => ok());
    expect(commandBus.list()).toEqual(['Cmd1', 'Cmd2']);
  });
});

describe('QueryBus (V8)', () => {
  it('should register and execute a query', async () => {
    queryBus.register('TestQuery', async () => {
      return { data: [1, 2, 3] };
    });

    class TestQuery extends BaseQuery {
      readonly queryName = 'TestQuery';
    }

    const result = await queryBus.execute(new TestQuery(), ctx);
    expect(result.data).toEqual([1, 2, 3]);
  });

  it('should throw when no handler registered', async () => {
    class UnknownQuery extends BaseQuery {
      readonly queryName = 'UnknownQuery';
    }
    await expect(queryBus.execute(new UnknownQuery(), ctx)).rejects.toThrow();
  });

  it('should cache query results', async () => {
    let callCount = 0;
    queryBus.register('CountedQuery', async () => {
      callCount++;
      return { count: callCount };
    });

    // Attach cache
    const { InMemoryCache } = await import('../src/cache/cache');
    const cache = new InMemoryCache();
    queryBus.attachCache(cache, 60);

    class CountedQuery extends BaseQuery {
      readonly queryName = 'CountedQuery';
    }

    const r1 = await queryBus.executeCached(new CountedQuery(), ctx);
    const r2 = await queryBus.executeCached(new CountedQuery(), ctx);
    expect(r1.count).toBe(1);
    expect(r2.count).toBe(1); // از cache خوانده شد
    expect(callCount).toBe(1);
  });

  it('should invalidate cache by query name', async () => {
    let callCount = 0;
    queryBus.register('InvalidatableQuery', async () => {
      callCount++;
      return { count: callCount };
    });

    const { InMemoryCache } = await import('../src/cache/cache');
    const cache = new InMemoryCache();
    queryBus.attachCache(cache, 60);

    class InvalidatableQuery extends BaseQuery {
      readonly queryName = 'InvalidatableQuery';
    }

    await queryBus.executeCached(new InvalidatableQuery(), ctx);
    await queryBus.executeCached(new InvalidatableQuery(), ctx);
    expect(callCount).toBe(1);

    await queryBus.invalidate('InvalidatableQuery', ctx);
    await queryBus.executeCached(new InvalidatableQuery(), ctx);
    expect(callCount).toBe(2);
  });

  it('should warn on slow queries (>1s)', async () => {
    const originalWarn = console.warn;
    let warned = false;
    console.warn = (...args: any[]) => {
      if (args[0]?.includes?.('Slow query')) warned = true;
    };

    queryBus.register('SlowQuery', async () => {
      await new Promise((r) => setTimeout(r, 1100));
      return {};
    });

    class SlowQuery extends BaseQuery {
      readonly queryName = 'SlowQuery';
    }
    await queryBus.execute(new SlowQuery(), ctx);
    expect(warned).toBe(true);
    console.warn = originalWarn;
  });
});

describe('Order Command/Query Handlers Integration', () => {
  it('should wire OrderCommandHandlers to OrderEngine via container', async () => {
    const container = new Container();

    // Mock OrderEngine — فقط createOrder دارد
    const mockEngine = {
      createOrder: async (input: any) => ({ orderId: 1, orderNumber: 'YIO-TEST' }),
    };
    container.bindInstance(TOKENS.OrderEngine, mockEngine);

    const handlers = new OrderCommandHandlers(container);
    commandBus.register('CreateOrderCommand', handlers.createOrder);

    const result = await commandBus.execute(
      new CreateOrderCommand({
        items: [{ productId: 1, quantity: 1 }],
        shippingAddress: 'Tehran',
        recipientName: 'Ali',
        recipientPhone: '09120000000',
        paymentMethod: 'cod',
      }),
      ctx,
    );

    expect(result.success).toBe(true);
    expect(result.data.orderNumber).toBe('YIO-TEST');
  });

  it('should wire OrderQueryHandlers to IOrderRepository via container', async () => {
    const container = new Container();

    const mockRepo: IOrderRepository = {
      findById: async (id: number) => ({ id, status: 'pending', items: [] }),
      findMany: async () => ({ data: [], pagination: { page: 1, pageSize: 10, total: 0, totalPages: 0 } }),
      create: async () => ({}),
      update: async () => ({}),
      softDelete: async () => {},
      count: async () => 0,
      findByStatus: async () => ({ data: [], pagination: { page: 1, pageSize: 10, total: 0, totalPages: 0 } }),
      findUserOrders: async () => [],
      updateStatus: async () => {},
      updateTracking: async () => {},
      generateOrderNumber: async () => 'YIO-1',
      createWithItems: async () => ({ id: 1, orderNumber: 'YIO-1' }),
    };
    container.bindInstance(TOKENS.OrderRepository, mockRepo);

    const handlers = new OrderQueryHandlers(container);
    queryBus.register('GetOrderByIdQuery', handlers.getOrderById);

    const result = await queryBus.execute(new GetOrderByIdQuery(123), ctx);
    expect(result.id).toBe(123);
    expect(result.status).toBe('pending');
  });
});
