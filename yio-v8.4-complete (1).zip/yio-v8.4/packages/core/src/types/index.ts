// ============================================================
// YIO V8.1 — Core Domain Types (Upgraded)
// ============================================================
// این فایل تمام تایپ‌های پایه سیستم را تعریف می‌کند.
// تمام پکیج‌های دیگر از این تایپ‌ها استفاده می‌کنند.
//
// در V8.1:
//   - MAX_PAGE_SIZE برای جلوگیری ازpageSize بزرگ
//   - sanitizePagination helper
//   - WhitelistedQueryOptions برای safe filtering
// ============================================================

// ===== BaseEntity =====
// تمام موجودیت‌ها از این پایه ارث‌بری می‌کنند
export interface BaseEntity {
  id: number;
  tenantId: number;
  createdAt: Date;
  updatedAt: Date;
  deletedAt?: Date | null;
}

// ===== Context =====
// در هر درخواست، این Context ساخته می‌شود و به همه سرویس‌ها پاس داده می‌شود
export interface Context {
  tenantId: number;
  userId?: number;
  userRole?: string;
  permissions?: string[];
  ip?: string;
  userAgent?: string;
  requestId?: string;
  branchId?: number;
  department?: string;
}

// ============================================================
// ===== Pagination (V8.1 — Cap'd) =====
// ============================================================

/** حداکثر تعداد آیتم در یک صفحه — جلوگیری از DOS با pageSize=100000 */
export const MAX_PAGE_SIZE: number = 100;

/** حداقل تعداد آیتم در یک صفحه */
export const MIN_PAGE_SIZE: number = 1;

/** حداکثر شماره صفحه — جلوگیری از skip بسیار بزرگ */
export const MAX_PAGE_NUMBER: number = 10000;

export interface PaginationParams {
  page: number;
  pageSize: number;
  sort?: string;
  order?: 'asc' | 'desc';
}

export interface PaginatedResult<T> {
  data: T[];
  pagination: {
    page: number;
    pageSize: number;
    total: number;
    totalPages: number;
  };
}

/**
 * Sanitize pagination parameters — جلوگیری از مقادیر غیرمجاز.
 * اگر page یا pageSize از حد مجاز بیشتر بود، به حداکثر محدود می‌شود.
 * این تابع در BaseRepository.findMany استفاده می‌شود.
 */
export function sanitizePagination(p?: Partial<PaginationParams>): Required<Pick<PaginationParams, 'page' | 'pageSize'>> & Pick<PaginationParams, 'sort' | 'order'> {
  const page = Math.max(1, Math.min(MAX_PAGE_NUMBER, Math.floor(p?.page ?? 1)));
  const pageSize = Math.max(MIN_PAGE_SIZE, Math.min(MAX_PAGE_SIZE, Math.floor(p?.pageSize ?? 10)));
  return {
    page,
    pageSize,
    sort: p?.sort,
    order: p?.order === 'asc' ? 'asc' : (p?.order === 'desc' ? 'desc' : undefined),
  };
}

// ============================================================
// ===== Query Options (V8.1 — Safe Filter) =====
// ============================================================

export interface QueryOptions {
  search?: string;
  /**
   * V8.1: این فیلترها قبل از اعمال باید توسط `allowedFilterFields()`
   * در هر Repository whitelist شوند. به‌صورت مستقیم به Prisma پاس داده
   * نمی‌شوند.
   */
  filters?: Record<string, any>;
  pagination?: PaginationParams;
  include?: string[];
}

/**
 * نتیجه‌ی sanitize شدن filters — فقط فیلدهای مجاز را دارد.
 */
export type SanitizedFilters = Record<string, any>;

// ===== Result Types =====
export type Result<T> =
  | { success: true; data: T }
  | { success: false; error: BusinessError };

export class BusinessError extends Error {
  constructor(
    message: string,
    public code: string = 'BUSINESS_ERROR',
    public field?: string,
    public statusCode: number = 400,
  ) {
    super(message);
    this.name = 'BusinessError';
  }
}

// ===== Operation Result =====
export interface OperationResult {
  success: boolean;
  message?: string;
  data?: any;
  warnings?: string[];
}

// ===== Audit =====
export interface AuditLogEntry {
  tenantId: number;
  userId: number;
  userRole?: string;
  action: string;
  entityType: string;
  entityId: number;
  operation?: 'create' | 'update' | 'delete' | 'read' | 'login' | 'logout' | 'export' | 'config';
  changes?: Record<string, { old: any; new: any }>;
  metadata?: Record<string, any>;
  ip?: string;
  userAgent?: string;
  requestId?: string;
  timestamp: Date;
}
