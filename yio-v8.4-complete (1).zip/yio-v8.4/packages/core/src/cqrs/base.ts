// ============================================================
// YIO V8.2 — CQRS Base Types
// ============================================================
// این فایل تایپ‌های پایه برای Commandها و Queryهای سیستم تعریف می‌کند.
// هر Command / Query در فایل خودش قرار می‌گیرد (commands/, queries/).
//
// V8.2 Fix: Context از '../types' import می‌شود (نه '../interfaces')
// چون interfaces/index.ts آن را re-export نمی‌کند.
// ============================================================

import { ICommand, IQuery, ICommandResult } from '../interfaces';
import { Context } from '../types';

// ----- Marker Base Classes -----
// این کلاس‌ها فقط برای راحتی استفاده هستند؛ می‌توان مستقیماً از
// اینترفیس‌ها هم استفاده کرد.

export abstract class BaseCommand implements ICommand {
  abstract readonly commandName: string;
}

export abstract class BaseQuery implements IQuery {
  abstract readonly queryName: string;
}

// ----- Result Helpers -----
export function ok(data?: any, message?: string): ICommandResult {
  return { success: true, data, message };
}

export function fail(message: string, data?: any): ICommandResult {
  return { success: false, message, data };
}

// ----- Handler Decorator (Metadata-based) -----
// این decoratorها فقط metadata را روی کلاس/متد می‌گذارند تا
// bootstrap بتواند handlerها را به‌صورت خودکار ثبت کند.

export function commandHandler(commandName: string) {
  return function (target: any, _propertyKey: string, descriptor: PropertyDescriptor) {
    if (!target.constructor.__commandHandlers) {
      target.constructor.__commandHandlers = [];
    }
    target.constructor.__commandHandlers.push({
      commandName,
      method: descriptor.value,
    });
  };
}

export function queryHandler(queryName: string) {
  return function (target: any, _propertyKey: string, descriptor: PropertyDescriptor) {
    if (!target.constructor.__queryHandlers) {
      target.constructor.__queryHandlers = [];
    }
    target.constructor.__queryHandlers.push({
      queryName,
      method: descriptor.value,
    });
  };
}
