// ============================================================
// YIO V8.2 — Core Interfaces (Upgraded — all tx-aware)
// ============================================================
// اینترفیس‌های پایه که Repositoryها، Engineها و Serviceها از آنها
// استفاده می‌کنند. در V8 چندین اینترفیس جدید اضافه شده است:
//   - IUnitOfWork / ITransactionManager
//   - IEventStore
//   - IAuditLogger
//   - ICache (بهبودیافته)
//   - ICommandBus / IQueryBus  (CQRS)
//   - IContainer (DI)
//   - IRepository<T>  (به‌جای وابستگی مستقیم به کلاس)
//   - IRuleRegistry / IRule   (Rule Engine توسعه‌پذیر)
//   - IAbacPermissionChecker  (RBAC + ABAC)
//
// V8.2 Fix: همه متدهای Repository یک پارامتر اختیاری tx? دریافت
// می‌کنند تا بتوانند در داخل یک Unit of Work اجرا شوند.
// ============================================================

import { BaseEntity, Context, QueryOptions, PaginatedResult, OperationResult } from '../types';
import { DomainEvent, EventName } from '../events';

// ============================================================
// ===== REPOSITORY INTERFACES (Improvement #1) =====
// ============================================================
// در V7، Engineها به کلاس Concrete مثل OrderRepository وابسته بودند.
// در V8، Engineها فقط اینترفیس می‌بینند — پیاده‌سازی می‌تواند
// Prisma، Mongo، یا حتی یک API Remote باشد.

export interface IBaseRepository<T extends BaseEntity> {
  findById(id: number, ctx: Context, tx?: ITransactionContext): Promise<T | null>;
  findMany(opts: QueryOptions, ctx: Context, tx?: ITransactionContext): Promise<PaginatedResult<T>>;
  create(data: Partial<T>, ctx: Context, tx?: ITransactionContext): Promise<T>;
  update(id: number, data: Partial<T>, ctx: Context, tx?: ITransactionContext): Promise<T>;
  softDelete(id: number, ctx: Context, tx?: ITransactionContext): Promise<void>;
  count(where: Record<string, any>, ctx: Context, tx?: ITransactionContext): Promise<number>;
}

// ----- Repositoryهای تخصصی دامنه -----
// هر Repository یک اینترفیس مستقل دارد تا Engine فقط متدهایی که
// واقعاً نیاز دارد را ببیند — و پیاده‌سازی بدون تأثیر بر Engine
// قابل تعویض باشد.

export interface IOrderRepository extends IBaseRepository<any> {
  findByStatus(status: string, ctx: Context, page?: number, pageSize?: number): Promise<PaginatedResult<any>>;
  findUserOrders(userId: number, ctx: Context): Promise<any[]>;
  updateStatus(id: number, status: string, ctx: Context, tx?: ITransactionContext): Promise<void>;
  generateOrderNumber(ctx: Context): Promise<string>;
  // متد جدید: ایجاد سفارش + اقلام در یک تراکنش
  createWithItems(
    order: Record<string, any>,
    items: Array<Record<string, any>>,
    ctx: Context,
    tx?: ITransactionContext,
  ): Promise<{ id: number; orderNumber: string }>;
  // متد جدید: آپدیت با trackingCode
  updateTracking(id: number, trackingCode: string, ctx: Context, tx?: ITransactionContext): Promise<void>;
}

export interface IProductRepository extends IBaseRepository<any> {
  findPublished(ctx: Context, opts?: QueryOptions): Promise<PaginatedResult<any>>;
  publish(id: number, ctx: Context, tx?: ITransactionContext): Promise<void>;
  unpublish(id: number, ctx: Context, tx?: ITransactionContext): Promise<void>;
  updateStock(id: number, delta: number, ctx: Context, tx?: ITransactionContext): Promise<number>;
  reserveStock(items: Array<{ productId: number; quantity: number }>, ctx: Context, tx?: ITransactionContext): Promise<void>;
  releaseStock(items: Array<{ productId: number; quantity: number }>, ctx: Context, tx?: ITransactionContext): Promise<void>;
}

export interface IInventoryRepository {
  getStock(itemType: string, itemId: number, ctx: Context): Promise<number>;
  adjustStock(itemType: string, itemId: number, delta: number, ctx: Context): Promise<number>;
  recordTransaction(transaction: Record<string, any>, ctx: Context, tx?: ITransactionContext): Promise<void>;
}

export interface IAccountingRepository {
  createJournalEntry(entry: Record<string, any>, lines: any[], ctx: Context): Promise<{ id: number; entryNumber: string }>;
  getTrialBalance(from: Date, to: Date, ctx: Context): Promise<any[]>;
  getProfitLoss(from: Date, to: Date, ctx: Context): Promise<any>;
  getBalanceSheet(asOf: Date, ctx: Context): Promise<any>;
}

export interface IWorkflowRepository {
  getActiveWorkflow(entityType: string, entityId: number, ctx: Context): Promise<any | null>;
  createWorkflow(state: Record<string, any>, ctx: Context): Promise<any>;
  updateWorkflowStep(id: number, step: string, status: string, history: any[], ctx: Context): Promise<void>;
  appendHistory(id: number, entry: any, ctx: Context): Promise<void>;
}

export interface IAuditLogRepository {
  append(entry: Record<string, any>): Promise<void>;
  query(filter: Record<string, any>, ctx: Context, page?: number, pageSize?: number): Promise<PaginatedResult<any>>;
}

export interface IEventStoreRepository {
  append(event: Record<string, any>): Promise<void>;
  getByAggregate(aggregateType: string, aggregateId: number, ctx: Context): Promise<any[]>;
  getByTenant(tenantId: number, from: Date, to: Date, page?: number, pageSize?: number): Promise<any[]>;
}

// ============================================================
// ===== EVENT BUS (Upgraded — Typed + Batch Publishing) =====
// ============================================================
export type EventHandler<E extends DomainEvent = DomainEvent> = (event: E) => Promise<void>;

export interface IEventBus {
  /** انتشار یک Event */
  publish<E extends DomainEvent>(event: E): Promise<void>;
  /**
   * V8.1: انتشار batch از Eventها
   * این متد برای Aggregateهایی که چند Domain Event تولید می‌کنند
   * طراحی شده است. همه eventها در یک batch به Event Store append می‌شوند.
   */
  publishAll<E extends DomainEvent>(events: E[]): Promise<void>;
  // ← در V8 نام Event فقط از نوع EventName قبول می‌شود (تایپ‌شده).
  subscribe<E extends DomainEvent>(
    eventName: EventName,
    handler: EventHandler<E>,
  ): void;
  unsubscribe(eventName: EventName, handler: EventHandler): void;
}

// ============================================================
// ===== EVENT STORE (Improvement #3) =====
// ============================================================
// Event Store تمام Eventهای منتشرشده را به‌صورت immutable ذخیره
// می‌کند تا بعداً برای Audit، Replay، یا rebuilding state قابل
// استفاده باشد.

export interface IEventStore {
  /** ذخیره یک Event در Store (به‌صورت async) */
  append(event: DomainEvent): Promise<void>;
  /** بازخوانی همه Eventهای یک Aggregate (برای Event Sourcing) */
  getByAggregate(aggregateType: string, aggregateId: number, ctx: Context): Promise<DomainEvent[]>;
  /** بازخوانی همه Eventهای یک Tenant در بازه زمانی */
  getByTenant(
    tenantId: number,
    from: Date,
    to: Date,
    page?: number,
    pageSize?: number,
  ): Promise<{ events: DomainEvent[]; total: number }>;
  /** بازخوانی همه Eventهای یک نوع (برای Replay) */
  getByType(
    eventType: EventName,
    from: Date,
    to: Date,
    page?: number,
    pageSize?: number,
  ): Promise<{ events: DomainEvent[]; total: number }>;
}

// ============================================================
// ===== UNIT OF WORK + TRANSACTION MANAGER (Improvement #2) =====
// ============================================================
// Unit of Work الگوی اصلی برای اجرای چند عملیات دیتابیس در یک
// تراکنش واحد است. اگر هر مرحله fail شود، کل تراکنش rollback می‌شود.

export interface IUnitOfWork {
  /** شروع یک تراکنش جدید */
  begin(): Promise<void>;
  /** ثبت موفقیت — commit تراکنش */
  commit(): Promise<void>;
  /** ثبت شکست — rollback تراکنش */
  rollback(): Promise<void>;
  /** اجرای یک تابع داخل تراکنش — در صورت خطا rollback خودکار */
  run<T>(fn: (tx: ITransactionContext) => Promise<T>): Promise<T>;
  /** آیا فعلاً در تراکنش هستیم؟ */
  isActive(): boolean;
}

// ----- Transaction Context -----
// در زمان اجرای یک Unit of Work، یک TransactionContext به تابع
// پاس داده می‌شود. این Context به Repositoryها اجازه می‌دهد
// بدانند در کدام تراکنش دارند عمل می‌کنند.

export interface ITransactionContext {
  /** شناسه یکتای تراکنش */
  readonly transactionId: string;
  /**Prisma transaction client (در پیاده‌سازی Prisma) */
  readonly client: any;
  /** ثبت یک Event برای انتشار بعد از commit موفق */
  collectEvent(event: DomainEvent): void;
  /**
   * V8.1: ثبت batch از Eventها برای انتشار بعد از commit موفق.
   * برای Aggregateهایی که چند Domain Event تولید می‌کنند.
   */
  collectEvents(events: DomainEvent[]): void;
  /** ثبت یک Audit entry برای نوشته شدن بعد از commit موفق */
  collectAudit(entry: Record<string, any>): void;
}

// ----- Transaction Manager -----
// Transaction Manager یک Factory برای IUnitOfWork است. در هر
// عملیات business که چندین Stage دارد، یک UoW ساخته می‌شود.

export interface ITransactionManager {
  create(): IUnitOfWork;
  /** shortcut: اجرای یک تابع در تراکنش جدید */
  run<T>(fn: (tx: ITransactionContext) => Promise<T>): Promise<T>;
}

// ============================================================
// ===== AUDIT LOGGER (Improvement #7) =====
// ============================================================
// Audit Log مرکزی — هر عملیات write باید یک رکورد Audit تولید کند.
// شامل اطلاعات کامل: Who / When / What / Old / New / IP / Browser / Tenant.

export interface AuditEntry {
  tenantId: number;
  userId?: number;
  userRole?: string;
  action: string;             // e.g. 'order.create', 'product.update'
  entityType: string;         // e.g. 'Order', 'Product'
  entityId: number | string;
  entityIdType?: 'int' | 'string';
  operation: 'create' | 'update' | 'delete' | 'read' | 'login' | 'logout' | 'export' | 'config';
  changes?: Record<string, { old: any; new: any }>;
  metadata?: Record<string, any>;
  ip?: string;
  userAgent?: string;
  requestId?: string;
  timestamp: Date;
}

export interface IAuditLogger {
  /** ثبت یک Audit entry (همیشه async) */
  log(entry: AuditEntry): Promise<void>;
  /** ثبت تغییرات یک Entity (diff خودکار) */
  logChange(
    entityType: string,
    entityId: number | string,
    oldValues: Record<string, any>,
    newValues: Record<string, any>,
    ctx: Context,
    action?: string,
  ): Promise<void>;
  /** query برای گزارش‌گیری Audit */
  query(
    filter: {
      tenantId?: number;
      userId?: number;
      entityType?: string;
      entityId?: number | string;
      action?: string;
      from?: Date;
      to?: Date;
    },
    page?: number,
    pageSize?: number,
  ): Promise<PaginatedResult<AuditEntry>>;
}

// ============================================================
// ===== CACHE LAYER (Improvement #10) =====
// ============================================================
// در V8 یک Cache Layer استاندارد اضافه شده که هم از Redis و هم
// از In-Memory پشتیبانی می‌کند. Repositoryها می‌توانند با Decorator
// از آن استفاده کنند.

export interface ICache {
  get<T>(key: string): Promise<T | null>;
  set<T>(key: string, value: T, ttl?: number): Promise<void>;
  delete(key: string): Promise<void>;
  /** حذف همه کلیدهایی که با pattern شروع می‌شوند (e.g. 'products:*') */
  invalidate(pattern: string): Promise<void>;
  /** تلاش برای خواندن از cache؛ در صورت miss، تابع اجرا و نتیجه ذخیره می‌شود */
  getOrSet<T>(key: string, ttl: number, factory: () => Promise<T>): Promise<T>;
  /** flush کل cache (فقط برای test/dev) */
  flush(): Promise<void>;
}

// ============================================================
// ===== CQRS: COMMAND BUS + QUERY BUS (Improvement #4) =====
// ============================================================
// در CQRS، Commands (write) و Queries (read) از هم جدا می‌شوند.
// این کار Performance و scalability را بالا می‌برد، چون Queryها
// می‌توانند از یک replica یا cache بخوانند و Commands از master.

// ----- Command -----
export interface ICommand {
  readonly commandName: string;
}
export interface ICommandResult {
  success: boolean;
  message?: string;
  data?: any;
}
export type ICommandHandler<C extends ICommand = ICommand> = (
  command: C,
  ctx: Context,
) => Promise<ICommandResult>;

export interface ICommandBus {
  /** ثبت یک Handler برای یک نوع Command */
  register<C extends ICommand>(commandName: string, handler: ICommandHandler<C>): void;
  /** اجرای یک Command */
  execute<C extends ICommand>(command: C, ctx: Context): Promise<ICommandResult>;
}

// ----- Query -----
export interface IQuery {
  readonly queryName: string;
}
export type IQueryHandler<Q extends IQuery = IQuery> = (
  query: Q,
  ctx: Context,
) => Promise<any>;

export interface IQueryBus {
  register<Q extends IQuery>(queryName: string, handler: IQueryHandler<Q>): void;
  execute<Q extends IQuery>(query: Q, ctx: Context): Promise<any>;
}

// ============================================================
// ===== DI CONTAINER (Improvement #8) =====
// ============================================================
// DI Container جایگزین Constructor Injection دستی می‌شود. تمام
// وابستگی‌ها در یک Container مرکزی ثبت می‌شوند و هر Engine فقط
// Tokenهای مورد نیازش را درخواست می‌کند.

export type Lifetime = 'singleton' | 'transient' | 'scoped';

export interface DIBinding<T> {
  token: string;
  factory: (container: IContainer) => T | Promise<T>;
  lifetime: Lifetime;
}

export interface IContainer {
  /** ثبت یک کلاس به‌عنوان Singleton یا Transient */
  bind<T>(token: string, factory: (c: IContainer) => T | Promise<T>, lifetime?: Lifetime): void;
  /** ثبت مستقیم یک instance (همیشه Singleton) */
  bindInstance<T>(token: string, instance: T): void;
  /** دریافت یک وابستگی */
  resolve<T>(token: string): Promise<T>;
  /** دریافت همزمان (فقط برای Singletons از قبل ساخته‌شده) */
  resolveSync<T>(token: string): T;
  /** بررسی ثبت بودن یک Token */
  has(token: string): boolean;
  /** شروع یک Scope جدید (برای Request-scoped bindings) */
  createScope(): IContainer;
  /** پاک کردن همه bindings (برای test) */
  reset(): void;
}

// ============================================================
// ===== RULE ENGINE EXTENSIBLE (Improvement #9) =====
// ============================================================
// در V8 Rule Engine به‌صورت یک Registry از کلاس‌های Rule طراحی شده.
// هر Rule یک کلاس مستقل است که اینترفیس IRule را پیاده‌سازی می‌کند.
// این کار امکان افزودن Rule جدید را بدون تغییر RuleEngine فراهم می‌کند.

export interface IRuleContext {
  action: string;
  data: any;
  ctx: Context;
  engine?: string;
}

export interface IRuleResult {
  passed: boolean;
  severity: 'error' | 'warn' | 'info';
  message?: string;
  /** اگر severity=warn یا info بود، rule ممکن است data را تغییر دهد */
  adjustedData?: any;
}

export interface IRule {
  /** نام یکتای قانون */
  readonly name: string;
  /** کدام Engine / action مرتبط است (مثلاً 'order.create') */
  readonly appliesTo: string;
  /** اولویت اجرا — کم‌ترین اول اجرا می‌شود */
  readonly priority: number;
  /** بررسی اینکه آیا این Rule برای این context فعال است */
  isApplicable(rc: IRuleContext): boolean;
  /** اجرای قانون */
  evaluate(rc: IRuleContext): Promise<IRuleResult>;
}

export interface IRuleRegistry {
  register(rule: IRule): void;
  unregister(ruleName: string): void;
  getRulesForAction(action: string, ctx: Context, data?: any): IRule[];
  list(): IRule[];
}

export interface IRuleEngine {
  validate(action: string, data: any, ctx: Context): Promise<OperationResult>;
  evaluate(condition: any, data: any): boolean;
}

// ============================================================
// ===== ABAC PERMISSION (Improvement #10b) =====
// ============================================================
// در V8 RBAC به ABAC ارتقاء یافته. علاوه بر Role، Attributeهای
// محیطی (Department, Branch, Owner, Time, Status) هم بررسی می‌شوند.

export interface AbacAttribute {
  userId?: number;
  role?: string;
  department?: string;
  branch?: string;
  ownershipLevel?: 'self' | 'team' | 'department' | 'company' | 'all';
  timeWindow?: { from: Date; to: Date };
  entityOwnerId?: number;
  entityStatus?: string;
  resourceType?: string;
  resourceId?: number;
}

export interface AbacPolicy {
  name: string;
  resource: string;
  action: string;
  /** شرط necessary: باید همه true باشند */
  requiredRoles?: string[];
  /** Attributeهایی که باید مطابقت داشته باشند */
  attributes?: Partial<AbacAttribute>;
  /** شرط اختیاری — تابعی که در runtime بررسی می‌شود */
  condition?: (attr: AbacAttribute) => boolean;
  effect: 'allow' | 'deny';
  priority: number;
}

export interface IAbacPermissionChecker {
  /** بررسی RBAC ساده */
  hasPermission(permission: string, ctx: Context): boolean;
  hasRole(role: string, ctx: Context): boolean;
  /** بررسی ABAC کامل */
  checkAccess(
    permission: string,
    ctx: Context,
    attributes?: Partial<AbacAttribute>,
  ): AbacDecision;
  /** ثبت یک Policy جدید */
  registerPolicy(policy: AbacPolicy): void;
  /** لیست Policyهای ثبت‌شده */
  listPolicies(): AbacPolicy[];
}

export interface AbacDecision {
  allowed: boolean;
  matchedPolicy?: string;
  deniedReason?: string;
  evaluatedAt: Date;
}

// ============================================================
// ===== Legacy / Retained Interfaces =====
// ============================================================

export interface IService {
  initialize?(): Promise<void>;
}

export interface IWorkflowEngine {
  startWorkflow(entityType: string, entityId: number, ctx: Context): Promise<void>;
  advanceStep(entityType: string, entityId: number, ctx: Context): Promise<OperationResult>;
  getCurrentStep(entityType: string, entityId: number): Promise<string | null>;
}

export interface ILogger {
  info(message: string, meta?: any): void;
  warn(message: string, meta?: any): void;
  error(message: string, meta?: any): void;
  debug(message: string, meta?: any): void;
}

/**
 * V8.1: یک NoopLogger که هیچ خروجی ندارد.
 * برای استفاده به‌عنوان default به‌جای `console`.
 */
export const noopLogger: ILogger = {
  info: () => {},
  warn: () => {},
  error: () => {},
  debug: () => {},
};

// ===== Pricing / Accounting / Analytics / Document (Phase 3) =====
export interface IPricingEngine {
  calculatePrice(input: any, ctx: Context): Promise<any>;
  calculateCost(productId: number, ctx: Context): Promise<any>;
  updateProductPrice(productId: number, newPrice: number, reason: string, ctx: Context): Promise<OperationResult>;
  applyBulkDiscount(productIds: number[], discountPercent: number, startDate: Date, endDate: Date, ctx: Context): Promise<OperationResult>;
}

export interface IAccountingEngine {
  createJournalEntry(entry: any, ctx: Context): Promise<{ entryId: number; entryNumber: string }>;
  recordSale(input: any, ctx: Context): Promise<OperationResult>;
  recordPaymentReceived(input: any, ctx: Context): Promise<OperationResult>;
  recordPaymentMade(input: any, ctx: Context): Promise<OperationResult>;
  recordExpense(input: any, ctx: Context): Promise<OperationResult>;
  getTrialBalance(from: Date, to: Date, ctx: Context): Promise<any[]>;
  getProfitLoss(from: Date, to: Date, ctx: Context): Promise<any>;
  getBalanceSheet(asOf: Date, ctx: Context): Promise<any>;
}

export interface IAnalyticsEngine {
  recordMetric(metric: string, value: number, dimensions: Record<string, any>, ctx: Context): Promise<void>;
  getLatestMetric(metric: string, ctx: Context): Promise<number | null>;
  getMetricTimeSeries(metric: string, from: Date, to: Date, ctx: Context): Promise<any[]>;
  recordDailyKPIs(ctx: Context): Promise<OperationResult>;
  getDashboard(ctx: Context): Promise<any>;
  getSalesReport(from: Date, to: Date, ctx: Context): Promise<any>;
  getProductionReport(from: Date, to: Date, ctx: Context): Promise<any>;
}

export interface IDocumentEngine {
  upload(input: any, ctx: Context): Promise<any>;
  uploadVersion(documentId: number, file: any, notes: string, ctx: Context): Promise<OperationResult>;
  getDocument(documentId: number, ctx: Context): Promise<any | null>;
  getDocumentsByEntity(entityType: string, entityId: number, type?: string, ctx?: Context): Promise<any[]>;
  deleteDocument(documentId: number, ctx: Context): Promise<OperationResult>;
  signDocument(input: any, ctx: Context): Promise<OperationResult>;
  shareDocument(documentId: number, userIds: number[], message: string, ctx: Context): Promise<OperationResult>;
  searchDocuments(query: string, filters: any, ctx: Context): Promise<any[]>;
}
