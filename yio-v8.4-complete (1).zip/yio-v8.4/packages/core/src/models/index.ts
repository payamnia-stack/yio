// ============================================================
// YIO V7 — Domain Models
// ============================================================
// تعریف تمام موجودیت‌های دامنه (Domain Entities)
// ============================================================

import { BaseEntity } from '../types';

// ===== Product Domain =====
export interface Product extends BaseEntity {
  title: string;
  brand: string;
  category: string;
  price: number;
  salePrice?: number | null;
  discountPrice?: number | null;
  discountPercent?: number | null;
  image: string;
  images?: string | null;
  videos?: string | null;
  colors?: string | null;
  rating: number;
  ratingCount: number;
  inStock: boolean;
  fastDelivery: boolean;
  isSpecial: boolean;
  isPublished: boolean;
  publishedAt?: Date | null;
  stockQuantity: number;
  description?: string | null;
  woodType?: string | null;
  productImages?: ProductImage[];
  productVideos?: ProductVideo[];
  productColors?: ProductColor[];
  productVariants?: ProductVariant[];
}

export interface ProductVariant extends BaseEntity {
  productId: number;
  colorId?: number | null;
  sku?: string | null;
  title: string;
  price?: number | null;
  salePrice?: number | null;
  stockQuantity: number;
  isDefault: boolean;
  isActive: boolean;
  updatedAt?: Date;
}

export interface ProductImage extends BaseEntity {
  productId: number;
  url: string;
  alt?: string | null;
  sortOrder: number;
  isPrimary: boolean;
}

export interface ProductVideo extends BaseEntity {
  productId: number;
  url: string;
  title?: string | null;
  sortOrder: number;
}

export interface ProductColor extends BaseEntity {
  productId: number;
  name: string;
  code: string;
  sortOrder: number;
}

export interface ProductDesign extends BaseEntity {
  productId: number;
  version: string;
  description?: string;
  changeReason?: string;
  designerId?: number;
  designerName?: string;
  status: 'draft' | 'review' | 'approved' | 'rejected';
  cadFile?: string;
  cncFile?: string;
  laserFile?: string;
  model3dFile?: string;
  costImpact?: string;
  parentId?: number | null;
}

// ===== BOM & Routing =====
export interface BOM extends BaseEntity {
  productId: number;
  name: string;
  isActive: boolean;
  totalCost?: number;
}

export interface BOMItem extends BaseEntity {
  bomId: number;
  materialId?: number;
  materialName: string;
  quantity: number;
  unit: string;
  unitCost?: number;
  totalCost?: number;
}

export interface Routing extends BaseEntity {
  productId: number;
  name: string;
  isActive: boolean;
  totalTime?: number;
  totalCost?: number;
}

export interface RoutingStep extends BaseEntity {
  routingId: number;
  stepOrder: number;
  name: string;
  description?: string;
  workStationId?: number;
  machineId?: number;
  standardTime: number;
  capacity?: number;
  cost?: number;
  isActive: boolean;
}

// ===== Production =====
export interface WorkOrder extends BaseEntity {
  woNumber: string;
  productId: number;
  orderId?: number;
  quantity: number;
  routingId?: number;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  status: 'planned' | 'in_progress' | 'paused' | 'completed' | 'cancelled';
  startDate?: Date;
  endDate?: Date;
  expectedDate?: Date;
  assignedTo?: string;
  notes?: string;
}

export interface WorkOrderStep extends BaseEntity {
  workOrderId: number;
  routingStepId?: number;
  workStationId?: number;
  machineId?: number;
  stepOrder: number;
  name: string;
  status: 'pending' | 'in_progress' | 'completed' | 'skipped';
  operatorId?: number;
  operatorName?: string;
  startTime?: Date;
  endTime?: Date;
  actualTime?: number;
  quantityDone: number;
  quantityReject: number;
  notes?: string;
}

export interface ProductionBatch extends BaseEntity {
  batchNumber: string;
  productId: number;
  workOrderId?: number;
  quantity: number;
  materialLot?: string;
  woodType?: string;
  startDate: Date;
  endDate?: Date;
  status: 'in_progress' | 'completed' | 'rejected';
  notes?: string;
}

// ===== Quality & Waste =====
export interface QualityCheck extends BaseEntity {
  workOrderId: number;
  productId: number;
  stepName?: string;
  result: 'pass' | 'fail' | 'rework';
  defectType?: string;
  defectCount: number;
  notes?: string;
  inspectorId?: number;
  inspectorName?: string;
  photoUrl?: string;
  checkedAt: Date;
}

export interface WasteRecord extends BaseEntity {
  workOrderId?: number;
  productId?: number;
  machineId?: number;
  materialType: string;
  inputWeight?: number;
  outputWeight?: number;
  wasteWeight?: number;
  wastePercent?: number;
  wasteType?: string;
  cause?: string;
}

// ===== Inventory =====
export interface Warehouse extends BaseEntity {
  name: string;
  type: 'raw' | 'finished' | 'wip' | 'packaging';
  location?: string;
  capacity?: number;
  managerId?: number;
  isActive: boolean;
}

export interface WoodStock extends BaseEntity {
  woodType: string;
  thickness: number;
  width?: number;
  length?: number;
  moisture?: number;
  grade?: string;
  quantity: number;
  unit: string;
  pricePerUnit?: number;
  supplierId?: number;
  warehouseId?: number;
  status: 'in_stock' | 'reserved' | 'used' | 'drying';
}

export interface PaintStock extends BaseEntity {
  name: string;
  type: string;
  color?: string;
  batchNumber?: string;
  expiryDate?: Date;
  quantity: number;
  unit: string;
  supplierId?: number;
  purchasePrice?: number;
  status: 'in_stock' | 'low' | 'expired' | 'used';
}

export interface Machine extends BaseEntity {
  name: string;
  type: string;
  model?: string;
  serialNumber?: string;
  workHours: number;
  serviceInterval: number;
  lastService?: Date;
  nextService?: Date;
  status: 'active' | 'maintenance' | 'broken' | 'retired';
  efficiency: number;
  operatorId?: number;
}

export interface Tool extends BaseEntity {
  name: string;
  type: string;
  machineId?: number;
  lifespan?: number;
  usedCount: number;
  cost?: number;
  status: 'active' | 'needs_replacement' | 'replaced';
}

// ===== Sales =====
export interface Customer extends BaseEntity {
  name: string;
  phone: string;
  email?: string;
  address?: string;
  city?: string;
  postalCode?: string;
  notes?: string;
}

export interface SalesOrder extends BaseEntity {
  orderNumber: string;
  customerId?: number;
  userId?: number;
  status: 'pending' | 'confirmed' | 'shipping' | 'delivered' | 'cancelled';
  totalAmount: number;
  shippingCost: number;
  finalAmount: number;
  paymentMethod: string;
  paymentStatus: 'unpaid' | 'paid' | 'refunded';
  shippingAddress: string;
  shippingCity?: string;
  recipientName: string;
  recipientPhone: string;
  trackingCode?: string;
  notes?: string;
}

export interface OrderItem extends BaseEntity {
  orderId: number;
  productId: number;
  productTitle: string;
  productImage: string;
  price: number;
  quantity: number;
  color?: string;
}

// ===== Purchasing =====
export interface Supplier extends BaseEntity {
  name: string;
  type: string;
  phone?: string;
  email?: string;
  address?: string;
  contactPerson?: string;
  rating: number;
  isActive: boolean;
}

export interface PurchaseOrder extends BaseEntity {
  poNumber: string;
  supplierId?: number;
  supplierName?: string;
  status: 'draft' | 'inquiry' | 'compared' | 'ordered' | 'received' | 'qc' | 'completed';
  totalAmount: number;
  orderDate: Date;
  expectedDate?: Date;
  receivedDate?: Date;
  notes?: string;
}

// ===== HR =====
export interface Employee extends BaseEntity {
  userId?: number;
  name: string;
  role: string;
  phone?: string;
  skills?: string;
  shift: string;
  hourlyRate?: number;
  efficiency: number;
  totalHours: number;
  isActive: boolean;
  hireDate: Date;
}

// ===== System =====
export interface User extends BaseEntity {
  phone: string;
  name?: string;
  email?: string;
  password?: string;
  avatar?: string;
  level: number;
  isVerified: boolean;
  isWholesale: boolean;
}

export interface Role extends BaseEntity {
  name: string;
  displayName: string;
  permissions?: string;
  description?: string;
}

export interface Document extends BaseEntity {
  productId?: number;
  workOrderId?: number;
  name: string;
  type: string;
  fileUrl: string;
  fileSize?: number;
  description?: string;
  uploadedBy?: string;
}

export interface CostFormula extends BaseEntity {
  productId: number;
  materialCost: number;
  laborCost: number;
  energyCost: number;
  depreciationCost: number;
  packagingCost: number;
  wasteCost: number;
  transportCost: number;
  commissionCost: number;
  taxCost: number;
  totalCost: number;
  profitMargin: number;
  suggestedPrice: number;
}
