// ============================================================
// YIO V8 — DI Tokens
// ============================================================
// تمام وابستگی‌ها در Container از طریق Token ثبت می‌شوند.
// این فایل منبع واحد حقیقت برای نام Tokenهاست.
// ============================================================

export const TOKENS = {
  // ---- Infrastructure ----
  PrismaClient:        'PrismaClient',
  EventBus:            'IEventBus',
  EventStore:          'IEventStore',
  UnitOfWork:          'IUnitOfWork',
  TransactionManager:  'ITransactionManager',
  AuditLogger:         'IAuditLogger',
  Cache:               'ICache',
  Logger:              'ILogger',
  Container:           'IContainer',

  // ---- Repositories ----
  OrderRepository:     'IOrderRepository',
  ProductRepository:   'IProductRepository',
  InventoryRepository: 'IInventoryRepository',
  AccountingRepository:'IAccountingRepository',
  WorkflowRepository:  'IWorkflowRepository',
  AuditLogRepository:  'IAuditLogRepository',
  EventStoreRepository:'IEventStoreRepository',

  // ---- Engines ----
  OrderEngine:         'OrderEngine',
  ProductionEngine:    'ProductionEngine',
  InventoryEngine:     'InventoryEngine',
  PricingEngine:       'PricingEngine',
  AccountingEngine:    'AccountingEngine',
  WorkflowEngine:      'WorkflowEngine',
  NotificationEngine:  'NotificationEngine',
  PermissionEngine:    'PermissionEngine',
  RuleEngine:          'RuleEngine',
  AnalyticsEngine:     'AnalyticsEngine',
  DocumentEngine:      'DocumentEngine',

  // ---- CQRS Buses ----
  CommandBus:          'ICommandBus',
  QueryBus:            'IQueryBus',

  // ---- Rule Registry ----
  RuleRegistry:        'IRuleRegistry',
} as const;

export type Token = (typeof TOKENS)[keyof typeof TOKENS];
