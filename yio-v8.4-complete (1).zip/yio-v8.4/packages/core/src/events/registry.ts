// ============================================================
// YIO V8 — Typed Event Registry
// ============================================================
// به جای عبور نام Event به‌صورت String خام، همه Eventها در یک
// رجیستری تایپ‌شده ثبت می‌شوند. این کار:
//   1) خطای تایپ نام Event را در زمان Compile میده
//   2) autocomplete کامل در IDE فراهم می‌کند
//   3) mapping دوطقه بین Event Class <-> Event Name
// ============================================================

import {
  DomainEvent,
  ProductCreatedEvent,
  ProductPublishedEvent,
  ProductUnpublishedEvent,
  ProductStockUpdatedEvent,
  OrderCreatedEvent,
  OrderConfirmedEvent,
  OrderShippedEvent,
  OrderDeliveredEvent,
  OrderCancelledEvent,
  OrderPaidEvent,
  WorkOrderCreatedEvent,
  ProductionStartedEvent,
  ProductionCompletedEvent,
  ProductionStepCompletedEvent,
  StockUpdatedEvent,
  LowStockAlertEvent,
  StockReservedEvent,
  QualityCheckPassedEvent,
  QualityCheckFailedEvent,
  MachineMaintenanceDueEvent,
  MachineBrokenEvent,
  UserRegisteredEvent,
  UserLoggedInEvent,
  PurchaseOrderCreatedEvent,
  PurchaseOrderReceivedEvent,
  PriceCalculatedEvent,
  PriceChangedEvent,
  DiscountAppliedEvent,
  CostUpdatedEvent,
  AccountingEntryCreatedEvent,
  PaymentReceivedEvent,
  PaymentMadeEvent,
  InvoiceIssuedEvent,
  WorkflowStartedEvent,
  WorkflowStepAdvancedEvent,
  WorkflowCompletedEvent,
  WorkflowCancelledEvent,
  WorkflowStepBlockedEvent,
  AnalyticsSnapshotRecordedEvent,
  DashboardUpdatedEvent,
  KPIAlertEvent,
  DocumentUploadedEvent,
  DocumentVersionedEvent,
  DocumentSignedEvent,
  DocumentSharedEvent,
} from './domain-events';

// ============================================================
// Events const — منبع واحد حقیقت برای نام Eventها
// ============================================================
// این شیء هم به‌عنوان enum و هم به‌عنوان map استفاده می‌شود.
// هر نام با کلاس متناظرش نگاشت می‌شود تا هیچ رشته‌ای بدون تایپ
// قابل استفاده نباشد.
export const Events = {
  // Product
  ProductCreated: 'product.created',
  ProductPublished: 'product.published',
  ProductUnpublished: 'product.unpublished',
  ProductStockUpdated: 'product.stock_updated',

  // Order
  OrderCreated: 'order.created',
  OrderConfirmed: 'order.confirmed',
  OrderShipped: 'order.shipped',
  OrderDelivered: 'order.delivered',
  OrderCancelled: 'order.cancelled',
  OrderPaid: 'order.paid',

  // Production
  WorkOrderCreated: 'work_order.created',
  ProductionStarted: 'production.started',
  ProductionCompleted: 'production.completed',
  ProductionStepCompleted: 'production.step_completed',

  // Inventory
  StockUpdated: 'inventory.stock_updated',
  LowStockAlert: 'inventory.low_stock',
  StockReserved: 'inventory.stock_reserved',

  // Quality
  QualityCheckPassed: 'quality.check_passed',
  QualityCheckFailed: 'quality.check_failed',

  // Machine
  MachineMaintenanceDue: 'machine.maintenance_due',
  MachineBroken: 'machine.broken',

  // User
  UserRegistered: 'user.registered',
  UserLoggedIn: 'user.logged_in',

  // Purchase
  PurchaseOrderCreated: 'purchase.created',
  PurchaseOrderReceived: 'purchase.received',

  // Pricing
  PriceCalculated: 'pricing.calculated',
  PriceChanged: 'pricing.changed',
  DiscountApplied: 'pricing.discount_applied',
  CostUpdated: 'pricing.cost_updated',

  // Accounting
  AccountingEntryCreated: 'accounting.entry_created',
  PaymentReceived: 'accounting.payment_received',
  PaymentMade: 'accounting.payment_made',
  InvoiceIssued: 'accounting.invoice_issued',

  // Workflow
  WorkflowStarted: 'workflow.started',
  WorkflowStepAdvanced: 'workflow.step_advanced',
  WorkflowCompleted: 'workflow.completed',
  WorkflowCancelled: 'workflow.cancelled',
  WorkflowStepBlocked: 'workflow.step_blocked',

  // Analytics
  AnalyticsSnapshotRecorded: 'analytics.snapshot_recorded',
  DashboardUpdated: 'analytics.dashboard_updated',
  KPIAlert: 'analytics.kpi_alert',

  // Document
  DocumentUploaded: 'document.uploaded',
  DocumentVersioned: 'document.versioned',
  DocumentSigned: 'document.signed',
  DocumentShared: 'document.shared',
} as const;

export type EventName = (typeof Events)[keyof typeof Events];

// ============================================================
// Event Registry — نگاشت دوطرفه کلاس <-> نام
// ============================================================
type EventConstructor = new (...args: any[]) => DomainEvent;

const eventRegistry = new Map<EventName, EventConstructor>();
const reverseRegistry = new Map<EventConstructor, EventName>();

function register(name: EventName, ctor: EventConstructor): void {
  eventRegistry.set(name, ctor);
  reverseRegistry.set(ctor, name);
}

// Product
register(Events.ProductCreated, ProductCreatedEvent);
register(Events.ProductPublished, ProductPublishedEvent);
register(Events.ProductUnpublished, ProductUnpublishedEvent);
register(Events.ProductStockUpdated, ProductStockUpdatedEvent);
// Order
register(Events.OrderCreated, OrderCreatedEvent);
register(Events.OrderConfirmed, OrderConfirmedEvent);
register(Events.OrderShipped, OrderShippedEvent);
register(Events.OrderDelivered, OrderDeliveredEvent);
register(Events.OrderCancelled, OrderCancelledEvent);
register(Events.OrderPaid, OrderPaidEvent);
// Production
register(Events.WorkOrderCreated, WorkOrderCreatedEvent);
register(Events.ProductionStarted, ProductionStartedEvent);
register(Events.ProductionCompleted, ProductionCompletedEvent);
register(Events.ProductionStepCompleted, ProductionStepCompletedEvent);
// Inventory
register(Events.StockUpdated, StockUpdatedEvent);
register(Events.LowStockAlert, LowStockAlertEvent);
register(Events.StockReserved, StockReservedEvent);
// Quality
register(Events.QualityCheckPassed, QualityCheckPassedEvent);
register(Events.QualityCheckFailed, QualityCheckFailedEvent);
// Machine
register(Events.MachineMaintenanceDue, MachineMaintenanceDueEvent);
register(Events.MachineBroken, MachineBrokenEvent);
// User
register(Events.UserRegistered, UserRegisteredEvent);
register(Events.UserLoggedIn, UserLoggedInEvent);
// Purchase
register(Events.PurchaseOrderCreated, PurchaseOrderCreatedEvent);
register(Events.PurchaseOrderReceived, PurchaseOrderReceivedEvent);
// Pricing
register(Events.PriceCalculated, PriceCalculatedEvent);
register(Events.PriceChanged, PriceChangedEvent);
register(Events.DiscountApplied, DiscountAppliedEvent);
register(Events.CostUpdated, CostUpdatedEvent);
// Accounting
register(Events.AccountingEntryCreated, AccountingEntryCreatedEvent);
register(Events.PaymentReceived, PaymentReceivedEvent);
register(Events.PaymentMade, PaymentMadeEvent);
register(Events.InvoiceIssued, InvoiceIssuedEvent);
// Workflow
register(Events.WorkflowStarted, WorkflowStartedEvent);
register(Events.WorkflowStepAdvanced, WorkflowStepAdvancedEvent);
register(Events.WorkflowCompleted, WorkflowCompletedEvent);
register(Events.WorkflowCancelled, WorkflowCancelledEvent);
register(Events.WorkflowStepBlocked, WorkflowStepBlockedEvent);
// Analytics
register(Events.AnalyticsSnapshotRecorded, AnalyticsSnapshotRecordedEvent);
register(Events.DashboardUpdated, DashboardUpdatedEvent);
register(Events.KPIAlert, KPIAlertEvent);
// Document
register(Events.DocumentUploaded, DocumentUploadedEvent);
register(Events.DocumentVersioned, DocumentVersionedEvent);
register(Events.DocumentSigned, DocumentSignedEvent);
register(Events.DocumentShared, DocumentSharedEvent);

// ============================================================
// Public Helpers
// ============================================================

/** دریافت کلاس Event بر اساس نام (برای Event Store replay) */
export function getEventClass(name: EventName): EventConstructor | undefined {
  return eventRegistry.get(name);
}

/** دریافت نام Event از روی یک instance — تایپ‌شده */
export function getEventName<E extends DomainEvent>(event: E): EventName {
  const ctor = event.constructor as EventConstructor;
  const name = reverseRegistry.get(ctor);
  if (!name) {
    throw new Error(
      `Event class "${ctor.name}" is not registered in Events registry. ` +
      `Please add it to packages/core/src/events/registry.ts`,
    );
  }
  return name;
}

/** لیست همه نام‌های ثبت‌شده (برای دیباگ / health check) */
export function listEventNames(): EventName[] {
  return Array.from(eventRegistry.keys());
}

/** اعتبارسنجی نام Event — برای جلوگیری از خطای تایپی */
export function isValidEventName(name: string): name is EventName {
  return eventRegistry.has(name as EventName);
}

// ============================================================
// Helper برای Subscribe با تایپ ایزوله
// ============================================================
// به جای eventBus.subscribe('product.published', handler)
// استفاده کنید: eventBus.subscribe(Events.ProductPublished, handler)
// این کار تضمین می‌کند که نام Event در زمان Compile بررسی می‌شود.
