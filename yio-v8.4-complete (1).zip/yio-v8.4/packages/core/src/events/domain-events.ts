// ============================================================
// YIO V7 — Domain Events
// ============================================================
// تمام Eventهای سیستم در اینجا تعریف می‌شوند.
// هر Event یک کلاس است که داده‌های مورد نیاز را حمل می‌کند.
// ============================================================

// ===== Base Event =====
export abstract class DomainEvent {
  public readonly timestamp: Date = new Date();
  public readonly eventId: string = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

  abstract get eventName(): string;
}

// ===== Product Events =====
export class ProductCreatedEvent extends DomainEvent {
  get eventName() { return 'product.created'; }
  constructor(
    public readonly productId: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class ProductPublishedEvent extends DomainEvent {
  get eventName() { return 'product.published'; }
  constructor(
    public readonly productId: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class ProductUnpublishedEvent extends DomainEvent {
  get eventName() { return 'product.unpublished'; }
  constructor(
    public readonly productId: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class ProductStockUpdatedEvent extends DomainEvent {
  get eventName() { return 'product.stock_updated'; }
  constructor(
    public readonly productId: number,
    public readonly oldStock: number,
    public readonly newStock: number,
    public readonly tenantId: number,
  ) { super(); }
}

// ===== Order Events =====
export class OrderCreatedEvent extends DomainEvent {
  get eventName() { return 'order.created'; }
  constructor(
    public readonly orderId: number,
    public readonly customerId: number | undefined,
    public readonly totalAmount: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class OrderConfirmedEvent extends DomainEvent {
  get eventName() { return 'order.confirmed'; }
  constructor(
    public readonly orderId: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class OrderShippedEvent extends DomainEvent {
  get eventName() { return 'order.shipped'; }
  constructor(
    public readonly orderId: number,
    public readonly trackingCode: string,
    public readonly tenantId: number,
  ) { super(); }
}

export class OrderDeliveredEvent extends DomainEvent {
  get eventName() { return 'order.delivered'; }
  constructor(
    public readonly orderId: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class OrderCancelledEvent extends DomainEvent {
  get eventName() { return 'order.cancelled'; }
  constructor(
    public readonly orderId: number,
    public readonly reason: string,
    public readonly tenantId: number,
  ) { super(); }
}

export class OrderPaidEvent extends DomainEvent {
  get eventName() { return 'order.paid'; }
  constructor(
    public readonly orderId: number,
    public readonly amount: number,
    public readonly paymentMethod: string,
    public readonly tenantId: number,
  ) { super(); }
}

// ===== Production Events =====
export class WorkOrderCreatedEvent extends DomainEvent {
  get eventName() { return 'work_order.created'; }
  constructor(
    public readonly workOrderId: number,
    public readonly productId: number,
    public readonly quantity: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class ProductionStartedEvent extends DomainEvent {
  get eventName() { return 'production.started'; }
  constructor(
    public readonly workOrderId: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class ProductionCompletedEvent extends DomainEvent {
  get eventName() { return 'production.completed'; }
  constructor(
    public readonly workOrderId: number,
    public readonly producedQuantity: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class ProductionStepCompletedEvent extends DomainEvent {
  get eventName() { return 'production.step_completed'; }
  constructor(
    public readonly workOrderId: number,
    public readonly stepName: string,
    public readonly tenantId: number,
  ) { super(); }
}

// ===== Inventory Events =====
export class StockUpdatedEvent extends DomainEvent {
  get eventName() { return 'inventory.stock_updated'; }
  constructor(
    public readonly itemType: 'wood' | 'paint' | 'material' | 'product',
    public readonly itemId: number,
    public readonly change: number,
    public readonly newQuantity: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class LowStockAlertEvent extends DomainEvent {
  get eventName() { return 'inventory.low_stock'; }
  constructor(
    public readonly itemType: string,
    public readonly itemId: number,
    public readonly itemName: string,
    public readonly currentQuantity: number,
    public readonly threshold: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class StockReservedEvent extends DomainEvent {
  get eventName() { return 'inventory.stock_reserved'; }
  constructor(
    public readonly productId: number,
    public readonly quantity: number,
    public readonly orderId: number,
    public readonly tenantId: number,
  ) { super(); }
}

// ===== Quality Events =====
export class QualityCheckPassedEvent extends DomainEvent {
  get eventName() { return 'quality.check_passed'; }
  constructor(
    public readonly workOrderId: number,
    public readonly productId: number,
    public readonly stepName: string,
    public readonly tenantId: number,
  ) { super(); }
}

export class QualityCheckFailedEvent extends DomainEvent {
  get eventName() { return 'quality.check_failed'; }
  constructor(
    public readonly workOrderId: number,
    public readonly productId: number,
    public readonly defectType: string,
    public readonly defectCount: number,
    public readonly tenantId: number,
  ) { super(); }
}

// ===== Machine Events =====
export class MachineMaintenanceDueEvent extends DomainEvent {
  get eventName() { return 'machine.maintenance_due'; }
  constructor(
    public readonly machineId: number,
    public readonly machineName: string,
    public readonly workHours: number,
    public readonly serviceInterval: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class MachineBrokenEvent extends DomainEvent {
  get eventName() { return 'machine.broken'; }
  constructor(
    public readonly machineId: number,
    public readonly machineName: string,
    public readonly tenantId: number,
  ) { super(); }
}

// ===== User Events =====
export class UserRegisteredEvent extends DomainEvent {
  get eventName() { return 'user.registered'; }
  constructor(
    public readonly userId: number,
    public readonly phone: string,
    public readonly isNewUser: boolean,
    public readonly tenantId: number,
  ) { super(); }
}

export class UserLoggedInEvent extends DomainEvent {
  get eventName() { return 'user.logged_in'; }
  constructor(
    public readonly userId: number,
    public readonly tenantId: number,
  ) { super(); }
}

// ===== Purchase Events =====
export class PurchaseOrderCreatedEvent extends DomainEvent {
  get eventName() { return 'purchase.created'; }
  constructor(
    public readonly poId: number,
    public readonly supplierId: number | undefined,
    public readonly totalAmount: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class PurchaseOrderReceivedEvent extends DomainEvent {
  get eventName() { return 'purchase.received'; }
  constructor(
    public readonly poId: number,
    public readonly tenantId: number,
  ) { super(); }
}

// ============================================================
// ===== PRICING EVENTS (Phase 3) =====
// ============================================================

export class PriceCalculatedEvent extends DomainEvent {
  get eventName() { return 'pricing.calculated'; }
  constructor(
    public readonly productId: number,
    public readonly finalAmount: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class PriceChangedEvent extends DomainEvent {
  get eventName() { return 'pricing.changed'; }
  constructor(
    public readonly productId: number,
    public readonly oldPrice: number,
    public readonly newPrice: number,
    public readonly reason: string,
    public readonly tenantId: number,
  ) { super(); }
}

export class DiscountAppliedEvent extends DomainEvent {
  get eventName() { return 'pricing.discount_applied'; }
  constructor(
    public readonly productId: number,
    public readonly discountRate: number,
    public readonly discountAmount: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class CostUpdatedEvent extends DomainEvent {
  get eventName() { return 'pricing.cost_updated'; }
  constructor(
    public readonly productId: number,
    public readonly totalCost: number,
    public readonly tenantId: number,
  ) { super(); }
}

// ============================================================
// ===== ACCOUNTING EVENTS (Phase 3) =====
// ============================================================

export class AccountingEntryCreatedEvent extends DomainEvent {
  get eventName() { return 'accounting.entry_created'; }
  constructor(
    public readonly entryNumber: string,
    public readonly amount: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class PaymentReceivedEvent extends DomainEvent {
  get eventName() { return 'accounting.payment_received'; }
  constructor(
    public readonly orderId: number,
    public readonly amount: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class PaymentMadeEvent extends DomainEvent {
  get eventName() { return 'accounting.payment_made'; }
  constructor(
    public readonly purchaseOrderId: number,
    public readonly amount: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class InvoiceIssuedEvent extends DomainEvent {
  get eventName() { return 'accounting.invoice_issued'; }
  constructor(
    public readonly orderId: number,
    public readonly amount: number,
    public readonly tenantId: number,
  ) { super(); }
}

// ============================================================
// ===== WORKFLOW EVENTS (Phase 3) =====
// ============================================================

export class WorkflowStartedEvent extends DomainEvent {
  get eventName() { return 'workflow.started'; }
  constructor(
    public readonly entityType: string,
    public readonly entityId: number,
    public readonly firstStep: string,
    public readonly tenantId: number,
  ) { super(); }
}

export class WorkflowStepAdvancedEvent extends DomainEvent {
  get eventName() { return 'workflow.step_advanced'; }
  constructor(
    public readonly entityType: string,
    public readonly entityId: number,
    public readonly fromStep: string,
    public readonly toStep: string,
    public readonly tenantId: number,
  ) { super(); }
}

export class WorkflowCompletedEvent extends DomainEvent {
  get eventName() { return 'workflow.completed'; }
  constructor(
    public readonly entityType: string,
    public readonly entityId: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class WorkflowCancelledEvent extends DomainEvent {
  get eventName() { return 'workflow.cancelled'; }
  constructor(
    public readonly entityType: string,
    public readonly entityId: number,
    public readonly reason: string,
    public readonly tenantId: number,
  ) { super(); }
}

export class WorkflowStepBlockedEvent extends DomainEvent {
  get eventName() { return 'workflow.step_blocked'; }
  constructor(
    public readonly entityType: string,
    public readonly entityId: number,
    public readonly stepName: string,
    public readonly reason: string,
    public readonly tenantId: number,
  ) { super(); }
}

// ============================================================
// ===== ANALYTICS EVENTS (Phase 3) =====
// ============================================================

export class AnalyticsSnapshotRecordedEvent extends DomainEvent {
  get eventName() { return 'analytics.snapshot_recorded'; }
  constructor(
    public readonly metric: string,
    public readonly value: number,
    public readonly tenantId: number,
  ) { super(); }
}

export class DashboardUpdatedEvent extends DomainEvent {
  get eventName() { return 'analytics.dashboard_updated'; }
  constructor(
    public readonly tenantId: number,
  ) { super(); }
}

export class KPIAlertEvent extends DomainEvent {
  get eventName() { return 'analytics.kpi_alert'; }
  constructor(
    public readonly metric: string,
    public readonly value: number,
    public readonly severity: 'warning' | 'critical',
    public readonly tenantId: number,
  ) { super(); }
}

// ============================================================
// ===== DOCUMENT EVENTS (Phase 3) =====
// ============================================================

export class DocumentUploadedEvent extends DomainEvent {
  get eventName() { return 'document.uploaded'; }
  constructor(
    public readonly documentId: number,
    public readonly type: string,
    public readonly category: string,
    public readonly tenantId: number,
  ) { super(); }
}

export class DocumentVersionedEvent extends DomainEvent {
  get eventName() { return 'document.versioned'; }
  constructor(
    public readonly documentId: number,
    public readonly version: number,
    public readonly hash: string,
    public readonly tenantId: number,
  ) { super(); }
}

export class DocumentSignedEvent extends DomainEvent {
  get eventName() { return 'document.signed'; }
  constructor(
    public readonly documentId: number,
    public readonly signerId: number,
    public readonly signerName: string,
    public readonly tenantId: number,
  ) { super(); }
}

export class DocumentSharedEvent extends DomainEvent {
  get eventName() { return 'document.shared'; }
  constructor(
    public readonly documentId: number,
    public readonly sharedWithUserIds: number[],
    public readonly tenantId: number,
  ) { super(); }
}
