export * from './prisma-delegate';
