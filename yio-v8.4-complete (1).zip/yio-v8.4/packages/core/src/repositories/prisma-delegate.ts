// ============================================================
// YIO V8.1 — Prisma Model Delegate
// ============================================================
// در V8، BaseRepository از `(this.prisma as any)[this.modelName]` استفاده
// می‌کرد که autocomplete و compile-time checking را از بین می‌برد.
//
// در V8.1، BaseRepository یک PrismaModelDelegate<T> دریافت می‌کند که
// یک تایپ دقیق از مدل Prisma است. هر Repository در constructor خودش
// delegate را به‌صورت تایپ‌شده ایجاد می‌کند.
//
// مزایا:
//   ✅ autocomplete کامل در IDE
//   ✅ compile-time checking برای نام متدها
//   ✅ اگر نام model اشتباه باشد، خطای TS می‌گیرد (نه runtime)
//   ✅ هیچ `any` لازم نیست
// ============================================================

import { PrismaClient } from '@prisma/client';

/**
 * Prisma Model Delegate — یک wrapper تایپ‌شده حول Prisma Model.
 * این اینترفیس فقط متدهایی که واقعاً در BaseRepository استفاده می‌شوند
 * را تعریف می‌کند تا پیاده‌سازی‌های دیگر (مثلاً Mongo) هم بتوانند آن را
 * پیاده‌سازی کنند.
 */
export interface PrismaModelDelegate<T> {
  findFirst(args?: any): Promise<T | null>;
  findMany(args?: any): Promise<T[]>;
  findUnique(args?: any): Promise<T | null>;
  create(args: { data: any; include?: any }): Promise<T>;
  createMany(args: { data: any[] }): Promise<{ count: number }>;
  update(args: { where: any; data: any; include?: any }): Promise<T>;
  updateMany(args: { where: any; data: any }): Promise<{ count: number }>;
  delete(args: { where: any }): Promise<T>;
  deleteMany(args: { where: any }): Promise<{ count: number }>;
  count(args?: { where?: any }): Promise<number>;
}

/**
 * Helper برای ساخت delegate از روی PrismaClient و نام model.
 * نوع خروجی به‌صورت PrismaModelDelegate<T> است.
 *
 * استفاده:
 *   const delegate = prismaDelegate<Product>(prisma, 'product');
 *
 * در V8.1، هر Repository این کار را در constructor خود انجام می‌دهد:
 *
 *   export class ProductRepository extends BaseRepository<Product> {
 *     constructor(prisma: PrismaClient) {
 *       super(prismaDelegate<Product>(prisma, 'product'));
 *     }
 *   }
 */
export function prismaDelegate<T>(
  prisma: PrismaClient,
  modelName: string,
): PrismaModelDelegate<T> {
  const model = (prisma as any)[modelName];
  if (!model) {
    throw new Error(
      `Prisma model "${modelName}" not found. ` +
      `Make sure prisma generate has been run and the model name is correct.`,
    );
  }
  return model as PrismaModelDelegate<T>;
}

/**
 * Helper برای ساخت delegate از روی Prisma Transaction Client.
 * این تابع در زمان اجرای Unit of Work استفاده می‌شود تا عملیات
 * در همان transaction انجام شوند.
 */
export function prismaTxDelegate<T>(
  txClient: any,
  modelName: string,
): PrismaModelDelegate<T> {
  const model = txClient[modelName];
  if (!model) {
    throw new Error(`Prisma transaction model "${modelName}" not found.`);
  }
  return model as PrismaModelDelegate<T>;
}
