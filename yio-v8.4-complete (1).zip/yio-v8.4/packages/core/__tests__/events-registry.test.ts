// ============================================================
// YIO V8 — Typed Events Registry Tests
// ============================================================

import { describe, it, expect } from 'vitest';
import {
  Events,
  EventName,
  getEventClass,
  getEventName,
  listEventNames,
  isValidEventName,
  OrderCreatedEvent,
  OrderCancelledEvent,
  ProductPublishedEvent,
  DomainEvent,
} from '../src/events';

describe('Typed Events Registry (V8)', () => {
  describe('Events const', () => {
    it('should define all expected event names', () => {
      expect(Events.OrderCreated).toBe('order.created');
      expect(Events.OrderConfirmed).toBe('order.confirmed');
      expect(Events.OrderPaid).toBe('order.paid');
      expect(Events.ProductPublished).toBe('product.published');
      expect(Events.StockUpdated).toBe('inventory.stock_updated');
      expect(Events.WorkflowStarted).toBe('workflow.started');
    });

    it('should not have any duplicate values', () => {
      const values = Object.values(Events);
      const unique = new Set(values);
      expect(values.length).toBe(unique.size);
    });
  });

  describe('getEventName', () => {
    it('should return event name from instance', () => {
      const event = new OrderCreatedEvent(1, 100, 500000, 1);
      expect(getEventName(event)).toBe(Events.OrderCreated);
    });

    it('should throw for unregistered event class', () => {
      class CustomEvent extends DomainEvent {
        get eventName() { return 'custom.unregistered'; }
      }
      expect(() => getEventName(new CustomEvent())).toThrow();
    });
  });

  describe('getEventClass', () => {
    it('should return constructor for known event', () => {
      const ctor = getEventClass(Events.OrderCreated);
      expect(ctor).toBeDefined();
      expect(ctor).toBe(OrderCreatedEvent);
    });

    it('should return undefined for unknown event name', () => {
      const ctor = getEventClass('unknown.event' as EventName);
      expect(ctor).toBeUndefined();
    });
  });

  describe('isValidEventName', () => {
    it('should return true for valid names', () => {
      expect(isValidEventName('order.created')).toBe(true);
      expect(isValidEventName('product.published')).toBe(true);
    });

    it('should return false for invalid names (catch typos)', () => {
      expect(isValidEventName('order.creatd')).toBe(false);  // typo
      expect(isValidEventName('order.publishd')).toBe(false); // wrong event
      expect(isValidEventName('')).toBe(false);
    });
  });

  describe('listEventNames', () => {
    it('should return array of all registered names', () => {
      const names = listEventNames();
      expect(names.length).toBeGreaterThan(20);
      expect(names).toContain(Events.OrderCreated);
      expect(names).toContain(Events.ProductPublished);
    });
  });

  describe('Type Safety at Compile Time', () => {
    // این تست کامپایل-تایم است؛ اگر درست شده باشد یعنی تایپ‌ها کار می‌کنند.
    it('should accept only valid EventName in subscribe', () => {
      // تایپ Events.OrderCreated از نوع EventName است
      const eventName: EventName = Events.OrderCreated;
      expect(eventName).toBe('order.created');

      // این خط اگر از Comment دربیاید نباید کامپایل شود:
      // const bad: EventName = 'order.creatd'; // ❌ TS Error
    });
  });
});
