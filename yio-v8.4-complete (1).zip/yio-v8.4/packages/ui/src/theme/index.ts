// ============================================================
// YIO V8.4 — Shared Theme (Design System)
// ============================================================
// پالت رنگ، تایپوگرافی و استایل مشترک برای همه پنل‌ها
// الهام‌گرفته از دیجی‌کالا — تم مدرن با رنگ قرمز اصلی
// ============================================================

// ===== Primary Color Palette (Red-600 / DigiKala Style) =====
export const COLORS = {
  // ===== Primary (Red — Shop Brand) =====
  primary: {
    50: '#fef2f2',
    100: '#fee2e2',
    200: '#fecaca',
    300: '#fca5a5',
    400: '#f87171',
    500: '#dc2626',  // Primary brand color (red-600)
    600: '#b91c1c',  // Hover color (red-700)
    700: '#991b1b',
    800: '#7f1d1d',
    900: '#450a0a',
  },

  // ===== Neutrals (Gray) =====
  gray: {
    50: '#f9fafb',
    100: '#f3f4f6',
    200: '#e5e7eb',
    300: '#d1d5db',
    400: '#9ca3af',
    500: '#6b7280',
    600: '#4b5563',
    700: '#374151',
    800: '#1f2937',
    900: '#111827',
  },

  // ===== Semantic Colors =====
  success: { 50: '#ecfdf5', 500: '#10b981', 700: '#047857' },
  warning: { 50: '#fffbeb', 500: '#f59e0b', 700: '#b45309' },
  danger: { 50: '#fef2f2', 500: '#ef4444', 700: '#b91c1c' },
  info: { 50: '#eff6ff', 500: '#3b82f6', 700: '#1d4ed8' },

  // ===== Panel-Specific Accents =====
  shop: '#dc2626',      // Red (DigiKala-style storefront)
  crm: '#3b82f6',       // Blue (sales, trust)
  erp: '#10b981',       // Green (production, growth)
  finance: '#8b5cf6',   // Purple (money, premium)
  admin: '#374151',     // Dark gray (authority)
} as const;

// ===== Typography =====
export const TYPOGRAPHY = {
  fontFamily: {
    sans: '"Vazirmatn", system-ui, sans-serif',
    mono: '"Fira Code", "Consolas", monospace',
  },
  fontSize: {
    xs: '0.75rem',      // 12px
    sm: '0.875rem',     // 14px
    base: '1rem',       // 16px
    lg: '1.125rem',     // 18px
    xl: '1.25rem',      // 20px
    '2xl': '1.5rem',    // 24px
    '3xl': '1.875rem',  // 30px
    '4xl': '2.25rem',   // 36px
  },
  fontWeight: {
    normal: 400,
    medium: 500,
    semibold: 600,
    bold: 700,
  },
  lineHeight: {
    tight: 1.25,
    normal: 1.5,
    relaxed: 1.75,
  },
} as const;

// ===== Spacing =====
export const SPACING = {
  xs: '0.25rem',   // 4px
  sm: '0.5rem',    // 8px
  md: '1rem',      // 16px
  lg: '1.5rem',    // 24px
  xl: '2rem',      // 32px
  '2xl': '3rem',   // 48px
  '3xl': '4rem',   // 64px
} as const;

// ===== Shadows =====
export const SHADOWS = {
  sm: '0 1px 2px rgba(0,0,0,0.05)',
  md: '0 4px 6px -1px rgba(0,0,0,0.1)',
  lg: '0 10px 15px -3px rgba(0,0,0,0.1)',
  xl: '0 20px 25px -5px rgba(0,0,0,0.1)',
} as const;

// ===== Border Radius =====
export const RADII = {
  sm: '0.25rem',
  md: '0.5rem',
  lg: '0.75rem',
  xl: '1rem',
  '2xl': '1.5rem',
  full: '9999px',
} as const;

// ===== Transitions =====
export const TRANSITIONS = {
  fast: '150ms',
  base: '250ms',
  slow: '350ms',
} as const;

// ===== Dark Mode Colors =====
export const DARK_COLORS = {
  background: '#0f1115',
  surface: '#1a1d24',
  border: '#2a2f3a',
  text: '#f3f4f6',
  textMuted: '#9ca3af',
} as const;

// ===== Theme Variants for Each Panel =====
export type PanelTheme = 'shop' | 'crm' | 'erp' | 'finance' | 'admin';

export interface ThemeConfig {
  primary: string;
  primaryLight: string;
  primaryDark: string;
  bg: string;
  surface: string;
  text: string;
  textMuted: string;
  border: string;
  sidebarBg: string;
  sidebarActive: string;
  sidebarText: string;
}

export const THEMES: Record<PanelTheme, ThemeConfig> = {
  shop: {
    primary: COLORS.shop,
    primaryLight: COLORS.primary[100],
    primaryDark: COLORS.primary[700],
    bg: '#f0f0f1',
    surface: '#ffffff',
    text: COLORS.gray[900],
    textMuted: COLORS.gray[500],
    border: COLORS.gray[200],
    sidebarBg: '#ffffff',
    sidebarActive: COLORS.shop,
    sidebarText: COLORS.gray[700],
  },
  crm: {
    primary: COLORS.crm,
    primaryLight: '#dbeafe',
    primaryDark: '#1e40af',
    bg: '#f0f4ff',
    surface: '#ffffff',
    text: COLORS.gray[900],
    textMuted: COLORS.gray[500],
    border: COLORS.gray[200],
    sidebarBg: '#1e293b',
    sidebarActive: COLORS.crm,
    sidebarText: '#e2e8f0',
  },
  erp: {
    primary: COLORS.erp,
    primaryLight: '#d1fae5',
    primaryDark: '#065f46',
    bg: '#f0fdf4',
    surface: '#ffffff',
    text: COLORS.gray[900],
    textMuted: COLORS.gray[500],
    border: COLORS.gray[200],
    sidebarBg: '#064e3b',
    sidebarActive: COLORS.erp,
    sidebarText: '#d1fae5',
  },
  finance: {
    primary: COLORS.finance,
    primaryLight: '#ede9fe',
    primaryDark: '#5b21b6',
    bg: '#faf5ff',
    surface: '#ffffff',
    text: COLORS.gray[900],
    textMuted: COLORS.gray[500],
    border: COLORS.gray[200],
    sidebarBg: '#4c1d95',
    sidebarActive: COLORS.finance,
    sidebarText: '#ede9fe',
  },
  admin: {
    primary: COLORS.admin,
    primaryLight: COLORS.gray[200],
    primaryDark: COLORS.gray[800],
    bg: '#f9fafb',
    surface: '#ffffff',
    text: COLORS.gray[900],
    textMuted: COLORS.gray[500],
    border: COLORS.gray[200],
    sidebarBg: COLORS.gray[900],
    sidebarActive: COLORS.gray[700],
    sidebarText: COLORS.gray[300],
  },
};

// ===== Status Colors (for StatusBadge component) =====
export const STATUS_COLORS: Record<string, { bg: string; text: string; label: string }> = {
  // Order Status
  pending: { bg: '#fffbeb', text: '#92400e', label: 'در انتظار' },
  confirmed: { bg: '#dbeafe', text: '#1e40af', label: 'تأیید شده' },
  shipping: { bg: '#ede9fe', text: '#5b21b6', label: 'در حال ارسال' },
  delivered: { bg: '#dcfce7', text: '#166534', label: 'تحویل شده' },
  cancelled: { bg: '#fee2e2', text: '#991b1b', label: 'لغو شده' },

  // Production / Work Order Status
  planned: { bg: '#f3f4f6', text: '#374151', label: 'برنامه‌ریزی شده' },
  in_progress: { bg: '#dbeafe', text: '#1e40af', label: 'در حال انجام' },
  paused: { bg: '#fffbeb', text: '#92400e', label: 'متوقف شده' },
  completed: { bg: '#dcfce7', text: '#166534', label: 'تکمیل شده' },

  // Payment Status
  unpaid: { bg: '#fee2e2', text: '#991b1b', label: 'پرداخت‌نشده' },
  paid: { bg: '#dcfce7', text: '#166534', label: 'پرداخت‌شده' },
  refunded: { bg: '#fffbeb', text: '#92400e', label: 'بازگشت‌داده شده' },

  // Quality
  pass: { bg: '#dcfce7', text: '#166534', label: 'قبول' },
  fail: { bg: '#fee2e2', text: '#991b1b', label: 'رد' },
  rework: { bg: '#fffbeb', text: '#92400e', label: 'اصلاح' },

  // Priority
  high: { bg: '#fee2e2', text: '#991b1b', label: 'بالایی' },
  normal: { bg: '#dbeafe', text: '#1e40af', label: 'معمولی' },
  low: { bg: '#f3f4f6', text: '#374151', label: 'پایین' },

  // Generic / Fallbacks
  warning: { bg: '#fffbeb', text: '#92400e', label: 'هشدار' },
  success: { bg: '#dcfce7', text: '#166534', label: 'موفق' },
  error: { bg: '#fee2e2', text: '#991b1b', label: 'خطا' },
  info: { bg: '#dbeafe', text: '#1e40af', label: 'اطلاع' },
  operational: { bg: '#dcfce7', text: '#166534', label: 'عملیاتی' },
  degraded: { bg: '#fffbeb', text: '#92400e', label: 'کند' },
  down: { bg: '#fee2e2', text: '#991b1b', label: 'قطع' },
};
