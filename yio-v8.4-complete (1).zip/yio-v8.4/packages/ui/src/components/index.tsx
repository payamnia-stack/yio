// ============================================================
// YIO V8.4 — Shared UI Components
// ============================================================
// کامپوننت‌های مشترک برای همه پنل‌ها
// الهام‌گرفته از دیجی‌کالا — تم مدرن با RTL کامل
// ============================================================

import React, { useState, useEffect, useRef } from 'react';
import {
  COLORS,
  SPACING,
  SHADOWS,
  RADII,
  TRANSITIONS,
  TYPOGRAPHY,
  STATUS_COLORS,
} from '../theme';

// ===== Theme Context (per-app primary color override) =====
const DEFAULT_PRIMARY = COLORS.primary[500];
const DEFAULT_PRIMARY_DARK = COLORS.primary[600];

interface ThemeOverride {
  primaryColor?: string;
}

const ThemeContext = React.createContext<ThemeOverride>({});

export { ThemeContext };

export function usePrimaryColor(): string {
  const ctx = React.useContext(ThemeContext);
  return ctx.primaryColor || DEFAULT_PRIMARY;
}
// ============================================================
// Spinner
// ============================================================
export interface SpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  color?: string;
}

export function Spinner({ size = 'md', color }: SpinnerProps) {
  const sizes = { sm: '16px', md: '24px', lg: '32px' };
  const primary = color || usePrimaryColor();
  return (
    <div
      style={{
        width: sizes[size],
        height: sizes[size],
        border: `2px solid ${COLORS.gray[200]}`,
        borderTopColor: primary,
        borderRadius: '50%',
        animation: 'yio-spin 0.8s linear infinite',
        display: 'inline-block',
      }}
    />
  );
}

// ============================================================
// Button
// ============================================================
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger' | 'success';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  icon?: React.ReactNode;
  fullWidth?: boolean;
  primaryColor?: string;
}

export function Button({
  variant = 'primary',
  size = 'md',
  loading = false,
  icon,
  fullWidth = false,
  primaryColor,
  children,
  style,
  ...props
}: ButtonProps) {
  const themePrimary = usePrimaryColor();
  const primary = primaryColor || themePrimary;
  const primaryDark = primaryColor ? shadeColor(primaryColor, -15) : COLORS.primary[600];

  const sizes = {
    sm: { padding: `${SPACING.xs} ${SPACING.md}`, fontSize: TYPOGRAPHY.fontSize.sm },
    md: { padding: `${SPACING.sm} ${SPACING.lg}`, fontSize: TYPOGRAPHY.fontSize.base },
    lg: { padding: `${SPACING.md} ${SPACING.xl}`, fontSize: TYPOGRAPHY.fontSize.lg },
  };

  const variants: Record<string, React.CSSProperties> = {
    primary: { backgroundColor: primary, color: '#fff', border: 'none' },
    secondary: {
      backgroundColor: COLORS.gray[100],
      color: COLORS.gray[900],
      border: `1px solid ${COLORS.gray[200]}`,
    },
    outline: {
      backgroundColor: 'transparent',
      color: primary,
      border: `1px solid ${primary}`,
    },
    ghost: {
      backgroundColor: 'transparent',
      color: COLORS.gray[700],
      border: 'none',
    },
    danger: { backgroundColor: COLORS.danger[500], color: '#fff', border: 'none' },
    success: { backgroundColor: COLORS.success[500], color: '#fff', border: 'none' },
  };

  return (
    <button
      style={{
        ...sizes[size],
        ...variants[variant],
        borderRadius: RADII.md,
        fontWeight: TYPOGRAPHY.fontWeight.medium,
        cursor: loading ? 'wait' : 'pointer',
        opacity: loading ? 0.7 : 1,
        width: fullWidth ? '100%' : 'auto',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: SPACING.sm,
        transition: `all ${TRANSITIONS.fast}`,
        boxShadow: variant === 'primary' || variant === 'danger' || variant === 'success' ? SHADOWS.sm : 'none',
        fontFamily: TYPOGRAPHY.fontFamily.sans,
        ...style,
      }}
      onMouseEnter={(e) => {
        if (!loading && !props.disabled) {
          if (variant === 'primary') e.currentTarget.style.backgroundColor = primaryDark;
          if (variant === 'outline' || variant === 'ghost') e.currentTarget.style.backgroundColor = `${primary}11`;
        }
      }}
      onMouseLeave={(e) => {
        if (!loading && !props.disabled) {
          if (variant === 'primary') e.currentTarget.style.backgroundColor = primary;
          if (variant === 'outline' || variant === 'ghost') e.currentTarget.style.backgroundColor = 'transparent';
        }
      }}
      disabled={loading || props.disabled}
      {...props}
    >
      {loading && <Spinner size={size === 'lg' ? 'md' : 'sm'} color={variant === 'primary' || variant === 'danger' || variant === 'success' ? '#fff' : primary} />}
      {icon && !loading && icon}
      {children}
    </button>
  );
}

// ============================================================
// Card
// ============================================================
export interface CardProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'title'> {
  hoverable?: boolean;
  padding?: 'sm' | 'md' | 'lg' | 'none';
  title?: React.ReactNode;
  subtitle?: React.ReactNode;
  actions?: React.ReactNode;
}

export function Card({
  hoverable = false,
  padding = 'md',
  title,
  subtitle,
  actions,
  children,
  style,
  ...props
}: CardProps) {
  const paddings = {
    none: '0',
    sm: SPACING.md,
    md: SPACING.lg,
    lg: SPACING.xl,
  };

  const hasHeader = title || actions;

  return (
    <div
      style={{
        backgroundColor: '#fff',
        borderRadius: RADII.xl,
        boxShadow: SHADOWS.sm,
        transition: `all ${TRANSITIONS.base}`,
        cursor: hoverable ? 'pointer' : 'default',
        border: `1px solid ${COLORS.gray[100]}`,
        overflow: 'hidden',
        ...style,
      }}
      onMouseEnter={hoverable ? (e) => { e.currentTarget.style.boxShadow = SHADOWS.lg; e.currentTarget.style.transform = 'translateY(-2px)'; } : undefined}
      onMouseLeave={hoverable ? (e) => { e.currentTarget.style.boxShadow = SHADOWS.sm; e.currentTarget.style.transform = 'translateY(0)'; } : undefined}
      {...props}
    >
      {hasHeader && (
        <div
          style={{
            padding: `${SPACING.md} ${paddings[padding]}`,
            borderBottom: `1px solid ${COLORS.gray[100]}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: SPACING.md,
          }}
        >
          <div>
            {title && (
              <h3 style={{ fontSize: TYPOGRAPHY.fontSize.lg, fontWeight: TYPOGRAPHY.fontWeight.semibold, color: COLORS.gray[900], margin: 0 }}>
                {title}
              </h3>
            )}
            {subtitle && (
              <p style={{ fontSize: TYPOGRAPHY.fontSize.sm, color: COLORS.gray[500], margin: 0, marginTop: SPACING.xs }}>
                {subtitle}
              </p>
            )}
          </div>
          {actions && <div style={{ display: 'flex', gap: SPACING.sm, flexShrink: 0 }}>{actions}</div>}
        </div>
      )}
      <div style={{ padding: paddings[padding] }}>{children}</div>
    </div>
  );
}

// ============================================================
// Badge
// ============================================================
export interface BadgeProps {
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'info';
  size?: 'sm' | 'md';
  children: React.ReactNode;
}

export function Badge({ variant = 'default', size = 'md', children }: BadgeProps) {
  const variants: Record<string, React.CSSProperties> = {
    default: { backgroundColor: COLORS.gray[100], color: COLORS.gray[700] },
    success: { backgroundColor: COLORS.success[50], color: COLORS.success[700] },
    warning: { backgroundColor: COLORS.warning[50], color: COLORS.warning[700] },
    danger: { backgroundColor: COLORS.danger[50], color: COLORS.danger[700] },
    info: { backgroundColor: COLORS.info[50], color: COLORS.info[700] },
  };

  const sizes = {
    sm: { padding: '2px 8px', fontSize: TYPOGRAPHY.fontSize.xs },
    md: { padding: '4px 12px', fontSize: TYPOGRAPHY.fontSize.sm },
  };

  return (
    <span
      style={{
        ...variants[variant],
        ...sizes[size],
        borderRadius: RADII.full,
        fontWeight: TYPOGRAPHY.fontWeight.medium,
        display: 'inline-flex',
        alignItems: 'center',
        whiteSpace: 'nowrap',
      }}
    >
      {children}
    </span>
  );
}

// ============================================================
// Status Badge
// ============================================================
export function StatusBadge({ status }: { status: string }) {
  const config = STATUS_COLORS[status] || {
    bg: COLORS.gray[100],
    text: COLORS.gray[700],
    label: status,
  };
  return (
    <span
      style={{
        backgroundColor: config.bg,
        color: config.text,
        padding: '4px 12px',
        borderRadius: RADII.full,
        fontSize: TYPOGRAPHY.fontSize.sm,
        fontWeight: TYPOGRAPHY.fontWeight.medium,
        display: 'inline-flex',
        alignItems: 'center',
        whiteSpace: 'nowrap',
      }}
    >
      {config.label}
    </span>
  );
}

// ============================================================
// Input
// ============================================================
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  icon?: React.ReactNode;
  hint?: string;
  primaryColor?: string;
}

export function Input({ label, error, icon, hint, primaryColor, style, ...props }: InputProps) {
  const themePrimary = usePrimaryColor();
  const primary = primaryColor || themePrimary;
  return (
    <div style={{ marginBottom: SPACING.md }}>
      {label && (
        <label style={{ display: 'block', marginBottom: SPACING.xs, fontWeight: TYPOGRAPHY.fontWeight.medium, color: COLORS.gray[700], fontSize: TYPOGRAPHY.fontSize.sm }}>
          {label}
        </label>
      )}
      <div style={{ position: 'relative' }}>
        {icon && (
          <div style={{ position: 'absolute', right: SPACING.md, top: '50%', transform: 'translateY(-50%)', color: COLORS.gray[400], pointerEvents: 'none' }}>
            {icon}
          </div>
        )}
        <input
          style={{
            width: '100%',
            padding: `${SPACING.sm} ${SPACING.md}`,
            paddingRight: icon ? '2.5rem' : SPACING.md,
            borderRadius: RADII.md,
            border: `1px solid ${error ? COLORS.danger[500] : COLORS.gray[300]}`,
            fontSize: TYPOGRAPHY.fontSize.base,
            outline: 'none',
            transition: `all ${TRANSITIONS.fast}`,
            fontFamily: TYPOGRAPHY.fontFamily.sans,
            backgroundColor: '#fff',
            boxSizing: 'border-box',
            ...style,
          }}
          onFocus={(e) => {
            e.currentTarget.style.borderColor = primary;
            e.currentTarget.style.boxShadow = `0 0 0 3px ${primary}22`;
          }}
          onBlur={(e) => {
            e.currentTarget.style.borderColor = error ? COLORS.danger[500] : COLORS.gray[300];
            e.currentTarget.style.boxShadow = 'none';
          }}
          {...props}
        />
      </div>
      {error && <p style={{ marginTop: SPACING.xs, color: COLORS.danger[500], fontSize: TYPOGRAPHY.fontSize.sm }}>{error}</p>}
      {hint && !error && <p style={{ marginTop: SPACING.xs, color: COLORS.gray[500], fontSize: TYPOGRAPHY.fontSize.sm }}>{hint}</p>}
    </div>
  );
}

// ============================================================
// Select
// ============================================================
export interface SelectOption {
  value: string | number;
  label: string;
}

export interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
  options: SelectOption[];
  placeholder?: string;
  primaryColor?: string;
}

export function Select({ label, error, options, placeholder, primaryColor, style, ...props }: SelectProps) {
  const themePrimary = usePrimaryColor();
  const primary = primaryColor || themePrimary;
  return (
    <div style={{ marginBottom: SPACING.md }}>
      {label && (
        <label style={{ display: 'block', marginBottom: SPACING.xs, fontWeight: TYPOGRAPHY.fontWeight.medium, color: COLORS.gray[700], fontSize: TYPOGRAPHY.fontSize.sm }}>
          {label}
        </label>
      )}
      <div style={{ position: 'relative' }}>
        <select
          style={{
            width: '100%',
            padding: `${SPACING.sm} ${SPACING.md}`,
            paddingLeft: '2rem',
            borderRadius: RADII.md,
            border: `1px solid ${error ? COLORS.danger[500] : COLORS.gray[300]}`,
            fontSize: TYPOGRAPHY.fontSize.base,
            outline: 'none',
            transition: `all ${TRANSITIONS.fast}`,
            fontFamily: TYPOGRAPHY.fontFamily.sans,
            backgroundColor: '#fff',
            boxSizing: 'border-box',
            appearance: 'none',
            cursor: 'pointer',
            backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%236b7280' stroke-width='2'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E")`,
            backgroundRepeat: 'no-repeat',
            backgroundPosition: `left ${SPACING.md} center`,
            ...style,
          }}
          onFocus={(e) => {
            e.currentTarget.style.borderColor = primary;
            e.currentTarget.style.boxShadow = `0 0 0 3px ${primary}22`;
          }}
          onBlur={(e) => {
            e.currentTarget.style.borderColor = error ? COLORS.danger[500] : COLORS.gray[300];
            e.currentTarget.style.boxShadow = 'none';
          }}
          {...props}
        >
          {placeholder && <option value="">{placeholder}</option>}
          {options.map((opt) => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
      </div>
      {error && <p style={{ marginTop: SPACING.xs, color: COLORS.danger[500], fontSize: TYPOGRAPHY.fontSize.sm }}>{error}</p>}
    </div>
  );
}

// ============================================================
// Modal
// ============================================================
export interface ModalProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  primaryColor?: string;
}

export function Modal({ open, onClose, title, children, footer, size = 'md', primaryColor }: ModalProps) {
  const [visible, setVisible] = useState(false);
  const themePrimary = usePrimaryColor();
  const primary = primaryColor || themePrimary;

  useEffect(() => {
    if (open) {
      setVisible(true);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
      const t = setTimeout(() => setVisible(false), 200);
      return () => clearTimeout(t);
    }
  }, [open]);

  if (!open && !visible) return null;

  const sizes = {
    sm: '400px',
    md: '600px',
    lg: '800px',
    xl: '1000px',
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        backdropFilter: 'blur(2px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1000,
        padding: SPACING.lg,
        opacity: open ? 1 : 0,
        transition: `opacity ${TRANSITIONS.base}`,
      }}
      onClick={onClose}
    >
      <div
        style={{
          backgroundColor: '#fff',
          borderRadius: RADII.xl,
          boxShadow: SHADOWS.xl,
          width: '100%',
          maxWidth: sizes[size],
          maxHeight: '90vh',
          overflow: 'auto',
          transform: open ? 'scale(1)' : 'scale(0.95)',
          transition: `transform ${TRANSITIONS.base}`,
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {(title || true) && (
          <div style={{
            padding: `${SPACING.md} ${SPACING.lg}`,
            borderBottom: `1px solid ${COLORS.gray[100]}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: SPACING.md,
          }}>
            <h3 style={{ margin: 0, fontWeight: TYPOGRAPHY.fontWeight.semibold, fontSize: TYPOGRAPHY.fontSize.lg, color: COLORS.gray[900] }}>
              {title}
            </h3>
            <button
              onClick={onClose}
              style={{
                width: '32px',
                height: '32px',
                borderRadius: RADII.md,
                border: 'none',
                backgroundColor: COLORS.gray[100],
                color: COLORS.gray[600],
                cursor: 'pointer',
                fontSize: '1.25rem',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: `all ${TRANSITIONS.fast}`,
              }}
              onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = COLORS.gray[200]; }}
              onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = COLORS.gray[100]; }}
            >
              ×
            </button>
          </div>
        )}
        <div style={{ padding: SPACING.lg }}>{children}</div>
        {footer && (
          <div style={{
            padding: SPACING.lg,
            borderTop: `1px solid ${COLORS.gray[100]}`,
            display: 'flex',
            gap: SPACING.sm,
            justifyContent: 'flex-end',
          }}>
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================
// Drawer (slide-in panel)
// ============================================================
export interface DrawerProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  side?: 'right' | 'left';
  width?: string;
  primaryColor?: string;
}

export function Drawer({ open, onClose, title, children, footer, side = 'right', width = '420px', primaryColor }: DrawerProps) {
  const [visible, setVisible] = useState(false);
  const themePrimary = usePrimaryColor();
  const primary = primaryColor || themePrimary;

  useEffect(() => {
    if (open) {
      setVisible(true);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
      const t = setTimeout(() => setVisible(false), 250);
      return () => clearTimeout(t);
    }
  }, [open]);

  if (!open && !visible) return null;

  const isRight = side === 'right';

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 1000,
        display: 'flex',
        justifyContent: isRight ? 'flex-start' : 'flex-end',
      }}
    >
      {/* Overlay */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          backdropFilter: 'blur(2px)',
          opacity: open ? 1 : 0,
          transition: `opacity ${TRANSITIONS.base}`,
        }}
        onClick={onClose}
      />
      {/* Drawer panel */}
      <div
        style={{
          position: 'relative',
          backgroundColor: '#fff',
          width,
          maxWidth: '90vw',
          height: '100vh',
          boxShadow: SHADOWS.xl,
          display: 'flex',
          flexDirection: 'column',
          transform: open ? 'translateX(0)' : `translateX(${isRight ? '-100%' : '100%'})`,
          transition: `transform ${TRANSITIONS.base}`,
          borderInlineStart: !isRight ? `4px solid ${primary}` : 'none',
          borderInlineEnd: isRight ? `4px solid ${primary}` : 'none',
        }}
      >
        {/* Header */}
        <div style={{
          padding: `${SPACING.md} ${SPACING.lg}`,
          borderBottom: `1px solid ${COLORS.gray[100]}`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: SPACING.md,
          flexShrink: 0,
        }}>
          <h3 style={{ margin: 0, fontWeight: TYPOGRAPHY.fontWeight.semibold, fontSize: TYPOGRAPHY.fontSize.lg, color: COLORS.gray[900] }}>
            {title}
          </h3>
          <button
            onClick={onClose}
            style={{
              width: '32px',
              height: '32px',
              borderRadius: RADII.md,
              border: 'none',
              backgroundColor: COLORS.gray[100],
              color: COLORS.gray[600],
              cursor: 'pointer',
              fontSize: '1.25rem',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: `all ${TRANSITIONS.fast}`,
            }}
            onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = COLORS.gray[200]; }}
            onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = COLORS.gray[100]; }}
          >
            ×
          </button>
        </div>
        {/* Body */}
        <div style={{ flex: 1, overflowY: 'auto', padding: SPACING.lg }}>
          {children}
        </div>
        {/* Footer */}
        {footer && (
          <div style={{
            padding: SPACING.lg,
            borderTop: `1px solid ${COLORS.gray[100]}`,
            display: 'flex',
            gap: SPACING.sm,
            justifyContent: 'flex-end',
            flexShrink: 0,
          }}>
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================================
// Tabs
// ============================================================
export interface TabItem {
  key: string;
  label: React.ReactNode;
  icon?: React.ReactNode;
  badge?: React.ReactNode;
}

export interface TabsProps {
  items: TabItem[];
  active: string;
  onChange: (key: string) => void;
  primaryColor?: string;
}

export function Tabs({ items, active, onChange, primaryColor }: TabsProps) {
  const themePrimary = usePrimaryColor();
  const primary = primaryColor || themePrimary;
  return (
    <div style={{
      display: 'flex',
      gap: SPACING.xs,
      borderBottom: `1px solid ${COLORS.gray[200]}`,
      overflowX: 'auto',
    }}>
      {items.map((item) => {
        const isActive = item.key === active;
        return (
          <button
            key={item.key}
            onClick={() => onChange(item.key)}
            style={{
              padding: `${SPACING.sm} ${SPACING.md}`,
              backgroundColor: 'transparent',
              border: 'none',
              borderBottom: `2px solid ${isActive ? primary : 'transparent'}`,
              color: isActive ? primary : COLORS.gray[600],
              fontWeight: isActive ? TYPOGRAPHY.fontWeight.semibold : TYPOGRAPHY.fontWeight.medium,
              fontSize: TYPOGRAPHY.fontSize.sm,
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: SPACING.xs,
              transition: `all ${TRANSITIONS.fast}`,
              whiteSpace: 'nowrap',
              marginBottom: '-1px',
            }}
            onMouseEnter={(e) => { if (!isActive) e.currentTarget.style.color = COLORS.gray[900]; }}
            onMouseLeave={(e) => { if (!isActive) e.currentTarget.style.color = COLORS.gray[600]; }}
          >
            {item.icon && <span>{item.icon}</span>}
            <span>{item.label}</span>
            {item.badge != null && (
              <span style={{
                backgroundColor: isActive ? primary : COLORS.gray[200],
                color: isActive ? '#fff' : COLORS.gray[700],
                padding: '0 6px',
                borderRadius: RADII.full,
                fontSize: TYPOGRAPHY.fontSize.xs,
                fontWeight: TYPOGRAPHY.fontWeight.semibold,
                minWidth: '18px',
                textAlign: 'center',
              }}>
                {item.badge}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}

// ============================================================
// Empty State
// ============================================================
export function EmptyState({ title, description, icon, action }: {
  title: string;
  description?: string;
  icon?: React.ReactNode;
  action?: React.ReactNode;
}) {
  return (
    <div style={{ textAlign: 'center', padding: SPACING['3xl'], color: COLORS.gray[500] }}>
      {icon && <div style={{ marginBottom: SPACING.lg, fontSize: '3rem' }}>{icon}</div>}
      <h3 style={{ color: COLORS.gray[700], marginBottom: SPACING.sm, fontSize: TYPOGRAPHY.fontSize.lg, fontWeight: TYPOGRAPHY.fontWeight.semibold }}>{title}</h3>
      {description && <p style={{ marginBottom: SPACING.lg, fontSize: TYPOGRAPHY.fontSize.sm, lineHeight: TYPOGRAPHY.lineHeight.relaxed }}>{description}</p>}
      {action}
    </div>
  );
}

// ============================================================
// KPI Card
// ============================================================
export interface KpiCardProps {
  title: string;
  value: string | number;
  unit?: string;
  trend?: { value: number; isPositive: boolean };
  icon?: React.ReactNode;
  color?: string;
}

export function KpiCard({ title, value, unit, trend, icon, color }: KpiCardProps) {
  const themePrimary = usePrimaryColor();
  const accent = color || themePrimary;
  return (
    <Card hoverable>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: SPACING.md }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ color: COLORS.gray[500], fontSize: TYPOGRAPHY.fontSize.sm, marginBottom: SPACING.xs, margin: 0 }}>
            {title}
          </p>
          <p style={{ fontSize: TYPOGRAPHY.fontSize['2xl'], fontWeight: TYPOGRAPHY.fontWeight.bold, color: COLORS.gray[900], margin: 0 }}>
            {value}
            {unit && <span style={{ fontSize: TYPOGRAPHY.fontSize.sm, color: COLORS.gray[500], marginRight: SPACING.xs, fontWeight: TYPOGRAPHY.fontWeight.normal }}>{unit}</span>}
          </p>
          {trend && (
            <p style={{
              marginTop: SPACING.xs,
              fontSize: TYPOGRAPHY.fontSize.sm,
              color: trend.isPositive ? COLORS.success[700] : COLORS.danger[700],
              display: 'inline-flex',
              alignItems: 'center',
              gap: '4px',
              backgroundColor: trend.isPositive ? COLORS.success[50] : COLORS.danger[50],
              padding: '2px 8px',
              borderRadius: RADII.full,
              fontWeight: TYPOGRAPHY.fontWeight.medium,
            }}>
              <span>{trend.isPositive ? '▲' : '▼'}</span>
              <span>{Math.abs(trend.value)}٪</span>
              <span style={{ color: COLORS.gray[500], fontWeight: TYPOGRAPHY.fontWeight.normal }}>نسبت به دیروز</span>
            </p>
          )}
        </div>
        {icon && (
          <div style={{
            backgroundColor: `${accent}15`,
            color: accent,
            padding: SPACING.md,
            borderRadius: RADII.lg,
            fontSize: '1.5rem',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0,
          }}>
            {icon}
          </div>
        )}
      </div>
    </Card>
  );
}

// ============================================================
// Table
// ============================================================
export interface TableColumn {
  key: string;
  title: string;
  width?: string;
  render?: (row: any) => React.ReactNode;
}

export interface TableProps {
  columns: TableColumn[];
  data: any[];
  loading?: boolean;
  emptyText?: string;
  onRowClick?: (row: any) => void;
  pagination?: {
    page: number;
    pageSize: number;
    total: number;
    onPageChange: (page: number) => void;
  };
}

export function Table({ columns, data, loading = false, emptyText = 'داده‌ای یافت نشد', onRowClick, pagination }: TableProps) {
  if (loading) {
    return (
      <div style={{ padding: SPACING.xl, textAlign: 'center' }}>
        <Spinner size="lg" />
      </div>
    );
  }

  if (data.length === 0) {
    return <EmptyState title={emptyText} icon="📭" />;
  }

  return (
    <div>
      <div style={{ overflowX: 'auto', borderRadius: RADII.lg, border: `1px solid ${COLORS.gray[200]}` }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ backgroundColor: COLORS.gray[50] }}>
              {columns.map((col) => (
                <th
                  key={col.key}
                  style={{
                    padding: `${SPACING.sm} ${SPACING.md}`,
                    textAlign: 'right',
                    fontWeight: TYPOGRAPHY.fontWeight.semibold,
                    color: COLORS.gray[700],
                    borderBottom: `2px solid ${COLORS.gray[200]}`,
                    width: col.width,
                    fontSize: TYPOGRAPHY.fontSize.sm,
                    whiteSpace: 'nowrap',
                  }}
                >
                  {col.title}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row, i) => (
              <tr
                key={i}
                onClick={() => onRowClick?.(row)}
                style={{
                  cursor: onRowClick ? 'pointer' : 'default',
                  transition: `background-color ${TRANSITIONS.fast}`,
                }}
                onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = COLORS.gray[50]; }}
                onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
              >
                {columns.map((col) => (
                  <td
                    key={col.key}
                    style={{
                      padding: `${SPACING.md}`,
                      borderBottom: `1px solid ${COLORS.gray[100]}`,
                      color: COLORS.gray[700],
                      fontSize: TYPOGRAPHY.fontSize.sm,
                    }}
                  >
                    {col.render ? col.render(row) : row[col.key]}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {pagination && (
        <Pagination
          page={pagination.page}
          pageSize={pagination.pageSize}
          total={pagination.total}
          onPageChange={pagination.onPageChange}
        />
      )}
    </div>
  );
}

// ============================================================
// Pagination
// ============================================================
export function Pagination({ page, pageSize, total, onPageChange }: {
  page: number;
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
}) {
  const totalPages = Math.ceil(total / pageSize);
  if (totalPages <= 1) return null;

  const pages: number[] = [];
  const start = Math.max(1, page - 2);
  const end = Math.min(totalPages, page + 2);
  for (let i = start; i <= end; i++) pages.push(i);

  const btnBase: React.CSSProperties = {
    minWidth: '32px',
    height: '32px',
    padding: `0 ${SPACING.sm}`,
    borderRadius: RADII.md,
    border: `1px solid ${COLORS.gray[300]}`,
    backgroundColor: '#fff',
    color: COLORS.gray[700],
    cursor: 'pointer',
    fontSize: TYPOGRAPHY.fontSize.sm,
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: `all ${TRANSITIONS.fast}`,
  };

  const primary = usePrimaryColor();

  return (
    <div style={{ display: 'flex', gap: SPACING.xs, justifyContent: 'center', alignItems: 'center', marginTop: SPACING.lg, flexWrap: 'wrap' }}>
      <button
        style={{ ...btnBase, opacity: page === 1 ? 0.5 : 1, cursor: page === 1 ? 'not-allowed' : 'pointer' }}
        disabled={page === 1}
        onClick={() => onPageChange(page - 1)}
      >
        قبلی
      </button>
      {pages.map((p) => (
        <button
          key={p}
          onClick={() => onPageChange(p)}
          style={{
            ...btnBase,
            ...(p === page ? {
              backgroundColor: primary,
              color: '#fff',
              borderColor: primary,
              fontWeight: TYPOGRAPHY.fontWeight.semibold,
            } : {}),
          }}
        >
          {p}
        </button>
      ))}
      <button
        style={{ ...btnBase, opacity: page === totalPages ? 0.5 : 1, cursor: page === totalPages ? 'not-allowed' : 'pointer' }}
        disabled={page === totalPages}
        onClick={() => onPageChange(page + 1)}
      >
        بعدی
      </button>
    </div>
  );
}

// ============================================================
// Page Container
// ============================================================
export function PageContainer({ title, subtitle, actions, children }: {
  title?: string;
  subtitle?: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div>
      {(title || actions) && (
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: SPACING.xl, gap: SPACING.md, flexWrap: 'wrap' }}>
          <div>
            {title && <h1 style={{ fontSize: TYPOGRAPHY.fontSize['2xl'], fontWeight: TYPOGRAPHY.fontWeight.bold, color: COLORS.gray[900], margin: 0 }}>{title}</h1>}
            {subtitle && <p style={{ color: COLORS.gray[500], fontSize: TYPOGRAPHY.fontSize.sm, margin: 0, marginTop: SPACING.xs }}>{subtitle}</p>}
          </div>
          {actions && <div style={{ display: 'flex', gap: SPACING.sm, flexShrink: 0 }}>{actions}</div>}
        </div>
      )}
      {children}
    </div>
  );
}

// ============================================================
// Alert
// ============================================================
export function Alert({ type = 'info', title, message, onClose }: {
  type?: 'info' | 'success' | 'warning' | 'danger';
  title?: string;
  message: string;
  onClose?: () => void;
}) {
  const types = {
    info: { bg: COLORS.info[50], border: COLORS.info[500], icon: 'ℹ️' },
    success: { bg: COLORS.success[50], border: COLORS.success[500], icon: '✅' },
    warning: { bg: COLORS.warning[50], border: COLORS.warning[500], icon: '⚠️' },
    danger: { bg: COLORS.danger[50], border: COLORS.danger[500], icon: '❌' },
  };

  const config = types[type];

  return (
    <div
      style={{
        backgroundColor: config.bg,
        border: `1px solid ${config.border}33`,
        borderInlineStart: `4px solid ${config.border}`,
        borderRadius: RADII.md,
        padding: SPACING.md,
        display: 'flex',
        alignItems: 'flex-start',
        gap: SPACING.sm,
      }}
    >
      <span style={{ fontSize: '1.25rem', flexShrink: 0 }}>{config.icon}</span>
      <div style={{ flex: 1 }}>
        {title && <p style={{ fontWeight: TYPOGRAPHY.fontWeight.semibold, marginBottom: SPACING.xs, margin: 0, color: COLORS.gray[900] }}>{title}</p>}
        <p style={{ color: COLORS.gray[700], margin: 0, fontSize: TYPOGRAPHY.fontSize.sm, lineHeight: TYPOGRAPHY.lineHeight.relaxed }}>{message}</p>
      </div>
      {onClose && (
        <button
          onClick={onClose}
          style={{
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            fontSize: '1.25rem',
            color: COLORS.gray[500],
            padding: 0,
            lineHeight: 1,
          }}
        >
          ×
        </button>
      )}
    </div>
  );
}

// ============================================================
// Helper: darken/lighten hex color
// ============================================================
function shadeColor(hex: string, percent: number): string {
  let c = hex.replace('#', '');
  if (c.length === 3) {
    c = c.split('').map((x) => x + x).join('');
  }
  const num = parseInt(c, 16);
  const amt = Math.round(2.55 * percent);
  const R = (num >> 16) + amt;
  const G = ((num >> 8) & 0x00ff) + amt;
  const B = (num & 0x0000ff) + amt;
  const clamp = (v: number) => Math.max(0, Math.min(255, v));
  return '#' + (0x1000000 + (clamp(R) << 16) + (clamp(G) << 8) + clamp(B)).toString(16).slice(1);
}

// ============================================================
// Export Theme Tokens
// ============================================================
export { COLORS, SPACING, SHADOWS, RADII, TRANSITIONS, TYPOGRAPHY, STATUS_COLORS, DARK_COLORS, THEMES } from '../theme';
export type { PanelTheme, ThemeConfig } from '../theme';

// ============================================================
// Export Panel Layout
// ============================================================
export * from './panel-layout';
