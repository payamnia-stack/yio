// ============================================================
// YIO V8.4 — Shared Panel Layout
// ============================================================
// چیدمان مشترک برای پنل‌های مدیریت (CRM, ERP, Finance, Admin)
// شامل: Sidebar (Collapsible), Header, Breadcrumb, Content, Footer
// با پشتیبانی از primaryColor سفارشی برای هر پنل
// ============================================================

import React, { useState, useEffect, useRef } from 'react';
import {
  COLORS,
  SPACING,
  SHADOWS,
  RADII,
  TRANSITIONS,
  TYPOGRAPHY,
  THEMES,
  PanelTheme,
} from '../theme';
import { Button, Badge } from '../components';
import { ThemeContext } from '../components';

// ===== Nav Item =====
export interface NavItem {
  label: string;
  icon?: React.ReactNode;
  href?: string;
  badge?: string | number;
  active?: boolean;
  onClick?: () => void;
  children?: NavItem[];
}

// ===== Breadcrumb =====
export interface BreadcrumbItem {
  label: string;
  href?: string;
  onClick?: () => void;
}

export function Breadcrumb({ items }: { items: BreadcrumbItem[] }) {
  if (!items || items.length === 0) return null;
  return (
    <nav style={{
      display: 'flex',
      alignItems: 'center',
      gap: SPACING.xs,
      fontSize: TYPOGRAPHY.fontSize.sm,
      color: COLORS.gray[500],
      marginBottom: SPACING.md,
      flexWrap: 'wrap',
    }}>
      {items.map((item, i) => {
        const isLast = i === items.length - 1;
        return (
          <React.Fragment key={i}>
            <span
              style={{
                color: isLast ? COLORS.gray[900] : COLORS.gray[500],
                fontWeight: isLast ? TYPOGRAPHY.fontWeight.medium : TYPOGRAPHY.fontWeight.normal,
                cursor: item.href || item.onClick ? 'pointer' : 'default',
                transition: `color ${TRANSITIONS.fast}`,
              }}
              onClick={() => {
                if (item.onClick) item.onClick();
              }}
            >
              {item.label}
            </span>
            {!isLast && (
              <span style={{ color: COLORS.gray[400], margin: '0 4px' }}>/</span>
            )}
          </React.Fragment>
        );
      })}
    </nav>
  );
}

// ===== Panel Layout Props =====
export interface PanelLayoutProps {
  theme: PanelTheme;
  title: string;
  navItems: NavItem[];
  primaryColor?: string;     // Override primary color (used by Button, Input, etc.)
  user?: { name: string; role: string; avatar?: string };
  notifications?: number;
  onLogout?: () => void;
  onSearch?: (query: string) => void;
  breadcrumbs?: BreadcrumbItem[];
  footer?: React.ReactNode;
  children: React.ReactNode;
}

export function PanelLayout({
  theme,
  title,
  navItems,
  primaryColor,
  user,
  notifications = 0,
  onLogout,
  onSearch,
  breadcrumbs,
  footer,
  children,
}: PanelLayoutProps) {
  const themeConfig = THEMES[theme];
  const primary = primaryColor || themeConfig.primary;
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on outside click
  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setUserMenuOpen(false);
      }
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotifOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch?.(searchQuery);
  };

  return (
    <ThemeContext.Provider value={{ primaryColor: primary }}>
      <div style={{
        display: 'flex',
        minHeight: '100vh',
        backgroundColor: themeConfig.bg,
        direction: 'rtl',
        fontFamily: TYPOGRAPHY.fontFamily.sans,
      }}>
        {/* ===== Sidebar (desktop) ===== */}
        <aside
          style={{
            width: sidebarOpen ? '260px' : '72px',
            backgroundColor: themeConfig.sidebarBg,
            color: themeConfig.sidebarText,
            transition: `width ${TRANSITIONS.base}`,
            display: 'flex',
            flexDirection: 'column',
            position: 'sticky',
            top: 0,
            height: '100vh',
            overflow: 'hidden',
            flexShrink: 0,
            borderInlineStart: 'none',
          }}
          className="yio-sidebar-desktop"
        >
          {/* Logo / Brand */}
          <div
            style={{
              padding: SPACING.lg,
              display: 'flex',
              alignItems: 'center',
              gap: SPACING.sm,
              borderBottom: `1px solid ${primary}22`,
              cursor: 'pointer',
              flexShrink: 0,
            }}
            onClick={() => setSidebarOpen(!sidebarOpen)}
            title="جمع/باز کردن منو"
          >
            <div
              style={{
                width: '40px',
                height: '40px',
                borderRadius: RADII.md,
                backgroundColor: primary,
                color: '#fff',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontWeight: TYPOGRAPHY.fontWeight.bold,
                fontSize: TYPOGRAPHY.fontSize.lg,
                flexShrink: 0,
                boxShadow: `0 4px 6px -1px ${primary}55`,
              }}
            >
              {title.charAt(0)}
            </div>
            {sidebarOpen && (
              <div style={{ overflow: 'hidden' }}>
                <div style={{ fontWeight: TYPOGRAPHY.fontWeight.bold, fontSize: TYPOGRAPHY.fontSize.base, whiteSpace: 'nowrap' }}>{title}</div>
                <div style={{ fontSize: TYPOGRAPHY.fontSize.xs, opacity: 0.7, whiteSpace: 'nowrap' }}>پنل مدیریت</div>
              </div>
            )}
          </div>

          {/* Navigation */}
          <nav style={{ flex: 1, padding: SPACING.md, overflowY: 'auto', overflowX: 'hidden' }}>
            {navItems.map((item, i) => (
              <NavItemComponent
                key={i}
                item={item}
                primary={primary}
                sidebarText={themeConfig.sidebarText}
                expanded={sidebarOpen}
              />
            ))}
          </nav>

          {/* User section */}
          {user && (
            <div style={{
              padding: SPACING.md,
              borderTop: `1px solid ${primary}22`,
              flexShrink: 0,
            }}>
              {sidebarOpen ? (
                <>
                  <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.sm, marginBottom: SPACING.sm }}>
                    <div style={{
                      width: '40px',
                      height: '40px',
                      borderRadius: '50%',
                      backgroundColor: primary,
                      color: '#fff',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontWeight: TYPOGRAPHY.fontWeight.semibold,
                      flexShrink: 0,
                    }}>
                      {user.name.charAt(0)}
                    </div>
                    <div style={{ overflow: 'hidden', flex: 1 }}>
                      <p style={{ fontWeight: TYPOGRAPHY.fontWeight.semibold, fontSize: TYPOGRAPHY.fontSize.sm, margin: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{user.name}</p>
                      <p style={{ fontSize: TYPOGRAPHY.fontSize.xs, opacity: 0.7, margin: 0, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{user.role}</p>
                    </div>
                  </div>
                  {onLogout && (
                    <button
                      onClick={onLogout}
                      style={{
                        width: '100%',
                        padding: `${SPACING.xs} ${SPACING.sm}`,
                        backgroundColor: 'transparent',
                        color: themeConfig.sidebarText,
                        border: `1px solid ${primary}33`,
                        borderRadius: RADII.md,
                        cursor: 'pointer',
                        fontSize: TYPOGRAPHY.fontSize.sm,
                        transition: `all ${TRANSITIONS.fast}`,
                        fontFamily: TYPOGRAPHY.fontFamily.sans,
                      }}
                      onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = `${primary}22`; }}
                      onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                    >
                      🚪 خروج
                    </button>
                  )}
                </>
              ) : (
                <div style={{ display: 'flex', justifyContent: 'center' }}>
                  <div style={{
                    width: '40px',
                    height: '40px',
                    borderRadius: '50%',
                    backgroundColor: primary,
                    color: '#fff',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontWeight: TYPOGRAPHY.fontWeight.semibold,
                    cursor: 'pointer',
                  }}
                    title={user.name}
                  >
                    {user.name.charAt(0)}
                  </div>
                </div>
              )}
            </div>
          )}
        </aside>

        {/* ===== Mobile sidebar overlay ===== */}
        {mobileSidebarOpen && (
          <div
            style={{
              position: 'fixed',
              inset: 0,
              zIndex: 1100,
              display: 'flex',
              justifyContent: 'flex-start',
            }}
          >
            <div
              style={{
                position: 'absolute',
                inset: 0,
                backgroundColor: 'rgba(0,0,0,0.5)',
                backdropFilter: 'blur(2px)',
              }}
              onClick={() => setMobileSidebarOpen(false)}
            />
            <aside style={{
              position: 'relative',
              width: '260px',
              backgroundColor: themeConfig.sidebarBg,
              color: themeConfig.sidebarText,
              display: 'flex',
              flexDirection: 'column',
              height: '100vh',
              overflow: 'hidden',
              boxShadow: SHADOWS.xl,
            }}>
              <div style={{
                padding: SPACING.lg,
                display: 'flex',
                alignItems: 'center',
                gap: SPACING.sm,
                borderBottom: `1px solid ${primary}22`,
                flexShrink: 0,
              }}>
                <div style={{
                  width: '40px',
                  height: '40px',
                  borderRadius: RADII.md,
                  backgroundColor: primary,
                  color: '#fff',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: TYPOGRAPHY.fontWeight.bold,
                  fontSize: TYPOGRAPHY.fontSize.lg,
                  flexShrink: 0,
                }}>
                  {title.charAt(0)}
                </div>
                <div style={{ fontWeight: TYPOGRAPHY.fontWeight.bold, fontSize: TYPOGRAPHY.fontSize.base }}>{title}</div>
              </div>
              <nav style={{ flex: 1, padding: SPACING.md, overflowY: 'auto' }}>
                {navItems.map((item, i) => (
                  <NavItemComponent
                    key={i}
                    item={item}
                    primary={primary}
                    sidebarText={themeConfig.sidebarText}
                    expanded={true}
                    onNavigate={() => setMobileSidebarOpen(false)}
                  />
                ))}
              </nav>
            </aside>
          </div>
        )}

        {/* ===== Main Content ===== */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
          {/* Header */}
          <header
            style={{
              backgroundColor: '#fff',
              padding: `${SPACING.sm} ${SPACING.lg}`,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              gap: SPACING.md,
              borderBottom: `1px solid ${COLORS.gray[200]}`,
              position: 'sticky',
              top: 0,
              zIndex: 100,
              flexShrink: 0,
            }}
          >
            {/* Mobile menu toggle */}
            <button
              style={{
                display: 'none',
                background: 'none',
                border: 'none',
                fontSize: '1.5rem',
                cursor: 'pointer',
                padding: SPACING.xs,
                color: COLORS.gray[700],
              }}
              className="yio-mobile-menu-btn"
              onClick={() => setMobileSidebarOpen(true)}
              aria-label="منو"
            >
              ☰
            </button>

            {/* Search */}
            {onSearch && (
              <form onSubmit={handleSearch} style={{ flex: 1, maxWidth: '420px' }}>
                <div style={{ position: 'relative' }}>
                  <span style={{
                    position: 'absolute',
                    right: SPACING.md,
                    top: '50%',
                    transform: 'translateY(-50%)',
                    color: COLORS.gray[400],
                    pointerEvents: 'none',
                    fontSize: '0.95rem',
                  }}>🔍</span>
                  <input
                    type="text"
                    placeholder="جستجو..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    style={{
                      width: '100%',
                      padding: `${SPACING.sm} ${SPACING.md}`,
                      paddingRight: '2.5rem',
                      borderRadius: RADII.lg,
                      border: `1px solid ${COLORS.gray[200]}`,
                      backgroundColor: COLORS.gray[50],
                      fontSize: TYPOGRAPHY.fontSize.sm,
                      outline: 'none',
                      transition: `all ${TRANSITIONS.fast}`,
                      fontFamily: TYPOGRAPHY.fontFamily.sans,
                      boxSizing: 'border-box',
                    }}
                    onFocus={(e) => {
                      e.currentTarget.style.backgroundColor = '#fff';
                      e.currentTarget.style.borderColor = primary;
                      e.currentTarget.style.boxShadow = `0 0 0 3px ${primary}22`;
                    }}
                    onBlur={(e) => {
                      e.currentTarget.style.backgroundColor = COLORS.gray[50];
                      e.currentTarget.style.borderColor = COLORS.gray[200];
                      e.currentTarget.style.boxShadow = 'none';
                    }}
                  />
                </div>
              </form>
            )}

            <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.sm }}>
              {/* Notifications */}
              <div ref={notifRef} style={{ position: 'relative' }}>
                <button
                  style={{
                    position: 'relative',
                    width: '40px',
                    height: '40px',
                    borderRadius: RADII.md,
                    border: 'none',
                    backgroundColor: notifOpen ? COLORS.gray[100] : 'transparent',
                    cursor: 'pointer',
                    fontSize: '1.25rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    transition: `background-color ${TRANSITIONS.fast}`,
                  }}
                  onClick={() => setNotifOpen(!notifOpen)}
                  aria-label="اعلان‌ها"
                >
                  🔔
                  {notifications > 0 && (
                    <span style={{
                      position: 'absolute',
                      top: '4px',
                      left: '4px',
                      backgroundColor: COLORS.danger[500],
                      color: '#fff',
                      borderRadius: '50%',
                      minWidth: '18px',
                      height: '18px',
                      padding: '0 4px',
                      fontSize: TYPOGRAPHY.fontSize.xs,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontWeight: TYPOGRAPHY.fontWeight.bold,
                      border: '2px solid #fff',
                    }}>
                      {notifications > 9 ? '۹+' : notifications}
                    </span>
                  )}
                </button>
                {notifOpen && (
                  <div style={{
                    position: 'absolute',
                    top: 'calc(100% + 8px)',
                    left: 0,
                    width: '320px',
                    backgroundColor: '#fff',
                    border: `1px solid ${COLORS.gray[200]}`,
                    borderRadius: RADII.lg,
                    boxShadow: SHADOWS.lg,
                    zIndex: 200,
                    overflow: 'hidden',
                  }}>
                    <div style={{
                      padding: `${SPACING.sm} ${SPACING.md}`,
                      borderBottom: `1px solid ${COLORS.gray[100]}`,
                      fontWeight: TYPOGRAPHY.fontWeight.semibold,
                      fontSize: TYPOGRAPHY.fontSize.sm,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                    }}>
                      <span>اعلان‌ها</span>
                      {notifications > 0 && <Badge variant="danger" size="sm">{notifications} جدید</Badge>}
                    </div>
                    <div style={{ maxHeight: '360px', overflowY: 'auto' }}>
                      {notifications > 0 ? (
                        <NotifItem icon="📦" title="سفارش جدید" desc="سفارش #YIO-2026 ثبت شد" time="۵ دقیقه پیش" />
                      ) : (
                        <div style={{ padding: SPACING.xl, textAlign: 'center', color: COLORS.gray[500], fontSize: TYPOGRAPHY.fontSize.sm }}>
                          🔕 اعلان جدیدی وجود ندارد
                        </div>
                      )}
                      <NotifItem icon="👥" title="کاربر جدید" desc="یک کاربر جدید ثبت‌نام کرد" time="۱ ساعت پیش" />
                      <NotifItem icon="⚠️" title="کمبود موجودی" desc="موجودی چوب فینلاندی رو به اتمام است" time="۲ ساعت پیش" />
                    </div>
                    <div style={{
                      padding: SPACING.sm,
                      borderTop: `1px solid ${COLORS.gray[100]}`,
                      textAlign: 'center',
                    }}>
                      <button style={{
                        background: 'none',
                        border: 'none',
                        color: primary,
                        cursor: 'pointer',
                        fontSize: TYPOGRAPHY.fontSize.sm,
                        fontWeight: TYPOGRAPHY.fontWeight.medium,
                        fontFamily: TYPOGRAPHY.fontFamily.sans,
                      }}>
                        مشاهده همه اعلان‌ها
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Quick settings */}
              <button
                style={{
                  width: '40px',
                  height: '40px',
                  borderRadius: RADII.md,
                  border: 'none',
                  backgroundColor: 'transparent',
                  cursor: 'pointer',
                  fontSize: '1.25rem',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: COLORS.gray[700],
                  transition: `background-color ${TRANSITIONS.fast}`,
                }}
                onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = COLORS.gray[100]; }}
                onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                aria-label="تنظیمات"
              >
                ⚙️
              </button>

              {/* User Menu */}
              {user && (
                <div ref={userMenuRef} style={{ position: 'relative' }}>
                  <button
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: SPACING.sm,
                      padding: `${SPACING.xs} ${SPACING.sm} ${SPACING.xs} ${SPACING.md}`,
                      borderRadius: RADII.lg,
                      border: 'none',
                      backgroundColor: userMenuOpen ? COLORS.gray[100] : 'transparent',
                      cursor: 'pointer',
                      transition: `background-color ${TRANSITIONS.fast}`,
                      fontFamily: TYPOGRAPHY.fontFamily.sans,
                    }}
                    onClick={() => setUserMenuOpen(!userMenuOpen)}
                  >
                    <div style={{
                      width: '32px',
                      height: '32px',
                      borderRadius: '50%',
                      backgroundColor: primary,
                      color: '#fff',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontWeight: TYPOGRAPHY.fontWeight.semibold,
                      fontSize: TYPOGRAPHY.fontSize.sm,
                    }}>
                      {user.name.charAt(0)}
                    </div>
                    <span style={{ fontSize: TYPOGRAPHY.fontSize.sm, fontWeight: TYPOGRAPHY.fontWeight.medium, color: COLORS.gray[700] }}>{user.name}</span>
                    <span style={{ color: COLORS.gray[400], fontSize: '0.75rem' }}>▼</span>
                  </button>
                  {userMenuOpen && (
                    <div style={{
                      position: 'absolute',
                      top: 'calc(100% + 8px)',
                      left: 0,
                      width: '220px',
                      backgroundColor: '#fff',
                      border: `1px solid ${COLORS.gray[200]}`,
                      borderRadius: RADII.lg,
                      boxShadow: SHADOWS.lg,
                      zIndex: 200,
                      overflow: 'hidden',
                    }}>
                      <div style={{ padding: SPACING.md, borderBottom: `1px solid ${COLORS.gray[100]}` }}>
                        <p style={{ margin: 0, fontWeight: TYPOGRAPHY.fontWeight.semibold, fontSize: TYPOGRAPHY.fontSize.sm, color: COLORS.gray[900] }}>{user.name}</p>
                        <p style={{ margin: 0, fontSize: TYPOGRAPHY.fontSize.xs, color: COLORS.gray[500], marginTop: 2 }}>{user.role}</p>
                      </div>
                      <UserMenuItem icon="👤" label="پروفایل من" />
                      <UserMenuItem icon="⚙️" label="تنظیمات حساب" />
                      <UserMenuItem icon="🌙" label="حالت تاریک" />
                      <UserMenuItem icon="❓" label="راهنما و پشتیبانی" />
                      {onLogout && (
                        <button
                          onClick={onLogout}
                          style={{
                            width: '100%',
                            padding: `${SPACING.sm} ${SPACING.md}`,
                            backgroundColor: 'transparent',
                            border: 'none',
                            borderBottom: 'none',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            gap: SPACING.sm,
                            color: COLORS.danger[700],
                            fontSize: TYPOGRAPHY.fontSize.sm,
                            fontWeight: TYPOGRAPHY.fontWeight.medium,
                            fontFamily: TYPOGRAPHY.fontFamily.sans,
                            transition: `background-color ${TRANSITIONS.fast}`,
                            textAlign: 'right',
                          }}
                          onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = COLORS.danger[50]; }}
                          onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
                        >
                          <span>🚪</span>
                          <span>خروج از حساب</span>
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </header>

          {/* Breadcrumb */}
          {breadcrumbs && breadcrumbs.length > 0 && (
            <div style={{ padding: `${SPACING.sm} ${SPACING.lg}`, backgroundColor: '#fff', borderBottom: `1px solid ${COLORS.gray[100]}` }}>
              <Breadcrumb items={breadcrumbs} />
            </div>
          )}

          {/* Content */}
          <main style={{ flex: 1, padding: SPACING.xl, overflowY: 'auto' }}>
            {children}
          </main>

          {/* Footer */}
          {footer && (
            <footer style={{
              backgroundColor: '#fff',
              borderTop: `1px solid ${COLORS.gray[200]}`,
              padding: `${SPACING.md} ${SPACING.lg}`,
              flexShrink: 0,
            }}>
              {footer}
            </footer>
          )}
        </div>

        {/* Inline CSS for responsive + spin animation */}
        <style dangerouslySetInnerHTML={{ __html: `
          @keyframes yio-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
          @media (max-width: 768px) {
            .yio-sidebar-desktop { display: none !important; }
            .yio-mobile-menu-btn { display: inline-flex !important; }
          }
          .yio-sidebar-desktop::-webkit-scrollbar,
          nav::-webkit-scrollbar { width: 6px; height: 6px; }
          .yio-sidebar-desktop::-webkit-scrollbar-thumb,
          nav::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.2); border-radius: 3px; }
        `}} />
      </div>
    </ThemeContext.Provider>
  );
}

// ============================================================
// Nav Item Component
// ============================================================
function NavItemComponent({
  item,
  primary,
  sidebarText,
  expanded,
  onNavigate,
}: {
  item: NavItem;
  primary: string;
  sidebarText: string;
  expanded: boolean;
  onNavigate?: () => void;
}) {
  const [open, setOpen] = useState(false);

  const handleClick = () => {
    if (item.children) {
      setOpen(!open);
    } else {
      item.onClick?.();
      onNavigate?.();
    }
  };

  return (
    <div style={{ marginBottom: SPACING.xs }}>
      <button
        onClick={handleClick}
        title={!expanded ? item.label : undefined}
        style={{
          width: '100%',
          padding: expanded ? `${SPACING.sm} ${SPACING.md}` : `${SPACING.sm}`,
          display: 'flex',
          alignItems: 'center',
          gap: SPACING.sm,
          justifyContent: expanded ? 'flex-start' : 'center',
          backgroundColor: item.active ? primary : 'transparent',
          color: item.active ? '#fff' : sidebarText,
          border: 'none',
          borderRadius: RADII.md,
          cursor: 'pointer',
          fontSize: TYPOGRAPHY.fontSize.sm,
          fontWeight: item.active ? TYPOGRAPHY.fontWeight.semibold : TYPOGRAPHY.fontWeight.normal,
          transition: `all ${TRANSITIONS.fast}`,
          fontFamily: TYPOGRAPHY.fontFamily.sans,
          textAlign: 'right',
        }}
        onMouseEnter={(e) => { if (!item.active) e.currentTarget.style.backgroundColor = `${primary}22`; }}
        onMouseLeave={(e) => { if (!item.active) e.currentTarget.style.backgroundColor = 'transparent'; }}
      >
        {item.icon && <span style={{ flexShrink: 0, fontSize: '1.1rem' }}>{item.icon}</span>}
        {expanded && (
          <>
            <span style={{ flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.label}</span>
            {item.badge != null && (
              <span style={{
                backgroundColor: item.active ? 'rgba(255,255,255,0.25)' : `${primary}33`,
                color: item.active ? '#fff' : primary,
                padding: '0 6px',
                borderRadius: RADII.full,
                fontSize: TYPOGRAPHY.fontSize.xs,
                fontWeight: TYPOGRAPHY.fontWeight.semibold,
                minWidth: '18px',
                textAlign: 'center',
              }}>
                {item.badge}
              </span>
            )}
            {item.children && (
              <span style={{ transform: open ? 'rotate(180deg)' : 'none', transition: `transform ${TRANSITIONS.fast}`, fontSize: '0.7rem' }}>▼</span>
            )}
          </>
        )}
      </button>

      {/* Children */}
      {item.children && open && expanded && (
        <div style={{ paddingInlineStart: SPACING.lg, marginTop: SPACING.xs }}>
          {item.children.map((child, i) => (
            <NavItemComponent
              key={i}
              item={child}
              primary={primary}
              sidebarText={sidebarText}
              expanded={expanded}
              onNavigate={onNavigate}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================================
// User Menu Item (internal)
// ============================================================
function UserMenuItem({ icon, label }: { icon: string; label: string }) {
  return (
    <button
      style={{
        width: '100%',
        padding: `${SPACING.sm} ${SPACING.md}`,
        backgroundColor: 'transparent',
        border: 'none',
        borderBottom: `1px solid ${COLORS.gray[100]}`,
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        gap: SPACING.sm,
        color: COLORS.gray[700],
        fontSize: TYPOGRAPHY.fontSize.sm,
        fontFamily: TYPOGRAPHY.fontFamily.sans,
        transition: `background-color ${TRANSITIONS.fast}`,
        textAlign: 'right',
      }}
      onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = COLORS.gray[50]; }}
      onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
    >
      <span>{icon}</span>
      <span>{label}</span>
    </button>
  );
}

// ============================================================
// Notification Item (internal)
// ============================================================
function NotifItem({ icon, title, desc, time }: { icon: string; title: string; desc: string; time: string }) {
  return (
    <div
      style={{
        padding: `${SPACING.md}`,
        borderBottom: `1px solid ${COLORS.gray[100]}`,
        display: 'flex',
        gap: SPACING.sm,
        cursor: 'pointer',
        transition: `background-color ${TRANSITIONS.fast}`,
      }}
      onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = COLORS.gray[50]; }}
      onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
    >
      <div style={{
        width: '36px',
        height: '36px',
        borderRadius: RADII.md,
        backgroundColor: COLORS.gray[100],
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: '1.1rem',
        flexShrink: 0,
      }}>{icon}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{ margin: 0, fontWeight: TYPOGRAPHY.fontWeight.semibold, fontSize: TYPOGRAPHY.fontSize.sm, color: COLORS.gray[900] }}>{title}</p>
        <p style={{ margin: 0, fontSize: TYPOGRAPHY.fontSize.xs, color: COLORS.gray[500], marginTop: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{desc}</p>
        <p style={{ margin: 0, fontSize: TYPOGRAPHY.fontSize.xs, color: COLORS.gray[400], marginTop: 4 }}>{time}</p>
      </div>
    </div>
  );
}
