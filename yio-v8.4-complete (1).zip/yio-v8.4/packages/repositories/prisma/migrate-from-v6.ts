/**
 * YIO V-7 — Migration Runner (V-6 → V-7)
 * ============================================================
 * این اسکریپت migration را به صورت خودکار اجرا می‌کند:
 *   1) بررسی اتصال به دیتابیس
 *   2) بررسی موجودیت جداول V-6
 *   3) اعمال Schema V-7 با prisma db push
 *   4) اجرای اسکریپت SQL مهاجرت
 *   5) اجرای seed
 *   6) گزارش نهایی
 *
 * Usage:
 *   cd packages/repositories
 *   npx tsx prisma/migrate-from-v6.ts --execute
 *
 *   برای dry-run (بدون تغییر):
 *   npx tsx prisma/migrate-from-v6.ts --dry-run
 * ============================================================
 */

import { PrismaClient } from '@prisma/client';
import { readFileSync, existsSync } from 'fs';
import { execSync } from 'child_process';
import { resolve, dirname } from 'path';

const prisma = new PrismaClient();
const isDryRun = process.argv.includes('--dry-run');
const isExecute = process.argv.includes('--execute');
const __dirname = resolve(dirname(process.argv[1] || '.'));

if (!isDryRun && !isExecute) {
  console.log('❌ Please specify --dry-run or --execute');
  process.exit(1);
}

interface Step {
  name: string;
  fn: () => Promise<void>;
}

const steps: Step[] = [];

function step(name: string, fn: () => Promise<void>) {
  steps.push({ name, fn });
}

// ============================================================
// STEP 1: Check database connection
// ============================================================
step('Check database connection', async () => {
  const result = await prisma.$queryRaw`SELECT 1 AS ok`;
  const row = result as Array<{ ok: number }>;
  if (!row[0] || row[0].ok !== 1) {
    throw new Error('Database connection failed');
  }
  console.log('  ✓ Database connection OK');
});

// ============================================================
// STEP 2: Check V-6 tables exist (legacy)
// ============================================================
step('Check V-6 tables exist', async () => {
  const v6Tables = ['User', 'Product', 'Order', 'OrderItem', 'ProductImage'];
  for (const table of v6Tables) {
    try {
      const result = await prisma.$queryRawUnsafe(
        `SELECT COUNT(*)::int AS count FROM "${table}" LIMIT 1`,
      );
      const row = result as Array<{ count: number }>;
      console.log(`  ✓ ${table}: ${row[0].count} rows`);
    } catch (e) {
      console.log(`  ⚠ Table ${table} not found or empty (will be created by V-7 schema)`);
    }
  }
});

// ============================================================
// STEP 3: Apply V-7 schema (skip in dry-run)
// ============================================================
step('Apply V-7 schema with prisma db push', async () => {
  if (isDryRun) {
    console.log('  ⊘ Skipped (dry-run mode)');
    return;
  }
  console.log('  ▸ Running prisma db push...');
  try {
    execSync('npx prisma db push --accept-data-loss --skip-generate', {
      cwd: __dirname,
      stdio: 'inherit',
      env: process.env,
    });
    console.log('  ✓ Schema applied');
  } catch (e) {
    throw new Error(`prisma db push failed: ${(e as Error).message}`);
  }
});

// ============================================================
// STEP 4: Run V-6 → V-7 migration SQL
// ============================================================
step('Run V-6 → V-7 migration SQL', async () => {
  if (isDryRun) {
    console.log('  ⊘ Skipped (dry-run mode)');
    return;
  }
  const sqlPath = resolve(__dirname, 'migrations/v6-to-v7-migration.sql');
  if (!existsSync(sqlPath)) {
    throw new Error(`Migration SQL file not found: ${sqlPath}`);
  }
  const sql = readFileSync(sqlPath, 'utf-8');
  console.log(`  ▸ Executing ${sql.length} chars of SQL...`);
  try {
    await prisma.$executeRawUnsafe(sql);
    console.log('  ✓ Migration SQL executed');
  } catch (e) {
    // در صورتی که خطای مربوط به وجود نداشتن جدول باشد، آن را به عنوان هشدار گزارش می‌دهیم
    const msg = (e as Error).message;
    if (msg.includes('relation') && msg.includes('does not exist')) {
      console.log(`  ⚠ Some V-6 tables do not exist (this is OK for fresh install): ${msg}`);
    } else {
      throw e;
    }
  }
});

// ============================================================
// STEP 5: Run seed
// ============================================================
step('Run seed script', async () => {
  if (isDryRun) {
    console.log('  ⊘ Skipped (dry-run mode)');
    return;
  }
  console.log('  ▸ Running seed.ts...');
  try {
    execSync('npx tsx prisma/seed.ts', {
      cwd: __dirname,
      stdio: 'inherit',
      env: process.env,
    });
    console.log('  ✓ Seed completed');
  } catch (e) {
    console.log(`  ⚠ Seed failed (may need tsx installed): ${(e as Error).message}`);
    console.log(`  ℹ You can run manually: npx tsx prisma/seed.ts`);
  }
});

// ============================================================
// STEP 6: Final verification & report
// ============================================================
step('Final verification', async () => {
  const tenantCount = await prisma.tenant.count();
  const userCount = await prisma.user.count();
  const productCount = await prisma.product.count();
  const orderCount = await prisma.order.count();

  console.log('\n═══════════════════════════════════════════════════');
  console.log('  YIO V-7 Migration Report');
  console.log('═══════════════════════════════════════════════════');
  console.log(`  Mode:          ${isDryRun ? 'DRY-RUN' : 'EXECUTE'}`);
  console.log(`  Tenants:       ${tenantCount}`);
  console.log(`  Users:         ${userCount}`);
  console.log(`  Products:      ${productCount}`);
  console.log(`  Orders:        ${orderCount}`);
  console.log('═══════════════════════════════════════════════════\n');

  // Health checks
  if (tenantCount === 0) {
    console.log('  ⚠ No tenants found — run seed to create default tenant');
  }
  if (userCount > 0) {
    const usersWithoutTenant = await prisma.user.count({ where: { tenantId: 0 } });
    if (usersWithoutTenant > 0) {
      console.log(`  ⚠ ${usersWithoutTenant} users have tenantId=0 (need migration)`);
    }
  }
});

// ============================================================
// Run all steps
// ============================================================
async function main() {
  console.log('🚀 YIO V-7 Migration Runner');
  console.log(`   Mode: ${isDryRun ? 'DRY-RUN' : 'EXECUTE'}\n`);

  let successCount = 0;
  let failCount = 0;

  for (const s of steps) {
    console.log(`\n[${successCount + failCount + 1}/${steps.length}] ${s.name}`);
    try {
      await s.fn();
      successCount++;
    } catch (e) {
      failCount++;
      console.log(`  ❌ FAILED: ${(e as Error).message}`);
      if (isExecute) {
        // در حالت execute، در صورت خطای بحرانی متوقف می‌شویم
        if ((e as Error).message.includes('database connection')) {
          break;
        }
      }
    }
  }

  console.log('\n═══════════════════════════════════════════════════');
  console.log(`  Migration ${failCount === 0 ? 'COMPLETED ✓' : 'PARTIALLY COMPLETED ⚠'}`);
  console.log(`  Successful steps: ${successCount}/${steps.length}`);
  console.log(`  Failed steps:     ${failCount}/${steps.length}`);
  console.log('═══════════════════════════════════════════════════\n');

  if (failCount > 0 && isExecute) {
    process.exit(1);
  }
}

main()
  .catch((e) => {
    console.error('❌ Fatal error:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
