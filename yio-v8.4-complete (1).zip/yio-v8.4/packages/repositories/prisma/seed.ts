/**
 * YIO V-7 — Database Seed Script
 * ============================================================
 * Creates the default Tenant, default admin user, RBAC roles,
 * sample wood-stock, machine, warehouse, suppliers, and demo products.
 *
 * Usage:
 *   cd packages/repositories
 *   npx tsx prisma/seed.ts
 *
 * Or after build:
 *   node dist/seed.js
 * ============================================================
 */

import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

const DEFAULT_TENANT_ID = 1;
const DEFAULT_ADMIN_PHONE = '09120000000';
const DEFAULT_ADMIN_PASSWORD = 'Admin@V7!2026';

async function main() {
  console.log('🌱 YIO V-7 — Starting seed...\n');

  // 1) Default Tenant
  console.log('▸ Creating default tenant...');
  await prisma.tenant.upsert({
    where: { id: DEFAULT_TENANT_ID },
    update: {},
    create: {
      id: DEFAULT_TENANT_ID,
      name: 'YIO Shop',
      domain: 'yio.ir',
      dbName: null,
      isActive: true,
      settings: JSON.stringify({
        defaultLanguage: 'fa',
        defaultCurrency: 'IRT',
        timezone: 'Asia/Tehran',
        smsProvider: 'melipayamak',
        emailProvider: 'smtp',
      }),
    },
  });
  console.log(`  ✓ Tenant #1 (yio.ir)\n`);

  // 2) Default Site Settings
  console.log('▸ Creating site settings...');
  const settings = [
    { key: 'site_name', value: 'YIO Shop', category: 'general' },
    { key: 'site_url', value: 'https://yio.ir', category: 'general' },
    { key: 'site_phone', value: '021-00000000', category: 'general' },
    { key: 'site_email', value: 'info@yio.ir', category: 'general' },
    { key: 'site_address', value: 'تهران، ایران', category: 'general' },
    { key: 'free_shipping_threshold', value: '500000', category: 'shipping' },
    { key: 'default_shipping_cost', value: '50000', category: 'shipping' },
    { key: 'tax_percent', value: '0', category: 'tax' },
    { key: 'sms_sender', value: '5000270019', category: 'sms' },
    { key: 'order_prefix', value: 'YIO', category: 'order' },
  ];
  for (const s of settings) {
    await prisma.siteSetting.upsert({
      where: { tenantId_key: { tenantId: DEFAULT_TENANT_ID, key: s.key } },
      update: { value: s.value },
      create: { ...s, tenantId: DEFAULT_TENANT_ID },
    });
  }
  console.log(`  ✓ ${settings.length} site settings\n`);

  // 3) Default Admin User (level 3 = admin)
  console.log('▸ Creating default admin user...');
  const adminPasswordHash = await bcrypt.hash(DEFAULT_ADMIN_PASSWORD, 10);
  await prisma.user.upsert({
    where: { tenantId_phone: { tenantId: DEFAULT_TENANT_ID, phone: DEFAULT_ADMIN_PHONE } },
    update: {},
    create: {
      tenantId: DEFAULT_TENANT_ID,
      phone: DEFAULT_ADMIN_PHONE,
      name: 'مدیر سیستم',
      email: 'admin@yio.ir',
      password: adminPasswordHash,
      level: 3,
      isVerified: true,
      isWholesale: false,
      referralCode: 'ADMIN-YIO',
    },
  });
  console.log(`  ✓ Admin user (phone: ${DEFAULT_ADMIN_PHONE})\n`);

  // 4) Default Employee record for admin
  console.log('▸ Creating admin employee record...');
  const adminUser = await prisma.user.findUnique({
    where: { tenantId_phone: { tenantId: DEFAULT_TENANT_ID, phone: DEFAULT_ADMIN_PHONE } },
  });
  if (adminUser) {
    await prisma.employee.upsert({
      where: { userId: adminUser.id },
      update: {},
      create: {
        tenantId: DEFAULT_TENANT_ID,
        userId: adminUser.id,
        name: 'مدیر سیستم',
        role: 'super_admin',
        phone: DEFAULT_ADMIN_PHONE,
        shift: 'morning',
        isActive: true,
        hireDate: new Date(),
      },
    });
    console.log(`  ✓ Employee linked to admin\n`);
  }

  // 5) Default Payment Methods
  console.log('▸ Creating default payment methods...');
  const payments = [
    { name: 'پرداخت در محل (COD)', type: 'cod', isDefault: true, priority: 1 },
    { name: 'کارت به کارت', type: 'bank_transfer', priority: 2 },
    { name: 'درگاه آنلاین (زرین‌پال)', type: 'online', priority: 3, merchantId: '', description: 'درگاه پرداخت آنلاین' },
  ];
  for (const p of payments) {
    const existing = await prisma.paymentMethod.findFirst({ where: { name: p.name } });
    if (!existing) {
      await prisma.paymentMethod.create({ data: p });
    }
  }
  console.log(`  ✓ ${payments.length} payment methods\n`);

  // 6) Default Warehouses
  console.log('▸ Creating default warehouses...');
  const warehouses = [
    { name: 'انبار چوب خام', type: 'raw', location: 'سالن ۱', capacity: 1000 },
    { name: 'انبار رنگ و مواد', type: 'raw', location: 'سالن ۲', capacity: 200 },
    { name: 'انبار تولید نیمه‌تمام', type: 'wip', location: 'سالن تولید', capacity: 500 },
    { name: 'انبار محصول تمام‌شده', type: 'finished', location: 'سالن بسته‌بندی', capacity: 800 },
    { name: 'انبار بسته‌بندی', type: 'packaging', location: 'سالن بسته‌بندی', capacity: 300 },
  ];
  for (const w of warehouses) {
    const existing = await prisma.warehouse.findFirst({ where: { tenantId: DEFAULT_TENANT_ID, name: w.name } });
    if (!existing) {
      await prisma.warehouse.create({
        data: {
          ...w,
          tenantId: DEFAULT_TENANT_ID,
          isActive: true,
        },
      });
    }
  }
  console.log(`  ✓ ${warehouses.length} warehouses\n`);

  // 7) Default Machines
  console.log('▸ Creating default machines...');
  const machines = [
    { name: 'دستگاه CNC روتینگ ۱', type: 'cnc', model: 'BlueElephant 1325', status: 'active' },
    { name: 'اره گردبر ۱', type: 'saw', model: 'Makita 5008MG', status: 'active' },
    { name: 'لیزر CO2 ۱', type: 'laser', model: 'Thunder Laser 1290', status: 'active' },
    { name: 'پرس گرم ۱', type: 'press', model: 'Industrial Press 50T', status: 'active' },
    { name: 'سمباده صنعتی ۱', type: 'sander', model: 'Bosch GSS 230', status: 'maintenance' },
  ];
  for (const m of machines) {
    const existing = await prisma.machine.findFirst({ where: { tenantId: DEFAULT_TENANT_ID, name: m.name } });
    if (!existing) {
      await prisma.machine.create({
        data: {
          ...m,
          tenantId: DEFAULT_TENANT_ID,
          workHours: 0,
          serviceInterval: 100,
          efficiency: 100,
        },
      });
    }
  }
  console.log(`  ✓ ${machines.length} machines\n`);

  // 8) Default Suppliers
  console.log('▸ Creating default suppliers...');
  const suppliers = [
    { name: 'تأمین‌کننده چوب شمال', type: 'wood', phone: '011-33334444', contactPerson: 'آقای رضایی', rating: 4.5, isActive: true },
    { name: 'پخش رنگ پارس', type: 'paint', phone: '021-44445555', contactPerson: 'خانم احمدی', rating: 4.2, isActive: true },
    { name: 'ابزار صنعت', type: 'tool', phone: '021-66667777', contactPerson: 'آقای کریمی', rating: 4.0, isActive: true },
    { name: 'بسته‌بندی نوین', type: 'packaging', phone: '021-88889999', contactPerson: 'خانم محمدی', rating: 4.8, isActive: true },
  ];
  for (const s of suppliers) {
    const existing = await prisma.supplier.findFirst({ where: { tenantId: DEFAULT_TENANT_ID, name: s.name } });
    if (!existing) {
      await prisma.supplier.create({ data: { ...s, tenantId: DEFAULT_TENANT_ID } });
    }
  }
  console.log(`  ✓ ${suppliers.length} suppliers\n`);

  // 9) Default Categories
  console.log('▸ Creating default categories...');
  const categories = [
    { title: 'اسباب‌بازی چوبی', slug: 'wooden-toys', icon: '🧸', color: '#D4A373', order: 1, isActive: true },
    { title: 'مایل سنگریزه‌ای', slug: 'wooden-building-blocks', icon: '🧱', color: '#A47148', order: 2, isActive: true },
    { title: 'پازل چوبی', slug: 'wooden-puzzles', icon: '🧩', color: '#6B705C', order: 3, isActive: true },
    { title: 'وسایل آموزشی', slug: 'educational', icon: '📚', color: '#B5838D', order: 4, isActive: true },
    { title: 'دکوراسیون چوبی', slug: 'wooden-decor', icon: '🎨', color: '#6D6875', order: 5, isActive: true },
  ];
  for (const c of categories) {
    const existing = await prisma.category.findFirst({ where: { slug: c.slug } });
    if (!existing) {
      await prisma.category.create({ data: c });
    }
  }
  console.log(`  ✓ ${categories.length} categories\n`);

  // 10) Sample Wood Stock
  console.log('▸ Creating sample wood stock...');
  const woodStocks = [
    { woodType: 'فینلاندی', thickness: 18, width: 122, length: 244, moisture: 8.5, grade: 'A', quantity: 50, unit: 'm2', pricePerUnit: 950000, status: 'in_stock' },
    { woodType: 'راش روسی', thickness: 16, width: 122, length: 244, moisture: 9.0, grade: 'A', quantity: 35, unit: 'm2', pricePerUnit: 1100000, status: 'in_stock' },
    { woodType: 'MDF', thickness: 18, width: 122, length: 244, moisture: 7.0, grade: 'B', quantity: 80, unit: 'm2', pricePerUnit: 750000, status: 'in_stock' },
    { woodType: 'چنار', thickness: 20, width: 100, length: 200, moisture: 12.0, grade: 'A', quantity: 15, unit: 'm2', pricePerUnit: 1500000, status: 'drying' },
  ];
  for (const w of woodStocks) {
    const existing = await prisma.woodStock.findFirst({
      where: { tenantId: DEFAULT_TENANT_ID, woodType: w.woodType, thickness: w.thickness },
    });
    if (!existing) {
      await prisma.woodStock.create({
        data: {
          ...w,
          tenantId: DEFAULT_TENANT_ID,
          purchaseDate: new Date(),
        },
      });
    }
  }
  console.log(`  ✓ ${woodStocks.length} wood stocks\n`);

  // 11) Default Rules (RBAC + business rules)
  console.log('▸ Creating default business rules...');
  const rules = [
    {
      key: 'order.min_amount',
      name: 'حداقل مبلغ سفارش',
      type: 'validation',
      engine: 'order',
      condition: JSON.stringify({ field: 'finalAmount', operator: '>=', value: 100000 }),
      action: JSON.stringify({ allow: true }),
      priority: 10,
      isActive: true,
    },
    {
      key: 'order.max_items',
      name: 'حداکثر اقلام در سفارش',
      type: 'validation',
      engine: 'order',
      condition: JSON.stringify({ field: 'items.length', operator: '<=', value: 50 }),
      action: JSON.stringify({ allow: true, message: 'حداکثر ۵۰ قلم در هر سفارش' }),
      priority: 10,
      isActive: true,
    },
    {
      key: 'inventory.low_stock_threshold',
      name: 'حداکثر موجودی کم',
      type: 'validation',
      engine: 'inventory',
      condition: JSON.stringify({ field: 'quantity', operator: '<=', value: 10 }),
      action: JSON.stringify({ alert: true, level: 'warning' }),
      priority: 10,
      isActive: true,
    },
    {
      key: 'production.work_order_priority',
      name: 'اولویت دستور کار بر اساس سفارش',
      type: 'workflow',
      engine: 'production',
      condition: JSON.stringify({ if: 'order.urgency === "high"', then: { priority: 'high' } }),
      action: JSON.stringify({ setField: 'priority', value: 'high' }),
      priority: 20,
      isActive: true,
    },
    {
      key: 'pricing.wholesale_discount',
      name: 'تخفیف عمده‌فروشان',
      type: 'pricing',
      engine: 'pricing',
      condition: JSON.stringify({ if: 'customer.isWholesale === true', then: { discount: 'customer.wholesaleDiscount' } }),
      action: JSON.stringify({ applyDiscount: true }),
      priority: 15,
      isActive: true,
    },
  ];
  for (const r of rules) {
    await prisma.rule.upsert({
      where: { tenantId_key: { tenantId: DEFAULT_TENANT_ID, key: r.key } },
      update: { name: r.name, condition: r.condition, action: r.action },
      create: { ...r, tenantId: DEFAULT_TENANT_ID },
    });
  }
  console.log(`  ✓ ${rules.length} business rules\n`);

  // 12) Default Workflow Definition (sales_order)
  console.log('▸ Creating default sales order workflow...');
  const existingWf = await prisma.workflowDefinition.findFirst({
    where: { tenantId: DEFAULT_TENANT_ID, entityType: 'sales_order', name: 'گردش کار پیش‌فرض سفارش' },
  });
  if (!existingWf) {
    const wf = await prisma.workflowDefinition.create({
      data: {
        tenantId: DEFAULT_TENANT_ID,
        name: 'گردش کار پیش‌فرض سفارش',
        entityType: 'sales_order',
        isActive: true,
        steps: {
          create: [
            { name: 'ثبت سفارش', order: 1, role: 'customer', autoAdvance: true },
            { name: 'بررسی سفارش', order: 2, role: 'sales_agent' },
            { name: 'تأیید سفارش', order: 3, role: 'sales_manager' },
            { name: 'صدور دستور کار', order: 4, role: 'production_manager', autoAdvance: true },
            { name: 'تولید', order: 5, role: 'production_operator' },
            { name: 'کنترل کیفیت', order: 6, role: 'qc_inspector' },
            { name: 'بسته‌بندی', order: 7, role: 'warehouse_operator' },
            { name: 'ارسال', order: 8, role: 'shipping_operator' },
            { name: 'تحویل', order: 9, role: 'customer', autoAdvance: true },
            { name: 'تکمیل', order: 10, role: 'system', autoAdvance: true },
          ],
        },
      },
    });
    console.log(`  ✓ Workflow #${wf.id} with 10 steps\n`);
  } else {
    console.log(`  ✓ Workflow already exists\n`);
  }

  // 13) Default FAQs
  console.log('▸ Creating default FAQs...');
  const faqs = [
    { question: 'چگونه می‌توانم سفارش ثبت کنم؟', answer: 'پس از انتخاب محصول، روی دکمه «افزودن به سبد خرید» کلیک کنید و سپس به سبد خرید بروید.', category: 'ordering', order: 1 },
    { question: 'مدت زمان ارسال چقدر است؟', answer: 'در تهران ۱ تا ۲ روز کاری و در شهرستان‌ها ۳ تا ۵ روز کاری.', category: 'shipping', order: 1 },
    { question: 'آیا محصولات ضمانت دارند؟', answer: 'بله، تمام محصولات چوبی YIO دارای ضمانت ۶ ماهه هستند.', category: 'warranty', order: 1 },
    { question: 'روش‌های پرداخت کدامند؟', answer: 'پرداخت در محل، کارت به کارت و درگاه آنلاین.', category: 'payment', order: 1 },
  ];
  for (const f of faqs) {
    const existing = await prisma.fAQ.findFirst({ where: { question: f.question } });
    if (!existing) {
      await prisma.fAQ.create({ data: { ...f, isActive: true } });
    }
  }
  console.log(`  ✓ ${faqs.length} FAQs\n`);

  // 14) Default Payment Method for online
  console.log('▸ Creating default online payment gateway settings...');
  const existingGateway = await prisma.paymentMethod.findFirst({ where: { type: 'online' } });
  if (!existingGateway) {
    await prisma.paymentMethod.create({
      data: {
        name: 'درگاه آنلاین (زرین‌پال)',
        type: 'online',
        merchantId: '00000000-0000-0000-0000-000000000000',
        callbackUrl: 'https://yio.ir/api/payment/callback',
        isDefault: false,
        priority: 5,
        isActive: true,
        description: 'درگاه پرداخت آنلاین زرین‌پال',
      },
    });
  }

  console.log('✅ Seed completed successfully!\n');
  console.log('═══════════════════════════════════════════════════');
  console.log('  Default Admin Credentials:');
  console.log(`    Phone:    ${DEFAULT_ADMIN_PHONE}`);
  console.log(`    Password: ${DEFAULT_ADMIN_PASSWORD}`);
  console.log('    Level:    3 (Admin)');
  console.log('═══════════════════════════════════════════════════\n');
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
