-- YIO V8.3 Product relational migration (PostgreSQL)
-- This migration is intentionally non-destructive: legacy Product pricing/media
-- columns remain as compatibility mirrors until the final cleanup migration.

ALTER TABLE "ProductVariant" ADD COLUMN IF NOT EXISTS "colorId" INTEGER;
ALTER TABLE "ProductVariant" ADD COLUMN IF NOT EXISTS "isDefault" BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE "ProductVariant" ADD COLUMN IF NOT EXISTS "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

CREATE INDEX IF NOT EXISTS "ProductVariant_productId_isActive_idx" ON "ProductVariant"("productId", "isActive");
CREATE INDEX IF NOT EXISTS "ProductVariant_colorId_idx" ON "ProductVariant"("colorId");
CREATE UNIQUE INDEX IF NOT EXISTS "ProductVariant_productId_sku_key" ON "ProductVariant"("productId", "sku");

ALTER TABLE "ProductVariant"
  ADD CONSTRAINT "ProductVariant_colorId_fkey"
  FOREIGN KEY ("colorId") REFERENCES "ProductColor"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "PriceHistory" ADD COLUMN IF NOT EXISTS "variantId" INTEGER;
CREATE INDEX IF NOT EXISTS "PriceHistory_variantId_idx" ON "PriceHistory"("variantId");
ALTER TABLE "PriceHistory"
  ADD CONSTRAINT "PriceHistory_variantId_fkey"
  FOREIGN KEY ("variantId") REFERENCES "ProductVariant"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Backfill one default variant for products that do not have one.
INSERT INTO "ProductVariant" ("productId", "title", "price", "salePrice", "stockQuantity", "isDefault", "isActive", "createdAt", "updatedAt")
SELECT p."id", p."title", p."price", COALESCE(p."discountPrice", p."salePrice"), p."stockQuantity", TRUE, TRUE, NOW(), NOW()
FROM "Product" p
WHERE NOT EXISTS (SELECT 1 FROM "ProductVariant" v WHERE v."productId" = p."id");

-- Backfill default flag for the first active variant per product.
WITH ranked AS (
  SELECT "id", ROW_NUMBER() OVER (PARTITION BY "productId" ORDER BY "id") AS rn
  FROM "ProductVariant"
  WHERE "isActive" = TRUE
)
UPDATE "ProductVariant" v
SET "isDefault" = TRUE
FROM ranked r
WHERE v."id" = r."id" AND r.rn = 1;

-- Backfill primary image from the legacy single-image field when available.
INSERT INTO "ProductImage" ("productId", "url", "alt", "sortOrder", "isPrimary")
SELECT p."id", p."image", p."title", 0, TRUE
FROM "Product" p
WHERE COALESCE(p."image", '') <> ''
  AND NOT EXISTS (SELECT 1 FROM "ProductImage" i WHERE i."productId" = p."id");

-- Tenant-scoped ABAC policy names.
DROP INDEX IF EXISTS "AbacPolicy_name_key";
CREATE UNIQUE INDEX IF NOT EXISTS "AbacPolicy_tenantId_name_key" ON "AbacPolicy"("tenantId", "name");
