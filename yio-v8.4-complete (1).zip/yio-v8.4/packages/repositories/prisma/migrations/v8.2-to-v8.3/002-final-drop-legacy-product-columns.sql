-- YIO V8.3 FINAL destructive cleanup.
-- Run ONLY after all application code has been deployed against the relational
-- ProductImage/ProductVideo/ProductColor/ProductVariant model and a verified backup exists.
-- The compatibility mirror columns are deliberately not dropped by the main migration.

ALTER TABLE "Product"
  DROP COLUMN IF EXISTS "price",
  DROP COLUMN IF EXISTS "salePrice",
  DROP COLUMN IF EXISTS "discountPrice",
  DROP COLUMN IF EXISTS "discountPercent",
  DROP COLUMN IF EXISTS "image",
  DROP COLUMN IF EXISTS "images",
  DROP COLUMN IF EXISTS "videos",
  DROP COLUMN IF EXISTS "colors",
  DROP COLUMN IF EXISTS "stockQuantity",
  DROP COLUMN IF EXISTS "inStock";
