-- ============================================================
-- YIO V-7 — MIGRATION FROM V-6 TO V-7
-- ============================================================
-- این اسکریپت داده‌های V-6 را به ساختار V-7 منتقل می‌کند.
-- پیش‌نیاز: Schema V-7 باید قبلاً با `prisma db push` اعمال شده باشد.
--
-- مراحل:
--   1) ساخت Tenant پیش‌فرض
--   2) مهاجرت جداول اصلی (افزودن tenantId)
--   3) مهاجرت جداول به‌هم‌پیوسته
--   4) اعمال ربط‌ها و کلیدهای خارجی
--
-- نکته: این اسکریپت Idempotent است (با ON CONFLICT اجرا می‌شود).
-- ============================================================

BEGIN;

-- ============================================================
-- 1) ایجاد Tenant پیش‌فرض
-- ============================================================
INSERT INTO "Tenant" (id, name, domain, "isActive", "settings", "createdAt", "updatedAt")
VALUES (1, 'YIO Shop (migrated)', 'yio.ir', true, '{}', NOW(), NOW())
ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, "updatedAt" = NOW();

-- ============================================================
-- 2) مهاجرت جداول اصلی — افزودن tenantId = 1
-- ============================================================

-- Users
UPDATE "User" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
-- اگر ستون tenantId وجود نداشت، با ALTER اضافه شده و سپس آپدیت شود
-- ALTER TABLE "User" ALTER COLUMN "tenantId" SET DEFAULT 1;

-- Products
UPDATE "Product" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;

-- Orders
UPDATE "Order" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;

-- Customers (V-6 مستقل نبود، معمولاً از User مشتق می‌شد)
-- اگر Customer در V-6 از User می‌آمد، داده‌ها را بسازید:
INSERT INTO "Customer" ("tenantId", name, phone, email, address, city, "postalCode", "createdAt")
SELECT DISTINCT 1,
  COALESCE(u.name, u.phone),
  u.phone,
  u.email,
  u.address,
  u.city,
  u."postalCode",
  COALESCE(u."createdAt", NOW())
FROM "User" u
WHERE NOT EXISTS (
  SELECT 1 FROM "Customer" c WHERE c."tenantId" = 1 AND c.phone = u.phone
)
ON CONFLICT DO NOTHING;

-- Map V-6 userId → CustomerId (برای سفارش‌ها)
UPDATE "Order" o
SET "customerId" = c.id
FROM "Customer" c
WHERE c."tenantId" = 1
  AND c.phone = (
    SELECT u.phone FROM "User" u WHERE u.id = o."userId"
  )
  AND o."customerId" IS NULL;

-- ============================================================
-- 3) مهاجرت جداول CRM/ERP جدید (در صورت وجود در V-6)
-- ============================================================

-- Warehouses
UPDATE "Warehouse" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "WoodStock" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "PaintStock" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "Supplier" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "Employee" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "Machine" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "PurchaseOrder" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "WholesaleOrder" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "ReturnRequest" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "DiscountRule" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "AccountingEntry" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "AnalyticsSnapshot" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "WorkflowDefinition" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "WorkflowInstance" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "Rule" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "AuditLog" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "SiteSetting" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "UserNotification" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "InventoryTransaction" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;
UPDATE "WorkOrder" SET "tenantId" = 1 WHERE "tenantId" IS NULL OR "tenantId" = 0;

-- ============================================================
-- 4) مهاجرت جداول از V-6 که در V-7 با همان نام هستند
--    (ProductImage, ProductVideo, ProductColor, ProductVariant,
--     OrderItem, Review, Wishlist, Address, Wallet, WalletTransaction,
--     LoyaltyPoint, Coupon, CouponUsage, BlogPost, FAQ, Page, Block,
--     Category, ContactMessage, PaymentMethod, IncomingEmail,
--     Newsletter, NotificationRequest, PBPage, PBTemplate,
--     RecentlyViewed, CustomerPhoto, ReturnRequest, PriceDropAlert)
-- ============================================================

-- این جداول در V-7 از tenantId استفاده نمی‌کنند (در سطح جهانی هستند)
-- اما اگرTenant-aware باشند، باید tenantId اضافه شود.

-- اطمینان از یکتایی ProductDesign (در صورت انتقال از V-6)
-- در V-6 این جدول وجود نداشت، پس نیازی به مهاجرت نیست.

-- ============================================================
-- 5) ساخت CostFormula پیش‌فرض برای محصولات موجود
-- ============================================================
INSERT INTO "CostFormula" (
  "productId", "materialCost", "laborCost", "energyCost", "depreciationCost",
  "packagingCost", "wasteCost", "transportCost", "commissionCost", "taxCost",
  "totalCost", "profitMargin", "suggestedPrice", "updatedAt"
)
SELECT
  p.id,
  0, 0, 0, 0, 0, 0, 0, 0, 0,
  GREATEST(p.price * 0.7, 0),
  0.2,
  p.price,
  NOW()
FROM "Product" p
WHERE NOT EXISTS (
  SELECT 1 FROM "CostFormula" cf WHERE cf."productId" = p.id
)
ON CONFLICT DO NOTHING;

-- ============================================================
-- 6) ساخت رکوردهای پیش‌فرض Workflow برای سفارش‌های موجود
-- ============================================================
INSERT INTO "WorkflowInstance" (
  "tenantId", "workflowId", "entityType", "entityId", "currentStep", "status", "startedAt"
)
SELECT
  1,
  wd.id,
  'sales_order',
  o.id,
  CASE o.status
    WHEN 'pending' THEN 'بررسی سفارش'
    WHEN 'confirmed' THEN 'صدور دستور کار'
    WHEN 'shipping' THEN 'ارسال'
    WHEN 'delivered' THEN 'تکمیل'
    WHEN 'cancelled' THEN 'تکمیل'
    ELSE 'بررسی سفارش'
  END,
  CASE o.status WHEN 'delivered' THEN 'completed' WHEN 'cancelled' THEN 'cancelled' ELSE 'active' END,
  o."createdAt"
FROM "Order" o
CROSS JOIN (
  SELECT id FROM "WorkflowDefinition" WHERE "tenantId" = 1 AND entityType = 'sales_order' LIMIT 1
) wd
WHERE NOT EXISTS (
  SELECT 1 FROM "WorkflowInstance" wi
  WHERE wi."tenantId" = 1 AND wi."entityType" = 'sales_order' AND wi."entityId" = o.id
)
ON CONFLICT DO NOTHING;

-- ============================================================
-- 7) ثبت لاگ مهاجرت در AuditLog
-- ============================================================
INSERT INTO "AuditLog" ("tenantId", "userId", action, "entityType", "entityId", changes, ip, timestamp)
VALUES (1, NULL, 'V6_TO_V7_MIGRATION', 'system', 0, JSONB_build_object('migrated_at', NOW(), 'version_from', 'V6', 'version_to', 'V7'), NULL, NOW());

COMMIT;

-- ============================================================
-- 8) Verify counts
-- ============================================================
DO $$
DECLARE
  v_tenant_count INTEGER;
  v_user_count INTEGER;
  v_product_count INTEGER;
  v_order_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO v_tenant_count FROM "Tenant";
  SELECT COUNT(*) INTO v_user_count FROM "User" WHERE "tenantId" = 1;
  SELECT COUNT(*) INTO v_product_count FROM "Product" WHERE "tenantId" = 1;
  SELECT COUNT(*) INTO v_order_count FROM "Order" WHERE "tenantId" = 1;

  RAISE NOTICE '═══════════════════════════════════════════════════';
  RAISE NOTICE '  V-6 → V-7 Migration Complete';
  RAISE NOTICE '  Tenants:    %', v_tenant_count;
  RAISE NOTICE '  Users:      % (tenantId=1)', v_user_count;
  RAISE NOTICE '  Products:   % (tenantId=1)', v_product_count;
  RAISE NOTICE '  Orders:     % (tenantId=1)', v_order_count;
  RAISE NOTICE '═══════════════════════════════════════════════════';
END $$;
