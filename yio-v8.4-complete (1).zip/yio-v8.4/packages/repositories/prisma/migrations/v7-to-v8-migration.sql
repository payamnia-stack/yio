-- ============================================================
-- YIO V8 — Migration: V7 → V8
-- ============================================================
-- این اسکریپت تغییرات schema V8 را اعمال می‌کند:
--   1) Enrichment AuditLog با فیلدهای جدید (userRole, operation, metadata, userAgent, requestId)
--   2) ایجاد جدول جدید EventStoreRecord
--   3) ایجاد جدول جدید AbacPolicy
--
-- نکته: این اسکریپت idempotent است — می‌توان آن را چند بار اجرا کرد.
-- ============================================================

BEGIN;

-- ============================================================
-- 1) AuditLog — Enrich
-- ============================================================
ALTER TABLE "AuditLog"
  ADD COLUMN IF NOT EXISTS "userRole"  TEXT,
  ADD COLUMN IF NOT EXISTS "operation" TEXT DEFAULT 'update',
  ADD COLUMN IF NOT EXISTS "metadata"  TEXT,
  ADD COLUMN IF NOT EXISTS "userAgent" TEXT,
  ADD COLUMN IF NOT EXISTS "requestId" TEXT;

CREATE INDEX IF NOT EXISTS "AuditLog_tenantId_action_idx"
  ON "AuditLog" ("tenantId", "action");
CREATE INDEX IF NOT EXISTS "AuditLog_tenantId_timestamp_idx"
  ON "AuditLog" ("tenantId", "timestamp");

-- ============================================================
-- 2) EventStoreRecord — New Table
-- ============================================================
CREATE TABLE IF NOT EXISTS "EventStoreRecord" (
  "id"            BIGSERIAL    PRIMARY KEY,
  "eventId"       TEXT         UNIQUE NOT NULL,
  "eventName"     TEXT         NOT NULL,
  "aggregateType" TEXT         NOT NULL,
  "aggregateId"   INTEGER      NOT NULL,
  "payload"       TEXT         NOT NULL,
  "metadata"      TEXT,
  "tenantId"      INTEGER      NOT NULL REFERENCES "Tenant" ("id"),
  "occurredAt"    TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS "EventStoreRecord_tenantId_aggregateType_aggregateId_idx"
  ON "EventStoreRecord" ("tenantId", "aggregateType", "aggregateId");
CREATE INDEX IF NOT EXISTS "EventStoreRecord_tenantId_eventName_idx"
  ON "EventStoreRecord" ("tenantId", "eventName");
CREATE INDEX IF NOT EXISTS "EventStoreRecord_tenantId_occurredAt_idx"
  ON "EventStoreRecord" ("tenantId", "occurredAt");
CREATE INDEX IF NOT EXISTS "EventStoreRecord_aggregateType_aggregateId_idx"
  ON "EventStoreRecord" ("aggregateType", "aggregateId");

-- ============================================================
-- 3) AbacPolicy — New Table
-- ============================================================
CREATE TABLE IF NOT EXISTS "AbacPolicy" (
  "id"             SERIAL      PRIMARY KEY,
  "tenantId"       INTEGER     NOT NULL REFERENCES "Tenant" ("id"),
  "name"           TEXT        UNIQUE NOT NULL,
  "resource"       TEXT        NOT NULL,
  "action"         TEXT        NOT NULL,
  "requiredRoles"  TEXT,
  "attributes"     TEXT,
  "conditionExpr"  TEXT,
  "effect"         TEXT        NOT NULL DEFAULT 'allow',
  "priority"       INTEGER     NOT NULL DEFAULT 100,
  "isActive"       BOOLEAN     NOT NULL DEFAULT TRUE,
  "createdAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt"      TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS "AbacPolicy_tenantId_resource_action_idx"
  ON "AbacPolicy" ("tenantId", "resource", "action");

-- ============================================================
-- 4) Seed default ABAC policies
-- ============================================================
INSERT INTO "AbacPolicy" ("tenantId", "name", "resource", "action", "requiredRoles", "effect", "priority", "isActive")
SELECT 1, 'admin_full_access', '*', '*', '["ceo"]', 'allow', 1, TRUE
WHERE NOT EXISTS (SELECT 1 FROM "AbacPolicy" WHERE name = 'admin_full_access');

INSERT INTO "AbacPolicy" ("tenantId", "name", "resource", "action", "requiredRoles", "effect", "priority", "isActive")
SELECT 1, 'no_modify_cancelled_orders', 'order', '*', NULL, 'deny', 1, TRUE
WHERE NOT EXISTS (SELECT 1 FROM "AbacPolicy" WHERE name = 'no_modify_cancelled_orders');

COMMIT;

-- ============================================================
-- Verification Queries
-- ============================================================
-- (برای دیباگ — اجرا نشودن اتوماتیک)
-- SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'AuditLog';
-- SELECT count(*) FROM "EventStoreRecord";
-- SELECT * FROM "AbacPolicy";

-- ============================================================
-- Rollback (در صورت نیاز)
-- ============================================================
-- DROP TABLE IF EXISTS "EventStoreRecord";
-- DROP TABLE IF EXISTS "AbacPolicy";
-- ALTER TABLE "AuditLog"
--   DROP COLUMN IF EXISTS "userRole",
--   DROP COLUMN IF EXISTS "operation",
--   DROP COLUMN IF EXISTS "metadata",
--   DROP COLUMN IF EXISTS "userAgent",
--   DROP COLUMN IF EXISTS "requestId";
