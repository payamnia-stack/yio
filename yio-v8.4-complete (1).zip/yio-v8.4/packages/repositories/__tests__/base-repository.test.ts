// ============================================================
// YIO V8.1 — BaseRepository Hardening Tests
// ============================================================
// این تست‌ها چهار اصلاح V8.1 را روی BaseRepository تأیید می‌کنند:
//   ۱) Generic Delegate (no `any`)
//   ۲) Searchable Fields per Entity
//   ۳) Whitelist Filter (no Object.assign)
//   ۴) Pagination Cap (MAX_PAGE_SIZE=100)
// ============================================================

import { describe, it, expect, beforeEach } from 'vitest';
import { BaseRepository } from '../src/base.repository';
import {
  BaseEntity,
  Context,
  QueryOptions,
  PaginatedResult,
  MAX_PAGE_SIZE,
  sanitizePagination,
  PrismaModelDelegate,
  prismaDelegate,
} from '@yio/core';

// ============================================================
// Fake Entity
// ============================================================
interface FakeProduct extends BaseEntity {
  title: string;
  sku: string;
  price: number;
  category: string;
}

// ============================================================
// In-Memory Prisma Model Delegate (Fake)
// ============================================================
function createFakeDelegate<T extends BaseEntity>(initialData: T[] = []): PrismaModelDelegate<T> {
  let data: T[] = [...initialData];
  let nextId = 1;
  for (const item of data) {
    if (item.id >= nextId) nextId = item.id + 1;
  }

  return {
    async findFirst(args?: any): Promise<T | null> {
      const where = args?.where || {};
      return data.find((item) => matchesWhere(item, where)) || null;
    },
    async findMany(args?: any): Promise<T[]> {
      const where = args?.where || {};
      let result = data.filter((item) => matchesWhere(item, where));
      if (args?.orderBy) {
        const [field, dir] = Object.entries(args.orderBy)[0];
        result.sort((a: any, b: any) => {
          if (a[field] < b[field]) return dir === 'asc' ? -1 : 1;
          if (a[field] > b[field]) return dir === 'asc' ? 1 : -1;
          return 0;
        });
      }
      if (args?.skip) result = result.slice(args.skip);
      if (args?.take) result = result.slice(0, args.take);
      return result;
    },
    async findUnique(args?: any): Promise<T | null> {
      return data.find((item) => item.id === args?.where?.id) || null;
    },
    async create(args: { data: any }): Promise<T> {
      const item = { ...args.data, id: nextId++, createdAt: new Date(), updatedAt: new Date() } as T;
      data.push(item);
      return item;
    },
    async createMany(args: { data: any[] }): Promise<{ count: number }> {
      for (const d of args.data) {
        const item = { ...d, id: nextId++, createdAt: new Date(), updatedAt: new Date() } as T;
        data.push(item);
      }
      return { count: args.data.length };
    },
    async update(args: { where: any; data: any }): Promise<T> {
      const idx = data.findIndex((item) => item.id === args.where.id);
      if (idx < 0) throw new Error('Not found');
      Object.assign(data[idx], args.data, { updatedAt: new Date() });
      return data[idx];
    },
    async updateMany(args: { where: any; data: any }): Promise<{ count: number }> {
      let count = 0;
      for (let i = 0; i < data.length; i++) {
        if (matchesWhere(data[i], args.where)) {
          Object.assign(data[i], args.data, { updatedAt: new Date() });
          count++;
        }
      }
      return { count };
    },
    async delete(args: { where: any }): Promise<T> {
      const idx = data.findIndex((item) => item.id === args.where.id);
      if (idx < 0) throw new Error('Not found');
      return data.splice(idx, 1)[0];
    },
    async deleteMany(args: { where: any }): Promise<{ count: number }> {
      const initial = data.length;
      data = data.filter((item) => !matchesWhere(item, args.where));
      return { count: initial - data.length };
    },
    async count(args?: { where?: any }): Promise<number> {
      const where = args?.where || {};
      return data.filter((item) => matchesWhere(item, where)).length;
    },
  };
}

function matchesWhere(item: any, where: any): boolean {
  if (!where) return true;
  for (const [key, value] of Object.entries(where)) {
    if (key === 'OR') {
      const orMatched = (value as any[]).some((cond) => matchesWhere(item, cond));
      if (!orMatched) return false;
      continue;
    }
    if (key === 'AND') {
      const allMatched = (value as any[]).every((cond) => matchesWhere(item, cond));
      if (!allMatched) return false;
      continue;
    }
    if (typeof value === 'object' && value !== null) {
      if (value.contains !== undefined) {
        const itemVal = String(item[key] || '').toLowerCase();
        const searchVal = String(value.contains).toLowerCase();
        if (!itemVal.includes(searchVal)) return false;
        continue;
      }
      if (value.gte !== undefined && item[key] < value.gte) return false;
      if (value.lte !== undefined && item[key] > value.lte) return false;
      if (value.gt !== undefined && item[key] <= value.gt) return false;
      if (value.lt !== undefined && item[key] >= value.lt) return false;
      if (value.increment !== undefined) continue;
    }
    // soft-delete: deletedAt: null باید با undefined یا null مطابقت کند
    if (key === 'deletedAt' && value === null) {
      if (item[key] !== null && item[key] !== undefined) return false;
      continue;
    }
    if (item[key] !== value) return false;
  }
  return true;
}

// ============================================================
// Test Repository Implementation
// ============================================================
class TestProductRepository extends BaseRepository<FakeProduct> {
  constructor(delegate: PrismaModelDelegate<FakeProduct>) {
    super(delegate);
  }

  protected searchableFields(): string[] {
    return ['title', 'sku'];
  }

  protected allowedFilterFields(): string[] {
    return ['category', 'price'];
  }

  protected allowedSortFields(): string[] {
    return ['createdAt', 'price', 'title'];
  }
}

// ============================================================
// Setup
// ============================================================
let delegate: PrismaModelDelegate<FakeProduct>;
let repo: TestProductRepository;
const ctx: Context = { tenantId: 1, userId: 1 };

beforeEach(() => {
  const initialData: FakeProduct[] = [
    { id: 1, tenantId: 1, title: 'میز چوبی', sku: 'TBL-001', price: 100000, category: 'furniture', createdAt: new Date(), updatedAt: new Date() },
    { id: 2, tenantId: 1, title: 'صندلی', sku: 'CHR-001', price: 50000, category: 'furniture', createdAt: new Date(), updatedAt: new Date() },
    { id: 3, tenantId: 1, title: 'لامپ', sku: 'LMP-001', price: 20000, category: 'lighting', createdAt: new Date(), updatedAt: new Date() },
    { id: 4, tenantId: 1, title: 'پنکه', sku: 'FAN-001', price: 150000, category: 'appliance', createdAt: new Date(), updatedAt: new Date() },
  ];
  delegate = createFakeDelegate<FakeProduct>(initialData);
  repo = new TestProductRepository(delegate);
});

// ============================================================
// Tests
// ============================================================
describe('BaseRepository V8.1 — Generic Delegate', () => {
  it('should accept a typed delegate (no `any` in constructor)', () => {
    expect(repo).toBeDefined();
  });

  it('should findById correctly', async () => {
    const product = await repo.findById(1, ctx);
    expect(product).not.toBeNull();
    expect(product!.title).toBe('میز چوبی');
  });

  it('should return null for non-existent id', async () => {
    const product = await repo.findById(999, ctx);
    expect(product).toBeNull();
  });

  it('should filter by tenantId automatically', async () => {
    const product = await repo.findById(1, { tenantId: 999 });
    expect(product).toBeNull();
  });
});

describe('BaseRepository V8.1 — Searchable Fields', () => {
  it('should search only on whitelisted fields (title, sku)', async () => {
    const result = await repo.findMany(
      { search: 'TBL', pagination: { page: 1, pageSize: 10 } },
      ctx,
    );
    expect(result.data.length).toBe(1);
    expect(result.data[0].sku).toBe('TBL-001');
  });

  it('should not search on fields not in searchableFields (e.g. category)', async () => {
    const result = await repo.findMany(
      { search: 'furniture', pagination: { page: 1, pageSize: 10 } },
      ctx,
    );
    expect(result.data.length).toBe(0);
  });

  it('should support case-insensitive search', async () => {
    const result = await repo.findMany(
      { search: 'tbl', pagination: { page: 1, pageSize: 10 } },
      ctx,
    );
    expect(result.data.length).toBe(1);
  });
});

describe('BaseRepository V8.1 — Whitelist Filter', () => {
  it('should allow filter on whitelisted field (category)', async () => {
    const result = await repo.findMany(
      { filters: { category: 'furniture' }, pagination: { page: 1, pageSize: 10 } },
      ctx,
    );
    expect(result.data.length).toBe(2);
  });

  it('should allow filter on whitelisted field (price)', async () => {
    const result = await repo.findMany(
      { filters: { price: 100000 }, pagination: { page: 1, pageSize: 10 } },
      ctx,
    );
    expect(result.data.length).toBe(1);
    expect(result.data[0].title).toBe('میز چوبی');
  });

  it('should IGNORE filter on non-whitelisted field (e.g. id)', async () => {
    const result = await repo.findMany(
      { filters: { id: 1 }, pagination: { page: 1, pageSize: 10 } },
      ctx,
    );
    expect(result.data.length).toBe(4);
  });

  it('should IGNORE filter on tenantId (cannot override)', async () => {
    const result = await repo.findMany(
      { filters: { tenantId: 999 }, pagination: { page: 1, pageSize: 10 } },
      ctx,
    );
    expect(result.data.length).toBe(4);
  });

  it('should IGNORE filter on deletedAt (cannot bypass soft delete)', async () => {
    const result = await repo.findMany(
      { filters: { deletedAt: null }, pagination: { page: 1, pageSize: 10 } },
      ctx,
    );
    expect(result.data.length).toBe(4);
  });
});

describe('BaseRepository V8.1 — Pagination Cap', () => {
  it('should cap pageSize at MAX_PAGE_SIZE (100)', async () => {
    const result = await repo.findMany(
      { pagination: { page: 1, pageSize: 100000 } },
      ctx,
    );
    expect(result.pagination.pageSize).toBe(MAX_PAGE_SIZE);
    expect(result.pagination.pageSize).toBe(100);
  });

  it('should default to page=1 if not provided', async () => {
    const result = await repo.findMany({}, ctx);
    expect(result.pagination.page).toBe(1);
  });

  it('should default to pageSize=10 if not provided', async () => {
    const result = await repo.findMany({}, ctx);
    expect(result.pagination.pageSize).toBe(10);
  });

  it('should handle negative page numbers', async () => {
    const result = await repo.findMany(
      { pagination: { page: -5, pageSize: 10 } },
      ctx,
    );
    expect(result.pagination.page).toBe(1);
  });

  it('should handle zero pageSize', async () => {
    const result = await repo.findMany(
      { pagination: { page: 1, pageSize: 0 } },
      ctx,
    );
    expect(result.pagination.pageSize).toBe(1);
  });

  it('should calculate totalPages correctly', async () => {
    const result = await repo.findMany(
      { pagination: { page: 1, pageSize: 2 } },
      ctx,
    );
    expect(result.pagination.total).toBe(4);
    expect(result.pagination.totalPages).toBe(2);
  });

  it('should support sort on whitelisted field (price)', async () => {
    const result = await repo.findMany(
      { pagination: { page: 1, pageSize: 10, sort: 'price', order: 'asc' } },
      ctx,
    );
    expect(result.data[0].price).toBe(20000);
    expect(result.data[result.data.length - 1].price).toBe(150000);
  });

  it('should IGNORE sort on non-whitelisted field', async () => {
    const result = await repo.findMany(
      { pagination: { page: 1, pageSize: 10, sort: 'sku', order: 'asc' } },
      ctx,
    );
    expect(result.data.length).toBe(4);
  });
});

describe('BaseRepository V8.1 — create / update / softDelete', () => {
  it('should create with auto-injected tenantId', async () => {
    const created = await repo.create(
      { title: 'کمد', sku: 'CBD-001', price: 200000, category: 'furniture' },
      ctx,
    );
    expect(created.id).toBeDefined();
    expect(created.tenantId).toBe(1);
  });

  it('should not allow tenantId override in update', async () => {
    const updated = await repo.update(
      1,
      { title: 'میز بزرگ', tenantId: 999 as any },
      ctx,
    );
    expect(updated.tenantId).toBe(1);
    expect(updated.title).toBe('میز بزرگ');
  });

  it('should not allow id override in update', async () => {
    const updated = await repo.update(
      1,
      { id: 999 as any, title: 'تغییر نام' },
      ctx,
    );
    expect(updated.id).toBe(1);
    expect(updated.title).toBe('تغییر نام');
  });

  it('should soft delete by setting deletedAt', async () => {
    await repo.softDelete(1, ctx);
    const product = await repo.findById(1, ctx);
    expect(product).toBeNull();
  });
});

describe('BaseRepository V8.1 — sanitizePagination helper', () => {
  it('should cap pageSize at MAX_PAGE_SIZE', () => {
    const result = sanitizePagination({ page: 1, pageSize: 100000 });
    expect(result.pageSize).toBe(MAX_PAGE_SIZE);
  });

  it('should default page to 1 if invalid', () => {
    expect(sanitizePagination({ page: -1, pageSize: 10 }).page).toBe(1);
    expect(sanitizePagination({ page: 0, pageSize: 10 }).page).toBe(1);
    expect(sanitizePagination({ pageSize: 10 }).page).toBe(1);
  });

  it('should default pageSize to 10 if not provided', () => {
    expect(sanitizePagination({ page: 1 }).pageSize).toBe(10);
  });

  it('should normalize order to "asc" or "desc"', () => {
    expect(sanitizePagination({ order: 'asc' as any }).order).toBe('asc');
    expect(sanitizePagination({ order: 'desc' as any }).order).toBe('desc');
    expect(sanitizePagination({ order: 'invalid' as any }).order).toBeUndefined();
  });
});

describe('BaseRepository V8.1 — prismaDelegate helper', () => {
  it('should throw clear error for non-existent model', () => {
    expect(() => prismaDelegate({} as any, 'nonExistentModel')).toThrow(
      /Prisma model "nonExistentModel" not found/,
    );
  });

  it('should return a delegate for an existing model', () => {
    const fakePrisma = {
      product: {
        findFirst: async () => null,
        findMany: async () => [],
        create: async () => ({}),
        update: async () => ({}),
        count: async () => 0,
      },
    };
    const delegate = prismaDelegate<any>(fakePrisma as any, 'product');
    expect(delegate).toBeDefined();
    expect(typeof delegate.findFirst).toBe('function');
  });
});
