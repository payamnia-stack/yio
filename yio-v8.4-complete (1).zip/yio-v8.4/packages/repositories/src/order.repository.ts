// ============================================================
// YIO V8.1 — Order Repository
// ============================================================
// در V8.1:
//   - استفاده از prismaDelegate<SalesOrder> به‌جای (this.prisma as any)['order']
//   - تعریف searchableFields و allowedFilterFields
//   - پشتیبانی کامل از Transaction Context
// ============================================================

import { PrismaClient } from '@prisma/client';
import { BaseRepository } from './base.repository';
import {
  SalesOrder,
  Context,
  IOrderRepository,
  PaginatedResult,
  ITransactionContext,
  PrismaModelDelegate,
  prismaDelegate,
  prismaTxDelegate,
} from '@yio/core';

export class OrderRepository extends BaseRepository<SalesOrder> implements IOrderRepository {
  private prisma: PrismaClient;

  constructor(prisma: PrismaClient) {
    super(prismaDelegate<SalesOrder>(prisma, 'order'));
    this.prisma = prisma;
  }

  // ============================================================
  // Whitelisted Config
  // ============================================================

  protected searchableFields(): string[] {
    return ['orderNumber', 'recipientName', 'recipientPhone'];
  }

  protected allowedFilterFields(): string[] {
    return [
      'status',
      'paymentStatus',
      'paymentMethod',
      'customerId',
      'userId',
      'shippingCity',
      'trackingCode',
    ];
  }

  protected allowedSortFields(): string[] {
    return ['createdAt', 'updatedAt', 'totalAmount', 'finalAmount', 'status'];
  }

  protected getTxDelegate(tx: ITransactionContext): PrismaModelDelegate<SalesOrder> {
    return prismaTxDelegate<SalesOrder>(tx.client, 'order');
  }

  // ============================================================
  // Specialized Methods
  // ============================================================

  async findByStatus(
    status: string,
    ctx: Context,
    page: number = 1,
    pageSize: number = 10,
  ): Promise<PaginatedResult<any>> {
    // استفاده از findMany با filter status
    return this.findMany(
      {
        filters: { status },
        pagination: { page, pageSize },
      },
      ctx,
    );
  }

  async findUserOrders(userId: number, ctx: Context): Promise<any[]> {
    const result = await this.findMany(
      {
        filters: { userId },
        pagination: { page: 1, pageSize: 100 },
      },
      ctx,
    );
    return result.data;
  }

  async updateStatus(id: number, status: string, ctx: Context, tx?: ITransactionContext): Promise<void> {
    const model = tx ? this.getTxDelegate(tx) : this.model;
    await model.update({
      where: { id },
      data: { status },
    });
  }

  async updateTracking(id: number, trackingCode: string, ctx: Context, tx?: ITransactionContext): Promise<void> {
    const model = tx ? this.getTxDelegate(tx) : this.model;
    await model.update({
      where: { id },
      data: { trackingCode, status: 'shipping' },
    });
  }

  async generateOrderNumber(ctx: Context): Promise<string> {
    const count = await this.prisma.order.count({ where: { tenantId: ctx.tenantId } });
    return `YIO-${1000 + count + 1}`;
  }

  /**
   * ایجاد سفارش + اقلام در یک تراکنش.
   * در V8.1، اگر tx ارائه شود، از آن استفاده می‌کند.
   */
  async createWithItems(
    order: Record<string, any>,
    items: Array<Record<string, any>>,
    ctx: Context,
    tx?: ITransactionContext,
  ): Promise<{ id: number; orderNumber: string }> {
    const client = tx?.client || this.prisma;

    const created = await client.order.create({
      data: {
        ...order,
        tenantId: ctx.tenantId,
      },
    });

    if (items.length > 0) {
      await client.orderItem.createMany({
        data: items.map((item) => ({ ...item, orderId: created.id })),
      });
    }

    return { id: created.id, orderNumber: created.orderNumber };
  }
}
