// ============================================================
// YIO V8.1 — Product Repository
// ============================================================
// در V8.1:
//   - استفاده از prismaDelegate<Product> به‌جای (this.prisma as any)['product']
//   - تعریف searchableFields و allowedFilterFields
//   - پشتیبانی از Transaction Context
// ============================================================

import { PrismaClient } from '@prisma/client';
import { BaseRepository } from './base.repository';
import {
  Product,
  Context,
  IProductRepository,
  PaginatedResult,
  QueryOptions,
  ITransactionContext,
  PrismaModelDelegate,
  prismaDelegate,
  prismaTxDelegate,
} from '@yio/core';

export class ProductRepository extends BaseRepository<Product> implements IProductRepository {
  private readonly prisma: PrismaClient;

  constructor(prisma: PrismaClient) {
    super(prismaDelegate<Product>(prisma, 'product'));
    this.prisma = prisma;
  }

  // ============================================================
  // Whitelisted Config
  // ============================================================

  /** فیلدهایی که قابل search هستند */
  protected searchableFields(): string[] {
    return ['title', 'brand', 'category'];
  }

  /** فیلدهایی که کاربر می‌تواند در filters استفاده کند */
  protected allowedFilterFields(): string[] {
    return [
      'status',
      'category',
      'brand',
      'inStock',
      'isPublished',
      'isSpecial',
      'fastDelivery',
      'price',
      'salePrice',
      'rating',
    ];
  }

  /** فیلدهایی که sortable هستند */
  protected allowedSortFields(): string[] {
    return ['createdAt', 'updatedAt', 'price', 'salePrice', 'rating', 'title'];
  }

  /** Helper: گرفتن delegate از Transaction Context */
  protected getTxDelegate(tx: ITransactionContext): PrismaModelDelegate<Product> {
    return prismaTxDelegate<Product>(tx.client, 'product');
  }

  // ============================================================
  // Specialized Methods
  // ============================================================

  async findPublished(ctx: Context, opts?: QueryOptions): Promise<PaginatedResult<any>> {
    // استفاده از findMany با filter پیش‌فرض isPublished: true
    return this.findMany(
      {
        ...opts,
        filters: { ...(opts?.filters || {}), isPublished: true },
      },
      ctx,
    );
  }

  async publish(id: number, ctx: Context, tx?: ITransactionContext): Promise<void> {
    if (!(await this.findById(id, ctx, tx))) throw new Error('محصول یافت نشد');
    const model = tx ? this.getTxDelegate(tx) : this.model;
    await model.update({
      where: { id },
      data: { isPublished: true, publishedAt: new Date() },
    });
  }

  async unpublish(id: number, ctx: Context, tx?: ITransactionContext): Promise<void> {
    if (!(await this.findById(id, ctx, tx))) throw new Error('محصول یافت نشد');
    const model = tx ? this.getTxDelegate(tx) : this.model;
    await model.update({
      where: { id },
      data: { isPublished: false, publishedAt: null },
    });
  }

  async updateStock(id: number, delta: number, ctx: Context, tx?: ITransactionContext): Promise<number> {
    const model = tx ? this.getTxDelegate(tx) : this.model;
    const product = await model.findFirst({
      where: { id, tenantId: ctx.tenantId, deletedAt: null },
      include: { productVariants: { where: { isActive: true }, orderBy: [{ isDefault: 'desc' }, { id: 'asc' }], take: 1 } },
    } as any);
    if (!product) throw new Error('محصول یافت نشد');

    const variant = (product as any).productVariants?.[0];
    if (!variant) {
      const next = Math.max(0, (product as any).stockQuantity + delta);
      await model.update({ where: { id }, data: { stockQuantity: next, inStock: next > 0 } });
      return next;
    }

    const next = Math.max(0, variant.stockQuantity + delta);
    await (tx?.client || this.prisma)?.productVariant?.update?.({
      where: { id: variant.id }, data: { stockQuantity: next },
    });
    // Legacy mirror is kept in sync during the compatibility window.
    await model.update({ where: { id }, data: { stockQuantity: next, inStock: next > 0 } });
    return next;
  }

  async reserveStock(items: Array<{ productId: number; quantity: number }>, ctx: Context, tx?: ITransactionContext): Promise<void> {
    for (const item of items) {
      const model = tx ? this.getTxDelegate(tx) : this.model;
      const product = await model.findFirst({
        where: { id: item.productId, tenantId: ctx.tenantId, deletedAt: null },
        include: { productVariants: { where: { isActive: true }, orderBy: [{ isDefault: 'desc' }, { id: 'asc' }], take: 1 } },
      } as any);
      if (!product) throw new Error(`محصول ${item.productId} یافت نشد`);
      const variant = (product as any).productVariants?.[0];
      const stock = variant ? variant.stockQuantity : (product as any).stockQuantity;
      if (stock < item.quantity) throw new Error(`موجودی محصول ${item.productId} کافی نیست`);
      const next = stock - item.quantity;
      if (variant) {
        await (tx?.client || this.prisma).productVariant.update({ where: { id: variant.id }, data: { stockQuantity: next } });
      }
      await model.update({ where: { id: item.productId }, data: { stockQuantity: next, inStock: next > 0 } });
    }
  }

  async releaseStock(items: Array<{ productId: number; quantity: number }>, ctx: Context, tx?: ITransactionContext): Promise<void> {
    for (const item of items) await this.updateStock(item.productId, item.quantity, ctx, tx);
  }

  // متد کمکی برای گرفتن product با روابط (read-only)
  async getWithRelations(id: number, ctx: Context) {
    // این متد از Prisma مستقیم استفاده می‌کند چون نیاز به include دارد.
    // در V8.1، BaseRepository فقط delegate پایه را مدیریت می‌کند.
    // برای include‌های پیچیده، Repository مستقیم با Prisma کار می‌کند.
    throw new Error(
      'getWithRelations باید با PrismaClient مستقیم پیاده‌سازی شود. ' +
      'این متد در BaseRepository جا ندارد چون include یک feature خاص Prisma است.',
    );
  }
}
