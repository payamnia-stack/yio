// ============================================================
// YIO V8.1 — Base Repository (Hardened)
// ============================================================
// در V8.1 چهار اصلاح مهم روی BaseRepository انجام شده:
//
//   ۱) Generic Delegate Pattern
//      به‌جای `(this.prisma as any)[this.modelName]`، یک
//      PrismaModelDelegate<T> تزریق می‌شود. این autocomplete کامل
//      و compile-time checking فراهم می‌کند.
//
//   ۲) Searchable Fields (per-Entity)
//      متد abstract `searchableFields()` به هر Repository اجازه
//      می‌دهد فقط فیلدهایی که واقعاً قابل search هستند را تعریف کند.
//      مثلاً ProductRepository → ["title","sku"] و
//      CustomerRepository → ["firstName","lastName","phone"].
//
//   ۳) Whitelist Filter (Safe Filtering)
//      به‌جای `Object.assign(where, filters)` خطرناک، یک
//      `allowedFilterFields()` Whitelist تعریف می‌شود. فقط فیلدهای
//      مجاز از `opts.filters` کپی می‌شوند. کاربر نمی‌تواند tenantId،
//      deletedAt یا هر شرط ناخواسته دیگری را override کند.
//
//   ۴) Pagination Cap
//      `sanitizePagination()` کمکی برای محدود کردن pageSize به
//      MAX_PAGE_SIZE=100. جلوگیری از DOS با pageSize=100000.
// ============================================================

import {
  BaseEntity,
  Context,
  QueryOptions,
  PaginatedResult,
  sanitizePagination,
  SanitizedFilters,
  PrismaModelDelegate,
  ITransactionContext,
  IBaseRepository,
} from '@yio/core';

export abstract class BaseRepository<T extends BaseEntity>
  implements IBaseRepository<T>
{
  /**
   * @param model یک PrismaModelDelegate<T> تایپ‌شده.
   *               هر Subclass این delegate را در constructor خود می‌سازد
   *               با استفاده از `prismaDelegate<T>(prisma, 'modelName')`.
   */
  constructor(
    protected readonly model: PrismaModelDelegate<T>,
  ) {}

  // ============================================================
  // ABSTRACT — Override in subclass
  // ============================================================

  /**
   * فیلدهایی که قابل search هستند (در findMany استفاده می‌شوند).
   * مثال: ['title', 'sku']
   * اگر Entity قابلیت search ندارد، [] برگردانید.
   */
  protected searchableFields(): string[] {
    return [];
  }

  /**
   * فیلدهایی که کاربر می‌تواند در filters استفاده کند.
   * این یک Whitelist است — فقط این فیلدها از opts.filters کپی می‌شوند.
   * فیلدهای حساس مثل tenantId، deletedAt، id نباید در این لیست باشند
   * (مگر اینکه منطق خاصی داشته باشند).
   *
   * مثال: ['status', 'category', 'customerId']
   */
  protected allowedFilterFields(): string[] {
    return [];
  }

  /**
   * فیلدهایی که sortable هستند. اگر opts.pagination.sort در این
   * لیست نباشد، نادیده گرفته می‌شود (default: createdAt).
   */
  protected allowedSortFields(): string[] {
    return ['createdAt', 'updatedAt'];
  }

  // ============================================================
  // Find by ID
  // ============================================================
  async findById(id: number, ctx: Context, tx?: ITransactionContext): Promise<T | null> {
    const model = tx ? this.getTxDelegate(tx) : this.model;
    return model.findFirst({
      where: { id, tenantId: ctx.tenantId, deletedAt: null },
    });
  }

  // ============================================================
  // Find Many — with safe search, whitelist filter, capped pagination
  // ============================================================
  async findMany(opts: QueryOptions, ctx: Context, tx?: ITransactionContext): Promise<PaginatedResult<T>> {
    const model = tx ? this.getTxDelegate(tx) : this.model;

    // ۱) Sanitize pagination (cap'd)
    const { page, pageSize, sort, order } = sanitizePagination(opts.pagination);

    // ۲) Build where clause
    const where: any = {
      tenantId: ctx.tenantId,
      deletedAt: null,
    };

    // ۳) Apply search (only on whitelisted searchable fields)
    if (opts.search && this.searchableFields().length > 0) {
      where.OR = this.searchableFields().map((field) => ({
        [field]: { contains: opts.search, mode: 'insensitive' },
      }));
    }

    // ۴) Apply whitelisted filters — هیچ Object.assign خطرناک نیست
    if (opts.filters) {
      const sanitized = this.sanitizeFilters(opts.filters);
      Object.assign(where, sanitized);
    }

    // ۵) Sort — فقط فیلدهای مجاز
    let orderBy: any = { createdAt: 'desc' };
    if (sort && this.allowedSortFields().includes(sort)) {
      orderBy = { [sort]: order || 'desc' };
    }

    // ۶) Execute query (parallel: data + count)
    const [data, total] = await Promise.all([
      model.findMany({
        where,
        orderBy,
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      model.count({ where }),
    ]);

    return {
      data,
      pagination: {
        page,
        pageSize,
        total,
        totalPages: Math.ceil(total / pageSize),
      },
    };
  }

  // ============================================================
  // Create
  // ============================================================
  async create(data: Partial<T>, ctx: Context, tx?: ITransactionContext): Promise<T> {
    const model = tx ? this.getTxDelegate(tx) : this.model;
    return model.create({
      data: {
        ...data,
        tenantId: ctx.tenantId,
      },
    });
  }

  // ============================================================
  // Update
  // ============================================================
  async update(id: number, data: Partial<T>, ctx: Context, tx?: ITransactionContext): Promise<T> {
    const model = tx ? this.getTxDelegate(tx) : this.model;
    // tenantId باید override نشود
    const safeData = { ...data };
    delete (safeData as any).tenantId;
    delete (safeData as any).id;
    const existing = await model.findFirst({ where: { id, tenantId: ctx.tenantId, deletedAt: null } });
    if (!existing) throw new Error(`Entity ${id} not found`);
    return model.update({ where: { id }, data: safeData });
  }

  // ============================================================
  // Soft Delete
  // ============================================================
  async softDelete(id: number, ctx: Context, tx?: ITransactionContext): Promise<void> {
    const model = tx ? this.getTxDelegate(tx) : this.model;
    const existing = await model.findFirst({ where: { id, tenantId: ctx.tenantId, deletedAt: null } });
    if (!existing) throw new Error(`Entity ${id} not found`);
    await model.update({ where: { id }, data: { deletedAt: new Date() } });
  }

  // ============================================================
  // Count
  // ============================================================
  async count(where: Record<string, any>, ctx: Context, tx?: ITransactionContext): Promise<number> {
    const model = tx ? this.getTxDelegate(tx) : this.model;
    // tenantId همیشه به‌صورت خودکار اعمال می‌شود (override نشدنی)
    const safeWhere = this.sanitizeFilters(where);
    return model.count({
      where: {
        ...safeWhere,
        tenantId: ctx.tenantId,
        deletedAt: null,
      },
    });
  }

  // ============================================================
  // Sanitize Filters — Whitelist enforcement
  // ============================================================
  /**
   * فقط فیلدهایی که در `allowedFilterFields()` هستند از `raw` کپی می‌شوند.
   * tenantId و deletedAt همیشه توسط BaseRepository خودمان مدیریت می‌شوند
   * و نمی‌توانند override شوند.
   */
  protected sanitizeFilters(raw: Record<string, any>): SanitizedFilters {
    const allowed = this.allowedFilterFields();
    const sanitized: SanitizedFilters = {};

    for (const key of Object.keys(raw)) {
      if (allowed.includes(key)) {
        sanitized[key] = raw[key];
      }
      // اگر فیلد مجاز نبود، نادیده گرفته می‌شود (silent ignore)
      // می‌توان در آینده یک warning هم log کرد
    }

    // tenantId و deletedAt هرگز از filters قابل override نیستند
    // (توسط BaseRepository خودشان مدیریت می‌شوند)
    delete sanitized.tenantId;
    delete sanitized.deletedAt;

    return sanitized;
  }

  // ============================================================
  // Helper: گرفتن delegate از Transaction Context
  // ============================================================
  /**
   * اگر عملیات داخل یک Unit of Work باشد، delegate باید از tx client
   * ساخته شود تا در همان تراکنش اجرا شود.
   * هر Subclass باید این متد را override کند تا modelName درست را پاس دهد.
   */
  protected getTxDelegate(_tx: ITransactionContext): PrismaModelDelegate<T> {
    // در حالت default، از default model استفاده می‌کنیم.
    // Subclassها باید این را override کنند تا delegate صحیح از tx بسازند.
    // مثال:
    //   protected getTxDelegate(tx: ITransactionContext) {
    //     return prismaTxDelegate<Product>(tx.client, 'product');
    //   }
    return this.model;
  }
}
