# YIO V8.3

V8.3 hardens multi-tenant product operations and introduces a relational product catalog flow using ProductImage, ProductVideo, ProductColor and ProductVariant while retaining legacy Product columns as a temporary compatibility mirror.

See `docs/MIGRATION-V8.2-to-V8.3.md` for deployment and the final cleanup migration.

# YIO V8 — پلتفرم تجارت الکترونیک و تولید Enterprise-Grade

> پلتفرم کامل فروشگاه آنلاین اسباب‌بازی چوبی با CRM، ERP، حسابداری، CQRS و Event Sourcing

## 📊 معرفی

YIO V8 یک جهش معماری از V7 است که ۱۰ بهبود اصلی برای مقیاس Enterprise دارد:

| # | بهبود | توضیح |
|---|-------|-------|
| ۱ | **Repository Interface** | وابستگی Engineها به اینترفیس به‌جای کلاس Concrete |
| ۲ | **Unit of Work + Transaction Manager** | تراکنش‌های atomic چندمرحله‌ای با rollback خودکار |
| ۳ | **Event Store** | ذخیره تمام Domain Eventها برای Audit و Replay |
| ۴ | **CQRS** | جداسازی Commands (write) و Queries (read) برای Performance |
| ۵ | **Typed Domain Events** | نام Eventها به‌جای رشته خام، تایپ‌شده (تایپ‌سیفتی) |
| ۶ | **Unit Tests** | Vitest + ۱۰ فایل تست برای Engineها و زیرساخت |
| ۷ | **Central Audit Log** | Audit غنی‌شده با userRole/operation/metadata/userAgent/requestId |
| ۸ | **DI Container** | Container سبک با Singleton/Transient/Scoped |
| ۹ | **Rule Engine توسعه‌پذیر** | Ruleهای استاتیک (کلاس) + داینامیک (DB) |
| ۱۰ | **Cache Layer (Redis)** | InMemory + Redis + `@cached` decorator |
| ۱۰b | **ABAC Permission** | ارتقاء RBAC به ABAC با Attributeهای محیطی |

## 🏗️ معماری

- **Backend**: Node.js + Express + TypeScript
- **Database**: PostgreSQL + Prisma ORM
- **Cache**: Redis (پشتیبانی InMemory fallback)
- **Frontend**: Next.js 14 + React 18
- **Mobile**: React Native + Expo
- **AI**: موتورهای پیش‌بینی، چت، تحلیل
- **Architecture**: Clean Architecture + DDD + CQRS + Event Sourcing + Multi-Tenant

## 📦 ساختار پروژه (V8)

```
yio-v8/
├── apps/                         # اپلیکیشن‌ها
│   ├── api/                      # REST API سرور (Express)
│   │   └── src/
│   │       ├── bootstrap.ts      # ← NEW: DI Container wiring
│   │       ├── server.ts
│   │       └── ...
│   ├── shop/ crm/ erp/ finance/ admin/  # پنل‌های Next.js
│   └── mobile/                   # اپ موبایل (Expo)
├── packages/
│   ├── core/                     # تایپ‌ها، مدل‌ها، رویدادها، اینترفیس‌ها
│   │   └── src/
│   │       ├── events/
│   │       │   ├── domain-events.ts
│   │       │   └── registry.ts   # ← NEW: Typed Events Registry
│   │       ├── interfaces/
│   │       │   └── index.ts      # ← UPDATED: IUnitOfWork, IEventStore, ICache, ICommandBus, IAbacPermissionChecker
│   │       ├── di/
│   │       │   └── tokens.ts     # ← NEW: DI Tokens
│   │       └── cqrs/
│   │           └── base.ts       # ← NEW: BaseCommand, BaseQuery
│   ├── repositories/
│   │   └── prisma/
│   │       ├── schema.prisma     # ← UPDATED: AuditLog enriched, EventStoreRecord, AbacPolicy
│   │       └── migrations/
│   │           └── v7-to-v8-migration.sql  # ← NEW
│   ├── services/                 # ۱۰ موتور تجاری + زیرساخت V8
│   │   └── src/
│   │       ├── event-bus/        # ← UPDATED: Typed + EventStore integration
│   │       ├── event-store/      # ← NEW
│   │       ├── unit-of-work/     # ← NEW
│   │       ├── audit/            # ← NEW
│   │       ├── cache/            # ← NEW
│   │       ├── di/               # ← NEW
│   │       ├── cqrs/             # ← NEW
│   │       ├── rule-engine/      # ← NEW
│   │       ├── rules/            # ← NEW
│   │       ├── engines/
│   │       │   ├── order-engine.ts       # ← REFACTORED
│   │       │   ├── permission-engine.ts  # ← UPDATED: ABAC
│   │       │   └── ...
│   │       └── __tests__/        # ← NEW: ۱۰ فایل تست
│   ├── ai/                       # ۵ موتور هوش مصنوعی
│   └── ui/                       # کامپوننت‌های مشترک
├── scripts/
├── docs/
│   └── MIGRATION-V7-to-V8.md     # ← NEW
└── vitest.config.ts              # ← NEW
```

## 🚀 شروع سریع

### پیش‌نیازها
- Node.js ≥ 18
- PostgreSQL ≥ 14
- Redis (اختیاری، در صورت تنظیم `REDIS_URL`)
- npm ≥ 9

### نصب

```bash
# 1. استخراج فایل zip
unzip yio-v8.zip
cd yio-v8

# 2. نصب وابستگی‌ها
npm install --legacy-peer-deps

# 3. کپی فایل env
cp .env.example .env
# .env را با اطلاعات دیتابیس خود ویرایش کنید

# 4. اجرای migration V7 → V8
psql $DATABASE_URL -f packages/repositories/prisma/migrations/v7-to-v8-migration.sql

# 5. اعمال schema به دیتابیس
cd packages/repositories
npx prisma generate --schema=prisma/schema.prisma
npx prisma db push --schema=prisma/schema.prisma --accept-data-loss

# 6. Seed دیتابیس
npx tsx prisma/seed.ts

# 7. اجرای تست‌ها (V8 — جدید)
cd ../..
npm test

# 8. شروع سرور
bash scripts/start-api.sh
```

### اجرای تست‌ها

```bash
# همه تست‌ها
npm test

# با watch mode
npm run test:watch

# با coverage
npx vitest run --coverage
```

## 📊 آمار پروژه (V8)

| شاخص | مقدار |
|------|-------|
| موتورهای تجاری | ۱۰ |
| موتورهای AI | ۵ |
| موجودیت‌های دامنه | ۸۱ (+۳: EventStoreRecord, AbacPolicy, AuditLog enriched) |
| مسیرهای API | ۱۲۹ |
| پنل‌های وب | ۵ |
| رویدادهای دامنه | ۵۰+ |
| **Unit Tests** | **۱۰ فایل** |
| **Ruleهای استاتیک** | **۹** |
| **Command Handlers** | **۶** |
| **Query Handlers** | **۵** |
| **DI Bindings** | **۲۰+** |
| **ABAC Policies** | **۵ پیش‌فرض** |

## 📖 مستندات

- `docs/MIGRATION-V7-to-V8.md` — راهنمای کامل مهاجرت V7 به V8
- `docs/SETUP-GUIDE.md` — راهنمای کامل راه‌اندازی
- `docs/DEBIAN-12-TUTORIAL.md` — آموزش گام به گام Debian 12
- `docs/API-REFERENCE.md` — مرجع API
- `docs/AI-FEATURES.md` — راهنمای هوش مصنوعی
- `docs/PANELS-ARCHITECTURE.md` — معماری پنل‌ها
- `docs/SCHEMA-REFERENCE.md` — مرجع دیتابیس

## 🛠️ اسکریپت‌ها

```bash
npm test                       # اجرای تست‌ها (V8)
npm run test:watch             # تست با watch mode
bash scripts/start-postgres.sh # شروع PostgreSQL (محلی)
bash scripts/start-api.sh      # شروع API
bash scripts/start-shop.sh     # شروع فروشگاه
bash scripts/stop-postgres.sh  # توقف PostgreSQL
bash scripts/deploy-vps.sh     # استقرار روی VPS
```

## 🎯 مثال استفاده (V8)

### ایجاد سفارش با CQRS

```typescript
import { CreateOrderCommand } from '@yio/services';
import { TOKENS } from '@yio/core';

// گرفتن CommandBus از Container
const commandBus = await container.resolve(TOKENS.CommandBus);

// اجرای Command
const result = await commandBus.execute(
  new CreateOrderCommand({
    items: [{ productId: 1, quantity: 2 }],
    shippingAddress: 'Tehran',
    recipientName: 'Ali',
    recipientPhone: '09120000000',
    paymentMethod: 'cod',
  }),
  ctx,
);
```

### Query با Cache خودکار

```typescript
import { ListOrdersQuery } from '@yio/services';

const queryBus = await container.resolve(TOKENS.QueryBus);
const orders = await queryBus.executeCached(
  new ListOrdersQuery('pending', 1, 20),
  ctx,
);
```

### بررسی ABAC Permission

```typescript
const permission = await container.resolve(TOKENS.PermissionEngine);
const decision = permission.checkAccess('order.view', ctx, {
  entityOwnerId: order.userId,
  entityStatus: order.status,
});
if (!decision.allowed) {
  throw new Error(`Unauthorized: ${decision.deniedReason}`);
}
```

## 📝 لایسنس

Proprietary — YIO Shop

---

**نسخه**: 8.0.0  
**تاریخ**: 2026-07-28
