// ============================================================
// YIO ERP Panel — Dashboard Page (V8.4 Rebuild)
// ============================================================
// پنل مدیریت تولید و انبار
// ============================================================

import React, { useState } from 'react';
import {
  PanelLayout,
  KpiCard,
  Card,
  Table,
  StatusBadge,
  Button,
  PageContainer,
  Badge,
  Tabs,
  Alert,
  SPACING,
  COLORS,
} from '@yio/ui';
import { formatCurrency, toPersianDigits } from '@yio/ui';

const PRIMARY_COLOR = '#10b981'; // ERP green

const NAV_ITEMS = [
  { label: 'داشبورد', icon: '📊', active: true },
  { label: 'دستورات کار', icon: '📋', badge: '۸' },
  {
    label: 'تولید', icon: '🏭', children: [
      { label: 'خط تولید' },
      { label: 'کنترل کیفیت' },
      { label: 'ضایعات' },
    ]
  },
  {
    label: 'انبار', icon: '📦', children: [
      { label: 'چوب خام' },
      { label: 'رنگ و مواد' },
      { label: 'محصول تمام‌شده' },
      { label: 'بسته‌بندی' },
    ]
  },
  {
    label: 'خرید', icon: '🛒', children: [
      { label: 'سفارشات خرید' },
      { label: 'تأمین‌کنندگان' },
    ]
  },
  { label: 'ماشین‌آلات', icon: '⚙️' },
  { label: 'نیروی انسانی', icon: '👷' },
  { label: 'گزارش‌ها', icon: '📈' },
];

export default function ERPDashboard() {
  const [activeTab, setActiveTab] = useState('workorders');

  const workOrders = [
    { id: 1, woNumber: 'WO-20260727-001', product: 'مایل ۱۰۰ تایی', qty: 50, status: 'in_progress', priority: 'high' },
    { id: 2, woNumber: 'WO-20260727-002', product: 'پازل حیوانات', qty: 100, status: 'planned', priority: 'normal' },
    { id: 3, woNumber: 'WO-20260727-003', product: 'دستکش عروسکی', qty: 30, status: 'completed', priority: 'low' },
    { id: 4, woNumber: 'WO-20260727-004', product: 'ماشین چوبی', qty: 75, status: 'paused', priority: 'high' },
    { id: 5, woNumber: 'WO-20260727-005', product: 'خانه عروسک', qty: 20, status: 'in_progress', priority: 'normal' },
  ];

  const lowStockItems = [
    { id: 1, name: 'چوب فینلاندی ۱۸mm', quantity: 5, unit: 'm²', threshold: 10 },
    { id: 2, name: 'رنگ پلی‌اورتان شفاف', quantity: 3, unit: 'لیتر', threshold: 5 },
    { id: 3, name: 'سمباده نرم ۱۲۰', quantity: 8, unit: 'عدد', threshold: 20 },
    { id: 4, name: 'چسب چوبی صنعتی', quantity: 2, unit: 'کیلوگرم', threshold: 8 },
  ];

  return (
    <PanelLayout
      theme="erp"
      primaryColor={PRIMARY_COLOR}
      title="YIO ERP"
      navItems={NAV_ITEMS}
      user={{ name: 'مدیر تولید', role: 'Production Manager' }}
      notifications={3}
      breadcrumbs={[
        { label: 'خانه' },
        { label: 'پنل ERP' },
        { label: 'داشبورد تولید' },
      ]}
      footer={
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.8125rem', color: COLORS.gray[500] }}>
          <span>© ۱۴۰۴ YIO ERP — تمام حقوق محفوظ است</span>
          <span>نسخه ۸.۴.۰</span>
        </div>
      }
    >
      <PageContainer
        title="داشبورد تولید و انبار"
        subtitle="نمای کلی از دستورات کار، موجودی و بهره‌وری"
        actions={
          <>
            <Button variant="outline" size="sm" icon="📈">گزارش تولید</Button>
            <Button variant="primary" size="sm" icon="➕" primaryColor={PRIMARY_COLOR}>دستور کار جدید</Button>
          </>
        }
      >
        {/* KPIs */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: SPACING.md,
          marginBottom: SPACING.xl,
        }}>
          <KpiCard
            title="دستورات کار فعال"
            value={toPersianDigits(8)}
            unit="عدد"
            icon="📋"
            color={PRIMARY_COLOR}
          />
          <KpiCard
            title="تولید امروز"
            value={toPersianDigits(142)}
            unit="عدد"
            icon="🏭"
            color={PRIMARY_COLOR}
            trend={{ value: 15, isPositive: true }}
          />
          <KpiCard
            title="اقلام کم‌موجودی"
            value={toPersianDigits(12)}
            unit="قلم"
            icon="⚠️"
            color="#f59e0b"
            trend={{ value: 4, isPositive: false }}
          />
          <KpiCard
            title="بازدهی تولید"
            value="۹۲٪"
            icon="📈"
            color="#10b981"
            trend={{ value: 2, isPositive: true }}
          />
        </div>

        {/* Low Stock Alert */}
        <div style={{ marginBottom: SPACING.xl }}>
          <Alert
            type="warning"
            title="هشدار کمبود موجودی"
            message={`${toPersianDigits(4)} قلم از مواد اولیه به حد آستانه رسیده‌اند — لطفاً در اسرع وقت نسبت به سفارش مجدد اقدام کنید.`}
          />
        </div>

        {/* Tabs */}
        <div style={{ marginBottom: SPACING.lg }}>
          <Tabs
            items={[
              { key: 'workorders', label: 'دستورات کار', icon: '📋', badge: 5 },
              { key: 'lowstock', label: 'هشدار کم‌موجودی', icon: '⚠️', badge: 4 },
            ]}
            active={activeTab}
            onChange={setActiveTab}
            primaryColor={PRIMARY_COLOR}
          />
        </div>

        {/* Work Orders Table */}
        {activeTab === 'workorders' && (
          <Card
            padding="none"
            title="دستورات کار اخیر"
            subtitle="آخرین دستورات کار ثبت‌شده در خط تولید"
            actions={
              <Button variant="ghost" size="sm" primaryColor={PRIMARY_COLOR}>مشاهده همه ←</Button>
            }
          >
            <Table
              columns={[
                { key: 'woNumber', title: 'شماره دستور', render: (row) => <strong style={{ color: PRIMARY_COLOR }}>{row.woNumber}</strong> },
                { key: 'product', title: 'محصول' },
                { key: 'qty', title: 'تعداد', render: (row) => <Badge variant="default">{toPersianDigits(row.qty)} عدد</Badge> },
                { key: 'priority', title: 'اولویت', render: (row) => <StatusBadge status={row.priority} /> },
                { key: 'status', title: 'وضعیت', render: (row) => <StatusBadge status={row.status} /> },
                { key: 'actions', title: 'عملیات', render: () => <Button size="sm" variant="ghost" primaryColor={PRIMARY_COLOR}>مشاهده</Button> },
              ]}
              data={workOrders}
              onRowClick={(row) => console.log('View work order', row.id)}
            />
          </Card>
        )}

        {/* Low Stock Table */}
        {activeTab === 'lowstock' && (
          <Card
            padding="none"
            title="هشدار کم‌موجودی"
            subtitle="مواد اولیه‌ای که به حد آستانه رسیده‌اند"
          >
            <Table
              columns={[
                { key: 'name', title: 'ماده اولیه', render: (row) => <strong>{row.name}</strong> },
                { key: 'quantity', title: 'موجودی فعلی', render: (row) => (
                  <span style={{ color: COLORS.danger[700], fontWeight: 600 }}>
                    {toPersianDigits(row.quantity)} {row.unit}
                  </span>
                ) },
                { key: 'threshold', title: 'حد آستانه', render: (row) => (
                  <span style={{ color: COLORS.gray[500] }}>
                    {toPersianDigits(row.threshold)} {row.unit}
                  </span>
                ) },
                { key: 'status', title: 'وضعیت', render: () => <StatusBadge status="warning" /> },
                { key: 'actions', title: 'عملیات', render: () => <Button size="sm" variant="outline" primaryColor={PRIMARY_COLOR}>سفارش خرید</Button> },
              ]}
              data={lowStockItems}
            />
          </Card>
        )}

        {/* Secondary cards */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
          gap: SPACING.lg,
          marginTop: SPACING.xl,
        }}>
          {/* Production Line Status */}
          <Card title="وضعیت خطوط تولید" subtitle="۳ خط فعال، ۱ خط متوقف">
            <div style={{ display: 'flex', flexDirection: 'column', gap: SPACING.md }}>
              <ProductionLine name="خط ۱ — مایل و بلوک" status="active" efficiency={95} color={PRIMARY_COLOR} />
              <ProductionLine name="خط ۲ — پازل و آموزشی" status="active" efficiency={88} color={PRIMARY_COLOR} />
              <ProductionLine name="خط ۳ — عروسکی" status="active" efficiency={92} color={PRIMARY_COLOR} />
              <ProductionLine name="خط ۴ — دکوراسیون" status="paused" efficiency={0} color={PRIMARY_COLOR} />
            </div>
          </Card>

          {/* Production Trend */}
          <Card title="روند تولید هفتگی" subtitle="تعداد تولید روزانه">
            <WeeklyProductionChart />
          </Card>
        </div>
      </PageContainer>
    </PanelLayout>
  );
}

// ============================================================
// Production Line Item
// ============================================================
function ProductionLine({ name, status, efficiency, color }: { name: string; status: 'active' | 'paused'; efficiency: number; color: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.md }}>
      <div style={{
        width: '8px', height: '8px', borderRadius: '50%',
        backgroundColor: status === 'active' ? '#10b981' : '#f59e0b',
        flexShrink: 0,
        boxShadow: status === 'active' ? '0 0 0 3px #10b98133' : '0 0 0 3px #f59e0b33',
      }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{ margin: 0, fontWeight: 600, fontSize: '0.875rem', color: COLORS.gray[900] }}>{name}</p>
        <div style={{
          width: '100%', height: '6px', backgroundColor: COLORS.gray[100],
          borderRadius: '9999px', overflow: 'hidden', marginTop: 4,
        }}>
          <div style={{
            width: `${efficiency}%`, height: '100%', backgroundColor: color,
            borderRadius: '9999px', transition: 'width 0.5s ease',
          }} />
        </div>
      </div>
      <div style={{ textAlign: 'left', flexShrink: 0 }}>
        <p style={{ margin: 0, fontWeight: 700, fontSize: '0.875rem', color: COLORS.gray[900] }}>
          {status === 'active' ? `${toPersianDigits(efficiency)}٪` : 'متوقف'}
        </p>
        <p style={{ margin: 0, fontSize: '0.75rem', color: status === 'active' ? COLORS.success[700] : COLORS.warning[700] }}>
          {status === 'active' ? 'فعال' : 'متوقف'}
        </p>
      </div>
    </div>
  );
}

// ============================================================
// Weekly Production Chart
// ============================================================
function WeeklyProductionChart() {
  const days = [
    { label: 'شنبه', value: 120 },
    { label: 'یکشنبه', value: 145 },
    { label: 'دوشنبه', value: 132 },
    { label: 'سه‌شنبه', value: 168 },
    { label: 'چهارشنبه', value: 142 },
    { label: 'پنجشنبه', value: 158 },
    { label: 'جمعه', value: 0 },
  ];
  const max = Math.max(...days.map((d) => d.value));

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: SPACING.xs, height: '180px', marginBottom: SPACING.sm }}>
        {days.map((d, i) => {
          const heightPercent = d.value === 0 ? 4 : (d.value / max) * 100;
          return (
            <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, height: '100%', justifyContent: 'flex-end' }}>
              <span style={{ fontSize: '0.7rem', color: COLORS.gray[700], fontWeight: 600 }}>
                {d.value > 0 ? toPersianDigits(d.value) : '—'}
              </span>
              <div style={{
                width: '100%', maxWidth: '32px', height: `${heightPercent}%`,
                background: d.value === 0 ? COLORS.gray[200] : 'linear-gradient(180deg, #10b981, #047857)',
                borderRadius: '4px 4px 0 0', transition: 'height 0.5s ease',
                minHeight: '4px',
              }} />
            </div>
          );
        })}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: SPACING.xs }}>
        {days.map((d, i) => (
          <span key={i} style={{ flex: 1, textAlign: 'center', fontSize: '0.7rem', color: COLORS.gray[500] }}>{d.label}</span>
        ))}
      </div>
    </div>
  );
}
