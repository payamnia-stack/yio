// ============================================================
// YIO V7 — Error Handler Middleware
// ============================================================
// مدیریت یکپارچه خطاها با:
//   - BusinessError (کدهای تجاری)
//   - ZodError (اعتبارسنجی)
//   - Prisma errors
//   - Unhandled errors
// ============================================================

import { Request, Response, NextFunction } from 'express';
import { BusinessError } from '@yio/core';
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library';

// ===== Async Handler Wrapper =====
// برای جلوگیری از try/catch در هر route
export function asyncHandler<T extends Request = Request>(
  fn: (req: T, res: Response, next: NextFunction) => Promise<any>,
) {
  return (req: T, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

// ===== Not Found Handler =====
export function notFoundHandler(req: Request, res: Response): void {
  res.status(404).json({
    success: false,
    error: {
      code: 'NOT_FOUND',
      message: `مسیر ${req.method} ${req.path} یافت نشد`,
    },
  });
}

// ===== Global Error Handler =====
export function errorHandler(err: any, req: Request, res: Response, next: NextFunction): void {
  // اگر headers قبلاً ارسال شده
  if (res.headersSent) {
    return next(err);
  }

  // 1. BusinessError
  if (err instanceof BusinessError) {
    res.status(err.statusCode || 400).json({
      success: false,
      error: {
        code: err.code,
        message: err.message,
        field: err.field,
      },
    });
    return;
  }

  // 2. Prisma Errors
  if (err instanceof PrismaClientKnownRequestError) {
    switch (err.code) {
      case 'P2002':
        // Unique constraint violation
        const target = (err.meta?.target as string[]) || [];
        res.status(409).json({
          success: false,
          error: {
            code: 'DUPLICATE_ENTRY',
            message: `مقدار فیلد ${target.join(', ')} تکراری است`,
            fields: target,
          },
        });
        return;

      case 'P2025':
        // Record not found
        res.status(404).json({
          success: false,
          error: {
            code: 'NOT_FOUND',
            message: 'رکورد یافت نشد',
          },
        });
        return;

      case 'P2003':
        // Foreign key constraint violation
        res.status(400).json({
          success: false,
          error: {
            code: 'FOREIGN_KEY_VIOLATION',
            message: 'این رکورد به رکوردهای دیگر وابسته است و قابل حذف/ویرایش نیست',
          },
        });
        return;

      default:
        res.status(400).json({
          success: false,
          error: {
            code: 'DATABASE_ERROR',
            message: `خطای پایگاه داده: ${err.code}`,
          },
        });
        return;
    }
  }

  // 3. Zod Validation Error
  if (err.name === 'ZodError') {
    res.status(422).json({
      success: false,
      error: {
        code: 'VALIDATION_ERROR',
        message: 'خطای اعتبارسنجی داده‌ها',
        details: err.errors || err.issues,
      },
    });
    return;
  }

  // 4. JWT Errors
  if (err.name === 'JsonWebTokenError') {
    res.status(401).json({
      success: false,
      error: {
        code: 'INVALID_TOKEN',
        message: 'توکن نامعتبر است',
      },
    });
    return;
  }

  if (err.name === 'TokenExpiredError') {
    res.status(401).json({
      success: false,
      error: {
        code: 'TOKEN_EXPIRED',
        message: 'توکن منقضی شده است',
      },
    });
    return;
  }

  // 5. Multer Errors (File Upload)
  if (err.code === 'LIMIT_FILE_SIZE') {
    res.status(413).json({
      success: false,
      error: {
        code: 'FILE_TOO_LARGE',
        message: 'حجم فایل بیش از حد مجاز است',
      },
    });
    return;
  }

  // 6. Syntax Error (JSON parse)
  if (err.type === 'entity.parse.failed') {
    res.status(400).json({
      success: false,
      error: {
        code: 'INVALID_JSON',
        message: 'فرمت JSON ارسالی نامعتبر است',
      },
    });
    return;
  }

  // 7. Unhandled Errors
  console.error('[ErrorHandler] Unhandled error:', err);
  res.status(500).json({
    success: false,
    error: {
      code: 'INTERNAL_ERROR',
      message: process.env.NODE_ENV === 'production'
        ? 'خطای داخلی سرور'
        : err.message || 'Unknown error',
      stack: process.env.NODE_ENV === 'production' ? undefined : err.stack,
    },
  });
}
