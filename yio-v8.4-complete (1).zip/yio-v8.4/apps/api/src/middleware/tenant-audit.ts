// ============================================================
// YIO V7 — Tenant Resolver & Audit Logger Middleware
// ============================================================
// - Tenant Resolver: شناسایی tenant از روی دامنه/هدر/توکن
// - Audit Logger: ثبت خودکار تغییرات در AuditLog
// ============================================================

import { Request, Response, NextFunction } from 'express';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// ===== Tenant Resolver =====
// tenantId را از توابع زیر استخراج می‌کند (به ترتیب اولویت):
//   1. JWT token (req.user.tenantId)
//   2. Header x-tenant-id
//   3. Subdomain (crm.yio.ir → tenantId از DB)
//   4. Default = 1
export async function tenantResolver(req: Request, res: Response, next: NextFunction): Promise<void> {
  let tenantId = 1;

  // 1. از توکن
  const user = (req as any).user;
  if (user?.tenantId) {
    tenantId = user.tenantId;
  } else {
    // 2. از header
    const headerTenant = req.headers['x-tenant-id'] as string;
    if (headerTenant) {
      const parsed = parseInt(headerTenant, 10);
      if (!isNaN(parsed) && parsed > 0) {
        tenantId = parsed;
      }
    } else {
      // 3. از subdomain
      const host = req.headers.host || '';
      const subdomain = host.split('.')[0];
      if (subdomain && subdomain !== 'www' && subdomain !== 'yio' && subdomain !== 'localhost') {
        const tenant = await prisma.tenant.findFirst({
          where: { domain: { contains: subdomain } },
        });
        if (tenant) {
          tenantId = tenant.id;
        }
      }
    }
  }

  (req as any).tenantId = tenantId;
  next();
}

// ===== Audit Logger =====
// تمام درخواست‌های write (POST/PUT/PATCH/DELETE) را در AuditLog ثبت می‌کند
export function auditLogger(entityType?: string) {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    // فقط درخواست‌های write را ثبت کن
    if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
      next();
      return;
    }

    const startTime = Date.now();

    // capture original send
    const originalSend = res.send;
    let responseBody: any;

    res.send = function (body: any): Response {
      responseBody = body;
      return originalSend.call(this, body);
    };

    res.on('finish', async () => {
      const duration = Date.now() - startTime;
      const user = (req as any).user;

      // فقط درخواست‌های موفق را لاگ کن
      if (res.statusCode >= 200 && res.statusCode < 400) {
        try {
          // استخراج entityId از URL یا body
          const pathParts = req.path.split('/');
          const entityIdStr = pathParts.find(p => /^\d+$/.test(p));
          const entityId = entityIdStr ? parseInt(entityIdStr, 10) : 0;

          await prisma.auditLog.create({
            data: {
              tenantId: (req as any).tenantId || 1,
              userId: user?.userId || null,
              action: `${req.method}:${req.path}`,
              entityType: entityType || pathParts[2] || 'unknown',
              entityId: entityId || 0,
              changes: JSON.stringify({
                method: req.method,
                path: req.path,
                body: sanitizeBody(req.body),
                query: req.query,
                params: req.params,
                statusCode: res.statusCode,
                duration,
              }),
              ip: req.ip,
              timestamp: new Date(),
            },
          });
        } catch (e) {
          console.error('[AuditLogger] Failed to log:', e);
        }
      }
    });

    next();
  };
}

// ===== Sanitize Body (حذف فیلدهای حساس) =====
function sanitizeBody(body: any): any {
  if (!body || typeof body !== 'object') return body;

  const sanitized = { ...body };
  const sensitiveFields = ['password', 'token', 'secret', 'creditCard', 'cvv', 'pin'];

  for (const field of sensitiveFields) {
    if (sanitized[field]) {
      sanitized[field] = '***REDACTED***';
    }
  }

  return sanitized;
}

// ===== Request Logger =====
// لاگ ساده درخواست‌ها (برای development)
export function requestLogger(req: Request, res: Response, next: NextFunction): void {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    const user = (req as any).user;
    const userId = user?.userId || '-';
    console.log(
      `[${new Date().toISOString()}] ${req.method} ${req.path} ${res.statusCode} ${duration}ms user=${userId}`,
    );
  });
  next();
}
