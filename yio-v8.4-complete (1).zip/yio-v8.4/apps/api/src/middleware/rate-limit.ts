// ============================================================
// YIO V7 — Rate Limiting Middleware
// ============================================================
// محدودیت نرخ درخواست برای جلوگیری از abuse و DDoS
// با پشتیبانی از:
//   - محدودیت کلی (general)
//   - محدودیت احراز هویت (login)
//   - محدودیت بر اساس نقش (role-based)
//   - محدودیت IP
// ============================================================

import rateLimit from 'express-rate-limit';
import { Request } from 'express';

// ===== General Rate Limit (100 req / 15 min per IP) =====
export const generalRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    error: {
      code: 'RATE_LIMIT_EXCEEDED',
      message: 'تعداد درخواست‌ها بیش از حد مجاز است. لطفاً ۱۵ دقیقه بعد تلاش کنید.',
    },
  },
  keyGenerator: (req: Request) => {
    const user = (req as any).user;
    return user ? `user:${user.userId}` : `ip:${req.ip}`;
  },
});

// ===== Auth Rate Limit (5 attempts / 15 min) =====
export const authRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    error: {
      code: 'AUTH_RATE_LIMIT',
      message: 'تعداد تلاش‌های ورود بیش از حد مجاز است. ۱۵ دقیقه بعد تلاش کنید.',
    },
  },
  keyGenerator: (req: Request) => `auth:${req.ip}`,
});

// ===== API Write Rate Limit (30 writes / min) =====
export const writeRateLimit = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    error: {
      code: 'WRITE_RATE_LIMIT',
      message: 'تعداد درخواست‌های نوشتن بیش از حد مجاز است.',
    },
  },
  keyGenerator: (req: Request) => {
    const user = (req as any).user;
    return user ? `write:user:${user.userId}` : `write:ip:${req.ip}`;
  },
});

// ===== Upload Rate Limit (10 uploads / hour) =====
export const uploadRateLimit = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    success: false,
    error: {
      code: 'UPLOAD_RATE_LIMIT',
      message: 'تعداد آپلودهای شما بیش از حد مجاز است. ۱ ساعت بعد تلاش کنید.',
    },
  },
  keyGenerator: (req: Request) => {
    const user = (req as any).user;
    return user ? `upload:user:${user.userId}` : `upload:ip:${req.ip}`;
  },
});

// ===== Admin Rate Limit (relaxed) =====
export const adminRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 1000,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req: Request) => {
    const user = (req as any).user;
    return user ? `admin:user:${user.userId}` : `admin:ip:${req.ip}`;
  },
});
