// ============================================================
// YIO V7 — Auth Middleware (JWT)
// ============================================================
// احراز هویت مبتنی بر JWT با پشتیبانی از:
//   - access token (کوتاه‌مدت)
//   - refresh token (بلندمدت)
//   - permission check
//   - role check
//   - tenant resolution
// ============================================================

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { PrismaClient } from '@prisma/client';
import { Context } from '@yio/core';
// eslint-disable-next-line @typescript-eslint/no-var-requires
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

const JWT_SECRET = process.env.JWT_SECRET || 'yio-v7-super-secret-change-me';
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'yio-v7-refresh-secret-change-me';
const ACCESS_TOKEN_TTL = '15m'; // 15 minutes
const REFRESH_TOKEN_TTL = '7d'; // 7 days

// ===== Token Generation =====
export interface JwtPayload {
  userId: number;
  tenantId: number;
  phone: string;
  level: number;
  role?: string;
  isWholesale: boolean;
}

export function generateAccessToken(payload: JwtPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: ACCESS_TOKEN_TTL });
}

export function generateRefreshToken(payload: JwtPayload): string {
  return jwt.sign(payload, JWT_REFRESH_SECRET, { expiresIn: REFRESH_TOKEN_TTL });
}

export function verifyAccessToken(token: string): JwtPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as JwtPayload;
  } catch {
    return null;
  }
}

export function verifyRefreshToken(token: string): JwtPayload | null {
  try {
    return jwt.verify(token, JWT_REFRESH_SECRET) as JwtPayload;
  } catch {
    return null;
  }
}

// ===== Build Context =====
export function buildContext(req: Request): Context {
  const user = (req as any).user as JwtPayload | undefined;
  return {
    tenantId: user?.tenantId || parseInt(req.headers['x-tenant-id'] as string, 10) || 1,
    userId: user?.userId,
    userRole: user?.role || (user?.level === 3 ? 'admin' : user?.level === 2 ? 'staff' : 'customer'),
    permissions: (req as any).permissions || [],
    ip: req.ip || req.socket.remoteAddress,
    userAgent: req.headers['user-agent'],
  };
}

// ===== Auth Middleware =====
// الزامی بودن احراز هویت
export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({
      success: false,
      error: {
        code: 'UNAUTHORIZED',
        message: 'توکن احراز هویت ارسال نشده است',
      },
    });
    return;
  }

  const token = authHeader.slice(7);
  const payload = verifyAccessToken(token);

  if (!payload) {
    res.status(401).json({
      success: false,
      error: {
        code: 'INVALID_TOKEN',
        message: 'توکن نامعتبر یا منقضی شده است',
      },
    });
    return;
  }

  (req as any).user = payload;
  next();
}

// ===== Optional Auth Middleware =====
// در صورت وجود توکن، اعتبارسنجی می‌کند ولی اجازه دسترسی بدون توکن را هم می‌دهد
export function optionalAuth(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.slice(7);
    const payload = verifyAccessToken(token);
    if (payload) {
      (req as any).user = payload;
    }
  }
  next();
}

// ===== Role Check Middleware =====
export function requireRole(...roles: string[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const user = (req as any).user as JwtPayload | undefined;
    if (!user) {
      res.status(401).json({
        success: false,
        error: { code: 'UNAUTHORIZED', message: 'احراز هویت لازم است' },
      });
      return;
    }

    // تبدیل level به role
    const userRole = user.role ||
      (user.level === 3 ? 'admin' : user.level === 2 ? 'staff' : 'customer');

    if (!roles.includes(userRole)) {
      res.status(403).json({
        success: false,
        error: {
          code: 'FORBIDDEN',
          message: 'دسترسی به این بخش محدود است',
          requiredRoles: roles,
        },
      });
      return;
    }

    next();
  };
}

// ===== Permission Check Middleware =====
export function requirePermission(permission: string) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const user = (req as any).user as JwtPayload | undefined;
    if (!user) {
      res.status(401).json({
        success: false,
        error: { code: 'UNAUTHORIZED', message: 'احراز هویت لازم است' },
      });
      return;
    }

    // مدیران (level=3) دسترسی کامل دارند
    if (user.level === 3) {
      (req as any).permissions = ['*'];
      next();
      return;
    }

    // در عمل باید از PermissionChecker استفاده شود
    // فعلاً برای کاربران level < 3 چک می‌کنیم
    const userPermissions: string[] = (req as any).permissions || [];

    if (!userPermissions.includes(permission) && !userPermissions.includes('*')) {
      res.status(403).json({
        success: false,
        error: {
          code: 'FORBIDDEN',
          message: `دسترسی "${permission}" لازم است`,
        },
      });
      return;
    }

    next();
  };
}

// ===== Admin Only =====
export function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  return requireRole('admin', 'super_admin')(req, res, next);
}

// ===== Login Helper =====
export async function loginUser(phone: string, password: string): Promise<{
  accessToken: string;
  refreshToken: string;
  user: any;
} | null> {
  const user = await prisma.user.findFirst({
    where: { phone },
  });

  if (!user || !user.password) return null;

  // استفاده از bcryptjs برای مقایسه رمز
  const isValid = await bcrypt.compare(password, user.password);
  if (!isValid) return null;

  const payload: JwtPayload = {
    userId: user.id,
    tenantId: user.tenantId,
    phone: user.phone,
    level: user.level,
    isWholesale: user.isWholesale,
  };

  return {
    accessToken: generateAccessToken(payload),
    refreshToken: generateRefreshToken(payload),
    user: {
      id: user.id,
      phone: user.phone,
      name: user.name,
      level: user.level,
      isWholesale: user.isWholesale,
    },
  };
}

// ===== Refresh Token Helper =====
export function refreshAccessToken(refreshToken: string): string | null {
  const payload = verifyRefreshToken(refreshToken);
  if (!payload) return null;

  const newPayload: JwtPayload = {
    userId: payload.userId,
    tenantId: payload.tenantId,
    phone: payload.phone,
    level: payload.level,
    isWholesale: payload.isWholesale,
  };

  return generateAccessToken(newPayload);
}
