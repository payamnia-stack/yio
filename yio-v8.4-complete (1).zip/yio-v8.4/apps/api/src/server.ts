// ============================================================
// YIO V7 — API Server (Phase 4)
// ============================================================
// Express server با:
//   - Helmet (security headers)
//   - CORS
//   - Compression
//   - Morgan (logging)
//   - JSON parser (with size limit)
//   - Tenant resolver
//   - Rate limiting
//   - Swagger UI (/api/docs)
//   - All engine routes (/api/v1/*)
//   - Health check (/api/health)
//   - Error handler
// ============================================================

import express, { Request, Response, NextFunction } from 'express';
import helmet from 'helmet';
import cors from 'cors';
import compression from 'compression';
import morgan from 'morgan';
import swaggerUi from 'swagger-ui-express';

import routes from './routes';
import { errorHandler, notFoundHandler } from './middleware/error-handler';
import { generalRateLimit, authRateLimit, writeRateLimit } from './middleware/rate-limit';
import { tenantResolver, auditLogger, requestLogger } from './middleware/tenant-audit';
import { generateOpenAPISpec } from './docs/openapi';
import { PrismaClient } from '@prisma/client';
import { bootstrapContainer } from './bootstrap';

const app = express();
const PORT = parseInt(process.env.PORT || '4000', 10);
const NODE_ENV = process.env.NODE_ENV || 'development';

// ===== Security Middleware =====
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' },
}));

// ===== CORS =====
app.use(cors({
  origin: process.env.CORS_ORIGINS?.split(',') || ['http://localhost:3000', 'http://localhost:3001'],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Tenant-Id', 'X-Request-Id'],
}));

// ===== Compression =====
app.use(compression());

// ===== Logging =====
app.use(morgan(NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use(requestLogger);

// ===== Body Parser =====
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ===== Static Files (uploads) =====
app.use('/uploads', express.static('storage/uploads', {
  maxAge: '7d',
  setHeaders: (res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
  },
}));

// ===== Health Check (before rate limit) =====
app.get('/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    service: 'yio-api',
    version: '8.3.0',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: NODE_ENV,
  });
});

// ===== General Rate Limit =====
app.use('/api', generalRateLimit);

// ===== Auth Rate Limit =====
app.use('/api/v1/auth/login', authRateLimit);
app.use('/api/v1/auth/register', authRateLimit);
app.use('/api/v1/auth/resend-code', authRateLimit);

// ===== Write Rate Limit =====
app.use('/api/v1', (req: Request, res: Response, next: NextFunction) => {
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
    return writeRateLimit(req, res, next);
  }
  next();
});

// ===== Tenant Resolver =====
app.use('/api/v1', tenantResolver);

// ===== Audit Logger =====
app.use('/api/v1', auditLogger());

// ===== Swagger UI =====
const openApiSpec = generateOpenAPISpec();
app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(openApiSpec, {
  customSiteTitle: 'YIO V7 API Documentation',
  customCss: '.swagger-ui .topbar { display: none }',
}));

// ===== API Routes =====
app.use('/api/v1', routes);

// ===== 404 Handler =====
app.use(notFoundHandler);

// ===== Global Error Handler =====
app.use(errorHandler);

// ===== Start Server =====
async function startServer() {
  const prisma = new PrismaClient();
  await bootstrapContainer(prisma, { useRedis: process.env.USE_REDIS === 'true' });
  (global as any).__yioContainer = (global as any).__yioContainer;
  app.listen(PORT, () => {
    console.log('═══════════════════════════════════════════════════');
    console.log(`  YIO V8.3 API Server`);
    console.log(`  Environment: ${NODE_ENV}`);
    console.log(`  Port: ${PORT}`);
    console.log(`  API:    http://localhost:${PORT}/api/v1`);
    console.log(`  Docs:   http://localhost:${PORT}/api/docs`);
    console.log(`  Health: http://localhost:${PORT}/health`);
    console.log('═══════════════════════════════════════════════════');
  });
}

if (process.env.NODE_ENV !== 'test') {
  startServer().catch((error) => {
    console.error('Failed to start YIO API', error);
    process.exit(1);
  });
}

export default app;
