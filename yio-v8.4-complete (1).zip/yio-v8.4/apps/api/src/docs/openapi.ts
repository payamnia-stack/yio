// ============================================================
// YIO V7 — OpenAPI/Swagger Specification Generator
// ============================================================
// تولید خودکار spec از ساختار routes
// قابل مشاهده در: /api/docs
// ============================================================

export function generateOpenAPISpec() {
  return {
    openapi: '3.0.3',
    info: {
      title: 'YIO V7 API',
      description: `# YIO V7 — REST API Documentation

پلتفرم کامل تجارت الکترونیک و تولید اسباب‌بازی چوبی YIO

## احراز هویت

تمام مسیرهای محافظت‌شده نیاز به Bearer Token دارند:

\`\`\`
Authorization: Bearer <your-access-token>
\`\`\`

برای دریافت توکن، از مسیر \`/api/v1/auth/login\` استفاده کنید.

## Multi-Tenant

تمام درخواست‌ها به طور خودکار به Tenant کاربر متصل می‌شوند.
می‌توانید Tenant را با header \`X-Tenant-Id\` نیز تعیین کنید.

## محدودیت نرخ

- عمومی: 100 درخواست در 15 دقیقه
- احراز هویت: 5 تلاش در 15 دقیقه
- نوشتن: 30 درخواست در دقیقه

## خطاها

تمام خطاها با فرمت استاندارد زیر برمی‌گردند:

\`\`\`json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "توضیح خطا",
    "field": "field_name"
  }
}
\`\`\`
`,
      version: '7.0.0',
      contact: {
        name: 'YIO Shop',
        url: 'https://yio.ir',
        email: 'info@yio.ir',
      },
      license: {
        name: 'Proprietary',
        url: 'https://yio.ir/license',
      },
    },
    servers: [
      {
        url: 'http://localhost:4000/api/v1',
        description: 'Development',
      },
      {
        url: 'https://api.yio.ir/api/v1',
        description: 'Production',
      },
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
          description: 'JWT Authorization header using the Bearer scheme',
        },
      },
      schemas: {
        Error: {
          type: 'object',
          properties: {
            success: { type: 'boolean', example: false },
            error: {
              type: 'object',
              properties: {
                code: { type: 'string', example: 'BUSINESS_ERROR' },
                message: { type: 'string', example: 'توضیح خطا' },
                field: { type: 'string', example: 'fieldName' },
              },
            },
          },
        },
        Success: {
          type: 'object',
          properties: {
            success: { type: 'boolean', example: true },
            data: { type: 'object' },
          },
        },
        PaginatedResponse: {
          type: 'object',
          properties: {
            success: { type: 'boolean', example: true },
            data: { type: 'array', items: { type: 'object' } },
            pagination: {
              type: 'object',
              properties: {
                page: { type: 'integer', example: 1 },
                pageSize: { type: 'integer', example: 20 },
                total: { type: 'integer', example: 100 },
                totalPages: { type: 'integer', example: 5 },
              },
            },
          },
        },
        User: {
          type: 'object',
          properties: {
            id: { type: 'integer' },
            phone: { type: 'string', example: '09120000000' },
            name: { type: 'string', example: 'محمد محمدی' },
            email: { type: 'string', example: 'user@yio.ir' },
            level: { type: 'integer', example: 0 },
            isWholesale: { type: 'boolean', example: false },
            isVerified: { type: 'boolean', example: true },
          },
        },
        Product: {
          type: 'object',
          properties: {
            id: { type: 'integer' },
            title: { type: 'string', example: 'مایل سنگریزه‌ای چوبی ۱۰۰ تایی' },
            brand: { type: 'string', example: 'YIO' },
            category: { type: 'string', example: 'wooden-building-blocks' },
            price: { type: 'integer', example: 350000 },
            discountPrice: { type: 'integer', example: 280000 },
            image: { type: 'string', example: '/uploads/products/product1.webp' },
            stockQuantity: { type: 'integer', example: 50 },
            isPublished: { type: 'boolean', example: true },
            rating: { type: 'number', example: 4.5 },
            ratingCount: { type: 'integer', example: 23 },
          },
        },
        Order: {
          type: 'object',
          properties: {
            id: { type: 'integer' },
            orderNumber: { type: 'string', example: 'YIO-20260727-0001' },
            status: { type: 'string', enum: ['pending', 'confirmed', 'shipping', 'delivered', 'cancelled'] },
            totalAmount: { type: 'integer', example: 700000 },
            shippingCost: { type: 'integer', example: 89000 },
            finalAmount: { type: 'integer', example: 789000 },
            paymentMethod: { type: 'string', example: 'cod' },
            paymentStatus: { type: 'string', enum: ['unpaid', 'paid', 'refunded'] },
            recipientName: { type: 'string', example: 'محمد محمدی' },
            recipientPhone: { type: 'string', example: '09120000000' },
            shippingAddress: { type: 'string', example: 'تهران، خیابان ولیعصر، پلاک ۱' },
            trackingCode: { type: 'string', example: 'TRK123456789' },
            items: { type: 'array', items: { $ref: '#/components/schemas/OrderItem' } },
          },
        },
        OrderItem: {
          type: 'object',
          properties: {
            id: { type: 'integer' },
            productId: { type: 'integer' },
            productTitle: { type: 'string' },
            productImage: { type: 'string' },
            price: { type: 'integer' },
            quantity: { type: 'integer' },
            color: { type: 'string' },
          },
        },
        WorkOrder: {
          type: 'object',
          properties: {
            id: { type: 'integer' },
            woNumber: { type: 'string', example: 'WO-20260727-001' },
            productId: { type: 'integer' },
            orderId: { type: 'integer' },
            quantity: { type: 'integer' },
            priority: { type: 'string', enum: ['low', 'normal', 'high', 'urgent'] },
            status: { type: 'string', enum: ['planned', 'in_progress', 'paused', 'completed', 'cancelled'] },
            startDate: { type: 'string', format: 'date-time' },
            endDate: { type: 'string', format: 'date-time' },
            expectedDate: { type: 'string', format: 'date-time' },
            assignedTo: { type: 'string' },
          },
        },
        LoginRequest: {
          type: 'object',
          required: ['phone', 'password'],
          properties: {
            phone: { type: 'string', example: '09120000000' },
            password: { type: 'string', example: 'password123' },
          },
        },
        LoginResponse: {
          type: 'object',
          properties: {
            success: { type: 'boolean', example: true },
            data: {
              type: 'object',
              properties: {
                accessToken: { type: 'string' },
                refreshToken: { type: 'string' },
                user: { $ref: '#/components/schemas/User' },
              },
            },
          },
        },
        PricingResult: {
          type: 'object',
          properties: {
            basePrice: { type: 'integer' },
            unitPrice: { type: 'integer' },
            quantity: { type: 'integer' },
            subtotal: { type: 'integer' },
            discountRate: { type: 'number' },
            discountAmount: { type: 'integer' },
            couponDiscount: { type: 'integer' },
            shippingCost: { type: 'integer' },
            taxAmount: { type: 'integer' },
            totalAmount: { type: 'integer' },
            finalAmount: { type: 'integer' },
          },
        },
        DashboardData: {
          type: 'object',
          properties: {
            kpis: { type: 'object' },
            charts: {
              type: 'object',
              properties: {
                salesTrend: { type: 'array', items: { type: 'object' } },
                topProducts: { type: 'array', items: { type: 'object' } },
                productionStatus: { type: 'object' },
                inventoryByWarehouse: { type: 'array', items: { type: 'object' } },
              },
            },
            alerts: { type: 'array', items: { type: 'object' } },
            generatedAt: { type: 'string', format: 'date-time' },
          },
        },
      },
    },
    security: [
      { bearerAuth: [] },
    ],
    tags: [
      { name: 'Auth', description: 'احراز هویت' },
      { name: 'Users', description: 'مدیریت کاربران' },
      { name: 'Products', description: 'مدیریت محصولات' },
      { name: 'Orders', description: 'مدیریت سفارشات' },
      { name: 'Production', description: 'دستورات کار و تولید' },
      { name: 'Inventory', description: 'انبار و موجودی' },
      { name: 'Pricing', description: 'قیمت‌گذاری و تخفیف' },
      { name: 'Accounting', description: 'حسابداری و مالی' },
      { name: 'Workflow', description: 'گردش کار' },
      { name: 'Analytics', description: 'گزارش‌گیری و داشبورد' },
      { name: 'Documents', description: 'مدیریت اسناد' },
      { name: 'Rules', description: 'قوانین پویا' },
      { name: 'Notifications', description: 'اعلان‌ها' },
      { name: 'Suppliers', description: 'تأمین‌کنندگان' },
      { name: 'Purchase Orders', description: 'سفارشات خرید' },
      { name: 'Machines', description: 'ماشین‌آلات' },
      { name: 'Employees', description: 'نیروی انسانی' },
      { name: 'Audit Logs', description: 'لاگ تغییرات' },
      { name: 'Tenants', description: 'مدیریت Tenantها' },
    ],
    paths: {
      // ===== AUTH =====
      '/auth/login': {
        post: {
          tags: ['Auth'],
          summary: 'ورود به سیستم',
          security: [],
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: { $ref: '#/components/schemas/LoginRequest' },
              },
            },
          },
          responses: {
            200: {
              description: 'ورود موفق',
              content: {
                'application/json': {
                  schema: { $ref: '#/components/schemas/LoginResponse' },
                },
              },
            },
            401: { description: 'خطای اعتبارسنجی', schema: { $ref: '#/components/schemas/Error' } },
          },
        },
      },
      '/auth/register': {
        post: {
          tags: ['Auth'],
          summary: 'ثبت‌نام کاربر جدید',
          security: [],
          requestBody: {
            required: true,
            content: { 'application/json': { schema: { type: 'object' } } },
          },
          responses: {
            201: { description: 'ثبت‌نام موفق', schema: { $ref: '#/components/schemas/LoginResponse' } },
            409: { description: 'کاربر تکراری', schema: { $ref: '#/components/schemas/Error' } },
          },
        },
      },
      '/auth/refresh': {
        post: {
          tags: ['Auth'],
          summary: 'تمدید توکن',
          security: [],
          requestBody: {
            required: true,
            content: { 'application/json': { schema: { type: 'object', properties: { refreshToken: { type: 'string' } } } } },
          },
          responses: {
            200: { description: 'توکن جدید', schema: { type: 'object' } },
            401: { description: 'توکن نامعتبر', schema: { $ref: '#/components/schemas/Error' } },
          },
        },
      },
      '/auth/me': {
        get: {
          tags: ['Auth'],
          summary: 'دریافت اطلاعات کاربر فعلی',
          responses: {
            200: { description: 'اطلاعات کاربر', schema: { $ref: '#/components/schemas/User' } },
            401: { description: 'احراز هویت لازم است', schema: { $ref: '#/components/schemas/Error' } },
          },
        },
      },

      // ===== PRODUCTS =====
      '/products': {
        get: {
          tags: ['Products'],
          summary: 'دریافت لیست محصولات',
          parameters: [
            { name: 'page', in: 'query', schema: { type: 'integer', default: 1 } },
            { name: 'pageSize', in: 'query', schema: { type: 'integer', default: 20 } },
            { name: 'search', in: 'query', schema: { type: 'string' } },
            { name: 'category', in: 'query', schema: { type: 'string' } },
            { name: 'isPublished', in: 'query', schema: { type: 'boolean' } },
            { name: 'isSpecial', in: 'query', schema: { type: 'boolean' } },
            { name: 'sort', in: 'query', schema: { type: 'string', default: 'createdAt' } },
            { name: 'order', in: 'query', schema: { type: 'string', enum: ['asc', 'desc'], default: 'desc' } },
          ],
          responses: {
            200: { description: 'لیست محصولات', schema: { $ref: '#/components/schemas/PaginatedResponse' } },
          },
        },
        post: {
          tags: ['Products'],
          summary: 'ایجاد محصول جدید',
          requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/Product' } } } },
          responses: {
            201: { description: 'محصول ایجاد شد', schema: { $ref: '#/components/schemas/Success' } },
            403: { description: 'دسترسی ممنوع', schema: { $ref: '#/components/schemas/Error' } },
          },
        },
      },
      '/products/{id}': {
        get: {
          tags: ['Products'],
          summary: 'دریافت یک محصول',
          parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
          responses: {
            200: { description: 'محصول', schema: { $ref: '#/components/schemas/Product' } },
            404: { description: 'یافت نشد', schema: { $ref: '#/components/schemas/Error' } },
          },
        },
        put: {
          tags: ['Products'],
          summary: 'به‌روزرسانی محصول',
          parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
          requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/Product' } } } },
          responses: {
            200: { description: 'به‌روزرسانی شد', schema: { $ref: '#/components/schemas/Success' } },
            404: { description: 'یافت نشد', schema: { $ref: '#/components/schemas/Error' } },
          },
        },
        delete: {
          tags: ['Products'],
          summary: 'حذف محصول (soft delete)',
          parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
          responses: {
            200: { description: 'حذف شد', schema: { $ref: '#/components/schemas/Success' } },
          },
        },
      },
      '/products/{id}/publish': {
        post: {
          tags: ['Products'],
          summary: 'انتشار محصول',
          parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
          responses: { 200: { description: 'منتشر شد', schema: { $ref: '#/components/schemas/Success' } } },
        },
      },
      '/products/{id}/stock': {
        patch: {
          tags: ['Products'],
          summary: 'به‌روزرسانی موجودی',
          parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
          requestBody: { required: true, content: { 'application/json': { schema: { type: 'object', properties: { stockQuantity: { type: 'integer' } } } } } },
          responses: { 200: { description: 'به‌روزرسانی شد', schema: { $ref: '#/components/schemas/Success' } } },
        },
      },

      // ===== ORDERS =====
      '/orders': {
        get: {
          tags: ['Orders'],
          summary: 'دریافت لیست سفارشات',
          parameters: [
            { name: 'page', in: 'query', schema: { type: 'integer', default: 1 } },
            { name: 'pageSize', in: 'query', schema: { type: 'integer', default: 20 } },
          ],
          responses: { 200: { description: 'لیست سفارشات', schema: { $ref: '#/components/schemas/PaginatedResponse' } } },
        },
        post: {
          tags: ['Orders'],
          summary: 'ایجاد سفارش جدید',
          requestBody: { required: true, content: { 'application/json': { schema: { type: 'object' } } } },
          responses: { 201: { description: 'سفارش ایجاد شد', schema: { $ref: '#/components/schemas/Success' } } },
        },
      },
      '/orders/{id}/confirm': {
        post: {
          tags: ['Orders'],
          summary: 'تأیید سفارش',
          parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
          responses: { 200: { description: 'تأیید شد', schema: { $ref: '#/components/schemas/Success' } } },
        },
      },
      '/orders/{id}/ship': {
        post: {
          tags: ['Orders'],
          summary: 'ارسال سفارش',
          parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
          requestBody: { required: true, content: { 'application/json': { schema: { type: 'object', properties: { trackingCode: { type: 'string' } } } } } },
          responses: { 200: { description: 'ارسال شد', schema: { $ref: '#/components/schemas/Success' } } },
        },
      },
      '/orders/{id}/cancel': {
        post: {
          tags: ['Orders'],
          summary: 'لغو سفارش',
          parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
          requestBody: { required: true, content: { 'application/json': { schema: { type: 'object', properties: { reason: { type: 'string' } } } } } },
          responses: { 200: { description: 'لغو شد', schema: { $ref: '#/components/schemas/Success' } } },
        },
      },

      // ===== PRICING =====
      '/pricing/calculate': {
        post: {
          tags: ['Pricing'],
          summary: 'محاسبه قیمت',
          requestBody: { required: true, content: { 'application/json': { schema: { type: 'object' } } } },
          responses: { 200: { description: 'قیمت محاسبه شده', schema: { $ref: '#/components/schemas/PricingResult' } } },
        },
      },
      '/pricing/cost/{productId}': {
        get: {
          tags: ['Pricing'],
          summary: 'محاسبه قیمت تمام شده',
          parameters: [{ name: 'productId', in: 'path', required: true, schema: { type: 'integer' } }],
          responses: { 200: { description: 'تجزیه هزینه', schema: { type: 'object' } } },
        },
      },

      // ===== ACCOUNTING =====
      '/accounting/journal-entry': {
        post: {
          tags: ['Accounting'],
          summary: 'ایجاد سند حسابداری',
          requestBody: { required: true, content: { 'application/json': { schema: { type: 'object' } } } },
          responses: { 201: { description: 'سند ایجاد شد', schema: { $ref: '#/components/schemas/Success' } } },
        },
      },
      '/accounting/trial-balance': {
        get: {
          tags: ['Accounting'],
          summary: 'گزارش ترازنامه',
          parameters: [
            { name: 'from', in: 'query', required: true, schema: { type: 'string', format: 'date' } },
            { name: 'to', in: 'query', required: true, schema: { type: 'string', format: 'date' } },
          ],
          responses: { 200: { description: 'ترازنامه', schema: { type: 'array' } } },
        },
      },
      '/accounting/profit-loss': {
        get: {
          tags: ['Accounting'],
          summary: 'گزارش سود و زیان',
          parameters: [
            { name: 'from', in: 'query', required: true, schema: { type: 'string', format: 'date' } },
            { name: 'to', in: 'query', required: true, schema: { type: 'string', format: 'date' } },
          ],
          responses: { 200: { description: 'سود و زیان', schema: { type: 'object' } } },
        },
      },
      '/accounting/balance-sheet': {
        get: {
          tags: ['Accounting'],
          summary: 'ترازنامه مالی',
          parameters: [{ name: 'asOf', in: 'query', required: true, schema: { type: 'string', format: 'date' } }],
          responses: { 200: { description: 'ترازنامه', schema: { type: 'object' } } },
        },
      },

      // ===== WORKFLOW =====
      '/workflow/start': {
        post: {
          tags: ['Workflow'],
          summary: 'شروع گردش کار',
          requestBody: { required: true, content: { 'application/json': { schema: { type: 'object', properties: { entityType: { type: 'string' }, entityId: { type: 'integer' } } } } } },
          responses: { 200: { description: 'شروع شد', schema: { $ref: '#/components/schemas/Success' } } },
        },
      },
      '/workflow/advance': {
        post: {
          tags: ['Workflow'],
          summary: 'پیشروی به مرحله بعد',
          requestBody: { required: true, content: { 'application/json': { schema: { type: 'object' } } } },
          responses: { 200: { description: 'پیشروی شد', schema: { $ref: '#/components/schemas/Success' } } },
        },
      },
      '/workflow/status/{entityType}/{entityId}': {
        get: {
          tags: ['Workflow'],
          summary: 'دریافت وضعیت گردش کار',
          parameters: [
            { name: 'entityType', in: 'path', required: true, schema: { type: 'string' } },
            { name: 'entityId', in: 'path', required: true, schema: { type: 'integer' } },
          ],
          responses: { 200: { description: 'وضعیت', schema: { type: 'object' } } },
        },
      },

      // ===== ANALYTICS =====
      '/analytics/dashboard': {
        get: {
          tags: ['Analytics'],
          summary: 'دریافت داشبورد',
          responses: { 200: { description: 'داشبورد', schema: { $ref: '#/components/schemas/DashboardData' } } },
        },
      },
      '/analytics/sales-report': {
        get: {
          tags: ['Analytics'],
          summary: 'گزارش فروش',
          parameters: [
            { name: 'from', in: 'query', required: true, schema: { type: 'string', format: 'date' } },
            { name: 'to', in: 'query', required: true, schema: { type: 'string', format: 'date' } },
          ],
          responses: { 200: { description: 'گزارش', schema: { type: 'object' } } },
        },
      },
      '/analytics/production-report': {
        get: {
          tags: ['Analytics'],
          summary: 'گزارش تولید',
          parameters: [
            { name: 'from', in: 'query', required: true, schema: { type: 'string', format: 'date' } },
            { name: 'to', in: 'query', required: true, schema: { type: 'string', format: 'date' } },
          ],
          responses: { 200: { description: 'گزارش', schema: { type: 'object' } } },
        },
      },

      // ===== DOCUMENTS =====
      '/documents/upload': {
        post: {
          tags: ['Documents'],
          summary: 'آپلود سند',
          requestBody: {
            required: true,
            content: {
              'multipart/form-data': {
                schema: {
                  type: 'object',
                  properties: {
                    file: { type: 'string', format: 'binary' },
                    type: { type: 'string' },
                    category: { type: 'string' },
                    name: { type: 'string' },
                  },
                },
              },
            },
          },
          responses: { 201: { description: 'آپلود شد', schema: { $ref: '#/components/schemas/Success' } } },
        },
      },
      '/documents/{id}/sign': {
        post: {
          tags: ['Documents'],
          summary: 'امضای دیجیتال سند',
          parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
          requestBody: { required: true, content: { 'application/json': { schema: { type: 'object' } } } },
          responses: { 200: { description: 'امضا شد', schema: { $ref: '#/components/schemas/Success' } } },
        },
      },

      // ===== WORK ORDERS =====
      '/work-orders': {
        get: {
          tags: ['Production'],
          summary: 'دریافت لیست دستورات کار',
          parameters: [
            { name: 'page', in: 'query', schema: { type: 'integer', default: 1 } },
            { name: 'pageSize', in: 'query', schema: { type: 'integer', default: 20 } },
            { name: 'status', in: 'query', schema: { type: 'string' } },
          ],
          responses: { 200: { description: 'لیست', schema: { $ref: '#/components/schemas/PaginatedResponse' } } },
        },
        post: {
          tags: ['Production'],
          summary: 'ایجاد دستور کار',
          requestBody: { required: true, content: { 'application/json': { schema: { $ref: '#/components/schemas/WorkOrder' } } } },
          responses: { 201: { description: 'ایجاد شد', schema: { $ref: '#/components/schemas/Success' } } },
        },
      },
      '/work-orders/{id}/start': {
        post: {
          tags: ['Production'],
          summary: 'شروع تولید',
          parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
          responses: { 200: { description: 'شروع شد', schema: { $ref: '#/components/schemas/Success' } } },
        },
      },
      '/work-orders/{id}/complete': {
        post: {
          tags: ['Production'],
          summary: 'تکمیل تولید',
          parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
          responses: { 200: { description: 'تکمیل شد', schema: { $ref: '#/components/schemas/Success' } } },
        },
      },

      // ===== INVENTORY =====
      '/inventory/low-stock': {
        get: {
          tags: ['Inventory'],
          summary: 'دریافت اقلام کم‌موجودی',
          responses: { 200: { description: 'لیست', schema: { $ref: '#/components/schemas/Success' } } },
        },
      },
      '/inventory/stock-in': {
        post: {
          tags: ['Inventory'],
          summary: 'ورود به انبار',
          requestBody: { required: true, content: { 'application/json': { schema: { type: 'object' } } } },
          responses: { 200: { description: 'ثبت شد', schema: { $ref: '#/components/schemas/Success' } } },
        },
      },

      // ===== AUDIT LOGS =====
      '/audit-logs': {
        get: {
          tags: ['Audit Logs'],
          summary: 'دریافت لاگ تغییرات',
          parameters: [
            { name: 'page', in: 'query', schema: { type: 'integer', default: 1 } },
            { name: 'userId', in: 'query', schema: { type: 'integer' } },
            { name: 'entityType', in: 'query', schema: { type: 'string' } },
          ],
          responses: { 200: { description: 'لاگ‌ها', schema: { $ref: '#/components/schemas/PaginatedResponse' } } },
        },
      },
    },
  };
}
