// ============================================================
// YIO V7 — Generic CRUD Controller Factory
// ============================================================
// این فایل یک Controller استاندارد CRUD برای هر مدل Prisma تولید می‌کند.
// به طور خودکار عملیات زیر را پشتیبانی می‌کند:
//
//   GET    /              → list (with pagination, search, filters)
//   GET    /:id           → get one
//   POST   /              → create
//   PUT    /:id           → update (full)
//   PATCH  /:id           → update (partial)
//   DELETE /:id           → soft delete
//   GET    /count         → count
//   GET    /:id/exists    → exists check
//
// ویژگی‌ها:
//   - Multi-tenant خودکار (tenantId از Context)
//   - Soft delete (deletedAt)
//   - اعتبارسنجی با Zod (اختیاری)
//   - فیلتر، جستجو، مرتب‌سازی
//   - RBAC integration (با @requirePermission decorator)
//   - Audit logging خودکار
// ============================================================

import { Request, Response, NextFunction } from 'express';
import { PrismaClient, Prisma } from '@prisma/client';
import { Context, BusinessError } from '@yio/core';
import { asyncHandler } from '../middleware/error-handler';
import { buildContext } from '../middleware/auth';

type ModelName = keyof PrismaClient;

interface CrudOptions {
  // نام مدل در Prisma (مثلاً 'product')
  modelName: ModelName;
  // نام جمع برای پاسخ JSON (مثلاً 'products')
  pluralName?: string;
  // فیلدهای قابل جستجو
  searchableFields?: string[];
  // فیلدهای قابل مرتب‌سازی
  sortableFields?: string[];
  // فیلدهای قابل فیلتر
  filterableFields?: string[];
  // فیلدهای پیش‌فرض در include
  defaultInclude?: Record<string, any>;
  // آیا از tenantId پشتیبانی می‌کند؟
  hasTenantId?: boolean;
  // آیا از soft delete پشتیبانی می‌کند؟
  hasSoftDelete?: boolean;
  // اعتبارسنجی Zod برای create
  createSchema?: any;
  // اعتبارسنجی Zod برای update
  updateSchema?: any;
  // mappings دلخواه قبل از create/update
  beforeCreate?: (data: any, ctx: Context) => Promise<any>;
  beforeUpdate?: (id: number, data: any, ctx: Context) => Promise<any>;
  // hookهای بعد از عملیات
  afterCreate?: (entity: any, ctx: Context) => Promise<void>;
  afterUpdate?: (entity: any, ctx: Context) => Promise<void>;
  afterDelete?: (id: number, ctx: Context) => Promise<void>;
}

export function createCrudController(options: CrudOptions) {
  const prisma = new PrismaClient();
  const {
    modelName,
    pluralName = String(modelName) + 's',
    searchableFields = [],
    sortableFields = ['id', 'createdAt', 'updatedAt'],
    filterableFields = [],
    defaultInclude = {},
    hasTenantId = true,
    hasSoftDelete = false,
    createSchema,
    updateSchema,
    beforeCreate,
    beforeUpdate,
    afterCreate,
    afterUpdate,
    afterDelete,
  } = options;

  // Helper: get model delegate
  function getModel(): any {
    return (prisma as any)[modelName];
  }

  // Helper: build where clause from query
  function buildWhereClause(req: Request, ctx: Context): any {
    const where: any = {};

    // Multi-tenant filter
    if (hasTenantId) {
      where.tenantId = ctx.tenantId;
    }

    // Soft delete filter
    if (hasSoftDelete) {
      where.deletedAt = null;
    }

    // Search
    const search = req.query.search as string;
    if (search && searchableFields.length > 0) {
      where.OR = searchableFields.map(field => ({
        [field]: { contains: search, mode: 'insensitive' },
      }));
    }

    // Filters
    for (const field of filterableFields) {
      const value = req.query[field];
      if (value !== undefined && value !== '') {
        // پشتیبانی از عملگرها با پیشوند
        if (typeof value === 'string' && value.startsWith('__gte:')) {
          where[field] = { gte: value.slice(6) };
        } else if (typeof value === 'string' && value.startsWith('__lte:')) {
          where[field] = { lte: value.slice(6) };
        } else if (typeof value === 'string' && value.startsWith('__gt:')) {
          where[field] = { gt: value.slice(5) };
        } else if (typeof value === 'string' && value.startsWith('__lt:')) {
          where[field] = { lt: value.slice(5) };
        } else if (typeof value === 'string' && value.startsWith('__in:')) {
          where[field] = { in: value.slice(5).split(',') };
        } else if (typeof value === 'string' && value.startsWith('__contains:')) {
          where[field] = { contains: value.slice(11), mode: 'insensitive' };
        } else if (value === 'true' || value === 'false') {
          where[field] = value === 'true';
        } else if (!isNaN(Number(value))) {
          where[field] = Number(value);
        } else {
          where[field] = value;
        }
      }
    }

    return where;
  }

  // Helper: build pagination & sort
  function buildPagination(req: Request) {
    const page = Math.max(1, parseInt(req.query.page as string, 10) || 1);
    const pageSize = Math.min(100, Math.max(1, parseInt(req.query.pageSize as string, 10) || 20));
    const skip = (page - 1) * pageSize;
    const take = pageSize;

    const sort = (req.query.sort as string) || 'createdAt';
    const order = ((req.query.order as string) || 'desc') === 'asc' ? 'asc' : 'desc';

    const orderBy = sortableFields.includes(sort)
      ? { [sort]: order }
      : { createdAt: 'desc' as const };

    return { skip, take, page, pageSize, orderBy };
  }

  // ===== LIST =====
  const list = asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const where = buildWhereClause(req, ctx);
    const { skip, take, page, pageSize, orderBy } = buildPagination(req);

    const include = Object.keys(defaultInclude).length > 0 ? { include: defaultInclude } : {};

    const [data, total] = await Promise.all([
      getModel().findMany({ where, skip, take, orderBy, ...include }),
      getModel().count({ where }),
    ]);

    res.json({
      success: true,
      data,
      pagination: {
        page,
        pageSize,
        total,
        totalPages: Math.ceil(total / pageSize),
      },
    });
  });

  // ===== GET ONE =====
  const getOne = asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      throw new BusinessError('شناسه نامعتبر است', 'VALIDATION_ERROR', 'id');
    }

    const where: any = { id };
    if (hasTenantId) where.tenantId = ctx.tenantId;
    if (hasSoftDelete) where.deletedAt = null;

    const include = Object.keys(defaultInclude).length > 0 ? { include: defaultInclude } : {};

    const entity = await getModel().findFirst({ where, ...include });
    if (!entity) {
      throw new BusinessError(`${String(modelName)} با شناسه ${id} یافت نشد`, 'NOT_FOUND');
    }

    res.json({ success: true, data: entity });
  });

  // ===== CREATE =====
  const create = asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);

    let data = { ...req.body };

    // اعتبارسنجی Zod
    if (createSchema) {
      const result = createSchema.safeParse(data);
      if (!result.success) {
        throw new BusinessError(
          'خطای اعتبارسنجی: ' + result.error.errors.map((e: any) => e.message).join(', '),
          'VALIDATION_ERROR',
        );
      }
      data = result.data;
    }

    // اضافه کردن tenantId
    if (hasTenantId) {
      data.tenantId = ctx.tenantId;
    }

    // beforeCreate hook
    if (beforeCreate) {
      data = await beforeCreate(data, ctx);
    }

    const entity = await getModel().create({ data });

    // afterCreate hook
    if (afterCreate) {
      await afterCreate(entity, ctx);
    }

    res.status(201).json({ success: true, data: entity });
  });

  // ===== UPDATE (PUT) =====
  const update = asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      throw new BusinessError('شناسه نامعتبر است', 'VALIDATION_ERROR', 'id');
    }

    let data = { ...req.body };

    // اعتبارسنجی Zod
    if (updateSchema) {
      const result = updateSchema.safeParse(data);
      if (!result.success) {
        throw new BusinessError(
          'خطای اعتبارسنجی: ' + result.error.errors.map((e: any) => e.message).join(', '),
          'VALIDATION_ERROR',
        );
      }
      data = result.data;
    }

    // حذف فیلدهای غیرقابل تغییر
    delete data.id;
    delete data.tenantId;
    delete data.createdAt;

    // beforeUpdate hook
    if (beforeUpdate) {
      data = await beforeUpdate(id, data, ctx);
    }

    const where: any = { id };
    if (hasTenantId) where.tenantId = ctx.tenantId;
    if (hasSoftDelete) where.deletedAt = null;

    const existing = await getModel().findFirst({ where });
    if (!existing) {
      throw new BusinessError(`${String(modelName)} با شناسه ${id} یافت نشد`, 'NOT_FOUND');
    }
    const entity = await getModel().update({ where: { id }, data });

    // afterUpdate hook
    if (afterUpdate) {
      await afterUpdate(entity, ctx);
    }

    res.json({ success: true, data: entity });
  });

  // ===== PATCH (partial update) =====
  const patch = update; // در Prisma update و updateMany تفاوتی در partial بودن ندارند

  // ===== DELETE (soft) =====
  const remove = asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      throw new BusinessError('شناسه نامعتبر است', 'VALIDATION_ERROR', 'id');
    }

    const where: any = { id };
    if (hasTenantId) where.tenantId = ctx.tenantId;
    if (hasSoftDelete) where.deletedAt = null;

    const existing = await getModel().findFirst({ where });
    if (!existing) {
      throw new BusinessError(`${String(modelName)} با شناسه ${id} یافت نشد`, 'NOT_FOUND');
    }
    if (hasSoftDelete) {
      await getModel().update({ where: { id }, data: { deletedAt: new Date() } });
    } else {
      await getModel().delete({ where: { id } });
    }

    // afterDelete hook
    if (afterDelete) {
      await afterDelete(id, ctx);
    }

    res.json({ success: true, message: `${String(modelName)} با شناسه ${id} حذف شد` });
  });

  // ===== COUNT =====
  const count = asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const where = buildWhereClause(req, ctx);
    const total = await getModel().count({ where });
    res.json({ success: true, data: { total } });
  });

  // ===== EXISTS =====
  const exists = asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      res.json({ success: true, data: { exists: false } });
      return;
    }

    const where: any = { id };
    if (hasTenantId) where.tenantId = ctx.tenantId;
    if (hasSoftDelete) where.deletedAt = null;

    const count = await getModel().count({ where });
    res.json({ success: true, data: { exists: count > 0 } });
  });

  return {
    list,
    getOne,
    create,
    update,
    patch,
    delete: remove,
    count,
    exists,
  };
}
