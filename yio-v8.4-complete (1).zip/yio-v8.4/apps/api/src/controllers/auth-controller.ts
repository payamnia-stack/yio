// ============================================================
// YIO V7 — Auth Controller
// ============================================================
// احراز هویت کاربران:
//   - login (phone + password)
//   - register (phone + verification code)
//   - refresh token
//   - logout
//   - me (دریافت اطلاعات کاربر فعلی)
//   - verify-phone
//   - resend-code
// ============================================================

import { Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';
import {
  generateAccessToken,
  generateRefreshToken,
  verifyRefreshToken,
  refreshAccessToken,
  loginUser,
} from '../middleware/auth';
import { BusinessError } from '@yio/core';
import { asyncHandler } from '../middleware/error-handler';

const prisma = new PrismaClient();

// ===== LOGIN =====
export const login = asyncHandler(async (req: Request, res: Response) => {
  const { phone, password } = req.body;

  if (!phone || !password) {
    throw new BusinessError('شماره موبایل و رمز عبور الزامی است', 'VALIDATION_ERROR');
  }

  // نرمال‌سازی شماره موبایل
  const normalizedPhone = phone.startsWith('0') ? phone : `0${phone}`;

  const result = await loginUser(normalizedPhone, password);
  if (!result) {
    throw new BusinessError('شماره موبایل یا رمز عبور اشتباه است', 'INVALID_CREDENTIALS', undefined, 401);
  }

  res.json({
    success: true,
    data: {
      accessToken: result.accessToken,
      refreshToken: result.refreshToken,
      user: result.user,
    },
  });
});

// ===== REGISTER =====
export const register = asyncHandler(async (req: Request, res: Response) => {
  const { phone, name, email, password, verificationCode } = req.body;

  if (!phone || !password) {
    throw new BusinessError('شماره موبایل و رمز عبور الزامی است', 'VALIDATION_ERROR');
  }

  const normalizedPhone = phone.startsWith('0') ? phone : `0${phone}`;

  // بررسی تکراری نبودن
  const existing = await prisma.user.findFirst({
    where: { phone: normalizedPhone },
  });

  if (existing) {
    throw new BusinessError('این شماره موبایل قبلاً ثبت شده است', 'DUPLICATE_ENTRY', 'phone', 409);
  }

  // در عمل باید verification code چک شود
  // فعلاً verificationCode را نادیده می‌گیریم

  // هش کردن رمز عبور
  const hashedPassword = await bcrypt.hash(password, 10);

  // ایجاد کاربر
  const user = await prisma.user.create({
    data: {
      tenantId: 1, // Tenant پیش‌فرض
      phone: normalizedPhone,
      name,
      email,
      password: hashedPassword,
      level: 0, // مشتری عادی
      isVerified: true, // در عمل باید بعد از تأیید کد true شود
      referralCode: `YIO-${Date.now().toString(36).toUpperCase()}`,
    },
  });

  // ایجاد کیف پول
  await prisma.wallet.create({
    data: { userId: user.id, balance: 0 },
  });

  // تولید توکن‌ها
  const payload = {
    userId: user.id,
    tenantId: user.tenantId,
    phone: user.phone,
    level: user.level,
    isWholesale: user.isWholesale,
  };

  res.status(201).json({
    success: true,
    data: {
      accessToken: generateAccessToken(payload),
      refreshToken: generateRefreshToken(payload),
      user: {
        id: user.id,
        phone: user.phone,
        name: user.name,
        level: user.level,
        isWholesale: user.isWholesale,
      },
    },
  });
});

// ===== REFRESH TOKEN =====
export const refresh = asyncHandler(async (req: Request, res: Response) => {
  const { refreshToken } = req.body;

  if (!refreshToken) {
    throw new BusinessError('refreshToken الزامی است', 'VALIDATION_ERROR');
  }

  const newAccessToken = refreshAccessToken(refreshToken);
  if (!newAccessToken) {
    throw new BusinessError('refreshToken نامعتبر یا منقضی شده است', 'INVALID_TOKEN', undefined, 401);
  }

  res.json({
    success: true,
    data: {
      accessToken: newAccessToken,
    },
  });
});

// ===== LOGOUT =====
export const logout = asyncHandler(async (req: Request, res: Response) => {
  // در حالت JWT stateless، فقط کلاینت باید توکن را پاک کند
  // در عمل می‌توان توکن را در blacklist قرار داد
  res.json({
    success: true,
    message: 'با موفقیت خارج شدید',
  });
});

// ===== ME (دریافت کاربر فعلی) =====
export const me = asyncHandler(async (req: Request, res: Response) => {
  const user = (req as any).user;
  if (!user) {
    throw new BusinessError('احراز هویت لازم است', 'UNAUTHORIZED', undefined, 401);
  }

  const dbUser = await prisma.user.findUnique({
    where: { id: user.userId },
    select: {
      id: true,
      phone: true,
      name: true,
      email: true,
      level: true,
      isVerified: true,
      isWholesale: true,
      wholesaleDiscount: true,
      avatar: true,
      city: true,
      province: true,
      referralCode: true,
      createdAt: true,
    },
  });

  if (!dbUser) {
    throw new BusinessError('کاربر یافت نشد', 'NOT_FOUND', undefined, 404);
  }

  res.json({ success: true, data: dbUser });
});

// ===== VERIFY PHONE =====
export const verifyPhone = asyncHandler(async (req: Request, res: Response) => {
  const { phone, code } = req.body;

  if (!phone || !code) {
    throw new BusinessError('شماره موبایل و کد الزامی است', 'VALIDATION_ERROR');
  }

  // در عمل باید کد از Redis یا DB چک شود
  // فعلاً کد 12345 را قبول می‌کنیم (فقط برای development)
  if (code !== '12345' && process.env.NODE_ENV !== 'production') {
    throw new BusinessError('کد تأیید اشتباه است', 'INVALID_CODE');
  }

  const user = await prisma.user.findFirst({
    where: { phone, verifyCode: code },
  });

  if (!user) {
    throw new BusinessError('کد تأیید اشتباه است یا منقضی شده', 'INVALID_CODE');
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { isVerified: true, verifyCode: null, verifyExpiry: null },
  });

  res.json({
    success: true,
    message: 'شماره موبایل با موفقیت تأیید شد',
  });
});

// ===== RESEND CODE =====
export const resendCode = asyncHandler(async (req: Request, res: Response) => {
  const { phone } = req.body;

  if (!phone) {
    throw new BusinessError('شماره موبایل الزامی است', 'VALIDATION_ERROR');
  }

  const user = await prisma.user.findFirst({ where: { phone } });
  if (!user) {
    throw new BusinessError('کاربر یافت نشد', 'NOT_FOUND', undefined, 404);
  }

  // تولید کد ۵ رقمی
  const code = Math.floor(10000 + Math.random() * 90000).toString();
  const expiry = new Date(Date.now() + 5 * 60 * 1000); // 5 دقیقه

  await prisma.user.update({
    where: { id: user.id },
    data: { verifyCode: code, verifyExpiry: expiry },
  });

  // در عمل باید SMS ارسال شود
  console.log(`[Auth] Verification code for ${phone}: ${code}`);

  res.json({
    success: true,
    message: 'کد تأیید جدید ارسال شد',
  });
});

export default {
  login,
  register,
  refresh,
  logout,
  me,
  verifyPhone,
  resendCode,
};
