// ============================================================
// YIO V8.2 — API Routes (All 10 Engines)
// ============================================================
// این فایل تمام مسیرهای API را برای هر ۱۰ موتور تجاری تعریف می‌کند.
//
// V8.2 Fix:
//   - ServiceContainer و ENGINE_NAMES حذف شده‌اند (در V8.1 به DI Container تغییر کرد)
//   - OrderEngine نیاز به ۷-۸ وابستگی دارد که در bootstrap.ts تزریق می‌شوند
//   - در اینجا stub می‌گذاریم؛ در runtime، نمونه‌های واقعی از bootstrap تزریق می‌شوند
//
// ساختار URL:
//   /api/v1/<entity>              → CRUD operations
//   /api/v1/<engine>/<action>     → Engine-specific actions
// ============================================================

import { Router, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { asyncHandler } from '../middleware/error-handler';
import { buildContext } from '../middleware/auth';
import { requireAuth, requireRole, requireAdmin, optionalAuth } from '../middleware/auth';
import { createCrudController } from '../controllers/crud-factory';
import webhookRoutes from './webhooks';
import {
  SalesForecastingEngine,
  SmartChatEngine,
  ProductDescriptionGenerator,
  CustomerInsightsAnalyzer,
  AnomalyDetectionEngine,
} from '@yio/ai';
import {
  OrderEngine,
  ProductionEngine,
  InventoryEngine,
  PricingEngine,
  AccountingEngine,
  WorkflowEngine,
  NotificationEngine,
  PermissionChecker,
  RuleEngine,
  RuleRegistry,
  AnalyticsEngine,
  DocumentEngine,
  getEventBus,
} from '@yio/services';
import { BusinessError } from '@yio/core';
import { getService } from '../bootstrap';

const prisma = new PrismaClient();
const eventBus = getEventBus();

// ===== Initialize Engines =====
// NOTE: در V8.2، OrderEngine نیاز به ۷-۸ وابستگی دارد که در bootstrap.ts تزریق می‌شوند.
// در اینجا stub می‌گذاریم؛ در runtime، نمونه‌های واقعی از bootstrap تزریق می‌شوند.
const ruleRegistry = new RuleRegistry();
const engines = {
  order: null as any, // Injected from bootstrap container at runtime
  production: new ProductionEngine(prisma, eventBus),
  inventory: new InventoryEngine(prisma, eventBus),
  pricing: new PricingEngine(prisma, eventBus),
  accounting: new AccountingEngine(prisma, eventBus),
  workflow: new WorkflowEngine(prisma, eventBus),
  notification: new NotificationEngine(prisma, eventBus),
  rule: new RuleEngine(prisma, ruleRegistry),
  analytics: new AnalyticsEngine(prisma, eventBus),
  document: new DocumentEngine(prisma, eventBus),
};

// ===== Initialize AI Engines =====
const aiEngines = {
  salesForecasting: new SalesForecastingEngine(prisma, eventBus),
  smartChat: new SmartChatEngine(prisma, eventBus),
  productDescription: new ProductDescriptionGenerator(prisma, eventBus),
  customerInsights: new CustomerInsightsAnalyzer(prisma, eventBus),
  anomalyDetection: new AnomalyDetectionEngine(prisma, eventBus),
};

const router = Router();

// ============================================================
// 1) AUTH ROUTES
// ============================================================
const authController = require('../controllers/auth-controller');
router.post('/auth/login', authController.login);
router.post('/auth/register', authController.register);
router.post('/auth/refresh', authController.refresh);
router.post('/auth/logout', requireAuth, authController.logout);
router.get('/auth/me', requireAuth, authController.me);
router.post('/auth/verify-phone', authController.verifyPhone);
router.post('/auth/resend-code', authController.resendCode);

// ============================================================
// 2) USER ROUTES
// ============================================================
const userCrud = createCrudController({
  modelName: 'user',
  pluralName: 'users',
  searchableFields: ['name', 'phone', 'email'],
  sortableFields: ['id', 'name', 'phone', 'level', 'createdAt'],
  filterableFields: ['level', 'isWholesale', 'isVerified', 'city'],
  hasTenantId: true,
  hasSoftDelete: true,
});

router.get('/users', requireAuth, requireRole('admin', 'super_admin'), userCrud.list);
router.get('/users/:id', requireAuth, userCrud.getOne);
router.post('/users', requireAuth, requireRole('admin', 'super_admin'), userCrud.create);
router.put('/users/:id', requireAuth, requireRole('admin', 'super_admin'), userCrud.update);
router.patch('/users/:id', requireAuth, userCrud.patch);
router.delete('/users/:id', requireAuth, requireRole('admin', 'super_admin'), userCrud.delete);
router.get('/users/count', requireAuth, requireRole('admin', 'super_admin'), userCrud.count);

// ============================================================
// 3) PRODUCT ROUTES
// ============================================================
const productCrud = createCrudController({
  modelName: 'product',
  pluralName: 'products',
  searchableFields: ['title', 'brand', 'category', 'woodType'],
  sortableFields: ['id', 'title', 'price', 'createdAt', 'stockQuantity', 'rating'],
  filterableFields: ['category', 'brand', 'isPublished', 'isSpecial', 'inStock', 'woodType'],
  defaultInclude: {
    productImages: { orderBy: { sortOrder: 'asc' } },
    productVideos: { orderBy: { sortOrder: 'asc' } },
    productColors: { orderBy: { sortOrder: 'asc' } },
    productVariants: {
      where: { isActive: true },
      orderBy: [{ isDefault: 'desc' }, { id: 'asc' }],
      include: { color: true },
    },
  },
  beforeCreate: async (data: any) => {
    const legacyImages = Array.isArray(data.images) ? data.images : [];
    const images = Array.isArray(data.productImages) ? data.productImages : legacyImages.map((url: string, index: number) => ({ url, sortOrder: index, isPrimary: index === 0 }));
    const videos = Array.isArray(data.productVideos) ? data.productVideos : [];
    const colors = Array.isArray(data.productColors) ? data.productColors : [];
    const variants = Array.isArray(data.productVariants) ? data.productVariants : [{
      title: data.title,
      sku: data.sku || undefined,
      price: data.price,
      salePrice: data.salePrice ?? data.discountPrice ?? undefined,
      stockQuantity: Number(data.stockQuantity || 0),
      isDefault: true,
      isActive: true,
    }];
    delete data.productImages;
    delete data.productVideos;
    delete data.productColors;
    delete data.productVariants;
    delete data.images;
    delete data.videos;
    delete data.colors;
    data.productImages = { create: images };
    data.productVideos = { create: videos };
    data.productColors = { create: colors };
    data.productVariants = { create: variants };
    return data;
  },
  beforeUpdate: async (_id: number, data: any) => {
    for (const relation of ['productImages', 'productVideos', 'productColors', 'productVariants']) {
      if (Array.isArray(data[relation])) {
        data[relation] = { deleteMany: {}, create: data[relation] };
      }
    }
    delete data.tenantId;
    delete data.id;
    return data;
  },
  hasTenantId: true,
  hasSoftDelete: true,
});

router.get('/products', optionalAuth, productCrud.list);
router.get('/products/:id', optionalAuth, productCrud.getOne);
router.post('/products', requireAuth, requireRole('admin', 'super_admin', 'staff'), productCrud.create);
router.put('/products/:id', requireAuth, requireRole('admin', 'super_admin', 'staff'), productCrud.update);
router.patch('/products/:id', requireAuth, requireRole('admin', 'super_admin', 'staff'), productCrud.patch);
router.delete('/products/:id', requireAuth, requireRole('admin', 'super_admin'), productCrud.delete);

// Product actions
router.post('/products/:id/publish', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const productId = parseInt(req.params.id, 10);
    const existing = await prisma.product.findFirst({ where: { id: productId, tenantId: ctx.tenantId, deletedAt: null } });
    if (!existing) throw new BusinessError('محصول یافت نشد', 'NOT_FOUND');
    const product = await prisma.product.update({
      where: { id: productId },
      data: { isPublished: true, publishedAt: new Date() },
    });
    await eventBus.publish({ eventName: 'product.published', productId, tenantId: ctx.tenantId, timestamp: new Date() } as any);
    res.json({ success: true, data: product, message: 'محصول منتشر شد' });
  })
);

router.post('/products/:id/unpublish', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const productId = parseInt(req.params.id, 10);
    const existing = await prisma.product.findFirst({ where: { id: productId, tenantId: ctx.tenantId, deletedAt: null } });
    if (!existing) throw new BusinessError('محصول یافت نشد', 'NOT_FOUND');
    const product = await prisma.product.update({
      where: { id: productId },
      data: { isPublished: false },
    });
    res.json({ success: true, data: product, message: 'محصول از انتشار خارج شد' });
  })
);

router.patch('/products/:id/stock', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const productId = parseInt(req.params.id, 10);
    const stockQuantity = Number(req.body?.stockQuantity);
    if (!Number.isInteger(stockQuantity) || stockQuantity < 0) {
      throw new BusinessError('موجودی نامعتبر است', 'VALIDATION_ERROR', 'stockQuantity');
    }
    const existing = await prisma.product.findFirst({ where: { id: productId, tenantId: ctx.tenantId, deletedAt: null }, include: { productVariants: { where: { isActive: true }, orderBy: [{ isDefault: 'desc' }, { id: 'asc' }], take: 1 } } });
    if (!existing) throw new BusinessError('محصول یافت نشد', 'NOT_FOUND');
    const variant = existing.productVariants[0];
    if (variant) {
      await prisma.productVariant.update({ where: { id: variant.id }, data: { stockQuantity } });
    }
    const product = await prisma.product.update({
      where: { id: productId },
      data: { stockQuantity, inStock: stockQuantity > 0 },
      include: { productVariants: true, productImages: true, productVideos: true, productColors: true },
    });
    res.json({ success: true, data: product });
  })
);

// ============================================================
// 4) ORDER ROUTES (Order Engine)
// ============================================================
router.post('/orders', requireAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  const body = req.body || {};
  if (!Array.isArray(body.items) || body.items.length === 0) {
    throw new BusinessError('اقلام سفارش الزامی است', 'VALIDATION_ERROR', 'items');
  }
  const orderUseCase = await getService<any>('OrderUseCase');
  const result = await orderUseCase.createOrder({
    customerId: typeof body.customerId === 'number' ? body.customerId : undefined,
    userId: ctx.userId,
    items: body.items.map((item: any) => ({
      productId: Number(item.productId),
      quantity: Math.max(1, Math.min(99, Number(item.quantity))),
      color: item.color ? String(item.color) : undefined,
    })),
    shippingAddress: String(body.shippingAddress || ''),
    shippingCity: body.shippingCity ? String(body.shippingCity) : undefined,
    postalCode: body.postalCode ? String(body.postalCode) : undefined,
    recipientName: String(body.recipientName || ''),
    recipientPhone: String(body.recipientPhone || ''),
    paymentMethod: String(body.paymentMethod || 'cod'),
    notes: body.notes ? String(body.notes) : undefined,
  }, ctx);
  res.status(201).json({ success: true, data: result });
}));

router.get('/orders', requireAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  const page = parseInt(req.query.page as string, 10) || 1;
  const pageSize = Math.min(100, parseInt(req.query.pageSize as string, 10) || 20);

  const where: any = { tenantId: ctx.tenantId };
  // کاربر عادی فقط سفارش‌های خودش را می‌بیند
  if (ctx.userRole === 'customer') {
    where.userId = ctx.userId;
  }

  const [orders, total] = await Promise.all([
    prisma.order.findMany({
      where,
      include: { items: true },
      skip: (page - 1) * pageSize,
      take: pageSize,
      orderBy: { createdAt: 'desc' },
    }),
    prisma.order.count({ where }),
  ]);

  res.json({
    success: true,
    data: orders,
    pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
  });
}));

router.get('/orders/:id', requireAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  const id = parseInt(req.params.id, 10);
  const where: any = { id, tenantId: ctx.tenantId };
  if (ctx.userRole === 'customer') where.userId = ctx.userId;

  const order = await prisma.order.findFirst({ where, include: { items: true } });
  if (!order) throw new BusinessError('سفارش یافت نشد', 'NOT_FOUND');
  res.json({ success: true, data: order });
}));

router.post('/orders/:id/confirm', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const id = parseInt(req.params.id, 10);
    const order = await prisma.order.update({
      where: { id, tenantId: ctx.tenantId },
      data: { status: 'confirmed' },
    });
    res.json({ success: true, data: order, message: 'سفارش تأیید شد' });
  })
);

router.post('/orders/:id/ship', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const id = parseInt(req.params.id, 10);
    const { trackingCode } = req.body;
    const order = await prisma.order.update({
      where: { id, tenantId: ctx.tenantId },
      data: { status: 'shipping', trackingCode },
    });
    res.json({ success: true, data: order, message: 'سفارش ارسال شد' });
  })
);

router.post('/orders/:id/deliver', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const id = parseInt(req.params.id, 10);
    const order = await prisma.order.update({
      where: { id, tenantId: ctx.tenantId },
      data: { status: 'delivered' },
    });
    res.json({ success: true, data: order, message: 'سفارش تحویل داده شد' });
  })
);

router.post('/orders/:id/cancel', requireAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  const id = parseInt(req.params.id, 10);
  const { reason } = req.body;
  const order = await prisma.order.update({
    where: { id, tenantId: ctx.tenantId },
    data: { status: 'cancelled', notes: reason },
  });
  res.json({ success: true, data: order, message: 'سفارش لغو شد' });
}));

// ============================================================
// 5) PRODUCTION ROUTES (Production Engine)
// ============================================================
const workOrderCrud = createCrudController({
  modelName: 'workOrder',
  pluralName: 'workOrders',
  searchableFields: ['woNumber', 'assignedTo', 'notes'],
  sortableFields: ['id', 'woNumber', 'priority', 'status', 'createdAt', 'expectedDate'],
  filterableFields: ['status', 'priority', 'productId', 'orderId', 'assignedTo'],
  defaultInclude: { steps: true, product: true },
  hasTenantId: true,
});

router.get('/work-orders', requireAuth, requireRole('admin', 'super_admin', 'staff'), workOrderCrud.list);
router.get('/work-orders/:id', requireAuth, requireRole('admin', 'super_admin', 'staff'), workOrderCrud.getOne);
router.post('/work-orders', requireAuth, requireRole('admin', 'super_admin', 'production_manager'), workOrderCrud.create);
router.put('/work-orders/:id', requireAuth, requireRole('admin', 'super_admin', 'production_manager'), workOrderCrud.update);
router.patch('/work-orders/:id', requireAuth, requireRole('admin', 'super_admin', 'production_manager', 'production_operator'), workOrderCrud.patch);

// Work order actions
router.post('/work-orders/:id/start', requireAuth, requireRole('admin', 'super_admin', 'production_manager'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const id = parseInt(req.params.id, 10);
    const wo = await prisma.workOrder.update({
      where: { id, tenantId: ctx.tenantId },
      data: { status: 'in_progress', startDate: new Date() },
    });
    res.json({ success: true, data: wo, message: 'تولید شروع شد' });
  })
);

router.post('/work-orders/:id/complete', requireAuth, requireRole('admin', 'super_admin', 'production_manager'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const id = parseInt(req.params.id, 10);
    const wo = await prisma.workOrder.update({
      where: { id, tenantId: ctx.tenantId },
      data: { status: 'completed', endDate: new Date() },
    });
    res.json({ success: true, data: wo, message: 'تولید تکمیل شد' });
  })
);

// ============================================================
// 6) INVENTORY ROUTES (Inventory Engine)
// ============================================================
const warehouseCrud = createCrudController({
  modelName: 'warehouse',
  searchableFields: ['name', 'location'],
  sortableFields: ['id', 'name', 'type'],
  filterableFields: ['type', 'isActive'],
  hasTenantId: true,
});

router.get('/warehouses', requireAuth, requireRole('admin', 'super_admin', 'staff'), warehouseCrud.list);
router.get('/warehouses/:id', requireAuth, warehouseCrud.getOne);
router.post('/warehouses', requireAuth, requireRole('admin', 'super_admin'), warehouseCrud.create);
router.put('/warehouses/:id', requireAuth, requireRole('admin', 'super_admin'), warehouseCrud.update);

const woodStockCrud = createCrudController({
  modelName: 'woodStock',
  searchableFields: ['woodType', 'grade'],
  sortableFields: ['id', 'woodType', 'thickness', 'quantity'],
  filterableFields: ['woodType', 'grade', 'status', 'warehouseId'],
  hasTenantId: true,
});

router.get('/wood-stocks', requireAuth, requireRole('admin', 'super_admin', 'staff'), woodStockCrud.list);
router.get('/wood-stocks/:id', requireAuth, woodStockCrud.getOne);
router.post('/wood-stocks', requireAuth, requireRole('admin', 'super_admin', 'warehouse_operator'), woodStockCrud.create);
router.put('/wood-stocks/:id', requireAuth, requireRole('admin', 'super_admin', 'warehouse_operator'), woodStockCrud.update);

// Inventory actions
router.post('/inventory/stock-in', requireAuth, requireRole('admin', 'super_admin', 'warehouse_operator'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const { itemType, itemId, quantity, reason, supplierId } = req.body;
    // در عمل باید InventoryEngine.stockIn() فراخوانی شود
    res.json({ success: true, message: `${quantity} واحد به موجودی اضافه شد` });
  })
);

router.post('/inventory/stock-out', requireAuth, requireRole('admin', 'super_admin', 'warehouse_operator'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const { itemType, itemId, quantity, reason } = req.body;
    res.json({ success: true, message: `${quantity} واحد از موجودی کسر شد` });
  })
);

router.get('/inventory/low-stock', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const products = await prisma.product.findMany({
      where: { tenantId: ctx.tenantId, stockQuantity: { lte: 10 }, inStock: true },
    });
    res.json({ success: true, data: products, count: products.length });
  })
);

// ============================================================
// 7) PRICING ROUTES (Pricing Engine)
// ============================================================
router.post('/pricing/calculate', optionalAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  const result = await engines.pricing.calculatePrice(req.body, ctx);
  res.json({ success: true, data: result });
}));

router.get('/pricing/cost/:productId', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const productId = parseInt(req.params.productId, 10);
    const breakdown = await engines.pricing.calculateCost(productId, ctx);
    res.json({ success: true, data: breakdown });
  })
);

router.post('/pricing/update-price', requireAuth, requireRole('admin', 'super_admin'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const { productId, newPrice, reason } = req.body;
    const result = await engines.pricing.updateProductPrice(productId, newPrice, reason, ctx);
    res.json(result);
  })
);

router.post('/pricing/bulk-discount', requireAuth, requireRole('admin', 'super_admin'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const { productIds, discountPercent, startDate, endDate } = req.body;
    const result = await engines.pricing.applyBulkDiscount(
      productIds, discountPercent, new Date(startDate), new Date(endDate), ctx
    );
    res.json(result);
  })
);

router.get('/pricing/price-history/:productId', requireAuth,
  asyncHandler(async (req: Request, res: Response) => {
    const productId = parseInt(req.params.productId, 10);
    const history = await prisma.priceHistory.findMany({
      where: { productId },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    res.json({ success: true, data: history });
  })
);

// ============================================================
// 8) ACCOUNTING ROUTES (Accounting Engine)
// ============================================================
router.post('/accounting/journal-entry', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const result = await engines.accounting.createJournalEntry(req.body, ctx);
    res.status(201).json({ success: true, data: result });
  })
);

router.post('/accounting/record-sale', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const result = await engines.accounting.recordSale(req.body, ctx);
    res.json(result);
  })
);

router.post('/accounting/payment-received', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const result = await engines.accounting.recordPaymentReceived(req.body, ctx);
    res.json(result);
  })
);

router.post('/accounting/payment-made', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const result = await engines.accounting.recordPaymentMade(req.body, ctx);
    res.json(result);
  })
);

router.post('/accounting/expense', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const result = await engines.accounting.recordExpense(req.body, ctx);
    res.json(result);
  })
);

router.get('/accounting/trial-balance', requireAuth, requireRole('admin', 'super_admin'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const from = new Date(req.query.from as string);
    const to = new Date(req.query.to as string);
    const result = await engines.accounting.getTrialBalance(from, to, ctx);
    res.json({ success: true, data: result });
  })
);

router.get('/accounting/profit-loss', requireAuth, requireRole('admin', 'super_admin'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const from = new Date(req.query.from as string);
    const to = new Date(req.query.to as string);
    const result = await engines.accounting.getProfitLoss(from, to, ctx);
    res.json({ success: true, data: result });
  })
);

router.get('/accounting/balance-sheet', requireAuth, requireRole('admin', 'super_admin'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const asOf = new Date(req.query.asOf as string);
    const result = await engines.accounting.getBalanceSheet(asOf, ctx);
    res.json({ success: true, data: result });
  })
);

// ============================================================
// 9) WORKFLOW ROUTES (Workflow Engine)
// ============================================================
router.post('/workflow/start', requireAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  const { entityType, entityId } = req.body;
  await engines.workflow.startWorkflow(entityType, entityId, ctx);
  res.json({ success: true, message: 'Workflow شروع شد' });
}));

router.post('/workflow/advance', requireAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  const { entityType, entityId, branch } = req.body;
  const result = await engines.workflow.advanceStep(entityType, entityId, ctx, branch);
  res.json(result);
}));

router.post('/workflow/cancel', requireAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  const { entityType, entityId, reason } = req.body;
  const result = await engines.workflow.cancelWorkflow(entityType, entityId, reason, ctx);
  res.json(result);
}));

router.get('/workflow/status/:entityType/:entityId', requireAuth,
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const { entityType, entityId } = req.params;
    const status = await engines.workflow.getWorkflowStatus(entityType, parseInt(entityId, 10), ctx);
    res.json({ success: true, data: status });
  })
);

router.get('/workflow/current-step/:entityType/:entityId', requireAuth,
  asyncHandler(async (req: Request, res: Response) => {
    const { entityType, entityId } = req.params;
    const step = await engines.workflow.getCurrentStep(entityType, parseInt(entityId, 10));
    res.json({ success: true, data: { currentStep: step } });
  })
);

// ============================================================
// 10) ANALYTICS ROUTES (Analytics Engine)
// ============================================================
router.get('/analytics/dashboard', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const dashboard = await engines.analytics.getDashboard(ctx);
    res.json({ success: true, data: dashboard });
  })
);

router.post('/analytics/record-kpis', requireAuth, requireRole('admin', 'super_admin'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const result = await engines.analytics.recordDailyKPIs(ctx);
    res.json(result);
  })
);

router.get('/analytics/metric/:metric', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const value = await engines.analytics.getLatestMetric(req.params.metric, ctx);
    res.json({ success: true, data: { metric: req.params.metric, value } });
  })
);

router.get('/analytics/metric/:metric/timeseries', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const from = new Date(req.query.from as string);
    const to = new Date(req.query.to as string);
    const series = await engines.analytics.getMetricTimeSeries(req.params.metric, from, to, ctx);
    res.json({ success: true, data: series });
  })
);

router.get('/analytics/sales-report', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const from = new Date(req.query.from as string);
    const to = new Date(req.query.to as string);
    const report = await engines.analytics.getSalesReport(from, to, ctx);
    res.json({ success: true, data: report });
  })
);

router.get('/analytics/production-report', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const from = new Date(req.query.from as string);
    const to = new Date(req.query.to as string);
    const report = await engines.analytics.getProductionReport(from, to, ctx);
    res.json({ success: true, data: report });
  })
);

// ============================================================
// 11) DOCUMENT ROUTES (Document Engine)
// ============================================================
const multer = require('multer');
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB
});

router.post('/documents/upload', requireAuth, upload.single('file'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const file = (req as any).file;
    if (!file) throw new BusinessError('فایل ارسال نشده است', 'VALIDATION_ERROR', 'file');

    const result = await engines.document.upload({
      file: {
        originalName: file.originalname,
        mimeType: file.mimetype,
        size: file.size,
        buffer: file.buffer,
      },
      type: req.body.type || 'other',
      category: req.body.category || 'other',
      name: req.body.name,
      description: req.body.description,
      entityType: req.body.entityType,
      entityId: req.body.entityId ? parseInt(req.body.entityId, 10) : undefined,
    }, ctx);

    res.status(201).json({ success: true, data: result });
  })
);

router.get('/documents/:id', requireAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  const id = parseInt(req.params.id, 10);
  const doc = await engines.document.getDocument(id, ctx);
  if (!doc) throw new BusinessError('سند یافت نشد', 'NOT_FOUND');
  res.json({ success: true, data: doc });
}));

router.get('/documents', requireAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  const { entityType, entityId, type } = req.query;
  const docs = await engines.document.getDocumentsByEntity(
    entityType as string,
    parseInt(entityId as string, 10),
    type as any,
    ctx,
  );
  res.json({ success: true, data: docs });
}));

router.delete('/documents/:id', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const id = parseInt(req.params.id, 10);
    const result = await engines.document.deleteDocument(id, ctx);
    res.json(result);
  })
);

router.post('/documents/:id/sign', requireAuth,
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const id = parseInt(req.params.id, 10);
    const result = await engines.document.signDocument({ ...req.body, documentId: id }, ctx);
    res.json(result);
  })
);

router.post('/documents/:id/share', requireAuth,
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const id = parseInt(req.params.id, 10);
    const { userIds, message } = req.body;
    const result = await engines.document.shareDocument(id, userIds, message, ctx);
    res.json(result);
  })
);

router.get('/documents/search', requireAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  const query = (req.query.q as string) || '';
  const filters: any = {};
  if (req.query.type) filters.type = req.query.type;
  if (req.query.category) filters.category = req.query.category;
  if (req.query.entityType) filters.entityType = req.query.entityType;
  if (req.query.from) filters.from = new Date(req.query.from as string);
  if (req.query.to) filters.to = new Date(req.query.to as string);
  const results = await engines.document.searchDocuments(query, filters, ctx);
  res.json({ success: true, data: results });
}));

// ============================================================
// 12) RULE ROUTES (Rule Engine)
// ============================================================
const ruleCrud = createCrudController({
  modelName: 'rule',
  searchableFields: ['key', 'name'],
  sortableFields: ['id', 'priority', 'engine', 'type'],
  filterableFields: ['engine', 'type', 'isActive'],
  hasTenantId: true,
});

router.get('/rules', requireAuth, requireRole('admin', 'super_admin'), ruleCrud.list);
router.get('/rules/:id', requireAuth, requireRole('admin', 'super_admin'), ruleCrud.getOne);
router.post('/rules', requireAuth, requireRole('admin', 'super_admin'), ruleCrud.create);
router.put('/rules/:id', requireAuth, requireRole('admin', 'super_admin'), ruleCrud.update);
router.delete('/rules/:id', requireAuth, requireRole('admin', 'super_admin'), ruleCrud.delete);

router.post('/rules/validate', requireAuth, requireRole('admin', 'super_admin'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const { action, data } = req.body;
    const result = await engines.rule.validate(action, data, ctx);
    res.json(result);
  })
);

// ============================================================
// 13) NOTIFICATION ROUTES (Notification Engine)
// ============================================================
router.get('/notifications', requireAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  const notifications = await prisma.userNotification.findMany({
    where: { tenantId: ctx.tenantId, userId: ctx.userId },
    orderBy: { createdAt: 'desc' },
    take: 50,
  });
  res.json({ success: true, data: notifications });
}));

router.get('/notifications/unread-count', requireAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  const count = await prisma.userNotification.count({
    where: { tenantId: ctx.tenantId, userId: ctx.userId, isRead: false },
  });
  res.json({ success: true, data: { count } });
}));

router.patch('/notifications/:id/read', requireAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  const id = parseInt(req.params.id, 10);
  const notif = await prisma.userNotification.update({
    where: { id, userId: ctx.userId },
    data: { isRead: true },
  });
  res.json({ success: true, data: notif });
}));

router.post('/notifications/mark-all-read', requireAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  await prisma.userNotification.updateMany({
    where: { tenantId: ctx.tenantId, userId: ctx.userId, isRead: false },
    data: { isRead: true },
  });
  res.json({ success: true, message: 'همه اعلان‌ها خوانده شدند' });
}));

// ============================================================
// 14) SUPPLIER ROUTES
// ============================================================
const supplierCrud = createCrudController({
  modelName: 'supplier',
  searchableFields: ['name', 'contactPerson', 'phone'],
  sortableFields: ['id', 'name', 'rating', 'type'],
  filterableFields: ['type', 'isActive', 'rating'],
  hasTenantId: true,
});

router.get('/suppliers', requireAuth, requireRole('admin', 'super_admin', 'staff'), supplierCrud.list);
router.get('/suppliers/:id', requireAuth, supplierCrud.getOne);
router.post('/suppliers', requireAuth, requireRole('admin', 'super_admin'), supplierCrud.create);
router.put('/suppliers/:id', requireAuth, requireRole('admin', 'super_admin'), supplierCrud.update);
router.delete('/suppliers/:id', requireAuth, requireRole('admin', 'super_admin'), supplierCrud.delete);

// ============================================================
// 15) PURCHASE ORDER ROUTES
// ============================================================
const purchaseOrderCrud = createCrudController({
  modelName: 'purchaseOrder',
  searchableFields: ['poNumber', 'supplierName', 'notes'],
  sortableFields: ['id', 'poNumber', 'status', 'orderDate', 'expectedDate'],
  filterableFields: ['status', 'supplierId'],
  defaultInclude: { items: true, supplier: true },
  hasTenantId: true,
});

router.get('/purchase-orders', requireAuth, requireRole('admin', 'super_admin', 'staff'), purchaseOrderCrud.list);
router.get('/purchase-orders/:id', requireAuth, purchaseOrderCrud.getOne);
router.post('/purchase-orders', requireAuth, requireRole('admin', 'super_admin', 'staff'), purchaseOrderCrud.create);
router.put('/purchase-orders/:id', requireAuth, requireRole('admin', 'super_admin', 'staff'), purchaseOrderCrud.update);
router.patch('/purchase-orders/:id', requireAuth, requireRole('admin', 'super_admin', 'staff'), purchaseOrderCrud.patch);

// ============================================================
// 16) MACHINE ROUTES
// ============================================================
const machineCrud = createCrudController({
  modelName: 'machine',
  searchableFields: ['name', 'model', 'serialNumber'],
  sortableFields: ['id', 'name', 'type', 'status', 'workHours'],
  filterableFields: ['type', 'status'],
  hasTenantId: true,
});

router.get('/machines', requireAuth, requireRole('admin', 'super_admin', 'staff'), machineCrud.list);
router.get('/machines/:id', requireAuth, machineCrud.getOne);
router.post('/machines', requireAuth, requireRole('admin', 'super_admin'), machineCrud.create);
router.put('/machines/:id', requireAuth, requireRole('admin', 'super_admin'), machineCrud.update);

// ============================================================
// 17) EMPLOYEE ROUTES
// ============================================================
const employeeCrud = createCrudController({
  modelName: 'employee',
  searchableFields: ['name', 'role', 'phone'],
  sortableFields: ['id', 'name', 'role', 'hireDate'],
  filterableFields: ['role', 'isActive', 'shift'],
  hasTenantId: true,
});

router.get('/employees', requireAuth, requireRole('admin', 'super_admin', 'staff'), employeeCrud.list);
router.get('/employees/:id', requireAuth, employeeCrud.getOne);
router.post('/employees', requireAuth, requireRole('admin', 'super_admin'), employeeCrud.create);
router.put('/employees/:id', requireAuth, requireRole('admin', 'super_admin'), employeeCrud.update);

// ============================================================
// 18) AUDIT LOG ROUTES
// ============================================================
router.get('/audit-logs', requireAuth, requireRole('admin', 'super_admin'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const page = parseInt(req.query.page as string, 10) || 1;
    const pageSize = Math.min(100, parseInt(req.query.pageSize as string, 10) || 20);

    const where: any = { tenantId: ctx.tenantId };
    if (req.query.userId) where.userId = parseInt(req.query.userId as string, 10);
    if (req.query.entityType) where.entityType = req.query.entityType;
    if (req.query.action) where.action = { contains: req.query.action as string };

    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        where,
        skip: (page - 1) * pageSize,
        take: pageSize,
        orderBy: { timestamp: 'desc' },
      }),
      prisma.auditLog.count({ where }),
    ]);

    res.json({
      success: true,
      data: logs,
      pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
    });
  })
);

// ============================================================
// 19) TENANT ROUTES
// ============================================================
router.get('/tenants', requireAuth, requireRole('super_admin'),
  asyncHandler(async (req: Request, res: Response) => {
    const tenants = await prisma.tenant.findMany({ include: { _count: true } });
    res.json({ success: true, data: tenants });
  })
);

router.get('/tenants/current', requireAuth,
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const tenant = await prisma.tenant.findUnique({ where: { id: ctx.tenantId } });
    res.json({ success: true, data: tenant });
  })
);

// ============================================================
// 20) WEBHOOK ROUTES
// ============================================================
router.use('/webhooks', webhookRoutes);

// ============================================================
// 21) AI ROUTES (Phase 6)
// ============================================================

// Sales Forecasting
router.get('/ai/sales-forecast', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const { method, periods, confidenceLevel, productId, categoryId } = req.query;
    const result = await aiEngines.salesForecasting.forecast(ctx, {
      method: method as any,
      periods: periods ? parseInt(periods as string, 10) : undefined,
      confidenceLevel: confidenceLevel ? parseFloat(confidenceLevel as string) : undefined,
      productId: productId ? parseInt(productId as string, 10) : undefined,
      categoryId: categoryId as string,
    });
    res.json({ success: true, data: result });
  })
);

router.get('/ai/sales-forecast/anomalies', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const days = req.query.days ? parseInt(req.query.days as string, 10) : 30;
    const anomalies = await aiEngines.salesForecasting.detectAnomalies(ctx, days);
    res.json({ success: true, data: anomalies });
  })
);

router.get('/ai/sales-forecast/product/:productId', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const productId = parseInt(req.params.productId, 10);
    const periods = req.query.periods ? parseInt(req.query.periods as string, 10) : 14;
    const result = await aiEngines.salesForecasting.forecastProductDemand(productId, ctx, periods);
    res.json({ success: true, data: result });
  })
);

// Smart Chat
router.post('/ai/chat/start', optionalAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  const session = await aiEngines.smartChat.startSession(ctx, ctx.userId);
  res.status(201).json({ success: true, data: session });
}));

router.post('/ai/chat/send', optionalAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  const { sessionId, message } = req.body;
  if (!sessionId || !message) {
    throw new BusinessError('sessionId و message الزامی هستند', 'VALIDATION_ERROR');
  }
  const response = await aiEngines.smartChat.sendMessage(sessionId, message, ctx);
  res.json({ success: true, data: response });
}));

router.get('/ai/chat/:sessionId', optionalAuth, asyncHandler(async (req: Request, res: Response) => {
  const session = aiEngines.smartChat.getSession(req.params.sessionId);
  if (!session) {
    throw new BusinessError('جلسه چت یافت نشد', 'NOT_FOUND', undefined, 404);
  }
  res.json({ success: true, data: session });
}));

router.post('/ai/chat/:sessionId/close', optionalAuth, asyncHandler(async (req: Request, res: Response) => {
  const { satisfactionScore } = req.body;
  await aiEngines.smartChat.closeSession(req.params.sessionId, satisfactionScore);
  res.json({ success: true, message: 'جلسه بسته شد' });
}));

router.get('/ai/chat/stats', requireAuth, requireRole('admin', 'super_admin'),
  asyncHandler(async (req: Request, res: Response) => {
    const stats = aiEngines.smartChat.getStats();
    res.json({ success: true, data: stats });
  })
);

// Product Description Generator
router.post('/ai/product-description/generate', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const { productId, tone, language, includeFeatures, includeBenefits, includeSpecs, seoOptimized } = req.body;
    const result = await aiEngines.productDescription.generate({
      productId,
      tone,
      language,
      includeFeatures,
      includeBenefits,
      includeSpecs,
      seoOptimized,
    }, ctx);
    res.json({ success: true, data: result });
  })
);

router.post('/ai/product-description/generate-bulk', requireAuth, requireRole('admin', 'super_admin'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const { category } = req.body;
    const result = await aiEngines.productDescription.generateBulk(ctx, category);
    res.json(result);
  })
);

router.post('/ai/product-description/update/:productId', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const productId = parseInt(req.params.productId, 10);
    const result = await aiEngines.productDescription.updateProductDescription(productId, ctx);
    res.json(result);
  })
);

// Customer Insights
router.get('/ai/customer-insights', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const insights = await aiEngines.customerInsights.analyze(ctx);
    res.json({ success: true, data: insights });
  })
);

router.get('/ai/customer-insights/:userId', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const userId = parseInt(req.params.userId, 10);
    const profile = await aiEngines.customerInsights.getCustomerProfile(userId, ctx);
    res.json({ success: true, data: profile });
  })
);

router.get('/ai/recommendations', optionalAuth, asyncHandler(async (req: Request, res: Response) => {
  const ctx = buildContext(req);
  if (!ctx.userId) {
    throw new BusinessError('برای دریافت پیشنهاد، وارد شوید', 'UNAUTHORIZED', undefined, 401);
  }
  const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 5;
  const recommendations = await aiEngines.customerInsights.recommendProducts(ctx.userId!, ctx, limit);
  res.json({ success: true, data: recommendations });
}));

// Anomaly Detection
router.get('/ai/anomalies', requireAuth, requireRole('admin', 'super_admin'),
  asyncHandler(async (req: Request, res: Response) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 20;
    const severity = req.query.severity as 'low' | 'medium' | 'high' | undefined;
    const anomalies = aiEngines.anomalyDetection.getRecentAnomalies(limit, severity);
    res.json({ success: true, data: anomalies });
  })
);

router.post('/ai/anomalies/scan', requireAuth, requireRole('admin', 'super_admin'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const result = await aiEngines.anomalyDetection.runFullScan(ctx);
    res.json(result);
  })
);

router.post('/ai/anomalies/check-order/:orderId', requireAuth, requireRole('admin', 'super_admin', 'staff'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const orderId = parseInt(req.params.orderId, 10);
    const anomaly = await aiEngines.anomalyDetection.detectOrderAnomaly(orderId, ctx);
    res.json({ success: true, data: anomaly });
  })
);

// ============================================================
// 22) HEALTH CHECK
// ============================================================
router.get('/health', (req: Request, res: Response) => {
  res.json({
    success: true,
    data: {
      status: 'ok',
      version: '7.0.0',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      engines: ["order","production","inventory","pricing","accounting","workflow","notification","rule","analytics","document"],
    },
  });
});

export default router;
