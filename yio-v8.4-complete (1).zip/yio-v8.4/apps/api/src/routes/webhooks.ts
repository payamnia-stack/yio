// ============================================================
// YIO V7 — Webhook Handler
// ============================================================
// ثبت webhookهای خارجی و ارسال رویدادها به آنها
//
// ساختار:
//   POST /api/v1/webhooks/register    → ثبت webhook
//   GET  /api/v1/webhooks             → لیست webhookها
//   DELETE /api/v1/webhooks/:id       → حذف webhook
//   POST /api/v1/webhooks/:id/test    → ارسال رویداد تست
//   GET  /api/v1/webhooks/events      → لیست رویدادهای قابل اشتراک
// ============================================================

import { Router, Request, Response } from 'express';
import { PrismaClient } from '@prisma/client';
import { getEventBus } from '@yio/services';
import { asyncHandler } from '../middleware/error-handler';
import { requireAuth, requireRole, buildContext } from '../middleware/auth';
import { BusinessError } from '@yio/core';
import fetch from 'node-fetch';

const prisma = new PrismaClient();
const eventBus = getEventBus();

// ===== In-Memory Webhook Registry =====
// در عمل باید در دیتابیس ذخیره شود
interface WebhookRegistration {
  id: string;
  tenantId: number;
  url: string;
  events: string[];
  secret: string;
  isActive: boolean;
  createdAt: Date;
  lastTriggeredAt?: Date;
  lastStatus?: number;
  failureCount: number;
}

const webhooks = new Map<string, WebhookRegistration>();

// ===== List Available Events =====
const AVAILABLE_EVENTS = [
  // Product
  'product.created', 'product.published', 'product.unpublished', 'product.stock_updated',
  // Order
  'order.created', 'order.confirmed', 'order.shipped', 'order.delivered', 'order.cancelled',
  // Production
  'work_order.created', 'production.started', 'production.completed', 'production.step_completed',
  // Inventory
  'inventory.stock_updated', 'inventory.low_stock', 'inventory.stock_reserved',
  // Quality
  'quality.check_passed', 'quality.check_failed',
  // Machine
  'machine.maintenance_due', 'machine.broken',
  // User
  'user.registered', 'user.logged_in',
  // Purchase
  'purchase.created', 'purchase.received',
  // Pricing (Phase 3)
  'pricing.calculated', 'pricing.changed', 'pricing.discount_applied', 'pricing.cost_updated',
  // Accounting (Phase 3)
  'accounting.entry_created', 'accounting.payment_received', 'accounting.payment_made', 'accounting.invoice_issued',
  // Workflow (Phase 3)
  'workflow.started', 'workflow.step_advanced', 'workflow.completed', 'workflow.cancelled', 'workflow.step_blocked',
  // Analytics (Phase 3)
  'analytics.snapshot_recorded', 'analytics.dashboard_updated', 'analytics.kpi_alert',
  // Document (Phase 3)
  'document.uploaded', 'document.versioned', 'document.signed', 'document.shared',
];

const router = Router();

// ===== Register Webhook =====
router.post('/register', requireAuth, requireRole('admin', 'super_admin'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const { url, events, secret } = req.body;

    if (!url || !events || !Array.isArray(events) || events.length === 0) {
      throw new BusinessError('url و events الزامی هستند', 'VALIDATION_ERROR');
    }

    // اعتبارسنجی URL
    try {
      new URL(url);
    } catch {
      throw new BusinessError('URL نامعتبر است', 'VALIDATION_ERROR', 'url');
    }

    // اعتبارسنجی events
    const invalidEvents = events.filter((e: string) => !AVAILABLE_EVENTS.includes(e));
    if (invalidEvents.length > 0) {
      throw new BusinessError(
        `رویدادهای نامعتبر: ${invalidEvents.join(', ')}`,
        'VALIDATION_ERROR',
        'events',
      );
    }

    const id = `wh_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const webhook: WebhookRegistration = {
      id,
      tenantId: ctx.tenantId,
      url,
      events,
      secret: secret || generateSecret(),
      isActive: true,
      createdAt: new Date(),
      failureCount: 0,
    };

    webhooks.set(id, webhook);

    // ثبت در همه eventهای مشخص شده
    for (const eventType of events) {
      eventBus.subscribe(eventType, async (event: any) => {
        await deliverWebhook(id, eventType, event);
      });
    }

    res.status(201).json({
      success: true,
      data: {
        id,
        url,
        events,
        secret: webhook.secret, // فقط هنگان ثبت نمایش داده می‌شود
        isActive: true,
      },
    });
  })
);

// ===== List Webhooks =====
router.get('/', requireAuth, requireRole('admin', 'super_admin'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const list = Array.from(webhooks.values())
      .filter(w => w.tenantId === ctx.tenantId)
      .map(w => ({
        id: w.id,
        url: w.url,
        events: w.events,
        isActive: w.isActive,
        createdAt: w.createdAt,
        lastTriggeredAt: w.lastTriggeredAt,
        lastStatus: w.lastStatus,
        failureCount: w.failureCount,
      }));

    res.json({ success: true, data: list });
  })
);

// ===== Delete Webhook =====
router.delete('/:id', requireAuth, requireRole('admin', 'super_admin'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const webhook = webhooks.get(req.params.id);

    if (!webhook || webhook.tenantId !== ctx.tenantId) {
      throw new BusinessError('Webhook یافت نشد', 'NOT_FOUND', undefined, 404);
    }

    webhooks.delete(req.params.id);
    // در عمل باید unsubscribe نیز انجام شود
    res.json({ success: true, message: 'Webhook حذف شد' });
  })
);

// ===== Test Webhook =====
router.post('/:id/test', requireAuth, requireRole('admin', 'super_admin'),
  asyncHandler(async (req: Request, res: Response) => {
    const ctx = buildContext(req);
    const webhook = webhooks.get(req.params.id);

    if (!webhook || webhook.tenantId !== ctx.tenantId) {
      throw new BusinessError('Webhook یافت نشد', 'NOT_FOUND', undefined, 404);
    }

    const testEvent = {
      eventName: 'webhook.test',
      timestamp: new Date(),
      data: { message: 'این یک رویداد تست است' },
    };

    const result = await deliverWebhook(req.params.id, 'webhook.test', testEvent);

    res.json({
      success: result.success,
      message: result.success ? 'تست موفق بود' : `تست ناموفق: ${result.error}`,
      data: { statusCode: result.statusCode, duration: result.duration },
    });
  })
);

// ===== List Available Events =====
router.get('/events', requireAuth, requireRole('admin', 'super_admin'),
  (req: Request, res: Response) => {
    res.json({ success: true, data: AVAILABLE_EVENTS });
  }
);

// ===== Webhook Delivery Function =====
async function deliverWebhook(
  webhookId: string,
  eventType: string,
  event: any,
): Promise<{ success: boolean; statusCode?: number; duration?: number; error?: string }> {
  const webhook = webhooks.get(webhookId);
  if (!webhook || !webhook.isActive) {
    return { success: false, error: 'Webhook غیرفعال یا حذف شده' };
  }

  if (!webhook.events.includes(eventType) && !webhook.events.includes('*')) {
    return { success: false, error: 'رویداد در لیست اشتراک نیست' };
  }

  const startTime = Date.now();

  try {
    // ایجاد امضای HMAC
    const crypto = require('crypto');
    const payload = JSON.stringify({ event: eventType, data: event, timestamp: new Date().toISOString() });
    const signature = crypto
      .createHmac('sha256', webhook.secret)
      .update(payload)
      .digest('hex');

    const response = await fetch(webhook.url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-YIO-Event': eventType,
        'X-YIO-Signature': `sha256=${signature}`,
        'X-YIO-Webhook-Id': webhookId,
        'User-Agent': 'YIO-V7-Webhook/1.0',
      },
      body: payload,
      timeout: 10000, // 10 seconds
    });

    const duration = Date.now() - startTime;
    webhook.lastTriggeredAt = new Date();
    webhook.lastStatus = response.status;

    if (response.status >= 200 && response.status < 300) {
      webhook.failureCount = 0;
      return { success: true, statusCode: response.status, duration };
    } else {
      webhook.failureCount++;
      // غیرفعال کردن بعد از ۵ شکست متوالی
      if (webhook.failureCount >= 5) {
        webhook.isActive = false;
      }
      return { success: false, statusCode: response.status, duration, error: `HTTP ${response.status}` };
    }
  } catch (e: any) {
    const duration = Date.now() - startTime;
    webhook.failureCount++;
    if (webhook.failureCount >= 5) {
      webhook.isActive = false;
    }
    return { success: false, duration, error: e.message };
  }
}

// ===== Generate Secret =====
function generateSecret(): string {
  const crypto = require('crypto');
  return crypto.randomBytes(32).toString('hex');
}

export default router;
