// ============================================================
// YIO V7 — API Client SDK
// ============================================================
// کلاینت TypeScript برای اتصال به YIO V7 API
// استفاده در frontend (Next.js) یا mobile (React Native)
// ============================================================

export interface ApiClientConfig {
  baseURL: string;
  accessToken?: string;
  refreshToken?: string;
  tenantId?: number;
  timeout?: number;
  onTokenExpired?: () => Promise<void>;
}

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    field?: string;
  };
  pagination?: {
    page: number;
    pageSize: number;
    total: number;
    totalPages: number;
  };
}


export interface ProductImageInput {
  url: string;
  alt?: string;
  sortOrder?: number;
  isPrimary?: boolean;
}

export interface ProductVideoInput {
  url: string;
  title?: string;
  sortOrder?: number;
}

export interface ProductColorInput {
  name: string;
  code: string;
  sortOrder?: number;
}

export interface ProductVariantInput {
  id?: number;
  colorId?: number | null;
  sku?: string;
  title: string;
  price?: number | null;
  salePrice?: number | null;
  stockQuantity: number;
  isDefault?: boolean;
  isActive?: boolean;
}

export interface ProductInput {
  title: string;
  brand?: string;
  category: string;
  description?: string;
  woodType?: string;
  fastDelivery?: boolean;
  isSpecial?: boolean;
  isPublished?: boolean;
  productImages?: ProductImageInput[];
  productVideos?: ProductVideoInput[];
  productColors?: ProductColorInput[];
  productVariants?: ProductVariantInput[];
}

export class ApiClient {
  private config: ApiClientConfig;

  constructor(config: ApiClientConfig) {
    this.config = {
      timeout: 30000,
      ...config,
    };
  }

  setAccessToken(token: string): void {
    this.config.accessToken = token;
  }

  setRefreshToken(token: string): void {
    this.config.refreshToken = token;
  }

  // ===== Core Request Method =====
  private async request<T = any>(
    method: string,
    path: string,
    data?: any,
    params?: Record<string, any>,
  ): Promise<ApiResponse<T>> {
    const url = new URL(`${this.config.baseURL}${path}`);

    if (params) {
      for (const [key, value] of Object.entries(params)) {
        if (value !== undefined && value !== null) {
          url.searchParams.append(key, String(value));
        }
      }
    }

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (this.config.accessToken) {
      headers['Authorization'] = `Bearer ${this.config.accessToken}`;
    }

    if (this.config.tenantId) {
      headers['X-Tenant-Id'] = String(this.config.tenantId);
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.config.timeout);

    try {
      const response = await fetch(url.toString(), {
        method,
        headers,
        body: data ? JSON.stringify(data) : undefined,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      // اگر توکن منقضی شده، تلاش برای refresh
      if (response.status === 401 && this.config.refreshToken && this.config.onTokenExpired) {
        await this.config.onTokenExpired();
        // تلاش مجدد با توکن جدید
        if (this.config.accessToken) {
          headers['Authorization'] = `Bearer ${this.config.accessToken}`;
          const retryResponse = await fetch(url.toString(), {
            method,
            headers,
            body: data ? JSON.stringify(data) : undefined,
          });
          return retryResponse.json();
        }
      }

      return response.json();
    } catch (e: any) {
      clearTimeout(timeoutId);
      return {
        success: false,
        error: {
          code: 'NETWORK_ERROR',
          message: e.message || 'خطای شبکه',
        },
      };
    }
  }

  // ===== Convenience Methods =====
  get<T = any>(path: string, params?: Record<string, any>): Promise<ApiResponse<T>> {
    return this.request<T>('GET', path, undefined, params);
  }

  post<T = any>(path: string, data?: any): Promise<ApiResponse<T>> {
    return this.request<T>('POST', path, data);
  }

  put<T = any>(path: string, data?: any): Promise<ApiResponse<T>> {
    return this.request<T>('PUT', path, data);
  }

  patch<T = any>(path: string, data?: any): Promise<ApiResponse<T>> {
    return this.request<T>('PATCH', path, data);
  }

  delete<T = any>(path: string): Promise<ApiResponse<T>> {
    return this.request<T>('DELETE', path);
  }

  upload<T = any>(path: string, file: File, fields?: Record<string, any>): Promise<ApiResponse<T>> {
    const formData = new FormData();
    formData.append('file', file);
    if (fields) {
      for (const [key, value] of Object.entries(fields)) {
        formData.append(key, String(value));
      }
    }

    const headers: Record<string, string> = {};
    if (this.config.accessToken) {
      headers['Authorization'] = `Bearer ${this.config.accessToken}`;
    }
    if (this.config.tenantId) {
      headers['X-Tenant-Id'] = String(this.config.tenantId);
    }

    return fetch(`${this.config.baseURL}${path}`, {
      method: 'POST',
      headers,
      body: formData,
    }).then(r => r.json());
  }

  // ===== Auth Methods =====
  auth = {
    login: (phone: string, password: string) =>
      this.post('/auth/login', { phone, password }),

    register: (data: { phone: string; name?: string; email?: string; password: string; verificationCode?: string }) =>
      this.post('/auth/register', data),

    refresh: (refreshToken: string) =>
      this.post('/auth/refresh', { refreshToken }),

    logout: () => this.post('/auth/logout'),

    me: () => this.get('/auth/me'),

    verifyPhone: (phone: string, code: string) =>
      this.post('/auth/verify-phone', { phone, code }),

    resendCode: (phone: string) =>
      this.post('/auth/resend-code', { phone }),
  };

  // ===== Product Methods =====
  products = {
    list: (params?: { page?: number; pageSize?: number; search?: string; category?: string; isPublished?: boolean }) =>
      this.get('/products', params),

    get: (id: number) => this.get(`/products/${id}`),

    create: (data: ProductInput) => this.post('/products', data),

    update: (id: number, data: Partial<ProductInput>) => this.put(`/products/${id}`, data),

    delete: (id: number) => this.delete(`/products/${id}`),

    publish: (id: number) => this.post(`/products/${id}/publish`),

    unpublish: (id: number) => this.post(`/products/${id}/unpublish`),

    updateStock: (id: number, stockQuantity: number) =>
      this.patch(`/products/${id}/stock`, { stockQuantity }),
  };

  // ===== Order Methods =====
  orders = {
    list: (params?: { page?: number; pageSize?: number }) =>
      this.get('/orders', params),

    get: (id: number) => this.get(`/orders/${id}`),

    create: (data: any) => this.post('/orders', data),

    confirm: (id: number) => this.post(`/orders/${id}/confirm`),

    ship: (id: number, trackingCode: string) =>
      this.post(`/orders/${id}/ship`, { trackingCode }),

    deliver: (id: number) => this.post(`/orders/${id}/deliver`),

    cancel: (id: number, reason: string) =>
      this.post(`/orders/${id}/cancel`, { reason }),
  };

  // ===== Pricing Methods =====
  pricing = {
    calculate: (input: any) => this.post('/pricing/calculate', input),

    calculateCost: (productId: number) =>
      this.get(`/pricing/cost/${productId}`),

    updatePrice: (productId: number, newPrice: number, reason: string) =>
      this.post('/pricing/update-price', { productId, newPrice, reason }),

    bulkDiscount: (productIds: number[], discountPercent: number, startDate: string, endDate: string) =>
      this.post('/pricing/bulk-discount', { productIds, discountPercent, startDate, endDate }),

    priceHistory: (productId: number) =>
      this.get(`/pricing/price-history/${productId}`),
  };

  // ===== Accounting Methods =====
  accounting = {
    createJournalEntry: (entry: any) =>
      this.post('/accounting/journal-entry', entry),

    recordSale: (data: any) => this.post('/accounting/record-sale', data),

    paymentReceived: (data: any) =>
      this.post('/accounting/payment-received', data),

    paymentMade: (data: any) => this.post('/accounting/payment-made', data),

    recordExpense: (data: any) => this.post('/accounting/expense', data),

    trialBalance: (from: string, to: string) =>
      this.get('/accounting/trial-balance', { from, to }),

    profitLoss: (from: string, to: string) =>
      this.get('/accounting/profit-loss', { from, to }),

    balanceSheet: (asOf: string) =>
      this.get('/accounting/balance-sheet', { asOf }),
  };

  // ===== Workflow Methods =====
  workflow = {
    start: (entityType: string, entityId: number) =>
      this.post('/workflow/start', { entityType, entityId }),

    advance: (entityType: string, entityId: number, branch?: string) =>
      this.post('/workflow/advance', { entityType, entityId, branch }),

    cancel: (entityType: string, entityId: number, reason: string) =>
      this.post('/workflow/cancel', { entityType, entityId, reason }),

    status: (entityType: string, entityId: number) =>
      this.get(`/workflow/status/${entityType}/${entityId}`),

    currentStep: (entityType: string, entityId: number) =>
      this.get(`/workflow/current-step/${entityType}/${entityId}`),
  };

  // ===== Analytics Methods =====
  analytics = {
    dashboard: () => this.get('/analytics/dashboard'),

    recordKPIs: () => this.post('/analytics/record-kpis'),

    metric: (metric: string) => this.get(`/analytics/metric/${metric}`),

    metricTimeSeries: (metric: string, from: string, to: string) =>
      this.get(`/analytics/metric/${metric}/timeseries`, { from, to }),

    salesReport: (from: string, to: string) =>
      this.get('/analytics/sales-report', { from, to }),

    productionReport: (from: string, to: string) =>
      this.get('/analytics/production-report', { from, to }),
  };

  // ===== Document Methods =====
  documents = {
    upload: (file: File, options: { type?: string; category?: string; name?: string; entityType?: string; entityId?: number }) =>
      this.upload('/documents/upload', file, options as any),

    get: (id: number) => this.get(`/documents/${id}`),

    list: (entityType?: string, entityId?: number, type?: string) =>
      this.get('/documents', { entityType, entityId, type }),

    delete: (id: number) => this.delete(`/documents/${id}`),

    sign: (id: number, data: any) => this.post(`/documents/${id}/sign`, data),

    share: (id: number, userIds: number[], message: string) =>
      this.post(`/documents/${id}/share`, { userIds, message }),

    search: (query: string, filters?: any) =>
      this.get('/documents/search', { q: query, ...filters }),
  };

  // ===== Webhook Methods =====
  webhooks = {
    register: (url: string, events: string[], secret?: string) =>
      this.post('/webhooks/register', { url, events, secret }),

    list: () => this.get('/webhooks'),

    delete: (id: string) => this.delete(`/webhooks/${id}`),

    test: (id: string) => this.post(`/webhooks/${id}/test`),

    events: () => this.get('/webhooks/events'),
  };

  // ===== Health Check =====
  health = () => this.get('/health');
}

// ===== Default Export =====
export function createApiClient(config: ApiClientConfig): ApiClient {
  return new ApiClient(config);
}

// ===== Singleton Instance =====
let defaultClient: ApiClient | null = null;

export function getApiClient(): ApiClient {
  if (!defaultClient) {
    throw new Error('API client not initialized. Call initApiClient() first.');
  }
  return defaultClient;
}

export function initApiClient(config: ApiClientConfig): ApiClient {
  defaultClient = new ApiClient(config);
  return defaultClient;
}
