// ============================================================
// YIO V8 — DI Bootstrap (Wire All Dependencies)
// ============================================================
// این فایل همه وابستگی‌های V8 را در یک Container مرکزی ثبت می‌کند.
// نحوه استفاده:
//
//   import { bootstrapContainer } from './bootstrap';
//   const container = await bootstrapContainer(prisma);
//   const orderEngine = await container.resolve(TOKENS.OrderEngine);
//
// در API server، این کار یک بار در startup انجام می‌شود.
// ============================================================

import { PrismaClient } from '@prisma/client';
import {
  TOKENS,
  IContainer,
} from '@yio/core';
import {
  Container,
  InMemoryEventBus,
  PrismaEventStore,
  PrismaEventStoreRepository,
  PrismaTransactionManager,
  PrismaUnitOfWork,
  AuditLogger,
  PrismaAuditLogRepository,
  InMemoryCache,
  RedisCache,
  createCache,
  setGlobalCache,
  RuleRegistry,
  RuleEngine,
  registerAllDefaultRules,
  OrderEngine,
  InventoryEngine,
  ProductionEngine,
  PricingEngine,
  AccountingEngine,
  WorkflowEngine,
  NotificationEngine,
  PermissionChecker,
  AnalyticsEngine,
  DocumentEngine,
  CommandBus,
  QueryBus,
  OrderCommandHandlers,
  OrderQueryHandlers,
  createLogger,
  registerAllGranularRules,
  OrderUseCase,
} from '@yio/services';
import { OrderRepository, ProductRepository } from '@yio/repositories';

export async function bootstrapContainer(
  prisma: PrismaClient,
  options: { useRedis?: boolean } = {},
): Promise<IContainer> {
  const container = new Container();

  // ============================================================
  // 1) Infrastructure
  // ============================================================
  container.bindInstance(TOKENS.PrismaClient, prisma);

  // V8.1: Logger مناسب محیط (Pino در production، Console در dev، Noop در test)
  const logger = createLogger();
  container.bindInstance(TOKENS.Logger, logger);

  // V8.1: EventBus با Logger تزریق شده
  const eventBus = new InMemoryEventBus(logger);
  container.bindInstance(TOKENS.EventBus, eventBus);

  // Audit Logger (Singleton)
  const auditRepo = new PrismaAuditLogRepository(prisma);
  const auditLogger = new AuditLogger(auditRepo);
  container.bindInstance(TOKENS.AuditLogger, auditLogger);

  // Event Store (Singleton)
  const eventStoreRepo = new PrismaEventStoreRepository(prisma);
  const eventStore = new PrismaEventStore(eventStoreRepo);
  container.bindInstance(TOKENS.EventStore, eventStore);

  // اتصال Event Store به EventBus (تا همه eventها ذخیره شوند)
  eventBus.attachEventStore(eventStore);

  // Transaction Manager (Singleton)
  const txManager = new PrismaTransactionManager(prisma, eventBus, auditLogger);
  container.bindInstance(TOKENS.TransactionManager, txManager);
  container.bind(TOKENS.UnitOfWork, (c) =>
    new PrismaUnitOfWork(
      prisma,
      c.resolveSync(TOKENS.EventBus),
      c.resolveSync(TOKENS.AuditLogger),
    ),
  );

  // Cache (Singleton — Redis یا InMemory)
  const cache = options.useRedis ? new RedisCache() : new InMemoryCache();
  setGlobalCache(cache);
  container.bindInstance(TOKENS.Cache, cache);

  // ============================================================
  // 2) Repositories (Singletons)
  // ============================================================
  const orderRepo = new OrderRepository(prisma);
  const productRepo = new ProductRepository(prisma);
  container.bindInstance(TOKENS.OrderRepository, orderRepo);
  container.bindInstance(TOKENS.ProductRepository, productRepo);

  // Inventory Repository — فعلاً InventoryEngine مستقیم با prisma کار می‌کند
  // در آینده IInventoryRepository جدا اضافه می‌شود
  container.bind(TOKENS.InventoryRepository, () => ({
    getStock: async () => 0,
    adjustStock: async () => 0,
    recordTransaction: async () => {},
  }));

  // ============================================================
  // 3) Rule Registry + Rule Engine
  // ============================================================
  // V8.1: تمام Ruleهای granular ثبت می‌شوند (شامل V8.0 + V8.1)
  const ruleRegistry = new RuleRegistry();
  registerAllGranularRules(ruleRegistry);
  container.bindInstance(TOKENS.RuleRegistry, ruleRegistry);

  const ruleEngine = new RuleEngine(prisma, ruleRegistry);
  container.bindInstance(TOKENS.RuleEngine, ruleEngine);

  // ============================================================
  // 4) Permission Engine (RBAC + ABAC)
  // ============================================================
  const permissionChecker = new PermissionChecker();
  container.bindInstance(TOKENS.PermissionEngine, permissionChecker);

  // ============================================================
  // 5) Business Engines (Singletons)
  // ============================================================
  // Order Engine (V8 — refactored با UoW و Rule Engine)
  const orderEngine = new OrderEngine(
    orderRepo,
    productRepo,
    container.resolveSync(TOKENS.InventoryRepository),
    eventBus,
    txManager,
    ruleEngine,
    auditLogger,
    logger,
  );
  container.bindInstance(TOKENS.OrderEngine, orderEngine);

  // V8.1: OrderUseCase (showcase of @Transactional + @Auditable)
  const orderUseCase = new OrderUseCase(
    orderRepo,
    productRepo,
    container.resolveSync(TOKENS.InventoryRepository),
    eventBus,
    ruleEngine,
    auditLogger,
    txManager,
    logger,
  );
  container.bindInstance('OrderUseCase', orderUseCase);

  // Inventory Engine
  const inventoryEngine = new InventoryEngine(prisma, eventBus);
  container.bindInstance(TOKENS.InventoryEngine, inventoryEngine);

  // Production Engine
  const productionEngine = new ProductionEngine(prisma, eventBus);
  container.bindInstance(TOKENS.ProductionEngine, productionEngine);

  // Pricing Engine
  const pricingEngine = new PricingEngine(prisma, eventBus);
  container.bindInstance(TOKENS.PricingEngine, pricingEngine);

  // Accounting Engine
  const accountingEngine = new AccountingEngine(prisma, eventBus);
  container.bindInstance(TOKENS.AccountingEngine, accountingEngine);

  // Workflow Engine
  const workflowEngine = new WorkflowEngine(prisma, eventBus);
  container.bindInstance(TOKENS.WorkflowEngine, workflowEngine);

  // Notification Engine
  const notificationEngine = new NotificationEngine(prisma, eventBus);
  container.bindInstance(TOKENS.NotificationEngine, notificationEngine);

  // Analytics Engine
  const analyticsEngine = new AnalyticsEngine(prisma, eventBus);
  container.bindInstance(TOKENS.AnalyticsEngine, analyticsEngine);

  // Document Engine
  const documentEngine = new DocumentEngine(prisma, eventBus);
  container.bindInstance(TOKENS.DocumentEngine, documentEngine);

  // ============================================================
  // 6) CQRS Buses + Handlers
  // ============================================================
  const commandBus = new CommandBus();
  const queryBus = new QueryBus();
  queryBus.attachCache(cache, 60);
  container.bindInstance(TOKENS.CommandBus, commandBus);
  container.bindInstance(TOKENS.QueryBus, queryBus);

  // Register Order Command/Query Handlers
  const orderCmdHandlers = new OrderCommandHandlers(container);
  commandBus.register('CreateOrderCommand', orderCmdHandlers.createOrder);
  commandBus.register('ConfirmOrderCommand', orderCmdHandlers.confirmOrder);
  commandBus.register('ShipOrderCommand', orderCmdHandlers.shipOrder);
  commandBus.register('CancelOrderCommand', orderCmdHandlers.cancelOrder);
  commandBus.register('DeliverOrderCommand', orderCmdHandlers.deliverOrder);
  commandBus.register('PayOrderCommand', orderCmdHandlers.payOrder);

  const orderQueryHandlers = new OrderQueryHandlers(container);
  queryBus.register('GetOrderByIdQuery', orderQueryHandlers.getOrderById);
  queryBus.register('ListOrdersQuery', orderQueryHandlers.listOrders);
  queryBus.register('GetUserOrdersQuery', orderQueryHandlers.getUserOrders);
  queryBus.register('GetOrderStatsQuery', orderQueryHandlers.getOrderStats);
  queryBus.register('SearchOrdersQuery', orderQueryHandlers.searchOrders);

  // ============================================================
  // 7) Container Self-Reference
  // ============================================================
  container.bindInstance(TOKENS.Container, container);

  // ============================================================
  // Done — Health Check
  // ============================================================
  console.log('═══════════════════════════════════════════════════');
  console.log('  YIO V8 — DI Container Bootstrapped');
  console.log(`  Registered bindings: ${container.listBindings().length}`);
  console.log(`  Registered command handlers: ${commandBus.list().length}`);
  console.log(`  Registered query handlers: ${queryBus.list().length}`);
  console.log(`  Registered rules: ${ruleRegistry.list().length}`);
  console.log(`  Registered ABAC policies: ${permissionChecker.listPolicies().length}`);
  console.log(`  Cache: ${options.useRedis ? 'Redis' : 'InMemory'}`);
  console.log('═══════════════════════════════════════════════════');

  (global as any).__yioContainer = container;
  return container;
}

// ============================================================
// Helper: Get Instance از Container (در API routes)
// ============================================================
// استفاده:
//   const orderEngine = await getService(TOKENS.OrderEngine);
export async function getService<T>(token: string): Promise<T> {
  // در عمل باید container را از app.state بگیریم
  // این wrapper فقط برای راحتی استفاده است
  const container = (global as any).__yioContainer;
  if (!container) {
    throw new Error('DI Container not bootstrapped. Call bootstrapContainer() first.');
  }
  // V8.2 Fix: cast به Promise<T> چون container از نوع any است و نمی‌تواند <T> قبول کند
  return container.resolve(token) as Promise<T>;
}
