// ============================================================
// YIO CRM Panel — Dashboard Page (V8.4 Rebuild)
// ============================================================
// پنل مدیریت فروش و ارتباط با مشتریان
// ============================================================

import React, { useState } from 'react';
import {
  PanelLayout,
  KpiCard,
  Card,
  Table,
  StatusBadge,
  Button,
  PageContainer,
  Badge,
  Tabs,
  Alert,
  SPACING,
  COLORS,
} from '@yio/ui';
import { formatCurrency, formatDate, toPersianDigits } from '@yio/ui';

const PRIMARY_COLOR = '#3b82f6'; // CRM blue

const NAV_ITEMS = [
  { label: 'داشبورد', icon: '📊', active: true },
  { label: 'سفارشات', icon: '📦', badge: '۱۲' },
  { label: 'مشتریان', icon: '👥' },
  { label: 'محصولات', icon: '🛍️' },
  {
    label: 'بازاریابی', icon: '📣', children: [
      { label: 'کمپین‌ها' },
      { label: 'کدهای تخفیف' },
      { label: 'خبرنامه' },
    ]
  },
  { label: 'گزارش‌ها', icon: '📈' },
  { label: 'تنظیمات', icon: '⚙️' },
];

export default function CRMDashboard() {
  const [activeTab, setActiveTab] = useState('recent');

  const recentOrders = [
    { id: 1, orderNumber: 'YIO-20260727-0001', customer: 'محمد محمدی', amount: 789000, status: 'pending', date: new Date() },
    { id: 2, orderNumber: 'YIO-20260727-0002', customer: 'فاطمه احمدی', amount: 350000, status: 'confirmed', date: new Date() },
    { id: 3, orderNumber: 'YIO-20260727-0003', customer: 'علی رضایی', amount: 1200000, status: 'shipping', date: new Date() },
    { id: 4, orderNumber: 'YIO-20260727-0004', customer: 'زهرا کریمی', amount: 450000, status: 'delivered', date: new Date() },
    { id: 5, orderNumber: 'YIO-20260727-0005', customer: 'حسین نوری', amount: 980000, status: 'cancelled', date: new Date() },
  ];

  const topCustomers = [
    { id: 1, name: 'محمد محمدی', phone: '09120000001', orders: 23, totalSpent: 8500000 },
    { id: 2, name: 'فاطمه احمدی', phone: '09120000002', orders: 18, totalSpent: 6200000 },
    { id: 3, name: 'علی رضایی', phone: '09120000003', orders: 15, totalSpent: 4800000 },
    { id: 4, name: 'زهرا کریمی', phone: '09120000004', orders: 12, totalSpent: 3900000 },
  ];

  return (
    <PanelLayout
      theme="crm"
      primaryColor={PRIMARY_COLOR}
      title="YIO CRM"
      navItems={NAV_ITEMS}
      user={{ name: 'مدیر فروش', role: 'Sales Manager' }}
      notifications={5}
      breadcrumbs={[
        { label: 'خانه' },
        { label: 'پنل CRM' },
        { label: 'داشبورد فروش' },
      ]}
      footer={
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.8125rem', color: COLORS.gray[500] }}>
          <span>© ۱۴۰۴ YIO CRM — تمام حقوق محفوظ است</span>
          <span>نسخه ۸.۴.۰</span>
        </div>
      }
    >
      <PageContainer
        title="داشبورد فروش"
        subtitle="خلاصه عملکرد فروش و سفارش‌های امروز"
        actions={
          <>
            <Button variant="outline" size="sm" icon="📊">دریافت گزارش</Button>
            <Button variant="primary" size="sm" icon="➕" primaryColor={PRIMARY_COLOR}>سفارش جدید</Button>
          </>
        }
      >
        {/* KPIs */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: SPACING.md,
          marginBottom: SPACING.xl,
        }}>
          <KpiCard
            title="فروش امروز"
            value={formatCurrency(2840000)}
            icon="💰"
            color={PRIMARY_COLOR}
            trend={{ value: 12, isPositive: true }}
          />
          <KpiCard
            title="سفارش‌های امروز"
            value={toPersianDigits(15)}
            unit="عدد"
            icon="📦"
            color={PRIMARY_COLOR}
            trend={{ value: 8, isPositive: true }}
          />
          <KpiCard
            title="مشتریان جدید"
            value={toPersianDigits(7)}
            unit="نفر"
            icon="👤"
            color="#10b981"
            trend={{ value: 5, isPositive: true }}
          />
          <KpiCard
            title="متوسط ارزش سفارش"
            value={formatCurrency(189000)}
            icon="📊"
            color="#f59e0b"
            trend={{ value: 3, isPositive: false }}
          />
        </div>

        {/* Alert */}
        <div style={{ marginBottom: SPACING.xl }}>
          <Alert
            type="warning"
            title="سفارش‌های در انتظار تأیید"
            message={`${toPersianDigits(12)} سفارش در انتظار تأیید هستند — لطفاً در اسرع وقت بررسی شوند.`}
          />
        </div>

        {/* Tabs */}
        <div style={{ marginBottom: SPACING.lg }}>
          <Tabs
            items={[
              { key: 'recent', label: 'سفارش‌های اخیر', icon: '📦', badge: 5 },
              { key: 'top', label: 'برترین مشتریان', icon: '🏆' },
            ]}
            active={activeTab}
            onChange={setActiveTab}
            primaryColor={PRIMARY_COLOR}
          />
        </div>

        {/* Recent Orders */}
        {activeTab === 'recent' && (
          <Card
            padding="none"
            title="سفارش‌های اخیر"
            subtitle="آخرین سفارش‌های ثبت‌شده در سیستم"
            actions={
              <Button variant="ghost" size="sm" primaryColor={PRIMARY_COLOR}>مشاهده همه ←</Button>
            }
          >
            <Table
              columns={[
                { key: 'orderNumber', title: 'شماره سفارش', render: (row) => <strong style={{ color: PRIMARY_COLOR }}>{row.orderNumber}</strong> },
                { key: 'customer', title: 'مشتری' },
                { key: 'amount', title: 'مبلغ', render: (row) => <span style={{ fontWeight: 600 }}>{formatCurrency(row.amount)}</span> },
                { key: 'status', title: 'وضعیت', render: (row) => <StatusBadge status={row.status} /> },
                { key: 'date', title: 'تاریخ', render: (row) => <span style={{ color: COLORS.gray[500] }}>{formatDate(row.date, true)}</span> },
                { key: 'actions', title: 'عملیات', render: () => <Button size="sm" variant="ghost" primaryColor={PRIMARY_COLOR}>مشاهده</Button> },
              ]}
              data={recentOrders}
              onRowClick={(row) => console.log('View order', row.id)}
            />
          </Card>
        )}

        {/* Top Customers */}
        {activeTab === 'top' && (
          <Card
            padding="none"
            title="برترین مشتریان"
            subtitle="مشتریانی که بیشترین خرید را داشته‌اند"
          >
            <Table
              columns={[
                { key: 'name', title: 'نام مشتری', render: (row) => (
                  <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.sm }}>
                    <div style={{
                      width: '32px', height: '32px', borderRadius: '50%',
                      backgroundColor: PRIMARY_COLOR, color: '#fff',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontWeight: 600, fontSize: '0.875rem',
                    }}>{row.name.charAt(0)}</div>
                    <span>{row.name}</span>
                  </div>
                ) },
                { key: 'phone', title: 'تلفن', render: (row) => <span style={{ direction: 'ltr', display: 'inline-block' }}>{row.phone}</span> },
                { key: 'orders', title: 'تعداد سفارش', render: (row) => <Badge variant="info">{toPersianDigits(row.orders)}</Badge> },
                { key: 'totalSpent', title: 'مجموع خرید', render: (row) => <span style={{ fontWeight: 700, color: PRIMARY_COLOR }}>{formatCurrency(row.totalSpent)}</span> },
              ]}
              data={topCustomers}
            />
          </Card>
        )}

        {/* Secondary cards */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
          gap: SPACING.lg,
          marginTop: SPACING.xl,
        }}>
          <Card title="فعالیت‌های امروز" subtitle="آخرین رویدادهای ثبت‌شده">
            <div style={{ display: 'flex', flexDirection: 'column', gap: SPACING.md }}>
              <ActivityItem icon="📦" color={PRIMARY_COLOR} title="سفارش جدید ثبت شد" desc="YIO-20260727-0005 توسط حسین نوری" time="۵ دقیقه پیش" />
              <ActivityItem icon="✅" color="#10b981" title="سفارش تحویل داده شد" desc="YIO-20260727-0004 با موفقیت تحویل شد" time="۱۵ دقیقه پیش" />
              <ActivityItem icon="👤" color="#f59e0b" title="مشتری جدید ثبت‌نام کرد" desc="زهرا کریمی عضو سیستم شد" time="۱ ساعت پیش" />
              <ActivityItem icon="💳" color="#8b5cf6" title="پرداخت تأیید شد" desc="مبلغ ۹۸۰٬۰۰۰ ریال تأیید شد" time="۲ ساعت پیش" />
            </div>
          </Card>

          <Card title="هدف فروش ماهانه" subtitle="مرداد ۱۴۰۴">
            <SalesProgress />
          </Card>
        </div>
      </PageContainer>
    </PanelLayout>
  );
}

// ============================================================
// Activity Item
// ============================================================
function ActivityItem({ icon, color, title, desc, time }: { icon: string; color: string; title: string; desc: string; time: string }) {
  return (
    <div style={{ display: 'flex', gap: SPACING.sm, alignItems: 'flex-start' }}>
      <div style={{
        width: '36px', height: '36px', borderRadius: '8px',
        backgroundColor: `${color}15`, color,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: '1rem', flexShrink: 0,
      }}>{icon}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{ margin: 0, fontWeight: 600, fontSize: '0.875rem', color: COLORS.gray[900] }}>{title}</p>
        <p style={{ margin: 0, fontSize: '0.8125rem', color: COLORS.gray[500], marginTop: 2 }}>{desc}</p>
        <p style={{ margin: 0, fontSize: '0.75rem', color: COLORS.gray[400], marginTop: 4 }}>{time}</p>
      </div>
    </div>
  );
}

// ============================================================
// Sales Progress
// ============================================================
function SalesProgress() {
  const target = 50000000;
  const current = 32400000;
  const percent = Math.round((current / target) * 100);
  const remaining = target - current;
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: SPACING.md }}>
        <div>
          <p style={{ margin: 0, fontSize: '1.75rem', fontWeight: 700, color: COLORS.gray[900] }}>{formatCurrency(current)}</p>
          <p style={{ margin: 0, fontSize: '0.8125rem', color: COLORS.gray[500] }}>از {formatCurrency(target)}</p>
        </div>
        <div style={{
          padding: '4px 10px', borderRadius: '9999px', backgroundColor: '#3b82f615', color: '#3b82f6',
          fontSize: '0.875rem', fontWeight: 600,
        }}>{toPersianDigits(percent)}٪</div>
      </div>
      <div style={{
        width: '100%', height: '12px', backgroundColor: COLORS.gray[100], borderRadius: '9999px',
        overflow: 'hidden', marginBottom: SPACING.md,
      }}>
        <div style={{
          width: `${percent}%`, height: '100%',
          background: 'linear-gradient(90deg, #3b82f6, #1d4ed8)',
          borderRadius: '9999px',
          transition: 'width 0.5s ease',
        }} />
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8125rem', color: COLORS.gray[500] }}>
        <span>⚡ باقیمانده: <strong style={{ color: COLORS.gray[700] }}>{formatCurrency(remaining)}</strong></span>
        <span>📈 میانگین روزانه: <strong style={{ color: COLORS.gray[700] }}>{formatCurrency(1620000)}</strong></span>
      </div>
    </div>
  );
}
