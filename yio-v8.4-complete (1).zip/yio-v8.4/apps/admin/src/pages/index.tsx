// ============================================================
// YIO Admin Panel — Dashboard Page (V8.4 Rebuild)
// ============================================================
// پنل مدیریت سیستم
// ============================================================

import React, { useState } from 'react';
import {
  PanelLayout,
  KpiCard,
  Card,
  Table,
  StatusBadge,
  Button,
  PageContainer,
  Badge,
  Tabs,
  Alert,
  SPACING,
  COLORS,
} from '@yio/ui';
import { formatCurrency, formatDate, toPersianDigits } from '@yio/ui';

const PRIMARY_COLOR = '#374151'; // Admin dark gray

const NAV_ITEMS = [
  { label: 'داشبورد', icon: '📊', active: true },
  {
    label: 'کاربران', icon: '👥', children: [
      { label: 'لیست کاربران' },
      { label: 'نقش‌ها' },
      { label: 'دسترسی‌ها' },
    ]
  },
  { label: 'Tenantها', icon: '🏢' },
  { label: 'محصولات', icon: '🛍️' },
  {
    label: 'صفحات', icon: '📄', children: [
      { label: 'صفحات سفارشی' },
      { label: 'بلاگ' },
      { label: 'FAQ' },
    ]
  },
  {
    label: 'تنظیمات', icon: '⚙️', children: [
      { label: 'تنظیمات سایت' },
      { label: 'روش‌های پرداخت' },
      { label: 'قالب‌ها' },
    ]
  },
  {
    label: 'لاگ‌ها', icon: '📜', children: [
      { label: 'Audit Log' },
      { label: 'خطاها' },
      { label: 'Webhookها' },
    ]
  },
  {
    label: 'پشتیبانی', icon: '💬', children: [
      { label: 'پیام‌ها' },
      { label: 'تیکت‌ها' },
    ]
  },
];

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('users');

  const recentUsers = [
    { id: 1, name: 'محمد محمدی', phone: '09120000001', level: 0, isVerified: true, createdAt: new Date() },
    { id: 2, name: 'فاطمه احمدی', phone: '09120000002', level: 0, isVerified: true, createdAt: new Date() },
    { id: 3, name: 'علی رضایی', phone: '09120000003', level: 2, isVerified: true, createdAt: new Date() },
    { id: 4, name: 'زهرا کریمی', phone: '09120000004', level: 3, isVerified: false, createdAt: new Date() },
    { id: 5, name: 'حسین نوری', phone: '09120000005', level: 1, isVerified: true, createdAt: new Date() },
  ];

  const auditLogs = [
    { id: 1, action: 'POST:/api/v1/products', user: 'مدیر سیستم', entity: 'Product', timestamp: new Date() },
    { id: 2, action: 'DELETE:/api/v1/users/5', user: 'مدیر سیستم', entity: 'User', timestamp: new Date() },
    { id: 3, action: 'PUT:/api/v1/orders/12', user: 'فاطمه احمدی', entity: 'Order', timestamp: new Date() },
    { id: 4, action: 'POST:/api/v1/tenants/3', user: 'مدیر سیستم', entity: 'Tenant', timestamp: new Date() },
    { id: 5, action: 'PATCH:/api/v1/settings', user: 'علی رضایی', entity: 'Setting', timestamp: new Date() },
  ];

  const systemServices = [
    { name: 'API Server', status: 'operational', uptime: '99.98%' },
    { name: 'Database (PostgreSQL)', status: 'operational', uptime: '100%' },
    { name: 'Redis Cache', status: 'operational', uptime: '99.95%' },
    { name: 'File Storage (S3)', status: 'operational', uptime: '100%' },
    { name: 'SMS Gateway', status: 'degraded', uptime: '98.5%' },
    { name: 'Email Service', status: 'operational', uptime: '99.9%' },
  ];

  return (
    <PanelLayout
      theme="admin"
      primaryColor={PRIMARY_COLOR}
      title="YIO Admin"
      navItems={NAV_ITEMS}
      user={{ name: 'مدیر سیستم', role: 'Super Admin' }}
      notifications={8}
      breadcrumbs={[
        { label: 'خانه' },
        { label: 'پنل مدیریت' },
        { label: 'داشبورد سیستم' },
      ]}
      footer={
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.8125rem', color: COLORS.gray[500] }}>
          <span>© ۱۴۰۴ YIO Admin — تمام حقوق محفوظ است</span>
          <span>نسخه ۸.۴.۰</span>
        </div>
      }
    >
      <PageContainer
        title="داشبورد مدیریت سیستم"
        subtitle="نمای کلی از کاربران، سفارشات و وضعیت سرویس‌ها"
        actions={
          <>
            <Button variant="outline" size="sm" icon="💾">پشتیبان‌گیری</Button>
            <Button variant="primary" size="sm" icon="➕" primaryColor={PRIMARY_COLOR}>کاربر جدید</Button>
          </>
        }
      >
        {/* KPIs */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: SPACING.md,
          marginBottom: SPACING.xl,
        }}>
          <KpiCard
            title="تعداد کاربران"
            value={toPersianDigits(1248)}
            unit="نفر"
            icon="👥"
            color={PRIMARY_COLOR}
            trend={{ value: 8, isPositive: true }}
          />
          <KpiCard
            title="محصولات فعال"
            value={toPersianDigits(87)}
            unit="محصول"
            icon="🛍️"
            color="#10b981"
          />
          <KpiCard
            title="سفارش‌های امروز"
            value={toPersianDigits(34)}
            unit="سفارش"
            icon="📦"
            color="#f59e0b"
            trend={{ value: 12, isPositive: true }}
          />
          <KpiCard
            title="بازدید امروز"
            value={toPersianDigits(3420)}
            icon="👁️"
            color="#3b82f6"
            trend={{ value: 18, isPositive: true }}
          />
        </div>

        {/* System Status Alert */}
        <div style={{ marginBottom: SPACING.xl }}>
          <Alert
            type="warning"
            title="وضعیت SMS Gateway"
            message="سرویس پیامک در حال حاضر با تأخیر مواجه است — ممکن است کدهای تأیید با تأخیر ارسال شوند. تیم فنی در حال بررسی است."
            onClose={() => {}}
          />
        </div>

        {/* System Status Grid */}
        <Card
          padding="none"
          title="وضعیت سیستم"
          subtitle="نظارت بر سلامت سرویس‌ها"
          actions={<Badge variant="success" size="sm">● ۵ از ۶ سرویس سالم</Badge>}
          style={{ marginBottom: SPACING.xl }}
        >
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
            gap: SPACING.sm,
            padding: SPACING.lg,
          }}>
            {systemServices.map((service) => (
              <SystemStatusItem
                key={service.name}
                name={service.name}
                status={service.status}
                uptime={service.uptime}
              />
            ))}
          </div>
        </Card>

        {/* Tabs */}
        <div style={{ marginBottom: SPACING.lg }}>
          <Tabs
            items={[
              { key: 'users', label: 'کاربران اخیر', icon: '👥', badge: 5 },
              { key: 'logs', label: 'لاگ تغییرات', icon: '📜', badge: 5 },
            ]}
            active={activeTab}
            onChange={setActiveTab}
            primaryColor={PRIMARY_COLOR}
          />
        </div>

        {/* Recent Users */}
        {activeTab === 'users' && (
          <Card
            padding="none"
            title="کاربران اخیر"
            subtitle="آخرین کاربران ثبت‌نام‌شده در سیستم"
            actions={
              <Button variant="ghost" size="sm" primaryColor={PRIMARY_COLOR}>مشاهده همه ←</Button>
            }
          >
            <Table
              columns={[
                { key: 'name', title: 'نام کاربر', render: (row) => (
                  <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.sm }}>
                    <div style={{
                      width: '32px', height: '32px', borderRadius: '50%',
                      backgroundColor: PRIMARY_COLOR, color: '#fff',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontWeight: 600, fontSize: '0.875rem',
                    }}>{row.name.charAt(0)}</div>
                    <span>{row.name}</span>
                  </div>
                ) },
                { key: 'phone', title: 'تلفن', render: (row) => <span style={{ direction: 'ltr', display: 'inline-block' }}>{row.phone}</span> },
                { key: 'level', title: 'سطح کاربری', render: (row) => {
                  const levelMap: Record<number, string> = { 0: 'pending', 1: 'confirmed', 2: 'shipping', 3: 'delivered' };
                  return <StatusBadge status={levelMap[row.level] || 'pending'} />;
                } },
                { key: 'isVerified', title: 'تأیید شده', render: (row) => row.isVerified ? <span style={{ fontSize: '1rem' }}>✅</span> : <span style={{ fontSize: '1rem' }}>❌</span> },
                { key: 'createdAt', title: 'تاریخ عضویت', render: (row) => <span style={{ color: COLORS.gray[500] }}>{formatDate(row.createdAt)}</span> },
                { key: 'actions', title: 'عملیات', render: () => <Button size="sm" variant="ghost" primaryColor={PRIMARY_COLOR}>مشاهده</Button> },
              ]}
              data={recentUsers}
              onRowClick={(row) => console.log('View user', row.id)}
            />
          </Card>
        )}

        {/* Audit Logs */}
        {activeTab === 'logs' && (
          <Card
            padding="none"
            title="لاگ تغییرات اخیر"
            subtitle="آخرین فعالیت‌های ثبت‌شده در سیستم"
          >
            <Table
              columns={[
                { key: 'action', title: 'عملیات', render: (row) => (
                  <span style={{
                    direction: 'ltr', display: 'inline-block',
                    fontFamily: 'monospace', fontSize: '0.8125rem',
                    backgroundColor: COLORS.gray[100], padding: '2px 8px',
                    borderRadius: '4px', color: COLORS.gray[800],
                  }}>{row.action}</span>
                ) },
                { key: 'user', title: 'کاربر', render: (row) => <strong>{row.user}</strong> },
                { key: 'entity', title: 'موجودیت', render: (row) => <Badge variant="info">{row.entity}</Badge> },
                { key: 'timestamp', title: 'زمان', render: (row) => <span style={{ color: COLORS.gray[500] }}>{formatDate(row.timestamp, true)}</span> },
              ]}
              data={auditLogs}
            />
          </Card>
        )}

        {/* Secondary cards */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
          gap: SPACING.lg,
          marginTop: SPACING.xl,
        }}>
          {/* Resource Usage */}
          <Card title="منابع سرور" subtitle="مصرف منابع در ۲۴ ساعت گذشته">
            <div style={{ display: 'flex', flexDirection: 'column', gap: SPACING.md }}>
              <ResourceBar label="CPU" value={42} color="#3b82f6" />
              <ResourceBar label="حافظه (RAM)" value={68} color="#10b981" />
              <ResourceBar label="فضای دیسک" value={55} color="#f59e0b" />
              <ResourceBar label="پهنای باند" value={31} color="#8b5cf6" />
            </div>
          </Card>

          {/* Quick Stats */}
          <Card title="آمار کلی" subtitle="آمار سیستم در یک نگاه">
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: SPACING.md }}>
              <QuickStat icon="🏢" label="Tenantهای فعال" value={toPersianDigits(12)} color="#3b82f6" />
              <QuickStat icon="📦" label="محصولات کل" value={toPersianDigits(234)} color="#10b981" />
              <QuickStat icon="🛒" label="سفارشات کل" value={toPersianDigits(4580)} color="#f59e0b" />
              <QuickStat icon="💰" label="درآمد کل" value={formatCurrency(284000000)} color="#8b5cf6" />
            </div>
          </Card>
        </div>
      </PageContainer>
    </PanelLayout>
  );
}

// ============================================================
// System Status Item
// ============================================================
function SystemStatusItem({ name, status, uptime }: { name: string; status: string; uptime: string }) {
  const colors: Record<string, string> = {
    operational: COLORS.success[500],
    degraded: COLORS.warning[500],
    down: COLORS.danger[500],
  };
  const labels: Record<string, string> = {
    operational: 'عملیاتی',
    degraded: 'کند',
    down: 'قطع',
  };
  const color = colors[status] || COLORS.gray[400];
  return (
    <div style={{
      padding: SPACING.md,
      borderRadius: '12px',
      backgroundColor: COLORS.gray[50],
      border: `1px solid ${COLORS.gray[200]}`,
      transition: 'all 0.2s',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.sm, marginBottom: SPACING.xs }}>
        <div style={{
          width: '8px', height: '8px', borderRadius: '50%',
          backgroundColor: color,
          boxShadow: `0 0 0 3px ${color}33`,
          flexShrink: 0,
        }} />
        <strong style={{ fontSize: '0.875rem', color: COLORS.gray[900] }}>{name}</strong>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 4 }}>
        <span style={{
          fontSize: '0.75rem', fontWeight: 600, color,
        }}>{labels[status] || status}</span>
        <span style={{ fontSize: '0.75rem', color: COLORS.gray[500] }}>آپتایم: {uptime}</span>
      </div>
    </div>
  );
}

// ============================================================
// Resource Bar
// ============================================================
function ResourceBar({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
        <span style={{ fontSize: '0.8125rem', fontWeight: 600, color: COLORS.gray[700] }}>{label}</span>
        <span style={{ fontSize: '0.8125rem', fontWeight: 700, color }}>{toPersianDigits(value)}٪</span>
      </div>
      <div style={{
        width: '100%', height: '8px', backgroundColor: COLORS.gray[100],
        borderRadius: '9999px', overflow: 'hidden',
      }}>
        <div style={{
          width: `${value}%`, height: '100%', backgroundColor: color,
          borderRadius: '9999px', transition: 'width 0.5s ease',
        }} />
      </div>
    </div>
  );
}

// ============================================================
// Quick Stat
// ============================================================
function QuickStat({ icon, label, value, color }: { icon: string; label: string; value: string; color: string }) {
  return (
    <div style={{
      padding: SPACING.md, borderRadius: '12px',
      backgroundColor: `${color}08`, border: `1px solid ${color}22`,
      display: 'flex', alignItems: 'center', gap: SPACING.sm,
    }}>
      <div style={{
        width: '40px', height: '40px', borderRadius: '10px',
        backgroundColor: color, color: '#fff',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: '1.25rem', flexShrink: 0,
      }}>{icon}</div>
      <div style={{ minWidth: 0, flex: 1 }}>
        <p style={{ margin: 0, fontSize: '0.75rem', color: COLORS.gray[500], whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{label}</p>
        <p style={{ margin: 0, fontSize: '0.95rem', fontWeight: 700, color: COLORS.gray[900], whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{value}</p>
      </div>
    </div>
  );
}
