/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Transpile local workspace packages (they contain .ts/.tsx files)
  transpilePackages: ['@yio/ui', '@yio/core', '@yio/services', '@yio/repositories', '@yio/ai'],
  env: {
    NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api/v1',
  },
};

module.exports = nextConfig;
