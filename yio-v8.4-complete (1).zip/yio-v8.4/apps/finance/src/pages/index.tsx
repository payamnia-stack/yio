// ============================================================
// YIO Finance Panel — Dashboard Page
// ============================================================
// پنل مدیریت مالی و حسابداری
// ============================================================

import React from 'react';
import { PanelLayout, KpiCard, Card, Table, StatusBadge, Button, PageContainer, SPACING, COLORS } from '@yio/ui';
import { formatCurrency, formatDate, toPersianDigits } from '@yio/ui';

const NAV_ITEMS = [
  { label: 'داشبورد', icon: '📊', active: true },
  { label: 'اسناد حسابداری', icon: '📝' },
  { label: 'فروش و درآمد', icon: '💰' },
  { label: 'هزینه‌ها', icon: '💸' },
  { label: 'پرداخت‌ها', icon: '🏦', children: [
    { label: 'دریافتی‌ها' },
    { label: 'پرداختی‌ها' },
  ]},
  { label: 'گردش کار', icon: '🔄' },
  { label: 'گزارش‌ها', icon: '📈', children: [
    { label: 'ترازنامه' },
    { label: 'سود و زیان' },
    { label: 'جریان نقدی' },
  ]},
  { label: 'تنظیمات', icon: '⚙️' },
];

export default function FinanceDashboard() {
  const recentTransactions = [
    { id: 1, entryNumber: 'JE-20260727-0001', description: 'فروش سفارش #1234', type: 'credit', amount: 789000, date: new Date() },
    { id: 2, entryNumber: 'JE-20260727-0002', description: 'پرداخت به تأمین‌کننده', type: 'debit', amount: 2500000, date: new Date() },
    { id: 3, entryNumber: 'JE-20260727-0003', description: 'دریافت وجه سفارش #1230', type: 'credit', amount: 350000, date: new Date() },
    { id: 4, entryNumber: 'JE-20260727-0004', description: 'هزینه انرژی', type: 'debit', amount: 180000, date: new Date() },
  ];

  return (
    <PanelLayout
      theme="finance"
      title="YIO Finance"
      navItems={NAV_ITEMS}
      user={{ name: 'مدیر مالی', role: 'Finance Manager' }}
      notifications={2}
    >
      <PageContainer
        title="داشبورد مالی"
        actions={
          <>
            <Button variant="outline" size="sm">دریافت گزارش</Button>
            <Button variant="primary" size="sm">سند جدید</Button>
          </>
        }
      >
        {/* KPIs */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: SPACING.md,
          marginBottom: SPACING.xl,
        }}>
          <KpiCard title="درآمد ماه" value={formatCurrency(45800000)} icon="📈" color="#8b5cf6" trend={{ value: 18, isPositive: true }} />
          <KpiCard title="هزینه‌های ماه" value={formatCurrency(28400000)} icon="📉" color="#ef4444" trend={{ value: 5, isPositive: false }} />
          <KpiCard title="سود خالص" value={formatCurrency(17400000)} icon="💰" color="#10b981" trend={{ value: 32, isPositive: true }} />
          <KpiCard title="موجودی نقدی" value={formatCurrency(82000000)} icon="🏦" color="#3b82f6" />
        </div>

        {/* Profit/Loss Summary */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: SPACING.lg,
          marginBottom: SPACING.xl,
        }}>
          <Card>
            <h3 style={{ marginBottom: SPACING.md, fontWeight: 600 }}>درآمد</h3>
            <div style={{ fontSize: '0.875rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: `${SPACING.sm} 0`, borderBottom: `1px solid ${COLORS.gray[100]}` }}>
                <span>فروش محصولات</span>
                <strong>{formatCurrency(42000000)}</strong>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: `${SPACING.sm} 0`, borderBottom: `1px solid ${COLORS.gray[100]}` }}>
                <span>درآمد ارسال</span>
                <strong>{formatCurrency(2800000)}</strong>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: `${SPACING.sm} 0`, borderBottom: `1px solid ${COLORS.gray[100]}` }}>
                <span>سایر درآمدها</span>
                <strong>{formatCurrency(1000000)}</strong>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: `${SPACING.md} 0`, fontWeight: 700, color: COLORS.success[700] }}>
                <span>جمع کل</span>
                <span>{formatCurrency(45800000)}</span>
              </div>
            </div>
          </Card>

          <Card>
            <h3 style={{ marginBottom: SPACING.md, fontWeight: 600 }}>هزینه‌ها</h3>
            <div style={{ fontSize: '0.875rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: `${SPACING.sm} 0`, borderBottom: `1px solid ${COLORS.gray[100]}` }}>
                <span>مواد اولیه</span>
                <strong>{formatCurrency(15000000)}</strong>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: `${SPACING.sm} 0`, borderBottom: `1px solid ${COLORS.gray[100]}` }}>
                <span>حقوق و دستمزد</span>
                <strong>{formatCurrency(8000000)}</strong>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: `${SPACING.sm} 0`, borderBottom: `1px solid ${COLORS.gray[100]}` }}>
                <span>هزینه‌های جانبی</span>
                <strong>{formatCurrency(5400000)}</strong>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: `${SPACING.md} 0`, fontWeight: 700, color: COLORS.danger[700] }}>
                <span>جمع کل</span>
                <span>{formatCurrency(28400000)}</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Recent Transactions */}
        <Card>
          <h3 style={{ marginBottom: SPACING.md, fontWeight: 600 }}>تراکنش‌های اخیر</h3>
          <Table
            columns={[
              { key: 'entryNumber', title: 'شماره سند' },
              { key: 'description', title: 'شرح' },
              { key: 'type', title: 'نوع', render: (row) => (
                <StatusBadge status={row.type === 'credit' ? 'paid' : 'unpaid'} />
              )},
              { key: 'amount', title: 'مبلغ', render: (row) => formatCurrency(row.amount) },
              { key: 'date', title: 'تاریخ', render: (row) => formatDate(row.date, true) },
            ]}
            data={recentTransactions}
          />
        </Card>
      </PageContainer>
    </PanelLayout>
  );
}
