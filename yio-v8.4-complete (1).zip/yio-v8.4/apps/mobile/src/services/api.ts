// ============================================================
// YIO Mobile — API Service
// ============================================================
// سرویس ارتباط با API سرور YIO V7
// ============================================================

import * as SecureStore from 'expo-secure-store';
import { Platform } from 'react-native';

const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:4000/api/v1';

interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: { code: string; message: string };
  pagination?: any;
}

class ApiService {
  private accessToken: string | null = null;
  private refreshToken: string | null = null;

  async init() {
    try {
      this.accessToken = await SecureStore.getItemAsync('yio_access_token');
      this.refreshToken = await SecureStore.getItemAsync('yio_refresh_token');
    } catch (e) {
      console.warn('SecureStore not available, falling back to memory');
    }
  }

  setTokens(access: string, refresh: string) {
    this.accessToken = access;
    this.refreshToken = refresh;
    if (Platform.OS !== 'web') {
      SecureStore.setItemAsync('yio_access_token', access);
      SecureStore.setItemAsync('yio_refresh_token', refresh);
    }
  }

  clearTokens() {
    this.accessToken = null;
    this.refreshToken = null;
    if (Platform.OS !== 'web') {
      SecureStore.deleteItemAsync('yio_access_token');
      SecureStore.deleteItemAsync('yio_refresh_token');
    }
  }

  private async request<T = any>(
    method: string,
    path: string,
    data?: any,
    params?: Record<string, any>,
  ): Promise<ApiResponse<T>> {
    const url = new URL(`${API_URL}${path}`);
    if (params) {
      for (const [key, value] of Object.entries(params)) {
        if (value !== undefined && value !== null) {
          url.searchParams.append(key, String(value));
        }
      }
    }

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (this.accessToken) {
      headers['Authorization'] = `Bearer ${this.accessToken}`;
    }

    try {
      const response = await fetch(url.toString(), {
        method,
        headers,
        body: data ? JSON.stringify(data) : undefined,
      });

      // اگر توکن منقضی شده
      if (response.status === 401 && this.refreshToken) {
        const refreshed = await this.refreshAccessToken();
        if (refreshed) {
          headers['Authorization'] = `Bearer ${this.accessToken}`;
          const retryResponse = await fetch(url.toString(), {
            method,
            headers,
            body: data ? JSON.stringify(data) : undefined,
          });
          return retryResponse.json();
        }
      }

      return response.json();
    } catch (e: any) {
      return {
        success: false,
        error: {
          code: 'NETWORK_ERROR',
          message: e.message || 'خطای شبکه',
        },
      };
    }
  }

  private async refreshAccessToken(): Promise<boolean> {
    if (!this.refreshToken) return false;

    try {
      const response = await fetch(`${API_URL}/auth/refresh`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refreshToken: this.refreshToken }),
      });
      const result = await response.json();
      if (result.success && result.data?.accessToken) {
        this.accessToken = result.data.accessToken;
        if (Platform.OS !== 'web') {
          SecureStore.setItemAsync('yio_access_token', this.accessToken);
        }
        return true;
      }
    } catch {}

    this.clearTokens();
    return false;
  }

  // ===== Auth =====
  auth = {
    login: (phone: string, password: string) =>
      this.request('POST', '/auth/login', { phone, password }),
    register: (data: any) => this.request('POST', '/auth/register', data),
    me: () => this.request('GET', '/auth/me'),
  };

  // ===== Products =====
  products = {
    list: (params?: any) => this.request('GET', '/products', undefined, params),
    get: (id: number) => this.request('GET', `/products/${id}`),
  };

  // ===== Orders =====
  orders = {
    list: (params?: any) => this.request('GET', '/orders', undefined, params),
    get: (id: number) => this.request('GET', `/orders/${id}`),
    create: (data: any) => this.request('POST', '/orders', data),
  };

  // ===== Chat =====
  chat = {
    startSession: () => this.request('POST', '/ai/chat/start'),
    sendMessage: (sessionId: string, message: string) =>
      this.request('POST', '/ai/chat/send', { sessionId, message }),
    getSession: (sessionId: string) => this.request('GET', `/ai/chat/${sessionId}`),
  };

  // ===== AI =====
  ai = {
    forecastSales: (params?: any) => this.request('GET', '/ai/sales-forecast', undefined, params),
    getRecommendations: () => this.request('GET', '/ai/recommendations'),
    getInsights: () => this.request('GET', '/ai/customer-insights'),
  };
}

export const api = new ApiService();
