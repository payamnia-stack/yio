// ============================================================
// YIO Mobile — Home Screen
// ============================================================

import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, FlatList, RefreshControl,
} from 'react-native';
import { COLORS } from '@yio/ui';
import { api } from '../services/api';
import { formatCurrency, toPersianDigits } from '@yio/ui';

export function HomeScreen({ navigation }: any) {
  const [products, setProducts] = useState<any[]>([]);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    const result = await api.products.list({ pageSize: 10, isPublished: true });
    if (result.success && result.data) {
      setProducts(result.data);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadProducts();
    setRefreshing(false);
  };

  const categories = [
    { id: 1, title: 'اسباب‌بازی چوبی', icon: '🧸', color: '#D4A373' },
    { id: 2, title: 'مایل سنگریزه‌ای', icon: '🧱', color: '#A47148' },
    { id: 3, title: 'پازل چوبی', icon: '🧩', color: '#6B705C' },
    { id: 4, title: 'وسایل آموزشی', icon: '📚', color: '#B5838D' },
  ];

  return (
    <ScrollView
      style={styles.container}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
    >
      {/* Hero */}
      <View style={styles.hero}>
        <Text style={styles.heroTitle}>اسباب‌بازی چوبی دست‌ساز</Text>
        <Text style={styles.heroSubtitle}>کیفیت بالا، طراحی زیبا</Text>
      </View>

      {/* Categories */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>دسته‌بندی‌ها</Text>
        <View style={styles.categoriesGrid}>
          {categories.map((cat) => (
            <TouchableOpacity
              key={cat.id}
              style={[styles.categoryCard, { backgroundColor: cat.color + '20' }]}
              onPress={() => navigation.navigate('Products', { category: cat.title })}
            >
              <Text style={styles.categoryIcon}>{cat.icon}</Text>
              <Text style={styles.categoryTitle}>{cat.title}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Featured Products */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>محصولات ویژه</Text>
          <TouchableOpacity onPress={() => navigation.navigate('Products')}>
            <Text style={styles.seeAll}>همه ←</Text>
          </TouchableOpacity>
        </View>
        <FlatList
          horizontal
          data={products}
          keyExtractor={(item) => item.id?.toString()}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.productCard}
              onPress={() => navigation.navigate('ProductDetail', { productId: item.id })}
            >
              <View style={styles.productImage}>
                <Text style={styles.productEmoji}>📦</Text>
              </View>
              <Text style={styles.productTitle} numberOfLines={2}>{item.title}</Text>
              <Text style={styles.productPrice}>{formatCurrency(item.price)}</Text>
            </TouchableOpacity>
          )}
          showsHorizontalScrollIndicator={false}
        />
      </View>

      {/* Features */}
      <View style={styles.featuresSection}>
        <View style={styles.feature}>
          <Text style={styles.featureIcon}>🚚</Text>
          <Text style={styles.featureText}>ارسال سریع</Text>
        </View>
        <View style={styles.feature}>
          <Text style={styles.featureIcon}>✅</Text>
          <Text style={styles.featureText}>ضمانت کیفیت</Text>
        </View>
        <View style={styles.feature}>
          <Text style={styles.featureIcon}>🔒</Text>
          <Text style={styles.featureText}>پرداخت امن</Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  hero: {
    backgroundColor: COLORS.primary[500],
    padding: 20,
    alignItems: 'center',
  },
  heroTitle: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  heroSubtitle: {
    color: '#fff',
    fontSize: 14,
    opacity: 0.9,
  },
  section: {
    padding: 15,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: COLORS.gray[900],
    marginBottom: 10,
  },
  seeAll: {
    color: COLORS.primary[500],
    fontSize: 14,
  },
  categoriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  categoryCard: {
    width: '48%',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 10,
  },
  categoryIcon: {
    fontSize: 32,
    marginBottom: 5,
  },
  categoryTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.gray[800],
  },
  productCard: {
    width: 150,
    marginRight: 10,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 10,
    borderWidth: 1,
    borderColor: COLORS.gray[200],
  },
  productImage: {
    width: '100%',
    height: 120,
    backgroundColor: COLORS.gray[100],
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  productEmoji: {
    fontSize: 40,
  },
  productTitle: {
    fontSize: 12,
    color: COLORS.gray[700],
    marginBottom: 5,
  },
  productPrice: {
    fontSize: 14,
    fontWeight: 'bold',
    color: COLORS.primary[500],
  },
  featuresSection: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 20,
    backgroundColor: COLORS.gray[50],
  },
  feature: {
    alignItems: 'center',
  },
  featureIcon: {
    fontSize: 24,
    marginBottom: 5,
  },
  featureText: {
    fontSize: 12,
    color: COLORS.gray[600],
  },
});
