// ============================================================
// YIO Mobile — CartScreen (Placeholder)
// ============================================================

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { COLORS } from '@yio/ui';

export function CartScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>CartScreen</Text>
      <Text style={styles.subtitle}>این صفحه در حال توسعه است</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: COLORS.gray[900],
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 14,
    color: COLORS.gray[500],
  },
});
