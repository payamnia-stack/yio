// ============================================================
// YIO Shop — Home Page
// ============================================================

import React from 'react';
import type { GetServerSideProps } from 'next';
import { ShopLayout, ProductCard } from '../components/Layout';
import { Card, Button, Badge, SPACING, COLORS } from '@yio/ui';

type ShopProduct = {
  id: number;
  title: string;
  price?: number | null;
  salePrice?: number | null;
  discountPrice?: number | null;
  discountPercent?: number | null;
  rating?: number;
  ratingCount?: number;
  productImages?: Array<{ url: string; alt?: string | null; isPrimary?: boolean; sortOrder?: number }>;
  productVariants?: Array<{ price?: number | null; salePrice?: number | null; stockQuantity: number; isDefault?: boolean }>;
};

export default function HomePage({ products }: { products: ShopProduct[] }) {
  const featuredProducts = products.slice(0, 8);

  const categories = [
    { id: 1, title: 'اسباب‌بازی چوبی', icon: '🧸' },
    { id: 2, title: 'مایل سنگریزه‌ای', icon: '🧱' },
    { id: 3, title: 'پازل چوبی', icon: '🧩' },
    { id: 4, title: 'وسایل آموزشی', icon: '📚' },
    { id: 5, title: 'دکوراسیون چوبی', icon: '🎨' },
  ];

  return (
    <ShopLayout>
      {/* Hero Section */}
      <section style={{
        background: `linear-gradient(135deg, ${COLORS.primary[500]} 0%, ${COLORS.primary[700]} 100%)`,
        color: '#fff',
        padding: `${SPACING['3xl']} ${SPACING.xl}`,
        textAlign: 'center',
      }}>
        <div style={{ maxWidth: '800px', margin: '0 auto' }}>
          <h1 style={{ fontSize: '2.5rem', fontWeight: 700, marginBottom: SPACING.md }}>
            اسباب‌بازی‌های چوبی دست‌ساز ایرانیان
          </h1>
          <p style={{ fontSize: '1.125rem', marginBottom: SPACING.xl, opacity: 0.9 }}>
            کیفیت بالا، طراحی زیبا و ایمن برای کودکان. ساخته شده با عشق در ایران.
          </p>
          <div style={{ display: 'flex', gap: SPACING.md, justifyContent: 'center' }}>
            <Button variant="secondary" size="lg">مشاهده محصولات</Button>
            <Button variant="outline" size="lg" style={{ color: '#fff', borderColor: '#fff' }}>
              درباره ما
            </Button>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section style={{ maxWidth: '1280px', margin: `${SPACING['2xl']} auto`, padding: `0 ${SPACING.xl}` }}>
        <h2 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: SPACING.lg, color: COLORS.gray[900] }}>
          دسته‌بندی‌ها
        </h2>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
          gap: SPACING.md,
        }}>
          {categories.map((cat) => (
            <Card key={cat.id} hoverable padding="md" style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '2.5rem', marginBottom: SPACING.sm }}>{cat.icon}</div>
              <h3 style={{ fontWeight: 600, marginBottom: SPACING.xs }}>{cat.title}</h3>
              <Badge variant="default">مشاهده محصولات</Badge>
            </Card>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section style={{ maxWidth: '1280px', margin: `${SPACING['2xl']} auto`, padding: `0 ${SPACING.xl}` }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: SPACING.lg }}>
          <h2 style={{ fontSize: '1.5rem', fontWeight: 700, color: COLORS.gray[900] }}>
            محصولات ویژه
          </h2>
          <Button variant="ghost">مشاهده همه ←</Button>
        </div>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
          gap: SPACING.md,
        }}>
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Features */}
      <section style={{
        backgroundColor: COLORS.gray[50],
        padding: `${SPACING['2xl']} ${SPACING.xl}`,
        marginTop: SPACING['2xl'],
      }}>
        <div style={{
          maxWidth: '1280px',
          margin: '0 auto',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
          gap: SPACING.lg,
        }}>
          <FeatureCard icon="🚚" title="ارسال رایگان" description="برای سفارش‌های بالای ۵۰۰٬۰۰۰ ریال" />
          <FeatureCard icon="🔒" title="پرداخت امن" description="پرداخت در محل یا آنلاین" />
          <FeatureCard icon="✅" title="ضمانت کیفیت" description="۶ ماه ضمانت تعویض" />
          <FeatureCard icon="📞" title="پشتیبانی ۲۴/۷" description="همیشه در کنار شما هستیم" />
        </div>
      </section>
    </ShopLayout>
  );
}

export const getServerSideProps: GetServerSideProps = async () => {
  const baseUrl = process.env.API_URL || process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api/v1';
  try {
    const response = await fetch(`${baseUrl}/products?page=1&pageSize=8&isPublished=true&sort=createdAt&order=desc`);
    if (!response.ok) return { props: { products: [] } };
    const payload = await response.json();
    return { props: { products: payload.data || [] } };
  } catch {
    return { props: { products: [] } };
  }
};

function FeatureCard({ icon, title, description }: { icon: string; title: string; description: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.md }}>
      <div style={{
        fontSize: '2rem',
        backgroundColor: '#fff',
        padding: SPACING.md,
        borderRadius: '50%',
      }}>
        {icon}
      </div>
      <div>
        <h4 style={{ fontWeight: 600, marginBottom: SPACING.xs }}>{title}</h4>
        <p style={{ color: COLORS.gray[500], fontSize: '0.875rem' }}>{description}</p>
      </div>
    </div>
  );
}
