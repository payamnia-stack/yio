// ============================================================
// YIO Shop — Storefront Layout
// ============================================================
// چیدمان اصلی فروشگاه با هدر، فوتر و content area
// ============================================================

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { COLORS, SPACING, SHADOWS, RADII, TRANSITIONS, Button, Badge } from '@yio/ui';
import { formatCurrency } from '@yio/ui';
import AuthModal from './AuthModal';

export function ShopLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [authOpen, setAuthOpen] = useState(false);
  const [user, setUser] = useState<{ name?: string; phone?: string; email?: string } | null>(null);

  const navLinks = [
    { href: '/', label: 'خانه' },
    { href: '/products', label: 'محصولات' },
    { href: '/categories', label: 'دسته‌بندی‌ها' },
    { href: '/blog', label: 'بلاگ' },
    { href: '/about', label: 'درباره ما' },
    { href: '/contact', label: 'تماس با ما' },
  ];

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', direction: 'rtl' }}>
      {/* ===== Header ===== */}
      <header
        style={{
          backgroundColor: '#fff',
          boxShadow: SHADOWS.sm,
          position: 'sticky',
          top: 0,
          zIndex: 100,
        }}
      >
        <div style={{
          maxWidth: '1280px',
          margin: '0 auto',
          padding: `${SPACING.md} ${SPACING.xl}`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: SPACING.lg,
        }}>
          {/* Logo */}
          <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: SPACING.sm }}>
            <div style={{
              width: '40px',
              height: '40px',
              borderRadius: RADII.md,
              backgroundColor: COLORS.primary[500],
              color: '#fff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 700,
              fontSize: '1.25rem',
            }}>
              Y
            </div>
            <span style={{ fontWeight: 700, fontSize: '1.25rem', color: COLORS.gray[900] }}>
              YIO Shop
            </span>
          </Link>

          {/* Search */}
          <form
            onSubmit={(e) => { e.preventDefault(); router.push(`/products?search=${searchQuery}`); }}
            style={{ flex: 1, maxWidth: '500px' }}
          >
            <input
              type="text"
              placeholder="جستجوی محصولات..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{
                width: '100%',
                padding: `${SPACING.sm} ${SPACING.lg}`,
                paddingRight: `2.5rem`,
                borderRadius: RADII.lg,
                border: `1px solid ${COLORS.gray[300]}`,
                fontSize: '0.875rem',
                outline: 'none',
                backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='none' stroke='%239ca3af' stroke-width='2'%3E%3Ccircle cx='11' cy='11' r='8'%3E%3C/circle%3E%3Cpath d='m21 21-4.35-4.35'%3E%3C/path%3E%3C/svg%3E")`,
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'right 0.75rem center',
              }}
            />
          </form>

          {/* Actions */}
          <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.md }}>
            <Link href="/cart" style={{ position: 'relative', color: COLORS.gray[700] }}>
              <span style={{ fontSize: '1.5rem' }}>🛒</span>
              <span style={{
                position: 'absolute',
                top: -8,
                left: -8,
                backgroundColor: COLORS.primary[500],
                color: '#fff',
                borderRadius: '50%',
                width: '20px',
                height: '20px',
                fontSize: '0.75rem',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}>۰</span>
            </Link>
            {user ? (
              <Link href="/account">
                <Button variant="outline" size="sm">
                  {user.name ? `سلام، ${user.name}` : 'حساب من'}
                </Button>
              </Link>
            ) : (
              <Button
                variant="primary"
                size="sm"
                onClick={() => setAuthOpen(true)}
              >
                ورود | ثبت‌نام
              </Button>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav style={{
          borderTop: `1px solid ${COLORS.gray[100]}`,
          padding: `${SPACING.sm} ${SPACING.xl}`,
        }}>
          <div style={{
            maxWidth: '1280px',
            margin: '0 auto',
            display: 'flex',
            gap: SPACING.xl,
          }}>
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                style={{
                  color: router.pathname === link.href ? COLORS.primary[500] : COLORS.gray[700],
                  fontWeight: router.pathname === link.href ? 600 : 400,
                  fontSize: '0.875rem',
                  textDecoration: 'none',
                  transition: TRANSITIONS.fast,
                }}
              >
                {link.label}
              </Link>
            ))}
          </div>
        </nav>
      </header>

      {/* ===== Content ===== */}
      <main style={{ flex: 1 }}>
        {children}
      </main>

      {/* ===== Footer ===== */}
      <footer style={{
        backgroundColor: COLORS.gray[900],
        color: COLORS.gray[300],
        padding: `${SPACING['2xl']} ${SPACING.xl}`,
        marginTop: SPACING['3xl'],
      }}>
        <div style={{
          maxWidth: '1280px',
          margin: '0 auto',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: SPACING.xl,
        }}>
          <div>
            <h3 style={{ color: '#fff', marginBottom: SPACING.md }}>YIO Shop</h3>
            <p style={{ fontSize: '0.875rem', lineHeight: 1.6 }}>
              فروشگاه آنلاین اسباب‌بازی‌های چوبی دست‌ساز ایرانیان. کیفیت بالا، طراحی زیبا و ایمن برای کودکان.
            </p>
          </div>
          <div>
            <h4 style={{ color: '#fff', marginBottom: SPACING.md }}>دسترسی سریع</h4>
            <ul style={{ listStyle: 'none', padding: 0, fontSize: '0.875rem', lineHeight: 2 }}>
              <li><Link href="/products" style={{ color: COLORS.gray[400] }}>محصولات</Link></li>
              <li><Link href="/orders" style={{ color: COLORS.gray[400] }}>سفارش‌های من</Link></li>
              <li><Link href="/wishlist" style={{ color: COLORS.gray[400] }}>علاقه‌مندی‌ها</Link></li>
            </ul>
          </div>
          <div>
            <h4 style={{ color: '#fff', marginBottom: SPACING.md }}>تماس با ما</h4>
            <p style={{ fontSize: '0.875rem', lineHeight: 2 }}>
              تلفن: ۰۲۱-۰۰۰۰۰۰۰۰<br />
              ایمیل: info@yio.ir<br />
              آدرس: تهران، ایران
            </p>
          </div>
          <div>
            <h4 style={{ color: '#fff', marginBottom: SPACING.md }}>نمادهای اعتماد</h4>
            <div style={{ display: 'flex', gap: SPACING.sm }}>
              <div style={{ width: '60px', height: '60px', backgroundColor: COLORS.gray[800], borderRadius: RADII.md }} />
              <div style={{ width: '60px', height: '60px', backgroundColor: COLORS.gray[800], borderRadius: RADII.md }} />
            </div>
          </div>
        </div>
        <div style={{
          maxWidth: '1280px',
          margin: `${SPACING.xl} auto 0`,
          paddingTop: SPACING.lg,
          borderTop: `1px solid ${COLORS.gray[800]}`,
          textAlign: 'center',
          fontSize: '0.875rem',
        }}>
          © ۱۴۰۴ YIO Shop — تمام حقوق محفوظ است
        </div>
      </footer>

      {/* ===== Auth Modal ===== */}
      <AuthModal
        isOpen={authOpen}
        onClose={() => setAuthOpen(false)}
        onSuccess={(u) => { setUser(u); setAuthOpen(false); }}
        mode="login"
      />
    </div>
  );
}

// ===== Product Card =====
export function ProductCard({ product }: { product: any }) {
  const variant = product.productVariants?.find((v: any) => v.isDefault) || product.productVariants?.[0];
  const image = product.productImages?.find((i: any) => i.isPrimary)?.url || product.productImages?.[0]?.url || product.image || '/placeholder.png';
  const regularPrice = variant?.price ?? product.price ?? 0;
  const currentPrice = variant?.salePrice ?? product.discountPrice ?? product.salePrice ?? regularPrice;
  const discountPercent = regularPrice > currentPrice ? Math.round((1 - currentPrice / regularPrice) * 100) : product.discountPercent;
  return (
    <div style={{
      backgroundColor: '#fff',
      borderRadius: RADII.lg,
      overflow: 'hidden',
      boxShadow: SHADOWS.md,
      transition: TRANSITIONS.base,
      cursor: 'pointer',
    }}>
      {/* Image */}
      <div style={{
        position: 'relative',
        paddingTop: '100%',
        backgroundColor: COLORS.gray[100],
      }}>
        <img
          src={image}
          alt={product.title}
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            objectFit: 'cover',
          }}
        />
        {discountPercent && (
          <div style={{
            position: 'absolute',
            top: SPACING.sm,
            right: SPACING.sm,
            backgroundColor: COLORS.danger[500],
            color: '#fff',
            padding: '2px 8px',
            borderRadius: RADII.sm,
            fontSize: '0.75rem',
            fontWeight: 600,
          }}>
            {discountPercent}٪
          </div>
        )}
      </div>

      {/* Info */}
      <div style={{ padding: SPACING.md }}>
        <h3 style={{
          fontSize: '0.875rem',
          fontWeight: 500,
          marginBottom: SPACING.xs,
          color: COLORS.gray[900],
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          display: '-webkit-box',
          WebkitLineClamp: 2,
          WebkitBoxOrient: 'vertical',
        }}>
          {product.title}
        </h3>

        <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.xs, marginBottom: SPACING.sm }}>
          <span style={{ color: COLORS.warning[500] }}>★</span>
          <span style={{ fontSize: '0.75rem', color: COLORS.gray[500] }}>
            {product.rating || '۰'} ({product.ratingCount || '۰'})
          </span>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            {currentPrice < regularPrice && (
              <p style={{ fontSize: '0.75rem', color: COLORS.gray[400], textDecoration: 'line-through' }}>
                {formatCurrency(regularPrice)}
              </p>
            )}
            <p style={{ fontSize: '1rem', fontWeight: 700, color: COLORS.primary[500] }}>
              {formatCurrency(currentPrice)}
            </p>
          </div>
          <Button size="sm" variant="primary">افزودن</Button>
        </div>
      </div>
    </div>
  );
}
