import React, { useState, useRef, useEffect } from 'react';

type AuthStep = 'input' | 'otp' | 'register' | 'success';
type InputType = 'phone' | 'email' | 'unknown';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: (user: { phone?: string; email?: string; name?: string }) => void;
  mode?: 'login' | 'register';
}

export function AuthModal({ isOpen, onClose, onSuccess, mode = 'login' }: AuthModalProps) {
  const [step, setStep] = useState<AuthStep>('input');
  const [identifier, setIdentifier] = useState('');
  const [inputType, setInputType] = useState<InputType>('unknown');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [resendTimer, setResendTimer] = useState(0);
  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);

  const detectInputType = (value: string): InputType => {
    const cleanValue = value.trim().replace(/[\s\-()]/g, '');
    if (/^(\+98|0)?9\d{9}$/.test(cleanValue)) return 'phone';
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanValue)) return 'email';
    return 'unknown';
  };

  const handleIdentifierChange = (value: string) => {
    setIdentifier(value);
    setInputType(detectInputType(value));
    setError('');
  };

  const handleSendOtp = async () => {
    if (inputType === 'unknown') { setError('لطفاً شماره موبایل یا ایمیل معتبر وارد کنید'); return; }
    setLoading(true); setError('');
    await new Promise((r) => setTimeout(r, 1000));
    setLoading(false);
    setStep('otp');
    setResendTimer(60);
    setTimeout(() => otpRefs.current[0]?.focus(), 100);
  };

  useEffect(() => {
    if (resendTimer > 0) {
      const timer = setTimeout(() => setResendTimer(resendTimer - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendTimer]);

  const handleOtpChange = (index: number, value: string) => {
    if (!/^\d?$/.test(value)) return;
    const newOtp = [...otp]; newOtp[index] = value; setOtp(newOtp);
    if (value && index < 5) otpRefs.current[index + 1]?.focus();
    if (newOtp.every((d) => d !== '') && newOtp.join('').length === 6) handleVerifyOtp(newOtp.join(''));
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) otpRefs.current[index - 1]?.focus();
  };

  const handleOtpPaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    if (pasted.length > 0) {
      const newOtp = pasted.split('').concat(Array(6 - pasted.length).fill(''));
      setOtp(newOtp as string[]);
      if (pasted.length === 6) handleVerifyOtp(pasted);
      else otpRefs.current[pasted.length]?.focus();
    }
  };

  const handleVerifyOtp = async (code: string) => {
    setLoading(true); setError('');
    await new Promise((r) => setTimeout(r, 1000));
    if (code === '123456' || code === '111111') {
      const isNewUser = Math.random() > 0.5;
      if (isNewUser && mode === 'register') { setLoading(false); setStep('register'); }
      else {
        setLoading(false); setStep('success');
        setTimeout(() => { onSuccess?.({ phone: inputType === 'phone' ? identifier : undefined, email: inputType === 'email' ? identifier : undefined }); handleClose(); }, 2000);
      }
    } else {
      setLoading(false); setError('کد تایید اشتباه است');
      setOtp(['', '', '', '', '', '']); otpRefs.current[0]?.focus();
    }
  };

  const handleResendOtp = () => {
    if (resendTimer > 0) return;
    setResendTimer(60); setOtp(['', '', '', '', '', '']);
  };

  const handleRegister = async () => {
    if (!name.trim()) { setError('لطفاً نام خود را وارد کنید'); return; }
    setLoading(true); await new Promise((r) => setTimeout(r, 1000)); setLoading(false);
    setStep('success');
    setTimeout(() => { onSuccess?.({ phone: inputType === 'phone' ? identifier : undefined, email: inputType === 'email' ? identifier : undefined, name: name.trim() }); handleClose(); }, 2000);
  };

  const handleClose = () => {
    setStep('input'); setIdentifier(''); setInputType('unknown');
    setOtp(['', '', '', '', '', '']); setName(''); setError(''); setResendTimer(0); onClose();
  };

  if (!isOpen) return null;
  const inputIcon = inputType === 'phone' ? '📱' : inputType === 'email' ? '📧' : '👤';
  const inputLabel = inputType === 'phone' ? 'شماره موبایل' : inputType === 'email' ? 'ایمیل' : 'موبایل یا ایمیل';

  return (
    <div onClick={handleClose} style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(17,24,39,0.7)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999, padding: '16px', overflowY: 'auto' }}>
      <div onClick={(e) => e.stopPropagation()} style={{ backgroundColor: '#fff', borderRadius: '24px', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.25)', width: '100%', maxWidth: '440px', maxHeight: '95vh', overflowY: 'auto', position: 'relative' }}>
        <div style={{ background: 'linear-gradient(to left, #dc2626, #991b1b)', color: '#fff', padding: '24px', borderRadius: '24px 24px 0 0', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ width: '44px', height: '44px', borderRadius: '12px', backgroundColor: 'rgba(255,255,255,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.5rem', fontWeight: 800 }}>Y</div>
            <div>
              <h2 style={{ fontSize: '1.125rem', fontWeight: 700 }}>{step === 'register' ? 'تکمیل ثبت‌نام' : step === 'success' ? 'خوش آمدید' : 'ورود | ثبت‌نام'}</h2>
              <p style={{ fontSize: '0.75rem', opacity: 0.9, marginTop: '2px' }}>{step === 'otp' ? 'کد تایید ارسال شد' : step === 'register' ? 'اطلاعات خود را تکمیل کنید' : step === 'success' ? 'با موفقیت وارد شدید' : 'به YIO Shop خوش آمدید'}</p>
            </div>
          </div>
          <button onClick={handleClose} style={{ width: '36px', height: '36px', borderRadius: '50%', backgroundColor: 'rgba(255,255,255,0.2)', border: 'none', cursor: 'pointer', color: '#fff', fontSize: '1.25rem', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>✕</button>
        </div>
        <div style={{ padding: '32px' }}>
          {step === 'input' && (
            <div>
              <div style={{ textAlign: 'center', marginBottom: '28px' }}>
                <div style={{ width: '72px', height: '72px', borderRadius: '50%', backgroundColor: '#fef3f4', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: '2rem', marginBottom: '16px' }}>🔐</div>
                <h3 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '8px', color: '#1a1a1a' }}>ورود یا ثبت‌نام</h3>
                <p style={{ fontSize: '0.875rem', color: '#6b7280', lineHeight: 1.6 }}>شماره موبایل یا ایمیل خود را وارد کنید<br />ما کد تایید را برایتان ارسال می‌کنیم</p>
              </div>
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: 600, marginBottom: '8px', color: '#374151' }}>{inputLabel}</label>
                <div style={{ position: 'relative' }}>
                  <span style={{ position: 'absolute', right: '14px', top: '50%', transform: 'translateY(-50%)', fontSize: '1.25rem', pointerEvents: 'none' }}>{inputIcon}</span>
                  <input type="text" value={identifier} onChange={(e) => handleIdentifierChange(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSendOtp()} placeholder="09xxxxxxxxx یا email@example.com" autoFocus dir="ltr" style={{ width: '100%', height: '52px', padding: '0 16px 0 48px', borderRadius: '12px', border: `2px solid ${inputType !== 'unknown' ? '#dc2626' : '#e5e7eb'}`, fontSize: '0.9375rem', outline: 'none', textAlign: 'left', fontFamily: 'inherit', transition: 'all 0.2s', backgroundColor: inputType !== 'unknown' ? '#fef3f4' : '#f9fafb' }} />
                  {inputType !== 'unknown' && <span style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: '#10b981', fontSize: '1.25rem' }}>✓</span>}
                </div>
                {inputType !== 'unknown' && <div style={{ marginTop: '8px', fontSize: '0.75rem', color: '#10b981', fontWeight: 600 }}>✓ {inputType === 'phone' ? 'شماره موبایل تشخیص داده شد' : 'ایمیل تشخیص داده شد'}</div>}
              </div>
              {error && <div style={{ padding: '10px 14px', backgroundColor: '#fef2f2', borderRadius: '8px', fontSize: '0.8125rem', color: '#dc2626', marginBottom: '16px' }}>⚠️ {error}</div>}
              <button onClick={handleSendOtp} disabled={loading || inputType === 'unknown'} style={{ width: '100%', height: '52px', backgroundColor: inputType === 'unknown' ? '#d1d5db' : '#dc2626', color: '#fff', border: 'none', borderRadius: '12px', fontSize: '0.9375rem', fontWeight: 700, cursor: inputType === 'unknown' ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', transition: 'all 0.2s' }}>
                {loading ? <>⏳ در حال ارسال کد...</> : <>ارسال کد تایید →</>}
              </button>
              <p style={{ fontSize: '0.75rem', color: '#9ca3af', textAlign: 'center', marginTop: '16px', lineHeight: 1.6 }}>با ورود یا ثبت‌نام، شرایط استفاده و حریم خصوصی YIO Shop را می‌پذیرید.</p>
            </div>
          )}
          {step === 'otp' && (
            <div>
              <div style={{ textAlign: 'center', marginBottom: '28px' }}>
                <div style={{ width: '72px', height: '72px', borderRadius: '50%', backgroundColor: '#fef3f4', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: '2rem', marginBottom: '16px' }}>{inputType === 'phone' ? '📱' : '📧'}</div>
                <h3 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '8px', color: '#1a1a1a' }}>کد تایید را وارد کنید</h3>
                <p style={{ fontSize: '0.875rem', color: '#6b7280', lineHeight: 1.6 }}>کد ۶ رقمی به <span style={{ fontWeight: 700, color: '#dc2626', direction: 'ltr', display: 'inline-block' }}>{identifier}</span> ارسال شد</p>
              </div>
              <div style={{ display: 'flex', gap: '8px', justifyContent: 'center', marginBottom: '24px', direction: 'ltr' }} onPaste={handleOtpPaste}>
                {otp.map((digit, index) => (
                  <input key={index} ref={(el) => { otpRefs.current[index] = el; }} type="text" value={digit} onChange={(e) => handleOtpChange(index, e.target.value)} onKeyDown={(e) => handleOtpKeyDown(index, e)} maxLength={1} style={{ width: '48px', height: '56px', textAlign: 'center', fontSize: '1.5rem', fontWeight: 700, borderRadius: '12px', border: `2px solid ${digit ? '#dc2626' : '#e5e7eb'}`, backgroundColor: digit ? '#fef3f4' : '#f9fafb', outline: 'none', fontFamily: 'inherit', color: '#1a1a1a', transition: 'all 0.2s' }} />
                ))}
              </div>
              <div style={{ padding: '10px 14px', backgroundColor: '#dbeafe', borderRadius: '8px', fontSize: '0.75rem', color: '#1e40af', textAlign: 'center', marginBottom: '16px' }}>💡 در محیط توسعه، کد پیش‌فرض: <strong dir="ltr">123456</strong></div>
              {error && <div style={{ padding: '10px 14px', backgroundColor: '#fef2f2', borderRadius: '8px', fontSize: '0.8125rem', color: '#dc2626', marginBottom: '16px', textAlign: 'center' }}>⚠️ {error}</div>}
              {loading && <div style={{ textAlign: 'center', marginBottom: '16px' }}>⏳</div>}
              <div style={{ textAlign: 'center', marginBottom: '16px' }}>
                {resendTimer > 0 ? <span style={{ fontSize: '0.8125rem', color: '#9ca3af' }}>ارسال مجدد کد تا <span style={{ fontWeight: 700, color: '#dc2626' }}>{String(Math.floor(resendTimer / 60)).padStart(2, '0')}:{String(resendTimer % 60).padStart(2, '0')}</span></span> : <button onClick={handleResendOtp} style={{ background: 'none', border: 'none', color: '#dc2626', fontSize: '0.875rem', fontWeight: 600, cursor: 'pointer', padding: 0 }}>← ارسال مجدد کد</button>}
              </div>
              <button onClick={() => { setStep('input'); setOtp(['', '', '', '', '', '']); setError(''); }} style={{ width: '100%', padding: '10px', background: 'none', border: 'none', color: '#6b7280', fontSize: '0.8125rem', cursor: 'pointer' }}>← تغییر شماره/ایمیل</button>
            </div>
          )}
          {step === 'register' && (
            <div>
              <div style={{ textAlign: 'center', marginBottom: '28px' }}>
                <div style={{ width: '72px', height: '72px', borderRadius: '50%', backgroundColor: '#fef3f4', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: '2rem', marginBottom: '16px' }}>👋</div>
                <h3 style={{ fontSize: '1.25rem', fontWeight: 700, marginBottom: '8px', color: '#1a1a1a' }}>خوش آمدید!</h3>
                <p style={{ fontSize: '0.875rem', color: '#6b7280', lineHeight: 1.6 }}>برای تکمیل ثبت‌نام، نام خود را وارد کنید</p>
              </div>
              <div style={{ marginBottom: '16px' }}>
                <label style={{ display: 'block', fontSize: '0.8125rem', fontWeight: 600, marginBottom: '8px', color: '#374151' }}>نام و نام خانوادگی</label>
                <input type="text" value={name} onChange={(e) => { setName(e.target.value); setError(''); }} onKeyDown={(e) => e.key === 'Enter' && handleRegister()} placeholder="مثلاً: محمد رضایی" autoFocus style={{ width: '100%', height: '52px', padding: '0 16px', borderRadius: '12px', border: '2px solid #e5e7eb', fontSize: '0.9375rem', outline: 'none', fontFamily: 'inherit', textAlign: 'right', transition: 'all 0.2s', backgroundColor: '#f9fafb' }} />
              </div>
              <div style={{ padding: '12px 16px', backgroundColor: '#f3f4f6', borderRadius: '12px', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.8125rem', color: '#6b7280' }}>
                <span>{inputType === 'phone' ? '📱' : '📧'}</span><span dir="ltr" style={{ fontWeight: 600, color: '#374151' }}>{identifier}</span><span style={{ marginRight: 'auto' }}>✓ تایید شد</span>
              </div>
              {error && <div style={{ padding: '10px 14px', backgroundColor: '#fef2f2', borderRadius: '8px', fontSize: '0.8125rem', color: '#dc2626', marginBottom: '16px' }}>⚠️ {error}</div>}
              <button onClick={handleRegister} disabled={loading || !name.trim()} style={{ width: '100%', height: '52px', backgroundColor: name.trim() ? '#dc2626' : '#d1d5db', color: '#fff', border: 'none', borderRadius: '12px', fontSize: '0.9375rem', fontWeight: 700, cursor: name.trim() ? 'pointer' : 'not-allowed' }}>{loading ? 'در حال ثبت...' : 'تکمیل ثبت‌نام ✓'}</button>
            </div>
          )}
          {step === 'success' && (
            <div style={{ textAlign: 'center', padding: '20px 0' }}>
              <div style={{ width: '80px', height: '80px', borderRadius: '50%', backgroundColor: '#dcfce7', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: '2.5rem', marginBottom: '20px' }}>✅</div>
              <h3 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '8px', color: '#1a1a1a' }}>{mode === 'register' ? 'ثبت‌نام موفق بود!' : 'خوش آمدید!'}</h3>
              <p style={{ fontSize: '0.875rem', color: '#6b7280', lineHeight: 1.6 }}>{name ? `سلام ${name}، ` : ''}با موفقیت وارد شدید</p>
              <div style={{ marginTop: '24px' }}>⏳</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default AuthModal;
