/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  transpilePackages: ['@yio/ui', '@yio/core', '@yio/services', '@yio/repositories', '@yio/ai'],
  images: {
    domains: ['localhost', 'yio.ir', 'api.yio.ir'],
  },
  env: {
    NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api/v1',
    NEXT_PUBLIC_SITE_URL: process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000',
  },
  experimental: {
    externalDir: true,
  },
};

module.exports = nextConfig;
