import { defineConfig } from 'vitest/config';
import path from 'path';

export default defineConfig({
  test: {
    globals: true,
    environment: 'node',
    include: [
      'packages/**/__tests__/**/*.test.ts',
      'packages/**/__tests__/**/*.integration.test.ts',
      'packages/**/__tests__/**/*.contract.test.ts',
    ],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json', 'html'],
      exclude: ['**/node_modules/**', '**/dist/**'],
    },
  },
  esbuild: {
    // پشتیبانی از TypeScript Decorators
    target: 'es2022',
    tsconfigRaw: {
      compilerOptions: {
        experimentalDecorators: true,
        emitDecoratorMetadata: true,
        target: 'es2022',
      },
    },
  },
  resolve: {
    alias: {
      '@yio/core': path.resolve(__dirname, 'packages/core/src'),
      '@yio/services': path.resolve(__dirname, 'packages/services/src'),
      '@yio/repositories': path.resolve(__dirname, 'packages/repositories/src'),
    },
  },
});
