'use client';

import { useState, useEffect } from 'react';
import {
  Plus, Search, Edit2, Trash2, ChevronRight, ChevronLeft,
  Package, Eye, EyeOff, Star, X,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AdminStats } from './admin-stats';
import { ProductForm } from './product-form';
import { formatPrice, toFa, parseColors } from '@/lib/shop-data';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

export function AdminProducts() {
  const [products, setProducts] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');
  const [inStock, setInStock] = useState('all');
  const [isSpecial, setIsSpecial] = useState('all');
  const [sort, setSort] = useState('newest');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);

  const [showForm, setShowForm] = useState(false);
  const [editProduct, setEditProduct] = useState<any>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  const fetchProducts = async () => {
    setLoading(true);
    const params = new URLSearchParams({
      search,
      sort,
      page: String(page),
      pageSize: '10',
    });
    if (category !== 'all') params.set('category', category);
    if (inStock !== 'all') params.set('inStock', inStock);
    if (isSpecial !== 'all') params.set('isSpecial', isSpecial);

    try {
      const res = await fetch(`/api/products?${params}`);
      if (res.status === 401) {
        toast.error('سشن شما منقضی شده. دوباره وارد شوید.');
        return;
      }
      const data = await res.json();
      setProducts(data.products || []);
      setStats(data.stats);
      setTotalPages(data.pagination?.totalPages || 1);
      setTotal(data.pagination?.total || 0);
    } catch {
      toast.error('خطا در دریافت محصولات');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      setPage(1);
      fetchProducts();
    }, 300);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, category, inStock, isSpecial, sort]);

  useEffect(() => {
    fetchProducts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page]);

  const handleDelete = async () => {
    if (!deleteId) return;
    setDeleteLoading(true);
    try {
      const res = await fetch(`/api/products/${deleteId}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('محصول حذف شد');
        setDeleteId(null);
        fetchProducts();
      } else {
        toast.error('خطا در حذف محصول');
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setDeleteLoading(false);
    }
  };

  const handleToggleStock = async (product: any) => {
    // تغییر سریع موجودی بین ۰ و ۱ (یا مقدار قبلی)
    // منطق جدید: موجود بودن فقط با تعداد موجودی کنترل می‌شود
    const newQty = (product.stockQuantity > 0) ? 0 : 10;
    try {
      const res = await fetch(`/api/products/${product.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stockQuantity: newQty }),
      });
      if (res.ok) {
        toast.success(newQty > 0 ? 'محصول موجود شد (موجودی: ۱۰)' : 'محصول ناموجود شد (موجودی: ۰)');
        fetchProducts();
      }
    } catch {
      toast.error('خطا در تغییر وضعیت');
    }
  };

  const categoryList = ['همه', 'اسباب‌بازی چوبی', 'ظروف آشپزخانه', 'مبلمان چوبی', 'دکوراسیون چوبی', 'لوازم کودک', 'هدیه و صنایع دستی'];

  return (
    <div className="space-y-4">
        {/* آمار */}
        <AdminStats stats={stats} />

        {/* نوار ابزار */}
        <div className="bg-white rounded-xl p-4 mb-4 shadow-sm">
          <div className="flex flex-col lg:flex-row gap-3 mb-3">
            {/* جستجو */}
            <div className="relative flex-1">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                type="text"
                placeholder="جستجو در عنوان، برند، نوع چوب..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pr-10"
              />
            </div>

            {/* فیلترها */}
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="w-full lg:w-44">
                <SelectValue placeholder="دسته‌بندی" />
              </SelectTrigger>
              <SelectContent>
                {categoryList.map(c => (
                  <SelectItem key={c} value={c === 'همه' ? 'all' : c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={inStock} onValueChange={setInStock}>
              <SelectTrigger className="w-full lg:w-36">
                <SelectValue placeholder="موجودی" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه</SelectItem>
                <SelectItem value="true">موجود</SelectItem>
                <SelectItem value="false">ناموجود</SelectItem>
              </SelectContent>
            </Select>

            <Select value={isSpecial} onValueChange={setIsSpecial}>
              <SelectTrigger className="w-full lg:w-36">
                <SelectValue placeholder="فروش ویژه" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">همه</SelectItem>
                <SelectItem value="true">فروش ویژه</SelectItem>
                <SelectItem value="false">عادی</SelectItem>
              </SelectContent>
            </Select>

            <Select value={sort} onValueChange={setSort}>
              <SelectTrigger className="w-full lg:w-36">
                <SelectValue placeholder="مرتب‌سازی" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">جدیدترین</SelectItem>
                <SelectItem value="oldest">قدیمی‌ترین</SelectItem>
                <SelectItem value="priceAsc">ارزان‌ترین</SelectItem>
                <SelectItem value="priceDesc">گران‌ترین</SelectItem>
                <SelectItem value="rating">محبوب‌ترین</SelectItem>
                <SelectItem value="title">الفبایی</SelectItem>
              </SelectContent>
            </Select>

            {/* افزودن محصول */}
            <Button
              onClick={() => {
                setEditProduct(null);
                setShowForm(true);
              }}
              className="bg-[#dc2626] hover:bg-[#b91c1c] whitespace-nowrap"
            >
              <Plus className="w-4 h-4 ml-1" />
              محصول جدید
            </Button>
          </div>

          {/* تعداد نتایج */}
          <div className="flex items-center justify-between text-sm text-gray-500">
            <span>
              نمایش {toFa(products.length)} محصول از {toFa(total)} محصول
            </span>
            {(search || category !== 'all' || inStock !== 'all' || isSpecial !== 'all') && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setSearch('');
                  setCategory('all');
                  setInStock('all');
                  setIsSpecial('all');
                  setSort('newest');
                }}
              >
                <X className="w-4 h-4 ml-1" />
                پاک کردن فیلترها
              </Button>
            )}
          </div>
        </div>

        {/* جدول محصولات */}
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          {loading ? (
            <div className="p-8 text-center text-gray-500">
              <div className="inline-block w-8 h-8 border-4 border-gray-200 border-t-[#dc2626] rounded-full animate-spin mb-3"></div>
              <p>در حال بارگذاری محصولات...</p>
            </div>
          ) : products.length === 0 ? (
            <div className="p-12 text-center">
              <Package className="w-16 h-16 mx-auto text-gray-300 mb-3" />
              <p className="text-gray-500 mb-4">هیچ محصولی یافت نشد</p>
              <Button
                onClick={() => {
                  setEditProduct(null);
                  setShowForm(true);
                }}
                className="bg-[#dc2626] hover:bg-[#b91c1c]"
              >
                <Plus className="w-4 h-4 ml-1" />
                افزودن اولین محصول
              </Button>
            </div>
          ) : (
            <>
              {/* نمایش دسکتاپ - جدول */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="text-right p-3 text-xs font-bold text-gray-600">تصویر</th>
                      <th className="text-right p-3 text-xs font-bold text-gray-600">عنوان</th>
                      <th className="text-right p-3 text-xs font-bold text-gray-600">دسته</th>
                      <th className="text-right p-3 text-xs font-bold text-gray-600">چوب</th>
                      <th className="text-right p-3 text-xs font-bold text-gray-600">قیمت</th>
                      <th className="text-right p-3 text-xs font-bold text-gray-600">موجودی</th>
                      <th className="text-right p-3 text-xs font-bold text-gray-600">انتشار</th>
                      <th className="text-right p-3 text-xs font-bold text-gray-600">ویژه</th>
                      <th className="text-center p-3 text-xs font-bold text-gray-600">عملیات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map(p => {
                      const colors = parseColors(p.colors);
                      return (
                        <tr key={p.id} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="p-3">
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img
                              src={p.image}
                              alt={p.title}
                              className="w-12 h-12 object-cover rounded-lg"
                            />
                          </td>
                          <td className="p-3 max-w-xs">
                            <p className="text-sm font-medium line-clamp-2">{p.title}</p>
                            <div className="flex items-center gap-1 mt-1">
                              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                              <span className="text-xs text-gray-500 fa-num">{toFa(p.rating.toFixed(1))}</span>
                            </div>
                          </td>
                          <td className="p-3">
                            <span className="text-xs bg-gray-100 px-2 py-1 rounded">{p.category}</span>
                          </td>
                          <td className="p-3 text-xs text-gray-600">{p.woodType || '-'}</td>
                          <td className="p-3">
                            {p.discountPrice ? (
                              <div>
                                <span className="text-xs text-gray-400 line-through fa-num block">
                                  {formatPrice(p.price)}
                                </span>
                                <span className="text-sm font-bold text-[#dc2626] fa-num">
                                  {formatPrice(p.discountPrice)}
                                </span>
                              </div>
                            ) : (
                              <span className="text-sm font-bold fa-num">{formatPrice(p.price)}</span>
                            )}
                          </td>
                          <td className="p-3">
                            <button
                              onClick={() => handleToggleStock(p)}
                              className={`flex items-center gap-1 px-2 py-1 rounded text-xs ${
                                (p.stockQuantity || 0) > 0
                                  ? 'bg-green-50 text-green-600 hover:bg-green-100'
                                  : 'bg-red-50 text-red-600 hover:bg-red-100'
                              }`}
                            >
                              {(p.stockQuantity || 0) > 0 ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                              {(p.stockQuantity || 0) > 0 ? 'موجود' : 'ناموجود'}
                            </button>
                            <span className={`text-[10px] fa-num block mt-1 ${
                              (p.stockQuantity || 0) > 0 ? 'text-gray-500' : 'text-red-500 font-bold'
                            }`}>
                              موجودی: {toFa(p.stockQuantity || 0)} عدد
                            </span>
                          </td>
                          <td className="p-3">
                            <button
                              onClick={async () => {
                                try {
                                  await fetch(`/api/products/${p.id}`, {
                                    method: 'PUT',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({ isPublished: !p.isPublished }),
                                  });
                                  toast.success(p.isPublished ? 'محصول خاموش شد' : 'محصول منتشر شد');
                                  fetchProducts();
                                } catch { toast.error('خطا'); }
                              }}
                              className={`flex items-center gap-1 px-2 py-1 rounded text-xs ${
                                p.isPublished
                                  ? 'bg-blue-50 text-blue-600 hover:bg-blue-100'
                                  : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                              }`}
                            >
                              {p.isPublished ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                              {p.isPublished ? 'منتشر' : 'خاموش'}
                            </button>
                          </td>
                          <td className="p-3">
                            {p.isSpecial && (
                              <span className="bg-amber-50 text-amber-600 px-2 py-1 rounded text-xs flex items-center gap-1 w-fit">
                                <Star className="w-3 h-3 fill-amber-500" />
                                بله
                              </span>
                            )}
                          </td>
                          <td className="p-3">
                            <div className="flex items-center justify-center gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  setEditProduct(p);
                                  setShowForm(true);
                                }}
                                className="h-8 w-8"
                                title="ویرایش"
                              >
                                <Edit2 className="w-4 h-4 text-blue-600" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => setDeleteId(p.id)}
                                className="h-8 w-8"
                                title="حذف"
                              >
                                <Trash2 className="w-4 h-4 text-red-600" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* نمایش موبایل - کارت */}
              <div className="md:hidden divide-y divide-gray-100">
                {products.map(p => (
                  <div key={p.id} className="p-3 flex gap-3">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={p.image}
                      alt={p.title}
                      className="w-16 h-16 object-cover rounded-lg shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium line-clamp-2 mb-1">{p.title}</p>
                      <p className="text-xs text-gray-500 mb-1">{p.category} - {p.woodType}</p>
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-sm font-bold text-[#dc2626] fa-num">
                          {formatPrice(p.discountPrice || p.price)}
                        </span>
                        {p.isSpecial && (
                          <span className="bg-amber-50 text-amber-600 px-1.5 py-0.5 rounded text-[10px]">ویژه</span>
                        )}
                        <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                          (p.stockQuantity || 0) > 0 ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'
                        }`}>
                          {(p.stockQuantity || 0) > 0 ? 'موجود' : 'ناموجود'}
                        </span>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setEditProduct(p);
                            setShowForm(true);
                          }}
                          className="h-7 text-xs"
                        >
                          <Edit2 className="w-3 h-3 ml-1" />
                          ویرایش
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setDeleteId(p.id)}
                          className="h-7 text-xs text-red-600"
                        >
                          <Trash2 className="w-3 h-3 ml-1" />
                          حذف
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* صفحه‌بندی */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between p-4 border-t border-gray-100 bg-gray-50">
                  <p className="text-sm text-gray-600 fa-num">
                    صفحه {toFa(page)} از {toFa(totalPages)}
                  </p>
                  <div className="flex gap-1">
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page === 1}
                      onClick={() => setPage(p => p - 1)}
                    >
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                    {Array.from({ length: Math.min(totalPages, 5) }).map((_, idx) => {
                      const pageNum = idx + 1;
                      return (
                        <Button
                          key={pageNum}
                          variant={page === pageNum ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => setPage(pageNum)}
                          className={page === pageNum ? 'bg-[#dc2626] hover:bg-[#b91c1c]' : ''}
                        >
                          <span className="fa-num">{toFa(pageNum)}</span>
                        </Button>
                      );
                    })}
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={page === totalPages}
                      onClick={() => setPage(p => p + 1)}
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

      {/* فرم افزودن/ویرایش */}
      {showForm && (
        <ProductForm
          product={editProduct}
          onSave={() => {
            setShowForm(false);
            setEditProduct(null);
            fetchProducts();
          }}
          onCancel={() => {
            setShowForm(false);
            setEditProduct(null);
          }}
        />
      )}

      {/* دیالوگ تأیید حذف */}
      <AlertDialog open={deleteId !== null} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف محصول</AlertDialogTitle>
            <AlertDialogDescription>
              آیا از حذف این محصول مطمئن هستید؟ این عملیات قابل بازگشت نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleteLoading}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteLoading ? 'در حال حذف...' : 'بله، حذف کن'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
