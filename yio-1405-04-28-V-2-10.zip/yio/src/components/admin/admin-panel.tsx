'use client';

import { useState } from 'react';
import {
  LogOut, ArrowRight, Package, ShoppingBag, CreditCard, Ticket,
  Building2, FolderOpen, Settings, FolderTree, Users,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import Image from 'next/image';
import { toast } from 'sonner';
import { AdminProducts } from './admin-products';
import { AdminOrders } from './admin-orders';
import { AdminPaymentMethods } from './admin-payment-methods';
import { AdminCoupons } from './admin-coupons';
import { AdminExtra } from './admin-extra';
import { AdminFileManager } from './admin-file-manager';
import { AdminSettings } from './admin-settings';
import { AdminCategories } from './admin-categories';
import { AdminUsers } from './admin-users';
import { ResponsiveTabs } from './responsive-tabs';

interface AdminPanelProps {
  onExit: () => void;
}

type Tab = 'products' | 'orders' | 'users' | 'categories' | 'payments' | 'coupons' | 'extra' | 'files' | 'settings';

export function AdminPanel({ onExit }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<Tab>('products');

  const handleLogout = async () => {
    try {
      await fetch('/api/admin/logout', { method: 'POST' });
      toast.success('خارج شدید');
      onExit();
    } catch {
      toast.error('خطا در خروج');
    }
  };

  const handleTabChange = (key: string) => {
    setActiveTab(key as Tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const tabs = [
    { key: 'products', label: 'محصولات', icon: Package, short: 'محصولات' },
    { key: 'orders', label: 'سفارش‌ها', icon: ShoppingBag, short: 'سفارش‌ها' },
    { key: 'users', label: 'اعضا', icon: Users, short: 'اعضا' },
    { key: 'categories', label: 'دسته‌بندی‌ها', icon: FolderTree, short: 'دسته‌ها' },
    { key: 'payments', label: 'پرداخت‌ها', icon: CreditCard, short: 'پرداخت' },
    { key: 'coupons', label: 'تخفیف‌ها', icon: Ticket, short: 'تخفیف' },
    { key: 'extra', label: 'عمده و ارتباطات', icon: Building2, short: 'عمده' },
    { key: 'files', label: 'فایل منیجر', icon: FolderOpen, short: 'فایل‌ها' },
    { key: 'settings', label: 'تنظیمات', icon: Settings, short: 'تنظیمات' },
  ];

  return (
    <div className="fixed inset-0 z-40 bg-gray-50 overflow-y-auto">
      {/* ===================== هدر ===================== */}
      <div className="sticky top-0 z-30 bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-3 md:px-4 py-2.5 md:py-3 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 md:gap-3 min-w-0">
            <div className="relative w-9 h-9 md:w-10 md:h-10 shrink-0">
              <Image src="/yio-logo.png" alt="YIO" fill sizes="40px" className="object-contain rounded-lg" />
            </div>
            <div className="min-w-0">
              <h1 className="font-bold text-base md:text-lg text-[#dc2626] truncate">پنل مدیریت YIO</h1>
              <p className="text-[10px] md:text-xs text-gray-500 hidden sm:block truncate">
                {tabs.find(t => t.key === activeTab)?.label || 'مدیریت فروشگاه محصولات چوبی'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 md:gap-2 shrink-0">
            <Button variant="outline" size="sm" onClick={onExit} className="hidden sm:flex">
              <ArrowRight className="w-4 h-4 ml-1" /> مشاهده فروشگاه
            </Button>
            <Button variant="outline" size="icon" onClick={onExit} className="sm:hidden h-9 w-9" aria-label="مشاهده فروشگاه">
              <ArrowRight className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={handleLogout} className="text-red-600 hover:bg-red-50">
              <LogOut className="w-4 h-4 ml-1" />
              <span className="hidden sm:inline">خروج</span>
            </Button>
          </div>
        </div>

        {/* سیستم تب responsive */}
        <ResponsiveTabs
          tabs={tabs}
          activeTab={activeTab}
          onTabChange={handleTabChange}
          variant="panel"
          maxVisible={4}
        />
      </div>

      {/* ===================== محتوای تب فعال ===================== */}
      <div className="container mx-auto px-3 md:px-4 py-4 md:py-6 pb-24 md:pb-6">
        {activeTab === 'products' && <AdminProducts />}
        {activeTab === 'orders' && <AdminOrders onBack={() => setActiveTab('products')} />}
        {activeTab === 'users' && <AdminUsers />}
        {activeTab === 'categories' && <AdminCategories />}
        {activeTab === 'payments' && <AdminPaymentMethods />}
        {activeTab === 'coupons' && <AdminCoupons />}
        {activeTab === 'extra' && <AdminExtra />}
        {activeTab === 'files' && <AdminFileManager />}
        {activeTab === 'settings' && <AdminSettings />}
      </div>
    </div>
  );
}
