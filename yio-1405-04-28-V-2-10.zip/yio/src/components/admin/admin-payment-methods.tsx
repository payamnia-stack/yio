'use client';

import { useState, useEffect } from 'react';
import {
  Plus, Edit2, Trash2, CreditCard, Banknote, Wallet, Building,
  CheckCircle, XCircle, Star, X, Save, Shield,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

interface PaymentMethod {
  id: number;
  name: string;
  type: string;
  bank?: string | null;
  merchantId?: string | null;
  terminalId?: string | null;
  apiKey?: string | null;
  callbackUrl?: string | null;
  description?: string | null;
  logo?: string | null;
  isActive: boolean;
  isDefault: boolean;
  priority: number;
}

const paymentTypes = [
  { value: 'cod', label: 'پرداخت در محل', icon: Banknote, color: 'bg-green-50 text-green-700' },
  { value: 'online', label: 'درگاه آنلاین', icon: CreditCard, color: 'bg-blue-50 text-blue-700' },
  { value: 'wallet', label: 'کیف پول', icon: Wallet, color: 'bg-purple-50 text-purple-700' },
  { value: 'transfer', label: 'انتقال بانکی', icon: Building, color: 'bg-amber-50 text-amber-700' },
];

const bankList = [
  'زرین‌پال', 'آیدی‌پی', 'نکست‌پی', 'پرداخت آنلاین بانک ملت',
  'پرداخت آنلاین بانک سامان', 'پرداخت آنلاین بانک پارسیان',
  'پرداخت آنلاین بانک تجارت', 'بانک ملی', 'بانک صادرات',
  'بانک رفاه', 'بانک سپه', 'بانک کشاورزی',
  'پی‌پینگ', 'ژي‌پی', 'سایر',
];

export function AdminPaymentMethods() {
  const [methods, setMethods] = useState<PaymentMethod[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editMethod, setEditMethod] = useState<PaymentMethod | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const fetchMethods = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/payment-methods');
      if (res.status === 401) {
        toast.error('سشن منقضی شده');
        return;
      }
      const data = await res.json();
      setMethods(data.methods || []);
    } catch {
      toast.error('خطا در دریافت روش‌های پرداخت');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMethods();
  }, []);

  const handleToggleActive = async (method: PaymentMethod) => {
    try {
      const res = await fetch(`/api/payment-methods/${method.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !method.isActive }),
      });
      if (res.ok) {
        toast.success(method.isActive ? 'غیرفعال شد' : 'فعال شد');
        fetchMethods();
      }
    } catch {
      toast.error('خطا در تغییر وضعیت');
    }
  };

  const handleSetDefault = async (method: PaymentMethod) => {
    try {
      const res = await fetch(`/api/payment-methods/${method.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isDefault: true }),
      });
      if (res.ok) {
        toast.success('به‌عنوان پیش‌فرض تنظیم شد');
        fetchMethods();
      }
    } catch {
      toast.error('خطا');
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      const res = await fetch(`/api/payment-methods/${deleteId}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('حذف شد');
        setDeleteId(null);
        fetchMethods();
      }
    } catch {
      toast.error('خطا در حذف');
    }
  };

  const getTypeInfo = (type: string) => paymentTypes.find(t => t.value === type) || paymentTypes[0];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <CreditCard className="w-6 h-6 text-[#dc2626]" />
          روش‌های پرداخت
        </h2>
        <Button
          onClick={() => { setEditMethod(null); setShowForm(true); }}
          className="bg-[#dc2626] hover:bg-[#b91c1c]"
        >
          <Plus className="w-4 h-4 ml-1" />
          افزودن روش پرداخت
        </Button>
      </div>

      {/* هشدار امنیتی */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-start gap-3">
        <Shield className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
        <div className="text-sm text-blue-800">
          <p className="font-bold mb-1">اطلاعات امنیتی شما رمزنگاری می‌شود</p>
          <p className="text-xs">کد پذیرنده، ترمینال و کلید API با الگوریتم AES-256 رمزنگاری شده و به‌صورت ماسک شده نمایش داده می‌شوند.</p>
        </div>
      </div>

      {/* لیست روش‌های پرداخت */}
      {loading ? (
        <div className="bg-white rounded-xl p-8 text-center">
          <div className="inline-block w-8 h-8 border-4 border-gray-200 border-t-[#dc2626] rounded-full animate-spin"></div>
        </div>
      ) : methods.length === 0 ? (
        <div className="bg-white rounded-xl p-12 text-center shadow-sm">
          <CreditCard className="w-16 h-16 mx-auto text-gray-300 mb-3" />
          <p className="text-gray-500 mb-4">هیچ روش پرداختی ثبت نشده</p>
          <Button
            onClick={() => { setEditMethod(null); setShowForm(true); }}
            className="bg-[#dc2626] hover:bg-[#b91c1c]"
          >
            <Plus className="w-4 h-4 ml-1" />
            افزودن اولین روش پرداخت
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {methods.map(method => {
            const typeInfo = getTypeInfo(method.type);
            const Icon = typeInfo.icon;
            return (
              <div
                key={method.id}
                className={`bg-white rounded-xl p-4 border-2 shadow-sm transition-all ${
                  method.isDefault ? 'border-[#dc2626]' : 'border-gray-100'
                } ${!method.isActive ? 'opacity-60' : ''}`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-lg ${typeInfo.color} flex items-center justify-center`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold">{method.name}</h3>
                        {method.isDefault && (
                          <span className="bg-[#dc2626] text-white text-[10px] px-1.5 py-0.5 rounded flex items-center gap-0.5">
                            <Star className="w-2.5 h-2.5 fill-white" />
                            پیش‌فرض
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-gray-500">{typeInfo.label}</p>
                      {method.bank && <p className="text-xs text-gray-400">{method.bank}</p>}
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    {method.isActive ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : (
                      <XCircle className="w-4 h-4 text-gray-400" />
                    )}
                  </div>
                </div>

                {/* اطلاعات حساس (ماسک شده) */}
                {method.type === 'online' && (
                  <div className="bg-gray-50 rounded-lg p-2 space-y-1 mb-3">
                    {method.merchantId && (
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-gray-500">کد پذیرنده:</span>
                        <code dir="ltr" className="font-mono">{method.merchantId}</code>
                      </div>
                    )}
                    {method.terminalId && (
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-gray-500">ترمینال:</span>
                        <code dir="ltr" className="font-mono">{method.terminalId}</code>
                      </div>
                    )}
                    {method.apiKey && (
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-gray-500">کلید API:</span>
                        <code dir="ltr" className="font-mono">{method.apiKey}</code>
                      </div>
                    )}
                  </div>
                )}

                {method.description && (
                  <p className="text-xs text-gray-600 mb-3 line-clamp-2">{method.description}</p>
                )}

                {/* دکمه‌ها */}
                <div className="flex gap-1 pt-2 border-t border-gray-50">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => { setEditMethod(method); setShowForm(true); }}
                    className="flex-1 h-8 text-xs"
                  >
                    <Edit2 className="w-3 h-3 ml-1" />
                    ویرایش
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleToggleActive(method)}
                    className="h-8 text-xs"
                  >
                    {method.isActive ? 'غیرفعال' : 'فعال'}
                  </Button>
                  {!method.isDefault && method.isActive && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleSetDefault(method)}
                      className="h-8 text-xs text-[#dc2626]"
                    >
                      پیش‌فرض
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setDeleteId(method.id)}
                    className="h-8 text-xs text-red-600"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* فرم افزودن/ویرایش */}
      {showForm && (
        <PaymentMethodForm
          method={editMethod}
          onSave={() => {
            setShowForm(false);
            setEditMethod(null);
            fetchMethods();
          }}
          onCancel={() => {
            setShowForm(false);
            setEditMethod(null);
          }}
        />
      )}

      {/* دیالوگ حذف */}
      <AlertDialog open={deleteId !== null} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف روش پرداخت</AlertDialogTitle>
            <AlertDialogDescription>
              آیا مطمئن هستید؟ این روش پرداخت از دسترس خارج خواهد شد.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// === فرم افزودن/ویرایش روش پرداخت ===
function PaymentMethodForm({
  method,
  onSave,
  onCancel,
}: {
  method: PaymentMethod | null;
  onSave: () => void;
  onCancel: () => void;
}) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    type: 'online',
    bank: '',
    merchantId: '',
    terminalId: '',
    apiKey: '',
    callbackUrl: '',
    description: '',
    logo: '',
    isActive: true,
    isDefault: false,
    priority: 0,
  });

  useEffect(() => {
    if (method) {
      const safeStr = (v: any): string => (typeof v === 'string' && v) ? v : '';
      const masked = (v: any): boolean => typeof v === 'string' && v.startsWith('••••');
      setFormData({
        name: method.name || '',
        type: method.type || 'online',
        bank: method.bank || '',
        merchantId: safeStr(method.merchantId) && !masked(method.merchantId) ? method.merchantId : '',
        terminalId: safeStr(method.terminalId) && !masked(method.terminalId) ? method.terminalId : '',
        apiKey: safeStr(method.apiKey) && !masked(method.apiKey) ? method.apiKey : '',
        callbackUrl: method.callbackUrl || '',
        description: method.description || '',
        logo: method.logo || '',
        isActive: method.isActive,
        isDefault: method.isDefault,
        priority: method.priority || 0,
      });
    }
  }, [method]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (formData.name.trim().length < 3) {
      toast.error('نام باید حداقل ۳ کاراکتر باشد');
      return;
    }

    if (formData.type === 'online' && !method && !formData.merchantId.trim()) {
      toast.error('کد پذیرنده برای درگاه آنلاین الزامی است');
      return;
    }

    setLoading(true);

    // اگر مقادیر ماسک شده هستن، نمی‌فرستیم
    const payload: any = { ...formData };
    if (method) {
      // در حالت ویرایش، اگر مقدار خالی یا ماسک شده بود، نمی‌فرستیم
      if (!formData.merchantId || formData.merchantId.startsWith('••••')) delete payload.merchantId;
      if (!formData.terminalId || formData.terminalId.startsWith('••••')) delete payload.terminalId;
      if (!formData.apiKey || formData.apiKey.startsWith('••••')) delete payload.apiKey;
    }

    try {
      const url = method ? `/api/payment-methods/${method.id}` : '/api/payment-methods';
      const httpMethod = method ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method: httpMethod,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (res.ok) {
        toast.success(method ? 'ویرایش شد' : 'افزوده شد');
        onSave();
      } else {
        toast.error(data.error || 'خطا');
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  };

  const typeInfo = paymentTypes.find(t => t.value === formData.type) || paymentTypes[0];
  const TypeIcon = typeInfo.icon;

  return (
    <div className="fixed inset-0 z-50 bg-gray-900/50 backdrop-blur-sm flex items-center justify-center p-2 md:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl my-8 max-h-[95vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-100 p-4 flex items-center justify-between z-10">
          <h2 className="text-lg font-bold">
            {method ? 'ویرایش روش پرداخت' : 'افزودن روش پرداخت'}
          </h2>
          <Button variant="ghost" size="icon" onClick={onCancel}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 md:p-6 space-y-4">
          {/* نوع پرداخت */}
          <div className="space-y-2">
            <Label>نوع پرداخت *</Label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {paymentTypes.map(t => {
                const Icon = t.icon;
                return (
                  <button
                    key={t.value}
                    type="button"
                    onClick={() => setFormData({ ...formData, type: t.value })}
                    className={`flex flex-col items-center gap-1 p-3 rounded-lg border-2 transition-all ${
                      formData.type === t.value
                        ? 'border-[#dc2626] bg-red-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <Icon className={`w-6 h-6 ${formData.type === t.value ? 'text-[#dc2626]' : 'text-gray-500'}`} />
                    <span className="text-xs font-medium">{t.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* نام و بانک */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">نام نمایشی *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
                placeholder="مثلا: درگاه زرین‌پال"
                required
              />
            </div>
            <div className="space-y-2">
              <Label>بانک / PSP</Label>
              <Select
                value={formData.bank}
                onValueChange={v => setFormData({ ...formData, bank: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب بانک" />
                </SelectTrigger>
                <SelectContent>
                  {bankList.map(b => (
                    <SelectItem key={b} value={b}>{b}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* فیلدهای درگاه آنلاین */}
          {formData.type === 'online' && (
            <div className="bg-blue-50 rounded-xl p-4 space-y-3">
              <h3 className="font-bold text-sm text-blue-800 flex items-center gap-2">
                <Shield className="w-4 h-4" />
                اطلاعات درگاه (رمزنگاری می‌شود)
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="merchantId">کد پذیرنده (Merchant ID)</Label>
                  <Input
                    id="merchantId"
                    value={formData.merchantId}
                    onChange={e => setFormData({ ...formData, merchantId: e.target.value })}
                    placeholder={method?.merchantId || "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"}
                    dir="ltr"
                  />
                  {method?.merchantId && (
                    <p className="text-[10px] text-gray-500">مقدار فعلی: {method.merchantId} (خالی بگذارید = بدون تغییر)</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="terminalId">شماره ترمینال</Label>
                  <Input
                    id="terminalId"
                    value={formData.terminalId}
                    onChange={e => setFormData({ ...formData, terminalId: e.target.value })}
                    placeholder={method?.terminalId || "XXXXXXXX"}
                    dir="ltr"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="apiKey">کلید API / کلید خصوصی</Label>
                <Input
                  id="apiKey"
                  type="password"
                  value={formData.apiKey}
                  onChange={e => setFormData({ ...formData, apiKey: e.target.value })}
                  placeholder={method?.apiKey || "••••••••••••"}
                  dir="ltr"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="callbackUrl">آدرس بازگشت (Callback URL)</Label>
                <Input
                  id="callbackUrl"
                  value={formData.callbackUrl}
                  onChange={e => setFormData({ ...formData, callbackUrl: e.target.value })}
                  placeholder="https://yio-shop.ir/api/payment/callback"
                  dir="ltr"
                />
              </div>
            </div>
          )}

          {/* اطلاعات انتقال بانکی */}
          {formData.type === 'transfer' && (
            <div className="bg-amber-50 rounded-xl p-4 space-y-3">
              <h3 className="font-bold text-sm text-amber-800">اطلاعات حساب بانکی</h3>
              <Textarea
                value={formData.description}
                onChange={e => setFormData({ ...formData, description: e.target.value })}
                placeholder="شماره حساب، شماره کارت، نام صاحب حساب و نام بانک را وارد کنید"
                rows={4}
              />
            </div>
          )}

          {/* توضیحات */}
          {formData.type !== 'transfer' && (
            <div className="space-y-2">
              <Label htmlFor="description">توضیحات</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={e => setFormData({ ...formData, description: e.target.value })}
                placeholder="توضیحات روش پرداخت..."
                rows={2}
              />
            </div>
          )}

          {/* آدرس لوگو */}
          <div className="space-y-2">
            <Label htmlFor="logo">آدرس لوگو (اختیاری)</Label>
            <Input
              id="logo"
              value={formData.logo}
              onChange={e => setFormData({ ...formData, logo: e.target.value })}
              placeholder="https://example.com/logo.png"
              dir="ltr"
            />
          </div>

          {/* اولویت */}
          <div className="space-y-2">
            <Label htmlFor="priority">اولویت نمایش (عدد کمتر = اول)</Label>
            <Input
              id="priority"
              type="number"
              value={formData.priority}
              onChange={e => setFormData({ ...formData, priority: parseInt(e.target.value) || 0 })}
              min="0"
              max="999"
            />
          </div>

          {/* سوئیچ‌ها */}
          <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center justify-between">
              <Label htmlFor="isActive" className="cursor-pointer">فعال</Label>
              <Switch
                id="isActive"
                checked={formData.isActive}
                onCheckedChange={v => setFormData({ ...formData, isActive: v })}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="isDefault" className="cursor-pointer">پیش‌فرض</Label>
              <Switch
                id="isDefault"
                checked={formData.isDefault}
                onCheckedChange={v => setFormData({ ...formData, isDefault: v })}
              />
            </div>
          </div>

          {/* دکمه‌ها */}
          <div className="flex gap-3">
            <Button
              type="submit"
              disabled={loading}
              className="flex-1 bg-[#dc2626] hover:bg-[#b91c1c] h-12"
            >
              <Save className="w-4 h-4 ml-2" />
              {loading ? 'در حال ذخیره...' : (method ? 'ذخیره تغییرات' : 'افزودن')}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              className="h-12 px-6"
            >
              انصراف
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
