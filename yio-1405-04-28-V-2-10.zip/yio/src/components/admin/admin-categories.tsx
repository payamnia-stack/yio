'use client';

import { useState, useEffect } from 'react';
import { FolderTree, Plus, Edit2, Trash2, X, Save, GripVertical, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const iconOptions = ['📦', '🧸', '🍽️', '🪑', '🖼️', '👶', '🎁', '🎨', '🌳', '🔧', '📚', '⚽', '🛒', '💄', '🏠', '🪵'];

export function AdminCategories() {
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editCat, setEditCat] = useState<any>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    title: '', icon: '📦', color: '#dc2626', description: '', order: 0, isActive: true,
  });

  const fetchCategories = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/categories');
      if (res.ok) {
        const data = await res.json();
        setCategories(data.categories || []);
      } else if (res.status === 401) {
        toast.error('سشن منقضی شده. دوباره وارد شوید.');
      }
    } catch {
      toast.error('خطا در دریافت دسته‌بندی‌ها');
    } finally {
      setLoading(false);
    }
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { fetchCategories(); }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.title.trim().length < 2) {
      toast.error('عنوان باید حداقل ۲ کاراکتر باشد');
      return;
    }

    try {
      const url = editCat ? `/api/admin/categories/${editCat.id}` : '/api/admin/categories';
      const method = editCat ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (res.ok) {
        toast.success(editCat ? 'ویرایش شد' : 'افزوده شد');
        setShowForm(false);
        setEditCat(null);
        fetchCategories();
      } else {
        toast.error(data.error || 'خطا');
      }
    } catch {}
  };

  const toggleActive = async (cat: any) => {
    try {
      await fetch(`/api/admin/categories/${cat.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !cat.isActive }),
      });
      fetchCategories();
    } catch {}
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await fetch(`/api/admin/categories/${deleteId}`, { method: 'DELETE' });
      toast.success('حذف شد');
      setDeleteId(null);
      fetchCategories();
    } catch {}
  };

  const openEdit = (cat: any) => {
    setEditCat(cat);
    setFormData({
      title: cat.title, icon: cat.icon, color: cat.color,
      description: cat.description || '', order: cat.order, isActive: cat.isActive,
    });
    setShowForm(true);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <FolderTree className="w-6 h-6 text-[#dc2626]" />
          مدیریت دسته‌بندی‌ها
        </h2>
        <Button onClick={() => { setEditCat(null); setFormData({ title: '', icon: '📦', color: '#dc2626', description: '', order: 0, isActive: true }); setShowForm(true); }} className="bg-[#dc2626] hover:bg-[#b91c1c]">
          <Plus className="w-4 h-4 ml-1" />
          دسته جدید
        </Button>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-sm text-blue-800">
        💡 این دسته‌بندی‌ها در کل سایت (هدر، فوتر، صفحه اصلی، فروشگاه) نمایش داده می‌شوند.
      </div>

      {loading ? (
        <div className="bg-white rounded-xl p-8 text-center">
          <Loader2 className="w-8 h-8 mx-auto animate-spin text-[#dc2626]" />
        </div>
      ) : categories.length === 0 ? (
        <div className="bg-white rounded-xl p-12 text-center">
          <FolderTree className="w-16 h-16 mx-auto mb-3 text-gray-300" />
          <p className="text-gray-500 mb-4">دسته‌بندی ثبت نشده</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {categories.map(cat => (
            <div key={cat.id} className={`bg-white rounded-xl p-4 border-2 ${cat.isActive ? 'border-gray-100' : 'border-gray-200 opacity-60'} shadow-sm`}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg flex items-center justify-center text-2xl" style={{ backgroundColor: `${cat.color}15` }}>
                    {cat.icon}
                  </div>
                  <div>
                    <h3 className="font-bold">{cat.title}</h3>
                    {cat.description && <p className="text-xs text-gray-500 line-clamp-1">{cat.description}</p>}
                    <p className="text-[10px] text-gray-400 mt-0.5">ترتیب: {cat.order}</p>
                  </div>
                </div>
                <Switch checked={cat.isActive} onCheckedChange={() => toggleActive(cat)} />
              </div>
              <div className="flex gap-1 pt-2 border-t border-gray-50">
                <Button variant="outline" size="sm" onClick={() => openEdit(cat)} className="flex-1 h-8 text-xs">
                  <Edit2 className="w-3 h-3 ml-1" /> ویرایش
                </Button>
                <Button variant="outline" size="sm" onClick={() => setDeleteId(cat.id)} className="h-8 text-xs text-red-600">
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* فرم */}
      {showForm && (
        <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg my-8 max-h-[90vh] overflow-y-auto">
            <div className="p-4 border-b border-gray-100 flex items-center justify-between sticky top-0 bg-white z-10">
              <h2 className="font-bold">{editCat ? 'ویرایش دسته' : 'دسته جدید'}</h2>
              <Button variant="ghost" size="icon" onClick={() => setShowForm(false)}><X className="w-5 h-5" /></Button>
            </div>
            <form onSubmit={handleSubmit} className="p-4 space-y-4">
              <div className="space-y-2">
                <Label>عنوان دسته‌بندی *</Label>
                <Input value={formData.title} onChange={e => setFormData({ ...formData, title: e.target.value })} placeholder="مثلا: اسباب‌بازی چوبی" required />
              </div>

              <div className="space-y-2">
                <Label>آیکون</Label>
                <div className="flex flex-wrap gap-1">
                  {iconOptions.map(ic => (
                    <button key={ic} type="button" onClick={() => setFormData({ ...formData, icon: ic })}
                      className={`w-10 h-10 rounded-lg text-xl flex items-center justify-center border-2 ${formData.icon === ic ? 'border-[#dc2626] bg-red-50' : 'border-gray-200'}`}>
                      {ic}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>رنگ</Label>
                  <div className="flex gap-2 items-center">
                    <input type="color" value={formData.color} onChange={e => setFormData({ ...formData, color: e.target.value })} className="w-12 h-10 rounded border border-gray-200 cursor-pointer" />
                    <Input value={formData.color} onChange={e => setFormData({ ...formData, color: e.target.value })} dir="ltr" className="flex-1" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>ترتیب نمایش</Label>
                  <Input type="number" value={formData.order} onChange={e => setFormData({ ...formData, order: parseInt(e.target.value) || 0 })} min="0" />
                </div>
              </div>

              <div className="space-y-2">
                <Label>توضیحات (اختیاری)</Label>
                <Textarea value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} rows={2} />
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <Label>فعال</Label>
                <Switch checked={formData.isActive} onCheckedChange={v => setFormData({ ...formData, isActive: v })} />
              </div>

              <div className="flex gap-2">
                <Button type="submit" className="flex-1 bg-[#dc2626] hover:bg-[#b91c1c]"><Save className="w-4 h-4 ml-1" />{editCat ? 'ذخیره' : 'افزودن'}</Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>انصراف</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <AlertDialog open={deleteId !== null} onOpenChange={o => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف دسته‌بندی</AlertDialogTitle>
            <AlertDialogDescription>آیا مطمئن هستید؟ محصولات این دسته بدون دسته می‌مانند.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">حذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
