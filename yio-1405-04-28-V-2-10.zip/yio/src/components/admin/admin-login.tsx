'use client';

import { useState } from 'react';
import { Lock, Eye, EyeOff, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import Image from 'next/image';
import { toast } from 'sonner';

interface AdminLoginProps {
  onSuccess: () => void;
  onCancel: () => void;
}

export function AdminLogin({ onSuccess, onCancel }: AdminLoginProps) {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });

      const data = await res.json();

      if (res.ok) {
        toast.success('ورود موفقیت‌آمیز بود');
        onSuccess();
      } else {
        toast.error(data.error || 'خطا در ورود');
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-gray-900/50 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8">
        {/* لوگو */}
        <div className="flex flex-col items-center mb-6">
          <div className="relative w-20 h-20 mb-3">
            <Image
              src="/yio-logo.png"
              alt="YIO"
              fill
              sizes="80px"
              className="object-contain rounded-xl"
            />
          </div>
          <h1 className="text-2xl font-bold text-[#dc2626]">پنل مدیریت YIO</h1>
          <p className="text-sm text-gray-500 mt-1">برای ورود رمز عبور را وارد کنید</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type={showPassword ? 'text' : 'password'}
              placeholder="رمز عبور"
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="pr-10 pl-10 h-12"
              required
              autoFocus
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>

          <Button
            type="submit"
            disabled={loading || !password}
            className="w-full h-12 bg-[#dc2626] hover:bg-[#b91c1c] text-white font-bold"
          >
            {loading ? 'در حال ورود...' : 'ورود'}
          </Button>

          <Button
            type="button"
            variant="ghost"
            onClick={onCancel}
            className="w-full"
          >
            <ArrowRight className="w-4 h-4 ml-1" />
            بازگشت به فروشگاه
          </Button>
        </form>

        <div className="mt-6 p-3 bg-amber-50 rounded-lg text-xs text-amber-800">
          <p className="font-bold mb-1">رمز عبور پیش‌فرض:</p>
          <code className="bg-white px-2 py-1 rounded">yio-admin-1403</code>
          <p className="mt-2">برای امنیت بیشتر، رمز را در فایل .env تغییر دهید.</p>
        </div>
      </div>
    </div>
  );
}
