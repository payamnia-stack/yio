'use client';

import { useState, useEffect } from 'react';
import {
  Plus, Edit2, Trash2, Ticket, Percent, Tag, Truck,
  CheckCircle, XCircle, Clock, Calendar,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { formatPrice, toFa } from '@/lib/shop-data';

const couponTypes: any = {
  percent: { label: 'درصدی', icon: Percent, color: 'bg-blue-50 text-blue-700' },
  fixed: { label: 'مبلغ ثابت', icon: Tag, color: 'bg-green-50 text-green-700' },
  free_shipping: { label: 'ارسال رایگان', icon: Truck, color: 'bg-purple-50 text-purple-700' },
};

interface Coupon {
  id: number;
  code: string;
  description?: string | null;
  type: string;
  value: number;
  minPurchase?: number | null;
  usageLimit?: number | null;
  usedCount: number;
  validFrom: string;
  validUntil: string;
  isActive: boolean;
  firstOrderOnly: boolean;
  _count?: { usedBy: number };
}

export function MobileCoupons() {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const fetchCoupons = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/coupons?pageSize=50');
      if (res.status === 401) return;
      const data = await res.json();
      setCoupons(data.coupons || []);
    } catch {
      toast.error('خطا در دریافت کوپن‌ها');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCoupons();
  }, []);

  const toggleActive = async (c: Coupon) => {
    try {
      await fetch(`/api/coupons/${c.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !c.isActive }),
      });
      fetchCoupons();
    } catch {}
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await fetch(`/api/coupons/${deleteId}`, { method: 'DELETE' });
      toast.success('حذف شد');
      setDeleteId(null);
      fetchCoupons();
    } catch {}
  };

  const formatDate = (s: string) => {
    try {
      return new Intl.DateTimeFormat('fa-IR', { month: 'short', day: 'numeric' }).format(new Date(s));
    } catch { return s; }
  };

  const formatValue = (c: Coupon) => {
    if (c.type === 'percent') return `${toFa(c.value)}٪ تخفیف`;
    if (c.type === 'fixed') return `${formatPrice(c.value)} ت تخفیف`;
    return 'ارسال رایگان';
  };

  const isExpired = (s: string) => new Date(s) < new Date();

  return (
    <div className="p-3 space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold">کوپن‌های تخفیف</h2>
        <Button size="sm" className="bg-[#dc2626] hover:bg-[#b91c1c]" onClick={() => toast.info('برای افزودن کامل، از حالت دسکتاپ استفاده کنید')}>
          <Plus className="w-4 h-4 ml-1" />
          جدید
        </Button>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-xs text-blue-800">
        💡 برای افزودن و ویرایش کامل کوپن‌ها، از کامپیوتر (حالت دسکتاپ) استفاده کنید. در موبایل فقط مشاهده و فعال/غیرفعال کردن ممکن است.
      </div>

      {loading ? (
        <div className="text-center py-8">
          <div className="inline-block w-6 h-6 border-3 border-gray-200 border-t-[#dc2626] rounded-full animate-spin"></div>
        </div>
      ) : coupons.length === 0 ? (
        <div className="text-center py-8 text-gray-500 text-sm">کوپنی ثبت نشده</div>
      ) : (
        <div className="space-y-2">
          {coupons.map(c => {
            const typeInfo = couponTypes[c.type] || couponTypes.percent;
            const Icon = typeInfo.icon;
            const expired = isExpired(c.validUntil);
            return (
              <div key={c.id} className={`bg-white rounded-xl p-3 border border-gray-100 shadow-sm ${!c.isActive ? 'opacity-60' : ''}`}>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <div className={`px-2 py-0.5 rounded ${typeInfo.color} flex items-center gap-1`}>
                      <Icon className="w-3 h-3" />
                      <span className="text-[10px]">{typeInfo.label}</span>
                    </div>
                    <code className="bg-gray-900 text-white px-2 py-0.5 rounded font-bold text-xs" dir="ltr">{c.code}</code>
                    {expired && <span className="text-[9px] text-red-600">منقضی</span>}
                  </div>
                  <Switch
                    checked={c.isActive}
                    onCheckedChange={() => toggleActive(c)}
                  />
                </div>

                <p className="font-bold text-sm text-[#dc2626] mb-1">{formatValue(c)}</p>

                {c.description && <p className="text-xs text-gray-600 mb-1 line-clamp-1">{c.description}</p>}

                <div className="flex items-center justify-between text-[10px] text-gray-500">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-2.5 h-2.5" />
                    {formatDate(c.validFrom)} - {formatDate(c.validUntil)}
                  </span>
                  <span className="fa-num">استفاده: {toFa(c.usedCount)}{c.usageLimit ? `/${toFa(c.usageLimit)}` : ''}</span>
                </div>

                <div className="flex gap-1 mt-2 pt-2 border-t border-gray-50">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => toast.info('ویرایش فقط در دسکتاپ')}
                    className="flex-1 h-7 text-[10px]"
                  >
                    <Edit2 className="w-2.5 h-2.5 ml-1" />
                    ویرایش
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setDeleteId(c.id)}
                    className="h-7 text-[10px] text-red-600"
                  >
                    <Trash2 className="w-2.5 h-2.5" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <AlertDialog open={deleteId !== null} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف کوپن</AlertDialogTitle>
            <AlertDialogDescription>آیا مطمئن هستید؟</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">حذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
