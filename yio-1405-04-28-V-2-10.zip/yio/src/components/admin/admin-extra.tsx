'use client';

import { useState, useEffect } from 'react';
import {
  Building2, MessageSquare, HelpCircle, Trash2, Phone, Mail,
  CheckCircle, Clock, XCircle, Package,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { toFa } from '@/lib/shop-data';
import { ResponsiveTabs } from './responsive-tabs';

type Section = 'wholesale' | 'contact' | 'faq';

export function AdminExtra() {
  const [section, setSection] = useState<Section>('wholesale');

  const subTabs = [
    { key: 'wholesale', label: 'سفارش‌های عمده', icon: Building2, short: 'عمده' },
    { key: 'contact', label: 'پیام‌های تماس', icon: MessageSquare, short: 'پیام‌ها' },
    { key: 'faq', label: 'سؤالات متداول', icon: HelpCircle, short: 'سؤالات' },
  ];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Building2 className="w-6 h-6 text-[#dc2626]" />
          سفارش‌های عمده و ارتباطات
        </h2>
      </div>

      {/* زیرتب‌های responsive */}
      <ResponsiveTabs
        tabs={subTabs}
        activeTab={section}
        onTabChange={(k) => setSection(k as Section)}
        variant="subsection"
        maxVisible={3}
      />

      {section === 'wholesale' && <WholesaleSection />}
      {section === 'contact' && <ContactSection />}
      {section === 'faq' && <FAQSection />}
    </div>
  );
}

// === سفارش‌های عمده ===
const wholesaleStatuses = [
  { value: 'pending', label: 'در انتظار', color: 'bg-amber-100 text-amber-700', icon: Clock },
  { value: 'contacted', label: 'تماس گرفته شد', color: 'bg-blue-100 text-blue-700', icon: Phone },
  { value: 'approved', label: 'تأیید شد', color: 'bg-green-100 text-green-700', icon: CheckCircle },
  { value: 'rejected', label: 'رد شد', color: 'bg-red-100 text-red-700', icon: XCircle },
];

function WholesaleSection() {
  const [orders, setOrders] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<any>(null);

  const fetchOrders = async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (statusFilter !== 'all') params.set('status', statusFilter);
    try {
      const res = await fetch(`/api/admin/wholesale?${params}`);
      if (!res.ok) return;
      const data = await res.json();
      setOrders(data.orders || []);
      setStats(data.stats);
    } catch {}
    setLoading(false);
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { fetchOrders(); }, [statusFilter]);

  const updateStatus = async (id: number, status: string) => {
    try {
      await fetch(`/api/admin/wholesale/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      toast.success('وضعیت به‌روزرسانی شد');
      fetchOrders();
      if (selectedOrder?.id === id) setSelectedOrder({ ...selectedOrder, status });
    } catch {}
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await fetch(`/api/admin/wholesale/${deleteId}`, { method: 'DELETE' });
      toast.success('حذف شد');
      setDeleteId(null);
      fetchOrders();
    } catch {}
  };

  const getStatusInfo = (s: string) => wholesaleStatuses.find(st => st.value === s) || wholesaleStatuses[0];

  return (
    <div className="space-y-3">
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {[
            { label: 'کل', value: stats.total, color: 'bg-blue-50 text-blue-600' },
            { label: 'در انتظار', value: stats.pending, color: 'bg-amber-50 text-amber-600' },
            { label: 'تماس گرفته شد', value: stats.contacted, color: 'bg-purple-50 text-purple-600' },
            { label: 'تأیید شد', value: stats.approved, color: 'bg-green-50 text-green-600' },
          ].map((c, i) => (
            <div key={i} className="bg-white rounded-lg p-3 border border-gray-100">
              <p className="text-xs text-gray-500">{c.label}</p>
              <p className={`text-xl font-bold fa-num ${c.color.split(' ')[1]}`}>{toFa(c.value)}</p>
            </div>
          ))}
        </div>
      )}

      <div className="bg-white rounded-xl p-3 shadow-sm">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه وضعیت‌ها</SelectItem>
            {wholesaleStatuses.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white rounded-xl shadow-sm divide-y divide-gray-100">
        {loading ? (
          <div className="p-8 text-center"><div className="inline-block w-8 h-8 border-4 border-gray-200 border-t-[#dc2626] rounded-full animate-spin"></div></div>
        ) : orders.length === 0 ? (
          <div className="p-8 text-center text-gray-500">سفارش عمده‌ای ثبت نشده</div>
        ) : (
          orders.map(o => {
            const si = getStatusInfo(o.status);
            const Icon = si.icon;
            return (
              <div key={o.id} className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <h3 className="font-bold">{o.companyName}</h3>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${si.color} flex items-center gap-1`}>
                        <Icon className="w-3 h-3" /> {si.label}
                      </span>
                    </div>
                    <div className="text-sm text-gray-600 space-y-0.5">
                      <p className="flex items-center gap-2"><span>👤 {o.contactPerson}</span><span dir="ltr">📱 {o.phone}</span></p>
                      <p>📍 {o.city} | 📦 {o.productCategory} | 🔢 <span className="fa-num">{toFa(o.quantity)} عدد</span></p>
                      {o.email && <p className="flex items-center gap-1"><Mail className="w-3 h-3" /> {o.email}</p>}
                      {o.description && <p className="text-xs text-gray-500 mt-1">💬 {o.description}</p>}
                    </div>
                  </div>
                  <div className="flex flex-col gap-1 shrink-0">
                    <Select value={o.status} onValueChange={v => updateStatus(o.id, v)}>
                      <SelectTrigger className="w-32 h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {wholesaleStatuses.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    <Button variant="outline" size="sm" onClick={() => setDeleteId(o.id)} className="h-7 text-xs text-red-600">
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      <AlertDialog open={deleteId !== null} onOpenChange={o => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف درخواست</AlertDialogTitle>
            <AlertDialogDescription>آیا مطمئن هستید؟</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">حذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// === پیام‌های تماس ===
const contactStatuses = [
  { value: 'new', label: 'جدید', color: 'bg-blue-100 text-blue-700' },
  { value: 'read', label: 'خوانده شده', color: 'bg-gray-100 text-gray-700' },
  { value: 'replied', label: 'پاسخ داده شده', color: 'bg-green-100 text-green-700' },
  { value: 'closed', label: 'بسته شد', color: 'bg-gray-100 text-gray-500' },
];

function ContactSection() {
  const [messages, setMessages] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedMsg, setSelectedMsg] = useState<any>(null);
  const [reply, setReply] = useState('');
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const fetchMessages = async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (statusFilter !== 'all') params.set('status', statusFilter);
    try {
      const res = await fetch(`/api/admin/contact?${params}`);
      if (!res.ok) return;
      const data = await res.json();
      setMessages(data.messages || []);
      setStats(data.stats);
    } catch {}
    setLoading(false);
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { fetchMessages(); }, [statusFilter]);

  const updateStatus = async (id: number, status: string) => {
    try {
      await fetch(`/api/admin/contact/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      fetchMessages();
    } catch {}
  };

  const sendReply = async () => {
    if (!selectedMsg || !reply.trim()) return;
    try {
      await fetch(`/api/admin/contact/${selectedMsg.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reply, status: 'replied' }),
      });
      toast.success('پاسخ ثبت شد');
      setReply('');
      setSelectedMsg(null);
      fetchMessages();
    } catch {}
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await fetch(`/api/admin/contact/${deleteId}`, { method: 'DELETE' });
      toast.success('حذف شد');
      setDeleteId(null);
      fetchMessages();
    } catch {}
  };

  const getStatusInfo = (s: string) => contactStatuses.find(st => st.value === s) || contactStatuses[0];

  return (
    <div className="space-y-3">
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {[
            { label: 'کل', value: stats.total, color: 'text-blue-600' },
            { label: 'جدید', value: stats.new, color: 'text-amber-600' },
            { label: 'خوانده شده', value: stats.read, color: 'text-gray-600' },
            { label: 'پاسخ داده شده', value: stats.replied, color: 'text-green-600' },
          ].map((c, i) => (
            <div key={i} className="bg-white rounded-lg p-3 border border-gray-100">
              <p className="text-xs text-gray-500">{c.label}</p>
              <p className={`text-xl font-bold fa-num ${c.color}`}>{toFa(c.value)}</p>
            </div>
          ))}
        </div>
      )}

      <div className="bg-white rounded-xl p-3 shadow-sm">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه وضعیت‌ها</SelectItem>
            {contactStatuses.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="bg-white rounded-xl shadow-sm divide-y divide-gray-100">
        {loading ? (
          <div className="p-8 text-center"><div className="inline-block w-8 h-8 border-4 border-gray-200 border-t-[#dc2626] rounded-full animate-spin"></div></div>
        ) : messages.length === 0 ? (
          <div className="p-8 text-center text-gray-500">پیامی ثبت نشده</div>
        ) : (
          messages.map(m => {
            const si = getStatusInfo(m.status);
            return (
              <div key={m.id} className={`p-4 ${m.status === 'new' ? 'bg-blue-50/30' : ''}`}>
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <h3 className="font-bold text-sm">{m.subject}</h3>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${si.color}`}>{si.label}</span>
                    </div>
                    <p className="text-xs text-gray-600 mb-1">
                      از <strong>{m.name}</strong> | <span dir="ltr">{m.phone}</span>
                      {m.email && <> | <span dir="ltr">{m.email}</span></>}
                    </p>
                    <p className="text-sm text-gray-700 line-clamp-2">{m.message}</p>
                  </div>
                  <div className="flex flex-col gap-1 shrink-0">
                    <Button variant="outline" size="sm" onClick={() => { setSelectedMsg(m); setReply(m.reply || ''); if (m.status === 'new') updateStatus(m.id, 'read'); }} className="h-7 text-xs">
                      مشاهده و پاسخ
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setDeleteId(m.id)} className="h-7 text-xs text-red-600">
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {selectedMsg && (
        <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto">
            <div className="p-4 border-b border-gray-100 flex items-center justify-between">
              <h2 className="font-bold">{selectedMsg.subject}</h2>
              <Button variant="ghost" size="icon" onClick={() => setSelectedMsg(null)}>✕</Button>
            </div>
            <div className="p-4 space-y-3">
              <div className="bg-gray-50 rounded-lg p-3 text-sm">
                <p className="text-xs text-gray-500 mb-1">از: <strong>{selectedMsg.name}</strong> | <span dir="ltr">{selectedMsg.phone}</span></p>
                <p className="leading-6">{selectedMsg.message}</p>
              </div>
              <div className="space-y-2">
                <Label>پاسخ شما (برای ثبت در سیستم):</Label>
                <Textarea value={reply} onChange={e => setReply(e.target.value)} rows={4} placeholder="پاسخ خود را وارد کنید..." />
              </div>
              <div className="flex gap-2">
                <Button onClick={sendReply} disabled={!reply.trim()} className="flex-1 bg-[#dc2626] hover:bg-[#b91c1c]">
                  ثبت پاسخ
                </Button>
                <Button variant="outline" onClick={() => updateStatus(selectedMsg.id, 'closed')}>بستن تیکت</Button>
              </div>
            </div>
          </div>
        </div>
      )}

      <AlertDialog open={deleteId !== null} onOpenChange={o => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف پیام</AlertDialogTitle>
            <AlertDialogDescription>آیا مطمئن هستید؟</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">حذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// === سؤالات متداول ===
const faqCategories = [
  { value: 'general', label: 'عمومی' },
  { value: 'products', label: 'محصولات' },
  { value: 'shipping', label: 'ارسال' },
  { value: 'payment', label: 'پرداخت' },
  { value: 'returns', label: 'بازگشت کالا' },
];

function FAQSection() {
  const [faqs, setFaqs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editFaq, setEditFaq] = useState<any>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const [formData, setFormData] = useState({
    question: '', answer: '', category: 'general', order: 0, isActive: true,
  });

  const fetchFaqs = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/faq');
      if (res.ok) {
        const data = await res.json();
        setFaqs(data.faqs || []);
      } else {
        // fallback به مسیر عمومی
        const res2 = await fetch('/api/faq');
        const data2 = await res2.json();
        setFaqs(data2.faqs || []);
      }
    } catch {}
    setLoading(false);
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { fetchFaqs(); }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.question.trim().length < 5 || formData.answer.trim().length < 10) {
      toast.error('سؤال و پاسخ را کامل وارد کنید');
      return;
    }
    try {
      const url = editFaq ? `/api/admin/faq/${editFaq.id}` : '/api/admin/faq';
      const method = editFaq ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (res.ok) {
        toast.success(editFaq ? 'ویرایش شد' : 'افزوده شد');
        setShowForm(false);
        setEditFaq(null);
        fetchFaqs();
      } else {
        toast.error(data.error || 'خطا');
      }
    } catch {}
  };

  const toggleActive = async (faq: any) => {
    try {
      await fetch(`/api/admin/faq/${faq.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !faq.isActive }),
      });
      fetchFaqs();
    } catch {}
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await fetch(`/api/admin/faq/${deleteId}`, { method: 'DELETE' });
      toast.success('حذف شد');
      setDeleteId(null);
      fetchFaqs();
    } catch {}
  };

  return (
    <div className="space-y-3">
      <div className="flex justify-end">
        <Button onClick={() => { setEditFaq(null); setFormData({ question: '', answer: '', category: 'general', order: 0, isActive: true }); setShowForm(true); }} className="bg-[#dc2626] hover:bg-[#b91c1c]">
          <HelpCircle className="w-4 h-4 ml-1" />
          سؤال جدید
        </Button>
      </div>

      <div className="bg-white rounded-xl shadow-sm divide-y divide-gray-100">
        {loading ? (
          <div className="p-8 text-center"><div className="inline-block w-8 h-8 border-4 border-gray-200 border-t-[#dc2626] rounded-full animate-spin"></div></div>
        ) : faqs.length === 0 ? (
          <div className="p-8 text-center text-gray-500">سؤالی ثبت نشده</div>
        ) : (
          faqs.map(f => (
            <div key={f.id} className={`p-4 ${!f.isActive ? 'opacity-60' : ''}`}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs bg-gray-100 px-2 py-0.5 rounded">{faqCategories.find(c => c.value === f.category)?.label || f.category}</span>
                    <span className="text-xs text-gray-400">ترتیب: <span className="fa-num">{toFa(f.order)}</span></span>
                  </div>
                  <p className="font-bold text-sm mb-1">{f.question}</p>
                  <p className="text-xs text-gray-600 line-clamp-2">{f.answer}</p>
                </div>
                <div className="flex flex-col gap-1 shrink-0">
                  <Button variant="outline" size="sm" onClick={() => { setEditFaq(f); setFormData({ question: f.question, answer: f.answer, category: f.category, order: f.order, isActive: f.isActive }); setShowForm(true); }} className="h-7 text-xs">ویرایش</Button>
                  <Button variant="outline" size="sm" onClick={() => toggleActive(f)} className="h-7 text-xs">{f.isActive ? 'غیرفعال' : 'فعال'}</Button>
                  <Button variant="outline" size="sm" onClick={() => setDeleteId(f.id)} className="h-7 text-xs text-red-600"><Trash2 className="w-3 h-3" /></Button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-xl max-h-[90vh] overflow-y-auto">
            <div className="p-4 border-b border-gray-100 flex items-center justify-between">
              <h2 className="font-bold">{editFaq ? 'ویرایش سؤال' : 'سؤال جدید'}</h2>
              <Button variant="ghost" size="icon" onClick={() => setShowForm(false)}>✕</Button>
            </div>
            <form onSubmit={handleSubmit} className="p-4 space-y-3">
              <div className="space-y-2">
                <Label>سؤال *</Label>
                <Input value={formData.question} onChange={e => setFormData({ ...formData, question: e.target.value })} required />
              </div>
              <div className="space-y-2">
                <Label>پاسخ *</Label>
                <Textarea value={formData.answer} onChange={e => setFormData({ ...formData, answer: e.target.value })} rows={4} required />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>دسته‌بندی</Label>
                  <Select value={formData.category} onValueChange={v => setFormData({ ...formData, category: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {faqCategories.map(c => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>ترتیب نمایش</Label>
                  <Input type="number" value={formData.order} onChange={e => setFormData({ ...formData, order: parseInt(e.target.value) || 0 })} />
                </div>
              </div>
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <Label>فعال</Label>
                <Switch checked={formData.isActive} onCheckedChange={v => setFormData({ ...formData, isActive: v })} />
              </div>
              <div className="flex gap-2">
                <Button type="submit" className="flex-1 bg-[#dc2626] hover:bg-[#b91c1c]">{editFaq ? 'ذخیره' : 'افزودن'}</Button>
                <Button type="button" variant="outline" onClick={() => setShowForm(false)}>انصراف</Button>
              </div>
            </form>
          </div>
        </div>
      )}

      <AlertDialog open={deleteId !== null} onOpenChange={o => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف سؤال</AlertDialogTitle>
            <AlertDialogDescription>آیا مطمئن هستید؟</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">حذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
