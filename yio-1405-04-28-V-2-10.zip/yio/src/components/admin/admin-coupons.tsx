'use client';

import { useState, useEffect } from 'react';
import {
  Plus, Edit2, Trash2, Ticket, Percent, Tag, Truck, X, Save,
  CheckCircle, XCircle, Clock, TrendingUp, Users, Calendar,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { formatPrice, toFa } from '@/lib/shop-data';

interface Coupon {
  id: number;
  code: string;
  description?: string | null;
  type: string;
  value: number;
  minPurchase?: number | null;
  maxDiscount?: number | null;
  usageLimit?: number | null;
  usedCount: number;
  perUserLimit: number;
  validFrom: string;
  validUntil: string;
  isActive: boolean;
  firstOrderOnly: boolean;
  _count?: { usedBy: number };
}

const couponTypes = [
  { value: 'percent', label: 'درصدی', icon: Percent, color: 'bg-blue-50 text-blue-700' },
  { value: 'fixed', label: 'مبلغ ثابت', icon: Tag, color: 'bg-green-50 text-green-700' },
  { value: 'free_shipping', label: 'ارسال رایگان', icon: Truck, color: 'bg-purple-50 text-purple-700' },
];

export function AdminCoupons() {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [showForm, setShowForm] = useState(false);
  const [editCoupon, setEditCoupon] = useState<Coupon | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const fetchCoupons = async () => {
    setLoading(true);
    const params = new URLSearchParams({ search, pageSize: '50' });
    if (filter !== 'all') params.set('isActive', filter);

    try {
      const res = await fetch(`/api/coupons?${params}`);
      if (res.status === 401) {
        toast.error('سشن منقضی شده');
        return;
      }
      const data = await res.json();
      setCoupons(data.coupons || []);
      setStats(data.stats);
    } catch {
      toast.error('خطا در دریافت کوپن‌ها');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const t = setTimeout(fetchCoupons, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, filter]);

  const handleToggleActive = async (coupon: Coupon) => {
    try {
      const res = await fetch(`/api/coupons/${coupon.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !coupon.isActive }),
      });
      if (res.ok) {
        toast.success(coupon.isActive ? 'غیرفعال شد' : 'فعال شد');
        fetchCoupons();
      }
    } catch {
      toast.error('خطا در تغییر وضعیت');
    }
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      const res = await fetch(`/api/coupons/${deleteId}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('حذف شد');
        setDeleteId(null);
        fetchCoupons();
      }
    } catch {
      toast.error('خطا در حذف');
    }
  };

  const getTypeInfo = (type: string) => couponTypes.find(t => t.value === type) || couponTypes[0];

  const formatDate = (dateStr: string) => {
    try {
      return new Intl.DateTimeFormat('fa-IR', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      }).format(new Date(dateStr));
    } catch {
      return dateStr;
    }
  };

  const isExpired = (dateStr: string) => new Date(dateStr) < new Date();
  const isNotStarted = (dateStr: string) => new Date(dateStr) > new Date();

  const formatValue = (coupon: Coupon) => {
    switch (coupon.type) {
      case 'percent':
        return `${toFa(coupon.value)}٪`;
      case 'fixed':
        return `${formatPrice(coupon.value)} ت`;
      case 'free_shipping':
        return 'ارسال رایگان';
      default:
        return '';
    }
  };

  const statsCards = stats ? [
    { title: 'کل کوپن‌ها', value: toFa(stats.total), icon: Ticket, color: 'bg-blue-50 text-blue-600' },
    { title: 'فعال', value: toFa(stats.active), icon: CheckCircle, color: 'bg-green-50 text-green-600' },
    { title: 'منقضی شده', value: toFa(stats.expired), icon: XCircle, color: 'bg-red-50 text-red-600' },
    { title: 'کل استفاده', value: toFa(stats.totalUsage), icon: Users, color: 'bg-purple-50 text-purple-600' },
  ] : [];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Ticket className="w-6 h-6 text-[#dc2626]" />
          مدیریت تخفیف‌ها و کوپن‌ها
        </h2>
        <Button
          onClick={() => { setEditCoupon(null); setShowForm(true); }}
          className="bg-[#dc2626] hover:bg-[#b91c1c]"
        >
          <Plus className="w-4 h-4 ml-1" />
          کوپن جدید
        </Button>
      </div>

      {/* آمار */}
      {stats && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {statsCards.map((card, idx) => {
              const Icon = card.icon;
              return (
                <div key={idx} className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
                  <div className={`w-10 h-10 rounded-lg ${card.color} flex items-center justify-center mb-2`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <p className="text-xs text-gray-500 mb-1">{card.title}</p>
                  <p className="text-2xl font-bold fa-num">{card.value}</p>
                </div>
              );
            })}
          </div>

          <div className="bg-gradient-to-l from-[#dc2626] to-[#991b1b] rounded-xl p-4 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90 mb-1">کل تخفیف اعطا شده</p>
                <p className="text-xl font-bold fa-num">
                  {formatPrice(stats.totalDiscount._sum.discountAmount || 0)} تومان
                </p>
              </div>
              <TrendingUp className="w-10 h-10 opacity-30" />
            </div>
          </div>
        </>
      )}

      {/* فیلتر و جستجو */}
      <div className="bg-white rounded-xl p-4 shadow-sm">
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Input
              type="text"
              placeholder="جستجو در کد یا توضیحات..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pr-4"
            />
          </div>
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-full md:w-44">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">همه</SelectItem>
              <SelectItem value="true">فقط فعال</SelectItem>
              <SelectItem value="false">فقط غیرفعال</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* لیست کوپن‌ها */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-8 text-center">
            <div className="inline-block w-8 h-8 border-4 border-gray-200 border-t-[#dc2626] rounded-full animate-spin"></div>
          </div>
        ) : coupons.length === 0 ? (
          <div className="p-12 text-center">
            <Ticket className="w-16 h-16 mx-auto text-gray-300 mb-3" />
            <p className="text-gray-500 mb-4">هیچ کوپنی ثبت نشده</p>
            <Button
              onClick={() => { setEditCoupon(null); setShowForm(true); }}
              className="bg-[#dc2626] hover:bg-[#b91c1c]"
            >
              <Plus className="w-4 h-4 ml-1" />
              افزودن اولین کوپن
            </Button>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {coupons.map(coupon => {
              const typeInfo = getTypeInfo(coupon.type);
              const TypeIcon = typeInfo.icon;
              const expired = isExpired(coupon.validUntil);
              const notStarted = isNotStarted(coupon.validFrom);
              const usagePercent = coupon.usageLimit
                ? Math.min(100, (coupon.usedCount / coupon.usageLimit) * 100)
                : 0;

              return (
                <div key={coupon.id} className={`p-4 hover:bg-gray-50 transition-colors ${!coupon.isActive ? 'opacity-60' : ''}`}>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2 flex-wrap">
                        <div className={`px-2 py-1 rounded-lg ${typeInfo.color} flex items-center gap-1`}>
                          <TypeIcon className="w-3.5 h-3.5" />
                          <span className="text-xs font-medium">{typeInfo.label}</span>
                        </div>
                        <code className="bg-gray-900 text-white px-3 py-1 rounded-lg font-bold text-sm" dir="ltr">
                          {coupon.code}
                        </code>
                        <span className="text-base font-bold text-[#dc2626]">
                          {formatValue(coupon)}
                        </span>
                        {coupon.firstOrderOnly && (
                          <span className="bg-amber-50 text-amber-700 text-[10px] px-2 py-0.5 rounded">
                            اولین سفارش
                          </span>
                        )}
                        {expired && (
                          <span className="bg-red-50 text-red-700 text-[10px] px-2 py-0.5 rounded flex items-center gap-1">
                            <XCircle className="w-3 h-3" />
                            منقضی
                          </span>
                        )}
                        {notStarted && !expired && (
                          <span className="bg-blue-50 text-blue-700 text-[10px] px-2 py-0.5 rounded flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            پیش‌رو
                          </span>
                        )}
                      </div>

                      {coupon.description && (
                        <p className="text-sm text-gray-600 mb-2 line-clamp-1">{coupon.description}</p>
                      )}

                      <div className="flex items-center gap-3 text-xs text-gray-500 mb-2 flex-wrap">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {formatDate(coupon.validFrom)} تا {formatDate(coupon.validUntil)}
                        </span>
                        {coupon.minPurchase && (
                          <span>حداقل خرید: {formatPrice(coupon.minPurchase)} ت</span>
                        )}
                        {coupon.maxDiscount && coupon.type === 'percent' && (
                          <span>حداکثر تخفیف: {formatPrice(coupon.maxDiscount)} ت</span>
                        )}
                      </div>

                      {/* نوار استفاده */}
                      <div className="flex items-center gap-2 text-xs">
                        <span className="text-gray-500">
                          استفاده: <span className="fa-num font-bold">{toFa(coupon.usedCount)}</span>
                          {coupon.usageLimit && <> از <span className="fa-num">{toFa(coupon.usageLimit)}</span></>}
                        </span>
                        {coupon.usageLimit && (
                          <div className="flex-1 max-w-32 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full ${usagePercent >= 90 ? 'bg-red-500' : 'bg-[#dc2626]'}`}
                              style={{ width: `${usagePercent}%` }}
                            />
                          </div>
                        )}
                        <span className="text-gray-400 fa-num">({toFa(coupon._count?.usedBy || 0)} رکورد)</span>
                      </div>
                    </div>

                    <div className="flex flex-col gap-1 shrink-0">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => { setEditCoupon(coupon); setShowForm(true); }}
                        className="h-8 text-xs"
                      >
                        <Edit2 className="w-3 h-3 ml-1" />
                        ویرایش
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleToggleActive(coupon)}
                        className="h-8 text-xs"
                      >
                        {coupon.isActive ? 'غیرفعال' : 'فعال'}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setDeleteId(coupon.id)}
                        className="h-8 text-xs text-red-600"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* فرم افزودن/ویرایش */}
      {showForm && (
        <CouponForm
          coupon={editCoupon}
          onSave={() => {
            setShowForm(false);
            setEditCoupon(null);
            fetchCoupons();
          }}
          onCancel={() => {
            setShowForm(false);
            setEditCoupon(null);
          }}
        />
      )}

      <AlertDialog open={deleteId !== null} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف کوپن</AlertDialogTitle>
            <AlertDialogDescription>
              آیا مطمئن هستید؟ این کوپن حذف می‌شود و تاریخچه استفاده آن نیز پاک خواهد شد.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// === فرم افزودن/ویرایش کوپن ===
function CouponForm({
  coupon,
  onSave,
  onCancel,
}: {
  coupon: Coupon | null;
  onSave: () => void;
  onCancel: () => void;
}) {
  const [loading, setLoading] = useState(false);

  // تبدیل تاریخ به فرمت datetime-local
  const toDateInput = (date: Date | string) => {
    const d = new Date(date);
    const offset = d.getTimezoneOffset();
    const local = new Date(d.getTime() - offset * 60000);
    return local.toISOString().slice(0, 16);
  };

  const now = new Date();
  const nextMonth = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

  const [formData, setFormData] = useState({
    code: '',
    description: '',
    type: 'percent',
    value: '10',
    minPurchase: '',
    maxDiscount: '',
    usageLimit: '',
    perUserLimit: '1',
    validFrom: toDateInput(now),
    validUntil: toDateInput(nextMonth),
    isActive: true,
    firstOrderOnly: false,
  });

  useEffect(() => {
    if (coupon) {
      setFormData({
        code: coupon.code,
        description: coupon.description || '',
        type: coupon.type,
        value: String(coupon.value),
        minPurchase: coupon.minPurchase ? String(coupon.minPurchase) : '',
        maxDiscount: coupon.maxDiscount ? String(coupon.maxDiscount) : '',
        usageLimit: coupon.usageLimit ? String(coupon.usageLimit) : '',
        perUserLimit: String(coupon.perUserLimit),
        validFrom: toDateInput(coupon.validFrom),
        validUntil: toDateInput(coupon.validUntil),
        isActive: coupon.isActive,
        firstOrderOnly: coupon.firstOrderOnly,
      });
    }
  }, [coupon]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const code = formData.code.trim().toUpperCase();
    if (code.length < 3 || code.length > 30) {
      toast.error('کد کوپن باید بین ۳ تا ۳۰ کاراکتر باشد');
      return;
    }
    if (!/^[A-Z0-9\-_]+$/.test(code)) {
      toast.error('کد فقط می‌تواند شامل حروف بزرگ، عدد، خط تیره و زیرخط باشد');
      return;
    }

    if (formData.type !== 'free_shipping') {
      const val = parseInt(formData.value);
      if (isNaN(val) || val < 1) {
        toast.error('مقدار تخفیف نامعتبر است');
        return;
      }
      if (formData.type === 'percent' && val > 90) {
        toast.error('درصد تخفیف نمی‌تواند بیشتر از ۹۰ باشد');
        return;
      }
    }

    setLoading(true);

    try {
      const url = coupon ? `/api/coupons/${coupon.id}` : '/api/coupons';
      const method = coupon ? 'PUT' : 'POST';

      const payload = {
        ...formData,
        code,
        value: formData.type === 'free_shipping' ? 0 : parseInt(formData.value),
        minPurchase: formData.minPurchase ? parseInt(formData.minPurchase) : null,
        maxDiscount: formData.maxDiscount ? parseInt(formData.maxDiscount) : null,
        usageLimit: formData.usageLimit ? parseInt(formData.usageLimit) : null,
        perUserLimit: parseInt(formData.perUserLimit),
      };

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (res.ok) {
        toast.success(coupon ? 'ویرایش شد' : 'کوپن ایجاد شد');
        onSave();
      } else {
        toast.error(data.error || 'خطا');
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  };

  const generateRandomCode = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = 'YIO-';
    for (let i = 0; i < 6; i++) {
      code += chars[Math.floor(Math.random() * chars.length)];
    }
    setFormData({ ...formData, code });
  };

  return (
    <div className="fixed inset-0 z-50 bg-gray-900/50 backdrop-blur-sm flex items-center justify-center p-2 md:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl my-8 max-h-[95vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-100 p-4 flex items-center justify-between z-10">
          <h2 className="text-lg font-bold">
            {coupon ? 'ویرایش کوپن' : 'افزودن کوپن جدید'}
          </h2>
          <Button variant="ghost" size="icon" onClick={onCancel}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 md:p-6 space-y-4">
          {/* نوع تخفیف */}
          <div className="space-y-2">
            <Label>نوع تخفیف *</Label>
            <div className="grid grid-cols-3 gap-2">
              {couponTypes.map(t => {
                const Icon = t.icon;
                return (
                  <button
                    key={t.value}
                    type="button"
                    onClick={() => setFormData({ ...formData, type: t.value })}
                    className={`flex flex-col items-center gap-1 p-3 rounded-lg border-2 transition-all ${
                      formData.type === t.value
                        ? 'border-[#dc2626] bg-red-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <Icon className={`w-6 h-6 ${formData.type === t.value ? 'text-[#dc2626]' : 'text-gray-500'}`} />
                    <span className="text-xs font-medium">{t.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* کد کوپن */}
          <div className="space-y-2">
            <Label htmlFor="code">کد کوپن *</Label>
            <div className="flex gap-2">
              <Input
                id="code"
                value={formData.code}
                onChange={e => setFormData({ ...formData, code: e.target.value.toUpperCase() })}
                placeholder="مثلا: YIO20 یا WINTER1403"
                dir="ltr"
                className="font-bold text-center text-lg"
                required
              />
              <Button type="button" variant="outline" onClick={generateRandomCode}>
                تصادفی
              </Button>
            </div>
            <p className="text-xs text-gray-500">فقط حروف بزرگ انگلیسی، عدد، خط تیره (-) و زیرخط (_)</p>
          </div>

          {/* مقدار تخفیف */}
          {formData.type !== 'free_shipping' && (
            <div className="space-y-2">
              <Label htmlFor="value">
                {formData.type === 'percent' ? 'درصد تخفیف (۱ تا ۹۰) *' : 'مبلغ تخفیف (تومان) *'}
              </Label>
              <Input
                id="value"
                type="number"
                value={formData.value}
                onChange={e => setFormData({ ...formData, value: e.target.value })}
                min={formData.type === 'percent' ? '1' : '1000'}
                max={formData.type === 'percent' ? '90' : undefined}
                required
              />
            </div>
          )}

          {/* توضیحات */}
          <div className="space-y-2">
            <Label htmlFor="description">توضیحات (اختیاری)</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={e => setFormData({ ...formData, description: e.target.value })}
              placeholder="مثلا: تخفیف ویژه نوروز ۱۴۰۳"
              rows={2}
            />
          </div>

          {/* حداقل خرید و حداکثر تخفیف */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="minPurchase">حداقل مبلغ خرید (تومان)</Label>
              <Input
                id="minPurchase"
                type="number"
                value={formData.minPurchase}
                onChange={e => setFormData({ ...formData, minPurchase: e.target.value })}
                placeholder="مثلا: 500000"
                min="0"
              />
            </div>
            {formData.type === 'percent' && (
              <div className="space-y-2">
                <Label htmlFor="maxDiscount">حداکثر مبلغ تخفیف (تومان)</Label>
                <Input
                  id="maxDiscount"
                  type="number"
                  value={formData.maxDiscount}
                  onChange={e => setFormData({ ...formData, maxDiscount: e.target.value })}
                  placeholder="مثلا: 100000"
                  min="0"
                />
              </div>
            )}
          </div>

          {/* سقف استفاده */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="usageLimit">حداکثر تعداد استفاده (کل)</Label>
              <Input
                id="usageLimit"
                type="number"
                value={formData.usageLimit}
                onChange={e => setFormData({ ...formData, usageLimit: e.target.value })}
                placeholder="خالی = نامحدود"
                min="1"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="perUserLimit">حداکثر استفاده برای هر کاربر</Label>
              <Input
                id="perUserLimit"
                type="number"
                value={formData.perUserLimit}
                onChange={e => setFormData({ ...formData, perUserLimit: e.target.value })}
                min="1"
                max="100"
                required
              />
            </div>
          </div>

          {/* تاریخ‌ها */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="validFrom">تاریخ شروع *</Label>
              <Input
                id="validFrom"
                type="datetime-local"
                value={formData.validFrom}
                onChange={e => setFormData({ ...formData, validFrom: e.target.value })}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="validUntil">تاریخ پایان *</Label>
              <Input
                id="validUntil"
                type="datetime-local"
                value={formData.validUntil}
                onChange={e => setFormData({ ...formData, validUntil: e.target.value })}
                required
              />
            </div>
          </div>

          {/* سوئیچ‌ها */}
          <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center justify-between">
              <Label htmlFor="isActive" className="cursor-pointer">فعال</Label>
              <Switch
                id="isActive"
                checked={formData.isActive}
                onCheckedChange={v => setFormData({ ...formData, isActive: v })}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="firstOrderOnly" className="cursor-pointer">فقط اولین سفارش</Label>
              <Switch
                id="firstOrderOnly"
                checked={formData.firstOrderOnly}
                onCheckedChange={v => setFormData({ ...formData, firstOrderOnly: v })}
              />
            </div>
          </div>

          {/* پیش‌نمایش */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm">
            <p className="font-bold text-blue-800 mb-1">پیش‌نمایش:</p>
            <p className="text-blue-700">
              با کد <code className="bg-white px-2 py-0.5 rounded font-bold" dir="ltr">{formData.code || '???'}</code>{' '}
              {formData.type === 'percent' && `دریافت ${toFa(formData.value || '0')}٪ تخفیف`}
              {formData.type === 'fixed' && `دریافت ${formatPrice(parseInt(formData.value) || 0)} تومان تخفیف`}
              {formData.type === 'free_shipping' && 'ارسال رایگان'}
            </p>
          </div>

          {/* دکمه‌ها */}
          <div className="flex gap-3">
            <Button
              type="submit"
              disabled={loading}
              className="flex-1 bg-[#dc2626] hover:bg-[#b91c1c] h-12"
            >
              <Save className="w-4 h-4 ml-2" />
              {loading ? 'در حال ذخیره...' : (coupon ? 'ذخیره تغییرات' : 'افزودن کوپن')}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              className="h-12 px-6"
            >
              انصراف
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
