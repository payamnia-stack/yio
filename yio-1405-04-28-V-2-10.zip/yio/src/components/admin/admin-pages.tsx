'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import {
  Plus, Edit2, Trash2, X, Save, Layout, Eye, EyeOff, Loader2,
  GripVertical, Copy, Monitor, Smartphone, ArrowRight, Settings,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { ImageUploader } from './image-uploader';
import { toFa } from '@/lib/shop-data';
import {
  DndContext, closestCenter, KeyboardSensor, PointerSensor,
  useSensor, useSensors, DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove, SortableContext, sortableKeyboardCoordinates,
  useSortable, verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

// ===== قالب‌های آماده (Templates) =====
const pageTemplates = [
  {
    id: 'home',
    name: 'صفحه اصلی فروشگاه',
    icon: '🏠',
    desc: 'بنر اصلی + دسته‌بندی‌ها + محصولات پرفروش + فروش ویژه',
    blocks: [
      { type: 'hero', title: 'بنر اصلی', content: { title: 'دنیای چوب YIO', subtitle: 'محصولات چوبی دست‌ساز و طبیعی', buttonText: 'مشاهده محصولات', buttonLink: '/special', bgImage: '', bgGradient: 'linear-gradient(135deg, #dc2626, #991b1b)' } },
      { type: 'categories', title: 'دسته‌بندی محصولات', content: { title: 'دسته‌بندی محصولات', style: 'circles' } },
      { type: 'products', title: 'پرفروش‌ترین محصولات', content: { title: '🔥 پرفروش‌ترین محصولات', productType: 'bestseller', count: 8 } },
      { type: 'special', title: 'فروش ویژه', content: { title: 'فروش ویژه', count: 6 } },
      { type: 'cta', title: 'دعوت به خرید', content: { title: 'آماده خرید هستید؟', buttonText: 'شروع خرید', buttonLink: '/special', bg: '#dc2626' } },
    ],
  },
  {
    id: 'about',
    name: 'صفحه درباره ما',
    icon: 'ℹ️',
    desc: 'عنوان + داستان برند + ویژگی‌ها + آمار + دعوت به اقدام',
    blocks: [
      { type: 'hero', title: 'بنر درباره ما', content: { title: 'داستان YIO', subtitle: 'از یک کارگاه کوچک تا برند محصولات چوبی', buttonText: '', buttonLink: '', bgGradient: 'linear-gradient(135deg, #1f2937, #374151)' } },
      { type: 'text', title: 'داستان ما', content: { title: 'داستان YIO', body: 'YIO با هدف معرفی محصولات چوبی دست‌ساز و طبیعی به بازار ایران شروع به کار کرد...', align: 'right' } },
      { type: 'features', title: 'ویژگی‌های ما', content: { title: 'چرا YIO؟', features: [{ icon: '🌲', title: '۱۰۰٪ طبیعی', desc: 'استفاده از چوب طبیعی' }, { icon: '✋', title: 'دست‌ساز', desc: 'تولید دستی و هنری' }, { icon: '🚚', title: 'ارسال سریع', desc: 'ارسال به سراسر کشور' }, { icon: '↩️', title: '۷ روز بازگشت', desc: 'ضمانت بازگشت کالا' }] } },
      { type: 'stats', title: 'آمار ما', content: { title: 'YIO در یک نگاه', stats: [{ number: '۱۰۰۰+', label: 'مشتری راضی' }, { number: '۵۰+', label: 'محصول چوبی' }, { number: '۸', label: 'سال تجربه' }] } },
      { type: 'cta', title: 'دعوت به اقدام', content: { title: 'آماده خرید هستید؟', buttonText: 'مشاهده محصولات', buttonLink: '/', bg: '#dc2626' } },
    ],
  },
  {
    id: 'landing',
    name: 'صفحه فرود (Landing)',
    icon: '🚀',
    desc: 'بنر بزرگ + ویژگی‌ها + نظرات مشتریان + آمار + دعوت به اقدام',
    blocks: [
      { type: 'hero', title: 'بنر اصلی', content: { title: 'محصولات چوبی YIO', subtitle: 'کیفیت بالا، قیمت مناسب، ارسال سریع', buttonText: 'خرید کنید', buttonLink: '/special', bgGradient: 'linear-gradient(135deg, #dc2626, #991b1b)' } },
      { type: 'features', title: 'ویژگی‌ها', content: { title: 'ویژگی‌های محصولات', features: [{ icon: '🌿', title: 'طبیعی', desc: 'چوب صد در صد طبیعی' }, { icon: '🎨', title: 'طراحی زیبا', desc: 'طراحی اسکاندیناوی' }, { icon: '⭐', title: 'کیفیت بالا', desc: 'ضمانت کیفیت' }] } },
      { type: 'testimonials', title: 'نظرات مشتریان', content: { title: 'مشتریان ما چه می‌گویند؟', testimonials: [{ name: 'محمد رضایی', text: 'کیفیت محصول عالی بود', rating: 5 }, { name: 'فاطمه احمدی', text: 'ارسال سریع و بسته‌بندی خوب', rating: 5 }] } },
      { type: 'stats', title: 'آمار', content: { title: 'اعتماد مشتریان', stats: [{ number: '۵۰۰۰+', label: 'فروخته شده' }, { number: '۴.۸', label: 'امتیاز میانگین' }] } },
      { type: 'cta', title: 'خرید کنید', content: { title: 'همین حالا خرید کنید', buttonText: 'افزودن به سبد', buttonLink: '/', bg: '#dc2626' } },
    ],
  },
  {
    id: 'contact',
    name: 'صفحه تماس با ما',
    icon: '📞',
    desc: 'بنر + اطلاعات تماس + فرم تماس + نقشه',
    blocks: [
      { type: 'hero', title: 'بنر تماس', content: { title: 'تماس با ما', subtitle: 'راه‌های ارتباطی با YIO', buttonText: '', buttonLink: '', bgGradient: 'linear-gradient(135deg, #1f2937, #374151)' } },
      { type: 'features', title: 'راه‌های ارتباطی', content: { title: 'با ما در ارتباط باشید', features: [{ icon: '📞', title: 'تلفن', desc: '۰۲۱-۹۱۰۰۲۰۲۰' }, { icon: '✉️', title: 'ایمیل', desc: 'info@yio-shop.ir' }, { icon: '📍', title: 'آدرس', desc: 'تهران، خیابان ولیعصر' }] } },
      { type: 'contact', title: 'فرم تماس', content: { title: 'پیام خود را بفرستید', desc: 'سؤال یا پیشنهاد خود را با ما در میان بگذارید' } },
      { type: 'faq', title: 'سؤالات متداول', content: { title: 'سؤالات متداول', items: [{ question: 'زمان ارسال چقدر است؟', answer: '۲ تا ۵ روز کاری' }, { question: 'چگونه می‌توانم سفارشم را پیگیری کنم؟', answer: 'از بخش پیگیری سفارش در سایت' }] } },
    ],
  },
  {
    id: 'blank',
    name: 'صفحه خالی',
    icon: '📄',
    desc: 'شروع از صفر — هیچ بلوکی اضافه نمی‌شود',
    blocks: [],
  },
];

// ===== Types =====
interface BlockContent { [key: string]: any }
interface Block {
  id: number; pageId: number; type: string; title: string | null;
  content: string | null; order: number; isActive: boolean;
  createdAt: string; updatedAt: string;
}
interface Page {
  id: number; slug: string; title: string; description: string | null;
  type: string; isPublished: boolean; showInMenu: boolean;
  menuLabel: string | null; order: number;
  blocks?: Block[]; _count?: { blocks: number };
  createdAt: string; updatedAt: string;
}
interface BlockTypeDef {
  type: string; label: string; icon: string; desc: string;
  defaults: BlockContent;
}

// ===== Block Types =====
const blockTypes: BlockTypeDef[] = [
  { type: 'hero', label: 'بنر اصلی', icon: '🎯', desc: 'بنر بزرگ با عنوان و دکمه', defaults: { subtitle: '', image: '', buttonText: 'مشاهده بیشتر', buttonLink: '', bgColor: '#dc2626' } },
  { type: 'products', label: 'محصولات', icon: '📦', desc: 'نمایش محصولات', defaults: { productType: 'bestseller', count: 8, category: '' } },
  { type: 'categories', label: 'دسته‌بندی‌ها', icon: '🗂️', desc: 'دایره یا کارت دسته‌بندی', defaults: { style: 'circles' } },
  { type: 'banner', label: 'بنر تبلیغاتی', icon: '📢', desc: 'بنر با رنگ و لینک', defaults: { image: '', link: '', bgColor: '#dc2626' } },
  { type: 'text', label: 'متن', icon: '📝', desc: 'بلاک متن', defaults: { content: '', alignment: 'right' } },
  { type: 'image', label: 'تصویر', icon: '🖼️', desc: 'تصویر با کپشن', defaults: { image: '', link: '', caption: '', alignment: 'center' } },
  { type: 'cta', label: 'دعوت به اقدام', icon: '🔘', desc: 'دکمه با لینک', defaults: { buttonText: 'کلیک کنید', buttonLink: '', bgColor: '#dc2626' } },
  { type: 'special', label: 'فروش ویژه', icon: '🔥', desc: 'محصولات فروش ویژه', defaults: { count: 6 } },
  { type: 'video', label: 'ویدیو', icon: '🎬', desc: 'ویدیو با پوستر', defaults: { videoUrl: '', poster: '' } },
  { type: 'gallery', label: 'گالری', icon: '🖼️', desc: 'گالری تصاویر', defaults: { images: [], columns: 3 } },
  { type: 'quote', label: 'نقل قول', icon: '💬', desc: 'نقل قول با نویسنده', defaults: { text: '', author: '', role: '' } },
  { type: 'divider', label: 'جداکننده', icon: '➖', desc: 'خط جداکننده', defaults: { style: 'solid', color: '#e5e7eb' } },
  { type: 'features', label: 'ویژگی‌ها', icon: '✨', desc: 'لیست ویژگی‌ها', defaults: { items: [] } },
  { type: 'testimonials', label: 'نظرات مشتریان', icon: '⭐', desc: 'نظرات و امتیاز', defaults: { items: [] } },
  { type: 'faq', label: 'سؤالات متداول', icon: '❓', desc: 'پرسش و پاسخ', defaults: { items: [] } },
  { type: 'stats', label: 'آمار', icon: '📊', desc: 'اعداد کلیدی', defaults: { items: [] } },
  { type: 'contact', label: 'فرم تماس', icon: '📧', desc: 'فرم تماس', defaults: { description: '' } },
  { type: 'blog', label: 'مقالات', icon: '📰', desc: 'آخرین مقالات', defaults: { count: 4 } },
];
const blockTypeMap: Record<string, BlockTypeDef> = Object.fromEntries(blockTypes.map(b => [b.type, b]));

// ===== System Pages =====
const systemPages = [
  { slug: 'home', label: 'صفحه اصلی', icon: '🏠' },
  { slug: 'about', label: 'درباره ما', icon: 'ℹ️' },
  { slug: 'contact', label: 'تماس با ما', icon: '📧' },
  { slug: 'faq', label: 'سؤالات متداول', icon: '❓' },
  { slug: 'blog', label: 'وبلاگ', icon: '📰' },
  { slug: 'special', label: 'فروش ویژه', icon: '🔥' },
  { slug: 'wholesale', label: 'خرید عمده', icon: '🏢' },
  { slug: 'compare', label: 'مقایسه', icon: '⚖️' },
];
const systemSlugs = new Set(systemPages.map(p => p.slug));
const menuSystemSlugs = new Set(['about', 'contact', 'faq', 'blog', 'special', 'wholesale']);
const pageTypeLabels: Record<string, string> = {
  home: 'صفحه اصلی', about: 'درباره ما', contact: 'تماس', faq: 'سؤالات',
  blog: 'وبلاگ', special: 'فروش ویژه', wholesale: 'عمده', compare: 'مقایسه', custom: 'سفارشی',
};

// ===== Helpers =====
function parseContent(c: string | null): BlockContent {
  if (!c) return {};
  try { return JSON.parse(c); } catch { return {}; }
}
function formatDate(iso: string): string {
  try {
    const d = new Date(iso);
    const s = `${d.getFullYear()}/${String(d.getMonth() + 1).padStart(2, '0')}/${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
    return toFa(s);
  } catch { return '-'; }
}

// =====================================================
// Main: AdminPages (Pages Manager)
// =====================================================
export function AdminPages() {
  const [pages, setPages] = useState<Page[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'system' | 'custom'>('all');
  const [search, setSearch] = useState('');
  const [pageBuilder, setPageBuilder] = useState<Page | null>(null);
  const [settingsPage, setSettingsPage] = useState<Page | null>(null);
  const [showNewPage, setShowNewPage] = useState(false);
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const ensuredRef = useRef(false);

  const fetchPages = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/admin/pages');
      if (res.status === 401) { toast.error('سشن منقضی شده. دوباره وارد شوید.'); return; }
      if (res.ok) {
        const data = await res.json();
        setPages(data.pages || []);
      } else toast.error('خطا در دریافت صفحات');
    } catch { toast.error('خطا در ارتباط'); }
    setLoading(false);
  }, []);

  useEffect(() => { fetchPages(); }, [fetchPages]);

  // Ensure system pages exist (run once after first load)
  useEffect(() => {
    if (ensuredRef.current || pages.length === 0) return;
    const existing = new Set(pages.map(p => p.slug));
    const missing = systemPages.filter(sp => !existing.has(sp.slug));
    if (missing.length === 0) { ensuredRef.current = true; return; }
    ensuredRef.current = true;
    (async () => {
      let created = false;
      for (const sp of missing) {
        try {
          const res = await fetch('/api/admin/pages', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              title: sp.label, slug: sp.slug, type: sp.slug,
              isPublished: true, showInMenu: menuSystemSlugs.has(sp.slug),
            }),
          });
          if (res.ok) created = true;
        } catch {}
      }
      if (created) fetchPages();
    })();
  }, [pages.length, fetchPages]);

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      const res = await fetch(`/api/admin/pages/${deleteId}`, { method: 'DELETE' });
      const data = await res.json();
      if (res.ok) { toast.success('صفحه حذف شد'); setDeleteId(null); fetchPages(); }
      else toast.error(data.error || 'خطا در حذف');
    } catch { toast.error('خطا در ارتباط'); }
  };

  const togglePublish = async (page: Page) => {
    try {
      const res = await fetch(`/api/admin/pages/${page.id}`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isPublished: !page.isPublished }),
      });
      if (res.ok) { toast.success(page.isPublished ? 'انتشار لغو شد' : 'صفحه منتشر شد'); fetchPages(); }
      else toast.error('خطا');
    } catch { toast.error('خطا'); }
  };

  const duplicatePage = async (page: Page) => {
    try {
      const newSlug = `${page.slug}-copy-${Date.now().toString().slice(-5)}`;
      const createRes = await fetch('/api/admin/pages', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: `${page.title} (کپی)`, slug: newSlug, type: 'custom',
          description: page.description, isPublished: false,
          showInMenu: false, menuLabel: page.menuLabel, order: page.order,
        }),
      });
      const createData = await createRes.json();
      if (!createRes.ok) { toast.error(createData.error || 'خطا'); return; }
      const newPageId = createData.page.id;
      const detailRes = await fetch(`/api/admin/pages/${page.id}`);
      if (detailRes.ok) {
        const detail = await detailRes.json();
        const blocks: Block[] = detail.page.blocks || [];
        for (let i = 0; i < blocks.length; i++) {
          await fetch(`/api/admin/pages/${newPageId}`, {
            method: 'PUT', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              action: 'addBlock', blockType: blocks[i].type,
              title: blocks[i].title, content: parseContent(blocks[i].content), order: i,
            }),
          });
        }
      }
      toast.success('صفحه کپی شد');
      fetchPages();
    } catch { toast.error('خطا در کپی'); }
  };

  const filtered = pages.filter(p => {
    if (filter === 'system' && !systemSlugs.has(p.slug)) return false;
    if (filter === 'custom' && systemSlugs.has(p.slug)) return false;
    if (search && !p.title.toLowerCase().includes(search.toLowerCase()) && !p.slug.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  if (pageBuilder) {
    return <PageBuilder page={pageBuilder} onBack={() => { setPageBuilder(null); fetchPages(); }} />;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Layout className="w-6 h-6 text-[#dc2626]" />
          مدیریت صفحات و سازنده صفحه
        </h2>
        <Button onClick={() => setShowNewPage(true)} className="bg-[#dc2626] hover:bg-[#b91c1c]">
          <Plus className="w-4 h-4 ml-1" /> صفحه جدید
        </Button>
      </div>

      {/* Toolbar: filter + search */}
      <div className="bg-white rounded-xl p-3 shadow-sm flex flex-wrap gap-2 items-center">
        <div className="flex bg-gray-100 rounded-lg p-1">
          {(['all', 'system', 'custom'] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-1 rounded-md text-sm transition-all ${filter === f ? 'bg-white shadow text-[#dc2626] font-medium' : 'text-gray-500'}`}>
              {f === 'all' ? 'همه' : f === 'system' ? 'سیستمی' : 'سفارشی'}
            </button>
          ))}
        </div>
        <Input placeholder="جستجوی عنوان یا آدرس..." value={search} onChange={e => setSearch(e.target.value)}
          className="flex-1 min-w-[200px] h-9" />
        <span className="text-xs text-gray-500">{toFa(filtered.length)} صفحه</span>
      </div>

      {loading ? (
        <div className="bg-white rounded-xl p-12 text-center">
          <Loader2 className="w-8 h-8 mx-auto animate-spin text-[#dc2626]" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-xl p-12 text-center">
          <Layout className="w-16 h-16 mx-auto mb-3 text-gray-300" />
          <p className="text-gray-500 mb-4">صفحه‌ای یافت نشد</p>
          <Button onClick={() => setShowNewPage(true)} className="bg-[#dc2626] hover:bg-[#b91c1c]">
            <Plus className="w-4 h-4 ml-1" /> ساخت صفحه جدید
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map(page => {
            const isSystem = systemSlugs.has(page.slug);
            const sp = systemPages.find(s => s.slug === page.slug);
            return (
              <div key={page.id} className={`bg-white rounded-xl p-4 border-2 shadow-sm ${page.isPublished ? 'border-gray-100' : 'border-amber-200 bg-amber-50/30'}`}>
                <div className="flex items-start justify-between mb-2 gap-2">
                  <div className="flex items-center gap-2 min-w-0 flex-1">
                    <span className="text-2xl shrink-0">{sp?.icon || '📄'}</span>
                    <div className="min-w-0 flex-1">
                      <h3 className="font-bold truncate">{page.title}</h3>
                      <code className="text-xs text-gray-400" dir="ltr">/{page.slug}</code>
                    </div>
                  </div>
                  {isSystem && <span className="text-[10px] bg-blue-100 text-blue-700 px-2 py-0.5 rounded shrink-0">سیستمی</span>}
                </div>

                <div className="flex flex-wrap gap-1.5 mb-3 text-[11px]">
                  <span className={`px-2 py-0.5 rounded ${page.isPublished ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                    {page.isPublished ? 'منتشر شده' : 'پیش‌نویس'}
                  </span>
                  <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded">
                    {toFa(page._count?.blocks || 0)} بلوک
                  </span>
                  {page.showInMenu && <span className="bg-purple-100 text-purple-700 px-2 py-0.5 rounded">در منو</span>}
                </div>

                <p className="text-[10px] text-gray-400 mb-2">به‌روزرسانی: {formatDate(page.updatedAt)}</p>

                <div className="flex flex-wrap gap-1 pt-2 border-t border-gray-50">
                  <Button variant="outline" size="sm" onClick={() => setPageBuilder(page)} className="flex-1 h-8 text-xs min-w-[80px]">
                    <Layout className="w-3 h-3 ml-1" /> ویرایشگر
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => togglePublish(page)} className="h-8 w-8 p-0" title={page.isPublished ? 'لغو انتشار' : 'انتشار'}>
                    {page.isPublished ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => setSettingsPage(page)} className="h-8 w-8 p-0" title="تنظیمات صفحه">
                    <Settings className="w-3 h-3" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => duplicatePage(page)} className="h-8 w-8 p-0" title="کپی صفحه">
                    <Copy className="w-3 h-3" />
                  </Button>
                  {!isSystem && (
                    <Button variant="outline" size="sm" onClick={() => setDeleteId(page.id)} className="h-8 w-8 p-0 text-red-600" title="حذف">
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {(showNewPage || settingsPage) && (
        <PageSettingsModal
          page={settingsPage}
          onClose={() => { setShowNewPage(false); setSettingsPage(null); }}
          onSaved={() => { setShowNewPage(false); setSettingsPage(null); fetchPages(); }}
        />
      )}

      <AlertDialog open={deleteId !== null} onOpenChange={o => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف صفحه</AlertDialogTitle>
            <AlertDialogDescription>آیا مطمئن هستید؟ تمام بلوک‌های این صفحه حذف خواهند شد. این عمل قابل بازگشت نیست.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">حذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// =====================================================
// Page Settings Modal (self-contained, reusable)
// =====================================================
function PageSettingsModal({ page, onClose, onSaved }: {
  page: Page | null; onClose: () => void; onSaved: () => void;
}) {
  const isEdit = !!page;
  const isSystem = page ? systemSlugs.has(page.slug) : false;
  const [form, setForm] = useState({
    title: page?.title || '',
    slug: page?.slug || '',
    description: page?.description || '',
    type: page?.type || 'custom',
    isPublished: page?.isPublished ?? true,
    showInMenu: page?.showInMenu ?? false,
    menuLabel: page?.menuLabel || '',
    order: page?.order || 0,
  });
  const [saving, setSaving] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.title.trim().length < 3) { toast.error('عنوان باید حداقل ۳ کاراکتر باشد'); return; }
    setSaving(true);
    try {
      const body: any = { ...form };
      if (isSystem) delete body.slug;
      const url = isEdit ? `/api/admin/pages/${page!.id}` : '/api/admin/pages';
      const method = isEdit ? 'PUT' : 'POST';
      const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      const data = await res.json();
      if (res.ok) { toast.success(isEdit ? 'صفحه ذخیره شد' : 'صفحه ایجاد شد'); onSaved(); }
      else toast.error(data.error || 'خطا');
    } catch { toast.error('خطا در ارتباط'); }
    setSaving(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg my-8 max-h-[90vh] overflow-y-auto">
        <div className="p-4 border-b border-gray-100 flex items-center justify-between sticky top-0 bg-white z-10">
          <h2 className="font-bold">{isEdit ? 'ویرایش صفحه' : 'صفحه جدید'}</h2>
          <Button variant="ghost" size="icon" onClick={onClose}><X className="w-5 h-5" /></Button>
        </div>
        <form onSubmit={submit} className="p-4 space-y-3">
          <div className="space-y-1.5">
            <Label>عنوان صفحه *</Label>
            <Input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="مثلا: درباره ما" required />
          </div>
          <div className="space-y-1.5">
            <Label>آدرس (slug) {isSystem && <span className="text-xs text-blue-600">(سیستمی - غیرقابل تغییر)</span>}</Label>
            <Input value={form.slug} onChange={e => setForm({ ...form, slug: e.target.value })} placeholder="about-us" dir="ltr"
              disabled={isSystem} className={isSystem ? 'bg-gray-100 text-gray-500' : ''} />
          </div>
          <div className="space-y-1.5">
            <Label>توضیحات (اختیاری)</Label>
            <Textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} rows={2} placeholder="توضیح کوتاه برای سئو" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>نوع صفحه</Label>
              <Select value={form.type} onValueChange={v => setForm({ ...form, type: v })} disabled={isSystem}>
                <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(pageTypeLabels).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>ترتیب نمایش</Label>
              <Input type="number" value={form.order} onChange={e => setForm({ ...form, order: parseInt(e.target.value) || 0 })} min="0" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>برچسب منو (در صورت نمایش در منو)</Label>
            <Input value={form.menuLabel} onChange={e => setForm({ ...form, menuLabel: e.target.value })} placeholder="مثلا: درباره ما" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <Label>منتشر شده</Label>
              <Switch checked={form.isPublished} onCheckedChange={v => setForm({ ...form, isPublished: v })} />
            </div>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <Label>نمایش در منو</Label>
              <Switch checked={form.showInMenu} onCheckedChange={v => setForm({ ...form, showInMenu: v })} />
            </div>
          </div>
          <div className="flex gap-2">
            <Button type="submit" disabled={saving} className="flex-1 bg-[#dc2626] hover:bg-[#b91c1c]">
              {saving ? <Loader2 className="w-4 h-4 ml-1 animate-spin" /> : <Save className="w-4 h-4 ml-1" />}
              {isEdit ? 'ذخیره' : 'ایجاد'}
            </Button>
            <Button type="button" variant="outline" onClick={onClose}>انصراف</Button>
          </div>
        </form>
      </div>
    </div>
  );
}

// =====================================================
// Page Builder
// =====================================================
function PageBuilder({ page, onBack }: { page: Page; onBack: () => void }) {
  const [blocks, setBlocks] = useState<Block[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showAddBlock, setShowAddBlock] = useState(false);
  const [editingBlock, setEditingBlock] = useState<Block | null>(null);
  const [previewMode, setPreviewMode] = useState<'desktop' | 'mobile'>('desktop');
  const [showSettings, setShowSettings] = useState(false);
  const [showTemplates, setShowTemplates] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates })
  );

  const fetchBlocks = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/pages/${page.id}`);
      if (res.ok) {
        const data = await res.json();
        setBlocks(data.page.blocks || []);
      }
    } catch { toast.error('خطا در دریافت بلوک‌ها'); }
    setLoading(false);
  }, [page.id]);

  useEffect(() => { fetchBlocks(); }, [fetchBlocks]);

  const apiCall = async (body: any) => {
    const res = await fetch(`/api/admin/pages/${page.id}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
    });
    return res.ok;
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const oldIndex = blocks.findIndex(b => b.id === active.id);
    const newIndex = blocks.findIndex(b => b.id === over.id);
    const newBlocks = arrayMove(blocks, oldIndex, newIndex);
    setBlocks(newBlocks);
    try {
      await apiCall({
        action: 'reorderBlocks',
        orders: newBlocks.map((b, i) => ({ id: b.id, order: i })),
      });
      toast.success('ترتیب ذخیره شد');
    } catch { toast.error('خطا در ذخیره ترتیب'); }
  };

  const handleAddBlock = async (type: string, title: string, content: BlockContent) => {
    setSaving(true);
    const ok = await apiCall({ action: 'addBlock', blockType: type, title, content, order: blocks.length });
    if (ok) { toast.success('بلوک اضافه شد'); setShowAddBlock(false); fetchBlocks(); }
    else toast.error('خطا در افزودن بلوک');
    setSaving(false);
  };

  const handleUpdateBlock = async (block: Block, title: string, content: BlockContent) => {
    setSaving(true);
    const ok = await apiCall({ action: 'updateBlock', blockId: block.id, title, content });
    if (ok) { toast.success('بلوک ذخیره شد'); setEditingBlock(null); fetchBlocks(); }
    else toast.error('خطا در ذخیره');
    setSaving(false);
  };

  const handleDeleteBlock = async (blockId: number) => {
    const ok = await apiCall({ action: 'deleteBlock', blockId });
    if (ok) { toast.success('بلوک حذف شد'); fetchBlocks(); }
  };

  const handleToggleBlock = async (block: Block) => {
    const ok = await apiCall({ action: 'updateBlock', blockId: block.id, isActive: !block.isActive });
    if (ok) fetchBlocks();
  };

  const duplicateBlock = async (block: Block) => {
    setSaving(true);
    const ok = await apiCall({ action: 'addBlock', blockType: block.type, title: block.title, content: parseContent(block.content), order: blocks.length });
    if (ok) { toast.success('بلوک کپی شد'); fetchBlocks(); }
    setSaving(false);
  };

  // اعمال قالب آماده — همه بلوک‌های قالب را به صفحه اضافه می‌کند
  const applyTemplate = async (template: typeof pageTemplates[0]) => {
    if (template.blocks.length === 0) {
      setShowTemplates(false);
      return;
    }
    setSaving(true);
    let success = 0;
    for (let i = 0; i < template.blocks.length; i++) {
      const b = template.blocks[i] as any;
      const ok = await apiCall({ action: 'addBlock', blockType: b.type, title: b.title, content: b.content, order: blocks.length + i });
      if (ok) success++;
    }
    if (success > 0) {
      toast.success(`${success} بلوک از قالب «${template.name}» اضافه شد`);
      fetchBlocks();
    } else {
      toast.error('خطا در اعمال قالب');
    }
    setShowTemplates(false);
    setSaving(false);
  };

  return (
    <div className="space-y-3">
      {/* Top bar */}
      <div className="bg-white rounded-xl p-3 shadow-sm">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <Button variant="ghost" size="sm" onClick={onBack} className="shrink-0">
              <ArrowRight className="w-4 h-4 ml-1" /> بازگشت
            </Button>
            <div className="min-w-0">
              <h2 className="font-bold truncate text-sm md:text-base">{page.title}</h2>
              <code className="text-xs text-gray-400" dir="ltr">/{page.slug}</code>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex bg-gray-100 rounded-lg p-1">
              <button onClick={() => setPreviewMode('desktop')} className={`p-1.5 rounded ${previewMode === 'desktop' ? 'bg-white shadow' : ''}`}>
                <Monitor className="w-4 h-4" />
              </button>
              <button onClick={() => setPreviewMode('mobile')} className={`p-1.5 rounded ${previewMode === 'mobile' ? 'bg-white shadow' : ''}`}>
                <Smartphone className="w-4 h-4" />
              </button>
            </div>
            <Button variant="outline" size="sm" onClick={() => setShowTemplates(true)} title="قالب‌های آماده">
              <Layout className="w-4 h-4 ml-1" /> قالب‌ها
            </Button>
            <Button variant="outline" size="sm" onClick={() => setShowSettings(true)}>
              <Settings className="w-4 h-4 ml-1" /> تنظیمات
            </Button>
            <Button onClick={() => setShowAddBlock(true)} className="bg-[#dc2626] hover:bg-[#b91c1c]">
              <Plus className="w-4 h-4 ml-1" /> بلوک
            </Button>
          </div>
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-xs text-blue-800 flex items-center gap-2">
        <GripVertical className="w-4 h-4 shrink-0" />
        <span>بلوک‌ها را با کشیدن مرتب کنید. برای ویرایش روی دکمه مداد کلیک کنید.</span>
      </div>

      {loading ? (
        <div className="p-12 text-center"><Loader2 className="w-8 h-8 mx-auto animate-spin text-[#dc2626]" /></div>
      ) : blocks.length === 0 ? (
        <div className="bg-white rounded-xl p-12 text-center border-2 border-dashed border-gray-200">
          <Layout className="w-16 h-16 mx-auto mb-3 text-gray-300" />
          <p className="text-gray-500 mb-4">صفحه خالی است - اولین بلوک را اضافه کنید</p>
          <Button onClick={() => setShowAddBlock(true)} className="bg-[#dc2626] hover:bg-[#b91c1c]">
            <Plus className="w-4 h-4 ml-1" /> افزودن بلوک
          </Button>
        </div>
      ) : (
        <div className={`mx-auto ${previewMode === 'mobile' ? 'max-w-[400px]' : 'max-w-full'}`}>
          <div className="bg-gray-200 rounded-t-xl px-4 py-2 flex items-center gap-2">
            <div className="flex gap-1.5">
              <div className="w-3 h-3 rounded-full bg-red-400" />
              <div className="w-3 h-3 rounded-full bg-amber-400" />
              <div className="w-3 h-3 rounded-full bg-green-400" />
            </div>
            <div className="flex-1 bg-white rounded-md px-3 py-1 text-xs text-gray-400" dir="ltr">yio-shop.ir/{page.slug}</div>
          </div>
          <div className="bg-[#f0f0f1] rounded-b-xl p-3 min-h-[300px]">
            <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
              <SortableContext items={blocks.map(b => b.id)} strategy={verticalListSortingStrategy}>
                <div className="space-y-2">
                  {blocks.map((block, idx) => (
                    <SortableBlock
                      key={block.id}
                      block={block}
                      idx={idx}
                      onDelete={handleDeleteBlock}
                      onEdit={setEditingBlock}
                      onToggle={handleToggleBlock}
                      onDuplicate={duplicateBlock}
                    />
                  ))}
                </div>
              </SortableContext>
            </DndContext>
            <button onClick={() => setShowAddBlock(true)}
              className="w-full mt-2 py-3 border-2 border-dashed border-gray-300 rounded-xl text-gray-400 hover:border-[#dc2626] hover:text-[#dc2626] transition-colors text-sm">
              <Plus className="w-4 h-4 inline ml-1" /> افزودن بلوک جدید
            </button>
          </div>
        </div>
      )}

      {showAddBlock && (
        <BlockEditorModal
          block={null}
          onClose={() => setShowAddBlock(false)}
          onSave={handleAddBlock}
          saving={saving}
        />
      )}

      {editingBlock && (
        <BlockEditorModal
          block={editingBlock}
          onClose={() => setEditingBlock(null)}
          onSave={(_type, title, content) => { if (editingBlock) handleUpdateBlock(editingBlock, title, content); }}
          saving={saving}
        />
      )}

      {showSettings && (
        <PageSettingsModal
          page={page}
          onClose={() => setShowSettings(false)}
          onSaved={() => { setShowSettings(false); onBack(); }}
        />
      )}

      {/* مدال قالب‌های آماده */}
      {showTemplates && (
        <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-2 md:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl my-4 max-h-[95vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-100 p-4 flex items-center justify-between z-10">
              <h2 className="text-lg font-bold flex items-center gap-2">
                <Layout className="w-5 h-5 text-[#dc2626]" />
                قالب‌های آماده
              </h2>
              <button onClick={() => setShowTemplates(false)} className="w-9 h-9 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 space-y-3">
              <p className="text-sm text-gray-500 mb-2">
                یک قالب را انتخاب کنید تا بلوک‌های آن به این صفحه اضافه شوند. می‌توانید بعداً هر بلوک را ویرایش یا حذف کنید.
              </p>
              {pageTemplates.map(tpl => (
                <button
                  key={tpl.id}
                  onClick={() => applyTemplate(tpl)}
                  disabled={saving}
                  className="w-full flex items-center gap-3 p-4 border-2 border-gray-100 rounded-xl hover:border-[#dc2626] hover:bg-red-50 transition-all text-right disabled:opacity-50"
                >
                  <span className="text-3xl shrink-0">{tpl.icon}</span>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-sm">{tpl.name}</h3>
                    <p className="text-xs text-gray-500 mt-0.5">{tpl.desc}</p>
                    {tpl.blocks.length > 0 && (
                      <span className="text-[10px] text-[#dc2626] mt-1 inline-block">{tpl.blocks.length} بلوک</span>
                    )}
                  </div>
                  {saving && <Loader2 className="w-5 h-5 animate-spin text-[#dc2626]" />}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// =====================================================
// Sortable Block Item
// =====================================================
function SortableBlock({ block, idx, onDelete, onEdit, onToggle, onDuplicate }: {
  block: Block; idx: number;
  onDelete: (id: number) => void;
  onEdit: (b: Block) => void;
  onToggle: (b: Block) => void;
  onDuplicate: (b: Block) => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: block.id });
  const bt = blockTypeMap[block.type];
  const style: React.CSSProperties = {
    transform: CSS.Transform.toString(transform), transition,
    zIndex: isDragging ? 50 : 'auto',
    opacity: isDragging ? 0.8 : 1,
  };
  return (
    <div ref={setNodeRef} style={style}
      className={`bg-white rounded-xl border-2 shadow-sm overflow-hidden ${isDragging ? 'border-[#dc2626] shadow-lg' : 'border-gray-100'} ${!block.isActive ? 'opacity-50' : ''}`}>
      <div className="flex items-center justify-between p-3 gap-2">
        <button {...attributes} {...listeners} className="cursor-grab active:cursor-grabbing p-1 text-gray-400 hover:text-[#dc2626] shrink-0">
          <GripVertical className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <span className="text-2xl shrink-0">{bt?.icon || '📦'}</span>
          <div className="flex-1 min-w-0">
            <p className="font-medium text-sm truncate">{block.title || bt?.label || block.type}</p>
            <p className="text-[10px] text-gray-400 truncate">{bt?.desc || block.type}</p>
          </div>
          <span className="text-[10px] bg-gray-100 text-gray-500 px-2 py-0.5 rounded fa-num shrink-0">ردیف {toFa(idx + 1)}</span>
        </div>
        <div className="flex items-center gap-0.5 shrink-0">
          <Button variant="ghost" size="sm" onClick={() => onToggle(block)} className="h-8 w-8 p-0" title={block.isActive ? 'مخفی کردن' : 'نمایش'}>
            {block.isActive ? <Eye className="w-3.5 h-3.5 text-green-600" /> : <EyeOff className="w-3.5 h-3.5 text-gray-400" />}
          </Button>
          <Button variant="ghost" size="sm" onClick={() => onEdit(block)} className="h-8 w-8 p-0" title="ویرایش">
            <Edit2 className="w-3.5 h-3.5 text-blue-600" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => onDuplicate(block)} className="h-8 w-8 p-0" title="کپی">
            <Copy className="w-3.5 h-3.5 text-gray-600" />
          </Button>
          <Button variant="ghost" size="sm" onClick={() => onDelete(block.id)} className="h-8 w-8 p-0" title="حذف">
            <Trash2 className="w-3.5 h-3.5 text-red-600" />
          </Button>
        </div>
      </div>
      <div className="border-t border-gray-50 bg-gray-50/50 p-3">
        <BlockPreview block={block} />
      </div>
    </div>
  );
}

// =====================================================
// Block Preview
// =====================================================
function BlockPreview({ block }: { block: Block }) {
  const c = parseContent(block.content);
  const title = block.title;
  switch (block.type) {
    case 'hero':
      return (
        <div className="rounded-lg p-4 text-center text-white text-xs" style={{ background: c.bgColor || 'linear-gradient(135deg, #dc2626, #991b1b)' }}>
          <p className="font-bold">{title || 'عنوان بنر'}</p>
          {c.subtitle && <p className="opacity-80 mt-1">{c.subtitle}</p>}
          {c.buttonLink && <span className="inline-block bg-white/20 px-2 py-0.5 rounded mt-2">{c.buttonText || 'مشاهده'}</span>}
        </div>
      );
    case 'banner':
      return (
        <div className="rounded-lg p-3 flex items-center justify-between text-white text-xs" style={{ background: c.bgColor || '#dc2626' }}>
          <span>{title || 'عنوان بنر'}</span>
          {c.link && <span className="bg-white/20 px-2 py-0.5 rounded">مشاهده ←</span>}
        </div>
      );
    case 'text':
      return <p className={`text-xs text-gray-600 leading-5 ${c.alignment === 'center' ? 'text-center' : c.alignment === 'left' ? 'text-left' : 'text-right'}`}>{c.content || title || 'متن بلوک...'}</p>;
    case 'cta':
      return (
        <div className="text-center">
          {title && <p className="text-xs font-medium mb-2">{title}</p>}
          <span className="inline-block text-white text-xs px-3 py-1.5 rounded" style={{ background: c.bgColor || '#dc2626' }}>{c.buttonText || 'کلیک کنید'}</span>
        </div>
      );
    case 'image':
      return (
        <div className={c.alignment === 'left' ? 'text-left' : c.alignment === 'right' ? 'text-right' : 'text-center'}>
          {c.image ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={c.image} alt={c.caption || ''} className="max-h-32 mx-auto rounded-lg" />
          ) : <div className="bg-gray-100 h-24 rounded-lg flex items-center justify-center text-gray-400 text-xs">تصویر</div>}
          {c.caption && <p className="text-xs text-gray-500 mt-1">{c.caption}</p>}
        </div>
      );
    case 'categories':
      return <p className="text-xs text-gray-400">🗂️ نمایش دسته‌بندی‌ها به سبک {c.style === 'cards' ? 'کارت' : 'دایره'}</p>;
    case 'products': {
      const typeLabel: Record<string, string> = { bestseller: 'پرفروش', new: 'جدید', special: 'فروش ویژه', category: 'دسته خاص' };
      return <p className="text-xs text-gray-400">📦 {typeLabel[c.productType] || 'محصولات'} - {toFa(c.count || 8)} مورد {c.category ? `(${c.category})` : ''}</p>;
    }
    case 'special':
      return <p className="text-xs text-gray-400">🔥 محصولات فروش ویژه ({toFa(c.count || 6)} مورد)</p>;
    case 'video':
      return <p className="text-xs text-gray-400">🎬 ویدیو {c.videoUrl ? '✓' : '(بدون لینک)'}</p>;
    case 'gallery':
      return Array.isArray(c.images) && c.images.length > 0 ? (
        <div style={{ display: 'grid', gridTemplateColumns: `repeat(${c.columns || 3}, minmax(0, 1fr))`, gap: '4px' }}>
          {c.images.slice(0, 6).map((img: string, i: number) => (
            // eslint-disable-next-line @next/next/no-img-element
            <img key={i} src={img} alt="" className="aspect-square object-cover rounded" />
          ))}
        </div>
      ) : <p className="text-xs text-gray-400">🖼️ گالری ({toFa(c.columns || 3)} ستونه)</p>;
    case 'quote':
      return (
        <div className="border-r-4 border-[#dc2626] pr-3 py-1">
          <p className="text-xs text-gray-600 italic">&ldquo;{c.text || 'متن نقل قول'}&rdquo;</p>
          {c.author && <p className="text-[10px] text-gray-500 mt-1">— {c.author}{c.role ? `، ${c.role}` : ''}</p>}
        </div>
      );
    case 'divider': {
      const borderStyle = c.style === 'dashed' ? 'dashed' : c.style === 'dots' ? 'dotted' : 'solid';
      return <div style={{ borderTop: `2px ${borderStyle} ${c.color || '#e5e7eb'}` }} />;
    }
    case 'features':
      return <p className="text-xs text-gray-400">✨ {toFa(Array.isArray(c.items) ? c.items.length : 0)} ویژگی</p>;
    case 'testimonials':
      return <p className="text-xs text-gray-400">⭐ {toFa(Array.isArray(c.items) ? c.items.length : 0)} نظر</p>;
    case 'faq':
      return <p className="text-xs text-gray-400">❓ {toFa(Array.isArray(c.items) ? c.items.length : 0)} پرسش</p>;
    case 'stats':
      return Array.isArray(c.items) && c.items.length > 0 ? (
        <div className="flex gap-3 flex-wrap">
          {c.items.slice(0, 4).map((s: any, i: number) => (
            <div key={i} className="text-center">
              <p className="text-lg font-bold text-[#dc2626] fa-num">{s.number}</p>
              <p className="text-[10px] text-gray-500">{s.label}</p>
            </div>
          ))}
        </div>
      ) : <p className="text-xs text-gray-400">📊 آمار</p>;
    case 'contact':
      return <p className="text-xs text-gray-400">📧 فرم تماس {c.description ? '- ' + String(c.description).slice(0, 30) : ''}</p>;
    case 'blog':
      return <p className="text-xs text-gray-400">📰 {toFa(c.count || 4)} مقاله اخیر</p>;
    default:
      return <p className="text-xs text-gray-400">بلوک نوع {block.type}</p>;
  }
}

// =====================================================
// Block Editor Modal (Add + Edit unified)
// =====================================================
function BlockEditorModal({ block, onClose, onSave, saving }: {
  block: Block | null;
  onClose: () => void;
  onSave: (type: string, title: string, content: BlockContent) => void;
  saving: boolean;
}) {
  const isEdit = !!block;
  const [selectedType, setSelectedType] = useState<string>(block?.type || '');
  const [title, setTitle] = useState(block?.title || '');
  const [content, setContent] = useState<BlockContent>(
    block ? parseContent(block.content) : {}
  );

  const pickType = (type: string) => {
    setSelectedType(type);
    setContent(blockTypeMap[type]?.defaults || {});
  };

  const handleSave = () => {
    const type = isEdit ? block!.type : selectedType;
    if (!type) { toast.error('نوع بلوک را انتخاب کنید'); return; }
    onSave(type, title, content);
  };

  const activeType = isEdit ? block!.type : selectedType;

  return (
    <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl my-8 max-h-[90vh] overflow-y-auto">
        <div className="p-4 border-b border-gray-100 flex items-center justify-between sticky top-0 bg-white z-10">
          <h3 className="font-bold flex items-center gap-2">
            {isEdit ? <><Edit2 className="w-4 h-4" /> ویرایش بلوک</> : <><Plus className="w-4 h-4" /> افزودن بلوک</>}
          </h3>
          <Button variant="ghost" size="icon" onClick={onClose}><X className="w-5 h-5" /></Button>
        </div>

        <div className="p-4 space-y-3">
          {/* Type picker (only for new blocks without a selected type) */}
          {!isEdit && !selectedType && (
            <div>
              <Label className="mb-2 block">انتخاب نوع بلوک</Label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {blockTypes.map(bt => (
                  <button key={bt.type} type="button" onClick={() => pickType(bt.type)}
                    className="p-3 rounded-lg border-2 border-gray-200 hover:border-[#dc2626] hover:bg-red-50/30 text-right transition-all">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xl">{bt.icon}</span>
                      <span className="text-sm font-medium">{bt.label}</span>
                    </div>
                    <p className="text-[10px] text-gray-500">{bt.desc}</p>
                  </button>
                ))}
              </div>
            </div>
          )}

          {(isEdit || selectedType) && (
            <>
              <div className="flex items-center justify-between bg-gray-50 rounded-lg p-2">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{blockTypeMap[activeType]?.icon}</span>
                  <span className="font-medium text-sm">{blockTypeMap[activeType]?.label}</span>
                </div>
                {!isEdit && (
                  <Button type="button" variant="ghost" size="sm" onClick={() => { setSelectedType(''); setContent({}); }}>
                    تغییر نوع
                  </Button>
                )}
              </div>

              <Field label="عنوان بلوک (اختیاری)">
                <Input value={title} onChange={e => setTitle(e.target.value)} placeholder="مثلا: محصولات پرفروش" className="h-9" />
              </Field>

              <BlockFields type={activeType} content={content} setContent={setContent} />

              <div className="flex gap-2 pt-2">
                <Button type="button" onClick={handleSave} disabled={saving} className="flex-1 bg-[#dc2626] hover:bg-[#b91c1c]">
                  {saving ? <Loader2 className="w-4 h-4 ml-1 animate-spin" /> : <Save className="w-4 h-4 ml-1" />}
                  {isEdit ? 'ذخیره تغییرات' : 'افزودن بلوک'}
                </Button>
                <Button type="button" variant="outline" onClick={onClose}>انصراف</Button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// =====================================================
// Field Helpers
// =====================================================
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs">{label}</Label>
      {children}
    </div>
  );
}

function ColorInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex gap-2 items-center">
      <input type="color" value={value || '#dc2626'} onChange={e => onChange(e.target.value)}
        className="w-10 h-9 rounded border border-gray-200 cursor-pointer p-0.5" />
      <Input value={value || ''} onChange={e => onChange(e.target.value)} dir="ltr" className="flex-1 h-9" />
    </div>
  );
}

interface ItemField {
  key: string; label: string;
  type: 'text' | 'textarea' | 'number' | 'select';
  options?: { value: string; label: string }[];
  placeholder?: string;
}
function ItemListEditor({ items, onChange, fields, addLabel }: {
  items: any[]; onChange: (items: any[]) => void;
  fields: ItemField[]; addLabel: string;
}) {
  const safeItems = Array.isArray(items) ? items : [];
  const update = (i: number, key: string, val: any) => {
    const next = [...safeItems];
    next[i] = { ...next[i], [key]: val };
    onChange(next);
  };
  const add = () => {
    const newItem: any = {};
    fields.forEach(f => { newItem[f.key] = f.type === 'number' ? 0 : (f.type === 'select' ? (f.options?.[0]?.value || '') : ''); });
    onChange([...safeItems, newItem]);
  };
  const remove = (i: number) => onChange(safeItems.filter((_, idx) => idx !== i));

  return (
    <div className="space-y-2">
      {safeItems.map((item, i) => (
        <div key={i} className="border border-gray-200 rounded-lg p-2 space-y-2 bg-gray-50/50">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-gray-500">ردیف {toFa(i + 1)}</span>
            <Button type="button" variant="ghost" size="icon" className="h-6 w-6" onClick={() => remove(i)}>
              <Trash2 className="w-3.5 h-3.5 text-red-600" />
            </Button>
          </div>
          {fields.map(f => (
            <Field key={f.key} label={f.label}>
              {f.type === 'textarea' ? (
                <Textarea value={item[f.key] || ''} onChange={e => update(i, f.key, e.target.value)} rows={2} className="text-xs" placeholder={f.placeholder} />
              ) : f.type === 'number' ? (
                <Input type="number" value={item[f.key] || 0} onChange={e => update(i, f.key, parseInt(e.target.value) || 0)} className="h-9 text-xs" />
              ) : f.type === 'select' ? (
                <Select value={String(item[f.key] || '')} onValueChange={v => update(i, f.key, v)}>
                  <SelectTrigger className="w-full h-9 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {f.options?.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              ) : (
                <Input value={item[f.key] || ''} onChange={e => update(i, f.key, e.target.value)} className="h-9 text-xs" placeholder={f.placeholder} />
              )}
            </Field>
          ))}
        </div>
      ))}
      <Button type="button" variant="outline" size="sm" onClick={add} className="w-full h-8 text-xs border-dashed">
        <Plus className="w-3 h-3 ml-1" /> {addLabel}
      </Button>
    </div>
  );
}

function GalleryEditor({ images, onChange }: { images: string[]; onChange: (imgs: string[]) => void }) {
  const safe = Array.isArray(images) ? images : [];
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-2">
        {safe.map((img, i) => (
          <div key={i} className="relative">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={img} alt="" className="w-20 h-20 object-cover rounded-lg border border-gray-200" />
            <button type="button" onClick={() => onChange(safe.filter((_, idx) => idx !== i))}
              className="absolute -top-2 -left-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center">
              <X className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>
      <div className="border-2 border-dashed border-gray-200 rounded-lg p-2">
        <ImageUploader value="" onChange={url => { if (url) onChange([...safe, url]); }} folder="pages" accept="image" />
        <p className="text-[10px] text-gray-400 mt-1 text-center">برای افزودن تصویر، آن را آپلود یا انتخاب کنید</p>
      </div>
    </div>
  );
}

// =====================================================
// Block Fields (per type)
// =====================================================
function BlockFields({ type, content, setContent }: {
  type: string; content: BlockContent; setContent: (c: BlockContent) => void;
}) {
  const set = (key: string, value: any) => setContent({ ...content, [key]: value });

  switch (type) {
    case 'hero':
      return (
        <div className="space-y-3">
          <Field label="زیرعنوان"><Input value={content.subtitle || ''} onChange={e => set('subtitle', e.target.value)} className="h-9" /></Field>
          <Field label="تصویر پس‌زمینه"><ImageUploader value={content.image || ''} onChange={v => set('image', v)} folder="pages" /></Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="متن دکمه"><Input value={content.buttonText || ''} onChange={e => set('buttonText', e.target.value)} className="h-9" /></Field>
            <Field label="لینک دکمه"><Input value={content.buttonLink || ''} onChange={e => set('buttonLink', e.target.value)} dir="ltr" className="h-9" placeholder="/special" /></Field>
          </div>
          <Field label="رنگ پس‌زمینه"><ColorInput value={content.bgColor || '#dc2626'} onChange={v => set('bgColor', v)} /></Field>
        </div>
      );
    case 'products':
      return (
        <div className="space-y-3">
          <Field label="نوع محصولات">
            <Select value={content.productType || 'bestseller'} onValueChange={v => set('productType', v)}>
              <SelectTrigger className="w-full h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="bestseller">پرفروش‌ها</SelectItem>
                <SelectItem value="new">جدیدترین‌ها</SelectItem>
                <SelectItem value="special">فروش ویژه</SelectItem>
                <SelectItem value="category">دسته خاص</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          {content.productType === 'category' && (
            <Field label="نام دسته"><Input value={content.category || ''} onChange={e => set('category', e.target.value)} className="h-9" placeholder="مثلا: اسباب‌بازی چوبی" /></Field>
          )}
          <Field label="تعداد محصولات"><Input type="number" value={content.count || 8} onChange={e => set('count', parseInt(e.target.value) || 8)} min="1" max="20" className="h-9" /></Field>
        </div>
      );
    case 'categories':
      return (
        <Field label="سبک نمایش">
          <Select value={content.style || 'circles'} onValueChange={v => set('style', v)}>
            <SelectTrigger className="w-full h-9"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="circles">دایره‌ای</SelectItem>
              <SelectItem value="cards">کارت</SelectItem>
            </SelectContent>
          </Select>
        </Field>
      );
    case 'banner':
      return (
        <div className="space-y-3">
          <Field label="تصویر"><ImageUploader value={content.image || ''} onChange={v => set('image', v)} folder="pages" /></Field>
          <Field label="لینک"><Input value={content.link || ''} onChange={e => set('link', e.target.value)} dir="ltr" className="h-9" placeholder="/special" /></Field>
          <Field label="رنگ پس‌زمینه"><ColorInput value={content.bgColor || '#dc2626'} onChange={v => set('bgColor', v)} /></Field>
        </div>
      );
    case 'text':
      return (
        <div className="space-y-3">
          <Field label="متن"><Textarea value={content.content || ''} onChange={e => set('content', e.target.value)} rows={4} /></Field>
          <Field label="ترازبندی">
            <Select value={content.alignment || 'right'} onValueChange={v => set('alignment', v)}>
              <SelectTrigger className="w-full h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="right">راست</SelectItem>
                <SelectItem value="center">وسط</SelectItem>
                <SelectItem value="left">چپ</SelectItem>
              </SelectContent>
            </Select>
          </Field>
        </div>
      );
    case 'image':
      return (
        <div className="space-y-3">
          <Field label="تصویر"><ImageUploader value={content.image || ''} onChange={v => set('image', v)} folder="pages" /></Field>
          <Field label="لینک (اختیاری)"><Input value={content.link || ''} onChange={e => set('link', e.target.value)} dir="ltr" className="h-9" /></Field>
          <Field label="کپشن (اختیاری)"><Input value={content.caption || ''} onChange={e => set('caption', e.target.value)} className="h-9" /></Field>
          <Field label="ترازبندی">
            <Select value={content.alignment || 'center'} onValueChange={v => set('alignment', v)}>
              <SelectTrigger className="w-full h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="center">وسط</SelectItem>
                <SelectItem value="left">چپ</SelectItem>
                <SelectItem value="right">راست</SelectItem>
              </SelectContent>
            </Select>
          </Field>
        </div>
      );
    case 'cta':
      return (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <Field label="متن دکمه"><Input value={content.buttonText || ''} onChange={e => set('buttonText', e.target.value)} className="h-9" /></Field>
            <Field label="لینک دکمه"><Input value={content.buttonLink || ''} onChange={e => set('buttonLink', e.target.value)} dir="ltr" className="h-9" placeholder="/contact" /></Field>
          </div>
          <Field label="رنگ دکمه"><ColorInput value={content.bgColor || '#dc2626'} onChange={v => set('bgColor', v)} /></Field>
        </div>
      );
    case 'special':
      return (
        <Field label="تعداد محصولات"><Input type="number" value={content.count || 6} onChange={e => set('count', parseInt(e.target.value) || 6)} min="1" max="20" className="h-9" /></Field>
      );
    case 'video':
      return (
        <div className="space-y-3">
          <Field label="آدرس ویدیو"><Input value={content.videoUrl || ''} onChange={e => set('videoUrl', e.target.value)} dir="ltr" className="h-9" placeholder="https://..." /></Field>
          <Field label="تصویر کاور"><ImageUploader value={content.poster || ''} onChange={v => set('poster', v)} folder="pages" /></Field>
        </div>
      );
    case 'gallery':
      return (
        <div className="space-y-3">
          <Field label="تعداد ستون‌ها">
            <Select value={String(content.columns || 3)} onValueChange={v => set('columns', parseInt(v))}>
              <SelectTrigger className="w-full h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="2">۲ ستون</SelectItem>
                <SelectItem value="3">۳ ستون</SelectItem>
                <SelectItem value="4">۴ ستون</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label="تصاویر گالری"><GalleryEditor images={Array.isArray(content.images) ? content.images : []} onChange={imgs => set('images', imgs)} /></Field>
        </div>
      );
    case 'quote':
      return (
        <div className="space-y-3">
          <Field label="متن نقل قول"><Textarea value={content.text || ''} onChange={e => set('text', e.target.value)} rows={3} /></Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="نام نویسنده"><Input value={content.author || ''} onChange={e => set('author', e.target.value)} className="h-9" /></Field>
            <Field label="سمت (اختیاری)"><Input value={content.role || ''} onChange={e => set('role', e.target.value)} className="h-9" placeholder="مدیرعامل" /></Field>
          </div>
        </div>
      );
    case 'divider':
      return (
        <div className="space-y-3">
          <Field label="سبک خط">
            <Select value={content.style || 'solid'} onValueChange={v => set('style', v)}>
              <SelectTrigger className="w-full h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="solid">ممکن</SelectItem>
                <SelectItem value="dashed">خط‌چین</SelectItem>
                <SelectItem value="dots">نقطه‌چین</SelectItem>
              </SelectContent>
            </Select>
          </Field>
          <Field label="رنگ"><ColorInput value={content.color || '#e5e7eb'} onChange={v => set('color', v)} /></Field>
        </div>
      );
    case 'features':
      return (
        <ItemListEditor
          items={Array.isArray(content.items) ? content.items : []}
          onChange={items => set('items', items)}
          addLabel="افزودن ویژگی"
          fields={[
            { key: 'icon', label: 'آیکون (ایموجی)', type: 'text', placeholder: '✨' },
            { key: 'title', label: 'عنوان', type: 'text' },
            { key: 'description', label: 'توضیح', type: 'textarea' },
          ]}
        />
      );
    case 'testimonials':
      return (
        <ItemListEditor
          items={Array.isArray(content.items) ? content.items : []}
          onChange={items => set('items', items)}
          addLabel="افزودن نظر"
          fields={[
            { key: 'name', label: 'نام', type: 'text' },
            { key: 'text', label: 'متن نظر', type: 'textarea' },
            { key: 'rating', label: 'امتیاز (۱-۵)', type: 'number' },
          ]}
        />
      );
    case 'faq':
      return (
        <ItemListEditor
          items={Array.isArray(content.items) ? content.items : []}
          onChange={items => set('items', items)}
          addLabel="افزودن پرسش"
          fields={[
            { key: 'question', label: 'پرسش', type: 'text' },
            { key: 'answer', label: 'پاسخ', type: 'textarea' },
          ]}
        />
      );
    case 'stats':
      return (
        <ItemListEditor
          items={Array.isArray(content.items) ? content.items : []}
          onChange={items => set('items', items)}
          addLabel="افزودن آمار"
          fields={[
            { key: 'number', label: 'عدد/مقدار', type: 'text', placeholder: '۱۲۰۰+' },
            { key: 'label', label: 'برچسب', type: 'text', placeholder: 'مشتری راضی' },
          ]}
        />
      );
    case 'contact':
      return (
        <Field label="توضیحات"><Textarea value={content.description || ''} onChange={e => set('description', e.target.value)} rows={3} placeholder="برای تماس با ما فرم زیر را پر کنید..." /></Field>
      );
    case 'blog':
      return (
        <Field label="تعداد مقالات"><Input type="number" value={content.count || 4} onChange={e => set('count', parseInt(e.target.value) || 4)} min="1" max="12" className="h-9" /></Field>
      );
    default:
      return <p className="text-xs text-gray-400">تنظیماتی برای این نوع بلوک تعریف نشده است.</p>;
  }
}
