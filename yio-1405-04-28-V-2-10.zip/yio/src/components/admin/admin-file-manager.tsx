'use client';

import { useState, useEffect, useRef } from 'react';
import {
  Folder, File, Image as FileImage, Video, FileText, Upload, Trash2,
  FolderPlus, ChevronRight, Home, RefreshCw, Download, Search, X,
  ArrowUp, Check, Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { formatPrice, toFa } from '@/lib/shop-data';

interface FileItem {
  name: string;
  type: 'folder' | 'file';
  size: number;
  modified: string;
  path: string;
  url: string | null;
  ext: string | null;
}

export function AdminFileManager() {
  const [items, setItems] = useState<FileItem[]>([]);
  const [currentPath, setCurrentPath] = useState('');
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [search, setSearch] = useState('');
  const [deletePath, setDeletePath] = useState<string | null>(null);
  const [showNewFolder, setShowNewFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [selectedItem, setSelectedItem] = useState<FileItem | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchFiles = async (path = currentPath) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/files?path=${encodeURIComponent(path)}`);
      if (!res.ok) return;
      const data = await res.json();
      setItems(data.items || []);
    } catch {
      toast.error('خطا در دریافت فایل‌ها');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchFiles(''); }, []);

  const navigateTo = (path: string) => {
    setCurrentPath(path);
    setSelectedItem(null);
    fetchFiles(path);
  };

  const breadcrumbs = currentPath ? currentPath.split('/') : [];

  const handleItemClick = (item: FileItem) => {
    if (item.type === 'folder') {
      navigateTo(item.path);
    } else {
      setSelectedItem(item);
    }
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    let successCount = 0;

    for (const file of Array.from(files)) {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('path', currentPath);

      try {
        const res = await fetch('/api/admin/upload', { method: 'POST', body: formData });
        if (res.ok) successCount++;
        else {
          const data = await res.json();
          toast.error(`${file.name}: ${data.error}`);
        }
      } catch {}
    }

    if (successCount > 0) {
      toast.success(`${toFa(successCount)} فایل آپلود شد`);
      fetchFiles();
    }
    setUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleDelete = async () => {
    if (!deletePath) return;
    try {
      const res = await fetch(`/api/admin/files?path=${encodeURIComponent(deletePath)}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('حذف شد');
        setDeletePath(null);
        fetchFiles();
      }
    } catch {
      toast.error('خطا در حذف');
    }
  };

  const handleCreateFolder = async () => {
    if (!newFolderName.trim()) return;
    try {
      const res = await fetch('/api/admin/files', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'mkdir', path: currentPath, name: newFolderName }),
      });
      if (res.ok) {
        toast.success('پوشه ساخته شد');
        setShowNewFolder(false);
        setNewFolderName('');
        fetchFiles();
      }
    } catch {}
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const getFileIcon = (item: FileItem) => {
    if (item.type === 'folder') return <Folder className="w-8 h-8 text-blue-500" />;
    if (['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'].includes(item.ext || '')) return <FileImage className="w-8 h-8 text-green-500" />;
    if (['.mp4', '.webm'].includes(item.ext || '')) return <Video className="w-8 h-8 text-purple-500" />;
    if (item.ext === '.pdf') return <FileText className="w-8 h-8 text-red-500" />;
    return <File className="w-8 h-8 text-gray-500" />;
  };

  const filteredItems = search
    ? items.filter(i => i.name.includes(search))
    : items;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Folder className="w-6 h-6 text-[#dc2626]" />
          فایل منیجر
        </h2>
        <div className="flex gap-2">
          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={handleUpload}
            className="hidden"
            accept="image/*,video/*,.pdf"
          />
          <Button
            variant="outline"
            size="sm"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
          >
            {uploading ? <Loader2 className="w-4 h-4 ml-1 animate-spin" /> : <Upload className="w-4 h-4 ml-1" />}
            {uploading ? 'در حال آپلود...' : 'آپلود فایل'}
          </Button>
          <Button variant="outline" size="sm" onClick={() => setShowNewFolder(true)}>
            <FolderPlus className="w-4 h-4 ml-1" />
            پوشه جدید
          </Button>
          <Button variant="outline" size="sm" onClick={() => fetchFiles()}>
            <RefreshCw className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* نوار آدرس */}
      <div className="bg-white rounded-xl p-3 shadow-sm">
        <div className="flex items-center gap-1 text-sm flex-wrap">
          <button
            onClick={() => navigateTo('')}
            className="flex items-center gap-1 px-2 py-1 hover:bg-gray-100 rounded text-[#dc2626]"
          >
            <Home className="w-4 h-4" />
            uploads
          </button>
          {breadcrumbs.map((crumb, idx) => {
            const path = breadcrumbs.slice(0, idx + 1).join('/');
            return (
              <div key={idx} className="flex items-center gap-1">
                <ChevronRight className="w-4 h-4 text-gray-400" />
                <button
                  onClick={() => navigateTo(path)}
                  className={`px-2 py-1 hover:bg-gray-100 rounded ${idx === breadcrumbs.length - 1 ? 'font-bold text-gray-900' : 'text-gray-600'}`}
                >
                  {crumb}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* جستجو */}
      <div className="bg-white rounded-xl p-3 shadow-sm">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="جستجو در فایل‌های فعلی..."
            className="pr-10"
          />
        </div>
      </div>

      {/* لیست فایل‌ها */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-8 text-center">
            <Loader2 className="w-8 h-8 mx-auto animate-spin text-[#dc2626]" />
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="p-12 text-center text-gray-500">
            <Folder className="w-16 h-16 mx-auto mb-3 text-gray-300" />
            <p>{search ? 'فایلی یافت نشد' : 'این پوشه خالی است'}</p>
            <p className="text-xs mt-2">برای افزودن فایل، روی «آپلود فایل» کلیک کنید</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 p-3">
            {filteredItems.map(item => (
              <div
                key={item.path}
                onClick={() => handleItemClick(item)}
                className={`p-3 rounded-lg border cursor-pointer transition-all hover:shadow-md ${
                  selectedItem?.path === item.path ? 'border-[#dc2626] bg-red-50' : 'border-gray-100 hover:border-gray-300'
                }`}
              >
                <div className="flex flex-col items-center text-center gap-2">
                  {item.type === 'file' && ['.jpg', '.jpeg', '.png', '.gif', '.webp'].includes(item.ext || '') ? (
                    <img src={item.url || ''} alt={item.name} className="w-12 h-12 object-cover rounded" />
                  ) : (
                    getFileIcon(item)
                  )}
                  <p className="text-xs font-medium line-clamp-2 w-full" title={item.name}>{item.name}</p>
                  {item.type === 'file' && (
                    <p className="text-[10px] text-gray-400">{formatSize(item.size)}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* پیش‌نمایش فایل انتخاب شده */}
      {selectedItem && (
        <div className="bg-white rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold">{selectedItem.name}</h3>
            <Button variant="ghost" size="icon" onClick={() => setSelectedItem(null)}>
              <X className="w-4 h-4" />
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-gray-50 rounded-lg p-4 flex items-center justify-center min-h-[200px]">
              {['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'].includes(selectedItem.ext || '') ? (
                <img src={selectedItem.url || ''} alt={selectedItem.name} className="max-w-full max-h-64 object-contain" />
              ) : ['.mp4', '.webm'].includes(selectedItem.ext || '') ? (
                <video src={selectedItem.url || ''} controls className="max-w-full max-h-64" />
              ) : (
                <File className="w-20 h-20 text-gray-400" />
              )}
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between p-2 bg-gray-50 rounded">
                <span className="text-gray-600">نام:</span>
                <span className="font-medium">{selectedItem.name}</span>
              </div>
              <div className="flex justify-between p-2 bg-gray-50 rounded">
                <span className="text-gray-600">حجم:</span>
                <span className="font-medium fa-num">{formatSize(selectedItem.size)}</span>
              </div>
              <div className="flex justify-between p-2 bg-gray-50 rounded">
                <span className="text-gray-600">نوع:</span>
                <span className="font-medium">{selectedItem.ext || 'پوشه'}</span>
              </div>
              <div className="p-2 bg-gray-50 rounded">
                <p className="text-gray-600 mb-1">URL:</p>
                <code className="text-xs bg-white p-2 rounded block break-all" dir="ltr">{selectedItem.url}</code>
              </div>
              <div className="flex gap-2 pt-2">
                {selectedItem.url && (
                  <a
                    href={selectedItem.url}
                    download={selectedItem.name}
                    className="flex-1"
                  >
                    <Button variant="outline" className="w-full">
                      <Download className="w-4 h-4 ml-1" />
                      دانلود
                    </Button>
                  </a>
                )}
                <Button
                  variant="outline"
                  onClick={() => setDeletePath(selectedItem.path)}
                  className="text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4 ml-1" />
                  حذف
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* مودال پوشه جدید */}
      {showNewFolder && (
        <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <FolderPlus className="w-5 h-5 text-[#dc2626]" />
              پوشه جدید
            </h3>
            <Input
              value={newFolderName}
              onChange={e => setNewFolderName(e.target.value)}
              placeholder="نام پوشه"
              autoFocus
              onKeyDown={e => e.key === 'Enter' && handleCreateFolder()}
            />
            <div className="flex gap-2 mt-4">
              <Button onClick={handleCreateFolder} className="flex-1 bg-[#dc2626] hover:bg-[#b91c1c]">
                ایجاد
              </Button>
              <Button variant="outline" onClick={() => { setShowNewFolder(false); setNewFolderName(''); }}>
                انصراف
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* تأیید حذف */}
      <AlertDialog open={deletePath !== null} onOpenChange={o => !o && setDeletePath(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف فایل</AlertDialogTitle>
            <AlertDialogDescription>
              آیا مطمئن هستید؟ این عملیات قابل بازگشت نیست.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
