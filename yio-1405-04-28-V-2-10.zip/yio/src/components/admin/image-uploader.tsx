'use client';

import { useState, useRef, useEffect } from 'react';
import { Upload, X, Loader2, Link as LinkIcon, FolderOpen, Search, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

interface ImageUploaderProps {
  value: string;
  onChange: (url: string) => void;
  label?: string;
  placeholder?: string;
  accept?: string; // 'image' یا 'video'
  folder?: string; // پوشه پیش‌فرض آپلود
}

interface FileItem {
  name: string;
  type: 'folder' | 'file';
  size: number;
  path: string;
  url: string | null;
  ext: string | null;
}

export function ImageUploader({
  value, onChange, label = 'تصویر', placeholder = 'URL یا آپلود کنید',
  accept = 'image', folder = 'products',
}: ImageUploaderProps) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [showUrl, setShowUrl] = useState(false);
  const [showGallery, setShowGallery] = useState(false);
  const [galleryItems, setGalleryItems] = useState<FileItem[]>([]);
  const [galleryPath, setGalleryPath] = useState('');
  const [galleryLoading, setGalleryLoading] = useState(false);
  const [gallerySearch, setGallerySearch] = useState('');

  const allowedExts = accept === 'video'
    ? ['.mp4', '.webm']
    : ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'];

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const ext = '.' + file.name.split('.').pop()?.toLowerCase();
    if (!allowedExts.includes(ext)) {
      toast.error(`فقط ${allowedExts.join(', ')} مجاز است`);
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      toast.error('حداکثر حجم ۱۰ مگابایت');
      return;
    }

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);
    formData.append('path', folder);

    try {
      const res = await fetch('/api/admin/upload', { method: 'POST', body: formData });
      const data = await res.json();
      if (res.ok) {
        onChange(data.file.url);
        toast.success('فایل آپلود شد و در گالری ذخیره شد');
      } else {
        toast.error(data.error || 'خطا در آپلود');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const fetchGallery = async (path = galleryPath) => {
    setGalleryLoading(true);
    try {
      const res = await fetch(`/api/admin/files?path=${encodeURIComponent(path)}`);
      if (res.ok) {
        const data = await res.json();
        let items = (data.items || []).filter((item: FileItem) => {
          if (item.type === 'folder') return true;
          return allowedExts.includes(item.ext || '');
        });
        if (gallerySearch) {
          items = items.filter(i => i.name.includes(gallerySearch));
        }
        setGalleryItems(items);
      }
    } catch {}
    setGalleryLoading(false);
  };

  useEffect(() => {
    if (showGallery) fetchGallery();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showGallery, galleryPath, gallerySearch]);

  const breadcrumbs = galleryPath ? galleryPath.split('/') : [];

  return (
    <div className="space-y-2">
      <input
        ref={fileRef}
        type="file"
        accept={accept === 'video' ? 'video/*' : 'image/*'}
        onChange={handleUpload}
        className="hidden"
      />

      {/* پیش‌نمایش */}
      {value && (
        <div className="relative inline-block">
          {accept === 'video' ? (
            <video src={value} className="w-24 h-24 object-cover rounded-lg border border-gray-200" muted />
          ) : (
            <img
              src={value}
              alt="پیش‌نمایش"
              className="w-24 h-24 object-cover rounded-lg border border-gray-200"
              onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
            />
          )}
          <button
            onClick={() => onChange('')}
            className="absolute -top-2 -left-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center hover:bg-red-600"
            type="button"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* دکمه‌های اصلی */}
      <div className="flex gap-1">
        {/* آپلود */}
        <Button
          type="button"
          variant="outline"
          onClick={() => fileRef.current?.click()}
          disabled={uploading}
          className="flex-1 text-[#dc2626] border-[#dc2626] hover:bg-red-50 text-xs"
        >
          {uploading ? (
            <><Loader2 className="w-3.5 h-3.5 ml-1 animate-spin" /> آپلود...</>
          ) : (
            <><Upload className="w-3.5 h-3.5 ml-1" /> آپلود</>
          )}
        </Button>

        {/* انتخاب از گالری */}
        <Button
          type="button"
          variant="outline"
          onClick={() => setShowGallery(true)}
          className="flex-1 text-blue-600 border-blue-600 hover:bg-blue-50 text-xs"
        >
          <FolderOpen className="w-3.5 h-3.5 ml-1" /> از گالری
        </Button>

        {/* ورود URL */}
        <Button
          type="button"
          variant="ghost"
          size="icon"
          onClick={() => setShowUrl(!showUrl)}
          title="ورود دستی URL"
          className="text-xs"
        >
          <LinkIcon className="w-3.5 h-3.5" />
        </Button>
      </div>

      {/* ورود دستی URL */}
      {showUrl && (
        <Input
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          dir="ltr"
          className="text-xs"
        />
      )}

      {/* مودال گالری */}
      {showGallery && (
        <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col">
            {/* هدر */}
            <div className="p-4 border-b border-gray-100 flex items-center justify-between">
              <h3 className="font-bold flex items-center gap-2">
                <FolderOpen className="w-5 h-5 text-blue-600" />
                انتخاب از گالری
              </h3>
              <Button variant="ghost" size="icon" onClick={() => setShowGallery(false)}>
                <X className="w-5 h-5" />
              </Button>
            </div>

            {/* مسیر + جستجو */}
            <div className="p-3 border-b border-gray-50 flex items-center gap-2">
              <button
                onClick={() => setGalleryPath('')}
                className="text-xs text-[#dc2626] hover:underline"
              >
                uploads
              </button>
              {breadcrumbs.map((crumb, idx) => {
                const path = breadcrumbs.slice(0, idx + 1).join('/');
                return (
                  <span key={idx} className="flex items-center gap-1">
                    <span className="text-gray-400">/</span>
                    <button
                      onClick={() => setGalleryPath(path)}
                      className="text-xs text-gray-600 hover:text-[#dc2626]"
                    >
                      {crumb}
                    </button>
                  </span>
                );
              })}
              <div className="flex-1" />
              <div className="relative w-40">
                <Search className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
                <Input
                  value={gallerySearch}
                  onChange={e => setGallerySearch(e.target.value)}
                  placeholder="جستجو..."
                  className="h-8 pr-8 text-xs"
                />
              </div>
            </div>

            {/* لیست فایل‌ها */}
            <div className="flex-1 overflow-y-auto p-4">
              {galleryLoading ? (
                <div className="text-center py-8">
                  <Loader2 className="w-8 h-8 mx-auto animate-spin text-[#dc2626]" />
                </div>
              ) : galleryItems.length === 0 ? (
                <div className="text-center py-8 text-gray-400 text-sm">
                  فایلی یافت نشد
                </div>
              ) : (
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2">
                  {galleryItems.map(item => (
                    <div
                      key={item.path}
                      onClick={() => {
                        if (item.type === 'folder') {
                          setGalleryPath(item.path);
                        } else if (item.url) {
                          onChange(item.url);
                          setShowGallery(false);
                          toast.success('فایل انتخاب شد');
                        }
                      }}
                      className={`p-2 rounded-lg border cursor-pointer transition-all hover:shadow-md ${
                        item.type === 'folder' ? 'border-blue-200 bg-blue-50/30' : 'border-gray-100'
                      } ${value === item.url ? 'border-[#dc2626] bg-red-50' : ''}`}
                    >
                      <div className="flex flex-col items-center gap-1">
                        {item.type === 'file' && ['.jpg', '.jpeg', '.png', '.gif', '.webp'].includes(item.ext || '') ? (
                          <img src={item.url || ''} alt={item.name} className="w-full aspect-square object-cover rounded" />
                        ) : item.type === 'file' && ['.mp4', '.webm'].includes(item.ext || '') ? (
                          <div className="w-full aspect-square bg-gray-900 rounded flex items-center justify-center">
                            <video src={item.url || ''} className="w-full h-full object-cover rounded" muted />
                          </div>
                        ) : (
                          <div className="w-full aspect-square flex items-center justify-center text-3xl">
                            📁
                          </div>
                        )}
                        <p className="text-[10px] text-center line-clamp-1 w-full">{item.name}</p>
                        {value === item.url && (
                          <Check className="w-4 h-4 text-[#dc2626]" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* فوتر */}
            <div className="p-3 border-t border-gray-100 flex justify-between items-center">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => fileRef.current?.click()}
                disabled={uploading}
                className="text-xs"
              >
                {uploading ? <Loader2 className="w-3.5 h-3.5 ml-1 animate-spin" /> : <Upload className="w-3.5 h-3.5 ml-1" />}
                آپلود جدید
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setShowGallery(false)}
                className="text-xs"
              >
                بستن
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
