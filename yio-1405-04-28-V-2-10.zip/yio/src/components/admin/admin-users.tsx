'use client';

import { useState, useEffect } from 'react';
import {
  Users, Search, Trash2, Edit2, X, Save, CheckCircle, XCircle,
  Phone, Mail, ShoppingBag, Heart, Loader2, MapPin, Award, Star,
  Plus, Eye, Package, Calendar, User as UserIcon, Home,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { toFa, formatPrice } from '@/lib/shop-data';
import { LocationSelector } from '@/components/shop/location-selector';
import { getUserLevel } from '@/lib/user-levels';

type DetailTab = 'info' | 'addresses' | 'orders' | 'wishlist' | 'reviews' | 'points';

export function AdminUsers() {
  const [users, setUsers] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'verified' | 'unverified'>('all');

  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [editUser, setEditUser] = useState<any>(null);
  const [editForm, setEditForm] = useState({ name: '', email: '', isVerified: false });

  // مدال جزئیات کاربر
  const [detailUser, setDetailUser] = useState<any>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailTab, setDetailTab] = useState<DetailTab>('info');

  // مدال آدرس
  const [addressForm, setAddressForm] = useState<any>(null);
  const [addressSaving, setAddressSaving] = useState(false);

  // مدال ساخت کاربر جدید
  const [showAddUser, setShowAddUser] = useState(false);
  const [addUserForm, setAddUserForm] = useState({
    name: '',
    phone: '',
    email: '',
    password: '',
    level: 1,
    isVerified: true,
  });
  const [addUserLoading, setAddUserLoading] = useState(false);

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!addUserForm.name.trim() || addUserForm.name.trim().length < 2) {
      toast.error('نام را کامل وارد کنید');
      return;
    }
    if (!/^09\d{9}$/.test(addUserForm.phone)) {
      toast.error('شماره موبایل معتبر وارد کنید');
      return;
    }
    setAddUserLoading(true);
    try {
      const res = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(addUserForm),
      });
      const data = await res.json();
      if (res.ok) {
        toast.success('کاربر جدید ساخته شد');
        setShowAddUser(false);
        setAddUserForm({ name: '', phone: '', email: '', password: '', level: 1, isVerified: true });
        fetchUsers();
      } else {
        toast.error(data.error || 'خطا در ساخت کاربر');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setAddUserLoading(false);
    }
  };

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/users?search=${encodeURIComponent(search)}`);
      if (res.ok) {
        const data = await res.json();
        setUsers(data.users || []);
        setStats(data.stats);
      }
    } catch {}
    setLoading(false);
  };

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { fetchUsers(); }, []);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    const t = setTimeout(fetchUsers, 300);
    return () => clearTimeout(t);
  }, [search]);

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      await fetch(`/api/admin/users/${deleteId}`, { method: 'DELETE' });
      toast.success('کاربر حذف شد');
      setDeleteId(null);
      fetchUsers();
    } catch {}
  };

  const handleSaveEdit = async () => {
    try {
      const res = await fetch(`/api/admin/users/${editUser.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editForm),
      });
      if (res.ok) {
        toast.success('ویرایش شد');
        setEditUser(null);
        fetchUsers();
      }
    } catch {}
  };

  const toggleVerified = async (user: any) => {
    try {
      await fetch(`/api/admin/users/${user.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isVerified: !user.isVerified }),
      });
      fetchUsers();
    } catch {}
  };

  // باز کردن مدال جزئیات کاربر
  const openDetail = async (userId: number) => {
    setDetailLoading(true);
    setDetailUser({ id: userId });
    setDetailTab('info');
    try {
      const res = await fetch(`/api/admin/users/${userId}`);
      if (res.ok) {
        const data = await res.json();
        setDetailUser(data.user);
      } else {
        toast.error('خطا در دریافت اطلاعات');
        setDetailUser(null);
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
      setDetailUser(null);
    }
    setDetailLoading(false);
  };

  // باز کردن فرم آدرس (جدید یا ویرایش)
  const openAddressForm = (address?: any) => {
    setAddressForm(address || {
      title: '', recipientName: '', phone: '', province: '', city: '',
      address: '', postalCode: '', isDefault: false,
    });
  };

  // ذخیره آدرس
  const handleSaveAddress = async () => {
    if (!detailUser) return;
    setAddressSaving(true);
    try {
      const isEdit = !!addressForm.id;
      const url = isEdit
        ? `/api/admin/users/${detailUser.id}/addresses/${addressForm.id}`
        : `/api/admin/users/${detailUser.id}/addresses`;
      const res = await fetch(url, {
        method: isEdit ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(addressForm),
      });
      if (res.ok) {
        toast.success(isEdit ? 'آدرس ویرایش شد' : 'آدرس اضافه شد');
        setAddressForm(null);
        // refresh detail
        openDetail(detailUser.id);
      } else {
        const data = await res.json();
        toast.error(data.error || 'خطا');
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
    }
    setAddressSaving(false);
  };

  // حذف آدرس
  const handleDeleteAddress = async (addressId: number) => {
    if (!detailUser) return;
    if (!confirm('آیا از حذف این آدرس مطمئن هستید؟')) return;
    try {
      const res = await fetch(`/api/admin/users/${detailUser.id}/addresses/${addressId}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        toast.success('آدرس حذف شد');
        openDetail(detailUser.id);
      }
    } catch {}
  };

  const formatDate = (d: string) => {
    return new Intl.DateTimeFormat('fa-IR', { year: 'numeric', month: 'short', day: 'numeric' }).format(new Date(d));
  };

  const formatDateTime = (d: string) => {
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit',
    }).format(new Date(d));
  };

  // فیلتر کاربران
  const filteredUsers = users.filter(u => {
    if (filter === 'verified') return u.isVerified;
    if (filter === 'unverified') return !u.isVerified;
    return true;
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Users className="w-6 h-6 text-[#dc2626]" />
          مدیریت اعضا
        </h2>
        {/* دکمه عضو جدید */}
        <Button
          onClick={() => setShowAddUser(true)}
          className="bg-[#dc2626] hover:bg-[#b91c1c]"
        >
          <Plus className="w-4 h-4 ml-1" />
          عضو جدید
        </Button>
      </div>

      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'کل اعضا', value: stats.total, color: 'text-blue-600', bg: 'bg-blue-50' },
            { label: 'تأیید شده', value: stats.verified, color: 'text-green-600', bg: 'bg-green-50' },
            { label: 'تأیید نشده', value: stats.unverified, color: 'text-amber-600', bg: 'bg-amber-50' },
            { label: 'جدید (۳۰ روز)', value: stats.newThisMonth, color: 'text-purple-600', bg: 'bg-purple-50' },
          ].map((c, i) => (
            <div key={i} className={`bg-white rounded-xl p-4 border border-gray-100 ${c.bg}`}>
              <p className="text-xs text-gray-500">{c.label}</p>
              <p className={`text-2xl font-bold fa-num ${c.color}`}>{toFa(c.value)}</p>
            </div>
          ))}
        </div>
      )}

      {/* جستجو و فیلتر */}
      <div className="bg-white rounded-xl p-3 shadow-sm space-y-2">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="جستجو با نام، موبایل یا ایمیل..." className="pr-10" />
        </div>
        <div className="flex gap-1">
          {[
            { key: 'all', label: 'همه' },
            { key: 'verified', label: 'تأیید شده' },
            { key: 'unverified', label: 'تأیید نشده' },
          ].map(f => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key as any)}
              className={`px-3 py-1 rounded-lg text-xs font-medium ${
                filter === f.key ? 'bg-[#dc2626] text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* لیست کاربران */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-8 text-center"><Loader2 className="w-8 h-8 mx-auto animate-spin text-[#dc2626]" /></div>
        ) : filteredUsers.length === 0 ? (
          <div className="p-12 text-center text-gray-500">
            <Users className="w-12 h-12 mx-auto mb-3 text-gray-200" />
            کاربری یافت نشد
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {filteredUsers.map(user => (
              <div key={user.id} className="p-4 flex items-center justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#dc2626] to-[#991b1b] text-white flex items-center justify-center text-sm font-bold ml-1">
                      {(user.name || user.phone).charAt(0)}
                    </div>
                    <h3 className="font-bold">{user.name || 'بدون نام'}</h3>
                    {/* Badge سطح کاربر */}
                    {(() => {
                      const lvl = user.level || 1;
                      const lvlInfo = getUserLevel(lvl);
                      return (
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1 ${lvlInfo.bgColor} ${lvlInfo.color}`} title={lvlInfo.description}>
                          <span>{lvlInfo.icon}</span>
                          <span>سطح {toFa(lvl)} - {lvlInfo.title}</span>
                        </span>
                      );
                    })()}
                    {user.isVerified ? (
                      <span className="bg-green-50 text-green-700 text-[10px] px-2 py-0.5 rounded flex items-center gap-1">
                        <CheckCircle className="w-3 h-3" /> تأیید شده
                      </span>
                    ) : (
                      <span className="bg-amber-50 text-amber-700 text-[10px] px-2 py-0.5 rounded flex items-center gap-1">
                        <XCircle className="w-3 h-3" /> تأیید نشده
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-xs text-gray-500 flex-wrap">
                    <span className="flex items-center gap-1" dir="ltr"><Phone className="w-3 h-3" /> {user.phone}</span>
                    {user.email && <span className="flex items-center gap-1" dir="ltr"><Mail className="w-3 h-3" /> {user.email}</span>}
                    <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {formatDate(user.createdAt)}</span>
                  </div>
                  <div className="flex items-center gap-3 text-[10px] text-gray-400 mt-1">
                    <span className="flex items-center gap-1"><ShoppingBag className="w-2.5 h-2.5" /> {toFa(user._count.orders)} سفارش</span>
                    <span className="flex items-center gap-1"><Heart className="w-2.5 h-2.5" /> {toFa(user._count.wishlist)} علاقه‌مندی</span>
                    <span className="flex items-center gap-1"><Star className="w-2.5 h-2.5" /> {toFa(user._count.reviews)} نظر</span>
                  </div>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <Button variant="outline" size="sm" onClick={() => openDetail(user.id)} className="h-8 text-xs" title="مشاهده جزئیات">
                    <Eye className="w-3 h-3 ml-1" />
                    جزئیات
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => { setEditUser(user); setEditForm({ name: user.name || '', email: user.email || '', isVerified: user.isVerified }); }} className="h-8 text-xs px-2" title="ویرایش">
                    <Edit2 className="w-3 h-3" />
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => setDeleteId(user.id)} className="h-8 text-xs text-red-600 px-2" title="حذف">
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ===================== مدال جزئیات کاربر ===================== */}
      {detailUser && (
        <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-2 md:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl my-4 max-h-[95vh] overflow-hidden flex flex-col">
            {/* هدر */}
            <div className="sticky top-0 bg-gradient-to-l from-[#dc2626] to-[#991b1b] text-white p-4 flex items-center justify-between z-10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center text-lg font-bold">
                  {(detailUser.name || detailUser.phone || '?').charAt(0)}
                </div>
                <div>
                  <h2 className="font-bold">{detailUser.name || 'بدون نام'}</h2>
                  <p className="text-xs opacity-90" dir="ltr">{detailUser.phone}</p>
                </div>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setDetailUser(null)} className="text-white hover:bg-white/20">
                <X className="w-5 h-5" />
              </Button>
            </div>

            {detailLoading ? (
              <div className="p-12 text-center">
                <Loader2 className="w-8 h-8 mx-auto animate-spin text-[#dc2626]" />
              </div>
            ) : (
              <>
                {/* تب‌ها */}
                <div className="border-b border-gray-100 px-2 py-2 flex gap-1 overflow-x-auto bg-gray-50 shrink-0">
                  {[
                    { key: 'info', label: 'اطلاعات', icon: UserIcon },
                    { key: 'addresses', label: `آدرس‌ها (${toFa(detailUser.addresses?.length || 0)})`, icon: MapPin },
                    { key: 'orders', label: `سفارش‌ها (${toFa(detailUser._count?.orders || 0)})`, icon: ShoppingBag },
                    { key: 'wishlist', label: `علاقه‌مندی (${toFa(detailUser._count?.wishlist || 0)})`, icon: Heart },
                    { key: 'reviews', label: `نظرات (${toFa(detailUser._count?.reviews || 0)})`, icon: Star },
                    { key: 'points', label: `امتیازات`, icon: Award },
                  ].map(t => {
                    const Icon = t.icon;
                    return (
                      <button
                        key={t.key}
                        onClick={() => setDetailTab(t.key as DetailTab)}
                        className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium whitespace-nowrap ${
                          detailTab === t.key ? 'bg-[#dc2626] text-white' : 'text-gray-600 hover:bg-gray-100'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5" />
                        {t.label}
                      </button>
                    );
                  })}
                </div>

                {/* محتوای تب */}
                <div className="flex-1 overflow-y-auto p-4">
                  {/* تب اطلاعات */}
                  {detailTab === 'info' && (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-3">
                        <div className="bg-gray-50 rounded-lg p-3">
                          <p className="text-xs text-gray-500 mb-1">نام</p>
                          <p className="font-medium">{detailUser.name || '—'}</p>
                        </div>
                        <div className="bg-gray-50 rounded-lg p-3">
                          <p className="text-xs text-gray-500 mb-1">موبایل</p>
                          <p className="font-medium" dir="ltr">{detailUser.phone}</p>
                        </div>
                        <div className="bg-gray-50 rounded-lg p-3">
                          <p className="text-xs text-gray-500 mb-1">ایمیل</p>
                          <p className="font-medium" dir="ltr">{detailUser.email || '—'}</p>
                        </div>
                        <div className="bg-gray-50 rounded-lg p-3">
                          <p className="text-xs text-gray-500 mb-1">وضعیت تأیید</p>
                          <p className="font-medium">
                            {detailUser.isVerified ? (
                              <span className="text-green-600 flex items-center gap-1"><CheckCircle className="w-4 h-4" /> تأیید شده</span>
                            ) : (
                              <span className="text-amber-600 flex items-center gap-1"><XCircle className="w-4 h-4" /> تأیید نشده</span>
                            )}
                          </p>
                        </div>
                        <div className="bg-gray-50 rounded-lg p-3">
                          <p className="text-xs text-gray-500 mb-1">تاریخ عضویت</p>
                          <p className="font-medium">{formatDateTime(detailUser.createdAt)}</p>
                        </div>
                        <div className="bg-gray-50 rounded-lg p-3">
                          <p className="text-xs text-gray-500 mb-1">آخرین به‌روزرسانی</p>
                          <p className="font-medium">{formatDateTime(detailUser.updatedAt)}</p>
                        </div>
                      </div>

                      {/* آمار کلی */}
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-2">
                        <div className="bg-blue-50 rounded-lg p-3 text-center">
                          <ShoppingBag className="w-5 h-5 mx-auto text-blue-600 mb-1" />
                          <p className="text-xl font-bold text-blue-600 fa-num">{toFa(detailUser._count?.orders || 0)}</p>
                          <p className="text-[10px] text-gray-500">سفارش</p>
                        </div>
                        <div className="bg-red-50 rounded-lg p-3 text-center">
                          <Heart className="w-5 h-5 mx-auto text-red-600 mb-1" />
                          <p className="text-xl font-bold text-red-600 fa-num">{toFa(detailUser._count?.wishlist || 0)}</p>
                          <p className="text-[10px] text-gray-500">علاقه‌مندی</p>
                        </div>
                        <div className="bg-amber-50 rounded-lg p-3 text-center">
                          <Star className="w-5 h-5 mx-auto text-amber-600 mb-1" />
                          <p className="text-xl font-bold text-amber-600 fa-num">{toFa(detailUser._count?.reviews || 0)}</p>
                          <p className="text-[10px] text-gray-500">نظر</p>
                        </div>
                        <div className="bg-purple-50 rounded-lg p-3 text-center">
                          <Award className="w-5 h-5 mx-auto text-purple-600 mb-1" />
                          <p className="text-xl font-bold text-purple-600 fa-num">{toFa(detailUser.totalLoyaltyPoints || 0)}</p>
                          <p className="text-[10px] text-gray-500">امتیاز</p>
                        </div>
                      </div>

                      {/* دکمه‌های اقدام */}
                      <div className="flex gap-2 pt-2">
                        <Button
                          onClick={() => {
                            setEditUser(detailUser);
                            setEditForm({
                              name: detailUser.name || '',
                              email: detailUser.email || '',
                              isVerified: detailUser.isVerified,
                            });
                          }}
                          className="flex-1 bg-[#dc2626] hover:bg-[#b91c1c]"
                        >
                          <Edit2 className="w-4 h-4 ml-1" />
                          ویرایش اطلاعات
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => toggleVerified(detailUser)}
                        >
                          {detailUser.isVerified ? 'لغو تأیید' : 'تأیید کاربر'}
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* تب آدرس‌ها */}
                  {detailTab === 'addresses' && (
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <h3 className="font-bold text-sm">آدرس‌های کاربر</h3>
                        <Button size="sm" onClick={() => openAddressForm()} className="bg-[#dc2626] hover:bg-[#b91c1c] h-8 text-xs">
                          <Plus className="w-3 h-3 ml-1" />
                          آدرس جدید
                        </Button>
                      </div>

                      {detailUser.addresses?.length === 0 ? (
                        <div className="bg-gray-50 rounded-lg p-8 text-center text-gray-500">
                          <MapPin className="w-10 h-10 mx-auto mb-2 text-gray-300" />
                          این کاربر هنوز آدرسی ثبت نکرده است
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {detailUser.addresses?.map((addr: any) => (
                            <div key={addr.id} className="border border-gray-200 rounded-lg p-3 hover:shadow-sm">
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-1">
                                    <Home className="w-4 h-4 text-[#dc2626]" />
                                    <span className="font-bold text-sm">{addr.title}</span>
                                    {addr.isDefault && (
                                      <span className="bg-green-50 text-green-700 text-[10px] px-2 py-0.5 rounded">پیش‌فرض</span>
                                    )}
                                  </div>
                                  <p className="text-xs text-gray-600">
                                    <span className="font-medium">{addr.recipientName}</span>
                                    <span dir="ltr" className="mx-2">{addr.phone}</span>
                                  </p>
                                  <p className="text-xs text-gray-600 mt-1">
                                    {addr.province}، {addr.city} — {addr.address}
                                  </p>
                                  {addr.postalCode && (
                                    <p className="text-[10px] text-gray-400 mt-1" dir="ltr">کد پستی: {addr.postalCode}</p>
                                  )}
                                </div>
                                <div className="flex gap-1 shrink-0">
                                  <Button size="sm" variant="outline" onClick={() => openAddressForm(addr)} className="h-7 px-2">
                                    <Edit2 className="w-3 h-3" />
                                  </Button>
                                  <Button size="sm" variant="outline" onClick={() => handleDeleteAddress(addr.id)} className="h-7 px-2 text-red-600">
                                    <Trash2 className="w-3 h-3" />
                                  </Button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {/* تب سفارشات */}
                  {detailTab === 'orders' && (
                    <div className="space-y-2">
                      {detailUser.orders?.length === 0 ? (
                        <div className="bg-gray-50 rounded-lg p-8 text-center text-gray-500">
                          <Package className="w-10 h-10 mx-auto mb-2 text-gray-300" />
                          این کاربر هنوز سفارشی ثبت نکرده است
                        </div>
                      ) : (
                        detailUser.orders?.map((order: any) => (
                          <div key={order.id} className="border border-gray-200 rounded-lg p-3">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <span className="font-bold text-sm" dir="ltr">{order.orderNumber}</span>
                                <span className={`text-[10px] px-2 py-0.5 rounded ${
                                  order.status === 'delivered' ? 'bg-green-50 text-green-700' :
                                  order.status === 'cancelled' ? 'bg-red-50 text-red-700' :
                                  'bg-amber-50 text-amber-700'
                                }`}>
                                  {order.status === 'pending' ? 'در انتظار' :
                                   order.status === 'confirmed' ? 'تأیید شده' :
                                   order.status === 'shipping' ? 'در حال ارسال' :
                                   order.status === 'delivered' ? 'تحویل شده' :
                                   order.status === 'cancelled' ? 'لغو شده' : order.status}
                                </span>
                              </div>
                              <span className="text-xs text-gray-500">{formatDateTime(order.createdAt)}</span>
                            </div>
                            <div className="flex items-center justify-between text-xs">
                              <div className="text-gray-600">
                                {order.items.length} کالا •
                                <span className={`mr-1 ${order.paymentStatus === 'paid' ? 'text-green-600' : 'text-amber-600'}`}>
                                  {order.paymentStatus === 'paid' ? 'پرداخت شده' :
                                   order.paymentStatus === 'refunded' ? 'بازگشت داده شده' : 'پرداخت نشده'}
                                </span>
                              </div>
                              <span className="font-bold text-[#dc2626] fa-num">
                                {formatPrice(order.finalAmount)} ت
                              </span>
                            </div>
                            {order.trackingCode && (
                              <p className="text-[10px] text-gray-400 mt-1" dir="ltr">کد رهگیری: {order.trackingCode}</p>
                            )}
                          </div>
                        ))
                      )}
                    </div>
                  )}

                  {/* تب علاقه‌مندی */}
                  {detailTab === 'wishlist' && (
                    <div className="space-y-2">
                      {detailUser.wishlist?.length === 0 ? (
                        <div className="bg-gray-50 rounded-lg p-8 text-center text-gray-500">
                          <Heart className="w-10 h-10 mx-auto mb-2 text-gray-300" />
                          این کاربر محصولی به علاقه‌مندی‌ها اضافه نکرده است
                        </div>
                      ) : (
                        detailUser.wishlist?.map((w: any) => (
                          <div key={w.id} className="border border-gray-200 rounded-lg p-3 flex gap-3">
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img src={w.product.image} alt={w.product.title} className="w-14 h-14 object-cover rounded-lg" />
                            <div className="flex-1">
                              <p className="text-sm font-medium line-clamp-1">{w.product.title}</p>
                              <div className="flex items-center gap-2 mt-1">
                                <span className="text-xs font-bold text-[#dc2626] fa-num">
                                  {formatPrice(w.product.discountPrice ?? w.product.price)} ت
                                </span>
                                <span className={`text-[10px] px-2 py-0.5 rounded ${
                                  w.product.inStock ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
                                }`}>
                                  {w.product.inStock ? 'موجود' : 'ناموجود'}
                                </span>
                              </div>
                              <p className="text-[10px] text-gray-400 mt-1">افزوده شده: {formatDate(w.createdAt)}</p>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  )}

                  {/* تب نظرات */}
                  {detailTab === 'reviews' && (
                    <div className="space-y-2">
                      {detailUser.reviews?.length === 0 ? (
                        <div className="bg-gray-50 rounded-lg p-8 text-center text-gray-500">
                          <Star className="w-10 h-10 mx-auto mb-2 text-gray-300" />
                          این کاربر نظری ثبت نکرده است
                        </div>
                      ) : (
                        detailUser.reviews?.map((r: any) => (
                          <div key={r.id} className="border border-gray-200 rounded-lg p-3">
                            <div className="flex items-center justify-between mb-1">
                              <div className="flex items-center gap-1">
                                {[1,2,3,4,5].map(i => (
                                  <Star key={i} className={`w-3 h-3 ${i <= r.rating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`} />
                                ))}
                                <span className="text-xs text-gray-500 mr-2">برای: {r.product?.title}</span>
                              </div>
                              <span className={`text-[10px] px-2 py-0.5 rounded ${r.isActive ? 'bg-green-50 text-green-700' : 'bg-gray-100 text-gray-600'}`}>
                                {r.isActive ? 'فعال' : 'غیرفعال'}
                              </span>
                            </div>
                            {r.comment && <p className="text-xs text-gray-600 mt-1">{r.comment}</p>}
                            <p className="text-[10px] text-gray-400 mt-1">{formatDate(r.createdAt)}</p>
                          </div>
                        ))
                      )}
                    </div>
                  )}

                  {/* تب امتیازات */}
                  {detailTab === 'points' && (
                    <div className="space-y-3">
                      <div className="bg-gradient-to-l from-purple-500 to-purple-700 rounded-xl p-4 text-white">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-xs opacity-90">مجموع امتیازات وفاداری</p>
                            <p className="text-3xl font-bold fa-num">{toFa(detailUser.totalLoyaltyPoints || 0)}</p>
                          </div>
                          <Award className="w-10 h-10 opacity-50" />
                        </div>
                      </div>

                      {detailUser.loyaltyPoints?.length === 0 ? (
                        <div className="bg-gray-50 rounded-lg p-8 text-center text-gray-500">
                          <Award className="w-10 h-10 mx-auto mb-2 text-gray-300" />
                          هنوز امتیازی کسب نشده است
                        </div>
                      ) : (
                        detailUser.loyaltyPoints?.map((p: any) => (
                          <div key={p.id} className="border border-gray-200 rounded-lg p-3 flex items-center justify-between">
                            <div>
                              <p className="text-sm font-medium">
                                {p.reason === 'purchase' ? 'خرید' :
                                 p.reason === 'review' ? 'ثبت نظر' :
                                 p.reason === 'signup' ? 'ثبت‌نام' :
                                 p.reason === 'referral' ? 'معرفی دوست' : p.reason}
                              </p>
                              <p className="text-[10px] text-gray-400">{formatDateTime(p.createdAt)}</p>
                            </div>
                            <span className="font-bold text-green-600 fa-num">+{toFa(p.points)}</span>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* ===================== مدال ویرایش کاربر ===================== */}
      {editUser && (
        <div className="fixed inset-0 z-[60] bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold">ویرایش کاربر</h3>
              <Button variant="ghost" size="icon" onClick={() => setEditUser(null)}><X className="w-5 h-5" /></Button>
            </div>
            <div className="space-y-3">
              <div className="space-y-2">
                <Label>نام</Label>
                <Input value={editForm.name} onChange={e => setEditForm({ ...editForm, name: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>ایمیل</Label>
                <Input value={editForm.email} onChange={e => setEditForm({ ...editForm, email: e.target.value })} dir="ltr" />
              </div>
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <Label>تأیید شده</Label>
                <Switch checked={editForm.isVerified} onCheckedChange={v => setEditForm({ ...editForm, isVerified: v })} />
              </div>
              <div className="flex gap-2">
                <Button onClick={handleSaveEdit} className="flex-1 bg-[#dc2626] hover:bg-[#b91c1c]"><Save className="w-4 h-4 ml-1" /> ذخیره</Button>
                <Button variant="outline" onClick={() => setEditUser(null)}>انصراف</Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================== مدال آدرس (جدید/ویرایش) ===================== */}
      {addressForm && detailUser && (
        <div className="fixed inset-0 z-[60] bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-2 md:p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg my-4">
            <div className="p-4 border-b border-gray-100 flex items-center justify-between">
              <h3 className="font-bold">{addressForm.id ? 'ویرایش آدرس' : 'آدرس جدید'}</h3>
              <Button variant="ghost" size="icon" onClick={() => setAddressForm(null)}><X className="w-5 h-5" /></Button>
            </div>
            <div className="p-4 space-y-3">
              <div className="space-y-2">
                <Label>عنوان آدرس *</Label>
                <Input
                  value={addressForm.title}
                  onChange={e => setAddressForm({ ...addressForm, title: e.target.value })}
                  placeholder="مثلاً: خانه، محل کار"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label>نام گیرنده *</Label>
                  <Input
                    value={addressForm.recipientName}
                    onChange={e => setAddressForm({ ...addressForm, recipientName: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>موبایل *</Label>
                  <Input
                    value={addressForm.phone}
                    onChange={e => setAddressForm({ ...addressForm, phone: e.target.value })}
                    dir="ltr"
                    placeholder="09121234567"
                  />
                </div>
              </div>
              <LocationSelector
                province={addressForm.province}
                city={addressForm.city}
                onProvinceChange={v => setAddressForm({ ...addressForm, province: v })}
                onCityChange={v => setAddressForm({ ...addressForm, city: v })}
                required
              />
              <div className="space-y-2">
                <Label>آدرس کامل *</Label>
                <Textarea
                  value={addressForm.address}
                  onChange={e => setAddressForm({ ...addressForm, address: e.target.value })}
                  placeholder="خیابان، کوچه، پلاک، واحد"
                  rows={2}
                />
              </div>
              <div className="space-y-2">
                <Label>کد پستی</Label>
                <Input
                  value={addressForm.postalCode || ''}
                  onChange={e => setAddressForm({ ...addressForm, postalCode: e.target.value })}
                  dir="ltr"
                />
              </div>
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <Label>آدرس پیش‌فرض</Label>
                <Switch
                  checked={addressForm.isDefault}
                  onCheckedChange={v => setAddressForm({ ...addressForm, isDefault: v })}
                />
              </div>
              <div className="flex gap-2 pt-2">
                <Button
                  onClick={handleSaveAddress}
                  disabled={addressSaving}
                  className="flex-1 bg-[#dc2626] hover:bg-[#b91c1c]"
                >
                  {addressSaving ? <Loader2 className="w-4 h-4 ml-1 animate-spin" /> : <Save className="w-4 h-4 ml-1" />}
                  ذخیره
                </Button>
                <Button variant="outline" onClick={() => setAddressForm(null)}>انصراف</Button>
              </div>
            </div>
          </div>
        </div>
      )}

      <AlertDialog open={deleteId !== null} onOpenChange={o => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف کاربر</AlertDialogTitle>
            <AlertDialogDescription>آیا مطمئن هستید؟ تمام اطلاعات کاربر (سفارشات، آدرس‌ها، علاقه‌مندی‌ها) حذف می‌شود.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">حذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* مودال ساخت کاربر جدید */}
      {showAddUser && (
        <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-100 p-4 flex items-center justify-between">
              <h3 className="font-bold flex items-center gap-2">
                <UserIcon className="w-5 h-5 text-[#dc2626]" />
                افزودن عضو جدید
              </h3>
              <button
                onClick={() => setShowAddUser(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <form onSubmit={handleAddUser} className="p-4 space-y-3">
              <div className="space-y-2">
                <Label htmlFor="add-name">نام و نام خانوادگی *</Label>
                <Input
                  id="add-name"
                  value={addUserForm.name}
                  onChange={e => setAddUserForm({ ...addUserForm, name: e.target.value })}
                  placeholder="مثلا: محمد رضایی"
                  required
                  autoFocus
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="add-phone">شماره موبایل *</Label>
                <Input
                  id="add-phone"
                  value={addUserForm.phone}
                  onChange={e => setAddUserForm({ ...addUserForm, phone: e.target.value })}
                  placeholder="09121234567"
                  dir="ltr"
                  className="text-left"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="add-email">ایمیل (اختیاری)</Label>
                <Input
                  id="add-email"
                  type="email"
                  value={addUserForm.email}
                  onChange={e => setAddUserForm({ ...addUserForm, email: e.target.value })}
                  placeholder="you@example.com"
                  dir="ltr"
                  className="text-left"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="add-password">رمز عبور (اختیاری)</Label>
                <Input
                  id="add-password"
                  type="password"
                  value={addUserForm.password}
                  onChange={e => setAddUserForm({ ...addUserForm, password: e.target.value })}
                  placeholder="اگر خالی باشد، کاربر با OTP وارد می‌شود"
                  dir="ltr"
                  className="text-left"
                />
              </div>

              <div className="space-y-2">
                <Label>سطح کاربری</Label>
                <div className="grid grid-cols-5 gap-1">
                  {[1, 2, 3, 4, 5].map(l => (
                    <button
                      key={l}
                      type="button"
                      onClick={() => setAddUserForm({ ...addUserForm, level: l })}
                      className={`py-2 rounded-md text-xs font-bold transition-all ${
                        addUserForm.level === l
                          ? 'bg-[#dc2626] text-white'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {toFa(l)}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-gray-500">
                  {addUserForm.level === 1 && '🌱 تازه‌وارد'}
                  {addUserForm.level === 2 && '📝 تکمیل‌شده'}
                  {addUserForm.level === 3 && '⭐ فعال'}
                  {addUserForm.level === 4 && '💎 حرفه‌ای'}
                  {addUserForm.level === 5 && '🏢 سازمانی'}
                </p>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <Label htmlFor="add-verified" className="cursor-pointer">حساب تأیید شده</Label>
                <Switch
                  id="add-verified"
                  checked={addUserForm.isVerified}
                  onCheckedChange={v => setAddUserForm({ ...addUserForm, isVerified: v })}
                />
              </div>

              <div className="flex gap-2 pt-2">
                <Button
                  type="submit"
                  disabled={addUserLoading}
                  className="flex-1 bg-[#dc2626] hover:bg-[#b91c1c] h-12"
                >
                  {addUserLoading ? (
                    <Loader2 className="w-4 h-4 ml-1 animate-spin" />
                  ) : (
                    <Save className="w-4 h-4 ml-1" />
                  )}
                  {addUserLoading ? 'در حال ساخت...' : 'ایجاد کاربر'}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowAddUser(false)}
                  className="h-12 px-6"
                >
                  انصراف
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
