'use client';

import dynamic from 'next/dynamic';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Editor = dynamic(
  () => import('@/components/page-builder/Editor').then((m) => m.Editor),
  {
    ssr: false,
    loading: () => (
      <div className="flex items-center justify-center h-96">
        <div className="inline-block w-12 h-12 border-4 border-gray-200 border-t-[#dc2626] rounded-full animate-spin"></div>
      </div>
    ),
  },
);

interface AdminPageBuilderProps {
  onExit: () => void;
}

export function AdminPageBuilder({ onExit }: AdminPageBuilderProps) {
  return (
    <div className="space-y-3">
      {/* هدر */}
      <div className="bg-white rounded-xl p-3 shadow-sm flex items-center justify-between">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <span className="text-2xl">🎨</span>
          صفحه‌ساز حرفه‌ای
        </h2>
        <Button variant="outline" size="sm" onClick={onExit}>
          <ArrowRight className="w-4 h-4 ml-1" />
          بازگشت
        </Button>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-sm text-blue-800">
        💡 ویجت‌ها را از پنل کناری به صفحه بکشید. در موبایل از نوار پایین برای تغییر پنل استفاده کنید.
      </div>

      {/* Editor — ارتفاع کافی برای کل صفحه */}
      <div
        className="bg-white rounded-xl overflow-hidden shadow-sm"
        style={{ height: 'calc(100vh - 200px)', minHeight: '500px' }}
      >
        <Editor />
      </div>
    </div>
  );
}
