'use client';

import { useState, useEffect } from 'react';
import { X, Save, Plus, Image as ImageIcon, Trash2, Video, Play, Link as LinkIcon, Sparkles, Loader2, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { categories, parseImages, parseVideos, toFa } from '@/lib/shop-data';
import { ImageUploader } from './image-uploader';

interface ProductFormProps {
  product?: any;
  onSave: () => void;
  onCancel: () => void;
}

interface ColorItem {
  name: string;
  code: string;
}

const woodTypes = ['چوب راش', 'چوب بامبو', 'چوب بلوط', 'چوب گردو', 'چوب MDF', 'چوب ممرز', 'چوب افرا', 'چوب فشرده'];
const MAX_IMAGES = 10;
const MAX_VIDEOS = 3;

export function ProductForm({ product, onSave, onCancel }: ProductFormProps) {
  const [loading, setLoading] = useState(false);
  const [aiGenerating, setAiGenerating] = useState(false);
  const [aiGenerated, setAiGenerated] = useState(false);
  const [colors, setColors] = useState<ColorItem[]>([]);
  const [newColorName, setNewColorName] = useState('');
  const [newColorCode, setNewColorCode] = useState('#000000');

  const [images, setImages] = useState<string[]>([]);
  const [newImageUrl, setNewImageUrl] = useState('');

  const [videos, setVideos] = useState<string[]>([]);
  const [newVideoUrl, setNewVideoUrl] = useState('');

  const [formData, setFormData] = useState({
    title: '',
    brand: 'YIO',
    category: 'اسباب‌بازی چوبی',
    price: '',
    discountPrice: '',
    image: '',
    rating: '0',
    ratingCount: '0',
    fastDelivery: true,
    isSpecial: false,
    isPublished: true,
    stockQuantity: '0',
    description: '',
    woodType: 'چوب راش',
  });

  useEffect(() => {
    if (product) {
      setFormData({
        title: product.title || '',
        brand: product.brand || 'YIO',
        category: product.category || 'اسباب‌بازی چوبی',
        price: String(product.price || ''),
        discountPrice: product.discountPrice ? String(product.discountPrice) : '',
        image: product.image || '',
        rating: String(product.rating || 0),
        ratingCount: String(product.ratingCount || 0),
        fastDelivery: product.fastDelivery ?? true,
        isSpecial: product.isSpecial ?? false,
        isPublished: product.isPublished ?? true,
        stockQuantity: String(product.stockQuantity || 0),
        description: product.description || '',
        woodType: product.woodType || 'چوب راش',
      });

      setImages(parseImages(product.images));
      setVideos(parseVideos(product.videos));

      try {
        if (product.colors) {
          const parsed = typeof product.colors === 'string' ? JSON.parse(product.colors) : product.colors;
          setColors(parsed || []);
        }
      } catch {
        setColors([]);
      }
    }
  }, [product]);

  // مدیریت تصاویر
  const handleAddImage = () => {
    if (!newImageUrl.trim() || !newImageUrl.startsWith('http')) {
      toast.error('آدرس تصویر معتبر وارد کنید (با http شروع شود)');
      return;
    }
    if (images.length >= MAX_IMAGES) {
      toast.error(`حداکثر ${toFa(MAX_IMAGES)} تصویر مجاز است`);
      return;
    }
    setImages([...images, newImageUrl.trim()]);
    setNewImageUrl('');
  };

  const handleRemoveImage = (idx: number) => {
    setImages(images.filter((_, i) => i !== idx));
  };

  // مدیریت ویدیوها
  const handleAddVideo = () => {
    if (!newVideoUrl.trim() || !newVideoUrl.startsWith('http')) {
      toast.error('آدرس ویدیو معتبر وارد کنید (با http شروع شود)');
      return;
    }
    if (videos.length >= MAX_VIDEOS) {
      toast.error(`حداکثر ${toFa(MAX_VIDEOS)} ویدیو مجاز است`);
      return;
    }
    setVideos([...videos, newVideoUrl.trim()]);
    setNewVideoUrl('');
  };

  const handleRemoveVideo = (idx: number) => {
    setVideos(videos.filter((_, i) => i !== idx));
  };

  const handleAddColor = () => {
    if (!newColorName.trim()) {
      toast.error('نام رنگ را وارد کنید');
      return;
    }
    setColors([...colors, { name: newColorName.trim(), code: newColorCode }]);
    setNewColorName('');
    setNewColorCode('#000000');
  };

  const handleRemoveColor = (idx: number) => {
    setColors(colors.filter((_, i) => i !== idx));
  };

  const handleGenerateDescription = async (mode: 'text' | 'vision' = 'text') => {
    if (!formData.title.trim()) {
      toast.error('ابتدا عنوان محصول را وارد کنید');
      return;
    }

    if (mode === 'vision' && !formData.image) {
      toast.error('برای تولید از روی عکس، ابتدا تصویر اصلی محصول را آپلود کنید');
      return;
    }

    setAiGenerating(true);
    setAiGenerated(false);
    try {
      const res = await fetch('/api/admin/ai-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: formData.title,
          category: formData.category,
          woodType: formData.woodType,
          brand: formData.brand,
          price: formData.price ? parseInt(formData.price) : null,
          discountPrice: formData.discountPrice ? parseInt(formData.discountPrice) : null,
          image: mode === 'vision' ? formData.image : null,
          mode,
        }),
      });

      const data = await res.json();

      if (res.ok && data.description) {
        setFormData({ ...formData, description: data.description });
        setAiGenerated(true);
        toast.success(
          mode === 'vision' ? 'توضیح از روی عکس تولید شد!' : 'توضیح با AI تولید شد!',
          { description: 'می‌توانید متن را ویرایش کنید' }
        );
      } else {
        toast.error(data.error || 'خطا در تولید توضیح');
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setAiGenerating(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (formData.title.trim().length < 3) {
      toast.error('عنوان باید حداقل ۳ کاراکتر باشد');
      return;
    }

    const priceNum = parseInt(formData.price);
    if (!priceNum || priceNum < 1000) {
      toast.error('قیمت باید عددی بزرگتر از ۱۰۰۰ تومان باشد');
      return;
    }

    if (!formData.image.trim() || !formData.image.startsWith('http')) {
      toast.error('آدرس تصویر اصلی معتبر وارد کنید');
      return;
    }

    setLoading(true);

    const payload = {
      ...formData,
      price: priceNum,
      discountPrice: formData.discountPrice ? parseInt(formData.discountPrice) : null,
      rating: parseFloat(formData.rating) || 0,
      ratingCount: parseInt(formData.ratingCount) || 0,
      stockQuantity: parseInt(formData.stockQuantity) || 0,
      colors: colors.length > 0 ? colors : null,
      images: images.length > 0 ? images : null,
      videos: videos.length > 0 ? videos : null,
    };

    try {
      const url = product ? `/api/products/${product.id}` : '/api/products';
      const method = product ? 'PUT' : 'POST';

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (res.ok) {
        toast.success(product ? 'محصول با موفقیت ویرایش شد' : 'محصول با موفقیت اضافه شد');
        onSave();
      } else {
        toast.error(data.error || 'خطا در ذخیره محصول');
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-gray-900/50 backdrop-blur-sm flex items-center justify-center p-2 md:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl my-8 max-h-[95vh] overflow-y-auto">
        {/* هدر */}
        <div className="sticky top-0 bg-white border-b border-gray-100 p-4 flex items-center justify-between z-10">
          <h2 className="text-lg font-bold">
            {product ? 'ویرایش محصول' : 'افزودن محصول جدید'}
          </h2>
          <Button variant="ghost" size="icon" onClick={onCancel}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 md:p-6 space-y-5">
          {/* پیش‌نمایش تصویر اصلی */}
          {formData.image && (
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <img
                src={formData.image}
                alt="پیش‌نمایش"
                className="w-20 h-20 object-cover rounded-lg"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = 'none';
                }}
              />
              <div className="text-sm text-gray-600">
                <p className="font-medium">تصویر اصلی محصول</p>
                <p className="text-xs">این تصویر در کارت محصول و لیست‌ها نمایش داده می‌شود</p>
              </div>
            </div>
          )}

          {/* عنوان */}
          <div className="space-y-2">
            <Label htmlFor="title">عنوان محصول *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={e => setFormData({ ...formData, title: e.target.value })}
              placeholder="مثلا: اسباب‌بازی چوبی ماشین باربری"
              required
            />
          </div>

          {/* دو ستونی */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="brand">برند</Label>
              <Input
                id="brand"
                value={formData.brand}
                onChange={e => setFormData({ ...formData, brand: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>دسته‌بندی *</Label>
              <Select
                value={formData.category}
                onValueChange={v => setFormData({ ...formData, category: v })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(cat => (
                    <SelectItem key={cat.id} value={cat.title}>
                      {cat.icon} {cat.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* نوع چوب */}
          <div className="space-y-2">
            <Label>نوع چوب</Label>
            <Select
              value={formData.woodType}
              onValueChange={v => setFormData({ ...formData, woodType: v })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {woodTypes.map(wood => (
                  <SelectItem key={wood} value={wood}>{wood}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* قیمت‌ها */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="price">قیمت اصلی (تومان) *</Label>
              <Input
                id="price"
                type="number"
                value={formData.price}
                onChange={e => setFormData({ ...formData, price: e.target.value })}
                placeholder="285000"
                min="1000"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="discountPrice">قیمت با تخفیف (اختیاری)</Label>
              <Input
                id="discountPrice"
                type="number"
                value={formData.discountPrice}
                onChange={e => setFormData({ ...formData, discountPrice: e.target.value })}
                placeholder="228000"
                min="0"
              />
            </div>
          </div>

          {formData.price && formData.discountPrice && parseInt(formData.discountPrice) < parseInt(formData.price) && (
            <div className="bg-green-50 text-green-700 text-sm p-3 rounded-lg">
              ✓ درصد تخفیف: {toFa(Math.round(((parseInt(formData.price) - parseInt(formData.discountPrice)) / parseInt(formData.price)) * 100))}٪
            </div>
          )}

          {/* تصویر اصلی */}
          <div className="space-y-2">
            <Label htmlFor="image">تصویر اصلی *</Label>
            <ImageUploader
              value={formData.image}
              onChange={url => setFormData({ ...formData, image: url })}
              label="تصویر اصلی"
              placeholder="https://example.com/image.jpg"
            />
          </div>

          {/* گالری تصاویر (تا ۱۰ عکس) */}
          <div className="space-y-2">
            <Label>
              گالری تصاویر ({toFa(images.length)} از {toFa(MAX_IMAGES)})
            </Label>
            {images.length > 0 && (
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 mb-2">
                {images.map((img, idx) => (
                  <div key={idx} className="relative group aspect-square rounded-lg overflow-hidden border border-gray-200">
                    <img
                      src={img}
                      alt={`تصویر ${idx + 1}`}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAgMTAwIj48cmVjdCB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgZmlsbD0iI2VlZSIvPjx0ZXh0IHg9IjUwIiB5PSI1NSIgZm9udC1zaXplPSIxMCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZmlsbD0iIzk5OSI+8J+PgTwvdGV4dD48L3N2Zz4=';
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => handleRemoveImage(idx)}
                      className="absolute top-1 right-1 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-3 h-3" />
                    </button>
                    <span className="absolute bottom-1 left-1 bg-black/60 text-white text-[10px] px-1.5 py-0.5 rounded fa-num">
                      {toFa(idx + 1)}
                    </span>
                  </div>
                ))}
              </div>
            )}
            {images.length < MAX_IMAGES && (
              <ImageUploader
                value={newImageUrl}
                onChange={(url) => {
                  if (url) {
                    setImages([...images, url]);
                    setNewImageUrl('');
                    toast.success('تصویر به گالری اضافه شد');
                  } else {
                    setNewImageUrl('');
                  }
                }}
                label="افزودن تصویر"
                folder="products"
                accept="image"
              />
            )}
            {images.length === 0 && (
              <p className="text-xs text-gray-500">تصویری اضافه نشده. می‌توانید تا {toFa(MAX_IMAGES)} تصویر اضافه کنید.</p>
            )}
          </div>

          {/* گالری ویدیوها (تا ۳ ویدیو) */}
          <div className="space-y-2">
            <Label>
              <span className="flex items-center gap-1">
                <Video className="w-4 h-4" />
                ویدیوهای محصول ({toFa(videos.length)} از {toFa(MAX_VIDEOS)})
              </span>
            </Label>
            {videos.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-2">
                {videos.map((video, idx) => (
                  <div key={idx} className="relative group rounded-lg overflow-hidden border border-gray-200 bg-gray-900 aspect-video">
                    <video
                      src={video}
                      className="w-full h-full object-cover"
                      controls
                      muted
                      preload="metadata"
                    />
                    <button
                      type="button"
                      onClick={() => handleRemoveVideo(idx)}
                      className="absolute top-1 right-1 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center"
                    >
                      <X className="w-3 h-3" />
                    </button>
                    <span className="absolute bottom-1 left-1 bg-black/60 text-white text-[10px] px-1.5 py-0.5 rounded flex items-center gap-1">
                      <Play className="w-2.5 h-2.5" />
                      ویدیو {toFa(idx + 1)}
                    </span>
                  </div>
                ))}
              </div>
            )}
            {videos.length < MAX_VIDEOS && (
              <ImageUploader
                value={newVideoUrl}
                onChange={(url) => {
                  if (url) {
                    setVideos([...videos, url]);
                    setNewVideoUrl('');
                    toast.success('ویدیو به گالری اضافه شد');
                  } else {
                    setNewVideoUrl('');
                  }
                }}
                label="افزودن ویدیو"
                folder="products"
                accept="video"
              />
            )}
            {videos.length === 0 && (
              <p className="text-xs text-gray-500">ویدیویی اضافه نشده. می‌توانید تا {toFa(MAX_VIDEOS)} ویدیو اضافه کنید.</p>
            )}
          </div>

          {/* امتیاز و تعداد نظر */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="rating">امتیاز (۰ تا ۵)</Label>
              <Input
                id="rating"
                type="number"
                step="0.1"
                min="0"
                max="5"
                value={formData.rating}
                onChange={e => setFormData({ ...formData, rating: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="ratingCount">تعداد نظرات</Label>
              <Input
                id="ratingCount"
                type="number"
                min="0"
                value={formData.ratingCount}
                onChange={e => setFormData({ ...formData, ratingCount: e.target.value })}
              />
            </div>
          </div>

          {/* توضیحات */}
          <div className="space-y-2">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <Label htmlFor="description">توضیحات محصول</Label>
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => handleGenerateDescription('text')}
                  disabled={aiGenerating || !formData.title}
                  className="text-[#dc2626] border-[#dc2626] hover:bg-red-50"
                >
                  {aiGenerating ? (
                    <><Loader2 className="w-3.5 h-3.5 ml-1 animate-spin" /> در حال تولید...</>
                  ) : (
                    <><Sparkles className="w-3.5 h-3.5 ml-1" /> از متن</>
                  )}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => handleGenerateDescription('vision')}
                  disabled={aiGenerating || !formData.title || !formData.image}
                  className="text-purple-600 border-purple-600 hover:bg-purple-50"
                  title={!formData.image ? 'ابتدا تصویر محصول را آپلود کنید' : 'تولید توضیح از روی عکس محصول'}
                >
                  {aiGenerating ? (
                    <><Loader2 className="w-3.5 h-3.5 ml-1 animate-spin" /></>
                  ) : (
                    <><ImageIcon className="w-3.5 h-3.5 ml-1" /> از عکس 📸</>
                  )}
                </Button>
              </div>
            </div>
            <Textarea
              id="description"
              value={formData.description}
              onChange={e => setFormData({ ...formData, description: e.target.value })}
              placeholder="توضیحات کامل محصول... (یا با AI تولید کنید)"
              rows={4}
            />
            {aiGenerated && (
              <p className="text-xs text-green-600 flex items-center gap-1">
                <CheckCircle className="w-3 h-3" />
                توضیح توسط AI تولید شد - می‌توانید ویرایش کنید
              </p>
            )}
            {!formData.image && (
              <p className="text-xs text-gray-400">
                💡 برای تولید توضیح از روی عکس، ابتدا تصویر اصلی محصول را آپلود کنید
              </p>
            )}
          </div>

          {/* رنگ‌ها */}
          <div className="space-y-2">
            <Label>رنگ‌های موجود</Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={newColorName}
                onChange={e => setNewColorName(e.target.value)}
                placeholder="نام رنگ (مثلا: قرمز)"
                className="flex-1"
              />
              <input
                type="color"
                value={newColorCode}
                onChange={e => setNewColorCode(e.target.value)}
                className="w-12 h-10 rounded border border-gray-200 cursor-pointer"
              />
              <Button type="button" onClick={handleAddColor} size="icon">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            {colors.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {colors.map((color, idx) => (
                  <div
                    key={idx}
                    className="flex items-center gap-2 bg-gray-100 rounded-lg px-3 py-1"
                  >
                    <div
                      className="w-5 h-5 rounded-full border border-gray-300"
                      style={{ backgroundColor: color.code }}
                    />
                    <span className="text-sm">{color.name}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveColor(idx)}
                      className="text-gray-400 hover:text-red-500"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* سوئیچ‌ها (بدون inStock — خودکار از تعداد موجودی) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center justify-between">
              <Label htmlFor="isPublished" className="cursor-pointer">منتشر شده</Label>
              <Switch
                id="isPublished"
                checked={formData.isPublished}
                onCheckedChange={v => setFormData({ ...formData, isPublished: v })}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="fastDelivery" className="cursor-pointer">ارسال سریع</Label>
              <Switch
                id="fastDelivery"
                checked={formData.fastDelivery}
                onCheckedChange={v => setFormData({ ...formData, fastDelivery: v })}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="isSpecial" className="cursor-pointer">فروش ویژه</Label>
              <Switch
                id="isSpecial"
                checked={formData.isSpecial}
                onCheckedChange={v => setFormData({ ...formData, isSpecial: v })}
              />
            </div>
          </div>

          {/* تعداد موجودی — منبع حقیقی موجود بودن محصول */}
          <div className="space-y-2 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center justify-between">
              <Label htmlFor="stockQuantity" className="cursor-pointer font-bold">تعداد موجودی (عدد)</Label>
              <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${
                (parseInt(formData.stockQuantity) || 0) > 0
                  ? 'bg-green-100 text-green-700'
                  : 'bg-red-100 text-red-700'
              }`}>
                {(parseInt(formData.stockQuantity) || 0) > 0 ? 'موجود' : 'ناموجود'}
              </span>
            </div>
            <Input
              id="stockQuantity"
              type="number"
              value={formData.stockQuantity}
              onChange={e => setFormData({ ...formData, stockQuantity: e.target.value })}
              placeholder="0"
              min="0"
              className="text-lg font-bold"
            />
            <p className="text-xs text-blue-700">
              💡 موجودی محصول فقط از این تعداد محاسبه می‌شود. اگر ۰ باشد، محصول خودکار «ناموجود» می‌شود و دکمه خرید غیرفعال می‌گردد.
            </p>
          </div>

          {/* دکمه‌ها */}
          <div className="flex gap-3 pt-2">
            <Button
              type="submit"
              disabled={loading}
              className="flex-1 bg-[#dc2626] hover:bg-[#b91c1c] h-12"
            >
              <Save className="w-4 h-4 ml-2" />
              {loading ? 'در حال ذخیره...' : (product ? 'ذخیره تغییرات' : 'افزودن محصول')}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              className="h-12 px-6"
            >
              انصراف
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
