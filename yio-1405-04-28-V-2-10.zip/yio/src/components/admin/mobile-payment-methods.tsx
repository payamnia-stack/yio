'use client';

import { useState, useEffect } from 'react';
import {
  Plus, Edit2, Trash2, CreditCard, Banknote, Wallet, Building,
  CheckCircle, XCircle, Star, Shield,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';

interface PaymentMethod {
  id: number;
  name: string;
  type: string;
  bank?: string | null;
  merchantId?: string | null;
  description?: string | null;
  isActive: boolean;
  isDefault: boolean;
  priority: number;
}

const paymentTypes: any = {
  cod: { label: 'پرداخت در محل', icon: Banknote, color: 'bg-green-50 text-green-700' },
  online: { label: 'درگاه آنلاین', icon: CreditCard, color: 'bg-blue-50 text-blue-700' },
  wallet: { label: 'کیف پول', icon: Wallet, color: 'bg-purple-50 text-purple-700' },
  transfer: { label: 'انتقال بانکی', icon: Building, color: 'bg-amber-50 text-amber-700' },
};

export function MobilePaymentMethods() {
  const [methods, setMethods] = useState<PaymentMethod[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchMethods = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/payment-methods');
      if (res.status === 401) return;
      const data = await res.json();
      setMethods(data.methods || []);
    } catch {
      toast.error('خطا در دریافت روش‌های پرداخت');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMethods();
  }, []);

  const toggleActive = async (m: PaymentMethod) => {
    try {
      await fetch(`/api/payment-methods/${m.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isActive: !m.isActive }),
      });
      toast.success(m.isActive ? 'غیرفعال شد' : 'فعال شد');
      fetchMethods();
    } catch {}
  };

  const setDefault = async (m: PaymentMethod) => {
    try {
      await fetch(`/api/payment-methods/${m.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isDefault: true }),
      });
      toast.success('پیش‌فرض شد');
      fetchMethods();
    } catch {}
  };

  return (
    <div className="p-3 space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold">روش‌های پرداخت</h2>
        <Button size="sm" className="bg-[#dc2626] hover:bg-[#b91c1c]" onClick={() => toast.info('برای افزودن کامل، از حالت دسکتاپ استفاده کنید')}>
          <Plus className="w-4 h-4 ml-1" />
          افزودن
        </Button>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 flex items-start gap-2">
        <Shield className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
        <p className="text-xs text-blue-800">اطلاعات بانکی با AES-256 رمزنگاری می‌شود.</p>
      </div>

      {loading ? (
        <div className="text-center py-8">
          <div className="inline-block w-6 h-6 border-3 border-gray-200 border-t-[#dc2626] rounded-full animate-spin"></div>
        </div>
      ) : methods.length === 0 ? (
        <div className="text-center py-8 text-gray-500 text-sm">روش پرداختی ثبت نشده</div>
      ) : (
        <div className="space-y-2">
          {methods.map(m => {
            const typeInfo = paymentTypes[m.type] || paymentTypes.online;
            const Icon = typeInfo.icon;
            return (
              <div key={m.id} className={`bg-white rounded-xl p-3 border-2 ${m.isDefault ? 'border-[#dc2626]' : 'border-gray-100'} shadow-sm ${!m.isActive ? 'opacity-60' : ''}`}>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className={`w-10 h-10 rounded-lg ${typeInfo.color} flex items-center justify-center`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-1">
                        <h3 className="font-bold text-sm">{m.name}</h3>
                        {m.isDefault && <Star className="w-3 h-3 fill-[#dc2626] text-[#dc2626]" />}
                      </div>
                      <p className="text-[10px] text-gray-500">{typeInfo.label}</p>
                    </div>
                  </div>
                  {m.isActive ? <CheckCircle className="w-4 h-4 text-green-500" /> : <XCircle className="w-4 h-4 text-gray-400" />}
                </div>

                {m.type === 'online' && m.merchantId && (
                  <div className="bg-gray-50 rounded p-2 mb-2 text-[10px]">
                    <span className="text-gray-500">کد پذیرنده: </span>
                    <code dir="ltr" className="font-mono">{m.merchantId}</code>
                  </div>
                )}

                <div className="flex items-center justify-between pt-2 border-t border-gray-50">
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={m.isActive}
                      onCheckedChange={() => toggleActive(m)}
                    />
                    <span className="text-[10px] text-gray-600">فعال</span>
                  </div>
                  {!m.isDefault && m.isActive && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setDefault(m)}
                      className="h-7 text-[10px] text-[#dc2626]"
                    >
                      پیش‌فرض
                    </Button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
