'use client';

import { useState, useEffect, useRef } from 'react';
import { Settings, Save, Phone, Mail, MapPin, Clock, Info, Share2, Loader2, Link as LinkIcon, Plus, Trash2, Link2, Upload, Image as ImageIcon, Palette, PanelTop, MessageSquare, Inbox, Send, Star, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { ResponsiveTabs } from './responsive-tabs';

const sections = [
  { key: 'contact', label: 'اطلاعات تماس', icon: Phone, short: 'تماس', fields: [
    { key: 'contact_phone', label: 'تلفن پشتیبانی', type: 'text' },
    { key: 'contact_email', label: 'ایمیل', type: 'email' },
    { key: 'contact_address', label: 'آدرس', type: 'textarea' },
    { key: 'contact_hours', label: 'ساعات کاری', type: 'textarea' },
  ]},
  { key: 'about', label: 'درباره ما', icon: Info, short: 'درباره', fields: [
    { key: 'about_title', label: 'عنوان بخش درباره ما', type: 'text' },
    { key: 'about_subtitle', label: 'زیرعنوان', type: 'text' },
    { key: 'about_story', label: 'داستان YIO', type: 'textarea' },
    { key: 'about_mission', label: 'مأموریت', type: 'textarea' },
  ]},
  { key: 'footer', label: 'فوتر سایت', icon: Settings, short: 'فوتر', fields: [
    { key: 'footer_description', label: 'توضیحات فوتر', type: 'textarea' },
    { key: 'footer_copyright', label: 'متن کپی‌رایت', type: 'text' },
  ]},
  { key: 'social', label: 'شبکه‌های اجتماعی', icon: Share2, short: 'شبکه‌ها', fields: [
    { key: 'social_instagram', label: 'اینستاگرام', type: 'text' },
    { key: 'social_telegram', label: 'تلگرام', type: 'text' },
    { key: 'social_whatsapp', label: 'واتساپ', type: 'text' },
  ]},
  { key: 'general', label: 'تنظیمات عمومی', icon: Settings, short: 'عمومی', fields: [
    { key: 'site_title', label: 'عنوان سایت', type: 'text' },
    { key: 'site_description', label: 'توضیحات سایت (SEO)', type: 'textarea' },
    { key: 'free_shipping_threshold', label: 'حداقل خرید برای ارسال رایگان (تومان)', type: 'number' },
    { key: 'shipping_cost', label: 'هزینه ارسال (تومان)', type: 'number' },
  ]},
  { key: 'topbar', label: 'نوار بالای سایت', icon: PanelTop, short: 'نوار بالا', fields: [] },
  { key: 'sms', label: 'پنل پیامکی', icon: MessageSquare, short: 'پیامک', fields: [] },
  { key: 'email', label: 'تنظیمات ایمیل', icon: Mail, short: 'ایمیل', fields: [] },
  { key: 'inbox', label: 'ایمیل‌های ورودی', icon: Inbox, short: 'صندوق', fields: [] },
  { key: 'quick_links', label: 'لینک‌های سریع', icon: LinkIcon, short: 'لینک‌ها', fields: [] },
];

// ===== لینک‌های سریع (دایره‌های صفحه اصلی) =====
interface QuickLink {
  title: string;
  href: string;
  icon: string;
  color: string;
}

function QuickLinksEditor() {
  const [links, setLinks] = useState<QuickLink[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch('/api/settings?q=quick_links')
      .then(r => r.json())
      .then(data => {
        if (data.value) {
          try {
            const parsed = JSON.parse(data.value);
            if (Array.isArray(parsed)) {
              setLinks(parsed);
              return;
            }
          } catch {}
        }
        // اگر چیزی ذخیره نشده بود، از دسته‌بندی‌ها پر کن
        fetch('/api/categories')
          .then(r => r.json())
          .then(catData => {
            const cats = (catData.categories || []).map((c: any) => ({
              title: c.title,
              href: `/category/${encodeURIComponent(c.slug || c.title)}`,
              icon: c.icon || '📦',
              color: c.color || '#dc2626',
            }));
            setLinks(cats);
          })
          .catch(() => setLinks([]));
      })
      .catch(() => setLinks([]))
      .finally(() => setLoading(false));
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          settings: { quick_links: JSON.stringify(links) },
        }),
      });
      if (res.ok) {
        toast.success('لینک‌های سریع ذخیره شد');
      } else {
        toast.error('خطا در ذخیره');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setSaving(false);
    }
  };

  const addLink = () => {
    setLinks([...links, { title: 'لینک جدید', href: '/', icon: '🔗', color: '#dc2626' }]);
  };

  const updateLink = (idx: number, field: keyof QuickLink, value: string) => {
    setLinks(links.map((l, i) => i === idx ? { ...l, [field]: value } : l));
  };

  const removeLink = (idx: number) => {
    setLinks(links.filter((_, i) => i !== idx));
  };

  if (loading) {
    return <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-[#dc2626]" /></div>;
  }

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-gray-500">
          این لینک‌ها در صفحه اصلی به‌صورت دایره نمایش داده می‌شوند. می‌توانید عنوان، لینک، آیکن (ایموجی) و رنگ هر کدام را تغییر دهید.
        </p>
        <Button onClick={addLink} size="sm" className="bg-[#dc2626] hover:bg-[#b91c1c]">
          <Plus className="w-4 h-4 ml-1" />
          افزودن لینک
        </Button>
      </div>

      {links.length === 0 ? (
        <div className="text-center py-8 text-gray-400">
          <Link2 className="w-12 h-12 mx-auto mb-2" />
          هیچ لینکی وجود ندارد
        </div>
      ) : (
        <div className="space-y-2">
          {links.map((link, idx) => (
            <div key={idx} className="flex items-center gap-2 p-3 border border-gray-100 rounded-lg">
              {/* پیش‌نمایش */}
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center text-xl shrink-0"
                style={{ backgroundColor: `${link.color}15` }}
              >
                {link.icon}
              </div>

              {/* فیلدها */}
              <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-2">
                <Input
                  value={link.title}
                  onChange={e => updateLink(idx, 'title', e.target.value)}
                  placeholder="عنوان"
                  className="text-sm"
                />
                <Input
                  value={link.href}
                  onChange={e => updateLink(idx, 'href', e.target.value)}
                  placeholder="/category/..."
                  className="text-sm"
                  dir="ltr"
                />
                <Input
                  value={link.icon}
                  onChange={e => updateLink(idx, 'icon', e.target.value)}
                  placeholder="📦"
                  className="text-sm text-center"
                />
                <div className="flex items-center gap-1">
                  <input
                    type="color"
                    value={link.color}
                    onChange={e => updateLink(idx, 'color', e.target.value)}
                    className="w-10 h-9 rounded cursor-pointer border border-gray-200"
                  />
                  <Input
                    value={link.color}
                    onChange={e => updateLink(idx, 'color', e.target.value)}
                    className="text-sm"
                    dir="ltr"
                  />
                </div>
              </div>

              {/* حذف */}
              <Button
                variant="outline"
                size="icon"
                onClick={() => removeLink(idx)}
                className="text-red-600 shrink-0"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>
      )}

      <Button onClick={handleSave} disabled={saving} className="w-full bg-[#dc2626] hover:bg-[#b91c1c]">
        {saving ? <Loader2 className="w-4 h-4 ml-1 animate-spin" /> : <Save className="w-4 h-4 ml-1" />}
        {saving ? 'در حال ذخیره...' : 'ذخیره لینک‌های سریع'}
      </Button>
    </div>
  );
}

// ===== ویرایشگر پنل پیامکی =====
function SmsEditor() {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testPhone, setTestPhone] = useState('');

  useEffect(() => {
    fetch('/api/settings')
      .then(r => r.json())
      .then(data => {
        const s = data.settings || {};
        setSettings({
          sms_enabled: s.sms_enabled ?? 'false',
          sms_provider: s.sms_provider ?? 'kavenegar',
          sms_api_key: s.sms_api_key ?? '',
          sms_sender_number: s.sms_sender_number ?? '',
          sms_api_url: s.sms_api_url ?? '',
          sms_otp_template: s.sms_otp_template ?? 'YIO\nکد تایید شما: {{code}}\nاین کد تا ۱۰ دقیقه معتبر است.',
          sms_welcome_template: s.sms_welcome_template ?? 'YIO\n{{name}} عزیز، به خانواده YIO خوش آمدید!',
          sms_order_template: s.sms_order_template ?? 'YIO\nسفارش {{orderNumber}} شما وضعیت «{{status}}» گرفت.',
        });
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const update = (key: string, value: string) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings }),
      });
      if (res.ok) {
        toast.success('تنظیمات پیامک ذخیره شد');
      } else {
        toast.error('خطا در ذخیره');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setSaving(false);
    }
  };

  const handleTest = async () => {
    if (!testPhone || !/^09\d{9}$/.test(testPhone)) {
      toast.error('شماره موبایل معتبر وارد کنید (09123456789)');
      return;
    }
    setTesting(true);
    try {
      const res = await fetch('/api/admin/sms-test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: testPhone }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        toast.success('پیامک تست ارسال شد');
      } else {
        toast.error(data.error || 'خطا در ارسال پیامک تست');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setTesting(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-[#dc2626]" /></div>;
  }

  const providers = [
    { value: 'kavenegar', label: 'کاوه‌نگار', needsKey: 'API Key', needsSender: true },
    { value: 'melipayamak', label: 'ملی پیامک', needsKey: 'Username|Password', needsSender: true },
    { value: 'farapayamak', label: 'فرا پیامک', needsKey: 'Username|Password', needsSender: true },
    { value: 'smsir', label: 'SMS.ir', needsKey: 'API Key', needsSender: true },
    { value: 'custom', label: 'سفارشی (Custom URL)', needsKey: 'API Key (اختیاری)', needsSender: false },
  ];

  const currentProvider = providers.find(p => p.value === settings.sms_provider);

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm space-y-5">
      <p className="text-sm text-gray-500">
        تنظیمات پنل پیامکی برای ارسال کد تایید موبایل، پیام خوش‌آمدگویی و وضعیت سفارش استفاده می‌شود.
      </p>

      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label>پنل پیامک فعال باشد؟</Label>
          <select
            value={settings.sms_enabled}
            onChange={e => update('sms_enabled', e.target.value)}
            className="w-full h-10 rounded-md border border-gray-200 px-3 text-sm"
          >
            <option value="true">بله، پیامک ارسال شود</option>
            <option value="false">خیر، فقط لاگ (محیط توسعه)</option>
          </select>
        </div>

        <div className="space-y-1.5">
          <Label>ارائه‌دهنده سرویس</Label>
          <select
            value={settings.sms_provider}
            onChange={e => update('sms_provider', e.target.value)}
            className="w-full h-10 rounded-md border border-gray-200 px-3 text-sm"
          >
            {providers.map(p => (
              <option key={p.value} value={p.value}>{p.label}</option>
            ))}
          </select>
        </div>

        <div className="space-y-1.5">
          <Label>{currentProvider?.needsKey || 'API Key'}</Label>
          <Input
            value={settings.sms_api_key}
            onChange={e => update('sms_api_key', e.target.value)}
            placeholder={currentProvider?.value === 'melipayamak' || currentProvider?.value === 'farapayamak' ? 'username|password' : 'API Key'}
            dir="ltr"
          />
        </div>

        {currentProvider?.needsSender && (
          <div className="space-y-1.5">
            <Label>شماره فرستنده</Label>
            <Input
              value={settings.sms_sender_number}
              onChange={e => update('sms_sender_number', e.target.value)}
              placeholder="3000123456"
              dir="ltr"
            />
          </div>
        )}
      </div>

      {settings.sms_provider === 'custom' && (
        <div className="space-y-1.5 p-4 bg-amber-50 border border-amber-200 rounded-lg">
          <Label>آدرس API سفارشی</Label>
          <Input
            value={settings.sms_api_url}
            onChange={e => update('sms_api_url', e.target.value)}
            placeholder="https://example.com/send?phone={{phone}}&message={{message}}&key={{apiKey}}"
            dir="ltr"
          />
          <p className="text-xs text-amber-700">
            متغیرهای قابل استفاده: <code className="bg-amber-100 px-1 rounded">{'{{phone}}'}</code>، <code className="bg-amber-100 px-1 rounded">{'{{message}}'}</code>، <code className="bg-amber-100 px-1 rounded">{'{{apiKey}}'}</code>، <code className="bg-amber-100 px-1 rounded">{'{{sender}}'}</code>
          </p>
        </div>
      )}

      {/* قالب‌های پیامک */}
      <div className="space-y-3 p-4 bg-gray-50 rounded-lg">
        <div className="flex items-center gap-2 text-sm font-bold text-gray-700">
          <MessageSquare className="w-4 h-4" />
          قالب‌های پیامک
        </div>

        <div className="space-y-1.5">
          <Label>قالب کد تایید</Label>
          <Textarea
            value={settings.sms_otp_template}
            onChange={e => update('sms_otp_template', e.target.value)}
            rows={3}
          />
          <p className="text-xs text-gray-500">متغیر: <code className="bg-gray-200 px-1 rounded">{'{{code}}'}</code></p>
        </div>

        <div className="space-y-1.5">
          <Label>قالب خوش‌آمدگویی</Label>
          <Textarea
            value={settings.sms_welcome_template}
            onChange={e => update('sms_welcome_template', e.target.value)}
            rows={2}
          />
          <p className="text-xs text-gray-500">متغیر: <code className="bg-gray-200 px-1 rounded">{'{{name}}'}</code></p>
        </div>

        <div className="space-y-1.5">
          <Label>قالب وضعیت سفارش</Label>
          <Textarea
            value={settings.sms_order_template}
            onChange={e => update('sms_order_template', e.target.value)}
            rows={2}
          />
          <p className="text-xs text-gray-500">متغیرها: <code className="bg-gray-200 px-1 rounded">{'{{orderNumber}}'}</code>، <code className="bg-gray-200 px-1 rounded">{'{{status}}'}</code></p>
        </div>
      </div>

      {/* تست ارسال */}
      <div className="space-y-2 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <Label>تست ارسال پیامک</Label>
        <div className="flex gap-2">
          <Input
            value={testPhone}
            onChange={e => setTestPhone(e.target.value)}
            placeholder="09123456789"
            dir="ltr"
            className="flex-1"
          />
          <Button onClick={handleTest} disabled={testing} variant="outline">
            {testing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            <span className="mr-1">ارسال تست</span>
          </Button>
        </div>
        <p className="text-xs text-blue-700">برای اطمینان از صحت تنظیمات، یک پیامک تست ارسال کنید</p>
      </div>

      <Button onClick={handleSave} disabled={saving} className="w-full bg-[#dc2626] hover:bg-[#b91c1c]">
        {saving ? <Loader2 className="w-4 h-4 ml-1 animate-spin" /> : <Save className="w-4 h-4 ml-1" />}
        {saving ? 'در حال ذخیره...' : 'ذخیره تنظیمات پیامک'}
      </Button>
    </div>
  );
}

// ===== ویرایشگر تنظیمات ایمیل =====
function EmailEditor() {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch('/api/settings')
      .then(r => r.json())
      .then(data => {
        const s = data.settings || {};
        setSettings({
          email_enabled: s.email_enabled ?? 'false',
          email_smtp_host: s.email_smtp_host ?? 'smtp.gmail.com',
          email_smtp_port: s.email_smtp_port ?? '587',
          email_smtp_secure: s.email_smtp_secure ?? 'tls',
          email_smtp_user: s.email_smtp_user ?? '',
          email_smtp_password: s.email_smtp_password ?? '',
          email_from_address: s.email_from_address ?? 'noreply@yio-shop.ir',
          email_from_name: s.email_from_name ?? 'YIO فروشگاه چوب',
          email_inbox_recipients: s.email_inbox_recipients ?? 'admin@yio-shop.ir',
          email_otp_template: s.email_otp_template ?? 'سلام {{name}}،\n\nکد تایید شما: {{code}}\n\nتیم YIO',
        });
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const update = (key: string, value: string) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings }),
      });
      if (res.ok) {
        toast.success('تنظیمات ایمیل ذخیره شد');
      } else {
        toast.error('خطا در ذخیره');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-[#dc2626]" /></div>;
  }

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm space-y-5">
      <p className="text-sm text-gray-500">
        تنظیمات SMTP برای ارسال ایمیل تایید، خبرنامه و… استفاده می‌شود. ایمیل‌های ورودی (پاسخ‌ها و تماس‌ها) در تب «ایمیل‌های ورودی» قابل مشاهده هستند.
      </p>

      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label>ارسال ایمیل فعال باشد؟</Label>
          <select
            value={settings.email_enabled}
            onChange={e => update('email_enabled', e.target.value)}
            className="w-full h-10 rounded-md border border-gray-200 px-3 text-sm"
          >
            <option value="true">بله</option>
            <option value="false">خیر (فقط ذخیره در دیتابیس)</option>
          </select>
        </div>

        <div className="space-y-1.5">
          <Label>پورت SMTP</Label>
          <Input
            type="number"
            value={settings.email_smtp_port}
            onChange={e => update('email_smtp_port', e.target.value)}
            dir="ltr"
          />
        </div>

        <div className="space-y-1.5 col-span-2">
          <Label>آدرس سرور SMTP</Label>
          <Input
            value={settings.email_smtp_host}
            onChange={e => update('email_smtp_host', e.target.value)}
            placeholder="smtp.gmail.com"
            dir="ltr"
          />
        </div>

        <div className="space-y-1.5">
          <Label>امنیت اتصال</Label>
          <select
            value={settings.email_smtp_secure}
            onChange={e => update('email_smtp_secure', e.target.value)}
            className="w-full h-10 rounded-md border border-gray-200 px-3 text-sm"
          >
            <option value="none">هیچ (پورت 25)</option>
            <option value="ssl">SSL (پورت 465)</option>
            <option value="tls">TLS (پورت 587)</option>
          </select>
        </div>

        <div className="space-y-1.5">
          <Label>نام نمایشی فرستنده</Label>
          <Input
            value={settings.email_from_name}
            onChange={e => update('email_from_name', e.target.value)}
          />
        </div>

        <div className="space-y-1.5">
          <Label>آدرس ایمیل فرستنده</Label>
          <Input
            value={settings.email_from_address}
            onChange={e => update('email_from_address', e.target.value)}
            dir="ltr"
          />
        </div>

        <div className="space-y-1.5">
          <Label>نام کاربری SMTP</Label>
          <Input
            value={settings.email_smtp_user}
            onChange={e => update('email_smtp_user', e.target.value)}
            dir="ltr"
          />
        </div>

        <div className="space-y-1.5 col-span-2">
          <Label>رمز عبور SMTP</Label>
          <Input
            type="password"
            value={settings.email_smtp_password}
            onChange={e => update('email_smtp_password', e.target.value)}
            placeholder="••••••••"
            dir="ltr"
          />
          <p className="text-xs text-gray-500">برای جیمیل، از App Password استفاده کنید (نه رمز اصلی)</p>
        </div>

        <div className="space-y-1.5 col-span-2">
          <Label>گیرندگان ایمیل‌های ورودی (با | جدا کنید)</Label>
          <Input
            value={settings.email_inbox_recipients}
            onChange={e => update('email_inbox_recipients', e.target.value)}
            placeholder="admin@yio-shop.ir|support@yio-shop.ir"
            dir="ltr"
          />
        </div>
      </div>

      <div className="space-y-1.5 p-4 bg-gray-50 rounded-lg">
        <Label>قالب ایمیل تایید</Label>
        <Textarea
          value={settings.email_otp_template}
          onChange={e => update('email_otp_template', e.target.value)}
          rows={5}
        />
        <p className="text-xs text-gray-500">متغیرها: <code className="bg-gray-200 px-1 rounded">{'{{name}}'}</code>، <code className="bg-gray-200 px-1 rounded">{'{{code}}'}</code></p>
      </div>

      <Button onClick={handleSave} disabled={saving} className="w-full bg-[#dc2626] hover:bg-[#b91c1c]">
        {saving ? <Loader2 className="w-4 h-4 ml-1 animate-spin" /> : <Save className="w-4 h-4 ml-1" />}
        {saving ? 'در حال ذخیره...' : 'ذخیره تنظیمات ایمیل'}
      </Button>
    </div>
  );
}

// ===== نمایشگر ایمیل‌های ورودی =====
interface IncomingEmail {
  id: number;
  fromEmail: string;
  fromName: string | null;
  toEmail: string;
  subject: string;
  body: string | null;
  isRead: boolean;
  isStarred: boolean;
  category: string;
  receivedAt: string;
}

function InboxViewer() {
  const [emails, setEmails] = useState<IncomingEmail[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedEmail, setSelectedEmail] = useState<IncomingEmail | null>(null);
  const [filter, setFilter] = useState<'all' | 'unread' | 'inbox' | 'outbox'>('all');
  const [search, setSearch] = useState('');
  const [unreadCount, setUnreadCount] = useState(0);

  const fetchEmails = async () => {
    try {
      const params = new URLSearchParams();
      if (filter === 'unread') params.set('unread', 'true');
      if (filter === 'inbox' || filter === 'outbox') params.set('category', filter);
      if (search) params.set('search', search);
      const res = await fetch(`/api/admin/emails?${params}`);
      const data = await res.json();
      setEmails(data.emails || []);
      setUnreadCount(data.unreadCount || 0);
    } catch {
      toast.error('خطا در دریافت ایمیل‌ها');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmails();
  }, [filter, search]);

  const handleSelect = async (email: IncomingEmail) => {
    setSelectedEmail(email);
    if (!email.isRead) {
      try {
        await fetch(`/api/admin/emails/${email.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ isRead: true }),
        });
        setEmails(emails.map(e => e.id === email.id ? { ...e, isRead: true } : e));
        setUnreadCount(c => Math.max(0, c - 1));
      } catch {}
    }
  };

  const handleToggleStar = async (email: IncomingEmail) => {
    try {
      await fetch(`/api/admin/emails/${email.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isStarred: !email.isStarred }),
      });
      setEmails(emails.map(e => e.id === email.id ? { ...e, isStarred: !e.isStarred } : e));
      if (selectedEmail?.id === email.id) {
        setSelectedEmail({ ...email, isStarred: !email.isStarred });
      }
    } catch {
      toast.error('خطا');
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('ایمیل حذف شود؟')) return;
    try {
      await fetch(`/api/admin/emails/${id}`, { method: 'DELETE' });
      setEmails(emails.filter(e => e.id !== id));
      if (selectedEmail?.id === id) setSelectedEmail(null);
      toast.success('حذف شد');
    } catch {
      toast.error('خطا در حذف');
    }
  };

  if (loading) {
    return <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-[#dc2626]" /></div>;
  }

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      {/* هدر */}
      <div className="p-4 border-b border-gray-100 space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-bold flex items-center gap-2">
            <Inbox className="w-5 h-5 text-[#dc2626]" />
            صندوق ایمیل
            {unreadCount > 0 && (
              <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full fa-num">{unreadCount} خوانده‌نشده</span>
            )}
          </h3>
        </div>

        {/* فیلترها */}
        <div className="flex gap-2 flex-wrap">
          {[
            { value: 'all', label: 'همه' },
            { value: 'inbox', label: 'ورودی' },
            { value: 'outbox', label: 'خروجی' },
            { value: 'unread', label: 'خوانده‌نشده' },
          ].map(f => (
            <button
              key={f.value}
              onClick={() => setFilter(f.value as any)}
              className={`text-xs px-3 py-1.5 rounded-full transition-colors ${
                filter === f.value ? 'bg-[#dc2626] text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {f.label}
            </button>
          ))}
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="جستجو..."
            className="text-xs px-3 py-1.5 rounded-full border border-gray-200 flex-1 min-w-[150px]"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 min-h-[400px]">
        {/* لیست ایمیل‌ها */}
        <div className={`border-l border-gray-100 overflow-y-auto ${selectedEmail ? 'hidden md:block lg:block' : 'block'}`}>
          {emails.length === 0 ? (
            <div className="text-center py-12 text-gray-400 text-sm">
              <Inbox className="w-12 h-12 mx-auto mb-2 opacity-30" />
              ایمالی وجود ندارد
            </div>
          ) : (
            emails.map(email => (
              <button
                key={email.id}
                onClick={() => handleSelect(email)}
                className={`w-full text-right p-3 border-b border-gray-50 hover:bg-gray-50 transition-colors ${
                  selectedEmail?.id === email.id ? 'bg-red-50' : ''
                } ${!email.isRead ? 'font-bold' : ''}`}
              >
                <div className="flex items-center gap-2 mb-1">
                  {!email.isRead && <span className="w-2 h-2 bg-blue-500 rounded-full shrink-0"></span>}
                  <span className="text-xs text-gray-500 shrink-0">
                    {email.category === 'outbox' ? '📤' : '📥'}
                  </span>
                  <span className="text-sm truncate flex-1">{email.fromName || email.fromEmail}</span>
                  <button
                    onClick={(e) => { e.stopPropagation(); handleToggleStar(email); }}
                    className="shrink-0"
                  >
                    <Star className={`w-4 h-4 ${email.isStarred ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`} />
                  </button>
                </div>
                <p className="text-xs truncate mb-1">{email.subject}</p>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-gray-400 fa-num">
                    {new Date(email.receivedAt).toLocaleDateString('fa-IR')}
                  </span>
                  <span className="text-[10px] text-gray-400">
                    {email.category === 'outbox' ? 'خروجی' : 'ورودی'}
                  </span>
                </div>
              </button>
            ))
          )}
        </div>

        {/* نمایش ایمیل انتخاب شده */}
        <div className={`col-span-1 md:col-span-1 lg:col-span-2 p-4 ${selectedEmail ? 'block' : 'hidden md:block lg:block'}`}>
          {selectedEmail ? (
            <div className="space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-lg">{selectedEmail.subject}</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    از: <span dir="ltr">{selectedEmail.fromName || selectedEmail.fromEmail}</span>
                  </p>
                  <p className="text-xs text-gray-500 mt-1 fa-num">
                    {new Date(selectedEmail.receivedAt).toLocaleString('fa-IR')}
                  </p>
                </div>
                <button
                  onClick={() => handleDelete(selectedEmail.id)}
                  className="text-red-500 hover:bg-red-50 p-2 rounded-lg"
                  title="حذف"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <div className="border-t border-gray-100 pt-3">
                <pre className="text-sm whitespace-pre-wrap font-sans leading-6">
                  {selectedEmail.body || '(بدون محتوا)'}
                </pre>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-gray-400 text-sm h-full flex items-center justify-center">
              <div>
                <Mail className="w-12 h-12 mx-auto mb-2 opacity-30" />
                یک ایمیل را برای مشاهده انتخاب کنید
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ===== ویرایشگر نوار بالای سایت (نوار قرمز) =====
function TopBarEditor() {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetch('/api/settings')
      .then(r => r.json())
      .then(data => {
        const s = data.settings || {};
        setSettings({
          topbar_enabled: s.topbar_enabled ?? 'true',
          topbar_height: s.topbar_height ?? '36',
          topbar_bg_color: s.topbar_bg_color ?? '#dc2626',
          topbar_text_color: s.topbar_text_color ?? '#ffffff',
          topbar_mode: s.topbar_mode ?? 'text',
          topbar_text_right: s.topbar_text_right ?? 'ارسال به: تهران|پشتیبانی ۲۴ ساعته: ۰۲۱-۹۱۰۰۲۰۲۰',
          topbar_text_left: s.topbar_text_left ?? 'ضمانت اصالت کالا|ارسال به سراسر کشور|پرداخت در محل',
          topbar_image_url: s.topbar_image_url ?? '',
          topbar_image_link: s.topbar_image_link ?? '',
          topbar_image_height: s.topbar_image_height ?? '28',
        });
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const update = (key: string, value: string) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);
    formData.append('path', 'topbar');

    try {
      const res = await fetch('/api/admin/upload', { method: 'POST', body: formData });
      const data = await res.json();
      if (res.ok && data.file?.url) {
        update('topbar_image_url', data.file.url);
        toast.success('تصویر آپلود شد');
      } else {
        toast.error(data.error || 'خطا در آپلود');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings }),
      });
      if (res.ok) {
        toast.success('تنظیمات نوار ذخیره شد');
      } else {
        toast.error('خطا در ذخیره');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-[#dc2626]" /></div>;
  }

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm space-y-5">
      <p className="text-sm text-gray-500">
        این نوار قرمز در بالای تمام صفحات سایت نمایش داده می‌شود. می‌توانید متن، تصویر (یا گیف)، ارتفاع و رنگ آن را تنظیم کنید. مناسب برای تبلیغات یا اطلاع‌رسانی.
      </p>

      {/* پیش‌نمایش زنده */}
      <div className="border border-gray-200 rounded-lg p-3 bg-gray-50">
        <p className="text-xs text-gray-500 mb-2">پیش‌نمایش:</p>
        {settings.topbar_enabled === 'true' ? (
          <div
            className="text-xs flex items-center justify-between px-3 rounded"
            style={{
              backgroundColor: settings.topbar_bg_color,
              color: settings.topbar_text_color,
              height: `${parseInt(settings.topbar_height) || 36}px`,
            }}
          >
            {(settings.topbar_mode === 'text' || settings.topbar_mode === 'mixed') && (
              <>
                <div className="flex gap-3 truncate">
                  {(settings.topbar_text_right || '').split('|').map((t, i) => t.trim() && <span key={i} className="truncate">{t.trim()}</span>)}
                </div>
                <div className="flex gap-3">
                  {(settings.topbar_text_left || '').split('|').map((t, i) => t.trim() && <span key={i}>{t.trim()}</span>)}
                </div>
              </>
            )}
            {settings.topbar_mode === 'image' && settings.topbar_image_url && (
              <img
                src={settings.topbar_image_url}
                alt="preview"
                className="w-full"
                style={{ height: `${parseInt(settings.topbar_height) || 36}px`, objectFit: 'cover' }}
              />
            )}
          </div>
        ) : (
          <div className="text-center text-gray-400 py-3 text-xs">نوار غیرفعال است</div>
        )}
      </div>

      {/* تنظیمات اصلی */}
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label>نوار فعال باشد؟</Label>
          <select
            value={settings.topbar_enabled}
            onChange={e => update('topbar_enabled', e.target.value)}
            className="w-full h-10 rounded-md border border-gray-200 px-3 text-sm"
          >
            <option value="true">بله، نمایش داده شود</option>
            <option value="false">خیر، مخفی شود</option>
          </select>
        </div>

        <div className="space-y-1.5">
          <Label>ارتفاع نوار (پیکسل)</Label>
          <Input
            type="number"
            min={20}
            max={120}
            value={settings.topbar_height}
            onChange={e => update('topbar_height', e.target.value)}
          />
        </div>

        <div className="space-y-1.5">
          <Label>رنگ پس‌زمینه</Label>
          <div className="flex gap-2">
            <input
              type="color"
              value={settings.topbar_bg_color}
              onChange={e => update('topbar_bg_color', e.target.value)}
              className="w-12 h-10 rounded cursor-pointer border border-gray-200"
            />
            <Input
              value={settings.topbar_bg_color}
              onChange={e => update('topbar_bg_color', e.target.value)}
              dir="ltr"
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <Label>رنگ متن</Label>
          <div className="flex gap-2">
            <input
              type="color"
              value={settings.topbar_text_color}
              onChange={e => update('topbar_text_color', e.target.value)}
              className="w-12 h-10 rounded cursor-pointer border border-gray-200"
            />
            <Input
              value={settings.topbar_text_color}
              onChange={e => update('topbar_text_color', e.target.value)}
              dir="ltr"
            />
          </div>
        </div>
      </div>

      <div className="space-y-1.5">
        <Label>حالت نمایش</Label>
        <div className="grid grid-cols-3 gap-2">
          {[
            { value: 'text', label: 'متن فقط', icon: '📝' },
            { value: 'image', label: 'تصویر/گیف', icon: '🖼️' },
            { value: 'mixed', label: 'ترکیبی (متن + تصویر)', icon: '🎨' },
          ].map(opt => (
            <button
              key={opt.value}
              type="button"
              onClick={() => update('topbar_mode', opt.value)}
              className={`p-3 rounded-lg border-2 text-sm font-medium transition-all ${
                settings.topbar_mode === opt.value
                  ? 'border-[#dc2626] bg-red-50 text-[#dc2626]'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="text-xl mb-1">{opt.icon}</div>
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* تنظیمات متنی */}
      {(settings.topbar_mode === 'text' || settings.topbar_mode === 'mixed') && (
        <div className="space-y-3 p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center gap-2 text-sm font-bold text-gray-700">
            <Palette className="w-4 h-4" />
            تنظیمات متن
          </div>
          <div className="space-y-1.5">
            <Label>متن‌های سمت راست (با | جدا کنید)</Label>
            <Textarea
              value={settings.topbar_text_right}
              onChange={e => update('topbar_text_right', e.target.value)}
              rows={2}
              placeholder="ارسال به: تهران|پشتیبانی ۲۴ ساعته: ۰۲۱-۹۱۰۰۲۰۲۰"
            />
            <p className="text-xs text-gray-500">هر <code className="bg-gray-200 px-1 rounded">|</code> یک آیتم جداگانه می‌سازد</p>
          </div>
          <div className="space-y-1.5">
            <Label>متن‌های سمت چپ (با | جدا کنید)</Label>
            <Textarea
              value={settings.topbar_text_left}
              onChange={e => update('topbar_text_left', e.target.value)}
              rows={2}
              placeholder="ضمانت اصالت کالا|ارسال به سراسر کشور|پرداخت در محل"
            />
          </div>
        </div>
      )}

      {/* تنظیمات تصویر */}
      {(settings.topbar_mode === 'image' || settings.topbar_mode === 'mixed') && (
        <div className="space-y-3 p-4 bg-gray-50 rounded-lg">
          <div className="flex items-center gap-2 text-sm font-bold text-gray-700">
            <ImageIcon className="w-4 h-4" />
            تنظیمات تصویر/گیف
          </div>

          <div className="space-y-1.5">
            <Label>تصویر نوار</Label>
            <div className="flex items-center gap-2">
              <Input
                value={settings.topbar_image_url}
                onChange={e => update('topbar_image_url', e.target.value)}
                placeholder="/uploads/topbar/..."
                dir="ltr"
              />
              <Button
                type="button"
                variant="outline"
                onClick={() => fileRef.current?.click()}
                disabled={uploading}
                className="shrink-0"
              >
                {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                <span className="mr-1 hidden sm:inline">{uploading ? '...' : 'آپلود'}</span>
              </Button>
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                onChange={handleUpload}
                className="hidden"
              />
            </div>
            <p className="text-xs text-gray-500">پسوندهای مجاز: JPG, PNG, GIF, WebP, SVG — حداکثر ۱۰ مگابایت</p>
          </div>

          {settings.topbar_image_url && (
            <div className="border border-gray-200 rounded-lg p-2 bg-white">
              <img
                src={settings.topbar_image_url}
                alt="preview"
                className="max-h-20 mx-auto"
              />
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>لینک تصویر (اختیاری)</Label>
              <Input
                value={settings.topbar_image_link}
                onChange={e => update('topbar_image_link', e.target.value)}
                placeholder="/special یا https://..."
                dir="ltr"
              />
            </div>
            <div className="space-y-1.5">
              <Label>ارتفاع تصویر در نوار (پیکسل)</Label>
              <Input
                type="number"
                min={10}
                max={100}
                value={settings.topbar_image_height}
                onChange={e => update('topbar_image_height', e.target.value)}
              />
            </div>
          </div>
        </div>
      )}

      <Button onClick={handleSave} disabled={saving} className="w-full bg-[#dc2626] hover:bg-[#b91c1c]">
        {saving ? <Loader2 className="w-4 h-4 ml-1 animate-spin" /> : <Save className="w-4 h-4 ml-1" />}
        {saving ? 'در حال ذخیره...' : 'ذخیره تنظیمات نوار'}
      </Button>
    </div>
  );
}

export function AdminSettings() {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeSection, setActiveSection] = useState('contact');

  useEffect(() => {
    fetch('/api/admin/settings')
      .then(r => r.json())
      .then(data => {
        const obj: Record<string, string> = {};
        (data.settings || []).forEach((s: any) => { obj[s.key] = s.value; });
        setSettings(obj);
      })
      .finally(() => setLoading(false));
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings }),
      });
      if (res.ok) {
        toast.success('تغییرات ذخیره شد');
      } else {
        toast.error('خطا در ذخیره');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setSaving(false);
    }
  };

  const currentSection = sections.find(s => s.key === activeSection);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-[#dc2626]" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Settings className="w-6 h-6 text-[#dc2626]" />
          تنظیمات سایت
        </h2>
        <Button onClick={handleSave} disabled={saving} className="bg-[#dc2626] hover:bg-[#b91c1c]">
          {saving ? <Loader2 className="w-4 h-4 ml-1 animate-spin" /> : <Save className="w-4 h-4 ml-1" />}
          {saving ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
        </Button>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-sm text-blue-800">
        💡 تغییرات شما در تمام صفحات سایت اعمال می‌شود. پس از ویرایش، روی «ذخیره تغییرات» کلیک کنید.
      </div>

      {/* تب‌های بخش‌ها — responsive */}
      <ResponsiveTabs
        tabs={sections.map(s => ({ key: s.key, label: s.label, icon: s.icon, short: (s as any).short }))}
        activeTab={activeSection}
        onTabChange={setActiveSection}
        variant="subsection"
        maxVisible={3}
      />

      {/* فیلدهای بخش فعلی */}
      {activeSection === 'quick_links' ? (
        <QuickLinksEditor />
      ) : activeSection === 'topbar' ? (
        <TopBarEditor />
      ) : activeSection === 'sms' ? (
        <SmsEditor />
      ) : activeSection === 'email' ? (
        <EmailEditor />
      ) : activeSection === 'inbox' ? (
        <InboxViewer />
      ) : (
        <div className="bg-white rounded-xl p-6 shadow-sm space-y-4">
          {currentSection?.fields.map(field => (
            <div key={field.key} className="space-y-2">
              <Label htmlFor={field.key}>{field.label}</Label>
              {field.type === 'textarea' ? (
                <Textarea
                  id={field.key}
                  value={settings[field.key] || ''}
                  onChange={e => setSettings({ ...settings, [field.key]: e.target.value })}
                  rows={3}
                />
              ) : (
                <Input
                  id={field.key}
                  type={field.type === 'number' ? 'number' : 'text'}
                  value={settings[field.key] || ''}
                  onChange={e => setSettings({ ...settings, [field.key]: e.target.value })}
                  dir={field.type === 'email' || field.type === 'number' || settings[field.key]?.startsWith('http') ? 'ltr' : 'rtl'}
                />
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
