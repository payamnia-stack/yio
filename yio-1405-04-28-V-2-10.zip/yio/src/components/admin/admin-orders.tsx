'use client';

import { useState, useEffect } from 'react';
import {
  Search, ChevronRight, ChevronLeft, Package, Phone, MapPin, User, X,
  TrendingUp, Clock, CheckCircle, Truck, DollarSign, PackageCheck,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { formatPrice, toFa, orderStatuses, getOrderStatusInfo } from '@/lib/shop-data';
import { toast } from 'sonner';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

interface Order {
  id: number;
  orderNumber: string;
  status: string;
  totalAmount: number;
  shippingCost: number;
  finalAmount: number;
  paymentMethod: string;
  paymentStatus: string;
  shippingAddress: string;
  shippingCity?: string | null;
  postalCode?: string | null;
  recipientName: string;
  recipientPhone: string;
  notes?: string | null;
  trackingCode?: string | null;
  createdAt: string;
  customer: any;
  items: any[];
}

interface OrderStats {
  total: number;
  pending: number;
  confirmed: number;
  shipping: number;
  delivered: number;
  cancelled: number;
  totalRevenue: { _sum: { finalAmount: number | null } };
  pendingRevenue: { _sum: { finalAmount: number | null } };
}

export function AdminOrders({ onBack }: { onBack: () => void }) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [stats, setStats] = useState<OrderStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('all');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);

  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [trackingCode, setTrackingCode] = useState('');
  const [notes, setNotes] = useState('');

  const fetchOrders = async () => {
    setLoading(true);
    const params = new URLSearchParams({
      search,
      page: String(page),
      pageSize: '10',
    });
    if (status !== 'all') params.set('status', status);

    try {
      const res = await fetch(`/api/orders?${params}`);
      if (res.status === 401) {
        toast.error('سشن منقضی شده');
        onBack();
        return;
      }
      const data = await res.json();
      setOrders(data.orders || []);
      setStats(data.stats);
      setTotalPages(data.pagination?.totalPages || 1);
      setTotal(data.pagination?.total || 0);
    } catch {
      toast.error('خطا در دریافت سفارش‌ها');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      setPage(1);
      fetchOrders();
    }, 300);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, status]);

  useEffect(() => {
    fetchOrders();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page]);

  const updateOrderStatus = async (orderId: number, newStatus: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      if (res.ok) {
        toast.success('وضعیت سفارش به‌روزرسانی شد');
        fetchOrders();
        if (selectedOrder?.id === orderId) {
          const updated = await res.json();
          setSelectedOrder(updated.order);
        }
      }
    } catch {
      toast.error('خطا در به‌روزرسانی');
    }
  };

  const updatePaymentStatus = async (orderId: number, newStatus: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paymentStatus: newStatus }),
      });
      if (res.ok) {
        toast.success('وضعیت پرداخت به‌روزرسانی شد');
        fetchOrders();
        if (selectedOrder?.id === orderId) {
          const updated = await res.json();
          setSelectedOrder(updated.order);
        }
      }
    } catch {
      toast.error('خطا در به‌روزرسانی');
    }
  };

  const saveTrackingCode = async () => {
    if (!selectedOrder) return;
    try {
      const res = await fetch(`/api/orders/${selectedOrder.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ trackingCode, notes }),
      });
      if (res.ok) {
        toast.success('اطلاعات ذخیره شد');
        fetchOrders();
        const updated = await res.json();
        setSelectedOrder(updated.order);
      }
    } catch {
      toast.error('خطا در ذخیره');
    }
  };

  useEffect(() => {
    if (selectedOrder) {
      setTrackingCode(selectedOrder.trackingCode || '');
      setNotes(selectedOrder.notes || '');
    }
  }, [selectedOrder]);

  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return new Intl.DateTimeFormat('fa-IR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }).format(d);
    } catch {
      return dateStr;
    }
  };

  const statsCards = stats ? [
    { title: 'کل سفارش‌ها', value: toFa(stats.total), icon: Package, color: 'bg-blue-50 text-blue-600' },
    { title: 'در انتظار', value: toFa(stats.pending), icon: Clock, color: 'bg-amber-50 text-amber-600' },
    { title: 'در حال ارسال', value: toFa(stats.shipping), icon: Truck, color: 'bg-purple-50 text-purple-600' },
    { title: 'تحویل شده', value: toFa(stats.delivered), icon: CheckCircle, color: 'bg-green-50 text-green-600' },
  ] : [];

  return (
    <div className="space-y-4">
      {/* هدر */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Package className="w-6 h-6 text-[#dc2626]" />
          مدیریت سفارش‌ها
        </h2>
        <Button variant="outline" onClick={onBack}>
          بازگشت
        </Button>
      </div>

      {/* آمار */}
      {stats && (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {statsCards.map((card, idx) => {
              const Icon = card.icon;
              return (
                <div key={idx} className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
                  <div className={`w-10 h-10 rounded-lg ${card.color} flex items-center justify-center mb-2`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <p className="text-xs text-gray-500 mb-1">{card.title}</p>
                  <p className="text-2xl font-bold fa-num">{card.value}</p>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="bg-gradient-to-l from-green-500 to-green-600 rounded-xl p-4 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm opacity-90 mb-1">درآمد دریافت‌شده</p>
                  <p className="text-xl font-bold fa-num">
                    {formatPrice(stats.totalRevenue._sum.finalAmount || 0)} ت
                  </p>
                </div>
                <DollarSign className="w-10 h-10 opacity-30" />
              </div>
            </div>
            <div className="bg-gradient-to-l from-amber-500 to-orange-600 rounded-xl p-4 text-white">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm opacity-90 mb-1">درآمد در انتظار وصول</p>
                  <p className="text-xl font-bold fa-num">
                    {formatPrice(stats.pendingRevenue._sum.finalAmount || 0)} ت
                  </p>
                </div>
                <Clock className="w-10 h-10 opacity-30" />
              </div>
            </div>
          </div>
        </>
      )}

      {/* فیلترها */}
      <div className="bg-white rounded-xl p-4 shadow-sm">
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder="جستجو: شماره سفارش، نام، تلفن، کد رهگیری..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pr-10"
            />
          </div>
          <Select value={status} onValueChange={setStatus}>
            <SelectTrigger className="w-full md:w-44">
              <SelectValue placeholder="وضعیت" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">همه وضعیت‌ها</SelectItem>
              {orderStatuses.map(s => (
                <SelectItem key={s.value} value={s.value}>
                  {s.icon} {s.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="mt-3 text-sm text-gray-500 fa-num">
          نمایش {toFa(orders.length)} سفارش از {toFa(total)} سفارش
        </div>
      </div>

      {/* لیست سفارش‌ها */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-8 text-center">
            <div className="inline-block w-8 h-8 border-4 border-gray-200 border-t-[#dc2626] rounded-full animate-spin"></div>
            <p className="text-gray-500 mt-2">در حال بارگذاری...</p>
          </div>
        ) : orders.length === 0 ? (
          <div className="p-12 text-center">
            <Package className="w-16 h-16 mx-auto text-gray-300 mb-3" />
            <p className="text-gray-500">سفارشی یافت نشد</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {orders.map(order => {
              const statusInfo = getOrderStatusInfo(order.status);
              return (
                <div
                  key={order.id}
                  className="p-4 hover:bg-gray-50 cursor-pointer transition-colors"
                  onClick={() => setSelectedOrder(order)}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className="font-bold text-[#dc2626]">{order.orderNumber}</span>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${statusInfo.color}`}>
                          {statusInfo.icon} {statusInfo.label}
                        </span>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${
                          order.paymentStatus === 'paid' ? 'bg-green-100 text-green-700' :
                          order.paymentStatus === 'refunded' ? 'bg-red-100 text-red-700' :
                          'bg-gray-100 text-gray-700'
                        }`}>
                          {order.paymentStatus === 'paid' ? 'پرداخت شده' :
                           order.paymentStatus === 'refunded' ? 'بازگشت داده شده' : 'پرداخت نشده'}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-sm text-gray-600 mb-1">
                        <span className="flex items-center gap-1">
                          <User className="w-3.5 h-3.5" />
                          {order.recipientName}
                        </span>
                        <span className="flex items-center gap-1" dir="ltr">
                          <Phone className="w-3.5 h-3.5" />
                          {order.recipientPhone}
                        </span>
                      </div>
                      <div className="text-xs text-gray-500">
                        {order.items.length} کالا • {formatDate(order.createdAt)}
                      </div>
                      {order.trackingCode && (
                        <div className="text-xs text-purple-600 mt-1" dir="ltr">
                          کد رهگیری: {order.trackingCode}
                        </div>
                      )}
                    </div>
                    <div className="text-left shrink-0">
                      <div className="text-lg font-bold text-[#dc2626] fa-num">
                        {formatPrice(order.finalAmount)}
                      </div>
                      <div className="text-xs text-gray-500">تومان</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* صفحه‌بندی */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between p-4 border-t border-gray-100 bg-gray-50">
            <p className="text-sm text-gray-600 fa-num">
              صفحه {toFa(page)} از {toFa(totalPages)}
            </p>
            <div className="flex gap-1">
              <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>
                <ChevronRight className="w-4 h-4" />
              </Button>
              {Array.from({ length: Math.min(totalPages, 5) }).map((_, idx) => {
                const pn = idx + 1;
                return (
                  <Button
                    key={pn}
                    variant={page === pn ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setPage(pn)}
                    className={page === pn ? 'bg-[#dc2626] hover:bg-[#b91c1c]' : ''}
                  >
                    <span className="fa-num">{toFa(pn)}</span>
                  </Button>
                );
              })}
              <Button variant="outline" size="sm" disabled={page === totalPages} onClick={() => setPage(p => p + 1)}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* مودال جزئیات سفارش */}
      <Sheet open={selectedOrder !== null} onOpenChange={(open) => !open && setSelectedOrder(null)}>
        <SheetContent side="left" className="w-full sm:max-w-2xl p-0 overflow-y-auto">
          {selectedOrder && (
            <>
              <SheetHeader className="p-4 border-b border-gray-100 bg-white sticky top-0 z-10">
                <SheetTitle className="flex items-center justify-between">
                  <span className="text-[#dc2626]">{selectedOrder.orderNumber}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${getOrderStatusInfo(selectedOrder.status).color}`}>
                    {getOrderStatusInfo(selectedOrder.status).label}
                  </span>
                </SheetTitle>
              </SheetHeader>

              <div className="p-4 space-y-4">
                {/* اطلاعات گیرنده */}
                <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                  <h3 className="font-bold text-sm mb-2">اطلاعات گیرنده</h3>
                  <div className="flex items-center gap-2 text-sm">
                    <User className="w-4 h-4 text-gray-400" />
                    <span>{selectedOrder.recipientName}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm" dir="ltr">
                    <Phone className="w-4 h-4 text-gray-400" />
                    <span>{selectedOrder.recipientPhone}</span>
                  </div>
                  <div className="flex items-start gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-gray-400 mt-0.5" />
                    <span>{selectedOrder.shippingAddress}</span>
                  </div>
                  {selectedOrder.shippingCity && (
                    <div className="text-xs text-gray-500">
                      شهر: {selectedOrder.shippingCity}
                      {selectedOrder.postalCode && ` • کد پستی: ${selectedOrder.postalCode}`}
                    </div>
                  )}
                </div>

                {/* اقلام سفارش */}
                <div className="space-y-2">
                  <h3 className="font-bold text-sm">اقلام سفارش ({toFa(selectedOrder.items.length)} کالا)</h3>
                  {selectedOrder.items.map((item: any) => (
                    <div key={item.id} className="flex gap-3 bg-white border border-gray-100 rounded-lg p-3">
                      <img
                        src={item.productImage}
                        alt={item.productTitle}
                        className="w-16 h-16 object-cover rounded-lg shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium line-clamp-2">{item.productTitle}</p>
                        {item.color && <p className="text-xs text-gray-500 mt-1">رنگ: {item.color}</p>}
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-xs text-gray-500 fa-num">
                            {toFa(item.quantity)} عدد × {formatPrice(item.price)}
                          </span>
                          <span className="text-sm font-bold fa-num">
                            {formatPrice(item.price * item.quantity)} ت
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* جمع‌بندی */}
                <div className="bg-gray-50 rounded-lg p-4 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">جمع کالاها:</span>
                    <span className="fa-num">{formatPrice(selectedOrder.totalAmount)} ت</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">هزینه ارسال:</span>
                    <span className="fa-num">
                      {selectedOrder.shippingCost === 0 ? 'رایگان' : `${formatPrice(selectedOrder.shippingCost)} ت`}
                    </span>
                  </div>
                  <div className="flex justify-between font-bold pt-2 border-t border-gray-200">
                    <span>مبلغ کل:</span>
                    <span className="text-[#dc2626] fa-num">{formatPrice(selectedOrder.finalAmount)} ت</span>
                  </div>
                  <div className="text-xs text-gray-500 pt-1">
                    روش پرداخت: {selectedOrder.paymentMethod === 'cod' ? 'پرداخت در محل' : 'آنلاین'}
                  </div>
                </div>

                {/* تغییر وضعیت */}
                <div className="space-y-2">
                  <h3 className="font-bold text-sm">تغییر وضعیت سفارش</h3>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {orderStatuses.map(s => (
                      <button
                        key={s.value}
                        onClick={() => updateOrderStatus(selectedOrder.id, s.value)}
                        className={`p-2 rounded-lg text-xs border transition-all ${
                          selectedOrder.status === s.value
                            ? 'border-[#dc2626] bg-red-50 text-[#dc2626]'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        {s.icon} {s.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* وضعیت پرداخت */}
                <div className="space-y-2">
                  <h3 className="font-bold text-sm">وضعیت پرداخت</h3>
                  <div className="flex gap-2">
                    <button
                      onClick={() => updatePaymentStatus(selectedOrder.id, 'unpaid')}
                      className={`flex-1 p-2 rounded-lg text-xs border ${
                        selectedOrder.paymentStatus === 'unpaid' ? 'border-[#dc2626] bg-red-50' : 'border-gray-200'
                      }`}
                    >
                      پرداخت نشده
                    </button>
                    <button
                      onClick={() => updatePaymentStatus(selectedOrder.id, 'paid')}
                      className={`flex-1 p-2 rounded-lg text-xs border ${
                        selectedOrder.paymentStatus === 'paid' ? 'border-green-500 bg-green-50' : 'border-gray-200'
                      }`}
                    >
                      پرداخت شده
                    </button>
                    <button
                      onClick={() => updatePaymentStatus(selectedOrder.id, 'refunded')}
                      className={`flex-1 p-2 rounded-lg text-xs border ${
                        selectedOrder.paymentStatus === 'refunded' ? 'border-red-500 bg-red-50' : 'border-gray-200'
                      }`}
                    >
                      بازگشت داده شده
                    </button>
                  </div>
                </div>

                {/* کد رهگیری و یادداشت */}
                <div className="space-y-3">
                  <h3 className="font-bold text-sm">اطلاعات ارسال</h3>
                  <div className="space-y-2">
                    <Label htmlFor="trackingCode">کد رهگیری پستی</Label>
                    <Input
                      id="trackingCode"
                      value={trackingCode}
                      onChange={e => setTrackingCode(e.target.value)}
                      placeholder="مثلا: TRK12345678"
                      dir="ltr"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="notes">یادداشت داخلی</Label>
                    <Textarea
                      id="notes"
                      value={notes}
                      onChange={e => setNotes(e.target.value)}
                      placeholder="یادداشت برای پرسنل..."
                      rows={2}
                    />
                  </div>
                  <Button onClick={saveTrackingCode} className="w-full bg-[#dc2626] hover:bg-[#b91c1c]">
                    ذخیره اطلاعات
                  </Button>
                </div>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
