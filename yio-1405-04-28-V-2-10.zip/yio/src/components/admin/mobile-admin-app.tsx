'use client';

import { useState, useEffect } from 'react';
import {
  Home, Package, ShoppingBag, BarChart3, Settings, LogOut,
  Plus, Search, Edit2, Trash2, TrendingUp, Clock, CheckCircle,
  Truck, DollarSign, Users, Bell, Menu, X, ChevronLeft,
  Phone, MapPin, User, Eye, EyeOff, Star, CreditCard, Banknote, Wallet, Building, Shield, Ticket,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Image from 'next/image';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { ProductForm } from './product-form';
import { MobilePaymentMethods } from './mobile-payment-methods';
import { MobileCoupons } from './mobile-coupons';
import {
  formatPrice, toFa, parseColors, parseImages, parseVideos,
  orderStatuses, getOrderStatusInfo,
} from '@/lib/shop-data';

interface MobileAdminAppProps {
  onExit: () => void;
}

type Tab = 'dashboard' | 'products' | 'orders' | 'payments' | 'coupons' | 'reports' | 'settings';

export function MobileAdminApp({ onExit }: MobileAdminAppProps) {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [showProductForm, setShowProductForm] = useState(false);
  const [editProduct, setEditProduct] = useState<any>(null);

  const handleLogout = async () => {
    try {
      await fetch('/api/admin/logout', { method: 'POST' });
      toast.success('خارج شدید');
      onExit();
    } catch {
      toast.error('خطا در خروج');
    }
  };

  return (
    <div className="fixed inset-0 z-40 bg-gray-50 flex flex-col" style={{ maxWidth: '100%', margin: '0 auto' }}>
      {/* هدر اپ */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-2">
          <div className="relative w-9 h-9">
            <Image
              src="/yio-logo.png"
              alt="YIO"
              fill
              sizes="36px"
              className="object-contain rounded-lg"
            />
          </div>
          <div>
            <h1 className="font-bold text-sm text-[#dc2626]">YIO اپ مدیریت</h1>
            <p className="text-[10px] text-gray-500">فروشگاه محصولات چوبی</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={handleLogout}
          className="text-red-600"
        >
          <LogOut className="w-5 h-5" />
        </Button>
      </div>

      {/* محتوای تب فعال */}
      <div className="flex-1 overflow-y-auto pb-20">
        {activeTab === 'dashboard' && <MobileDashboard onNavigate={setActiveTab} />}
        {activeTab === 'products' && (
          <MobileProducts
            onAdd={() => { setEditProduct(null); setShowProductForm(true); }}
            onEdit={(p) => { setEditProduct(p); setShowProductForm(true); }}
          />
        )}
        {activeTab === 'orders' && <MobileOrders />}
        {activeTab === 'payments' && <MobilePaymentMethods />}
        {activeTab === 'coupons' && <MobileCoupons />}
        {activeTab === 'reports' && <MobileReports />}
        {activeTab === 'settings' && <MobileSettings onExit={onExit} />}
      </div>

      {/* نوار پایین */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-1 py-1.5 flex items-center justify-around z-30 overflow-x-auto no-scrollbar" style={{ maxWidth: '100%', margin: '0 auto' }}>
        <TabButton
          active={activeTab === 'dashboard'}
          onClick={() => setActiveTab('dashboard')}
          icon={Home}
          label="خانه"
        />
        <TabButton
          active={activeTab === 'products'}
          onClick={() => setActiveTab('products')}
          icon={Package}
          label="محصولات"
        />
        <TabButton
          active={activeTab === 'orders'}
          onClick={() => setActiveTab('orders')}
          icon={ShoppingBag}
          label="سفارش‌ها"
        />
        <TabButton
          active={activeTab === 'payments'}
          onClick={() => setActiveTab('payments')}
          icon={CreditCard}
          label="پرداخت"
        />
        <TabButton
          active={activeTab === 'coupons'}
          onClick={() => setActiveTab('coupons')}
          icon={Ticket}
          label="تخفیف"
        />
        <TabButton
          active={activeTab === 'reports'}
          onClick={() => setActiveTab('reports')}
          icon={BarChart3}
          label="گزارش"
        />
        <TabButton
          active={activeTab === 'settings'}
          onClick={() => setActiveTab('settings')}
          icon={Settings}
          label="تنظیمات"
        />
      </div>

      {/* فرم محصول */}
      {showProductForm && (
        <ProductForm
          product={editProduct}
          onSave={() => {
            setShowProductForm(false);
            setEditProduct(null);
          }}
          onCancel={() => {
            setShowProductForm(false);
            setEditProduct(null);
          }}
        />
      )}
    </div>
  );
}

function TabButton({ active, onClick, icon: Icon, label }: {
  active: boolean;
  onClick: () => void;
  icon: any;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-lg transition-colors ${
        active ? 'text-[#dc2626]' : 'text-gray-500'
      }`}
    >
      <Icon className={`w-5 h-5 ${active ? 'fill-red-50' : ''}`} />
      <span className="text-[10px] font-medium">{label}</span>
    </button>
  );
}

// داشبورد موبایل
function MobileDashboard({ onNavigate }: { onNavigate: (tab: Tab) => void }) {
  const [stats, setStats] = useState<any>(null);
  const [orderStats, setOrderStats] = useState<any>(null);
  const [recentOrders, setRecentOrders] = useState<any[]>([]);

  useEffect(() => {
    fetch('/api/products?pageSize=1').then(r => r.json()).then(d => setStats(d.stats)).catch(() => {});
    fetch('/api/orders?pageSize=5').then(r => r.json()).then(d => {
      setOrderStats(d.stats);
      setRecentOrders(d.orders || []);
    }).catch(() => {});
  }, []);

  const cards = [
    { title: 'محصولات', value: stats?.total || 0, icon: Package, color: 'bg-blue-500', tab: 'products' as Tab },
    { title: 'سفارش‌ها', value: orderStats?.total || 0, icon: ShoppingBag, color: 'bg-purple-500', tab: 'orders' as Tab },
    { title: 'در انتظار', value: orderStats?.pending || 0, icon: Clock, color: 'bg-amber-500', tab: 'orders' as Tab },
    { title: 'تحویل شده', value: orderStats?.delivered || 0, icon: CheckCircle, color: 'bg-green-500', tab: 'orders' as Tab },
  ];

  return (
    <div className="p-3 space-y-4">
      <h2 className="text-lg font-bold">داشبورد</h2>

      {/* کارت‌های آمار */}
      <div className="grid grid-cols-2 gap-2">
        {cards.map((card, idx) => {
          const Icon = card.icon;
          return (
            <button
              key={idx}
              onClick={() => onNavigate(card.tab)}
              className="bg-white rounded-xl p-3 border border-gray-100 shadow-sm text-right"
            >
              <div className={`w-9 h-9 rounded-lg ${card.color} text-white flex items-center justify-center mb-2`}>
                <Icon className="w-5 h-5" />
              </div>
              <p className="text-[10px] text-gray-500">{card.title}</p>
              <p className="text-xl font-bold fa-num">{toFa(card.value)}</p>
            </button>
          );
        })}
      </div>

      {/* درآمد */}
      <div className="bg-gradient-to-l from-green-500 to-green-600 rounded-xl p-4 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs opacity-90">درآمد دریافت‌شده</p>
            <p className="text-lg font-bold fa-num">
              {formatPrice(orderStats?.totalRevenue?._sum?.finalAmount || 0)} ت
            </p>
          </div>
          <DollarSign className="w-10 h-10 opacity-30" />
        </div>
      </div>

      {/* آخرین سفارش‌ها */}
      <div className="bg-white rounded-xl p-3 border border-gray-100 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-bold text-sm">آخرین سفارش‌ها</h3>
          <Button variant="ghost" size="sm" onClick={() => onNavigate('orders')} className="text-[#dc2626] text-xs p-1">
            همه
            <ChevronLeft className="w-3 h-3" />
          </Button>
        </div>
        {recentOrders.length === 0 ? (
          <p className="text-xs text-gray-500 text-center py-4">سفارشی وجود ندارد</p>
        ) : (
          <div className="space-y-2">
            {recentOrders.map((order: any) => {
              const statusInfo = getOrderStatusInfo(order.status);
              return (
                <div key={order.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                  <div>
                    <p className="text-xs font-bold text-[#dc2626]">{order.orderNumber}</p>
                    <p className="text-[10px] text-gray-500">{order.recipientName}</p>
                  </div>
                  <div className="text-left">
                    <p className="text-xs font-bold fa-num">{formatPrice(order.finalAmount)} ت</p>
                    <span className={`text-[9px] px-1.5 py-0.5 rounded-full ${statusInfo.color}`}>
                      {statusInfo.icon} {statusInfo.label}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* دکمه افزودن سریع محصول */}
      <Button
        onClick={() => onNavigate('products')}
        className="w-full bg-[#dc2626] hover:bg-[#b91c1c] h-12"
      >
        <Plus className="w-5 h-5 ml-1" />
        افزودن محصول جدید
      </Button>
    </div>
  );
}

// محصولات موبایل
function MobileProducts({ onAdd, onEdit }: { onAdd: () => void; onEdit: (p: any) => void }) {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  const fetchProducts = async () => {
    setLoading(true);
    const params = new URLSearchParams({ search, pageSize: '20' });
    try {
      const res = await fetch(`/api/products?${params}`);
      if (res.status === 401) return;
      const data = await res.json();
      setProducts(data.products || []);
    } catch {
      toast.error('خطا در دریافت محصولات');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const t = setTimeout(fetchProducts, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);

  const handleDelete = async () => {
    if (!deleteId) return;
    setDeleteLoading(true);
    try {
      const res = await fetch(`/api/products/${deleteId}`, { method: 'DELETE' });
      if (res.ok) {
        toast.success('محصول حذف شد');
        setDeleteId(null);
        fetchProducts();
      }
    } catch {
      toast.error('خطا در حذف');
    } finally {
      setDeleteLoading(false);
    }
  };

  const handleToggleStock = async (p: any) => {
    try {
      await fetch(`/api/products/${p.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ inStock: !p.inStock }),
      });
      fetchProducts();
    } catch {}
  };

  return (
    <div className="p-3 space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold">محصولات</h2>
        <Button onClick={onAdd} size="sm" className="bg-[#dc2626] hover:bg-[#b91c1c]">
          <Plus className="w-4 h-4 ml-1" />
          جدید
        </Button>
      </div>

      {/* جستجو */}
      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <Input
          type="text"
          placeholder="جستجو..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="pr-9 h-10"
        />
      </div>

      {/* لیست محصولات */}
      {loading ? (
        <div className="text-center py-8">
          <div className="inline-block w-6 h-6 border-3 border-gray-200 border-t-[#dc2626] rounded-full animate-spin"></div>
        </div>
      ) : products.length === 0 ? (
        <div className="text-center py-8 text-gray-500 text-sm">محصولی یافت نشد</div>
      ) : (
        <div className="space-y-2">
          {products.map(p => {
            const imgCount = parseImages(p.images).length + 1;
            const vidCount = parseVideos(p.videos).length;
            return (
              <div key={p.id} className="bg-white rounded-xl p-3 border border-gray-100 shadow-sm">
                <div className="flex gap-3">
                  <img src={p.image} alt={p.title} className="w-16 h-16 object-cover rounded-lg shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium line-clamp-2 mb-1">{p.title}</p>
                    <div className="flex items-center gap-1 mb-1 flex-wrap">
                      <span className="text-[9px] bg-gray-100 px-1.5 py-0.5 rounded">{p.category}</span>
                      {p.woodType && <span className="text-[9px] bg-amber-50 text-amber-700 px-1.5 py-0.5 rounded">{p.woodType}</span>}
                      {imgCount > 1 && <span className="text-[9px] bg-blue-50 text-blue-600 px-1.5 py-0.5 rounded fa-num">📸 {toFa(imgCount)}</span>}
                      {vidCount > 0 && <span className="text-[9px] bg-purple-50 text-purple-600 px-1.5 py-0.5 rounded fa-num">🎬 {toFa(vidCount)}</span>}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-[#dc2626] fa-num">
                        {formatPrice(p.discountPrice || p.price)}
                      </span>
                      <button
                        onClick={() => handleToggleStock(p)}
                        className={`text-[9px] px-1.5 py-0.5 rounded ${
                          p.inStock ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'
                        }`}
                      >
                        {p.inStock ? 'موجود' : 'ناموجود'}
                      </button>
                    </div>
                  </div>
                </div>
                <div className="flex gap-1 mt-2 pt-2 border-t border-gray-50">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onEdit(p)}
                    className="flex-1 h-8 text-xs"
                  >
                    <Edit2 className="w-3 h-3 ml-1" />
                    ویرایش
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setDeleteId(p.id)}
                    className="h-8 text-xs text-red-600"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <AlertDialog open={deleteId !== null} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>حذف محصول</AlertDialogTitle>
            <AlertDialogDescription>آیا مطمئن هستید؟ این عملیات قابل بازگشت نیست.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleteLoading}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteLoading ? 'در حال حذف...' : 'حذف'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// سفارش‌ها موبایل
function MobileOrders() {
  const [orders, setOrders] = useState<any[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('all');
  const [selectedOrder, setSelectedOrder] = useState<any>(null);

  const fetchOrders = async () => {
    setLoading(true);
    const params = new URLSearchParams({ search, pageSize: '20' });
    if (status !== 'all') params.set('status', status);
    try {
      const res = await fetch(`/api/orders?${params}`);
      if (res.status === 401) return;
      const data = await res.json();
      setOrders(data.orders || []);
      setStats(data.stats);
    } catch {
      toast.error('خطا در دریافت سفارش‌ها');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const t = setTimeout(fetchOrders, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, status]);

  const updateStatus = async (orderId: number, newStatus: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      if (res.ok) {
        toast.success('وضعیت به‌روزرسانی شد');
        fetchOrders();
        if (selectedOrder?.id === orderId) {
          const data = await res.json();
          setSelectedOrder(data.order);
        }
      }
    } catch {}
  };

  return (
    <div className="p-3 space-y-3">
      <h2 className="text-lg font-bold">سفارش‌ها</h2>

      {/* آمار سریع */}
      {stats && (
        <div className="grid grid-cols-4 gap-1">
          {[
            { label: 'کل', value: stats.total, color: 'bg-blue-500' },
            { label: 'در انتظار', value: stats.pending, color: 'bg-amber-500' },
            { label: 'ارسال', value: stats.shipping, color: 'bg-purple-500' },
            { label: 'تحویل', value: stats.delivered, color: 'bg-green-500' },
          ].map((s, i) => (
            <div key={i} className="bg-white rounded-lg p-2 text-center border border-gray-100">
              <div className={`w-2 h-2 rounded-full ${s.color} mx-auto mb-1`}></div>
              <p className="text-base font-bold fa-num">{toFa(s.value)}</p>
              <p className="text-[8px] text-gray-500">{s.label}</p>
            </div>
          ))}
        </div>
      )}

      {/* فیلتر */}
      <Select value={status} onValueChange={setStatus}>
        <SelectTrigger className="h-10">
          <SelectValue placeholder="همه وضعیت‌ها" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">همه وضعیت‌ها</SelectItem>
          {orderStatuses.map(s => (
            <SelectItem key={s.value} value={s.value}>{s.icon} {s.label}</SelectItem>
          ))}
        </SelectContent>
      </Select>

      <div className="relative">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <Input
          type="text"
          placeholder="جستجو: شماره، نام، تلفن..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="pr-9 h-10"
        />
      </div>

      {/* لیست سفارش‌ها */}
      {loading ? (
        <div className="text-center py-8">
          <div className="inline-block w-6 h-6 border-3 border-gray-200 border-t-[#dc2626] rounded-full animate-spin"></div>
        </div>
      ) : orders.length === 0 ? (
        <div className="text-center py-8 text-gray-500 text-sm">سفارشی یافت نشد</div>
      ) : (
        <div className="space-y-2">
          {orders.map(order => {
            const statusInfo = getOrderStatusInfo(order.status);
            return (
              <button
                key={order.id}
                onClick={() => setSelectedOrder(order)}
                className="w-full bg-white rounded-xl p-3 border border-gray-100 shadow-sm text-right"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-[#dc2626]">{order.orderNumber}</span>
                  <span className={`text-[9px] px-1.5 py-0.5 rounded-full ${statusInfo.color}`}>
                    {statusInfo.icon} {statusInfo.label}
                  </span>
                </div>
                <p className="text-xs font-medium">{order.recipientName}</p>
                <div className="flex items-center justify-between mt-1">
                  <span className="text-[10px] text-gray-500 fa-num">{toFa(order.items.length)} کالا</span>
                  <span className="text-sm font-bold fa-num">{formatPrice(order.finalAmount)} ت</span>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {/* مودال جزئیات سفارش */}
      <Sheet open={selectedOrder !== null} onOpenChange={(open) => !open && setSelectedOrder(null)}>
        <SheetContent side="bottom" className="h-[90vh] p-0 overflow-y-auto rounded-t-2xl">
          {selectedOrder && (
            <>
              <SheetHeader className="p-4 border-b border-gray-100 sticky top-0 bg-white z-10">
                <SheetTitle className="flex items-center justify-between">
                  <span className="text-[#dc2626]">{selectedOrder.orderNumber}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${getOrderStatusInfo(selectedOrder.status).color}`}>
                    {getOrderStatusInfo(selectedOrder.status).label}
                  </span>
                </SheetTitle>
              </SheetHeader>

              <div className="p-4 space-y-4">
                {/* اطلاعات گیرنده */}
                <div className="bg-gray-50 rounded-lg p-3 space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-gray-400" />
                    <span>{selectedOrder.recipientName}</span>
                  </div>
                  <div className="flex items-center gap-2" dir="ltr">
                    <Phone className="w-4 h-4 text-gray-400" />
                    <span>{selectedOrder.recipientPhone}</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 text-gray-400 mt-0.5" />
                    <span>{selectedOrder.shippingAddress}</span>
                  </div>
                </div>

                {/* اقلام */}
                <div className="space-y-2">
                  <h3 className="font-bold text-sm">اقلام ({toFa(selectedOrder.items.length)})</h3>
                  {selectedOrder.items.map((item: any) => (
                    <div key={item.id} className="flex gap-2 bg-white border border-gray-100 rounded-lg p-2">
                      <img src={item.productImage} alt="" className="w-12 h-12 object-cover rounded shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs line-clamp-2">{item.productTitle}</p>
                        <p className="text-[10px] text-gray-500 fa-num">{toFa(item.quantity)} عدد</p>
                      </div>
                      <span className="text-xs font-bold fa-num">{formatPrice(item.price * item.quantity)} ت</span>
                    </div>
                  ))}
                </div>

                {/* جمع */}
                <div className="bg-gray-50 rounded-lg p-3 space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>جمع کالاها:</span>
                    <span className="fa-num">{formatPrice(selectedOrder.totalAmount)} ت</span>
                  </div>
                  <div className="flex justify-between">
                    <span>ارسال:</span>
                    <span className="fa-num">{selectedOrder.shippingCost === 0 ? 'رایگان' : `${formatPrice(selectedOrder.shippingCost)} ت`}</span>
                  </div>
                  <div className="flex justify-between font-bold pt-1 border-t border-gray-200">
                    <span>کل:</span>
                    <span className="text-[#dc2626] fa-num">{formatPrice(selectedOrder.finalAmount)} ت</span>
                  </div>
                </div>

                {/* تغییر وضعیت */}
                <div className="space-y-2">
                  <h3 className="font-bold text-sm">تغییر وضعیت</h3>
                  <div className="grid grid-cols-2 gap-1">
                    {orderStatuses.map(s => (
                      <button
                        key={s.value}
                        onClick={() => updateStatus(selectedOrder.id, s.value)}
                        className={`p-2 rounded-lg text-xs border ${
                          selectedOrder.status === s.value
                            ? 'border-[#dc2626] bg-red-50 text-[#dc2626]'
                            : 'border-gray-200'
                        }`}
                      >
                        {s.icon} {s.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* کد رهگیری */}
                {selectedOrder.trackingCode && (
                  <div className="bg-purple-50 rounded-lg p-3 text-sm">
                    <p className="text-xs text-purple-600 mb-1">کد رهگیری:</p>
                    <p className="font-bold text-purple-800 fa-num" dir="ltr">{selectedOrder.trackingCode}</p>
                  </div>
                )}
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}

// گزارش‌ها موبایل
function MobileReports() {
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    fetch('/api/orders?pageSize=1').then(r => r.json()).then(d => setStats(d.stats)).catch(() => {});
  }, []);

  return (
    <div className="p-3 space-y-3">
      <h2 className="text-lg font-bold">گزارش‌ها</h2>

      <div className="grid grid-cols-2 gap-2">
        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-4 text-white">
          <DollarSign className="w-8 h-8 opacity-30 mb-2" />
          <p className="text-xs opacity-90">درآمد دریافت‌شده</p>
          <p className="text-lg font-bold fa-num">{formatPrice(stats?.totalRevenue?._sum?.finalAmount || 0)} ت</p>
        </div>
        <div className="bg-gradient-to-br from-amber-500 to-orange-600 rounded-xl p-4 text-white">
          <Clock className="w-8 h-8 opacity-30 mb-2" />
          <p className="text-xs opacity-90">در انتظار وصول</p>
          <p className="text-lg font-bold fa-num">{formatPrice(stats?.pendingRevenue?._sum?.finalAmount || 0)} ت</p>
        </div>
      </div>

      {/* وضعیت سفارش‌ها */}
      <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
        <h3 className="font-bold text-sm mb-3">وضعیت سفارش‌ها</h3>
        {orderStatuses.map(s => {
          const count = stats ? (stats as any)[s.value] || 0 : 0;
          const total = stats?.total || 1;
          const percent = (count / total) * 100;
          return (
            <div key={s.value} className="mb-3">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs">{s.icon} {s.label}</span>
                <span className="text-xs font-bold fa-num">{toFa(count)}</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#dc2626] rounded-full transition-all"
                  style={{ width: `${percent}%` }}
                ></div>
              </div>
            </div>
          );
        })}
      </div>

      {/* آمار کلی */}
      <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
        <h3 className="font-bold text-sm mb-3">آمار کلی</h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-600">کل سفارش‌ها:</span>
            <span className="font-bold fa-num">{toFa(stats?.total || 0)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">تحویل شده:</span>
            <span className="font-bold text-green-600 fa-num">{toFa(stats?.delivered || 0)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">در حال ارسال:</span>
            <span className="font-bold text-purple-600 fa-num">{toFa(stats?.shipping || 0)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">لغو شده:</span>
            <span className="font-bold text-red-600 fa-num">{toFa(stats?.cancelled || 0)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// تنظیمات موبایل
function MobileSettings({ onExit }: { onExit: () => void }) {
  return (
    <div className="p-3 space-y-3">
      <h2 className="text-lg font-bold">تنظیمات</h2>

      <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm space-y-3">
        <h3 className="font-bold text-sm">درباره اپلیکیشن</h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-600">نسخه:</span>
            <span className="font-medium fa-num">۱.۰.۰</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">برند:</span>
            <span className="font-medium">YIO</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">نوع:</span>
            <span className="font-medium">PWA</span>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm space-y-3">
        <h3 className="font-bold text-sm">راهنمای نصب</h3>
        <p className="text-xs text-gray-600 leading-5">
          برای نصب این اپ روی موبایل اندروید:
        </p>
        <ol className="text-xs text-gray-600 space-y-1 list-decimal pr-4">
          <li>در مرورگر Chrome سایت را باز کنید</li>
          <li>از منوی بالا (⋮) گزینه «Add to Home screen» را انتخاب کنید</li>
          <li>روی «Add» کلیک کنید</li>
          <li>اپ از صفحه اصلی موبایل شما قابل دسترسی است</li>
        </ol>
      </div>

      <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm space-y-3">
        <h3 className="font-bold text-sm">امکانات</h3>
        <div className="space-y-2 text-xs">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-500" />
            <span>مدیریت محصولات (افزودن، ویرایش، حذف)</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-500" />
            <span>گالری تصاویر (تا ۱۰ عکس) و ویدیو (تا ۳ ویدیو)</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-500" />
            <span>مدیریت سفارش‌ها و تغییر وضعیت</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-500" />
            <span>گزارش‌گیری مالی و آماری</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-green-500" />
            <span>کار آفلاین (PWA)</span>
          </div>
        </div>
      </div>

      <Button
        onClick={onExit}
        variant="outline"
        className="w-full text-red-600"
      >
        <LogOut className="w-4 h-4 ml-1" />
        خروج از اپ
      </Button>
    </div>
  );
}
