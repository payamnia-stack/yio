'use client';

import { Package, TrendingUp, AlertCircle, Star } from 'lucide-react';
import { formatPrice, toFa } from '@/lib/shop-data';

interface Stats {
  total: number;
  inStock: number;
  outOfStock: number;
  special: number;
  totalValue: { _sum: { price: number | null } };
}

export function AdminStats({ stats }: { stats: Stats | null }) {
  if (!stats) return null;

  const cards = [
    {
      title: 'کل محصولات',
      value: toFa(stats.total),
      icon: Package,
      color: 'bg-blue-50 text-blue-600',
      bgColor: 'bg-blue-500',
    },
    {
      title: 'موجود در انبار',
      value: toFa(stats.inStock),
      icon: TrendingUp,
      color: 'bg-green-50 text-green-600',
      bgColor: 'bg-green-500',
    },
    {
      title: 'ناموجود',
      value: toFa(stats.outOfStock),
      icon: AlertCircle,
      color: 'bg-red-50 text-red-600',
      bgColor: 'bg-red-500',
    },
    {
      title: 'محصولات فروش ویژه',
      value: toFa(stats.special),
      icon: Star,
      color: 'bg-amber-50 text-amber-600',
      bgColor: 'bg-amber-500',
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 mb-6">
      {cards.map((card, idx) => {
        const Icon = card.icon;
        return (
          <div
            key={idx}
            className="bg-white rounded-xl p-4 md:p-5 border border-gray-100 shadow-sm"
          >
            <div className="flex items-center justify-between mb-2">
              <div className={`w-10 h-10 rounded-lg ${card.color} flex items-center justify-center`}>
                <Icon className="w-5 h-5" />
              </div>
            </div>
            <p className="text-xs text-gray-500 mb-1">{card.title}</p>
            <p className="text-2xl font-bold fa-num">{card.value}</p>
          </div>
        );
      })}

      {/* ارزش کل انبار */}
      <div className="col-span-2 md:col-span-4 bg-gradient-to-l from-[#dc2626] to-[#991b1b] rounded-xl p-5 text-white">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm opacity-90 mb-1">ارزش کل انبار</p>
            <p className="text-3xl font-bold fa-num">
              {formatPrice(stats.totalValue._sum.price || 0)}
              <span className="text-base mr-2">تومان</span>
            </p>
          </div>
          <div className="text-5xl opacity-30">💰</div>
        </div>
      </div>
    </div>
  );
}
