'use client';

import { useState, useEffect, useRef } from 'react';
import { ChevronDown, MoreHorizontal, X } from 'lucide-react';

export interface TabItem {
  key: string;
  label: string;
  icon?: any;
  short?: string; // نسخه کوتاه برای موبایل
}

interface ResponsiveTabsProps {
  tabs: TabItem[];
  activeTab: string;
  onTabChange: (key: string) => void;
  variant?: 'panel' | 'subsection'; // panel: پنل اصلی (با نوار پایین موبایل) | subsection: تب داخلی
  maxVisible?: number; // حداکثر تب‌های قابل دیدن قبل از «بیشتر» (در حالت subsection)
}

/**
 * سیستم تب responsive یکپارچه
 *
 * - در دسکتاپ بزرگ (lg+): همه تب‌ها به‌صورت افقی
 * - در تبلت/دسکتاپ کوچک (sm تا lg): maxVisible تب اصلی + دکمه «بیشتر» کشویی
 * - در موبایل (variant=panel): نوار پایین ثابت + دکمه «بیشتر»
 * - در موبایل (variant=subsection): dropdown کشویی
 */
export function ResponsiveTabs({
  tabs,
  activeTab,
  onTabChange,
  variant = 'subsection',
  maxVisible = 4,
}: ResponsiveTabsProps) {
  const [moreOpen, setMoreOpen] = useState(false);
  const moreRef = useRef<HTMLDivElement>(null);

  // بستن منوی «بیشتر» با کلیک بیرون یا Escape
  useEffect(() => {
    if (!moreOpen) return;

    const handleClickOutside = (e: MouseEvent) => {
      if (moreRef.current && !moreRef.current.contains(e.target as Node)) {
        setMoreOpen(false);
      }
    };

    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMoreOpen(false);
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [moreOpen]);

  const handleSelect = (key: string) => {
    onTabChange(key);
    setMoreOpen(false);
  };

  const visibleTabs = tabs.slice(0, maxVisible);
  const moreTabs = tabs.slice(maxVisible);
  const hasMore = moreTabs.length > 0;
  const isMoreActive = moreTabs.some(t => t.key === activeTab);

  // ============= variant=panel: نوار پایین موبایل + تب‌های افقی دسکتاپ =============
  if (variant === 'panel') {
    return (
      <>
        {/* تب‌های افقی — دسکتاپ و تبلت (md+) — با اسکرول افقی */}
        <div
          className="hidden md:flex w-full px-2 gap-1 border-t border-gray-100 overflow-x-auto thin-scrollbar"
          style={{
            WebkitOverflowScrolling: 'touch',
          }}
        >
          {tabs.map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => handleSelect(tab.key)}
                className={`flex items-center gap-1.5 px-3 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'border-[#dc2626] text-[#dc2626]'
                    : 'border-transparent text-gray-600 hover:text-gray-900'
                }`}
              >
                {Icon && <Icon className="w-4 h-4 shrink-0" />}
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* نوار پایین موبایل (زیر md) */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-30 shadow-lg">
          <div className="flex items-stretch justify-around">
            {visibleTabs.map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.key;
              return (
                <button
                  key={tab.key}
                  onClick={() => handleSelect(tab.key)}
                  className={`flex flex-col items-center justify-center gap-0.5 py-2 px-1 flex-1 transition-colors ${
                    isActive ? 'text-[#dc2626]' : 'text-gray-500'
                  }`}
                >
                  <div className={`p-1 rounded-lg ${isActive ? 'bg-red-50' : ''}`}>
                    {Icon && <Icon className="w-5 h-5" />}
                  </div>
                  <span className="text-[10px] font-medium">{tab.short || tab.label}</span>
                </button>
              );
            })}

            {/* دکمه «بیشتر» */}
            {hasMore && (
              <button
                onClick={() => setMoreOpen(!moreOpen)}
                className={`flex flex-col items-center justify-center gap-0.5 py-2 px-1 flex-1 transition-colors ${
                  moreOpen || isMoreActive ? 'text-[#dc2626]' : 'text-gray-500'
                }`}
              >
                <div className={`p-1 rounded-lg ${moreOpen ? 'bg-red-50' : ''}`}>
                  {moreOpen ? <ChevronDown className="w-5 h-5 rotate-180" /> : <MoreHorizontal className="w-5 h-5" />}
                </div>
                <span className="text-[10px] font-medium">بیشتر</span>
              </button>
            )}
          </div>
        </div>

        {/* منوی کشویی «بیشتر» (موبایل + تبلت) */}
        {hasMore && moreOpen && (
          <div className="md:hidden fixed inset-0 z-40" onClick={() => setMoreOpen(false)}>
            <div className="absolute inset-0 bg-black/30" />
            <div
              className="absolute bottom-0 left-0 right-0 bg-white rounded-t-2xl shadow-2xl pb-4"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between p-4 border-b border-gray-100">
                <h3 className="font-bold text-sm">بیشتر</h3>
                <button
                  onClick={() => setMoreOpen(false)}
                  className="p-1.5 rounded-lg hover:bg-gray-100"
                  aria-label="بستن"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-3 grid grid-cols-3 gap-2">
                {moreTabs.map(tab => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.key;
                  return (
                    <button
                      key={tab.key}
                      onClick={() => handleSelect(tab.key)}
                      className={`flex flex-col items-center justify-center gap-1.5 py-3 rounded-xl transition-colors ${
                        isActive
                          ? 'bg-red-50 text-[#dc2626]'
                          : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      {Icon && <Icon className="w-5 h-5" />}
                      <span className="text-[10px] font-medium">{tab.short || tab.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </>
    );
  }

  // ============= variant=subsection: تب‌های داخلی =============
  // دسکتاپ: همه تب‌ها افقی
  // موبایل/تبلت: maxVisible تب + dropdown «بیشتر»
  return (
    <div ref={moreRef} className="bg-white rounded-xl p-2 shadow-sm">
      {/* حالت دسکتاپ — همه تب‌ها افقی */}
      <div className="hidden md:flex gap-1 overflow-x-auto no-scrollbar">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => handleSelect(tab.key)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                isActive
                  ? 'bg-[#dc2626] text-white'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              {Icon && <Icon className="w-4 h-4" />}
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* حالت موبایل/تبلت — maxVisible تب + dropdown */}
      <div className="flex md:hidden gap-1">
        {visibleTabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => handleSelect(tab.key)}
              className={`flex-1 flex flex-col items-center justify-center gap-1 py-2 rounded-lg text-xs font-medium transition-colors min-w-0 ${
                isActive
                  ? 'bg-[#dc2626] text-white'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              {Icon && <Icon className="w-4 h-4" />}
              <span className="truncate w-full text-center">{tab.short || tab.label}</span>
            </button>
          );
        })}

        {/* دکمه «بیشتر» */}
        {hasMore && (
          <div className="relative">
            <button
              onClick={() => setMoreOpen(!moreOpen)}
              className={`flex flex-col items-center justify-center gap-1 py-2 px-3 rounded-lg text-xs font-medium transition-colors ${
                moreOpen || isMoreActive
                  ? 'bg-[#dc2626] text-white'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              {moreOpen ? <X className="w-4 h-4" /> : <MoreHorizontal className="w-4 h-4" />}
              <span>بیشتر</span>
            </button>

            {/* Dropdown کشویی */}
            {moreOpen && (
              <div className="absolute top-full left-0 mt-1 bg-white rounded-lg shadow-xl border border-gray-100 py-1 min-w-[160px] z-20">
                {moreTabs.map(tab => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.key;
                  return (
                    <button
                      key={tab.key}
                      onClick={() => handleSelect(tab.key)}
                      className={`w-full flex items-center gap-2 px-3 py-2 text-xs font-medium transition-colors text-right ${
                        isActive
                          ? 'bg-red-50 text-[#dc2626]'
                          : 'text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      {Icon && <Icon className="w-4 h-4 shrink-0" />}
                      <span className="truncate">{tab.label}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
