'use client';

import { Truck, ShieldCheck, Leaf, RotateCcw, Headphones, Award } from 'lucide-react';

const services = [
  { icon: Truck, title: 'ارسال سریع', desc: 'تحویل در کمترین زمان' },
  { icon: ShieldCheck, title: 'ضمانت اصالت', desc: 'ضمانت کالای اورجینال' },
  { icon: Leaf, title: '۱۰۰٪ طبیعی', desc: 'چوب طبیعی و غیرسمی' },
  { icon: RotateCcw, title: '۷ روز بازگشت', desc: 'ضمانت بازگشت کالا' },
  { icon: Headphones, title: 'پشتیبانی ۲۴/۷', desc: 'همیشه در کنار شما' },
  { icon: Award, title: 'دست‌ساز', desc: 'ساخت دستی هنرمندان' },
];

export function ServiceFeatures() {
  return (
    <section className="bg-white rounded-xl p-4 md:p-6 shadow-sm">
      <div className="grid grid-cols-3 md:grid-cols-6 gap-4">
        {services.map((service, idx) => {
          const Icon = service.icon;
          return (
            <div
              key={idx}
              className="flex flex-col items-center text-center gap-2 p-2 hover:bg-gray-50 rounded-lg transition-colors"
            >
              <div className="w-12 h-12 rounded-full bg-[#fef3f4] flex items-center justify-center">
                <Icon className="w-6 h-6 text-[#dc2626]" />
              </div>
              <div>
                <h3 className="text-xs md:text-sm font-bold">{service.title}</h3>
                <p className="text-[10px] md:text-xs text-gray-500">{service.desc}</p>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
