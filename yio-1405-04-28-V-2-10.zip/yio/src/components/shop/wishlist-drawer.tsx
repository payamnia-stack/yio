'use client';

import { useState, useEffect } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Trash2, ShoppingCart, Heart } from 'lucide-react';
import Link from 'next/link';
import { useShopStore } from '@/store/shop-store';
import { formatPrice, toFa, parseImages } from '@/lib/shop-data';
import { toast } from 'sonner';

export function WishlistDrawer() {
  const { isWishlistOpen, setWishlistOpen, favorites, toggleFavorite, addToCart, setCartOpen } = useShopStore();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // بارگذاری جزئیات محصولات مورد علاقه
  useEffect(() => {
    if (!isWishlistOpen || favorites.length === 0) {
      setItems([]);
      return;
    }
    setLoading(true);
    fetch(`/api/shop/products?ids=${favorites.join(',')}&pageSize=50`)
      .then(r => r.json())
      .then(data => {
        // مرتب بر اساس ترتیب favorites (جدیدترین اول)
        const sorted = (data.products || []).sort(
          (a: any, b: any) => favorites.indexOf(b.id) - favorites.indexOf(a.id)
        );
        setItems(sorted);
      })
      .catch(() => setItems([]))
      .finally(() => setLoading(false));
  }, [isWishlistOpen, favorites]);

  const handleRemove = async (productId: number, title: string) => {
    await toggleFavorite(productId);
    toast.success('از علاقه‌مندی‌ها حذف شد', { description: title.slice(0, 40) + '...' });
  };

  const handleAddToCart = (product: any) => {
    addToCart(product);
    toast.success('به سبد خرید اضافه شد', { description: product.title.slice(0, 40) + '...' });
    setWishlistOpen(false);
    setTimeout(() => setCartOpen(true), 200);
  };

  return (
    <Sheet open={isWishlistOpen} onOpenChange={setWishlistOpen}>
      <SheetContent side="left" className="w-full sm:w-[450px] p-0 flex flex-col">
        <SheetHeader className="p-4 pl-12 border-b border-gray-100 bg-white">
          <SheetTitle className="flex items-center gap-2 flex-row-reverse justify-end text-left">
            <Heart className="w-5 h-5 text-[#dc2626] fill-[#dc2626]" />
            <span>علاقه‌مندی‌ها</span>
            {favorites.length > 0 && (
              <span className="bg-[#dc2626] text-white text-xs px-2 py-0.5 rounded-full fa-num">
                {toFa(favorites.length)}
              </span>
            )}
          </SheetTitle>
        </SheetHeader>

        {loading ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="inline-block w-8 h-8 border-4 border-gray-200 border-t-[#dc2626] rounded-full animate-spin"></div>
          </div>
        ) : items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <Heart className="w-16 h-16 text-gray-200 mb-4" />
            <p className="text-gray-500 mb-1">هنوز محصولی به علاقه‌مندی‌ها اضافه نکرده‌اید</p>
            <p className="text-xs text-gray-400 mb-4">با کلیک روی آیکن قلب در هر محصول، آن را اینجا ذخیره کنید</p>
            <Button
              onClick={() => setWishlistOpen(false)}
              className="bg-[#dc2626] hover:bg-[#b91c1c]"
            >
              شروع خرید
            </Button>
          </div>
        ) : (
          <>
            {/* لیست محصولات */}
            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {items.map(product => {
                const finalPrice = product.discountPrice ?? product.price;
                return (
                  <div
                    key={product.id}
                    className="bg-white border border-gray-100 rounded-lg p-3 flex gap-3 hover:shadow-sm transition-shadow"
                  >
                    <Link
                      href={`/products/${product.id}`}
                      onClick={() => setWishlistOpen(false)}
                      className="shrink-0"
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={product.image}
                        alt={product.title}
                        className="w-20 h-20 object-cover rounded-lg"
                      />
                    </Link>

                    <div className="flex-1 min-w-0 flex flex-col">
                      <Link
                        href={`/products/${product.id}`}
                        onClick={() => setWishlistOpen(false)}
                        className="text-sm font-medium line-clamp-2 hover:text-[#dc2626] text-left"
                        dir="rtl"
                      >
                        {product.title}
                      </Link>

                      {product.woodType && (
                        <span className="text-[10px] text-amber-700 bg-amber-50 inline-block w-fit px-1.5 py-0.5 rounded mt-1">
                          {product.woodType}
                        </span>
                      )}

                      <div className="mt-auto flex items-center justify-between gap-2 pt-2">
                        <div className="text-sm text-left" dir="ltr">
                          {product.discountPrice && (
                            <span className="text-[10px] text-gray-400 line-through ml-1 fa-num">
                              {formatPrice(product.price)}
                            </span>
                          )}
                          <span className="font-bold text-[#dc2626] fa-num">
                            {formatPrice(finalPrice)}
                            <span className="text-[10px] mr-1">ت</span>
                          </span>
                        </div>
                      </div>

                      <div className="flex gap-1 mt-2">
                        <Button
                          size="sm"
                          onClick={() => handleAddToCart(product)}
                          className="h-7 text-xs bg-[#dc2626] hover:bg-[#b91c1c] flex-1"
                          disabled={!product.inStock}
                        >
                          <ShoppingCart className="w-3 h-3 ml-1" />
                          {product.inStock ? 'افزودن به سبد' : 'ناموجود'}
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleRemove(product.id, product.title)}
                          className="h-7 text-xs text-red-600 hover:bg-red-50 px-2"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* فوتر */}
            <div className="border-t border-gray-100 p-3 bg-white space-y-2">
              <Button
                onClick={() => setWishlistOpen(false)}
                variant="outline"
                className="w-full h-10"
              >
                ادامه خرید
              </Button>
              <Link
                href="/profile"
                onClick={() => setWishlistOpen(false)}
                className="block text-center text-xs text-gray-500 hover:text-[#dc2626] py-1"
              >
                مشاهده همه در پروفایل
              </Link>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
