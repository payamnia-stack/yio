'use client';

import { useState, useEffect, useRef } from 'react';
import { Bell, Check, Trash2, X, CheckCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toFa } from '@/lib/shop-data';
import { getNotificationIcon, getNotificationColor } from '@/lib/notifications';
import { useNotificationStream } from '@/hooks/use-notification-stream';
import Link from 'next/link';
import { toast } from 'sonner';

interface Notification {
  id: number;
  type: string;
  title: string;
  body: string | null;
  link: string | null;
  isRead: boolean;
  createdAt: string;
}

export function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Real-time notifications
  const { notifications: liveNotifs, dismiss } = useNotificationStream();

  const fetchNotifications = async () => {
    try {
      const res = await fetch('/api/user/notifications?limit=20');
      if (res.ok) {
        const data = await res.json();
        setNotifications(data.notifications || []);
        setUnreadCount(data.unreadCount || 0);
      }
    } catch {}
    setLoading(false);
  };

  useEffect(() => {
    fetchNotifications();
  }, []);

  // وقتی اعلان real-time جدید میاد
  useEffect(() => {
    if (liveNotifs.length > 0) {
      const latest = liveNotifs[0];
      toast.success(latest.title, {
        description: latest.body,
        duration: 5000,
      });
      // رفرش لیست
      fetchNotifications();
      dismiss(0);
    }
  }, [liveNotifs]);

  // بستن dropdown با کلیک بیرون
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleMarkRead = async (id: number) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
    setUnreadCount(c => Math.max(0, c - 1));
    await fetch('/api/user/notifications', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id }),
    });
  };

  const handleMarkAllRead = async () => {
    setNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
    setUnreadCount(0);
    await fetch('/api/user/notifications', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ markAllRead: true }),
    });
    toast.success('همه اعلان‌ها خوانده شدند');
  };

  const handleDelete = async (id: number) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
    await fetch(`/api/user/notifications?id=${id}`, { method: 'DELETE' });
  };

  const formatTime = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'همین حالا';
    if (mins < 60) return `${toFa(mins)} دقیقه پیش`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${toFa(hours)} ساعت پیش`;
    return new Date(dateStr).toLocaleDateString('fa-IR');
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setOpen(!open)}
        className="relative p-2 rounded-lg hover:bg-gray-100 transition-colors"
        title="اعلان‌ها"
      >
        <Bell className="w-5 h-5 text-gray-700" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-[#dc2626] text-white text-[10px] min-w-[18px] h-[18px] flex items-center justify-center rounded-full px-1 fa-num">
            {toFa(unreadCount > 99 ? 99 : unreadCount)}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute left-0 mt-2 w-80 sm:w-96 bg-white rounded-xl shadow-2xl border border-gray-100 z-50 max-h-[28rem] overflow-hidden flex flex-col">
          {/* هدر */}
          <div className="flex items-center justify-between p-3 border-b border-gray-100">
            <h3 className="font-bold flex items-center gap-2">
              <Bell className="w-4 h-4 text-[#dc2626]" />
              اعلان‌ها
              {unreadCount > 0 && (
                <span className="bg-red-100 text-red-600 text-xs px-2 py-0.5 rounded-full fa-num">
                  {toFa(unreadCount)} جدید
                </span>
              )}
            </h3>
            {unreadCount > 0 && (
              <button
                onClick={handleMarkAllRead}
                className="text-xs text-[#dc2626] hover:underline flex items-center gap-1"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                خواندن همه
              </button>
            )}
          </div>

          {/* لیست */}
          <div className="overflow-y-auto flex-1">
            {loading ? (
              <div className="p-8 text-center text-gray-400 text-sm">در حال بارگذاری...</div>
            ) : notifications.length === 0 ? (
              <div className="p-8 text-center text-gray-400 text-sm">
                <Bell className="w-12 h-12 mx-auto mb-2 opacity-20" />
                اعلانی ندارید
              </div>
            ) : (
              notifications.map((notif) => (
                <div
                  key={notif.id}
                  className={`p-3 border-b border-gray-50 hover:bg-gray-50 transition-colors group ${
                    !notif.isRead ? 'bg-blue-50/50' : ''
                  }`}
                >
                  <div className="flex items-start gap-2">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm shrink-0 ${getNotificationColor(notif.type as any)}`}>
                      {getNotificationIcon(notif.type as any)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-1">
                        <p className={`text-sm ${notif.isRead ? 'text-gray-700' : 'font-bold text-gray-900'}`}>
                          {notif.title}
                        </p>
                        {!notif.isRead && (
                          <button
                            onClick={() => handleMarkRead(notif.id)}
                            className="text-blue-500 hover:bg-blue-100 p-1 rounded shrink-0"
                            title="خواندن"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                      {notif.body && (
                        <p className="text-xs text-gray-500 mt-0.5 line-clamp-2">{notif.body}</p>
                      )}
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-[10px] text-gray-400">{formatTime(notif.createdAt)}</span>
                        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          {notif.link && (
                            <Link
                              href={notif.link}
                              onClick={() => {
                                if (!notif.isRead) handleMarkRead(notif.id);
                                setOpen(false);
                              }}
                              className="text-[10px] text-[#dc2626] hover:underline"
                            >
                              مشاهده
                            </Link>
                          )}
                          <button
                            onClick={() => handleDelete(notif.id)}
                            className="text-red-400 hover:bg-red-50 p-1 rounded"
                            title="حذف"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* فوتر */}
          <div className="p-2 border-t border-gray-100 text-center">
            <Link
              href="/profile?tab=notifications"
              onClick={() => setOpen(false)}
              className="text-xs text-[#dc2626] hover:underline font-medium"
            >
              مشاهده همه اعلان‌ها
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
