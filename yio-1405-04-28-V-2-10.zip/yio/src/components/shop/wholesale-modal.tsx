'use client';

import { useState } from 'react';
import { X, Building2, User, Phone, Mail, MapPin, Package, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { categories } from '@/lib/shop-data';

export function WholesaleModal({ onClose }: { onClose: () => void }) {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const [formData, setFormData] = useState({
    companyName: '',
    contactPerson: '',
    phone: '',
    email: '',
    city: '',
    productCategory: '',
    quantity: '50',
    description: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (formData.companyName.trim().length < 2) {
      toast.error('نام شرکت/فروشگاه را کامل وارد کنید');
      return;
    }
    if (formData.contactPerson.trim().length < 3) {
      toast.error('نام شخص مسئول را کامل وارد کنید');
      return;
    }
    if (!/^09\d{9}$/.test(formData.phone)) {
      toast.error('شماره موبایل نامعتبر است');
      return;
    }
    if (parseInt(formData.quantity) < 10) {
      toast.error('حداقل تعداد برای سفارش عمده ۱۰ عدد است');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/wholesale', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await res.json();

      if (res.ok) {
        setSuccess(true);
        toast.success('درخواست شما ثبت شد');
      } else {
        toast.error(data.error || 'خطا در ثبت درخواست');
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8 text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Send className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold mb-2">درخواست ثبت شد!</h2>
          <p className="text-gray-600 mb-6">
            درخواست سفارش عمده شما با موفقیت ثبت شد. کارشناسان ما ظرف ۲۴ ساعت کاری با شما تماس می‌گیرند.
          </p>
          <Button onClick={onClose} className="w-full bg-[#dc2626] hover:bg-[#b91c1c] h-12">
            بازگشت به فروشگاه
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-2 md:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl my-4 max-h-[95vh] overflow-y-auto">
        <div className="sticky top-0 bg-gradient-to-l from-[#dc2626] to-[#991b1b] text-white p-4 flex items-center justify-between z-10">
          <div>
            <h2 className="text-lg font-bold flex items-center gap-2">
              <Building2 className="w-5 h-5" />
              ثبت سفارش عمده
            </h2>
            <p className="text-xs opacity-90 mt-1">برای فروشگاه‌ها، شرکت‌ها و مشتریان عمده - تخفیف ویژه</p>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-white/20">
            <X className="w-5 h-5" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 md:p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="companyName">نام شرکت / فروشگاه *</Label>
              <Input
                id="companyName"
                value={formData.companyName}
                onChange={e => setFormData({ ...formData, companyName: e.target.value })}
                placeholder="مثلا: فروشگاه چوب پارسی"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="contactPerson">نام شخص مسئول *</Label>
              <Input
                id="contactPerson"
                value={formData.contactPerson}
                onChange={e => setFormData({ ...formData, contactPerson: e.target.value })}
                placeholder="مثلا: محمد رضایی"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="phone">شماره موبایل *</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                placeholder="09121234567"
                dir="ltr"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">ایمیل (اختیاری)</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
                placeholder="info@company.ir"
                dir="ltr"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="city">شهر *</Label>
              <Input
                id="city"
                value={formData.city}
                onChange={e => setFormData({ ...formData, city: e.target.value })}
                placeholder="مثلا: تهران"
                required
              />
            </div>
            <div className="space-y-2">
              <Label>دسته‌بندی محصول مورد نظر *</Label>
              <Select
                value={formData.productCategory}
                onValueChange={v => setFormData({ ...formData, productCategory: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="انتخاب دسته" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(cat => (
                    <SelectItem key={cat.id} value={cat.title}>
                      {cat.icon} {cat.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="quantity">تعداد تقریبی (حداقل ۱۰) *</Label>
            <Input
              id="quantity"
              type="number"
              value={formData.quantity}
              onChange={e => setFormData({ ...formData, quantity: e.target.value })}
              min="10"
              required
            />
            <p className="text-xs text-gray-500">برای تعداد بالای ۵۰ عدد، تخفیف ویژه اعمال می‌شود</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">توضیحات (اختیاری)</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={e => setFormData({ ...formData, description: e.target.value })}
              placeholder="هر توضیحی که لازم است..."
              rows={3}
            />
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-800">
            <p className="font-bold mb-1">📋 روند پردازش:</p>
            <ol className="list-decimal pr-5 space-y-1 text-xs">
              <li>ثبت درخواست (شما)</li>
              <li>تماس کارشناسان ما ظرف ۲۴ ساعت</li>
              <li>ارسال پیش‌فاکتور با تخفیف عمده</li>
              <li>تأیید و تولید سفارش</li>
            </ol>
          </div>

          <div className="flex gap-3">
            <Button
              type="submit"
              disabled={loading}
              className="flex-1 bg-[#dc2626] hover:bg-[#b91c1c] h-12"
            >
              <Send className="w-4 h-4 ml-2" />
              {loading ? 'در حال ارسال...' : 'ثبت درخواست'}
            </Button>
            <Button type="button" variant="outline" onClick={onClose} className="h-12 px-6">
              انصراف
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
