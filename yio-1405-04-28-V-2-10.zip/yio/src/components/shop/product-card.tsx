'use client';

import { useState } from 'react';
import { Heart, Star, Truck, Image as ImageIcon, Video } from 'lucide-react';
import { Product, formatPrice, toFa, parseColors, parseImages, parseVideos, getStockBadge, isProductAvailable } from '@/lib/shop-data';
import { useShopStore } from '@/store/shop-store';
import { useStockContext } from '@/components/shop/stock-provider';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import Link from 'next/link';

interface ProductCardProps {
  product: Product;
  compact?: boolean;
}

export function ProductCard({ product, compact = false }: ProductCardProps) {
  const addToCart = useShopStore(s => s.addToCart);
  const toggleFavorite = useShopStore(s => s.toggleFavorite);
  const favorites = useShopStore(s => s.favorites);
  const isFavorite = favorites.includes(product.id);
  const { getStock } = useStockContext();

  const [selectedColor, setSelectedColor] = useState<string | undefined>();
  const [hovered, setHovered] = useState(false);

  const colors = parseColors(product.colors as any);
  const imageCount = parseImages(product.images).length + 1;
  const videoCount = parseVideos(product.videos).length;

  // دریافت موجودی real-time (اگر آپدیتی از SSE آمده باشد، آن را استفاده می‌کنیم)
  const realtimeStock = getStock(product.id, product.stockQuantity);

  const finalPrice = product.discountPrice ?? product.price;
  const stockInfo = getStockBadge(realtimeStock);
  const available = realtimeStock === undefined
    ? isProductAvailable(product)
    : realtimeStock > 0;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    if (!available) {
      toast.error('این محصول در حال حاضر ناموجود است');
      return;
    }
    addToCart(product as any, selectedColor || colors[0]?.name);
    toast.success('به سبد خرید اضافه شد', {
      description: product.title.slice(0, 40) + '...',
    });
  };

  const handleFavorite = async (e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    // بهینه‌سازی: پیش از تکمیل درخواست، toast نمایش می‌دهیم تا UX سریع باشد
    toast.success(isFavorite ? 'از علاقه‌مندی‌ها حذف شد' : 'به علاقه‌مندی‌ها اضافه شد');
    try {
      await toggleFavorite(product.id);
    } catch {
      // خطای شبکه — کاربر پیام موفقیت را قبلاً دیده، state محلی اگر لازم برگردانده می‌شود
    }
  };

  return (
    <Link
      href={`/products/${product.id}`}
      className={`bg-white rounded-lg border border-gray-100 hover:border-gray-200 hover:shadow-md transition-all overflow-hidden flex flex-col ${compact ? 'p-3' : 'p-4'}`}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* تصویر محصول */}
      <div className="relative aspect-square mb-3 bg-gray-50 rounded-lg overflow-hidden">
        <img
          src={product.image}
          alt={product.title}
          className="w-full h-full object-cover hover:scale-105 transition-transform"
          loading="lazy"
        />
        {product.discountPercent && (
          <div className="absolute top-2 right-2 bg-[#dc2626] text-white text-xs font-bold px-2 py-1 rounded-md fa-num">
            {toFa(product.discountPercent)}٪ تخفیف
          </div>
        )}
        <button
          onClick={handleFavorite}
          className="absolute top-2 left-2 bg-white/80 backdrop-blur p-1.5 rounded-full hover:bg-white"
          aria-label="افزودن به علاقه‌مندی"
        >
          <Heart
            className={`w-4 h-4 ${isFavorite ? 'fill-[#dc2626] text-[#dc2626]' : 'text-gray-600'}`}
          />
        </button>

        {/* انتخاب رنگ با hover */}
        {colors.length > 1 && hovered && (
          <div className="absolute bottom-2 left-2 right-2 bg-white/90 backdrop-blur rounded-lg p-2 flex items-center gap-1.5 justify-center animate-in fade-in slide-in-from-bottom-2 duration-200">
            <span className="text-[10px] text-gray-500 ml-1">رنگ:</span>
            {colors.map(color => (
              <button
                key={color.name}
                onClick={(e) => { e.preventDefault(); e.stopPropagation(); setSelectedColor(color.name); }}
                className={`w-5 h-5 rounded-full border-2 transition-all ${
                  selectedColor === color.name ? 'border-[#dc2626] scale-125' : 'border-gray-300'
                }`}
                style={{ backgroundColor: color.code }}
                title={color.name}
              />
            ))}
          </div>
        )}

        {/* نشانگر تعداد تصاویر و ویدیوها */}
        {(imageCount > 1 || videoCount > 0) && (
          <div className="absolute bottom-2 left-2 flex gap-1">
            {imageCount > 1 && (
              <span className="bg-black/60 text-white text-[10px] px-1.5 py-0.5 rounded flex items-center gap-1 fa-num">
                <ImageIcon className="w-2.5 h-2.5" />
                {toFa(imageCount)}
              </span>
            )}
            {videoCount > 0 && (
              <span className="bg-[#dc2626] text-white text-[10px] px-1.5 py-0.5 rounded flex items-center gap-1 fa-num">
                <Video className="w-2.5 h-2.5" />
                {toFa(videoCount)}
              </span>
            )}
          </div>
        )}
      </div>

      {/* اطلاعات محصول */}
      <div className="flex-1 flex flex-col">
        {product.woodType && (
          <span className="text-xs text-amber-700 bg-amber-50 inline-block w-fit px-2 py-0.5 rounded mb-1">
            {product.woodType}
          </span>
        )}

        <span className="text-xs text-gray-500 mb-1">{product.brand}</span>

        <h3 className={`font-medium text-gray-800 mb-2 line-clamp-2 ${compact ? 'text-xs' : 'text-sm'} hover:text-[#dc2626]`}>
          {product.title}
        </h3>

        {/* Badge موجودی — متن رنگی بدون پس‌زمینه */}
        <div className={`inline-flex items-center gap-1.5 ${stockInfo.textClass} ${compact ? 'text-[9px]' : 'text-[10px]'} font-bold w-fit mb-2 fa-num`}>
          <span className={`w-1.5 h-1.5 rounded-full ${stockInfo.dotClass} ${stockInfo.isOutOfStock ? 'animate-pulse' : ''}`}></span>
          {stockInfo.countLabel}
        </div>

        {/* رنگ‌های ثابت (وقتی hover نیست) */}
        {colors.length > 0 && !hovered && (
          <div className="flex gap-1 mb-2">
            {colors.slice(0, 4).map(color => (
              <div
                key={color.name}
                className="w-4 h-4 rounded-full border border-gray-200"
                style={{ backgroundColor: color.code }}
                title={color.name}
              />
            ))}
            {colors.length > 4 && (
              <span className="text-xs text-gray-500">+{toFa(colors.length - 4)}</span>
            )}
          </div>
        )}

        <div className="flex items-center gap-1 mb-2 text-xs">
          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
          <span className="font-medium fa-num">{toFa(product.rating.toFixed(1))}</span>
          <span className="text-gray-400 fa-num">({toFa(product.ratingCount)})</span>
        </div>

        {product.fastDelivery && (
          <div className="flex items-center gap-1 text-[10px] text-green-600 mb-2">
            <Truck className="w-3 h-3" />
            <span>ارسال سریع</span>
          </div>
        )}

        <div className="mt-auto">
          {product.discountPercent ? (
            <div className="flex flex-col items-end">
              <span className="text-xs text-gray-400 line-through fa-num">
                {formatPrice(product.price)}
              </span>
              <div className="flex items-center gap-1">
                <span className="text-base font-bold text-[#dc2626] fa-num">
                  {formatPrice(finalPrice)}
                </span>
                <span className="text-[10px] text-gray-500">تومان</span>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-1 justify-end">
              <span className="text-base font-bold text-gray-800 fa-num">
                {formatPrice(finalPrice)}
              </span>
              <span className="text-[10px] text-gray-500">تومان</span>
            </div>
          )}
        </div>

        {!compact && (
          <Button
            onClick={handleAddToCart}
            disabled={!available}
            className={`w-full mt-3 ${available ? 'bg-[#dc2626] hover:bg-[#b91c1c]' : 'bg-gray-300 hover:bg-gray-300 cursor-not-allowed'} text-white font-medium text-sm h-9`}
          >
            {available ? 'افزودن به سبد' : 'ناموجود'}
          </Button>
        )}

        {compact && (
          <Button
            onClick={handleAddToCart}
            disabled={!available}
            size="sm"
            className={`w-full mt-2 ${available ? 'bg-[#dc2626] hover:bg-[#b91c1c]' : 'bg-gray-300 hover:bg-gray-300 cursor-not-allowed'} text-white h-8 text-xs`}
          >
            {available ? 'خرید' : 'ناموجود'}
          </Button>
        )}
      </div>
    </Link>
  );
}
