'use client';

import { useState } from 'react';
import { useShopStore } from '@/store/shop-store';
import { formatPrice, toFa } from '@/lib/shop-data';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Trash2, Plus, Minus, ShoppingBag, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { CheckoutModal } from './checkout-modal';
import { CartProgressBar } from './cart-progress-bar';

export function CartDrawer() {
  const { cart, isCartOpen, setCartOpen, removeFromCart, updateQuantity, cartTotal, clearCart } = useShopStore();
  const total = cartTotal();
  const shippingCost = total > 500000 ? 0 : 89000;
  const finalTotal = total + shippingCost;
  const [showCheckout, setShowCheckout] = useState(false);

  return (
    <Sheet open={isCartOpen} onOpenChange={setCartOpen}>
      <SheetContent side="left" className="w-full sm:w-[450px] p-0 flex flex-col">
        <SheetHeader className="p-4 pl-12 border-b border-gray-100 bg-white">
          <SheetTitle className="flex items-center gap-2 flex-row-reverse justify-end text-left">
            <ShoppingBag className="w-5 h-5 text-[#dc2626]" />
            <span>سبد خرید</span>
            {cart.length > 0 && (
              <span className="bg-[#dc2626] text-white text-xs px-2 py-0.5 rounded-full fa-num">
                {toFa(cart.length)}
              </span>
            )}
          </SheetTitle>
        </SheetHeader>

        {cart.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center">
            <div className="text-6xl mb-4">🛒</div>
            <h3 className="text-lg font-bold mb-2">سبد خرید شما خالی است</h3>
            <p className="text-sm text-gray-500 mb-6">
              هنوز محصولی به سبد خرید اضافه نکرده‌اید
            </p>
            <Button
              onClick={() => setCartOpen(false)}
              className="bg-[#dc2626] hover:bg-[#b91c1c]"
            >
              شروع خرید
            </Button>
          </div>
        ) : (
          <>
            {/* نوار پیشرفت ارسال رایگان */}
            <div className="px-4 pt-3">
              <CartProgressBar />
            </div>

            {/* لیست محصولات */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50">
              {cart.map(item => {
                const price = item.discountPrice ?? item.price;
                const itemTotal = price * item.quantity;
                return (
                  <div
                    key={`${item.id}-${item.selectedColor}`}
                    className="bg-white rounded-lg p-3 flex gap-3"
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-20 h-20 object-cover rounded-lg shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-medium line-clamp-2 mb-1 text-left" dir="rtl">
                        {item.title}
                      </h4>
                      {item.selectedColor && (
                        <p className="text-xs text-gray-500 mb-2 text-left">
                          رنگ: {item.selectedColor}
                        </p>
                      )}
                      <div className="flex items-center justify-between">
                        {/* کنترل تعداد */}
                        <div className="flex items-center gap-1 bg-gray-100 rounded-lg p-1">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="w-6 h-6 flex items-center justify-center hover:bg-white rounded"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                          <span className="w-6 text-center text-sm font-medium fa-num">
                            {toFa(item.quantity)}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="w-6 h-6 flex items-center justify-center hover:bg-white rounded"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                        </div>

                        <div className="text-left">
                          <div className="text-sm font-bold text-[#dc2626] fa-num" dir="ltr">
                            {formatPrice(itemTotal)}
                            <span className="text-[10px] text-gray-500 mr-1">ت</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        removeFromCart(item.id);
                        toast.info('محصول از سبد حذف شد');
                      }}
                      className="text-gray-400 hover:text-[#dc2626] p-1 shrink-0"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}

              {/* پاک کردن سبد */}
              <button
                onClick={() => {
                  clearCart();
                  toast.info('سبد خرید پاک شد');
                }}
                className="w-full text-center text-xs text-gray-500 hover:text-[#dc2626] py-2"
              >
                پاک کردن سبد خرید
              </button>
            </div>

            {/* خلاصه سفارش */}
            <div className="border-t border-gray-100 bg-white p-4 space-y-3">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between text-gray-600">
                  <span>جمع کالاها:</span>
                  <span className="fa-num">{formatPrice(total)} تومان</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>هزینه ارسال:</span>
                  <span className="fa-num">
                    {shippingCost === 0 ? (
                      <span className="text-green-600">رایگان</span>
                    ) : (
                      `${formatPrice(shippingCost)} تومان`
                    )}
                  </span>
                </div>
                {shippingCost === 0 && (
                  <p className="text-xs text-green-600 bg-green-50 rounded p-2">
                    ✓ ارسال رایگان برای خریدهای بالای ۵۰۰ هزار تومان
                  </p>
                )}
                <div className="border-t border-gray-100 pt-2 flex justify-between font-bold">
                  <span>مبلغ قابل پرداخت:</span>
                  <span className="text-[#dc2626] fa-num">
                    {formatPrice(finalTotal)} تومان
                  </span>
                </div>
              </div>

              <Button
                className="w-full bg-[#dc2626] hover:bg-[#b91c1c] h-12 text-base"
                onClick={() => {
                  // ابتدا cart را می‌بندیم، سپس پس از یک تأخیر کوتاه مدال checkout را باز می‌کنیم
                  // این کار از تداخل انیمیشن‌های Radix (Sheet بسته شدن + Dialog باز شدن) جلوگیری می‌کند
                  setCartOpen(false);
                  setTimeout(() => setShowCheckout(true), 250);
                }}
              >
                ادامه فرآیند خرید
                <ArrowLeft className="w-4 h-4 mr-1" />
              </Button>
            </div>
          </>
        )}
      </SheetContent>

      {/* CheckoutModal باید خارج از Sheet رندر شود تا از تداخل z-index و focus management جلوگیری شود */}
      {showCheckout && (
        <CheckoutModal
          onClose={() => setShowCheckout(false)}
          onSuccess={() => {
            setShowCheckout(false);
          }}
        />
      )}
    </Sheet>
  );
}
