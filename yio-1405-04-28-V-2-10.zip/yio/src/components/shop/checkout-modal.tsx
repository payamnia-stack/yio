'use client';

import { useState, useEffect } from 'react';
import { X, ShoppingBag, MapPin, User, Phone, CreditCard, CheckCircle2, Ticket, Tag, AlertCircle, ArrowLeft, ShieldCheck, Mail } from 'lucide-react';
import { useShopStore } from '@/store/shop-store';
import { formatPrice, toFa } from '@/lib/shop-data';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { LocationSelector } from './location-selector';

interface CheckoutModalProps {
  onClose: () => void;
  onSuccess: (orderNumber: string) => void;
}

export function CheckoutModal({ onClose, onSuccess }: CheckoutModalProps) {
  const { cart, cartTotal, clearCart } = useShopStore();
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState<'auth' | 'form' | 'success'>('form');
  const [orderNumber, setOrderNumber] = useState('');

  // وضعیت کاربر
  const [user, setUser] = useState<any>(null);
  const [userAddresses, setUserAddresses] = useState<any[]>([]);

  // اطلاعات فرم checkout
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    province: '',
    city: '',
    postalCode: '',
    notes: '',
    paymentMethod: 'cod',
  });

  // فرم auth (OTP)
  const [authIdentifier, setAuthIdentifier] = useState('');
  const [authVerifyCode, setAuthVerifyCode] = useState('');
  const [authStep, setAuthStep] = useState<'identifier' | 'verify'>('identifier');
  const [maskedIdentifier, setMaskedIdentifier] = useState('');
  const [devCode, setDevCode] = useState('');
  const [authLoading, setAuthLoading] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);

  // روش‌های پرداخت
  const [paymentMethods, setPaymentMethods] = useState<any[]>([]);

  // کوپن تخفیف
  const [couponCode, setCouponCode] = useState('');
  const [couponLoading, setCouponLoading] = useState(false);
  const [appliedCoupon, setAppliedCoupon] = useState<any>(null);
  const [discountAmount, setDiscountAmount] = useState(0);
  const [freeShipping, setFreeShipping] = useState(false);

  const total = cartTotal();
  const shippingCost = freeShipping ? 0 : (total > 500000 ? 0 : 89000);
  const finalTotal = Math.max(0, total - discountAmount + shippingCost);

  // تایمر ارسال مجدد
  useEffect(() => {
    if (resendTimer <= 0) return;
    const t = setTimeout(() => setResendTimer(resendTimer - 1), 1000);
    return () => clearTimeout(t);
  }, [resendTimer]);

  // بارگذاری روش‌های پرداخت
  useEffect(() => {
    fetch('/api/payment-methods/active')
      .then(r => r.json())
      .then(data => {
        const methods = data.methods || [];
        setPaymentMethods(methods);
        const defaultMethod = methods.find((m: any) => m.isDefault);
        if (defaultMethod) {
          setFormData(prev => ({ ...prev, paymentMethod: defaultMethod.type }));
        }
      })
      .catch(() => {});
  }, []);

  // بررسی وضعیت ورود کاربر
  useEffect(() => {
    fetch('/api/auth/check')
      .then(r => r.json())
      .then(data => {
        if (data.authenticated && data.user) {
          setUser(data.user);
          setFormData(prev => ({
            ...prev,
            name: data.user.name || '',
            phone: data.user.phone?.startsWith('nomail_') ? '' : (data.user.phone || ''),
            email: data.user.email || '',
          }));
          // بارگذاری آدرس‌های ذخیره شده
          fetch('/api/user/profile')
            .then(r => r.json())
            .then(d => {
              if (d.addresses && d.addresses.length > 0) {
                setUserAddresses(d.addresses);
                // انتخاب آدرس پیش‌فرض
                const defaultAddr = d.addresses.find((a: any) => a.isDefault) || d.addresses[0];
                if (defaultAddr) {
                  setFormData(prev => ({
                    ...prev,
                    province: defaultAddr.province || '',
                    city: defaultAddr.city || '',
                    address: defaultAddr.address || '',
                    postalCode: defaultAddr.postalCode || '',
                  }));
                }
              }
            })
            .catch(() => {});
        } else {
          // کاربر لاگین نیست — به مرحله auth برو
          setStep('auth');
        }
      })
      .catch(() => setStep('auth'));
  }, []);

  // تشخیص موبایل یا ایمیل
  const detectType = (value: string): 'phone' | 'email' | 'invalid' => {
    const v = value.trim().toLowerCase();
    if (!v) return 'invalid';
    if (/^09\d{9}$/.test(v)) return 'phone';
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return 'email';
    return 'invalid';
  };

  // درخواست کد تایید
  const handleAuthRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    const type = detectType(authIdentifier);
    if (type === 'invalid') {
      toast.error('شماره موبایل یا ایمیل معتبر وارد کنید');
      return;
    }

    setAuthLoading(true);
    try {
      const res = await fetch('/api/auth/otp-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier: authIdentifier }),
      });
      const data = await res.json();
      if (res.ok) {
        setMaskedIdentifier(data.maskedIdentifier);
        if (data.verifyCode) setDevCode(data.verifyCode);
        setAuthStep('verify');
        setResendTimer(60);
        toast.success(`کد تایید به ${data.method === 'phone' ? 'موبایل' : 'ایمیل'} ارسال شد`);
      } else {
        toast.error(data.error || 'خطا');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setAuthLoading(false);
    }
  };

  // تایید کد و ورود
  const handleAuthVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (authVerifyCode.length !== 6) {
      toast.error('کد ۶ رقمی را وارد کنید');
      return;
    }

    setAuthLoading(true);
    try {
      const res = await fetch('/api/auth/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: authVerifyCode, identifier: authIdentifier }),
      });
      const data = await res.json();
      if (res.ok) {
        toast.success(data.isNewUser ? 'حساب شما ایجاد شد' : 'خوش آمدید');
        // رفرش صفحه برای بارگذاری مجدد
        window.location.reload();
      } else {
        toast.error(data.error || 'خطا');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setAuthLoading(false);
    }
  };

  // اعتبارسنجی و اعمال کوپن
  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return;

    setCouponLoading(true);
    try {
      const res = await fetch('/api/coupons/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: couponCode,
          cartTotal: total,
          customerPhone: formData.phone,
        }),
      });

      const data = await res.json();

      if (res.ok && data.valid) {
        setAppliedCoupon(data.coupon);
        setDiscountAmount(data.discountAmount);
        setFreeShipping(data.freeShipping);
        toast.success(
          data.freeShipping
            ? 'کوپن ارسال رایگان اعمال شد!'
            : `تخفیف ${formatPrice(data.discountAmount)} تومان اعمال شد!`
        );
      } else {
        setAppliedCoupon(null);
        setDiscountAmount(0);
        setFreeShipping(false);
        toast.error(data.error || 'کد کوپن نامعتبر است');
      }
    } catch {
      toast.error('خطا در بررسی کوپن');
    } finally {
      setCouponLoading(false);
    }
  };

  const handleRemoveCoupon = () => {
    setAppliedCoupon(null);
    setDiscountAmount(0);
    setFreeShipping(false);
    setCouponCode('');
  };

  // ثبت سفارش
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // اعتبارسنجی حداقلی
    if (!formData.name.trim() || formData.name.trim().length < 3) {
      toast.error('نام را کامل وارد کنید');
      return;
    }
    if (!/^09\d{9}$/.test(formData.phone)) {
      toast.error('شماره موبایل نامعتبر است');
      return;
    }
    if (!formData.address.trim() || formData.address.trim().length < 10) {
      toast.error('آدرس را کامل وارد کنید');
      return;
    }
    if (!formData.province || !formData.city) {
      toast.error('استان و شهر را انتخاب کنید');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer: {
            name: formData.name,
            phone: formData.phone,
            email: formData.email || undefined,
          },
          items: cart.map(item => ({
            productId: item.id,
            quantity: item.quantity,
            color: item.selectedColor,
          })),
          shippingAddress: formData.address,
          shippingCity: `${formData.province} - ${formData.city}`,
          postalCode: formData.postalCode,
          notes: formData.notes,
          paymentMethod: formData.paymentMethod,
        }),
      });

      const data = await res.json();

      if (res.ok) {
        // ثبت استفاده از کوپن
        if (appliedCoupon) {
          try {
            await fetch('/api/coupons/validate', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                code: appliedCoupon.code,
                cartTotal: total,
                customerPhone: formData.phone,
                markUsed: true,
                orderId: data.order.id,
              }),
            });
          } catch {}
        }
        setOrderNumber(data.order.orderNumber);
        setStep('success');
        clearCart();
        toast.success('سفارش با موفقیت ثبت شد');
      } else {
        toast.error(data.error || 'خطا در ثبت سفارش');
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  };

  // ===== مرحله موفقیت =====
  if (step === 'success') {
    return (
      <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8 text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-12 h-12 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold mb-2">سفارش ثبت شد!</h2>
          <p className="text-gray-600 mb-4">سفارش شما با موفقیت ثبت شد. می‌توانید در پروفایل خود وضعیت آن را پیگیری کنید.</p>
          <div className="bg-gray-50 rounded-lg p-4 mb-4">
            <p className="text-sm text-gray-600 mb-1">شماره سفارش:</p>
            <p className="text-2xl font-bold text-[#dc2626]">{orderNumber}</p>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={() => {
                onSuccess(orderNumber);
                window.location.href = '/profile';
              }}
              className="flex-1 bg-[#dc2626] hover:bg-[#b91c1c] h-12"
            >
              مشاهده سفارش
            </Button>
            <Button
              onClick={() => onSuccess(orderNumber)}
              variant="outline"
              className="h-12 px-6"
            >
              بستن
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // ===== مرحله auth (اگر کاربر لاگین نیست) =====
  if (step === 'auth') {
    return (
      <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
          {/* هدر */}
          <div className="bg-gradient-to-l from-[#dc2626] to-[#991b1b] text-white p-4 flex items-center justify-between">
            <h2 className="font-bold flex items-center gap-2">
              <ShoppingBag className="w-5 h-5" />
              ورود برای تکمیل سفارش
            </h2>
            <button
              onClick={onClose}
              className="w-8 h-8 flex items-center justify-center rounded-full bg-white/20 hover:bg-white/30"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="p-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4 text-sm text-blue-800">
              <p>برای ثبت سفارش، ابتدا با موبایل یا ایمیل وارد شوید. اگر حساب ندارید، خودکار ساخته می‌شود.</p>
            </div>

            {authStep === 'identifier' ? (
              <form onSubmit={handleAuthRequest} className="space-y-4">
                <div className="space-y-2">
                  <Label>شماره موبایل یا ایمیل</Label>
                  <div className="relative">
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                      {detectType(authIdentifier) === 'email' ? (
                        <Mail className="w-5 h-5" />
                      ) : (
                        <Phone className="w-5 h-5" />
                      )}
                    </div>
                    <Input
                      type="text"
                      value={authIdentifier}
                      onChange={e => setAuthIdentifier(e.target.value)}
                      placeholder="09123456789 یا you@example.com"
                      dir="ltr"
                      className="pr-11 pl-4 h-12 text-left"
                      autoFocus
                      required
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={authLoading || detectType(authIdentifier) === 'invalid'}
                  className="w-full bg-[#dc2626] hover:bg-[#b91c1c] h-12"
                >
                  {authLoading ? 'لطفا صبر کنید...' : 'دریافت کد تایید'}
                </Button>

                <p className="text-xs text-center text-gray-500">
                  ورود شما به معنای پذیرش شرایط YIO و قوانین حریم‌خصوصی است
                </p>
              </form>
            ) : (
              <form onSubmit={handleAuthVerify} className="space-y-4">
                {devCode && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-800 text-center">
                    <p className="font-bold">🔧 محیط توسعه</p>
                    <p>کد تایید: <code className="bg-white px-2 py-0.5 rounded font-bold">{devCode}</code></p>
                  </div>
                )}

                <div className="space-y-2">
                  <Label>کد ۶ رقمی ارسال شده به {maskedIdentifier}</Label>
                  <Input
                    value={authVerifyCode}
                    onChange={e => setAuthVerifyCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    placeholder="123456"
                    dir="ltr"
                    className="text-center text-2xl font-bold tracking-widest h-14"
                    maxLength={6}
                    autoFocus
                    required
                  />
                </div>

                <Button
                  type="submit"
                  disabled={authLoading || authVerifyCode.length !== 6}
                  className="w-full bg-[#dc2626] hover:bg-[#b91c1c] h-12"
                >
                  <ShieldCheck className="w-4 h-4 ml-2" />
                  {authLoading ? 'در حال تایید...' : 'تایید و ادامه'}
                </Button>

                <div className="flex items-center justify-between text-xs">
                  <button
                    type="button"
                    onClick={() => { setAuthStep('identifier'); setAuthVerifyCode(''); setDevCode(''); }}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    ← تغییر
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      if (resendTimer > 0) return;
                      setAuthLoading(true);
                      try {
                        const res = await fetch('/api/auth/otp-request', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ identifier: authIdentifier }),
                        });
                        const data = await res.json();
                        if (res.ok) {
                          if (data.verifyCode) setDevCode(data.verifyCode);
                          setResendTimer(60);
                          toast.success('کد جدید ارسال شد');
                        }
                      } finally {
                        setAuthLoading(false);
                      }
                    }}
                    disabled={resendTimer > 0}
                    className="text-[#dc2626] hover:underline disabled:text-gray-400"
                  >
                    {resendTimer > 0 ? `ارسال مجدد (${resendTimer}s)` : 'ارسال مجدد'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ===== مرحله فرم checkout =====
  return (
    <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-2 md:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl my-4 max-h-[95vh] overflow-y-auto">
        {/* هدر */}
        <div className="sticky top-0 bg-white border-b border-gray-100 p-4 flex items-center justify-between gap-2 z-10">
          <h2 className="text-lg font-bold flex items-center gap-2 flex-row-reverse justify-end text-left">
            <ShoppingBag className="w-5 h-5 text-[#dc2626]" />
            <span>تکمیل سفارش</span>
          </h2>
          <button
            onClick={onClose}
            className="w-9 h-9 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200 text-gray-700 transition-all hover:scale-105 shrink-0"
            aria-label="بستن"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 md:p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* اطلاعات کاربر وارد شده */}
          {user && (
            <div className="md:col-span-2 bg-green-50 border border-green-200 rounded-lg p-3 flex items-center gap-2 text-sm text-green-800">
              <CheckCircle2 className="w-5 h-5 shrink-0" />
              <span>وارد شده به عنوان <strong>{user.name || user.phone || user.email}</strong></span>
            </div>
          )}

          {/* انتخاب آدرس ذخیره شده */}
          {userAddresses.length > 0 && (
            <div className="md:col-span-2 space-y-2">
              <Label className="text-sm font-medium">آدرس‌های ذخیره شده</Label>
              <div className="flex gap-2 flex-wrap">
                {userAddresses.map(addr => (
                  <button
                    key={addr.id}
                    type="button"
                    onClick={() => setFormData(prev => ({
                      ...prev,
                      province: addr.province || '',
                      city: addr.city || '',
                      address: addr.address || '',
                      postalCode: addr.postalCode || '',
                    }))}
                    className={`text-xs px-3 py-2 rounded-lg border transition-all ${
                      formData.address === addr.address
                        ? 'border-[#dc2626] bg-red-50 text-[#dc2626]'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    {addr.title || addr.province}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* اطلاعات تماس */}
          <div className="md:col-span-2">
            <h3 className="font-bold mb-3 flex items-center gap-2">
              <User className="w-4 h-4 text-[#dc2626]" />
              اطلاعات تماس
            </h3>
          </div>

          <div className="space-y-2">
            <Label htmlFor="name">نام و نام خانوادگی *</Label>
            <div className="relative">
              <User className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                id="name"
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
                placeholder="مثلا: محمد رضایی"
                className="pr-10"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">شماره موبایل *</Label>
            <div className="relative">
              <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                id="phone"
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                placeholder="09121234567"
                dir="ltr"
                className="pr-10 text-left"
                required
              />
            </div>
          </div>

          {/* آدرس ارسال */}
          <div className="md:col-span-2">
            <h3 className="font-bold mb-3 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#dc2626]" />
              آدرس ارسال
            </h3>
          </div>

          <LocationSelector
            province={formData.province}
            city={formData.city}
            onProvinceChange={v => setFormData({ ...formData, province: v })}
            onCityChange={v => setFormData({ ...formData, city: v })}
          />

          <div className="space-y-2">
            <Label htmlFor="postalCode">کد پستی</Label>
            <Input
              id="postalCode"
              value={formData.postalCode}
              onChange={e => setFormData({ ...formData, postalCode: e.target.value })}
              placeholder="کد پستی ۱۰ رقمی"
              dir="ltr"
              className="text-left"
            />
          </div>

          <div className="md:col-span-2 space-y-2">
            <Label htmlFor="address">آدرس کامل *</Label>
            <Textarea
              id="address"
              value={formData.address}
              onChange={e => setFormData({ ...formData, address: e.target.value })}
              placeholder="خیابان، کوچه، پلاک، واحد"
              rows={2}
              required
            />
          </div>

          {/* کوپن تخفیف */}
          <div className="md:col-span-2">
            <h3 className="font-bold mb-3 flex items-center gap-2">
              <Ticket className="w-4 h-4 text-[#dc2626]" />
              کوپن تخفیف
            </h3>
            {appliedCoupon ? (
              <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded-lg p-3">
                <div className="flex items-center gap-2">
                  <Tag className="w-4 h-4 text-green-600" />
                  <span className="text-sm font-medium text-green-700">
                    {appliedCoupon.code} {appliedCoupon.type === 'free_shipping' ? '(ارسال رایگان)' : `(${formatPrice(discountAmount)} تومان تخفیف)`}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleRemoveCoupon}
                  className="text-red-500 hover:bg-red-50 p-1 rounded"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex gap-2">
                <Input
                  value={couponCode}
                  onChange={e => setCouponCode(e.target.value)}
                  placeholder="کد تخفیف"
                  className="flex-1"
                />
                <Button
                  type="button"
                  onClick={handleApplyCoupon}
                  disabled={couponLoading || !couponCode.trim()}
                  variant="outline"
                >
                  {couponLoading ? '...' : 'اعمال'}
                </Button>
              </div>
            )}
          </div>

          {/* روش پرداخت */}
          {paymentMethods.length > 0 && (
            <>
              <div className="md:col-span-2">
                <h3 className="font-bold mb-3 flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-[#dc2626]" />
                  روش پرداخت
                </h3>
              </div>
              <div className={`md:col-span-2 grid gap-2 ${paymentMethods.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
                {paymentMethods.map(pm => (
                  <button
                    key={pm.id}
                    type="button"
                    onClick={() => setFormData({ ...formData, paymentMethod: pm.type })}
                    className={`flex items-center gap-2 p-3 rounded-lg border-2 transition-all text-right ${
                      formData.paymentMethod === pm.type
                        ? 'border-[#dc2626] bg-red-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <CreditCard className={`w-5 h-5 ${formData.paymentMethod === pm.type ? 'text-[#dc2626]' : 'text-gray-400'}`} />
                    <div className="flex-1">
                      <p className="text-sm font-medium">{pm.name}</p>
                      {pm.description && <p className="text-xs text-gray-500">{pm.description}</p>}
                    </div>
                  </button>
                ))}
              </div>
            </>
          )}

          {/* یادداشت */}
          <div className="md:col-span-2 space-y-2">
            <Label htmlFor="notes">یادداشت (اختیاری)</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={e => setFormData({ ...formData, notes: e.target.value })}
              placeholder="هر توضیحی که برای ارسال لازم است..."
              rows={2}
            />
          </div>

          {/* خلاصه سفارش */}
          <div className="md:col-span-2 bg-gray-50 rounded-lg p-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">جمع کالاها:</span>
              <span className="font-bold fa-num">{formatPrice(total)} ت</span>
            </div>
            {discountAmount > 0 && (
              <div className="flex justify-between text-sm text-green-600">
                <span>تخفیف:</span>
                <span className="font-bold fa-num">- {formatPrice(discountAmount)} ت</span>
              </div>
            )}
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">هزینه ارسال:</span>
              <span className="font-bold fa-num">{shippingCost === 0 ? 'رایگان' : `${formatPrice(shippingCost)} ت`}</span>
            </div>
            <div className="border-t border-gray-200 pt-2 flex justify-between">
              <span className="font-bold">مبلغ نهایی:</span>
              <span className="font-bold text-[#dc2626] text-lg fa-num">{formatPrice(finalTotal)} ت</span>
            </div>
          </div>

          {/* دکمه ثبت */}
          <div className="md:col-span-2">
            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-[#dc2626] hover:bg-[#b91c1c] h-12 text-base font-bold"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin ml-1"></div>
                  در حال ثبت...
                </>
              ) : (
                `ثبت سفارش (${formatPrice(finalTotal)} ت)`
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
