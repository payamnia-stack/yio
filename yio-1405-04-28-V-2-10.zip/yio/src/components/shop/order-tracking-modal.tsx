'use client';

import { useState } from 'react';
import { X, Search, Package, Truck, CheckCircle, Clock, XCircle, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { formatPrice, toFa, orderStatuses, getOrderStatusInfo } from '@/lib/shop-data';

interface OrderInfo {
  orderNumber: string;
  status: string;
  finalAmount: number;
  createdAt: string;
  trackingCode?: string | null;
  paymentStatus: string;
  itemsCount: number;
  items: any[];
}

export function OrderTrackingModal({ onClose }: { onClose: () => void }) {
  const [loading, setLoading] = useState(false);
  const [order, setOrder] = useState<OrderInfo | null>(null);
  const [formData, setFormData] = useState({
    orderNumber: '',
    phone: '',
  });

  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.orderNumber.trim()) {
      toast.error('شماره سفارش را وارد کنید');
      return;
    }
    if (!/^09\d{9}$/.test(formData.phone)) {
      toast.error('شماره موبایل نامعتبر است');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/order-tracking', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await res.json();

      if (res.ok) {
        setOrder(data.order);
      } else {
        toast.error(data.error || 'سفارش یافت نشد');
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  };

  const statusInfo = order ? getOrderStatusInfo(order.status) : null;

  const formatDate = (d: string) => {
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(d));
  };

  return (
    <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-2 md:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-xl my-4 max-h-[95vh] overflow-y-auto">
        <div className="sticky top-0 bg-gradient-to-l from-[#dc2626] to-[#991b1b] text-white p-4 flex items-center justify-between z-10">
          <h2 className="text-lg font-bold flex items-center gap-2">
            <Search className="w-5 h-5" />
            پیگیری سفارش
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-white/20">
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="p-4 md:p-6">
          {!order ? (
            <form onSubmit={handleTrack} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="orderNumber">شماره سفارش *</Label>
                <Input
                  id="orderNumber"
                  value={formData.orderNumber}
                  onChange={e => setFormData({ ...formData, orderNumber: e.target.value.toUpperCase() })}
                  placeholder="مثلا: YIO-1004"
                  dir="ltr"
                  className="text-center font-bold"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">شماره موبایل (همان موقع ثبت سفارش) *</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="09121234567"
                  dir="ltr"
                  required
                />
              </div>

              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-[#dc2626] hover:bg-[#b91c1c] h-12"
              >
                <Search className="w-4 h-4 ml-2" />
                {loading ? 'در حال جستجو...' : 'پیگیری سفارش'}
              </Button>
            </form>
          ) : (
            <div className="space-y-4">
              {statusInfo && (
                <div className={`rounded-xl p-4 ${statusInfo.color}`}>
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{statusInfo.icon}</span>
                    <div>
                      <p className="text-xs opacity-80">وضعیت فعلی سفارش</p>
                      <p className="text-lg font-bold">{statusInfo.label}</p>
                    </div>
                  </div>
                </div>
              )}

              <div className="bg-gray-50 rounded-xl p-4 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">شماره سفارش:</span>
                  <span className="font-bold text-[#dc2626]">{order.orderNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">تاریخ ثبت:</span>
                  <span className="fa-num">{formatDate(order.createdAt)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">تعداد اقلام:</span>
                  <span className="fa-num">{toFa(order.itemsCount)} کالا</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">مبلغ کل:</span>
                  <span className="font-bold fa-num">{formatPrice(order.finalAmount)} ت</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">وضعیت پرداخت:</span>
                  <span className={order.paymentStatus === 'paid' ? 'text-green-600 font-bold' : 'text-amber-600 font-bold'}>
                    {order.paymentStatus === 'paid' ? 'پرداخت شده' : 'پرداخت نشده'}
                  </span>
                </div>
                {order.trackingCode && (
                  <div className="flex justify-between items-center pt-2 border-t border-gray-200">
                    <span className="text-gray-600">کد رهگیری پستی:</span>
                    <code className="bg-purple-50 text-purple-800 px-2 py-1 rounded font-bold fa-num" dir="ltr">
                      {order.trackingCode}
                    </code>
                  </div>
                )}
              </div>

              {/* اقلام سفارش */}
              <div>
                <h3 className="font-bold mb-2 text-sm">اقلام سفارش:</h3>
                <div className="space-y-2">
                  {order.items.map((item, idx) => (
                    <div key={idx} className="flex gap-3 bg-white border border-gray-100 rounded-lg p-2">
                      <img src={item.image} alt={item.title} className="w-12 h-12 object-cover rounded shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs line-clamp-2">{item.title}</p>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-[10px] text-gray-500 fa-num">{toFa(item.quantity)} عدد</span>
                          <span className="text-xs font-bold fa-num">{formatPrice(item.price * item.quantity)} ت</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* مراحل سفارش */}
              <div>
                <h3 className="font-bold mb-2 text-sm">مراحل سفارش:</h3>
                <div className="space-y-2">
                  {orderStatuses.map((status, idx) => {
                    const currentIdx = orderStatuses.findIndex(s => s.value === order.status);
                    const isPast = idx <= currentIdx;
                    const isCurrent = idx === currentIdx;
                    return (
                      <div key={status.value} className={`flex items-center gap-2 p-2 rounded-lg ${isCurrent ? 'bg-red-50' : ''}`}>
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${
                          isPast ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'
                        }`}>
                          {isPast ? <CheckCircle className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                        </div>
                        <span className={`text-sm ${isPast ? 'font-bold' : 'text-gray-400'}`}>
                          {status.icon} {status.label}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>

              <Button onClick={() => setOrder(null)} variant="outline" className="w-full">
                پیگیری سفارش دیگر
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
