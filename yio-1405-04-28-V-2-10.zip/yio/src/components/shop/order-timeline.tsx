'use client';

import { Check, Package, Truck, Home, Clock, XCircle, ShoppingBag } from 'lucide-react';
import { toFa } from '@/lib/shop-data';

interface OrderTimelineProps {
  status: string;
  createdAt: string;
  updatedAt?: string;
}

interface TimelineStep {
  key: string;
  label: string;
  icon: any;
  description: string;
}

const STEPS: TimelineStep[] = [
  { key: 'pending', label: 'ثبت سفارش', icon: ShoppingBag, description: 'سفارش شما ثبت شد' },
  { key: 'confirmed', label: 'تأیید سفارش', icon: Check, description: 'سفارش توسط فروشگاه تأیید شد' },
  { key: 'shipping', label: 'ارسال', icon: Truck, description: 'سفارش در حال ارسال است' },
  { key: 'delivered', label: 'تحویل', icon: Home, description: 'سفارش تحویل داده شد' },
];

export function OrderTimeline({ status, createdAt, updatedAt }: OrderTimelineProps) {
  const isCancelled = status === 'cancelled';

  // پیدا کردن ایندکس فعلی
  const currentIndex = isCancelled ? -1 : STEPS.findIndex(s => s.key === status);

  return (
    <div className="bg-white rounded-xl p-4 border border-gray-100">
      <h4 className="font-bold text-sm mb-4 flex items-center gap-2">
        <Clock className="w-4 h-4 text-[#dc2626]" />
        وضعیت سفارش
      </h4>

      {isCancelled ? (
        <div className="flex items-center gap-3 p-4 bg-red-50 rounded-lg">
          <XCircle className="w-8 h-8 text-red-500" />
          <div>
            <p className="font-bold text-red-700">سفارش لغو شد</p>
            <p className="text-xs text-red-500 mt-0.5">
              {new Date(updatedAt || createdAt).toLocaleDateString('fa-IR')}
            </p>
          </div>
        </div>
      ) : (
        <div className="relative">
          {/* خط اتصال */}
          <div className="absolute right-5 top-5 bottom-5 w-0.5 bg-gray-200"></div>

          <div className="space-y-4">
            {STEPS.map((step, idx) => {
              const isDone = idx <= currentIndex;
              const isCurrent = idx === currentIndex;
              const Icon = step.icon;

              return (
                <div key={step.key} className="flex items-start gap-3 relative">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 z-10 transition-all ${
                    isDone
                      ? isCurrent
                        ? 'bg-[#dc2626] text-white ring-4 ring-[#dc2626]/20'
                        : 'bg-[#dc2626] text-white'
                      : 'bg-gray-100 text-gray-400'
                  }`}>
                    <Icon className={`w-5 h-5 ${isDone ? '' : ''}`} />
                  </div>
                  <div className="flex-1 pt-1">
                    <p className={`text-sm font-medium ${isDone ? 'text-gray-900' : 'text-gray-400'}`}>
                      {step.label}
                      {isCurrent && (
                        <span className="mr-2 text-xs text-[#dc2626] bg-red-50 px-2 py-0.5 rounded-full">
                          در حال انجام
                        </span>
                      )}
                    </p>
                    <p className="text-xs text-gray-400 mt-0.5">{step.description}</p>
                    {isDone && idx === currentIndex && (
                      <p className="text-[10px] text-gray-400 mt-1">
                        {new Date(updatedAt || createdAt).toLocaleDateString('fa-IR')}
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
