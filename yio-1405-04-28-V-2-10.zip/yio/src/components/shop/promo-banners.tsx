'use client';

import { Button } from '@/components/ui/button';

export function PromoBanners() {
  return (
    <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {/* بنر اول - اسباب‌بازی چوبی */}
      <div
        className="rounded-xl overflow-hidden p-6 md:p-8 text-white relative min-h-[160px] flex items-center"
        style={{ background: 'linear-gradient(135deg, #f59e0b 0%, #b45309 100%)' }}
      >
        <div className="relative z-10">
          <h3 className="text-xl md:text-2xl font-bold mb-2">اسباب‌بازی‌های چوبی</h3>
          <p className="text-sm opacity-90 mb-4">ایمن و طبیعی برای کودکان شما</p>
          <Button
            size="sm"
            className="bg-white text-[#b45309] hover:bg-gray-100 font-bold"
          >
            مشاهده محصولات
          </Button>
        </div>
        <div className="absolute left-4 text-8xl opacity-20">🧸</div>
      </div>

      {/* بنر دوم - ظروف چوبی */}
      <div
        className="rounded-xl overflow-hidden p-6 md:p-8 text-white relative min-h-[160px] flex items-center"
        style={{ background: 'linear-gradient(135deg, #84cc16 0%, #365314 100%)' }}
      >
        <div className="relative z-10">
          <h3 className="text-xl md:text-2xl font-bold mb-2">ظروف بامبو آشپزخانه</h3>
          <p className="text-sm opacity-90 mb-4">طبیعی، ضدباکتری و زیبا</p>
          <Button
            size="sm"
            className="bg-white text-[#365314] hover:bg-gray-100 font-bold"
          >
            خرید کنید
          </Button>
        </div>
        <div className="absolute left-4 text-8xl opacity-20">🍽️</div>
      </div>
    </section>
  );
}
