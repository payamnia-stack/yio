'use client';

import { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { useStockUpdates } from '@/hooks/use-stock-updates';
import type { StockUpdate } from '@/lib/stock-events';

interface StockContextValue {
  // map از productId به stockQuantity آپدیت شده
  stockOverrides: Record<number, number>;
  // تابعی برای گرفتن stockQuantity فعلی یک محصول
  getStock: (productId: number, originalStock?: number) => number | undefined;
  // تعداد آپدیت‌های دریافتی (برای debug)
  updateCount: number;
}

const StockContext = createContext<StockContextValue>({
  stockOverrides: {},
  getStock: (_productId, originalStock) => originalStock,
  updateCount: 0,
});

export function useStockContext() {
  return useContext(StockContext);
}

export function StockProvider({ children }: { children: ReactNode }) {
  const [stockOverrides, setStockOverrides] = useState<Record<number, number>>({});
  const [updateCount, setUpdateCount] = useState(0);

  const handleStockUpdate = useCallback((update: StockUpdate) => {
    setStockOverrides(prev => ({
      ...prev,
      [update.productId]: update.stockQuantity,
    }));
    setUpdateCount(c => c + 1);
  }, []);

  // subscribtion به SSE (فقط یک اتصال برای کل صفحه)
  useStockUpdates({ onStockUpdate: handleStockUpdate });

  const getStock = useCallback((productId: number, originalStock?: number): number | undefined => {
    if (productId in stockOverrides) {
      return stockOverrides[productId];
    }
    return originalStock;
  }, [stockOverrides]);

  return (
    <StockContext.Provider value={{ stockOverrides, getStock, updateCount }}>
      {children}
    </StockContext.Provider>
  );
}
