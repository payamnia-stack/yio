'use client';

import { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';
import { toFa } from '@/lib/shop-data';

interface DiscountTimerProps {
  endDate?: string | null;
}

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export function DiscountTimer({ endDate }: DiscountTimerProps) {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  const [expired, setExpired] = useState(false);

  useEffect(() => {
    if (!endDate) return;

    const target = new Date(endDate).getTime();

    const timer = setInterval(() => {
      const now = Date.now();
      const diff = target - now;

      if (diff <= 0) {
        setExpired(true);
        clearInterval(timer);
        return;
      }

      setTimeLeft({
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((diff % (1000 * 60)) / 1000),
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [endDate]);

  if (!endDate || expired) return null;

  const pad = (n: number) => n.toString().padStart(2, '0');

  const TimeBlock = ({ value, label }: { value: number; label: string }) => (
    <div className="flex flex-col items-center">
      <span className="bg-[#dc2626] text-white text-sm font-bold min-w-[2.2rem] px-1.5 py-1 rounded text-center fa-num">
        {toFa(pad(value))}
      </span>
      <span className="text-[10px] text-gray-600 mt-1 font-medium">{label}</span>
    </div>
  );

  const Separator = () => (
    <span className="text-[#dc2626] font-bold text-lg leading-none mt-[1px]">:</span>
  );

  return (
    <div className="inline-flex items-center gap-3 bg-red-50 border border-red-200 rounded-lg px-4 py-2">
      <Clock className="w-4 h-4 text-[#dc2626] animate-pulse shrink-0" />
      <span className="text-xs text-red-700 font-medium shrink-0">پایان تخفیف:</span>
      <div className="flex items-start gap-1.5" dir="ltr">
        {timeLeft.days > 0 && (
          <>
            <TimeBlock value={timeLeft.days} label="روز" />
            <Separator />
          </>
        )}
        <TimeBlock value={timeLeft.hours} label="ساعت" />
        <Separator />
        <TimeBlock value={timeLeft.minutes} label="دقیقه" />
        <Separator />
        <TimeBlock value={timeLeft.seconds} label="ثانیه" />
      </div>
    </div>
  );
}
