'use client';

import { useState, useEffect } from 'react';
import { Users, Copy, Check, Gift, UserPlus, Award } from 'lucide-react';
import { toFa } from '@/lib/shop-data';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export function ReferralTab() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  const fetchReferral = async () => {
    try {
      const res = await fetch('/api/user/referral');
      if (res.ok) {
        const d = await res.json();
        setData(d);
      }
    } catch {}
    setLoading(false);
  };

  useEffect(() => { fetchReferral(); }, []);

  const handleCopy = () => {
    if (!data?.referralCode) return;
    navigator.clipboard.writeText(data.referralCode);
    setCopied(true);
    toast.success('کد ارجاع کپی شد');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareLink = () => {
    if (!data?.referralLink) return;
    navigator.clipboard.writeText(data.referralLink);
    toast.success('لینک ارجاع کپی شد');
  };

  if (loading) {
    return <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-[#dc2626]" /></div>;
  }

  if (!data) {
    return <div className="bg-white rounded-xl p-8 text-center text-gray-500">خطا</div>;
  }

  return (
    <div className="space-y-4">
      {/* کارت کد ارجاع */}
      <div className="bg-gradient-to-l from-purple-600 to-indigo-700 rounded-2xl p-6 text-white shadow-lg">
        <div className="flex items-center gap-2 mb-3">
          <Gift className="w-5 h-5" />
          <h3 className="font-bold">دعوت دوستان = پاداش مشترک!</h3>
        </div>
        <p className="text-sm opacity-90 mb-4">
          با معرفی سایت به دوستانت، هر دو ۵۰هزار تومان پاداش بگیرید!
          وقتی دوستت با کد تو ثبت‌نام کنه، خودکار به کیف پولت واریز می‌شه.
        </p>

        <div className="bg-white/20 backdrop-blur rounded-xl p-4">
          <p className="text-xs opacity-90 mb-1">کد ارجاع شما:</p>
          <div className="flex items-center justify-between gap-2">
            <code className="text-2xl font-bold tracking-wider" dir="ltr">{data.referralCode}</code>
            <button
              onClick={handleCopy}
              className="bg-white text-purple-700 px-3 py-1.5 rounded-lg text-sm font-medium hover:bg-gray-100 transition-colors flex items-center gap-1"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copied ? 'کپی شد' : 'کپی'}
            </button>
          </div>
        </div>

        <button
          onClick={handleShareLink}
          className="mt-3 w-full bg-white/20 hover:bg-white/30 backdrop-blur text-white py-2 rounded-lg text-sm font-medium transition-colors"
        >
          📋 کپی لینک دعوت
        </button>
      </div>

      {/* آمار */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white rounded-xl p-4 border border-gray-100 text-center">
          <UserPlus className="w-6 h-6 mx-auto mb-1 text-purple-500" />
          <p className="text-2xl font-bold fa-num text-purple-600">{toFa(data.stats.total)}</p>
          <p className="text-xs text-gray-500">کل دعوت‌ها</p>
        </div>
        <div className="bg-white rounded-xl p-4 border border-gray-100 text-center">
          <Award className="w-6 h-6 mx-auto mb-1 text-green-500" />
          <p className="text-2xl font-bold fa-num text-green-600">{toFa(data.stats.verified)}</p>
          <p className="text-xs text-gray-500">تأیید شده</p>
        </div>
      </div>

      {/* لیست دوستان دعوت‌شده */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="p-4 border-b border-gray-100">
          <h3 className="font-bold flex items-center gap-2">
            <Users className="w-4 h-4 text-[#dc2626]" />
            دوستان دعوت‌شده
          </h3>
        </div>
        {data.referrals.length === 0 ? (
          <div className="p-8 text-center text-gray-400 text-sm">
            <Users className="w-12 h-12 mx-auto mb-2 opacity-20" />
            هنوز کسی را دعوت نکرده‌اید
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {data.referrals.map((ref: any, idx: number) => (
              <div key={ref.id} className="p-3 flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center text-xs font-bold">
                  {toFa(idx + 1)}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">{ref.name || 'کاربر جدید'}</p>
                  <p className="text-[10px] text-gray-400">
                    {new Date(ref.createdAt).toLocaleDateString('fa-IR')}
                  </p>
                </div>
                {ref.isVerified ? (
                  <span className="bg-green-50 text-green-600 text-[10px] px-2 py-0.5 rounded-full">
                    ✓ تأیید شده
                  </span>
                ) : (
                  <span className="bg-amber-50 text-amber-600 text-[10px] px-2 py-0.5 rounded-full">
                    در انتظار
                  </span>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
