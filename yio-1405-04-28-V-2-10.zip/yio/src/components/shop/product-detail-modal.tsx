'use client';

import { useState } from 'react';
import { X, ChevronRight, ChevronLeft, Image as ImageIcon, Video, Play, Star, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Product, parseImages, parseVideos, parseColors, formatPrice, toFa, getStockBadge, isProductAvailable } from '@/lib/shop-data';
import { useShopStore } from '@/store/shop-store';
import { toast } from 'sonner';

interface ProductDetailModalProps {
  product: Product;
  onClose: () => void;
}

export function ProductDetailModal({ product, onClose }: ProductDetailModalProps) {
  const images = parseImages(product.images);
  const allImages = product.image && !images.includes(product.image)
    ? [product.image, ...images]
    : images.length > 0 ? images : [product.image];
  const videos = parseVideos(product.videos);
  const colors = parseColors(product.colors as any);

  const [activeTab, setActiveTab] = useState<'images' | 'videos'>('images');
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedColor, setSelectedColor] = useState<string | undefined>(colors[0]?.name);
  const [quantity, setQuantity] = useState(1);

  const addToCart = useShopStore(s => s.addToCart);

  const finalPrice = product.discountPrice ?? product.price;
  const total = finalPrice * quantity;
  const stockInfo = getStockBadge(product.stockQuantity);
  const available = isProductAvailable(product);

  const handleAddToCart = () => {
    if (!available) {
      toast.error('این محصول در حال حاضر ناموجود است');
      return;
    }
    addToCart(product as any, selectedColor);
    toast.success('به سبد خرید اضافه شد', {
      description: `${quantity} عدد ${product.title.slice(0, 30)}...`,
    });
    onClose();
  };

  const nextItem = () => {
    const max = activeTab === 'images' ? allImages.length : videos.length;
    setCurrentIdx(prev => (prev + 1) % max);
  };

  const prevItem = () => {
    const max = activeTab === 'images' ? allImages.length : videos.length;
    setCurrentIdx(prev => (prev - 1 + max) % max);
  };

  return (
    <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-2 md:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl my-4 max-h-[95vh] overflow-y-auto">
        {/* هدر */}
        <div className="sticky top-0 bg-white border-b border-gray-100 p-4 flex items-center justify-between gap-2 z-10">
          <h2 className="text-lg font-bold line-clamp-1 text-left flex-1" dir="rtl">{product.title}</h2>
          <button
            onClick={onClose}
            className="w-9 h-9 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200 text-gray-700 transition-all hover:scale-105 shrink-0"
            aria-label="بستن"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 md:p-6">
          {/* بخش نمایش چندرسانه‌ای */}
          <div className="space-y-3">
            {/* نمایش اصلی */}
            <div className="relative aspect-square bg-gray-100 rounded-xl overflow-hidden">
              {activeTab === 'images' ? (
                <img
                  src={allImages[currentIdx]}
                  alt={product.title}
                  className="w-full h-full object-cover"
                />
              ) : (
                <video
                  src={videos[currentIdx]}
                  className="w-full h-full object-cover"
                  controls
                  autoPlay
                  playsInline
                />
              )}

              {/* دکمه‌های ناوبری */}
              {((activeTab === 'images' && allImages.length > 1) || (activeTab === 'videos' && videos.length > 1)) && (
                <>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={prevItem}
                    className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white"
                  >
                    <ChevronRight className="w-6 h-6" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={nextItem}
                    className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white"
                  >
                    <ChevronLeft className="w-6 h-6" />
                  </Button>
                </>
              )}

              {/* شمارنده */}
              <div className="absolute bottom-2 left-2 bg-black/60 text-white text-xs px-2 py-1 rounded fa-num">
                {toFa(currentIdx + 1)} / {toFa(activeTab === 'images' ? allImages.length : videos.length)}
              </div>
            </div>

            {/* تب‌ها */}
            {videos.length > 0 && (
              <div className="flex gap-2">
                <button
                  onClick={() => { setActiveTab('images'); setCurrentIdx(0); }}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm transition-colors ${
                    activeTab === 'images' ? 'bg-[#dc2626] text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  <ImageIcon className="w-4 h-4" />
                  تصاویر ({toFa(allImages.length)})
                </button>
                <button
                  onClick={() => { setActiveTab('videos'); setCurrentIdx(0); }}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm transition-colors ${
                    activeTab === 'videos' ? 'bg-[#dc2626] text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  <Video className="w-4 h-4" />
                  ویدیوها ({toFa(videos.length)})
                </button>
              </div>
            )}

            {/* تصاویر کوچک */}
            {activeTab === 'images' && allImages.length > 1 && (
              <div className="grid grid-cols-5 gap-2">
                {allImages.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentIdx(idx)}
                    className={`aspect-square rounded-lg overflow-hidden border-2 transition-all ${
                      currentIdx === idx ? 'border-[#dc2626]' : 'border-transparent opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt={`تصویر ${idx + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}

            {/* ویدیوهای کوچک */}
            {activeTab === 'videos' && videos.length > 1 && (
              <div className="grid grid-cols-3 gap-2">
                {videos.map((video, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentIdx(idx)}
                    className={`aspect-video rounded-lg overflow-hidden border-2 transition-all relative bg-gray-900 ${
                      currentIdx === idx ? 'border-[#dc2626]' : 'border-transparent opacity-60 hover:opacity-100'
                    }`}
                  >
                    <video src={video} className="w-full h-full object-cover" muted preload="metadata" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Play className="w-6 h-6 text-white" />
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* بخش اطلاعات */}
          <div className="space-y-4">
            {/* برند و نوع چوب */}
            <div className="flex flex-wrap gap-2">
              <span className="bg-gray-100 text-gray-700 text-xs px-3 py-1 rounded-full">
                {product.brand}
              </span>
              {product.woodType && (
                <span className="bg-amber-50 text-amber-700 text-xs px-3 py-1 rounded-full">
                  🪵 {product.woodType}
                </span>
              )}
              <span className="bg-gray-100 text-gray-700 text-xs px-3 py-1 rounded-full">
                {product.category}
              </span>
            </div>

            {/* عنوان */}
            <h1 className="text-xl font-bold text-gray-900">{product.title}</h1>

            {/* Badge موجودی — متن رنگی بدون پس‌زمینه */}
            <div className={`inline-flex items-center gap-2 ${stockInfo.textClass} text-xs font-bold w-fit fa-num`}>
              <span className={`w-2 h-2 rounded-full ${stockInfo.dotClass} ${stockInfo.isOutOfStock ? 'animate-pulse' : ''}`}></span>
              {stockInfo.countLabel}
            </div>

            {/* امتیاز */}
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 bg-amber-50 px-2 py-1 rounded">
                <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                <span className="font-bold text-sm fa-num">{toFa(product.rating.toFixed(1))}</span>
              </div>
              <span className="text-sm text-gray-500 fa-num">
                ({toFa(product.ratingCount)} نظر)
              </span>
            </div>

            {/* قیمت */}
            <div className="bg-gradient-to-l from-red-50 to-transparent p-4 rounded-xl">
              {product.discountPercent ? (
                <div className="flex items-end gap-3">
                  <div>
                    <span className="text-sm text-gray-400 line-through fa-num block">
                      {formatPrice(product.price)} تومان
                    </span>
                    <span className="text-2xl font-bold text-[#dc2626] fa-num">
                      {formatPrice(finalPrice)}
                      <span className="text-sm mr-1">تومان</span>
                    </span>
                  </div>
                  <span className="bg-[#dc2626] text-white text-sm px-2 py-1 rounded fa-num mb-1">
                    {toFa(product.discountPercent)}٪ تخفیف
                  </span>
                </div>
              ) : (
                <span className="text-2xl font-bold text-gray-900 fa-num">
                  {formatPrice(finalPrice)}
                  <span className="text-sm mr-1">تومان</span>
                </span>
              )}
            </div>

            {/* رنگ‌ها */}
            {colors.length > 0 && (
              <div className="space-y-2">
                <Label className="text-sm font-medium">رنگ: {selectedColor}</Label>
                <div className="flex gap-2">
                  {colors.map(color => (
                    <button
                      key={color.name}
                      onClick={() => setSelectedColor(color.name)}
                      className={`w-10 h-10 rounded-full border-2 transition-all ${
                        selectedColor === color.name ? 'border-[#dc2626] scale-110' : 'border-gray-200'
                      }`}
                      style={{ backgroundColor: color.code }}
                      title={color.name}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* تعداد */}
            <div className="space-y-2">
              <Label className="text-sm font-medium">تعداد</Label>
              <div className="flex items-center gap-2 bg-gray-100 rounded-lg p-1 w-fit">
                <button
                  onClick={() => setQuantity(q => Math.max(1, q - 1))}
                  className="w-9 h-9 flex items-center justify-center hover:bg-white rounded"
                >
                  −
                </button>
                <span className="w-10 text-center font-bold fa-num">{toFa(quantity)}</span>
                <button
                  onClick={() => setQuantity(q => Math.min(99, q + 1))}
                  className="w-9 h-9 flex items-center justify-center hover:bg-white rounded"
                >
                  +
                </button>
              </div>
            </div>

            {/* مجموع */}
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-sm text-gray-600">مجموع:</span>
              <span className="text-lg font-bold text-[#dc2626] fa-num">
                {formatPrice(total)} تومان
              </span>
            </div>

            {/* دکمه خرید */}
            <Button
              onClick={handleAddToCart}
              disabled={!available}
              className={`w-full h-12 ${available ? 'bg-[#dc2626] hover:bg-[#b91c1c]' : 'bg-gray-300 hover:bg-gray-300 cursor-not-allowed'} text-white font-bold text-base`}
            >
              {available ? 'افزودن به سبد خرید' : 'ناموجود'}
            </Button>

            {/* توضیحات */}
            {product.description && (
              <div className="pt-4 border-t border-gray-100">
                <h3 className="font-bold mb-2">توضیحات محصول</h3>
                <p className="text-sm text-gray-600 leading-6">{product.description}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function Label({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <label className={`block text-sm font-medium text-gray-700 ${className}`}>{children}</label>;
}
