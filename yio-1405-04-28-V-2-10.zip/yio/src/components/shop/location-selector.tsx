'use client';

import { useState, useEffect } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { getProvinces, getCities } from '@/lib/iran-cities';

interface LocationSelectorProps {
  province: string;
  city: string;
  onProvinceChange: (v: string) => void;
  onCityChange: (v: string) => void;
  required?: boolean;
}

export function LocationSelector({
  province, city, onCityChange, onProvinceChange, required = false,
}: LocationSelectorProps) {
  // محاسبه شهرها بر اساس استان فعلی
  const cities = province ? Array.from(new Set(getCities(province))) : [];

  // وقتی province تغییر کرد، اگر city فعلی در شهرهای استان جدید نیست، پاکش کن
  useEffect(() => {
    if (province) {
      const newCities = Array.from(new Set(getCities(province)));
      if (city && !newCities.includes(city)) {
        // city در لیست نیست → پاک کن
        onCityChange('');
      }
    } else {
      // province خالی → city را هم پاک کن
      if (city) onCityChange('');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [province]);

  return (
    <div className="grid grid-cols-2 gap-3">
      <div className="space-y-2">
        <Label>استان {required && '*'}</Label>
        <Select value={province} onValueChange={onProvinceChange}>
          <SelectTrigger>
            <SelectValue placeholder="انتخاب استان" />
          </SelectTrigger>
          <SelectContent>
            {getProvinces().map(p => (
              <SelectItem key={p} value={p}>{p}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label>شهر {required && '*'}</Label>
        <Select
          value={city}
          onValueChange={onCityChange}
          disabled={!province}
        >
          <SelectTrigger>
            <SelectValue placeholder={province ? 'انتخاب شهر' : 'ابتدا استان را انتخاب کنید'} />
          </SelectTrigger>
          <SelectContent>
            {cities.map(c => (
              <SelectItem key={c} value={c}>{c}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
