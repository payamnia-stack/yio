'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { Menu, ChevronLeft, Flame, Percent, TrendingUp, Phone, Info, FileText } from 'lucide-react';

interface Cat {
  id: number;
  title: string;
  slug: string;
  icon: string;
  color: string;
  description?: string | null;
}

// زیردسته‌های هر دسته‌بندی (از shop-data.ts)
const SUBCATEGORIES: Record<string, string[]> = {
  'اسباب‌بازی چوبی': ['ماشین چوبی', 'پازل چوبی', 'بلوک چوبی', 'خانه عروسکی'],
  'ظروف آشپزخانه': ['بشقاب چوبی', 'قاشق و چنگال', 'تخته برش', 'کاسه چوبی'],
  'مبلمان چوبی': ['صندلی', 'میز', 'تاب', 'کمد'],
  'دکوراسیون چوبی': ['تابلو', 'آینه', 'ساعت', 'جعبه'],
  'لوازم کودک': ['کرسی کودک', 'میز تحریر', 'اسباب‌بازی آموزشی'],
  'هدیه و صنایع دستی': ['جعبه هدیه', 'ساعت رومیزی', 'مجسمه'],
  'نقاشی و هنر': ['پالت نقاشی', 'استند', 'قاب عکس'],
  'باغ و حیاط': ['گلدان چوبی', 'حصار', 'نیمکت'],
};

// لینک‌های افقی کنار دکمه «دسته‌بندی کالاها»
const QUICK_LINKS = [
  { href: '/special', label: 'فروش ویژه', icon: Flame, color: 'text-[#dc2626]' },
  { href: '/category/all?hasDiscount=true', label: 'تخفیف‌ها', icon: Percent, color: 'text-orange-600' },
  { href: '/category/all?sort=rating', label: 'پرفروش‌ها', icon: TrendingUp, color: 'text-green-600' },
  { href: '/blog', label: 'بلاگ', icon: FileText, color: 'text-blue-600' },
  { href: '/contact', label: 'تماس با ما', icon: Phone, color: 'text-gray-600' },
  { href: '/about', label: 'درباره ما', icon: Info, color: 'text-gray-600' },
];

export function CategoryMenu() {
  const [categories, setCategories] = useState<Cat[]>([]);
  const [megaOpen, setMegaOpen] = useState(false);
  const [hoveredCategory, setHoveredCategory] = useState<Cat | null>(null);
  const [hoveredTopCat, setHoveredTopCat] = useState<Cat | null>(null);
  const closeTimerRef = useRef<NodeJS.Timeout | null>(null);
  const topCatTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    fetch('/api/categories')
      .then(r => r.json())
      .then(data => setCategories(data.categories || []))
      .catch(() => {});
  }, []);

  const openMega = () => {
    if (closeTimerRef.current) clearTimeout(closeTimerRef.current);
    setMegaOpen(true);
  };

  const scheduleCloseMega = () => {
    if (closeTimerRef.current) clearTimeout(closeTimerRef.current);
    closeTimerRef.current = setTimeout(() => {
      setMegaOpen(false);
      setHoveredCategory(null);
    }, 200);
  };

  const scheduleCloseTopCat = () => {
    if (topCatTimerRef.current) clearTimeout(topCatTimerRef.current);
    topCatTimerRef.current = setTimeout(() => setHoveredTopCat(null), 200);
  };

  const cancelCloseTopCat = () => {
    if (topCatTimerRef.current) clearTimeout(topCatTimerRef.current);
  };

  if (categories.length === 0) return null;

  // ۴ دسته اول برای نمایش افقی
  const topCategories = categories.slice(0, 4);

  return (
    <div className="border-t border-gray-100 bg-white hidden lg:block relative">
      <div className="container mx-auto px-4">
        <div className="flex items-center gap-1 h-12">
          {/* دکمه «دسته‌بندی کالاها» با آیکون همبرگر */}
          <div
            className="relative"
            onMouseEnter={openMega}
            onMouseLeave={scheduleCloseMega}
          >
            <button
              className={`flex items-center gap-2 px-3 py-2 text-sm font-bold rounded-md transition-colors ${
                megaOpen ? 'bg-red-50 text-[#dc2626]' : 'text-gray-700 hover:bg-gray-50'
              }`}
            >
              <Menu className="w-5 h-5" />
              دسته‌بندی کالاها
            </button>

            {/* Mega Menu کشویی */}
            {megaOpen && (
              <div
                className="absolute top-full right-0 mt-0 bg-white shadow-2xl border border-gray-100 z-50 flex"
                style={{
                  width: 'min(900px, 80vw)',
                  minHeight: '420px',
                  borderRadius: '0 0 8px 8px',
                }}
                onMouseEnter={openMega}
                onMouseLeave={scheduleCloseMega}
              >
                {/* ستون راست: لیست دسته‌ها */}
                <div className="w-[260px] border-l border-gray-100 bg-gray-50/50 overflow-y-auto">
                  {categories.map(cat => {
                    const isActive = hoveredCategory?.id === cat.id;
                    return (
                      <Link
                        key={cat.id}
                        href={`/category/${encodeURIComponent(cat.slug || cat.title)}`}
                        className={`flex items-center justify-between gap-2 px-4 py-3 text-sm transition-colors group ${
                          isActive ? 'bg-white text-[#dc2626] font-bold border-r-2 border-[#dc2626]' : 'text-gray-700 hover:bg-white'
                        }`}
                        onMouseEnter={() => setHoveredCategory(cat)}
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="text-lg shrink-0">{cat.icon}</span>
                          <span className="truncate">{cat.title}</span>
                        </div>
                        <ChevronLeft className={`w-4 h-4 shrink-0 transition-transform ${isActive ? 'text-[#dc2626]' : 'text-gray-300 group-hover:text-gray-500'}`} />
                      </Link>
                    );
                  })}
                </div>

                {/* ستون چپ: زیردسته‌های دسته‌ی hover شده */}
                <div className="flex-1 p-5 overflow-y-auto">
                  {hoveredCategory ? (
                    <>
                      <div className="mb-4 pb-3 border-b border-gray-100">
                        <h3 className="text-base font-bold text-gray-900 flex items-center gap-2">
                          <span className="text-xl">{hoveredCategory.icon}</span>
                          {hoveredCategory.title}
                        </h3>
                      </div>

                      {/* لینک «همه محصولات» */}
                      <Link
                        href={`/category/${encodeURIComponent(hoveredCategory.slug || hoveredCategory.title)}`}
                        className="inline-block text-sm font-bold text-[#dc2626] hover:underline mb-4"
                      >
                        مشاهده همه محصولات {hoveredCategory.title} ←
                      </Link>

                      {/* زیردسته‌ها در ۳ ستون */}
                      <div className="grid grid-cols-3 gap-x-5 gap-y-3">
                        {(SUBCATEGORIES[hoveredCategory.title] || []).map((sub, idx) => (
                          <Link
                            key={idx}
                            href={`/category/${encodeURIComponent(hoveredCategory.slug || hoveredCategory.title)}?sub=${encodeURIComponent(sub)}`}
                            className="text-xs text-gray-600 hover:text-[#dc2626] hover:font-medium transition-colors block"
                          >
                            {sub}
                          </Link>
                        ))}

                        {/* لینک‌های مفید */}
                        <Link
                          href={`/category/${encodeURIComponent(hoveredCategory.slug || hoveredCategory.title)}?sort=priceAsc`}
                          className="text-xs text-gray-600 hover:text-[#dc2626] hover:font-medium transition-colors block"
                        >
                          ارزان‌ترین‌ها
                        </Link>
                        <Link
                          href={`/category/${encodeURIComponent(hoveredCategory.slug || hoveredCategory.title)}?sort=rating`}
                          className="text-xs text-gray-600 hover:text-[#dc2626] hover:font-medium transition-colors block"
                        >
                          محبوب‌ترین‌ها
                        </Link>
                        <Link
                          href={`/category/${encodeURIComponent(hoveredCategory.slug || hoveredCategory.title)}?hasDiscount=true`}
                          className="text-xs text-gray-600 hover:text-[#dc2626] hover:font-medium transition-colors block"
                        >
                          تخفیف‌دارها
                        </Link>
                      </div>

                      {/* بنر تبلیغاتی پایین */}
                      <Link
                        href={`/category/${encodeURIComponent(hoveredCategory.slug || hoveredCategory.title)}`}
                        className="mt-5 block bg-gradient-to-l from-red-50 to-orange-50 border border-red-100 rounded-lg p-3 hover:from-red-100 hover:to-orange-100 transition-colors"
                      >
                        <div className="flex items-center gap-2 text-xs">
                          <span className="text-[#dc2626] font-bold">🔥 فروش ویژه</span>
                          <span className="text-gray-600">— بهترین تخفیف‌های {hoveredCategory.title}</span>
                        </div>
                      </Link>
                    </>
                  ) : (
                    // وقتی هیچ دسته‌ای hover نیست، پیش‌فرض: دسته اول
                    <div className="text-center py-12">
                      <p className="text-sm text-gray-400">
                        نشانگر موس را روی یک دسته ببرید تا زیردسته‌ها نمایش داده شوند
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* جداکننده */}
          <div className="w-px h-6 bg-gray-200 mx-2"></div>

          {/* لینک‌های افقی: دسته‌های پررنگ */}
          {topCategories.map(cat => (
            <div
              key={cat.id}
              className="relative"
              onMouseEnter={() => {
                cancelCloseTopCat();
                setHoveredTopCat(cat);
              }}
              onMouseLeave={scheduleCloseTopCat}
            >
              <Link
                href={`/category/${encodeURIComponent(cat.slug || cat.title)}`}
                className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-gray-700 hover:text-[#dc2626] transition-colors"
              >
                <span className="text-base">{cat.icon}</span>
                {cat.title}
              </Link>

              {/* Dropdown کوچک برای زیردسته‌ها */}
              {hoveredTopCat?.id === cat.id && (
                <div
                  className="absolute top-full right-0 mt-0 bg-white shadow-2xl border border-gray-100 z-40 p-3"
                  style={{
                    width: '240px',
                    borderRadius: '0 0 8px 8px',
                  }}
                  onMouseEnter={cancelCloseTopCat}
                  onMouseLeave={scheduleCloseTopCat}
                >
                  <Link
                    href={`/category/${encodeURIComponent(cat.slug || cat.title)}`}
                    className="block px-2 py-1.5 text-xs font-bold text-[#dc2626] hover:bg-red-50 rounded mb-2"
                  >
                    همه محصولات {cat.title} ←
                  </Link>
                  <div className="space-y-0.5">
                    {(SUBCATEGORIES[cat.title] || []).map((sub, idx) => (
                      <Link
                        key={idx}
                        href={`/category/${encodeURIComponent(cat.slug || cat.title)}?sub=${encodeURIComponent(sub)}`}
                        className="block px-2 py-1.5 text-xs text-gray-600 hover:text-[#dc2626] hover:bg-gray-50 rounded transition-colors"
                      >
                        {sub}
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}

          {/* لینک‌های سریع سمت چپ */}
          <div className="flex items-center gap-1 mr-auto pr-3 border-r border-gray-100">
            {QUICK_LINKS.map(link => {
              const Icon = link.icon;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className="flex items-center gap-1 px-2.5 py-2 text-xs font-medium text-gray-600 hover:text-[#dc2626] transition-colors"
                >
                  <Icon className={`w-3.5 h-3.5 ${link.color}`} />
                  {link.label}
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
