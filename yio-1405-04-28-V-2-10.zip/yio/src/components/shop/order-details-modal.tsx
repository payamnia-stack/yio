'use client';

import { useState, useEffect } from 'react';
import { X, Package, Truck, CheckCircle, Clock, XCircle, MapPin, Phone, User, CreditCard, Truck as TruckIcon, ArrowLeft, RotateCcw, FileText, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatPrice, toFa, orderStatuses, getOrderStatusInfo } from '@/lib/shop-data';
import { OrderTimeline } from './order-timeline';
import { useShopStore } from '@/store/shop-store';
import { toast } from 'sonner';

interface OrderItem {
  id: number;
  productTitle: string;
  productImage: string;
  price: number;
  quantity: number;
  color?: string | null;
}

interface OrderDetails {
  id: number;
  orderNumber: string;
  status: string;
  totalAmount: number;
  shippingCost: number;
  finalAmount: number;
  paymentMethod: string;
  paymentStatus: string;
  shippingAddress: string;
  shippingCity?: string | null;
  postalCode?: string | null;
  recipientName: string;
  recipientPhone: string;
  notes?: string | null;
  trackingCode?: string | null;
  createdAt: string;
  items: OrderItem[];
}

interface OrderDetailsModalProps {
  orderId: number | null;
  onClose: () => void;
}

export function OrderDetailsModal({ orderId, onClose }: OrderDetailsModalProps) {
  const [order, setOrder] = useState<OrderDetails | null>(null);
  const [loading, setLoading] = useState(false);
  const [reorderLoading, setReorderLoading] = useState(false);
  const addToCart = useShopStore(s => s.addToCart);
  const setCartOpen = useShopStore(s => s.setCartOpen);

  const handleReorder = async () => {
    if (!order) return;
    setReorderLoading(true);
    try {
      const res = await fetch(`/api/orders/reorder/${order.id}`, { method: 'POST' });
      const data = await res.json();
      if (res.ok && data.success) {
        // اضافه کردن آیتم‌ها به سبد خرید
        data.items.forEach((item: any) => {
          addToCart(item, item.selectedColor);
        });
        toast.success(
          `${toFa(data.addedCount)} محصول به سبد خرید اضافه شد`,
          data.unavailableItems?.length > 0 ? {
            description: `${toFa(data.unavailableItems.length)} محصول ناموجود بود`,
          } : undefined
        );
        setCartOpen(true);
        onClose();
      } else {
        toast.error(data.error || 'خطا در سفارش مجدد');
      }
    } catch {
      toast.error('خطا در ارتباط');
    }
    setReorderLoading(false);
  };

  const handleDownloadInvoice = () => {
    if (!order) return;
    // باز کردن فاکتور در تب جدید
    window.open(`/api/orders/invoice/${order.id}`, '_blank');
  };

  useEffect(() => {
    if (!orderId) {
      setOrder(null);
      return;
    }

    setLoading(true);
    setOrder(null);

    fetch(`/api/user/orders/${orderId}`)
      .then(r => {
        if (!r.ok) throw new Error('خطا در دریافت سفارش');
        return r.json();
      })
      .then(data => {
        setOrder(data.order);
      })
      .catch(err => {
        toast.error(err.message || 'خطا در دریافت اطلاعات سفارش');
        onClose();
      })
      .finally(() => setLoading(false));
  }, [orderId, onClose]);

  const statusInfo = order ? getOrderStatusInfo(order.status) : null;

  const formatDate = (d: string) => {
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(d));
  };

  const getPaymentMethodLabel = (method: string) => {
    const labels: Record<string, string> = {
      cod: 'پرداخت در محل',
      online: 'پرداخت آنلاین',
      wallet: 'کیف پول',
      transfer: 'انتقال بانکی',
    };
    return labels[method] || method;
  };

  if (!orderId) return null;

  return (
    <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-2 md:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl my-4 max-h-[95vh] overflow-y-auto">
        {/* هدر */}
        <div className="sticky top-0 bg-gradient-to-l from-[#dc2626] to-[#991b1b] text-white p-4 flex items-center justify-between gap-2 z-10">
          <h2 className="text-lg font-bold flex items-center gap-2 flex-row-reverse justify-end text-left">
            <Package className="w-5 h-5" />
            <span>جزئیات سفارش</span>
          </h2>
          <button
            onClick={onClose}
            className="w-9 h-9 flex items-center justify-center rounded-full bg-white/20 hover:bg-white/30 transition-all hover:scale-105 shrink-0"
            aria-label="بستن"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        </div>

        {loading ? (
          <div className="p-12 text-center">
            <div className="inline-block w-10 h-10 border-4 border-gray-200 border-t-[#dc2626] rounded-full animate-spin"></div>
            <p className="text-sm text-gray-500 mt-3">در حال دریافت اطلاعات سفارش...</p>
          </div>
        ) : order ? (
          <div className="p-4 md:p-6 space-y-4">
            {/* تایملاین تصویری وضعیت سفارش */}
            <OrderTimeline
              status={order.status}
              createdAt={order.createdAt}
              updatedAt={order.updatedAt}
            />

            {/* وضعیت فعلی سفارش */}
            {statusInfo && (
              <div className={`rounded-xl p-4 ${statusInfo.color}`}>
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{statusInfo.icon}</span>
                  <div className="flex-1">
                    <p className="text-xs opacity-80">وضعیت فعلی سفارش</p>
                    <p className="text-lg font-bold">{statusInfo.label}</p>
                  </div>
                  <code className="bg-white/50 px-3 py-1 rounded-lg font-bold text-sm" dir="ltr">
                    {order.orderNumber}
                  </code>
                </div>
              </div>
            )}

            {/* اطلاعات سفارش */}
            <div className="bg-gray-50 rounded-xl p-4 space-y-2 text-sm">
              <p className="font-bold text-gray-700 mb-2 pb-2 border-b border-gray-200">اطلاعات سفارش</p>
              <div className="flex justify-between">
                <span className="text-gray-600">تاریخ ثبت:</span>
                <span className="fa-num">{formatDate(order.createdAt)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">تعداد اقلام:</span>
                <span className="fa-num">{toFa(order.items.length)} کالا</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">مبلغ کالاها:</span>
                <span className="fa-num">{formatPrice(order.totalAmount)} ت</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">هزینه ارسال:</span>
                <span className="fa-num">
                  {order.shippingCost === 0 ? (
                    <span className="text-green-600 font-bold">رایگان</span>
                  ) : (
                    `${formatPrice(order.shippingCost)} ت`
                  )}
                </span>
              </div>
              <div className="flex justify-between pt-2 border-t border-gray-200">
                <span className="text-gray-600 font-bold">مبلغ قابل پرداخت:</span>
                <span className="font-bold text-[#dc2626] fa-num">{formatPrice(order.finalAmount)} ت</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">روش پرداخت:</span>
                <span className="font-medium">{getPaymentMethodLabel(order.paymentMethod)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">وضعیت پرداخت:</span>
                <span className={
                  order.paymentStatus === 'paid' ? 'text-green-600 font-bold' :
                  order.paymentStatus === 'refunded' ? 'text-blue-600 font-bold' :
                  'text-amber-600 font-bold'
                }>
                  {order.paymentStatus === 'paid' ? '✓ پرداخت شده' :
                   order.paymentStatus === 'refunded' ? 'بازگشت داده شده' :
                   'پرداخت نشده'}
                </span>
              </div>
              {order.trackingCode && (
                <div className="flex justify-between items-center pt-2 border-t border-gray-200">
                  <span className="text-gray-600 flex items-center gap-1">
                    <Truck className="w-3.5 h-3.5" />
                    کد رهگیری پستی:
                  </span>
                  <code className="bg-purple-50 text-purple-800 px-2 py-1 rounded font-bold fa-num" dir="ltr">
                    {order.trackingCode}
                  </code>
                </div>
              )}
            </div>

            {/* اطلاعات گیرنده و آدرس */}
            <div className="bg-gray-50 rounded-xl p-4 space-y-2 text-sm">
              <p className="font-bold text-gray-700 mb-2 pb-2 border-b border-gray-200 flex items-center gap-1">
                <MapPin className="w-4 h-4" />
                اطلاعات ارسال
              </p>
              <div className="flex justify-between">
                <span className="text-gray-600 flex items-center gap-1">
                  <User className="w-3.5 h-3.5" />
                  گیرنده:
                </span>
                <span className="font-medium">{order.recipientName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600 flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5" />
                  موبایل:
                </span>
                <span className="font-medium" dir="ltr">{order.recipientPhone}</span>
              </div>
              <div className="flex justify-between gap-2">
                <span className="text-gray-600 shrink-0">آدرس:</span>
                <span className="font-medium text-left">
                  {order.shippingCity && `${order.shippingCity}، `}
                  {order.shippingAddress}
                </span>
              </div>
              {order.postalCode && (
                <div className="flex justify-between">
                  <span className="text-gray-600">کد پستی:</span>
                  <span className="font-medium fa-num" dir="ltr">{order.postalCode}</span>
                </div>
              )}
            </div>

            {/* اقلام سفارش */}
            <div>
              <h3 className="font-bold mb-2 text-sm flex items-center gap-1">
                <Package className="w-4 h-4" />
                اقلام سفارش ({toFa(order.items.length)} کالا)
              </h3>
              <div className="space-y-2">
                {order.items.map((item) => (
                  <div key={item.id} className="flex gap-3 bg-white border border-gray-100 rounded-lg p-3 hover:shadow-sm transition-shadow">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={item.productImage}
                      alt={item.productTitle}
                      className="w-14 h-14 object-cover rounded-lg shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium line-clamp-2">{item.productTitle}</p>
                      {item.color && (
                        <p className="text-[10px] text-gray-500 mt-0.5">رنگ: {item.color}</p>
                      )}
                      <div className="flex items-center justify-between mt-1">
                        <span className="text-xs text-gray-500 fa-num">
                          {toFa(item.quantity)} عدد × {formatPrice(item.price)} ت
                        </span>
                        <span className="text-sm font-bold text-[#dc2626] fa-num">
                          {formatPrice(item.price * item.quantity)} ت
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* یادداشت سفارش */}
            {order.notes && (
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-sm">
                <p className="font-bold text-amber-800 mb-1 text-xs">یادداشت سفارش:</p>
                <p className="text-amber-700">{order.notes}</p>
              </div>
            )}

            {/* مراحل سفارش (Timeline) */}
            <div>
              <h3 className="font-bold mb-2 text-sm flex items-center gap-1">
                <Clock className="w-4 h-4" />
                مراحل سفارش
              </h3>
              <div className="space-y-1">
                {orderStatuses.map((status, idx) => {
                  const currentIdx = orderStatuses.findIndex(s => s.value === order.status);
                  const isPast = idx <= currentIdx;
                  const isCurrent = idx === currentIdx;
                  const isCancelled = order.status === 'cancelled';

                  // اگر سفارش لغو شده، فقط مراحل تا لغو را نشان بده
                  if (isCancelled && status.value !== 'cancelled' && idx >= currentIdx) {
                    return null;
                  }

                  return (
                    <div
                      key={status.value}
                      className={`flex items-center gap-3 p-2 rounded-lg transition-colors ${
                        isCurrent ? 'bg-red-50 border border-red-100' : ''
                      }`}
                    >
                      <div className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
                        isPast
                          ? (status.value === 'cancelled' ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600')
                          : 'bg-gray-100 text-gray-400'
                      }`}>
                        {isPast ? (
                          status.value === 'cancelled' ? <XCircle className="w-5 h-5" /> : <CheckCircle className="w-5 h-5" />
                        ) : (
                          <Clock className="w-4 h-4" />
                        )}
                      </div>
                      <div className="flex-1">
                        <span className={`text-sm ${isPast ? 'font-bold' : 'text-gray-400'}`}>
                          {status.icon} {status.label}
                        </span>
                        {isCurrent && (
                          <p className="text-[10px] text-[#dc2626] mt-0.5">وضعیت فعلی</p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* دکمه‌ها */}
            <div className="flex gap-2">
              <Button
                onClick={handleReorder}
                disabled={reorderLoading}
                className="flex-1 bg-[#dc2626] hover:bg-[#b91c1c] h-11"
              >
                {reorderLoading ? (
                  <Loader2 className="w-4 h-4 ml-1 animate-spin" />
                ) : (
                  <RotateCcw className="w-4 h-4 ml-1" />
                )}
                {reorderLoading ? 'در حال...' : 'سفارش مجدد'}
              </Button>
              <Button
                onClick={handleDownloadInvoice}
                variant="outline"
                className="h-11 px-4"
                title="دانلود فاکتور"
              >
                <FileText className="w-4 h-4 ml-1" />
                فاکتور
              </Button>
              <Button onClick={onClose} variant="outline" className="h-11 px-6">
                بستن
              </Button>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
