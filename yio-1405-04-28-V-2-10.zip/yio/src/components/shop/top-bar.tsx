'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

interface TopBarSettings {
  enabled: boolean;
  height: number;
  bgColor: string;
  textColor: string;
  mode: 'text' | 'image' | 'mixed';
  textRight: string[];   // آرایه متن‌های سمت راست
  textLeft: string[];    // آرایه متن‌های سمت چپ
  imageUrl: string;
  imageLink: string;
  imageHeight: number;
}

const defaultSettings: TopBarSettings = {
  enabled: true,
  height: 36,
  bgColor: '#dc2626',
  textColor: '#ffffff',
  mode: 'text',
  textRight: ['ارسال به: تهران', 'پشتیبانی ۲۴ ساعته: ۰۲۱-۹۱۰۰۲۰۲۰'],
  textLeft: ['ضمانت اصالت کالا', 'ارسال به سراسر کشور', 'پرداخت در محل'],
  imageUrl: '',
  imageLink: '',
  imageHeight: 28,
};

function parseList(value: string | undefined): string[] {
  if (!value) return [];
  return value
    .split('|')
    .map(s => s.trim())
    .filter(Boolean);
}

export function TopBar() {
  const [settings, setSettings] = useState<TopBarSettings>(defaultSettings);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch('/api/settings', { cache: 'no-store' });
        const data = await res.json();
        const s = data.settings || {};
        if (cancelled) return;
        setSettings({
          enabled: s.topbar_enabled !== 'false',
          height: parseInt(s.topbar_height) || defaultSettings.height,
          bgColor: s.topbar_bg_color || defaultSettings.bgColor,
          textColor: s.topbar_text_color || defaultSettings.textColor,
          mode: (s.topbar_mode as any) || 'text',
          textRight: parseList(s.topbar_text_right),
          textLeft: parseList(s.topbar_text_left),
          imageUrl: s.topbar_image_url || '',
          imageLink: s.topbar_image_link || '',
          imageHeight: parseInt(s.topbar_image_height) || defaultSettings.imageHeight,
        });
      } catch {
        // در صورت خطا، پیش‌فرض‌ها باقی می‌مانند
      } finally {
        if (!cancelled) setLoaded(true);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  if (!loaded || !settings.enabled) return null;

  const hasImage = settings.imageUrl && (settings.mode === 'image' || settings.mode === 'mixed');
  const hasText = settings.mode === 'text' || settings.mode === 'mixed';

  // اگر تصویر فقط نمایش داده می‌شود و لینک دارد، کل نوار لینک شود
  if (settings.mode === 'image' && hasImage && settings.imageLink) {
    return (
      <Link
        href={settings.imageLink}
        className="block w-full"
        style={{ backgroundColor: settings.bgColor, lineHeight: 0 }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={settings.imageUrl}
          alt="نوار اعلان"
          className="w-full"
          style={{ height: `${settings.height}px`, objectFit: 'cover', objectPosition: 'center' }}
        />
      </Link>
    );
  }

  // اگر تصویر فقط و بدون لینک
  if (settings.mode === 'image' && hasImage) {
    return (
      <div style={{ backgroundColor: settings.bgColor, lineHeight: 0 }}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={settings.imageUrl}
          alt="نوار اعلان"
          className="w-full"
          style={{ height: `${settings.height}px`, objectFit: 'cover', objectPosition: 'center' }}
        />
      </div>
    );
  }

  // حالت متن یا mixed
  return (
    <div
      className="text-xs hidden md:block"
      style={{
        backgroundColor: settings.bgColor,
        color: settings.textColor,
        height: `${settings.height}px`,
      }}
    >
      <div
        className="container mx-auto px-4 flex items-center justify-between h-full"
        style={{ minHeight: `${settings.height}px` }}
      >
        {/* سمت راست: متن‌های اطلاع‌رسانی */}
        {hasText && (
          <div className="flex items-center gap-4 flex-1 min-w-0">
            {settings.textRight.map((text, idx) => (
              <span key={idx} className="truncate">
                {text}
              </span>
            ))}
          </div>
        )}

        {/* وسط: تصویر (در حالت mixed) */}
        {hasImage && (
          <div className="flex items-center mx-4 shrink-0">
            {settings.imageLink ? (
              <Link href={settings.imageLink}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={settings.imageUrl}
                  alt="بنر نوار"
                  style={{ height: `${settings.imageHeight}px`, width: 'auto' }}
                  className="max-w-none"
                />
              </Link>
            ) : (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={settings.imageUrl}
                alt="بنر نوار"
                style={{ height: `${settings.imageHeight}px`, width: 'auto' }}
                className="max-w-none"
              />
            )}
          </div>
        )}

        {/* سمت چپ: متن‌های ویژگی‌ها */}
        {hasText && (
          <div className="flex items-center gap-4 shrink-0">
            {settings.textLeft.map((text, idx) => (
              <span key={idx}>{text}</span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
