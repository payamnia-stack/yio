'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

interface QuickLink {
  title: string;
  href: string;
  icon: string;
  color: string;
}

export function CategoryCircles() {
  const [links, setLinks] = useState<QuickLink[]>([]);

  useEffect(() => {
    // ابتدا سعی می‌کنیم لینک‌های سفارشی را از تنظیمات بخوانیم
    fetch('/api/settings?q=quick_links')
      .then(r => r.json())
      .then(data => {
        if (data.value) {
          try {
            const parsed = JSON.parse(data.value);
            if (Array.isArray(parsed) && parsed.length > 0) {
              setLinks(parsed);
              return;
            }
          } catch {}
        }
        // اگر لینک سفارشی نبود، از دسته‌بندی‌ها استفاده کن
        fetch('/api/categories')
          .then(r => r.json())
          .then(catData => {
            const cats = (catData.categories || []).map((c: any) => ({
              title: c.title,
              href: `/category/${encodeURIComponent(c.slug || c.title)}`,
              icon: c.icon || '📦',
              color: c.color || '#dc2626',
            }));
            setLinks(cats);
          })
          .catch(() => {});
      })
      .catch(() => {
        // fallback: از دسته‌بندی‌ها استفاده کن
        fetch('/api/categories')
          .then(r => r.json())
          .then(catData => {
            const cats = (catData.categories || []).map((c: any) => ({
              title: c.title,
              href: `/category/${encodeURIComponent(c.slug || c.title)}`,
              icon: c.icon || '📦',
              color: c.color || '#dc2626',
            }));
            setLinks(cats);
          })
          .catch(() => {});
      });
  }, []);

  if (links.length === 0) return null;

  return (
    <section className="bg-white rounded-xl p-4 md:p-6 shadow-sm">
      <div className="grid grid-cols-4 md:grid-cols-8 gap-2 md:gap-4">
        {links.map((link, idx) => (
          <Link
            key={idx}
            href={link.href}
            className="flex flex-col items-center gap-2 group"
          >
            <div
              className="w-14 h-14 md:w-20 md:h-20 rounded-full flex items-center justify-center text-2xl md:text-3xl transition-transform group-hover:scale-110"
              style={{ backgroundColor: `${link.color}15` }}
            >
              {link.icon}
            </div>
            <span className="text-[10px] md:text-xs font-medium text-center text-gray-700 line-clamp-1">
              {link.title}
            </span>
          </Link>
        ))}
      </div>
    </section>
  );
}
