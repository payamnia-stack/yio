'use client';

import { useState, useEffect } from 'react';
import { Wallet, TrendingUp, TrendingDown, ArrowDownCircle, ArrowUpCircle, RefreshCw } from 'lucide-react';
import { formatPrice, toFa } from '@/lib/shop-data';
import { Loader2 } from 'lucide-react';

interface WalletTransaction {
  id: number;
  type: string;
  amount: number;
  balance: number;
  description: string | null;
  createdAt: string;
}

export function WalletTab() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchWallet = async () => {
    try {
      const res = await fetch('/api/user/wallet');
      if (res.ok) {
        const d = await res.json();
        setData(d);
      }
    } catch {}
    setLoading(false);
  };

  useEffect(() => { fetchWallet(); }, []);

  if (loading) {
    return <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-[#dc2626]" /></div>;
  }

  if (!data) {
    return <div className="bg-white rounded-xl p-8 text-center text-gray-500">خطا در بارگذاری</div>;
  }

  const { wallet, transactions, stats } = data;

  const typeLabels: Record<string, { label: string; icon: any; color: string }> = {
    credit: { label: 'افزایش موجودی', icon: ArrowUpCircle, color: 'text-green-600' },
    debit: { label: 'کاهش موجودی', icon: ArrowDownCircle, color: 'text-red-600' },
    refund: { label: 'بازگشت وجه', icon: ArrowUpCircle, color: 'text-green-600' },
    referral_bonus: { label: 'پاداش دعوت', icon: ArrowUpCircle, color: 'text-purple-600' },
    purchase: { label: 'خرید', icon: ArrowDownCircle, color: 'text-red-600' },
  };

  return (
    <div className="space-y-4">
      {/* کارت موجودی */}
      <div className="bg-gradient-to-l from-[#dc2626] to-[#991b1b] rounded-2xl p-6 text-white shadow-lg">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm opacity-90 mb-1 flex items-center gap-1">
              <Wallet className="w-4 h-4" />
              موجودی کیف پول
            </p>
            <p className="text-3xl font-bold fa-num">{formatPrice(wallet.balance)}</p>
            <p className="text-xs opacity-75 mt-1">تومان</p>
          </div>
          <div className="text-6xl opacity-20">💰</div>
        </div>
      </div>

      {/* آمار */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white rounded-xl p-4 border border-gray-100">
          <div className="flex items-center gap-2 text-green-600 mb-1">
            <TrendingUp className="w-4 h-4" />
            <span className="text-xs">کل واریزها</span>
          </div>
          <p className="text-xl font-bold fa-num text-green-600">{formatPrice(stats.totalCredited)}</p>
          <p className="text-xs text-gray-400">تومان</p>
        </div>
        <div className="bg-white rounded-xl p-4 border border-gray-100">
          <div className="flex items-center gap-2 text-red-600 mb-1">
            <TrendingDown className="w-4 h-4" />
            <span className="text-xs">کل برداشت‌ها</span>
          </div>
          <p className="text-xl font-bold fa-num text-red-600">{formatPrice(stats.totalDebited)}</p>
          <p className="text-xs text-gray-400">تومان</p>
        </div>
      </div>

      {/* تاریخچه تراکنش‌ها */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex items-center justify-between">
          <h3 className="font-bold">تاریخچه تراکنش‌ها</h3>
          <button onClick={fetchWallet} className="text-gray-400 hover:text-[#dc2626]">
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
        {transactions.length === 0 ? (
          <div className="p-8 text-center text-gray-400 text-sm">
            <Wallet className="w-12 h-12 mx-auto mb-2 opacity-20" />
            تراکنشی ندارید
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {transactions.map((tx: WalletTransaction) => {
              const info = typeLabels[tx.type] || typeLabels.debit;
              const Icon = info.icon;
              const isCredit = tx.amount > 0;
              return (
                <div key={tx.id} className="p-4 flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isCredit ? 'bg-green-50' : 'bg-red-50'}`}>
                    <Icon className={`w-5 h-5 ${info.color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{info.label}</p>
                    {tx.description && <p className="text-xs text-gray-500 line-clamp-1">{tx.description}</p>}
                    <p className="text-[10px] text-gray-400 mt-0.5">
                      {new Date(tx.createdAt).toLocaleDateString('fa-IR', {
                        year: 'numeric', month: 'long', day: 'numeric',
                        hour: '2-digit', minute: '2-digit',
                      })}
                    </p>
                  </div>
                  <div className="text-left shrink-0">
                    <p className={`font-bold fa-num ${isCredit ? 'text-green-600' : 'text-red-600'}`}>
                      {isCredit ? '+' : ''}{formatPrice(tx.amount)}
                    </p>
                    <p className="text-[10px] text-gray-400">تومان</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
