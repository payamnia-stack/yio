'use client';

import { useState, useEffect } from 'react';
import { X, HelpCircle, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';

const categoryLabels: Record<string, string> = {
  general: 'عمومی',
  products: 'محصولات',
  shipping: 'ارسال',
  payment: 'پرداخت',
  returns: 'بازگشت کالا',
};

export function FAQModal({ onClose }: { onClose: () => void }) {
  const [grouped, setGrouped] = useState<Record<string, any[]>>({});
  const [loading, setLoading] = useState(true);
  const [openItems, setOpenItems] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetch('/api/faq')
      .then(r => r.json())
      .then(data => {
        setGrouped(data.grouped || {});
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const toggleItem = (id: string) => {
    setOpenItems(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-2 md:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl my-4 max-h-[95vh] overflow-y-auto">
        <div className="sticky top-0 bg-gradient-to-l from-[#dc2626] to-[#991b1b] text-white p-4 flex items-center justify-between z-10">
          <h2 className="text-lg font-bold flex items-center gap-2">
            <HelpCircle className="w-5 h-5" />
            سؤالات متداول
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-white/20">
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="p-4 md:p-6">
          {loading ? (
            <div className="text-center py-8">
              <div className="inline-block w-8 h-8 border-4 border-gray-200 border-t-[#dc2626] rounded-full animate-spin"></div>
            </div>
          ) : Object.keys(grouped).length === 0 ? (
            <p className="text-center text-gray-500 py-8">سؤالی ثبت نشده است</p>
          ) : (
            <div className="space-y-6">
              {Object.entries(grouped).map(([category, faqs]) => (
                <div key={category}>
                  <h3 className="font-bold text-[#dc2626] mb-3 pb-2 border-b-2 border-red-100">
                    {categoryLabels[category] || category}
                  </h3>
                  <div className="space-y-2">
                    {faqs.map(faq => {
                      const isOpen = openItems.has(faq.id);
                      return (
                        <div key={faq.id} className="bg-gray-50 rounded-lg overflow-hidden">
                          <button
                            onClick={() => toggleItem(String(faq.id))}
                            className="w-full p-3 text-right flex items-center justify-between gap-2 hover:bg-gray-100 transition-colors"
                          >
                            <span className="font-medium text-sm">{faq.question}</span>
                            <ChevronDown className={`w-4 h-4 text-gray-400 shrink-0 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                          </button>
                          {isOpen && (
                            <div className="px-3 pb-3 text-sm text-gray-600 leading-6">
                              {faq.answer}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
