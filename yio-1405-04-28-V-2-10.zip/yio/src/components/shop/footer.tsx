'use client';

import { useState, useEffect } from 'react';
import { Mail, Phone, MapPin, Send, Instagram, MessageCircle, HelpCircle, Search, Building2, Flame, Info, CheckCircle } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import Image from 'next/image';
import { OrderTrackingModal } from './order-tracking-modal';
import { toast } from 'sonner';

export function Footer() {
  const [modal, setModal] = useState<'tracking' | null>(null);
  const [footerCategories, setFooterCategories] = useState<any[]>([]);
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterLoading, setNewsletterLoading] = useState(false);
  const [newsletterDone, setNewsletterDone] = useState(false);

  useEffect(() => {
    fetch('/api/categories').then(r => r.json()).then(d => setFooterCategories(d.categories || [])).catch(() => {});
    fetch('/api/settings').then(r => r.json()).then(d => setSettings(d.settings || {})).catch(() => {});
  }, []);

  const handleNewsletter = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim()) {
      toast.error('ایمیل خود را وارد کنید');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newsletterEmail)) {
      toast.error('ایمیل نامعتبر است');
      return;
    }
    setNewsletterLoading(true);
    try {
      const res = await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: newsletterEmail }),
      });
      const data = await res.json();
      if (res.ok) {
        setNewsletterDone(true);
        toast.success('عضویت شما در خبرنامه ثبت شد');
        setNewsletterEmail('');
        setTimeout(() => setNewsletterDone(false), 5000);
      } else {
        toast.error(data.error || 'خطا در ثبت عضویت');
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setNewsletterLoading(false);
    }
  };

  return (
    <footer className="bg-white border-t border-gray-200 mt-8">
      {/* بخش دسترسی سریع */}
      <div className="bg-gradient-to-l from-[#fef3f4] to-white border-b border-gray-100">
        <div className="container mx-auto px-4 py-6">
          <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
            <Link
              href="/special"
              className="bg-white rounded-xl p-4 border border-gray-100 hover:border-[#dc2626] hover:shadow-md transition-all text-right"
            >
              <Flame className="w-6 h-6 text-[#dc2626] mb-2" />
              <p className="font-bold text-sm">فروش ویژه</p>
              <p className="text-xs text-gray-500 mt-1">بهترین تخفیف‌ها</p>
            </Link>
            <button
              onClick={() => setModal('tracking')}
              className="bg-white rounded-xl p-4 border border-gray-100 hover:border-[#dc2626] hover:shadow-md transition-all text-right"
            >
              <Search className="w-6 h-6 text-[#dc2626] mb-2" />
              <p className="font-bold text-sm">پیگیری سفارش</p>
              <p className="text-xs text-gray-500 mt-1">بررسی وضعیت سفارش</p>
            </button>
            <Link
              href="/wholesale"
              className="bg-white rounded-xl p-4 border border-gray-100 hover:border-[#dc2626] hover:shadow-md transition-all text-right"
            >
              <Building2 className="w-6 h-6 text-[#dc2626] mb-2" />
              <p className="font-bold text-sm">سفارش عمده</p>
              <p className="text-xs text-gray-500 mt-1">برای همکاران و شرکت‌ها</p>
            </Link>
            <Link
              href="/faq"
              className="bg-white rounded-xl p-4 border border-gray-100 hover:border-[#dc2626] hover:shadow-md transition-all text-right"
            >
              <HelpCircle className="w-6 h-6 text-[#dc2626] mb-2" />
              <p className="font-bold text-sm">سؤالات متداول</p>
              <p className="text-xs text-gray-500 mt-1">پاسخ سؤالات شما</p>
            </Link>
            <Link
              href="/contact"
              className="bg-white rounded-xl p-4 border border-gray-100 hover:border-[#dc2626] hover:shadow-md transition-all text-right"
            >
              <Mail className="w-6 h-6 text-[#dc2626] mb-2" />
              <p className="font-bold text-sm">تماس با ما</p>
              <p className="text-xs text-gray-500 mt-1">ارتباط با پشتیبانی</p>
            </Link>
            <Link
              href="/about"
              className="bg-white rounded-xl p-4 border border-gray-100 hover:border-[#dc2626] hover:shadow-md transition-all text-right"
            >
              <Info className="w-6 h-6 text-[#dc2626] mb-2" />
              <p className="font-bold text-sm">درباره ما</p>
              <p className="text-xs text-gray-500 mt-1">داستان YIO</p>
            </Link>
          </div>
        </div>
      </div>

      {/* بخش خبرنامه */}
      <div className="bg-gradient-to-l from-[#fef3f4] to-white border-b border-gray-100">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-center md:text-right">
              <h3 className="text-lg font-bold mb-1">با عضویت در خبرنامه از تخفیف‌ها باخبر شوید</h3>
              <p className="text-sm text-gray-600">جدیدترین محصولات چوبی و پیشنهادهای ویژه را دریافت کنید</p>
            </div>
            <form onSubmit={handleNewsletter} className="flex w-full md:w-auto gap-2">
              {newsletterDone ? (
                <div className="flex items-center gap-2 text-green-600 bg-green-50 px-4 py-2.5 rounded-lg">
                  <CheckCircle className="w-5 h-5" />
                  <span className="font-medium">عضویت ثبت شد!</span>
                </div>
              ) : (
                <>
                  <Input
                    type="email"
                    value={newsletterEmail}
                    onChange={e => setNewsletterEmail(e.target.value)}
                    placeholder="ایمیل خود را وارد کنید"
                    className="md:w-72 bg-white"
                    disabled={newsletterLoading}
                    required
                  />
                  <Button type="submit" disabled={newsletterLoading} className="bg-[#dc2626] hover:bg-[#b91c1c]">
                    {newsletterLoading ? (
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <Send className="w-4 h-4 ml-1" />
                    )}
                    عضویت
                  </Button>
                </>
              )}
            </form>
          </div>
        </div>
      </div>

      {/* بخش اصلی فوتر */}
      <div className="container mx-auto px-4 py-10">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
          {/* درباره YIO */}
          <div className="col-span-2 lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="relative w-12 h-12">
                <Image
                  src="/yio-logo.png"
                  alt="YIO"
                  fill
                  sizes="48px"
                  className="object-contain rounded-lg"
                />
              </div>
              <div>
                <h3 className="font-bold text-lg text-[#dc2626]">YIO</h3>
                <p className="text-xs text-gray-500">محصولات چوبی دست‌ساز</p>
              </div>
            </div>
            <p className="text-sm text-gray-600 leading-6 mb-4">
              YIO برند تخصصی محصولات چوبی دست‌ساز. ما با بهره‌گیری از چوب‌های طبیعی و مرغوب، اسباب‌بازی، ظروف آشپزخانه، مبلمان و دکوراسیون چوبی با کیفیت و ایمن تولید می‌کنیم.
            </p>
            <div className="space-y-2 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#dc2626]" />
                <span className="fa-num" dir="ltr">{settings.contact_phone || '۰۲۱-۹۱۰۰۲۰۲۰'}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#dc2626]" />
                <span dir="ltr">{settings.contact_email || 'info@yio-shop.ir'}</span>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-[#dc2626] mt-0.5" />
                <span>{settings.contact_address || 'تهران، خیابان ولیعصر، کارگاه تولید چوب YIO'}</span>
              </div>
            </div>
            <div className="flex gap-2 mt-4">
              {settings.social_instagram && (
                <a href={settings.social_instagram} target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-[#dc2626] hover:text-white transition-colors" aria-label="اینستاگرام">
                  <Instagram className="w-5 h-5" />
                </a>
              )}
              {settings.social_telegram && (
                <a href={settings.social_telegram} target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-[#dc2626] hover:text-white transition-colors" aria-label="تلگرام">
                  <MessageCircle className="w-5 h-5" />
                </a>
              )}
              {settings.social_whatsapp && (
                <a href={settings.social_whatsapp} target="_blank" rel="noopener noreferrer" className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-[#dc2626] hover:text-white transition-colors" aria-label="واتساپ">
                  <Phone className="w-5 h-5" />
                </a>
              )}
              {!settings.social_instagram && !settings.social_telegram && !settings.social_whatsapp && (
                <>
                  <span className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-400">
                    <Instagram className="w-5 h-5" />
                  </span>
                  <span className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center text-gray-400">
                    <MessageCircle className="w-5 h-5" />
                  </span>
                </>
              )}
            </div>
          </div>

          {/* خدمات مشتریان */}
          <div>
            <h4 className="font-bold mb-4 text-gray-800">خدمات مشتریان</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><Link href="/contact" className="hover:text-[#dc2626]">تماس با ما</Link></li>
              <li><Link href="/faq" className="hover:text-[#dc2626]">سؤالات متداول</Link></li>
              <li><Link href="/about" className="hover:text-[#dc2626]">درباره ما</Link></li>
              <li>شرایط بازگشت کالا</li>
              <li>گارانتی محصولات</li>
            </ul>
          </div>

          {/* محصولات - داینامیک از دیتابیس */}
          <div>
            <h4 className="font-bold mb-4 text-gray-800">دسته‌بندی محصولات</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              {footerCategories.slice(0, 6).map(cat => (
                <li key={cat.id}>
                  <Link href={`/category/${encodeURIComponent(cat.title)}`} className="hover:text-[#dc2626]">
                    {cat.icon} {cat.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* همکاری با ما */}
          <div>
            <h4 className="font-bold mb-4 text-gray-800">همکاری با ما</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><Link href="/wholesale" className="hover:text-[#dc2626] font-medium">🏢 سفارش عمده</Link></li>
              <li>فروش در YIO</li>
              <li>بازاریابی</li>
              <li>نمایندگی</li>
              <li>همکاری در تولید</li>
            </ul>
          </div>

          {/* نمادهای اعتماد */}
          <div>
            <h4 className="font-bold mb-4 text-gray-800">نمادهای اعتماد</h4>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 flex items-center justify-center text-xs font-medium text-gray-600 h-16">
                نماد اعتماد الکترونیک
              </div>
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 flex items-center justify-center text-xs font-medium text-gray-600 h-16">
                ساماندهی
              </div>
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 flex items-center justify-center text-xs font-medium text-gray-600 h-16">
                اینماد
              </div>
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 flex items-center justify-center text-xs font-medium text-gray-600 h-16">
                عضو اتحادیه
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* کپی‌رایت */}
      <div className="border-t border-gray-100">
        <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-gray-500">
          <p>کلیه حقوق این سایت متعلق به YIO می‌باشد © ۱۴۰۳</p>
          <div className="flex items-center gap-4">
            <span>ساخته شده با ❤️ برای محصولات چوبی طبیعی</span>
          </div>
        </div>
      </div>

      {/* مودال‌ها - فقط پیگیری سفارش به‌صورت مودال باقی می‌ماند */}
      {modal === 'tracking' && <OrderTrackingModal onClose={() => setModal(null)} />}
    </footer>
  );
}
