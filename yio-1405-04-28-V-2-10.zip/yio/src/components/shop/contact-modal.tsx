'use client';

import { useState } from 'react';
import { X, Send, Phone, Mail, MapPin, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';

export function ContactModal({ onClose }: { onClose: () => void }) {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    subject: '',
    message: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (formData.name.trim().length < 3) {
      toast.error('نام را کامل وارد کنید');
      return;
    }
    if (!/^09\d{9}$/.test(formData.phone)) {
      toast.error('شماره موبایل نامعتبر است');
      return;
    }
    if (formData.subject.trim().length < 3) {
      toast.error('موضوع را وارد کنید');
      return;
    }
    if (formData.message.trim().length < 10) {
      toast.error('پیام شما باید حداقل ۱۰ کاراکتر باشد');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await res.json();

      if (res.ok) {
        setSuccess(true);
        toast.success('پیام شما ارسال شد');
      } else {
        toast.error(data.error || 'خطا در ارسال');
      }
    } catch {
      toast.error('خطا در ارتباط با سرور');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8 text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Send className="w-10 h-10 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold mb-2">پیام ارسال شد!</h2>
          <p className="text-gray-600 mb-6">
            پیام شما با موفقیت ارسال شد. تیم پشتیبانی ما در اولین فرصت پاسخ می‌دهد.
          </p>
          <Button onClick={onClose} className="w-full bg-[#dc2626] hover:bg-[#b91c1c] h-12">
            بستن
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-2 md:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl my-4 max-h-[95vh] overflow-y-auto">
        <div className="sticky top-0 bg-gradient-to-l from-[#dc2626] to-[#991b1b] text-white p-4 flex items-center justify-between z-10">
          <h2 className="text-lg font-bold flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            تماس با ما
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-white/20">
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="p-4 md:p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* اطلاعات تماس */}
          <div className="md:col-span-1 space-y-3">
            <div className="bg-gray-50 rounded-lg p-3">
              <div className="flex items-center gap-2 mb-1">
                <Phone className="w-4 h-4 text-[#dc2626]" />
                <span className="text-xs text-gray-600">تلفن پشتیبانی</span>
              </div>
              <p className="font-bold text-sm fa-num" dir="ltr">۰۲۱-۹۱۰۰۲۰۲۰</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-3">
              <div className="flex items-center gap-2 mb-1">
                <Mail className="w-4 h-4 text-[#dc2626]" />
                <span className="text-xs text-gray-600">ایمیل</span>
              </div>
              <p className="font-bold text-sm" dir="ltr">info@yio-shop.ir</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-3">
              <div className="flex items-center gap-2 mb-1">
                <MapPin className="w-4 h-4 text-[#dc2626]" />
                <span className="text-xs text-gray-600">آدرس</span>
              </div>
              <p className="text-xs leading-5">تهران، خیابان ولیعصر، کارگاه تولید چوب YIO</p>
            </div>
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
              <p className="text-xs text-amber-800">
                <strong>ساعات کاری:</strong><br />
                شنبه تا چهارشنبه: ۹ تا ۱۸<br />
                پنجشنبه: ۹ تا ۱۳<br />
                جمعه: تعطیل
              </p>
            </div>
          </div>

          {/* فرم */}
          <form onSubmit={handleSubmit} className="md:col-span-2 space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label htmlFor="name">نام و نام خانوادگی *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="phone">شماره موبایل *</Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  dir="ltr"
                  required
                />
              </div>
            </div>

            <div className="space-y-1">
              <Label htmlFor="email">ایمیل (اختیاری)</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
                dir="ltr"
              />
            </div>

            <div className="space-y-1">
              <Label htmlFor="subject">موضوع *</Label>
              <Input
                id="subject"
                value={formData.subject}
                onChange={e => setFormData({ ...formData, subject: e.target.value })}
                placeholder="مثلا: سؤال درباره محصول"
                required
              />
            </div>

            <div className="space-y-1">
              <Label htmlFor="message">پیام شما *</Label>
              <Textarea
                id="message"
                value={formData.message}
                onChange={e => setFormData({ ...formData, message: e.target.value })}
                placeholder="پیام خود را وارد کنید..."
                rows={4}
                required
              />
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-[#dc2626] hover:bg-[#b91c1c] h-12"
            >
              <Send className="w-4 h-4 ml-2" />
              {loading ? 'در حال ارسال...' : 'ارسال پیام'}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
