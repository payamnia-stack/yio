'use client';

import { useState, useEffect, useRef } from 'react';
import { Search, ShoppingCart, User, Heart, Menu, MapPin, LogOut, X, TrendingUp } from 'lucide-react';
import { useShopStore } from '@/store/shop-store';
import { toFa } from '@/lib/shop-data';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import Image from 'next/image';
import Link from 'next/link';
import { CategoryMenu } from './category-menu';
import { WishlistDrawer } from './wishlist-drawer';
import { TopBar } from './top-bar';
import { NotificationBell } from './notification-bell';

interface Product {
  id: number;
  title: string;
  brand: string;
  price: number;
  discountPrice?: number | null;
  image: string;
}

// پیشنهادات جستجوی پیش‌فرض (در حالت بدون ورودی)
const DEFAULT_SUGGESTIONS = [
  'اسباب‌بازی چوبی',
  'ظروف آشپزخانه',
  'مبلمان چوبی',
  'تخته برش',
  'صندلی کودک',
  'جعبه هدیه',
];

export function Header() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [mobileCategories, setMobileCategories] = useState<any[]>([]);
  const [user, setUser] = useState<{ name: string; phone: string } | null>(null);
  const [searchFocused, setSearchFocused] = useState(false);
  const cartCount = useShopStore(s => s.cartCount());
  const favorites = useShopStore(s => s.favorites);
  const setCartOpen = useShopStore(s => s.setCartOpen);
  const setWishlistOpen = useShopStore(s => s.setWishlistOpen);
  const syncFavoritesFromServer = useShopStore(s => s.syncFavoritesFromServer);
  const setAuthed = useShopStore(s => s.setAuthed);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // بارگذاری دسته‌بندی‌ها برای منوی موبایل
  useEffect(() => {
    fetch('/api/categories').then(r => r.json()).then(d => setMobileCategories(d.categories || [])).catch(() => {});
  }, []);

  // بررسی وضعیت ورود کاربر
  useEffect(() => {
    fetch('/api/auth/check')
      .then(r => r.json())
      .then(d => {
        if (d.authenticated && d.user) {
          setUser({ name: d.user.name || d.user.phone, phone: d.user.phone });
          setAuthed(true);
          syncFavoritesFromServer();
        } else {
          setUser(null);
          setAuthed(false);
        }
      })
      .catch(() => setUser(null));
  }, [syncFavoritesFromServer, setAuthed]);

  // جستجوی محصولات از API
  useEffect(() => {
    const timer = setTimeout(async () => {
      if (searchQuery.trim().length > 1) {
        try {
          const res = await fetch(`/api/shop/products?search=${encodeURIComponent(searchQuery)}&pageSize=8`);
          if (res.ok) {
            const data = await res.json();
            setSearchResults(data.products);
          }
        } catch (e) {
          setSearchResults([]);
        }
      } else {
        setSearchResults([]);
      }
    }, 250);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // بستن dropdown جستجو با کلیک بیرون
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setSearchFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const showSuggestions = searchFocused && searchQuery.trim().length <= 1;
  const showResults = searchFocused && searchResults.length > 0 && searchQuery.trim().length > 1;

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      {/* نوار بالای سایت (قابل تنظیم از پنل ادمین) */}
      <TopBar />

      {/* نوار اصلی هدر */}
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center gap-4">
          {/* منوی موبایل */}
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden">
                <Menu className="w-6 h-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] overflow-y-auto">
              <SheetHeader>
                <SheetTitle>منوی اصلی</SheetTitle>
              </SheetHeader>
              <div className="mt-6 space-y-2">
                <Link href="/" className="block px-4 py-3 hover:bg-gray-100 rounded-lg font-medium">
                  صفحه اصلی
                </Link>
                {mobileCategories.map(cat => (
                  <Link
                    key={cat.id}
                    href={`/category/${encodeURIComponent(cat.slug || cat.title)}`}
                    className="flex items-center gap-3 px-4 py-3 hover:bg-gray-100 rounded-lg"
                  >
                    <span className="text-xl">{cat.icon}</span>
                    <span className="text-sm">{cat.title}</span>
                  </Link>
                ))}
              </div>
            </SheetContent>
          </Sheet>

          {/* لوگو YIO */}
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <div className="relative w-12 h-12 md:w-14 md:h-14">
              <Image
                src="/yio-logo.png"
                alt="YIO"
                fill
                sizes="56px"
                className="object-contain rounded-lg"
                priority
              />
            </div>
            <div className="hidden sm:block">
              <h1 className="text-xl font-bold text-[#dc2626]">YIO</h1>
              <p className="text-[10px] text-gray-500">محصولات چوبی دست‌ساز</p>
            </div>
          </Link>

          {/* جستجو — استایل دیجی‌کالا با گوشه‌های کمتر گرد */}
          <div
            ref={searchContainerRef}
            className="flex-1 relative hidden md:block"
          >
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
              <input
                type="text"
                placeholder="جستجوی محصول، برند یا دسته‌بندی..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                onFocus={() => setSearchFocused(true)}
                className="w-full h-11 pr-11 pl-4 bg-gray-100 border border-transparent focus:border-[#dc2626] focus:bg-white rounded-lg text-sm outline-none transition-all placeholder:text-gray-400"
              />
              {searchQuery && (
                <button
                  onClick={() => { setSearchQuery(''); setSearchResults([]); }}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-700"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Dropdown جستجو */}
            {(showSuggestions || showResults) && (
              <div className="absolute top-12 left-0 right-0 bg-white border border-gray-200 rounded-lg shadow-xl max-h-[28rem] overflow-y-auto z-50">
                {/* پیشنهادات پیش‌فرض (وقتی متن خالی است) */}
                {showSuggestions && (
                  <div className="p-3">
                    <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-2 px-2">
                      <TrendingUp className="w-3.5 h-3.5" />
                      جستجوهای پرطرفدار
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {DEFAULT_SUGGESTIONS.map(suggestion => (
                        <button
                          key={suggestion}
                          onClick={() => {
                            setSearchQuery(suggestion);
                          }}
                          className="text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-1.5 rounded-full transition-colors"
                        >
                          {suggestion}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* نتایج جستجو */}
                {showResults && (
                  <div>
                    <div className="px-3 py-2 text-xs text-gray-500 border-b border-gray-100 bg-gray-50">
                      {toFa(searchResults.length)} نتیجه برای «{searchQuery}»
                    </div>
                    {searchResults.map(product => (
                      <Link
                        key={product.id}
                        href={`/products/${product.id}`}
                        onClick={() => {
                          setSearchQuery('');
                          setSearchResults([]);
                          setSearchFocused(false);
                        }}
                        className="flex items-center gap-3 p-3 hover:bg-gray-50 border-b border-gray-100 cursor-pointer transition-colors"
                      >
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={product.image}
                          alt={product.title}
                          className="w-12 h-12 object-cover rounded-lg shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium line-clamp-1">{product.title}</p>
                          <p className="text-xs text-gray-500">{product.brand}</p>
                        </div>
                        <span className="text-sm font-bold text-[#dc2626] shrink-0 fa-num">
                          {toFa(product.discountPrice ?? product.price)}
                          <span className="text-xs mr-1">ت</span>
                        </span>
                      </Link>
                    ))}
                    <Link
                      href={`/search?q=${encodeURIComponent(searchQuery)}`}
                      onClick={() => {
                        setSearchFocused(false);
                      }}
                      className="block p-3 text-center text-sm text-[#dc2626] hover:bg-red-50 font-medium"
                    >
                      مشاهده همه نتایج جستجو
                    </Link>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* آیکون‌های هدر */}
          <div className="flex items-center gap-1 md:gap-2 shrink-0">
            {/* حساب کاربری */}
            {user ? (
              <div className="hidden md:flex items-center gap-1">
                <Link href="/profile" className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-100 text-sm">
                  <div className="w-8 h-8 bg-[#dc2626] text-white rounded-full flex items-center justify-center text-xs font-bold">
                    {user.name.charAt(0)}
                  </div>
                  <span>سلام، {user.name}</span>
                </Link>
                <button
                  onClick={async () => {
                    await fetch('/api/auth/logout', { method: 'POST' });
                    window.location.href = '/';
                  }}
                  className="p-2 rounded-lg hover:bg-red-50 text-gray-500 hover:text-red-600 transition-colors"
                  title="خروج"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <Link href="/auth" className="hidden md:flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-100 text-sm">
                <User className="w-5 h-5" />
                <span>ورود | ثبت‌نام</span>
              </Link>
            )}

            {/* زنگوله اعلان‌ها (فقط برای کاربران وارد شده) */}
            {user && <NotificationBell />}

            {/* علاقه‌مندی‌ها */}
            <Button
              variant="ghost"
              size="icon"
              className="relative"
              onClick={() => setWishlistOpen(true)}
              title="علاقه‌مندی‌ها"
            >
              <Heart className="w-5 h-5" />
              {favorites.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#dc2626] text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center fa-num">
                  {toFa(favorites.length)}
                </span>
              )}
            </Button>

            {/* سبد خرید */}
            <Button
              variant="ghost"
              size="icon"
              className="relative"
              onClick={() => setCartOpen(true)}
            >
              <ShoppingCart className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#dc2626] text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center fa-num">
                  {toFa(cartCount)}
                </span>
              )}
            </Button>
          </div>
        </div>

        {/* جستجو موبایل */}
        <div className="md:hidden mt-3">
          <div className="relative">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="جستجوی محصول..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full h-10 pr-10 pl-4 bg-gray-100 border border-transparent focus:border-[#dc2626] focus:bg-white rounded-lg text-sm outline-none placeholder:text-gray-400"
            />
          </div>
        </div>
      </div>

      {/* منوی دسته‌بندی */}
      <CategoryMenu />

      {/* Drawer علاقه‌مندی‌ها */}
      <WishlistDrawer />
    </header>
  );
}
