'use client';

import { useState, useEffect } from 'react';
import {
  Clock, Trash2, Loader2, Star, Edit2, Trash, Smartphone, Monitor, Tablet,
  Camera, Upload, X, Image as ImageIcon, RefreshCw, Package,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { formatPrice, toFa } from '@/lib/shop-data';
import { toast } from 'sonner';
import Link from 'next/link';

// ===== Recently Viewed Tab =====
export function RecentlyViewedTab() {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchRecent = async () => {
    try {
      const res = await fetch('/api/user/recently-viewed');
      if (res.ok) {
        const data = await res.json();
        setProducts(data.recentlyViewed || []);
      }
    } catch {}
    setLoading(false);
  };

  useEffect(() => { fetchRecent(); }, []);

  const handleClear = async () => {
    if (!confirm('بازدیدهای اخیر پاک شود؟')) return;
    await fetch('/api/user/recently-viewed', { method: 'DELETE' });
    setProducts([]);
    toast.success('پاک شد');
  };

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-[#dc2626]" /></div>;

  return (
    <div className="space-y-3">
      {products.length === 0 ? (
        <div className="bg-white rounded-xl p-8 text-center text-gray-500">
          <Clock className="w-12 h-12 mx-auto mb-2 text-gray-200" />
          محصولی بازدید نکرده‌اید
          <Link href="/" className="block mt-3 text-[#dc2626] hover:underline">شروع خرید</Link>
        </div>
      ) : (
        <>
          <div className="flex justify-end">
            <Button onClick={handleClear} variant="outline" size="sm" className="text-red-600">
              <Trash2 className="w-4 h-4 ml-1" />
              پاک کردن
            </Button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {products.map((p: any) => (
              <Link key={p.id} href={`/products/${p.id}`} className="bg-white rounded-lg border border-gray-100 overflow-hidden hover:shadow-md transition-shadow">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={p.image} alt={p.title} className="w-full aspect-square object-cover" />
                <div className="p-2">
                  <p className="text-xs line-clamp-2 mb-1">{p.title}</p>
                  <p className="font-bold text-[#dc2626] fa-num text-sm">
                    {formatPrice(p.discountPrice || p.price)} ت
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

// ===== Reviews Management Tab =====
export function ReviewsTab() {
  const [reviews, setReviews] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editForm, setEditForm] = useState({ rating: 5, comment: '' });

  const fetchReviews = async () => {
    try {
      const res = await fetch('/api/user/reviews');
      if (res.ok) {
        const data = await res.json();
        setReviews(data.reviews || []);
      }
    } catch {}
    setLoading(false);
  };

  useEffect(() => { fetchReviews(); }, []);

  const handleEdit = (review: any) => {
    setEditingId(review.id);
    setEditForm({ rating: review.rating, comment: review.comment || '' });
  };

  const handleSave = async (id: number) => {
    const res = await fetch('/api/user/reviews', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, ...editForm }),
    });
    if (res.ok) {
      toast.success('نظر ویرایش شد');
      setEditingId(null);
      fetchReviews();
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('نظر حذف شود؟')) return;
    await fetch(`/api/user/reviews?id=${id}`, { method: 'DELETE' });
    setReviews(reviews.filter(r => r.id !== id));
    toast.success('حذف شد');
  };

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-[#dc2626]" /></div>;

  return (
    <div className="space-y-3">
      {reviews.length === 0 ? (
        <div className="bg-white rounded-xl p-8 text-center text-gray-500">
          <Star className="w-12 h-12 mx-auto mb-2 text-gray-200" />
          نظری ثبت نکرده‌اید
        </div>
      ) : (
        reviews.map((review: any) => (
          <div key={review.id} className="bg-white rounded-xl p-4 border border-gray-100">
            <div className="flex items-start gap-3">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={review.product.image} alt={review.product.title} className="w-14 h-14 rounded-lg object-cover" />
              <div className="flex-1 min-w-0">
                <Link href={`/products/${review.id}`} className="text-sm font-medium hover:text-[#dc2626] line-clamp-1">
                  {review.product.title}
                </Link>
                <div className="flex items-center gap-1 mt-1">
                  {[1, 2, 3, 4, 5].map(i => (
                    <Star key={i} className={`w-3.5 h-3.5 ${i <= review.rating ? 'fill-amber-400 text-amber-400' : 'text-gray-200'}`} />
                  ))}
                  <span className="text-xs text-gray-400 mr-1">{toFa(review.rating)} از ۵</span>
                </div>
                <p className="text-xs text-gray-400 mt-0.5">
                  {new Date(review.createdAt).toLocaleDateString('fa-IR')}
                </p>
              </div>
              {editingId !== review.id && (
                <div className="flex gap-1 shrink-0">
                  <button onClick={() => handleEdit(review)} className="p-1.5 hover:bg-gray-100 rounded text-gray-500">
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => handleDelete(review.id)} className="p-1.5 hover:bg-red-50 rounded text-red-500">
                    <Trash className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            {editingId === review.id ? (
              <div className="mt-3 pt-3 border-t border-gray-100 space-y-2">
                <div className="flex items-center gap-2">
                  <Label className="text-xs">امتیاز:</Label>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map(i => (
                      <button
                        key={i}
                        onClick={() => setEditForm({ ...editForm, rating: i })}
                        type="button"
                      >
                        <Star className={`w-5 h-5 ${i <= editForm.rating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`} />
                      </button>
                    ))}
                  </div>
                </div>
                <Textarea
                  value={editForm.comment}
                  onChange={e => setEditForm({ ...editForm, comment: e.target.value })}
                  rows={3}
                  placeholder="نظر خود را بنویسید..."
                />
                <div className="flex gap-2">
                  <Button onClick={() => handleSave(review.id)} size="sm" className="bg-[#dc2626] hover:bg-[#b91c1c]">
                    ذخیره
                  </Button>
                  <Button onClick={() => setEditingId(null)} size="sm" variant="outline">
                    انصراف
                  </Button>
                </div>
              </div>
            ) : (
              review.comment && (
                <p className="text-sm text-gray-600 mt-2 pt-2 border-t border-gray-50">{review.comment}</p>
              )
            )}
          </div>
        ))
      )}
    </div>
  );
}

// ===== Active Sessions Tab =====
export function SessionsTab() {
  const [sessions, setSessions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchSessions = async () => {
    try {
      const res = await fetch('/api/user/sessions');
      if (res.ok) {
        const data = await res.json();
        setSessions(data.sessions || []);
      }
    } catch {}
    setLoading(false);
  };

  useEffect(() => { fetchSessions(); }, []);

  const handleRevoke = async (id: number) => {
    if (!confirm('از این نشست خارج شوید؟')) return;
    const res = await fetch(`/api/user/sessions?id=${id}`, { method: 'DELETE' });
    if (res.ok) {
      toast.success('خروج انجام شد');
      fetchSessions();
    } else {
      const data = await res.json();
      toast.error(data.error || 'خطا');
    }
  };

  const handleRevokeAll = async () => {
    if (!confirm('از همه دستگاه‌های دیگر خارج شوید؟')) return;
    const res = await fetch('/api/user/sessions?all=true', { method: 'DELETE' });
    if (res.ok) {
      toast.success('از همه نشست‌های دیگر خارج شدید');
      fetchSessions();
    }
  };

  const getDeviceIcon = (deviceType: string) => {
    if (deviceType === 'mobile') return Smartphone;
    if (deviceType === 'tablet') return Tablet;
    return Monitor;
  };

  const formatDevice = (ua: string) => {
    if (!ua) return 'دستگاه ناشناخته';
    if (/chrome/i.test(ua)) return 'Chrome';
    if (/firefox/i.test(ua)) return 'Firefox';
    if (/safari/i.test(ua)) return 'Safari';
    if (/edge/i.test(ua)) return 'Edge';
    return 'مرورگر ناشناخته';
  };

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-[#dc2626]" /></div>;

  return (
    <div className="space-y-3">
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-center justify-between">
        <p className="text-sm text-blue-800">
          🔐 {toFa(sessions.length)} دستگاه به حساب شما متصل است
        </p>
        {sessions.filter(s => !s.isCurrent).length > 0 && (
          <Button onClick={handleRevokeAll} size="sm" variant="outline" className="text-red-600 border-red-200 hover:bg-red-50">
            خروج از همه
          </Button>
        )}
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="divide-y divide-gray-50">
          {sessions.map((session: any) => {
            const DeviceIcon = getDeviceIcon(session.deviceType || 'desktop');
            return (
              <div key={session.id} className="p-4 flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  session.isCurrent ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-600'
                }`}>
                  <DeviceIcon className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-medium">{formatDevice(session.userAgent || '')}</p>
                    {session.isCurrent && (
                      <span className="bg-green-50 text-green-600 text-[10px] px-2 py-0.5 rounded-full">
                        این دستگاه
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-xs text-gray-400 mt-0.5">
                    {session.ipAddress && <span dir="ltr">{session.ipAddress}</span>}
                    <span>آخرین فعالیت: {new Date(session.lastActivity).toLocaleDateString('fa-IR')}</span>
                  </div>
                </div>
                {!session.isCurrent && (
                  <button
                    onClick={() => handleRevoke(session.id)}
                    className="text-red-500 hover:bg-red-50 p-2 rounded-lg"
                    title="خروج"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ===== Customer Photos Tab =====
export function CustomerPhotosTab() {
  const [photos, setPhotos] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchPhotos = async () => {
    try {
      const res = await fetch('/api/user/customer-photos');
      if (res.ok) {
        const data = await res.json();
        setPhotos(data.photos || []);
      }
    } catch {}
    setLoading(false);
  };

  useEffect(() => { fetchPhotos(); }, []);

  const handleDelete = async (id: number) => {
    if (!confirm('عکس حذف شود؟')) return;
    await fetch(`/api/user/customer-photos?id=${id}`, { method: 'DELETE' });
    setPhotos(photos.filter(p => p.id !== id));
    toast.success('حذف شد');
  };

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-[#dc2626]" /></div>;

  return (
    <div className="space-y-3">
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-800">
        📸 عکس‌های شما پس از تأیید مدیر در صفحه محصول نمایش داده می‌شوند.
        برای آپلود عکس، به صفحه محصولی که خریده‌اید بروید و روی «افزودن عکس» کلیک کنید.
      </div>

      {photos.length === 0 ? (
        <div className="bg-white rounded-xl p-8 text-center text-gray-500">
          <Camera className="w-12 h-12 mx-auto mb-2 text-gray-200" />
          عکسی آپلود نکرده‌اید
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {photos.map((photo: any) => (
            <div key={photo.id} className="bg-white rounded-xl border border-gray-100 overflow-hidden group relative">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={photo.imageUrl} alt={photo.product?.title} className="w-full aspect-square object-cover" />
              <div className="p-2">
                <p className="text-xs font-medium line-clamp-1">{photo.product?.title}</p>
                {photo.caption && <p className="text-[10px] text-gray-500 mt-0.5 line-clamp-1">{photo.caption}</p>}
                <div className="flex items-center justify-between mt-1">
                  <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                    photo.isApproved ? 'bg-green-50 text-green-600' : 'bg-amber-50 text-amber-600'
                  }`}>
                    {photo.isApproved ? '✓ تأیید شده' : '⏳ در انتظار'}
                  </span>
                  <button
                    onClick={() => handleDelete(photo.id)}
                    className="text-red-400 hover:bg-red-50 p-1 rounded"
                  >
                    <Trash className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ===== Return Requests Tab =====
export function ReturnsTab() {
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchRequests = async () => {
    try {
      const res = await fetch('/api/user/return-requests');
      if (res.ok) {
        const data = await res.json();
        setRequests(data.requests || []);
      }
    } catch {}
    setLoading(false);
  };

  useEffect(() => { fetchRequests(); }, []);

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-[#dc2626]" /></div>;

  const statusLabels: Record<string, { label: string; color: string }> = {
    pending: { label: 'در انتظار بررسی', color: 'bg-amber-50 text-amber-600' },
    approved: { label: 'تأیید شده', color: 'bg-blue-50 text-blue-600' },
    rejected: { label: 'رد شده', color: 'bg-red-50 text-red-600' },
    completed: { label: 'تکمیل شده', color: 'bg-green-50 text-green-600' },
  };

  const reasonLabels: Record<string, string> = {
    defective: 'کالا معیوب است',
    wrong_item: 'کالای اشتباه ارسال شده',
    not_as_described: 'مطابق با توضیحات نیست',
    changed_mind: 'منظرم تغییر کرد',
    other: 'سایر',
  };

  return (
    <div className="space-y-3">
      {requests.length === 0 ? (
        <div className="bg-white rounded-xl p-8 text-center text-gray-500">
          <Package className="w-12 h-12 mx-auto mb-2 text-gray-200" />
          درخواست مرجوعی ندارید
          <p className="text-xs text-gray-400 mt-2">
            برای ثبت درخواست مرجوعی، به جزئیات سفارش مورد نظر بروید
          </p>
        </div>
      ) : (
        requests.map((req: any) => {
          const status = statusLabels[req.status] || statusLabels.pending;
          return (
            <div key={req.id} className="bg-white rounded-xl p-4 border border-gray-100">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <span className="text-xs text-gray-500">سفارش:</span>
                  <code className="text-sm font-bold text-[#dc2626] mr-1" dir="ltr">{req.order.orderNumber}</code>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full ${status.color}`}>{status.label}</span>
              </div>
              <p className="text-sm font-medium">{reasonLabels[req.reason] || req.reason}</p>
              {req.description && <p className="text-xs text-gray-500 mt-1">{req.description}</p>}
              <div className="flex items-center justify-between mt-2 pt-2 border-t border-gray-50 text-xs text-gray-400">
                <span>{new Date(req.createdAt).toLocaleDateString('fa-IR')}</span>
                {req.refundAmount && (
                  <span className="text-green-600 font-bold fa-num">
                    مبلغ بازگشتی: {formatPrice(req.refundAmount)} ت
                  </span>
                )}
              </div>
            </div>
          );
        })
      )}
    </div>
  );
}

// ===== Notifications Tab (full page) =====
export function NotificationsTab() {
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const fetchNotifications = async () => {
    try {
      const res = await fetch(`/api/user/notifications?limit=100${filter === 'unread' ? '&unread=true' : ''}`);
      if (res.ok) {
        const data = await res.json();
        setNotifications(data.notifications || []);
      }
    } catch {}
    setLoading(false);
  };

  useEffect(() => { fetchNotifications(); }, [filter]);

  const handleMarkAllRead = async () => {
    await fetch('/api/user/notifications', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ markAllRead: true }),
    });
    fetchNotifications();
    toast.success('همه خوانده شدند');
  };

  const handleDelete = async (id: number) => {
    await fetch(`/api/user/notifications?id=${id}`, { method: 'DELETE' });
    setNotifications(notifications.filter(n => n.id !== id));
  };

  if (loading) return <div className="flex justify-center py-8"><Loader2 className="w-8 h-8 animate-spin text-[#dc2626]" /></div>;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          <button
            onClick={() => setFilter('all')}
            className={`text-xs px-3 py-1.5 rounded-full ${filter === 'all' ? 'bg-[#dc2626] text-white' : 'bg-gray-100'}`}
          >
            همه
          </button>
          <button
            onClick={() => setFilter('unread')}
            className={`text-xs px-3 py-1.5 rounded-full ${filter === 'unread' ? 'bg-[#dc2626] text-white' : 'bg-gray-100'}`}
          >
            خوانده‌نشده
          </button>
        </div>
        {notifications.some(n => !n.isRead) && (
          <Button onClick={handleMarkAllRead} size="sm" variant="outline">
            خواندن همه
          </Button>
        )}
      </div>

      {notifications.length === 0 ? (
        <div className="bg-white rounded-xl p-8 text-center text-gray-500">
          اعلانی وجود ندارد
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="divide-y divide-gray-50">
            {notifications.map((notif: any) => (
              <div key={notif.id} className={`p-4 ${!notif.isRead ? 'bg-blue-50/30' : ''}`}>
                <div className="flex items-start gap-3">
                  <div className="flex-1">
                    <p className={`text-sm ${notif.isRead ? 'text-gray-700' : 'font-bold text-gray-900'}`}>
                      {notif.title}
                    </p>
                    {notif.body && <p className="text-xs text-gray-500 mt-1">{notif.body}</p>}
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-[10px] text-gray-400">
                        {new Date(notif.createdAt).toLocaleDateString('fa-IR')}
                      </span>
                      <div className="flex gap-2">
                        {notif.link && (
                          <Link href={notif.link} className="text-xs text-[#dc2626] hover:underline">
                            مشاهده
                          </Link>
                        )}
                        <button
                          onClick={() => handleDelete(notif.id)}
                          className="text-xs text-red-400 hover:underline"
                        >
                          حذف
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ===== Delete Account Tab =====
export function DeleteAccountTab() {
  const [confirmText, setConfirmText] = useState('');
  const [loading, setLoading] = useState(false);

  const handleDelete = async () => {
    if (confirmText !== 'حذف کن') {
      toast.error('برای تأیید، عبارت "حذف کن" را بنویسید');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/user/delete-account', { method: 'DELETE' });
      const data = await res.json();
      if (res.ok) {
        toast.success('حساب شما حذف شد');
        setTimeout(() => {
          window.location.href = '/';
        }, 1500);
      } else {
        toast.error(data.error || 'خطا');
      }
    } catch {
      toast.error('خطا در ارتباط');
    }
    setLoading(false);
  };

  return (
    <div className="space-y-4">
      <div className="bg-red-50 border border-red-200 rounded-xl p-5">
        <h3 className="font-bold text-red-800 mb-2 flex items-center gap-2">
          <Trash2 className="w-5 h-5" />
          حذف حساب کاربری
        </h3>
        <p className="text-sm text-red-700 mb-3">
          ⚠️ توجه: با حذف حساب کاربری:
        </p>
        <ul className="text-sm text-red-700 list-disc pr-5 space-y-1 mb-4">
          <li>اطلاعات شخصی شما (نام، ایمیل، آدرس) پاک می‌شود</li>
          <li>از تمام دستگاه‌ها خارج می‌شوید</li>
          <li>تاریخچه سفارش‌ها برای گزارش‌گیری مالی حفظ می‌شود (بدون اطلاعات شخصی)</li>
          <li>این عمل قابل بازگشت نیست</li>
        </ul>

        <div className="space-y-2">
          <Label className="text-red-800">
            برای تأیید، عبارت "حذف کن" را در کادر زیر بنویسید:
          </Label>
          <Input
            value={confirmText}
            onChange={e => setConfirmText(e.target.value)}
            placeholder="حذف کن"
            className="border-red-300"
          />
        </div>

        <Button
          onClick={handleDelete}
          disabled={loading || confirmText !== 'حذف کن'}
          className="w-full mt-4 bg-red-600 hover:bg-red-700"
        >
          {loading ? <Loader2 className="w-4 h-4 ml-1 animate-spin" /> : <Trash2 className="w-4 h-4 ml-1" />}
          حذف کامل حساب
        </Button>
      </div>
    </div>
  );
}
