'use client';

const woodTypes = [
  { name: "چوب راش", icon: "🌳", color: "#d4a373" },
  { name: "چوب بامبو", icon: "🎋", color: "#84cc16" },
  { name: "چوب بلوط", icon: "🪵", color: "#8b5cf6" },
  { name: "چوب گردو", icon: "🌰", color: "#5d4037" },
  { name: "چوب MDF", icon: "🪚", color: "#a8a8a8" },
  { name: "چوب ممرز", icon: "🌲", color: "#10b981" },
  { name: "چوب راش قرمز", icon: "🍂", color: "#dc2626" },
  { name: "چوب افرا", icon: "🍁", color: "#f59e0b" },
];

export function PopularBrands() {
  return (
    <section className="bg-white rounded-xl p-4 md:p-6 shadow-sm">
      <div className="flex items-center justify-between mb-4 md:mb-6">
        <h2 className="text-lg md:text-xl font-bold">انواع چوب استفاده شده</h2>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-3 md:gap-4">
        {woodTypes.map(wood => (
          <div
            key={wood.name}
            className="border border-gray-100 rounded-lg p-4 flex flex-col items-center gap-2 hover:border-[#dc2626] hover:shadow-md transition-all cursor-pointer group"
          >
            <div
              className="w-12 h-12 rounded-full flex items-center justify-center text-2xl"
              style={{ backgroundColor: `${wood.color}20` }}
            >
              {wood.icon}
            </div>
            <span className="text-xs md:text-sm font-medium text-gray-700 group-hover:text-[#dc2626] transition-colors">
              {wood.name}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}
