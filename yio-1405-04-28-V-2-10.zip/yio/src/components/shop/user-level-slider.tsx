'use client';

import { USER_LEVELS, getUserLevel } from '@/lib/user-levels';
import { toFa } from '@/lib/shop-data';
import { ChevronUp, Award } from 'lucide-react';

interface UserLevelSliderProps {
  level: number;
  progress: number; // 0-100
  nextLevelHint: string | null;
  compact?: boolean;
}

export function UserLevelSlider({ level, progress, nextLevelHint, compact = false }: UserLevelSliderProps) {
  const levelInfo = getUserLevel(level);
  const nextLevel = level < 5 ? getUserLevel(level + 1) : null;

  if (compact) {
    return (
      <div className="flex items-center gap-2">
        <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${levelInfo.bgColor} ${levelInfo.color}`}>
          {levelInfo.icon} سطح {toFa(level)}
        </span>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
      {/* هدر: آیکون + عنوان + سطح فعلی */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center text-xl ${levelInfo.bgColor}`}>
            {levelInfo.icon}
          </div>
          <div>
            <p className={`font-bold ${levelInfo.color}`}>{levelInfo.title}</p>
            <p className="text-xs text-gray-500">{levelInfo.description}</p>
          </div>
        </div>
        <div className="text-left">
          <p className="text-xs text-gray-500">سطح فعلی</p>
          <p className={`text-2xl font-bold ${levelInfo.color} fa-num`}>{toFa(level)}<span className="text-sm text-gray-400">/۵</span></p>
        </div>
      </div>

      {/* اسلایدر پیشرفت — استایل مشابه نوار ارسال رایگان */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="text-gray-600">{levelInfo.title}</span>
          {nextLevel ? (
            <span className="text-gray-400">{nextLevel.title}</span>
          ) : (
            <span className="text-amber-600 font-bold flex items-center gap-1">
              <Award className="w-3 h-3" />
              حداکثر سطح
            </span>
          )}
        </div>

        {/* نوار پیشرفت — gradient قرمز به نارنجی مثل نوار ارسال رایگان */}
        <div className="relative h-2.5 bg-gray-100 rounded-full overflow-hidden">
          {nextLevel ? (
            <div
              className="absolute top-0 bottom-0 right-0 bg-gradient-to-l from-[#dc2626] to-[#f59e0b] rounded-full transition-all duration-500"
              style={{ width: `${(level - 1) * 20 + (progress * 20 / 100)}%` }}
            />
          ) : (
            <div className="absolute inset-0 bg-gradient-to-l from-[#dc2626] to-[#f59e0b] rounded-full" />
          )}
          {/* نقطه نشانگر */}
          <div
            className="absolute top-1/2 -translate-y-1/2 w-4 h-4 rounded-full border-2 border-white shadow-md transition-all duration-500 bg-[#dc2626]"
            style={{
              right: `calc(${(level - 1) * 20 + (progress * 20 / 100)}% - 8px)`,
            }}
          />
        </div>

        {/* شماره سطح‌ها */}
        <div className="flex justify-between text-[10px] text-gray-400 fa-num px-0.5">
          {[1, 2, 3, 4, 5].map(l => (
            <span key={l} className={l === level ? 'text-[#dc2626] font-bold' : ''}>{toFa(l)}</span>
          ))}
        </div>
      </div>

      {/* راهنمای ارتقا */}
      {nextLevelHint && (
        <div className="mt-3 bg-gradient-to-l from-amber-50 to-orange-50 border border-amber-200 rounded-lg p-3 flex items-start gap-2">
          <ChevronUp className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <div>
            <p className="text-xs font-bold text-amber-800 mb-0.5">برای ارتقا به سطح بعدی:</p>
            <p className="text-xs text-amber-700">{nextLevelHint}</p>
          </div>
        </div>
      )}

      {/* مزایای سطح فعلی */}
      <div className="mt-3 pt-3 border-t border-gray-100">
        <p className="text-xs text-gray-500 mb-2">مزایای سطح فعلی شما:</p>
        <div className="flex flex-wrap gap-1.5">
          {levelInfo.perks.map((perk, idx) => (
            <span key={idx} className={`text-xs px-2 py-1 rounded-md ${levelInfo.bgColor} ${levelInfo.color}`}>
              ✓ {perk}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
