'use client';

import { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { banners } from '@/lib/shop-data';
import { Button } from '@/components/ui/button';

export function HeroSlider() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent(prev => (prev + 1) % banners.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const next = () => setCurrent(prev => (prev + 1) % banners.length);
  const prev = () => setCurrent(prev => (prev - 1 + banners.length) % banners.length);

  return (
    <div className="relative w-full h-[200px] sm:h-[280px] md:h-[340px] lg:h-[400px] rounded-xl overflow-hidden shadow-md">
      {banners.map((banner, idx) => (
        <div
          key={banner.id}
          className="absolute inset-0 transition-opacity duration-500"
          style={{
            background: banner.bgColor,
            opacity: idx === current ? 1 : 0,
            zIndex: idx === current ? 10 : 1,
          }}
        >
          <div className="h-full flex items-center justify-between px-8 md:px-16">
            <div className="text-white max-w-md">
              <h2 className="text-2xl md:text-4xl font-bold mb-3 md:mb-4">
                {banner.title}
              </h2>
              {banner.subtitle && (
                <p className="text-base md:text-xl opacity-90 mb-6">
                  {banner.subtitle}
                </p>
              )}
              <Button
                size="lg"
                className="bg-white text-[#dc2626] hover:bg-gray-100 font-bold"
              >
                مشاهده محصولات
              </Button>
            </div>
            <div className="hidden md:flex items-center justify-center text-9xl opacity-30">
              {idx === 0 && '🪵'}
              {idx === 1 && '🧸'}
              {idx === 2 && '🍽️'}
            </div>
          </div>
        </div>
      ))}

      {/* دکمه‌های ناوبری */}
      <Button
        variant="ghost"
        size="icon"
        onClick={prev}
        className="absolute right-2 top-1/2 -translate-y-1/2 z-20 bg-white/30 hover:bg-white/50 text-white"
      >
        <ChevronRight className="w-6 h-6" />
      </Button>
      <Button
        variant="ghost"
        size="icon"
        onClick={next}
        className="absolute left-2 top-1/2 -translate-y-1/2 z-20 bg-white/30 hover:bg-white/50 text-white"
      >
        <ChevronLeft className="w-6 h-6" />
      </Button>

      {/* نقاط نشانگر */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 z-20">
        {banners.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrent(idx)}
            className={`h-2 rounded-full transition-all ${
              idx === current ? 'w-8 bg-white' : 'w-2 bg-white/50'
            }`}
          />
        ))}
      </div>
    </div>
  );
}
