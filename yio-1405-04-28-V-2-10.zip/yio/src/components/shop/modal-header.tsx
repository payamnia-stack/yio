'use client';

import { X, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ModalHeaderProps {
  title: string;
  icon?: any;
  onClose: () => void;
  variant?: 'default' | 'gradient';
}

/**
 * هدر مدال با دکمه بستن واضح
 * - در دسکتاپ: هدر معمولی با دکمه بستن در گوشه
 * - در موبایل: هدر sticky با دکمه بستن بزرگ و واضح
 */
export function ModalHeader({ title, icon: Icon, onClose, variant = 'default' }: ModalHeaderProps) {
  const isGradient = variant === 'gradient';

  return (
    <div
      className={`sticky top-0 z-10 p-3 md:p-4 flex items-center justify-between border-b ${
        isGradient
          ? 'bg-gradient-to-l from-[#dc2626] to-[#991b1b] text-white border-transparent'
          : 'bg-white border-gray-100'
      }`}
    >
      <h2 className="text-base md:text-lg font-bold flex items-center gap-2 min-w-0">
        {Icon && <Icon className="w-5 h-5 shrink-0" />}
        <span className="truncate">{title}</span>
      </h2>
      <button
        onClick={onClose}
        className={`shrink-0 w-9 h-9 flex items-center justify-center rounded-full transition-all hover:scale-110 ${
          isGradient
            ? 'bg-white/20 hover:bg-white/30 text-white'
            : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
        }`}
        aria-label="بستن"
      >
        <X className="w-5 h-5" />
      </button>
    </div>
  );
}

/**
 * دکمه بازگشت برای صفحات داخلی (مثل صفحه محصول)
 * در موبایل در هدر بالا نمایش داده می‌شود
 */
export function BackButton({ href = '/', className = '' }: { href?: string; className?: string }) {
  return (
    <a
      href={href}
      className={`shrink-0 w-9 h-9 flex items-center justify-center rounded-full bg-white hover:bg-gray-100 shadow-sm border border-gray-200 transition-all hover:scale-105 ${className}`}
      aria-label="بازگشت"
    >
      <ArrowRight className="w-5 h-5 text-gray-700" />
    </a>
  );
}
