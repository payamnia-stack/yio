'use client';

import { useEffect, useState } from 'react';
import { toFa, type Product } from '@/lib/shop-data';
import { ProductCard } from './product-card';
import { Skeleton } from '@/components/ui/skeleton';

function useCountdown() {
  const [timeLeft, setTimeLeft] = useState({
    hours: 12,
    minutes: 34,
    seconds: 56,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        let { hours, minutes, seconds } = prev;
        seconds--;
        if (seconds < 0) {
          seconds = 59;
          minutes--;
          if (minutes < 0) {
            minutes = 59;
            hours--;
            if (hours < 0) {
              hours = 23;
            }
          }
        }
        return { hours, minutes, seconds };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return timeLeft;
}

export function SpecialOffers() {
  const timeLeft = useCountdown();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/shop/special')
      .then(res => res.json())
      .then(data => {
        setProducts(data.products || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  return (
    <section className="bg-gradient-to-l from-[#dc2626] to-[#991b1b] rounded-xl overflow-hidden shadow-md">
      <div className="flex flex-col md:flex-row">
        {/* ستون چپ - تایتل و تایمر */}
        <div className="md:w-1/4 p-6 md:p-8 text-white flex flex-col items-center justify-center min-h-[200px]">
          <div className="text-5xl mb-3">🔥</div>
          <h2 className="text-2xl md:text-3xl font-bold mb-2 text-center">فروش ویژه</h2>
          <p className="text-sm opacity-90 mb-6 text-center">پیشنهادهای ویژه چوبی</p>

          {/* تایمر */}
          <div className="flex items-center gap-2" dir="ltr">
            <div className="bg-white/20 backdrop-blur rounded-lg w-14 h-14 flex flex-col items-center justify-center">
              <span className="text-2xl font-bold fa-num">{toFa(timeLeft.hours)}</span>
              <span className="text-[10px] opacity-80">ساعت</span>
            </div>
            <span className="text-2xl font-bold">:</span>
            <div className="bg-white/20 backdrop-blur rounded-lg w-14 h-14 flex flex-col items-center justify-center">
              <span className="text-2xl font-bold fa-num">{toFa(timeLeft.minutes)}</span>
              <span className="text-[10px] opacity-80">دقیقه</span>
            </div>
            <span className="text-2xl font-bold">:</span>
            <div className="bg-white/20 backdrop-blur rounded-lg w-14 h-14 flex flex-col items-center justify-center">
              <span className="text-2xl font-bold fa-num">{toFa(timeLeft.seconds)}</span>
              <span className="text-[10px] opacity-80">ثانیه</span>
            </div>
          </div>
        </div>

        {/* ستون راست - محصولات */}
        <div className="md:w-3/4 bg-white p-4 md:p-6">
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="aspect-square w-full" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-3 md:gap-4">
              {products.slice(0, 3).map(product => (
                <ProductCard key={product.id} product={product} compact />
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
