'use client';

import { useShopStore } from '@/store/shop-store';
import { formatPrice, toFa } from '@/lib/shop-data';
import { Truck, CheckCircle } from 'lucide-react';

export function CartProgressBar() {
  const cartTotal = useShopStore(s => s.cartTotal());
  const threshold = 500000; // ۵۰۰ هزار تومان

  const remaining = Math.max(0, threshold - cartTotal);
  const progress = Math.min(100, (cartTotal / threshold) * 100);
  const isFree = cartTotal >= threshold;

  if (cartTotal === 0) return null;

  return (
    <div className="bg-white rounded-lg p-3 shadow-sm">
      {isFree ? (
        <div className="flex items-center gap-2 text-green-600 text-sm font-medium">
          <CheckCircle className="w-5 h-5" />
          <span>ارسال این سفارش رایگان است! 🎉</span>
        </div>
      ) : (
        <div>
          <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
            <Truck className="w-4 h-4 text-[#dc2626]" />
            <span>
              با <strong className="text-[#dc2626] fa-num">{formatPrice(remaining)}</strong> تومان خرید بیشتر، ارسال رایگان شو!
            </span>
          </div>
          <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-l from-[#dc2626] to-[#f59e0b] rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between text-[10px] text-gray-400 mt-1">
            <span className="fa-num">{formatPrice(cartTotal)} ت</span>
            <span className="fa-num">{formatPrice(threshold)} ت</span>
          </div>
        </div>
      )}
    </div>
  );
}
