'use client';

import { useState, useRef } from 'react';
import { Camera, Upload, Check, X, Loader2, Pencil } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';

// لیست آواتارهای پیش‌فرض (16 آواتار PNG)
const DEFAULT_AVATARS = Array.from({ length: 16 }, (_, i) => `/avatars/${(i + 1).toString().padStart(2, '0')}.png`);

interface AvatarEditorProps {
  currentAvatar: string | null | undefined;
  userName?: string | null;
  size?: 'sm' | 'md' | 'lg';
  onAvatarChange?: (avatar: string) => void;
}

export function AvatarEditor({ currentAvatar, userName, size = 'md', onAvatarChange }: AvatarEditorProps) {
  const [open, setOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [selecting, setSelecting] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  // سایزها بر اساس prop
  const sizeClasses = {
    sm: 'w-12 h-12',
    md: 'w-20 h-20',
    lg: 'w-24 h-24',
  };
  const pencilSizeClasses = {
    sm: 'w-5 h-5 -bottom-1 -right-1',
    md: 'w-7 h-7 -bottom-1 -right-1',
    lg: 'w-8 h-8 -bottom-1 -right-1',
  };

  const fallbackAvatar = '/avatars/01.png';
  const avatarSrc = currentAvatar || fallbackAvatar;

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append('avatar', file);

    try {
      const res = await fetch('/api/user/avatar', { method: 'POST', body: formData });
      const data = await res.json();
      if (res.ok && data.avatar) {
        toast.success('آواتار آپلود شد');
        onAvatarChange?.(data.avatar);
        setOpen(false);
      } else {
        toast.error(data.error || 'خطا در آپلود');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const handleSelectAvatar = async (avatar: string) => {
    setSelecting(true);
    try {
      const res = await fetch('/api/user/avatar', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ avatar }),
      });
      if (res.ok) {
        toast.success('آواتار انتخاب شد');
        onAvatarChange?.(avatar);
        setOpen(false);
      } else {
        toast.error('خطا');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setSelecting(false);
    }
  };

  return (
    <>
      {/* آواتار با آیکون مداد */}
      <div className="relative inline-block group">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={avatarSrc}
          alt={userName || 'آواتار'}
          className={`${sizeClasses[size]} rounded-full border-2 border-white shadow-md object-cover bg-gray-100`}
        />
        {/* آیکون مداد برای ویرایش */}
        <button
          type="button"
          onClick={() => setOpen(true)}
          className={`absolute ${pencilSizeClasses[size]} bg-[#dc2626] hover:bg-[#b91c1c] text-white rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-110 border-2 border-white`}
          title="تغییر آواتار"
          aria-label="تغییر آواتار"
        >
          <Pencil className="w-2/3 h-2/3" />
        </button>
      </div>

      {/* پاپ‌آپ انتخاب آواتار */}
      {open && (
        <div
          className="fixed inset-0 z-50 bg-gray-900/70 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setOpen(false)}
        >
          <div
            className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
          >
            {/* هدر */}
            <div className="sticky top-0 bg-white border-b border-gray-100 p-4 flex items-center justify-between z-10">
              <h3 className="font-bold flex items-center gap-2">
                <Camera className="w-5 h-5 text-[#dc2626]" />
                انتخاب آواتار
              </h3>
              <button
                onClick={() => setOpen(false)}
                className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-4">
              {/* پیش‌نمایش فعلی */}
              <div className="flex flex-col items-center gap-2 pb-4 border-b border-gray-100">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={avatarSrc}
                  alt="آواتار فعلی"
                  className="w-24 h-24 rounded-full border-4 border-gray-100"
                />
                <p className="text-sm text-gray-500">آواتار فعلی شما</p>
              </div>

              {/* دکمه آپلود */}
              <Button
                type="button"
                variant="outline"
                onClick={() => fileRef.current?.click()}
                disabled={uploading}
                className="w-full"
              >
                {uploading ? (
                  <>
                    <Loader2 className="w-4 h-4 ml-1 animate-spin" />
                    در حال آپلود...
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4 ml-1" />
                    آپلود عکس شخصی
                  </>
                )}
              </Button>
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                onChange={handleUpload}
                className="hidden"
              />
              <p className="text-xs text-gray-500 text-center">حداکثر ۵ مگابایت - JPG, PNG, GIF, WebP</p>

              {/* جداکننده */}
              <div className="flex items-center gap-2 py-2">
                <div className="flex-1 h-px bg-gray-200"></div>
                <span className="text-xs text-gray-400">یا انتخاب از آواتارهای آماده</span>
                <div className="flex-1 h-px bg-gray-200"></div>
              </div>

              {/* آواتارهای پیش‌فرض */}
              <div className="grid grid-cols-4 gap-2">
                {DEFAULT_AVATARS.map(avatar => {
                  const isSelected = avatarSrc === avatar;
                  return (
                    <button
                      key={avatar}
                      type="button"
                      onClick={() => handleSelectAvatar(avatar)}
                      disabled={selecting}
                      className={`relative rounded-full overflow-hidden border-2 transition-all aspect-square ${
                        isSelected
                          ? 'border-[#dc2626] ring-2 ring-[#dc2626]/30 scale-105'
                          : 'border-transparent hover:border-gray-300 hover:scale-105'
                      }`}
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={avatar} alt="avatar" className="w-full h-full object-cover" />
                      {isSelected && (
                        <div className="absolute inset-0 bg-[#dc2626]/30 flex items-center justify-center">
                          <Check className="w-5 h-5 text-white drop-shadow" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>

              {selecting && (
                <div className="flex items-center justify-center gap-2 text-sm text-gray-500">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  در حال ذخیره...
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
