'use client'

import { useEffect, useRef, useState } from 'react'
import { useEditorStore } from '@/store/editorStore'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  Monitor,
  Tablet,
  Smartphone,
  Eye,
  Pencil,
  Save,
  Download,
  Undo2,
  Redo2,
  FileText,
  Plus,
  Trash2,
  Loader2,
} from 'lucide-react'
import { toast } from 'sonner'
import type { DeviceMode } from '@/lib/page-builder/types'
import type { ElementNode } from '@/lib/page-builder/types'

interface PageListItem {
  id: string
  name: string
  slug: string
  status: string
  updatedAt: string
}

export function TopBar() {
  const pageId = useEditorStore((s) => s.pageId)
  const pageName = useEditorStore((s) => s.pageName)
  const pageSlug = useEditorStore((s) => s.pageSlug)
  const tree = useEditorStore((s) => s.tree)
  const isDirty = useEditorStore((s) => s.isDirty)
  const isPreview = useEditorStore((s) => s.isPreview)
  const device = useEditorStore((s) => s.device)
  const past = useEditorStore((s) => s.past)
  const future = useEditorStore((s) => s.future)

  const setDevice = useEditorStore((s) => s.setDevice)
  const setPreview = useEditorStore((s) => s.setPreview)
  const undo = useEditorStore((s) => s.undo)
  const redo = useEditorStore((s) => s.redo)
  const setPage = useEditorStore((s) => s.setPage)
  const markSaved = useEditorStore((s) => s.markSaved)

  const [pages, setPages] = useState<PageListItem[]>([])
  const [loadingList, setLoadingList] = useState(true)
  const [saving, setSaving] = useState(false)
  const [newPageOpen, setNewPageOpen] = useState(false)
  const [newPageName, setNewPageName] = useState('')
  const [deleteOpen, setDeleteOpen] = useState(false)

  const autoInitRef = useRef(false)

  // Load pages list once
  useEffect(() => {
    void refreshPages()
  }, [])

  // If no page is loaded, auto-load or auto-create one — guarded by a ref to prevent duplicates
  useEffect(() => {
    if (autoInitRef.current) return
    if (loadingList) return
    autoInitRef.current = true
    if (pages.length > 0) {
      void loadPage(pages[0].id)
    } else {
      void createDefaultPage()
    }
  }, [pageId, pages, loadingList])

  async function refreshPages() {
    setLoadingList(true)
    try {
      const res = await fetch('/api/pagebuilder/pages')
      const data = await res.json()
      setPages(data.pages ?? [])
    } catch (err) {
      console.error(err)
    } finally {
      setLoadingList(false)
    }
  }

  async function loadPage(id: string) {
    try {
      const res = await fetch(`/api/pagebuilder/pages/${id}`)
      const data = await res.json()
      setPage({
        id: data.page.id,
        name: data.page.name,
        slug: data.page.slug,
        content: data.page.content as ElementNode[],
      })
    } catch (err) {
      toast.error('Failed to load page')
      console.error(err)
    }
  }

  async function createDefaultPage() {
    try {
      const res = await fetch('/api/pagebuilder/pages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: 'Welcome Page', content: defaultPageContent() }),
      })
      const data = await res.json()
      await refreshPages()
      setPage({
        id: data.page.id,
        name: data.page.name,
        slug: data.page.slug,
        content: data.page.content as ElementNode[],
      })
    } catch (err) {
      console.error(err)
    }
  }

  async function createPage(name: string) {
    try {
      const res = await fetch('/api/pagebuilder/pages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, content: [] }),
      })
      const data = await res.json()
      await refreshPages()
      setPage({
        id: data.page.id,
        name: data.page.name,
        slug: data.page.slug,
        content: data.page.content as ElementNode[],
      })
      toast.success('Page created')
    } catch (err) {
      toast.error('Failed to create page')
      console.error(err)
    }
  }

  async function savePage() {
    if (!pageId) return
    setSaving(true)
    try {
      await fetch(`/api/pagebuilder/pages/${pageId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: pageName, slug: pageSlug, content: tree, status: 'draft' }),
      })
      markSaved()
      toast.success('Page saved')
      await refreshPages()
    } catch (err) {
      toast.error('Failed to save')
      console.error(err)
    } finally {
      setSaving(false)
    }
  }

  async function deletePage() {
    if (!pageId) return
    try {
      await fetch(`/api/pagebuilder/pages/${pageId}`, { method: 'DELETE' })
      toast.success('Page deleted')
      await refreshPages()
      // Load another page if available
      const remaining = pages.filter((p) => p.id !== pageId)
      if (remaining.length > 0) {
        await loadPage(remaining[0].id)
      } else {
        await createDefaultPage()
      }
    } catch (err) {
      toast.error('Failed to delete')
      console.error(err)
    } finally {
      setDeleteOpen(false)
    }
  }

  function exportHtml() {
    if (!pageId) return
    window.open(`/api/pagebuilder/export/${pageId}`, '_blank')
  }

  const devices: { value: DeviceMode; icon: typeof Monitor }[] = [
    { value: 'desktop', icon: Monitor },
    { value: 'tablet', icon: Tablet },
    { value: 'mobile', icon: Smartphone },
  ]

  return (
    <header className="h-14 border-b bg-background flex items-center gap-2 px-3 shrink-0 z-20">
      {/* Logo */}
      <div className="flex items-center gap-2 pr-2 border-r">
        <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
          <FileText className="h-4 w-4" />
        </div>
        <span className="font-semibold text-sm hidden sm:inline">Page Builder</span>
      </div>

      {/* Page selector */}
      <Select
        value={pageId ?? ''}
        onValueChange={(v) => loadPage(v)}
      >
        <SelectTrigger className="h-9 w-44 sm:w-56 text-sm">
          <SelectValue placeholder="Select page..." />
        </SelectTrigger>
        <SelectContent>
          {pages.map((p) => (
            <SelectItem key={p.id} value={p.id} className="text-sm">
              <span className="flex items-center gap-2">
                <span className="truncate">{p.name}</span>
                {p.status === 'published' && (
                  <Badge variant="secondary" className="text-[9px] py-0 px-1">live</Badge>
                )}
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Button
        variant="outline"
        size="icon"
        className="h-9 w-9"
        onClick={() => setNewPageOpen(true)}
        title="New page"
      >
        <Plus className="h-4 w-4" />
      </Button>

      {pageId && (
        <Button
          variant="outline"
          size="icon"
          className="h-9 w-9 text-destructive hover:text-destructive"
          onClick={() => setDeleteOpen(true)}
          title="Delete page"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      )}

      {/* Dirty indicator */}
      {isDirty && (
        <span className="text-xs text-amber-500 hidden md:inline">● unsaved</span>
      )}

      {/* Spacer */}
      <div className="flex-1" />

      {/* Undo/Redo */}
      <div className="hidden sm:flex items-center gap-0.5">
        <Button
          variant="ghost"
          size="icon"
          className="h-9 w-9"
          onClick={undo}
          disabled={past.length === 0}
          title="Undo"
        >
          <Undo2 className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-9 w-9"
          onClick={redo}
          disabled={future.length === 0}
          title="Redo"
        >
          <Redo2 className="h-4 w-4" />
        </Button>
      </div>

      {/* Device toggle */}
      <div className="flex items-center gap-0.5 rounded-md border bg-muted/30 p-0.5">
        {devices.map(({ value, icon: Icon }) => (
          <Button
            key={value}
            variant={device === value ? 'default' : 'ghost'}
            size="icon"
            className="h-7 w-7"
            onClick={() => setDevice(value)}
            title={value}
          >
            <Icon className="h-3.5 w-3.5" />
          </Button>
        ))}
      </div>

      {/* Preview toggle */}
      <Button
        variant={isPreview ? 'default' : 'outline'}
        size="sm"
        className="h-9"
        onClick={() => setPreview(!isPreview)}
      >
        {isPreview ? <Pencil className="h-4 w-4 mr-1" /> : <Eye className="h-4 w-4 mr-1" />}
        <span className="hidden sm:inline">{isPreview ? 'Edit' : 'Preview'}</span>
      </Button>

      {/* Export */}
      <Button
        variant="outline"
        size="sm"
        className="h-9"
        onClick={exportHtml}
        disabled={!pageId}
        title="Export standalone HTML"
      >
        <Download className="h-4 w-4 mr-1" />
        <span className="hidden sm:inline">Export</span>
      </Button>

      {/* Save */}
      <Button
        size="sm"
        className="h-9"
        onClick={savePage}
        disabled={!pageId || saving}
      >
        {saving ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <Save className="h-4 w-4 mr-1" />}
        <span className="hidden sm:inline">Save</span>
      </Button>

      {/* New Page Dialog */}
      <Dialog open={newPageOpen} onOpenChange={setNewPageOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Page</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 py-2">
            <Label htmlFor="new-page-name">Page Name</Label>
            <Input
              id="new-page-name"
              value={newPageName}
              onChange={(e) => setNewPageName(e.target.value)}
              placeholder="e.g. About Us"
              autoFocus
              onKeyDown={(e) => {
                if (e.key === 'Enter' && newPageName.trim()) {
                  createPage(newPageName.trim())
                  setNewPageName('')
                  setNewPageOpen(false)
                }
              }}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setNewPageOpen(false)}>Cancel</Button>
            <Button
              onClick={() => {
                if (newPageName.trim()) {
                  createPage(newPageName.trim())
                  setNewPageName('')
                  setNewPageOpen(false)
                }
              }}
            >
              Create
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <Dialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Page</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground py-2">
            Are you sure you want to delete &ldquo;{pageName}&rdquo;? This cannot be undone.
          </p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteOpen(false)}>Cancel</Button>
            <Button variant="destructive" onClick={deletePage}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </header>
  )
}

function Label({ htmlFor, children }: { htmlFor?: string; children: React.ReactNode }) {
  return (
    <label htmlFor={htmlFor} className="text-sm font-medium">
      {children}
    </label>
  )
}

/* Default welcome page content — gives the user something to see immediately. */
function defaultPageContent(): ElementNode[] {
  return [
    {
      id: 'container-hero',
      type: 'container',
      widget: 'container',
      props: {
        direction: 'column',
        justify: 'center',
        align: 'center',
        gap: '16px',
        wrap: false,
        minHeight: '60vh',
        padding: { top: '64px', right: '32px', bottom: '64px', left: '32px' },
        margin: { top: '0px', right: '0px', bottom: '0px', left: '0px' },
        background: '#6366f1',
        borderRadius: '0px',
        borderWidth: '0px',
        borderColor: '#e5e7eb',
      },
      children: [
        {
          id: 'heading-hero',
          type: 'widget',
          widget: 'heading',
          props: {
            text: 'Build Beautiful Pages Visually',
            tag: 'h1',
            align: 'center',
            color: '#ffffff',
            typography: {
              family: 'Inter, sans-serif',
              size: '48px',
              weight: '800',
              transform: 'none',
              style: 'normal',
              decoration: 'none',
              lineHeight: '1.2',
              letterSpacing: '-1px',
            },
            padding: { top: '0px', right: '0px', bottom: '0px', left: '0px' },
            margin: { top: '0px', right: '0px', bottom: '0px', left: '0px' },
          },
          children: [],
        },
        {
          id: 'text-hero',
          type: 'widget',
          widget: 'text',
          props: {
            text: 'Drag widgets from the left, drop them on the canvas, edit them in the right panel. Then export to clean standalone HTML.',
            align: 'center',
            color: '#e0e7ff',
            typography: {
              family: 'Inter, sans-serif',
              size: '18px',
              weight: '400',
              transform: 'none',
              style: 'normal',
              decoration: 'none',
              lineHeight: '1.6',
              letterSpacing: '0px',
            },
            padding: { top: '0px', right: '0px', bottom: '0px', left: '0px' },
            margin: { top: '0px', right: '0px', bottom: '0px', left: '0px' },
          },
          children: [],
        },
        {
          id: 'button-hero',
          type: 'widget',
          widget: 'button',
          props: {
            text: 'Get Started',
            url: '#',
            target: '_self',
            align: 'center',
            bgColor: '#ffffff',
            textColor: '#6366f1',
            hoverBgColor: '#f1f5f9',
            typography: {
              family: 'Inter, sans-serif',
              size: '15px',
              weight: '600',
              transform: 'none',
              style: 'normal',
              decoration: 'none',
              lineHeight: '1.5',
              letterSpacing: '0px',
            },
            padding: { top: '12px', right: '28px', bottom: '12px', left: '28px' },
            margin: { top: '8px', right: '0px', bottom: '0px', left: '0px' },
            borderRadius: '8px',
            width: 'auto',
          },
          children: [],
        },
      ],
    },
    {
      id: 'container-features',
      type: 'container',
      widget: 'container',
      props: {
        direction: 'row',
        justify: 'flex-start',
        align: 'stretch',
        gap: '20px',
        wrap: true,
        minHeight: 'auto',
        padding: { top: '64px', right: '32px', bottom: '64px', left: '32px' },
        margin: { top: '0px', right: '0px', bottom: '0px', left: '0px' },
        background: 'transparent',
        borderRadius: '0px',
        borderWidth: '0px',
        borderColor: '#e5e7eb',
      },
      children: [
        {
          id: 'iconbox-1',
          type: 'widget',
          widget: 'icon-box',
          props: {
            icon: 'Rocket',
            title: 'Drag & Drop',
            description: 'Move widgets anywhere on the canvas with intuitive drag-and-drop.',
            position: 'top',
            iconSize: '40px',
            iconColor: '#6366f1',
            titleColor: '#0f172a',
            descColor: '#64748b',
            align: 'center',
            bgColor: '#ffffff',
            padding: { top: '24px', right: '24px', bottom: '24px', left: '24px' },
            borderRadius: '12px',
          },
          children: [],
        },
        {
          id: 'iconbox-2',
          type: 'widget',
          widget: 'icon-box',
          props: {
            icon: 'Smartphone',
            title: 'Responsive',
            description: 'Preview your page on desktop, tablet and mobile breakpoints.',
            position: 'top',
            iconSize: '40px',
            iconColor: '#10b981',
            titleColor: '#0f172a',
            descColor: '#64748b',
            align: 'center',
            bgColor: '#ffffff',
            padding: { top: '24px', right: '24px', bottom: '24px', left: '24px' },
            borderRadius: '12px',
          },
          children: [],
        },
        {
          id: 'iconbox-3',
          type: 'widget',
          widget: 'icon-box',
          props: {
            icon: 'Code2',
            title: 'Export HTML',
            description: 'Download your page as standalone HTML with inline styles.',
            position: 'top',
            iconSize: '40px',
            iconColor: '#f59e0b',
            titleColor: '#0f172a',
            descColor: '#64748b',
            align: 'center',
            bgColor: '#ffffff',
            padding: { top: '24px', right: '24px', bottom: '24px', left: '24px' },
            borderRadius: '12px',
          },
          children: [],
        },
      ],
    },
  ]
}
