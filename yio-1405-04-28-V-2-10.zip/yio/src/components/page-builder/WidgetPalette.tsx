'use client'

import { useDraggable } from '@dnd-kit/core'
import { widgetRegistry } from '@/lib/page-builder/widgets'
import { useEditorStore } from '@/store/editorStore'
import { DynamicIcon } from './DynamicIcon'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useState } from 'react'
import { Input } from '@/components/ui/input'
import { Search } from 'lucide-react'
import type { WidgetDefinition } from '@/lib/page-builder/types'

const CATEGORY_LABELS: Record<string, string> = {
  layout: 'Layout',
  basic: 'Basic',
  media: 'Media',
  interactive: 'Interactive',
  marketing: 'Marketing',
  advanced: 'Advanced',
}

const CATEGORY_ORDER = ['layout', 'basic', 'media', 'marketing', 'interactive', 'advanced']

export function WidgetPalette() {
  const [search, setSearch] = useState('')
  const insertWidget = useEditorStore((s) => s.insertWidget)

  const filtered = widgetRegistry.filter(
    (w) =>
      w.name.toLowerCase().includes(search.toLowerCase()) ||
      w.description.toLowerCase().includes(search.toLowerCase()),
  )

  const grouped: Record<string, WidgetDefinition[]> = {}
  for (const w of filtered) {
    if (!grouped[w.category]) grouped[w.category] = []
    grouped[w.category].push(w)
  }

  return (
    <aside className="w-full lg:w-64 border-r bg-background flex flex-col shrink-0 h-full">
      <div className="p-3 border-b">
        <h2 className="text-sm font-semibold mb-2">Widgets</h2>
        <div className="relative">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search widgets..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-8 pl-7 text-sm"
          />
        </div>
      </div>
      <ScrollArea className="flex-1">
        <div className="p-2 space-y-4">
          {CATEGORY_ORDER.filter((c) => grouped[c]?.length).map((cat) => (
            <div key={cat}>
              <h3 className="text-[10px] uppercase tracking-wider font-semibold text-muted-foreground px-1 mb-1.5">
                {CATEGORY_LABELS[cat]}
              </h3>
              <div className="grid grid-cols-2 gap-1.5">
                {grouped[cat].map((w) => (
                  <WidgetTile key={w.type} widget={w} onDoubleClick={() => insertWidget(w.type, null, 999)} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </aside>
  )
}

function WidgetTile({
  widget,
  onDoubleClick,
}: {
  widget: WidgetDefinition
  onDoubleClick: () => void
}) {
  const { setNodeRef, listeners, attributes, isDragging } = useDraggable({
    id: `palette-${widget.type}`,
    data: { type: 'palette', widgetType: widget.type },
  })
  return (
    <button
      ref={setNodeRef}
      {...listeners}
      {...attributes}
      onDoubleClick={onDoubleClick}
      className="flex flex-col items-center gap-1 rounded-md border border-input bg-background p-2 text-center hover:bg-accent hover:border-primary/40 transition-colors cursor-grab active:cursor-grabbing"
      style={{ opacity: isDragging ? 0.4 : 1 }}
      title={widget.description}
    >
      <DynamicIcon name={widget.icon} style={{ width: 18, height: 18 }} className="text-primary" />
      <span className="text-[10px] font-medium leading-tight">{widget.name}</span>
    </button>
  )
}
