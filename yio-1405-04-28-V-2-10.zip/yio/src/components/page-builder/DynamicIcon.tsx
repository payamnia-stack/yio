'use client'

import * as Icons from 'lucide-react'
import type { LucideProps } from 'lucide-react'

interface IconProps extends LucideProps {
  name: string
}

/**
 * Render a Lucide icon by its PascalCase name.
 * Falls back to a square if the icon name doesn't exist.
 */
export function DynamicIcon({ name, ...rest }: IconProps) {
  const Comp = (Icons as unknown as Record<string, React.ComponentType<LucideProps>>)[name]
  if (!Comp) {
    return (
      <span
        aria-hidden
        style={{
          display: 'inline-block',
          width: '1em',
          height: '1em',
          background: 'currentColor',
          opacity: 0.4,
          borderRadius: 2,
        }}
        {...(rest as object)}
      />
    )
  }
  return <Comp {...rest} />
}
