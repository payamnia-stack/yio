'use client'

import { useDroppable, useDraggable } from '@dnd-kit/core'
import { useEditorStore } from '@/store/editorStore'
import type { ElementNode, Spacing, Typography } from '@/lib/page-builder/types'
import { widgetMap } from '@/lib/page-builder/widgets'
import { spacingStyle, typographyStyle } from './styleUtils'
import { DynamicIcon } from './DynamicIcon'
import {
  Copy,
  Trash2,
  ChevronUp,
  ChevronDown,
} from 'lucide-react'
import type { ReactNode } from 'react'
import { useState } from 'react'

/* -------------------------------------------------------------------------- */
/*  Canvas — the top-level droppable area                                     */
/* -------------------------------------------------------------------------- */

export function Canvas() {
  const tree = useEditorStore((s) => s.tree)
  const isPreview = useEditorStore((s) => s.isPreview)
  const device = useEditorStore((s) => s.device)
  const select = useEditorStore((s) => s.select)
  const selectedId = useEditorStore((s) => s.selectedId)
  const { setNodeRef, isOver } = useDroppable({ id: 'canvas-root' })

  const deviceWidth = device === 'desktop' ? '100%' : device === 'tablet' ? '768px' : '375px'

  return (
    <div className="flex-1 overflow-auto bg-muted/30 p-6 flex justify-center">
      <div
        className="bg-background shadow-sm transition-all"
        style={{
          width: deviceWidth,
          maxWidth: '100%',
          minHeight: '100%',
          borderRadius: device === 'desktop' ? 0 : 8,
        }}
      >
        {/* Drop zone for the root */}
        <div
          ref={setNodeRef}
          onClick={(e) => {
            if (e.target === e.currentTarget) select(null)
          }}
          data-canvas-root
          className="min-h-[200px] relative"
          style={{
            outline: isOver && tree.length === 0 ? '2px dashed hsl(var(--primary))' : undefined,
            outlineOffset: -2,
          }}
        >
          {tree.length === 0 ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-muted-foreground text-sm pointer-events-none">
              <DynamicIcon name="LayoutTemplate" style={{ width: 48, height: 48, opacity: 0.3 }} />
              <p className="mt-2">Drag a widget here to start building</p>
            </div>
          ) : isPreview ? (
            tree.map((node) => <PreviewNode key={node.id} node={node} />)
          ) : (
            tree.map((node, idx) => (
              <ElementWrapper
                key={node.id}
                node={node}
                parentId={null}
                index={idx}
                selectedId={selectedId}
              />
            ))
          )}
        </div>
      </div>
    </div>
  )
}

/* -------------------------------------------------------------------------- */
/*  PreviewNode — used in preview mode, renders widget tree without wrappers  */
/* -------------------------------------------------------------------------- */

function PreviewNode({ node }: { node: ElementNode }) {
  const p = node.props as Record<string, unknown>
  if (node.type === 'container') {
    const style: React.CSSProperties = {
      display: 'flex',
      flexDirection: p.direction as React.CSSProperties['flexDirection'],
      justifyContent: p.justify as React.CSSProperties['justifyContent'],
      alignItems: p.align as React.CSSProperties['alignItems'],
      gap: p.gap as string,
      flexWrap: p.wrap ? 'wrap' : 'nowrap',
      minHeight: p.minHeight as string,
      background: p.background as string,
      borderRadius: p.borderRadius as string,
      ...(p.borderWidth && p.borderWidth !== '0px'
        ? { border: `${p.borderWidth} solid ${p.borderColor}` }
        : {}),
      ...spacingStyle(p.padding as Spacing, 'padding'),
      ...spacingStyle(p.margin as Spacing, 'margin'),
    }
    return (
      <div style={style}>
        {node.children.map((c) => <PreviewNode key={c.id} node={c} />)}
      </div>
    )
  }
  return <WidgetLeaf node={node} />
}

/* -------------------------------------------------------------------------- */
/*  ElementWrapper — wraps each element (root or nested) with selection/drag  */
/* -------------------------------------------------------------------------- */

interface WrapperProps {
  node: ElementNode
  parentId: string | null
  index: number
  selectedId: string | null
}

function ElementWrapper({ node, parentId, index, selectedId }: WrapperProps) {
  const select = useEditorStore((s) => s.select)
  const hover = useEditorStore((s) => s.hover)
  const hoveredId = useEditorStore((s) => s.hoveredId)
  const deleteElement = useEditorStore((s) => s.deleteElement)
  const duplicateElement = useEditorStore((s) => s.duplicateElement)
  const moveElement = useEditorStore((s) => s.moveElement)

  const def = node.widget ? widgetMap[node.widget] : null
  const isContainer = node.type === 'container'
  const isSelected = selectedId === node.id
  const isHovered = hoveredId === node.id

  // Each element is draggable so existing items can be re-arranged
  const { setNodeRef: setDragRef, listeners, attributes, isDragging } = useDraggable({
    id: node.id,
    data: { type: 'existing', node, parentId, index },
  })

  // Containers are also droppable so items can be dropped inside
  const { setNodeRef: setDropRef, isOver } = useDroppable({
    id: `drop-${node.id}`,
    data: { type: 'container', parentId: node.id },
    disabled: !isContainer,
  })

  const setRef = (el: HTMLDivElement | null) => {
    setDragRef(el)
    if (isContainer) setDropRef(el)
  }

  // Compute container styles for the outer div (when container) or wrapper styles (when widget)
  const p = node.props as Record<string, unknown>

  const containerStyle: React.CSSProperties = isContainer
    ? {
        display: 'flex',
        flexDirection: p.direction as React.CSSProperties['flexDirection'],
        justifyContent: p.justify as React.CSSProperties['justifyContent'],
        alignItems: p.align as React.CSSProperties['alignItems'],
        gap: p.gap as string,
        flexWrap: p.wrap ? 'wrap' : 'nowrap',
        minHeight: p.minHeight as string,
        background: p.background as string,
        borderRadius: p.borderRadius as string,
        ...(p.borderWidth && p.borderWidth !== '0px'
          ? { border: `${p.borderWidth} solid ${p.borderColor}` }
          : {}),
        ...spacingStyle(p.padding as Spacing, 'padding'),
        ...spacingStyle(p.margin as Spacing, 'margin'),
      }
    : {}

  return (
    <div
      ref={setRef}
      {...attributes}
      {...listeners}
      onClick={(e) => {
        e.stopPropagation()
        select(node.id)
      }}
      onMouseEnter={(e) => {
        e.stopPropagation()
        hover(node.id)
      }}
      onMouseLeave={() => hover(null)}
      data-element-id={node.id}
      className="relative group"
      style={{
        outline: isSelected
          ? '2px solid hsl(var(--primary))'
          : isHovered
          ? '1px dashed hsl(var(--primary) / 0.5)'
          : undefined,
        outlineOffset: isSelected ? -2 : -1,
        opacity: isDragging ? 0.4 : 1,
        cursor: 'default',
        minHeight: isContainer ? '60px' : undefined,
        ...containerStyle,
      }}
    >
      {/* Floating toolbar */}
      {def && !isDragging && (
        <div
          className={`absolute -top-6 left-0 z-10 flex items-center gap-0.5 rounded-t bg-primary text-primary-foreground text-xs px-1 py-0.5 transition-opacity ${
            isSelected || isHovered ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <DynamicIcon name={def.icon} style={{ width: 12, height: 12, margin: '0 4px 0 2px' }} />
          <span className="font-medium pr-1">{def.name}</span>
          <button
            type="button"
            className="p-0.5 hover:bg-primary-foreground/20 rounded"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => {
              e.stopPropagation()
              moveElement(node.id, parentId, Math.max(0, index - 1))
            }}
            title="Move up"
          >
            <ChevronUp style={{ width: 12, height: 12 }} />
          </button>
          <button
            type="button"
            className="p-0.5 hover:bg-primary-foreground/20 rounded"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => {
              e.stopPropagation()
              moveElement(node.id, parentId, index + 2)
            }}
            title="Move down"
          >
            <ChevronDown style={{ width: 12, height: 12 }} />
          </button>
          <button
            type="button"
            className="p-0.5 hover:bg-primary-foreground/20 rounded"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => {
              e.stopPropagation()
              duplicateElement(node.id)
            }}
            title="Duplicate"
          >
            <Copy style={{ width: 12, height: 12 }} />
          </button>
          <button
            type="button"
            className="p-0.5 hover:bg-primary-foreground/20 rounded"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => {
              e.stopPropagation()
              deleteElement(node.id)
            }}
            title="Delete"
          >
            <Trash2 style={{ width: 12, height: 12 }} />
          </button>
        </div>
      )}

      {/* Render the actual widget content (no children — they're rendered below for containers) */}
      {isContainer ? (
        <>
          {node.children.length === 0 ? (
            <div className="text-xs text-muted-foreground italic p-2 pointer-events-none">
              Empty container — drop widgets here
            </div>
          ) : (
            node.children.map((child, i) => (
              <ElementWrapper
                key={child.id}
                node={child}
                parentId={node.id}
                index={i}
                selectedId={selectedId}
              />
            ))
          )}
        </>
      ) : (
        <WidgetLeaf node={node} />
      )}

      {/* Container drop indicator */}
      {isContainer && isOver && (
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            outline: '2px dashed hsl(var(--primary))',
            outlineOffset: -4,
            background: 'hsl(var(--primary) / 0.05)',
          }}
        />
      )}
    </div>
  )
}

/* -------------------------------------------------------------------------- */
/*  WidgetLeaf — renders the inner content of a non-container widget         */
/* -------------------------------------------------------------------------- */

function WidgetLeaf({ node }: { node: ElementNode }): ReactNode {
  const p = node.props as Record<string, unknown>

  switch (node.widget) {
    case 'heading': return <HeadingLeaf p={p} />
    case 'text': return <TextLeaf p={p} />
    case 'button': return <ButtonLeaf p={p} />
    case 'image': return <ImageLeaf p={p} />
    case 'video': return <VideoLeaf p={p} />
    case 'divider': return <DividerLeaf p={p} />
    case 'spacer': return <SpacerLeaf p={p} />
    case 'icon': return <IconLeaf p={p} />
    case 'icon-box': return <IconBoxLeaf p={p} />
    case 'image-box': return <ImageBoxLeaf p={p} />
    case 'cta': return <CTALeaf p={p} />
    case 'flip-box': return <FlipBoxLeaf p={p} />
    case 'testimonial': return <TestimonialLeaf p={p} />
    case 'alert': return <AlertLeaf p={p} />
    case 'accordion': return <AccordionLeaf p={p} />
    case 'animated-headline': return <AnimatedHeadlineLeaf p={p} />
    case 'code-highlight': return <CodeHighlightLeaf p={p} />
    default:
      return <div className="text-red-500 text-xs">Unknown widget: {node.widget}</div>
  }
}

/* -------------------------------------------------------------------------- */
/*  Leaf components (canvas-rendering versions, identical to WidgetRenderer)  */
/* -------------------------------------------------------------------------- */

interface LeafProps { p: Record<string, unknown> }

function HeadingLeaf({ p }: LeafProps) {
  const Tag = (p.tag as keyof JSX.IntrinsicElements) || 'h2'
  const style: React.CSSProperties = {
    textAlign: p.align as React.CSSProperties['textAlign'],
    color: p.color as string,
    margin: 0,
    ...typographyStyle(p.typography as Typography),
    ...spacingStyle(p.padding as Spacing, 'padding'),
    ...spacingStyle(p.margin as Spacing, 'margin'),
  }
  return <Tag style={style}>{String(p.text ?? '')}</Tag>
}

function TextLeaf({ p }: LeafProps) {
  const style: React.CSSProperties = {
    textAlign: p.align as React.CSSProperties['textAlign'],
    color: p.color as string,
    margin: 0,
    ...typographyStyle(p.typography as Typography),
    ...spacingStyle(p.padding as Spacing, 'padding'),
    ...spacingStyle(p.margin as Spacing, 'margin'),
  }
  return <p style={style}>{String(p.text ?? '')}</p>
}

function ButtonLeaf({ p }: LeafProps) {
  const [hover, setHover] = useState(false)
  const btnStyle: React.CSSProperties = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    textDecoration: 'none',
    background: hover ? (p.hoverBgColor as string) : (p.bgColor as string),
    color: p.textColor as string,
    borderRadius: p.borderRadius as string,
    width: p.width === '100%' ? '100%' : 'auto',
    border: 'none',
    cursor: 'pointer',
    transition: 'background .2s',
    ...typographyStyle(p.typography as Typography),
    ...spacingStyle(p.padding as Spacing, 'padding'),
  }
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: p.align as React.CSSProperties['justifyContent'],
        ...spacingStyle(p.margin as Spacing, 'margin'),
      }}
    >
      <a
        href={p.url as string}
        target={p.target as string}
        style={btnStyle}
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
      >
        {String(p.text ?? '')}
      </a>
    </div>
  )
}

function ImageLeaf({ p }: LeafProps) {
  return (
    <div
      style={{
        textAlign: p.align as React.CSSProperties['textAlign'],
        ...spacingStyle(p.margin as Spacing, 'margin'),
      }}
    >
      <figure style={{ margin: 0, display: 'inline-block', maxWidth: '100%' }}>
        <img
          src={p.src as string}
          alt={String(p.alt ?? '')}
          style={{
            width: p.width as string,
            maxWidth: p.maxWidth as string,
            height: p.height as string,
            objectFit: p.objectFit as React.CSSProperties['objectFit'],
            borderRadius: p.borderRadius as string,
            display: 'block',
          }}
        />
        {p.caption ? (
          <figcaption style={{ textAlign: 'center', marginTop: 8, color: '#64748b', fontSize: 14 }}>
            {String(p.caption)}
          </figcaption>
        ) : null}
      </figure>
    </div>
  )
}

function VideoLeaf({ p }: LeafProps) {
  return (
    <div
      style={{
        position: 'relative',
        aspectRatio: p.aspectRatio as string,
        borderRadius: p.borderRadius as string,
        overflow: 'hidden',
        ...spacingStyle(p.margin as Spacing, 'margin'),
      }}
    >
      <iframe
        src={p.url as string}
        style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', border: 0 }}
        allowFullScreen
      />
    </div>
  )
}

function DividerLeaf({ p }: LeafProps) {
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: p.align as React.CSSProperties['justifyContent'],
        ...spacingStyle(p.margin as Spacing, 'margin'),
      }}
    >
      <hr
        style={{
          border: 0,
          borderTop: `${p.thickness} solid ${p.color}`,
          width: `${p.width}%`,
          margin: 0,
        }}
      />
    </div>
  )
}

function SpacerLeaf({ p }: LeafProps) {
  return <div style={{ height: p.height as string }} />
}

function IconLeaf({ p }: LeafProps) {
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: p.align as React.CSSProperties['justifyContent'],
        ...spacingStyle(p.margin as Spacing, 'margin'),
      }}
    >
      <DynamicIcon
        name={String(p.icon ?? 'Star')}
        style={{ fontSize: p.size as string, color: p.color as string, width: p.size as string, height: p.size as string }}
      />
    </div>
  )
}

function IconBoxLeaf({ p }: LeafProps) {
  const flexDir =
    p.position === 'top' ? 'column' : p.position === 'right' ? 'row-reverse' : 'row'
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: flexDir as React.CSSProperties['flexDirection'],
        alignItems: 'center',
        gap: 16,
        textAlign: p.align as React.CSSProperties['textAlign'],
        background: p.bgColor as string,
        borderRadius: p.borderRadius as string,
        ...spacingStyle(p.padding as Spacing, 'padding'),
      }}
    >
      <DynamicIcon
        name={String(p.icon ?? 'Rocket')}
        style={{
          fontSize: p.iconSize as string,
          color: p.iconColor as string,
          width: p.iconSize as string,
          height: p.iconSize as string,
          flexShrink: 0,
        }}
      />
      <div>
        <h4 style={{ margin: '0 0 6px', color: p.titleColor as string, fontSize: 18, fontWeight: 600 }}>
          {String(p.title ?? '')}
        </h4>
        <p style={{ margin: 0, color: p.descColor as string, fontSize: 14 }}>
          {String(p.description ?? '')}
        </p>
      </div>
    </div>
  )
}

function ImageBoxLeaf({ p }: LeafProps) {
  return (
    <div
      style={{
        overflow: 'hidden',
        background: p.bgColor as string,
        borderRadius: p.borderRadius as string,
        ...spacingStyle(p.padding as Spacing, 'padding'),
      }}
    >
      <img
        src={p.src as string}
        alt=""
        style={{ width: '100%', height: p.imageHeight as string, objectFit: 'cover', display: 'block' }}
      />
      <div style={{ padding: 16 }}>
        <h4 style={{ margin: '0 0 6px', color: p.titleColor as string, fontSize: 18, fontWeight: 600 }}>
          {String(p.title ?? '')}
        </h4>
        <p style={{ margin: 0, color: p.descColor as string, fontSize: 14 }}>
          {String(p.description ?? '')}
        </p>
      </div>
    </div>
  )
}

function CTALeaf({ p }: LeafProps) {
  return (
    <div
      style={{
        textAlign: p.align as React.CSSProperties['textAlign'],
        background: p.bgColor as string,
        borderRadius: p.borderRadius as string,
        ...spacingStyle(p.padding as Spacing, 'padding'),
      }}
    >
      <h2 style={{ margin: '0 0 12px', color: p.titleColor as string, fontSize: 32 }}>{String(p.title ?? '')}</h2>
      <p style={{ margin: '0 0 20px', color: p.descColor as string, fontSize: 16 }}>{String(p.description ?? '')}</p>
      <a
        href={p.buttonUrl as string}
        style={{
          display: 'inline-block',
          background: p.buttonBg as string,
          color: p.buttonText as string,
          padding: '12px 28px',
          borderRadius: 8,
          textDecoration: 'none',
          fontWeight: 600,
        }}
      >
        {String(p.buttonText ?? '')}
      </a>
    </div>
  )
}

function FlipBoxLeaf({ p }: LeafProps) {
  return (
    <div style={{ perspective: 1000, height: p.height as string }}>
      <div className="group/flip" style={{ position: 'relative', width: '100%', height: '100%', transition: 'transform .6s', transformStyle: 'preserve-3d' }}>
        <div
          className="group-hover/flip:[transform:rotateY(180deg)]"
          style={{ position: 'absolute', inset: 0, backfaceVisibility: 'hidden', background: p.frontBg as string, color: p.frontTextColor as string, borderRadius: p.borderRadius as string, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 24 }}
        >
          <DynamicIcon name={String(p.frontIcon ?? 'Bulb')} style={{ width: 48, height: 48 }} />
          <h3 style={{ margin: '12px 0 8px' }}>{String(p.frontTitle ?? '')}</h3>
          <p style={{ margin: 0 }}>{String(p.frontDesc ?? '')}</p>
        </div>
        <div
          className="group-hover/flip:[transform:rotateY(180deg)]"
          style={{ position: 'absolute', inset: 0, backfaceVisibility: 'hidden', transform: 'rotateY(180deg)', background: p.backBg as string, color: p.backTextColor as string, borderRadius: p.borderRadius as string, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 24 }}
        >
          <h3 style={{ margin: '0 0 8px' }}>{String(p.backTitle ?? '')}</h3>
          <p style={{ margin: '0 0 16px' }}>{String(p.backDesc ?? '')}</p>
          <a
            href={p.backButtonUrl as string}
            style={{ display: 'inline-block', padding: '8px 20px', border: '2px solid currentColor', borderRadius: 6, textDecoration: 'none' }}
          >
            {String(p.backButtonText ?? '')}
          </a>
        </div>
      </div>
    </div>
  )
}

function TestimonialLeaf({ p }: LeafProps) {
  const rating = Number(p.rating || 0)
  return (
    <div
      style={{
        background: p.bgColor as string,
        textAlign: p.align as React.CSSProperties['textAlign'],
        borderRadius: p.borderRadius as string,
        ...spacingStyle(p.padding as Spacing, 'padding'),
      }}
    >
      <div style={{ color: p.starColor as string, fontSize: 18, marginBottom: 12 }}>
        {'★'.repeat(rating)}{'☆'.repeat(5 - rating)}
      </div>
      <blockquote style={{ margin: '0 0 16px', color: p.textColor as string, fontSize: 16, fontStyle: 'italic' }}>
        “{String(p.quote ?? '')}”
      </blockquote>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          justifyContent: p.align === 'center' ? 'center' : 'flex-start',
        }}
      >
        <img
          src={p.avatar as string}
          alt=""
          style={{ width: 48, height: 48, borderRadius: '50%', objectFit: 'cover' }}
        />
        <div>
          <div style={{ color: p.nameColor as string, fontWeight: 600 }}>{String(p.name ?? '')}</div>
          <div style={{ color: p.roleColor as string, fontSize: 13 }}>{String(p.role ?? '')}</div>
        </div>
      </div>
    </div>
  )
}

function AlertLeaf({ p }: LeafProps) {
  const colors: Record<string, { bg: string; border: string; text: string }> = {
    info: { bg: '#eff6ff', border: '#3b82f6', text: '#1e40af' },
    success: { bg: '#ecfdf5', border: '#10b981', text: '#065f46' },
    warning: { bg: '#fffbeb', border: '#f59e0b', text: '#92400e' },
    error: { bg: '#fef2f2', border: '#ef4444', text: '#991b1b' },
  }
  const v = colors[String(p.variant)] || colors.info
  return (
    <div
      style={{
        display: 'flex',
        gap: 12,
        alignItems: 'flex-start',
        background: v.bg,
        borderLeft: `4px solid ${v.border}`,
        color: v.text,
        borderRadius: p.borderRadius as string,
        ...spacingStyle(p.padding as Spacing, 'padding'),
        ...spacingStyle(p.margin as Spacing, 'margin'),
      }}
    >
      <DynamicIcon name={String(p.icon ?? 'Info')} style={{ width: 20, height: 20, flexShrink: 0, marginTop: 2 }} />
      <div>
        <strong style={{ display: 'block', marginBottom: 4 }}>{String(p.title ?? '')}</strong>
        <span style={{ fontSize: 14 }}>{String(p.description ?? '')}</span>
      </div>
    </div>
  )
}

function AccordionLeaf({ p }: LeafProps) {
  const items = String(p.items ?? '')
    .split('\n')
    .map((l) => l.split('|'))
    .filter((parts) => parts.length >= 2)
  return (
    <div style={{ ...spacingStyle(p.margin as Spacing, 'margin') }}>
      {items.map((it, i) => {
        const title = it[0].trim()
        const body = it.slice(1).join('|').trim()
        return (
          <details
            key={i}
            open={(p.firstOpen as boolean) && i === 0}
            style={{ marginBottom: 8, borderRadius: p.borderRadius as string, overflow: 'hidden' }}
          >
            <summary
              style={{
                background: p.headerBgColor as string,
                color: p.headerTextColor as string,
                padding: '14px 18px',
                cursor: 'pointer',
                fontWeight: 500,
                listStyle: 'none',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}
            >
              {title}
              <ChevronDown style={{ width: 16, height: 16 }} />
            </summary>
            <div style={{ background: p.bgColor as string, color: p.bodyTextColor as string, padding: '14px 18px', fontSize: 14 }}>
              {body}
            </div>
          </details>
        )
      })}
    </div>
  )
}

function AnimatedHeadlineLeaf({ p }: LeafProps) {
  const words = String(p.rotating ?? '').split(',').map((w) => w.trim()).filter(Boolean)
  const [idx, setIdx] = useState(0)
  // Rotate every 2s
  if (typeof window !== 'undefined' && words.length > 0) {
    setTimeout(() => setIdx((i) => (i + 1) % Math.max(words.length, 1)), 2000)
  }
  const Tag = (p.tag as keyof JSX.IntrinsicElements) || 'h2'
  const style: React.CSSProperties = {
    textAlign: p.align as React.CSSProperties['textAlign'],
    color: p.textColor as string,
    margin: 0,
    ...typographyStyle(p.typography as Typography),
    ...spacingStyle(p.margin as Spacing, 'margin'),
  }
  return (
    <Tag style={style}>
      {String(p.before ?? '')}
      <span style={{ color: p.highlightColor as string }}>
        {words[idx] ?? ''}
      </span>
      {String(p.after ?? '')}
    </Tag>
  )
}

function CodeHighlightLeaf({ p }: LeafProps) {
  const isDark = p.theme === 'dark'
  const bg = isDark ? '#1e1e1e' : '#f8fafc'
  const fg = isDark ? '#d4d4d4' : '#0f172a'
  return (
    <pre
      style={{
        background: bg,
        color: fg,
        padding: 18,
        borderRadius: p.borderRadius as string,
        overflow: 'auto',
        fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
        fontSize: 13,
        lineHeight: 1.6,
        ...spacingStyle(p.margin as Spacing, 'margin'),
      }}
    >
      <code data-lang={p.language as string}>{String(p.code ?? '')}</code>
    </pre>
  )
}
