'use client'

import { useEffect, useState } from 'react'
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragStartEvent,
} from '@dnd-kit/core'
import { TopBar } from './TopBar'
import { WidgetPalette } from './WidgetPalette'
import { Canvas } from './Canvas'
import { Inspector } from './Inspector'
import { useEditorStore } from '@/store/editorStore'
import { widgetMap } from '@/lib/page-builder/widgets'
import type { ElementNode } from '@/lib/page-builder/types'
import { DynamicIcon } from './DynamicIcon'
import { Layout, Settings, Boxes } from 'lucide-react'

type MobilePanel = 'palette' | 'canvas' | 'inspector'

export function Editor() {
  const tree = useEditorStore((s) => s.tree)
  const insertWidget = useEditorStore((s) => s.insertWidget)
  const moveElement = useEditorStore((s) => s.moveElement)
  const selectedId = useEditorStore((s) => s.selectedId)

  // پنل فعال در موبایل/تبلت
  const [mobilePanel, setMobilePanel] = useState<MobilePanel>('canvas')
  const [activeDrag, setActiveDrag] = useState<
    | { kind: 'palette'; widgetType: string }
    | { kind: 'existing'; node: ElementNode }
    | null
  >(null)

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: { distance: 6 },
    }),
  )

  // وقتی عنصری انتخاب شد، در موبایل به‌طور خودکار به inspector برو
  useEffect(() => {
    if (selectedId) {
      setMobilePanel('inspector')
    }
  }, [selectedId])

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName
      if (tag === 'INPUT' || tag === 'TEXTAREA' || (e.target as HTMLElement)?.isContentEditable) return
      const s = useEditorStore.getState()
      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (s.selectedId) {
          e.preventDefault()
          s.deleteElement(s.selectedId)
        }
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z' && !e.shiftKey) {
        e.preventDefault()
        s.undo()
      } else if ((e.ctrlKey || e.metaKey) && (e.key.toLowerCase() === 'y' || (e.key.toLowerCase() === 'z' && e.shiftKey))) {
        e.preventDefault()
        s.redo()
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'd' && s.selectedId) {
        e.preventDefault()
        s.duplicateElement(s.selectedId)
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault()
        const btn = document.querySelector<HTMLButtonElement>('button[title="Save"]') ||
                    document.querySelectorAll('header button')[
                      Array.from(document.querySelectorAll('header button')).findIndex((b) => b.textContent?.includes('Save'))
                    ]
        if (btn) btn.click()
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [])

  function handleDragStart(e: DragStartEvent) {
    const data = e.active.data.current as
      | { type: 'palette'; widgetType: string }
      | { type: 'existing'; node: ElementNode; parentId: string | null; index: number }
      | undefined
    if (!data) return
    if (data.type === 'palette') {
      setActiveDrag({ kind: 'palette', widgetType: data.widgetType })
    } else {
      setActiveDrag({ kind: 'existing', node: data.node })
    }
  }

  function handleDragEnd(e: DragEndEvent) {
    setActiveDrag(null)
    const { active, over } = e
    if (!over) return

    const activeData = active.data.current as
      | { type: 'palette'; widgetType: string }
      | { type: 'existing'; node: ElementNode; parentId: string | null; index: number }
      | undefined
    const overData = over.data.current as
      | { type: 'container'; parentId: string }
      | { type: 'canvas-root' }
      | undefined

    if (!activeData) return

    let targetParent: string | null = null
    let targetIndex = 999

    if (overData?.type === 'container') {
      targetParent = overData.parentId
    } else if (over.id === 'canvas-root') {
      targetParent = null
    } else {
      const overId = String(over.id)
      const { parent, node } = findInTree(tree, overId)
      if (node && parent) {
        targetParent = parent.find((n) => n.children.some((c) => c.id === overId))?.id ?? null
        targetIndex = parent.indexOf(node) + 1
      }
    }

    if (activeData.type === 'palette') {
      insertWidget(activeData.widgetType, targetParent, targetIndex)
    } else {
      if (activeData.parentId === targetParent) {
        const parent = targetParent
          ? (findInTree(tree, targetParent).node?.children ?? [])
          : tree
        const currentIndex = parent.findIndex((n) => n.id === activeData.node.id)
        if (currentIndex !== -1 && currentIndex < targetIndex) {
          targetIndex -= 1
        }
      }
      moveElement(activeData.node.id, targetParent, targetIndex)
    }
  }

  return (
    <DndContext
      sensors={sensors}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      onDragCancel={() => setActiveDrag(null)}
    >
      <div className="flex flex-col h-full w-full overflow-hidden bg-background">
        <TopBar />

        {/* === دسکتاپ: ۳ ستون === */}
        <div className="hidden lg:flex flex-1 min-h-0">
          <WidgetPalette />
          <Canvas />
          <Inspector />
        </div>

        {/* === موبایل/تبلت: ۱ پنل + نوار پایین === */}
        <div className="flex lg:hidden flex-1 min-h-0 relative">
          {/* WidgetPalette */}
          <div className="absolute inset-0" style={{ display: mobilePanel === 'palette' ? 'flex' : 'none' }}>
            <WidgetPalette />
          </div>

          {/* Canvas */}
          <div className="absolute inset-0" style={{ display: mobilePanel === 'canvas' ? 'flex' : 'none' }}>
            <Canvas />
          </div>

          {/* Inspector */}
          <div className="absolute inset-0" style={{ display: mobilePanel === 'inspector' ? 'flex' : 'none' }}>
            <Inspector />
          </div>
        </div>

        {/* نوار پایین موبایل/تبلت برای切换 بین پنل‌ها */}
        <div className="lg:hidden flex items-stretch border-t border-gray-200 bg-white shrink-0">
          <button
            onClick={() => setMobilePanel('palette')}
            className={`flex-1 flex flex-col items-center justify-center gap-1 py-2.5 transition-colors ${
              mobilePanel === 'palette' ? 'text-[#dc2626] bg-red-50' : 'text-gray-500'
            }`}
          >
            <Boxes className="w-5 h-5" />
            <span className="text-[10px] font-medium">ویجت‌ها</span>
          </button>
          <button
            onClick={() => setMobilePanel('canvas')}
            className={`flex-1 flex flex-col items-center justify-center gap-1 py-2.5 transition-colors ${
              mobilePanel === 'canvas' ? 'text-[#dc2626] bg-red-50' : 'text-gray-500'
            }`}
          >
            <Layout className="w-5 h-5" />
            <span className="text-[10px] font-medium">صفحه</span>
          </button>
          <button
            onClick={() => setMobilePanel('inspector')}
            className={`flex-1 flex flex-col items-center justify-center gap-1 py-2.5 transition-colors ${
              mobilePanel === 'inspector' ? 'text-[#dc2626] bg-red-50' : 'text-gray-500'
            }`}
          >
            <Settings className="w-5 h-5" />
            <span className="text-[10px] font-medium">تنظیمات</span>
          </button>
        </div>
      </div>

      <DragOverlay dropAnimation={null}>
        {activeDrag ? (
          <div className="bg-background border rounded-md shadow-lg p-2 flex items-center gap-2 text-sm">
            {activeDrag.kind === 'palette' ? (
              <>
                <DynamicIcon
                  name={widgetMap[activeDrag.widgetType]?.icon ?? 'Box'}
                  style={{ width: 14, height: 14 }}
                  className="text-primary"
                />
                <span className="font-medium">{widgetMap[activeDrag.widgetType]?.name}</span>
              </>
            ) : (
              <>
                <DynamicIcon
                  name={widgetMap[activeDrag.node.widget ?? '']?.icon ?? 'Box'}
                  style={{ width: 14, height: 14 }}
                  className="text-primary"
                />
                <span className="font-medium">
                  {widgetMap[activeDrag.node.widget ?? '']?.name ?? 'Element'}
                </span>
              </>
            )}
          </div>
        ) : null}
      </DragOverlay>
    </DndContext>
  )
}

/** Find a node and its parent array by id. */
function findInTree(
  tree: ElementNode[],
  id: string,
): { node: ElementNode | null; parent: ElementNode[] | null } {
  for (const node of tree) {
    if (node.id === id) return { node, parent: tree }
    if (node.children.length) {
      const found = findInTree(node.children, id)
      if (found.node) return found
    }
  }
  return { node: null, parent: null }
}
