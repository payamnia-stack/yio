'use client'

import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Slider } from '@/components/ui/slider'
import { Switch } from '@/components/ui/switch'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Plus } from 'lucide-react'
import type { FieldSchema, Spacing, Typography } from '@/lib/page-builder/types'

interface FieldProps {
  field: FieldSchema
  value: unknown
  onChange: (v: unknown) => void
}

export function Field({ field, value, onChange }: FieldProps) {
  switch (field.type) {
    case 'text':
    case 'url':
      return <TextField field={field} value={value} onChange={onChange} />
    case 'textarea':
      return <TextAreaField field={field} value={value} onChange={onChange} />
    case 'number':
      return <NumberField field={field} value={value} onChange={onChange} />
    case 'color':
      return <ColorField field={field} value={value} onChange={onChange} />
    case 'slider':
      return <SliderField field={field} value={value} onChange={onChange} />
    case 'select':
      return <SelectField field={field} value={value} onChange={onChange} />
    case 'switch':
      return <SwitchField field={field} value={value} onChange={onChange} />
    case 'icon':
      return <IconField field={field} value={value} onChange={onChange} />
    case 'image':
      return <ImageField field={field} value={value} onChange={onChange} />
    case 'spacing':
      return <SpacingField field={field} value={value} onChange={onChange} />
    case 'typography':
      return <TypographyField field={field} value={value} onChange={onChange} />
    default:
      return null
  }
}

function FieldLabel({ field }: { field: FieldSchema }) {
  return (
    <Label className="text-xs font-medium text-muted-foreground mb-1.5 block">
      {field.label}
    </Label>
  )
}

function TextField({ field, value, onChange }: FieldProps) {
  return (
    <div>
      <FieldLabel field={field} />
      <Input
        type="text"
        value={String(value ?? '')}
        onChange={(e) => onChange(e.target.value)}
        placeholder={field.hint}
        className="h-8 text-sm"
      />
    </div>
  )
}

function TextAreaField({ field, value, onChange }: FieldProps) {
  return (
    <div>
      <FieldLabel field={field} />
      <Textarea
        value={String(value ?? '')}
        onChange={(e) => onChange(e.target.value)}
        placeholder={field.hint}
        className="text-sm min-h-[80px] resize-y"
      />
    </div>
  )
}

function NumberField({ field, value, onChange }: FieldProps) {
  return (
    <div>
      <FieldLabel field={field} />
      <Input
        type="number"
        value={Number(value ?? 0)}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-8 text-sm"
      />
    </div>
  )
}

function ColorField({ field, value, onChange }: FieldProps) {
  const v = String(value ?? '#000000')
  const safe = v.startsWith('#') || v === 'transparent' ? v : '#000000'
  return (
    <div>
      <FieldLabel field={field} />
      <div className="flex items-center gap-2">
        <div className="relative h-8 w-10 rounded border border-input overflow-hidden shrink-0">
          <input
            type="color"
            value={safe === 'transparent' ? '#ffffff' : safe}
            onChange={(e) => onChange(e.target.value)}
            className="absolute inset-0 cursor-pointer opacity-0"
          />
          <div
            className="absolute inset-0 pointer-events-none"
            style={{ background: v }}
          />
        </div>
        <Input
          type="text"
          value={v}
          onChange={(e) => onChange(e.target.value)}
          className="h-8 text-sm font-mono"
        />
      </div>
    </div>
  )
}

function SliderField({ field, value, onChange }: FieldProps) {
  const v = Number(value ?? field.default ?? 0)
  return (
    <div>
      <div className="flex items-center justify-between mb-1.5">
        <Label className="text-xs font-medium text-muted-foreground">{field.label}</Label>
        <span className="text-xs tabular-nums text-foreground">{v}</span>
      </div>
      <Slider
        value={[v]}
        min={field.min ?? 0}
        max={field.max ?? 100}
        step={field.step ?? 1}
        onValueChange={(arr) => onChange(arr[0])}
        className="mt-2"
      />
    </div>
  )
}

function SelectField({ field, value, onChange }: FieldProps) {
  return (
    <div>
      <FieldLabel field={field} />
      <Select value={String(value ?? '')} onValueChange={onChange}>
        <SelectTrigger className="h-8 text-sm">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {field.options?.map((opt) => (
            <SelectItem key={opt.value} value={opt.value} className="text-sm">
              {opt.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}

function SwitchField({ field, value, onChange }: FieldProps) {
  return (
    <div className="flex items-center justify-between">
      <Label className="text-xs font-medium text-muted-foreground">{field.label}</Label>
      <Switch checked={Boolean(value)} onCheckedChange={onChange} />
    </div>
  )
}

function IconField({ field, value, onChange }: FieldProps) {
  // A simple text input for the lucide icon name; could be upgraded to a picker.
  return (
    <div>
      <FieldLabel field={field} />
      <Input
        type="text"
        value={String(value ?? '')}
        onChange={(e) => onChange(e.target.value)}
        placeholder="e.g. Star, Rocket, Heart"
        className="h-8 text-sm"
      />
    </div>
  )
}

function ImageField({ field, value, onChange }: FieldProps) {
  const v = String(value ?? '')
  return (
    <div>
      <FieldLabel field={field} />
      <div className="space-y-2">
        {v && (
          <div className="h-24 w-full rounded border border-input overflow-hidden bg-muted">
            <img src={v} alt="" className="h-full w-full object-cover" />
          </div>
        )}
        <div className="flex gap-2">
          <Input
            type="text"
            value={v}
            onChange={(e) => onChange(e.target.value)}
            placeholder="https://..."
            className="h-8 text-sm"
          />
          <label className="inline-flex h-8 items-center justify-center gap-1 rounded-md border border-input bg-background px-2.5 text-xs font-medium cursor-pointer hover:bg-accent">
            <Plus className="h-3 w-3" />
            URL
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={async (e) => {
                const file = e.target.files?.[0]
                if (!file) return
                const reader = new FileReader()
                reader.onload = () => onChange(String(reader.result))
                reader.readAsDataURL(file)
              }}
            />
          </label>
        </div>
      </div>
    </div>
  )
}

function SpacingField({ field, value, onChange }: FieldProps) {
  const sp = (value ?? field.default ?? { top: '0', right: '0', bottom: '0', left: '0' }) as Spacing
  const update = (k: keyof Spacing, v: string) => onChange({ ...sp, [k]: v })
  const keys: { k: keyof Spacing; label: string }[] = [
    { k: 'top', label: 'T' },
    { k: 'right', label: 'R' },
    { k: 'bottom', label: 'B' },
    { k: 'left', label: 'L' },
  ]
  return (
    <div>
      <FieldLabel field={field} />
      <div className="grid grid-cols-4 gap-1.5">
        {keys.map(({ k, label }) => (
          <div key={k} className="flex flex-col items-center gap-1">
            <span className="text-[10px] text-muted-foreground">{label}</span>
            <Input
              type="text"
              value={sp[k]}
              onChange={(e) => update(k, e.target.value)}
              className="h-7 text-xs text-center px-1"
            />
          </div>
        ))}
      </div>
    </div>
  )
}

function TypographyField({ field, value, onChange }: FieldProps) {
  const ty = (value ?? field.default ?? {}) as Typography
  const update = (k: keyof Typography, v: string) => onChange({ ...ty, [k]: v })
  return (
    <div className="space-y-2 rounded-md border border-input p-2.5">
      <Label className="text-xs font-medium text-muted-foreground">{field.label}</Label>
      <div className="grid grid-cols-2 gap-2">
        <div>
          <Label className="text-[10px] text-muted-foreground">Size</Label>
          <Input
            type="text"
            value={ty.size ?? ''}
            onChange={(e) => update('size', e.target.value)}
            className="h-7 text-xs"
          />
        </div>
        <div>
          <Label className="text-[10px] text-muted-foreground">Weight</Label>
          <Select value={ty.weight ?? '400'} onValueChange={(v) => update('weight', v)}>
            <SelectTrigger className="h-7 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {['300', '400', '500', '600', '700', '800', '900'].map((w) => (
                <SelectItem key={w} value={w}>{w}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-[10px] text-muted-foreground">Transform</Label>
          <Select value={ty.transform ?? 'none'} onValueChange={(v) => update('transform', v)}>
            <SelectTrigger className="h-7 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {['none', 'uppercase', 'lowercase', 'capitalize'].map((w) => (
                <SelectItem key={w} value={w}>{w}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-[10px] text-muted-foreground">Style</Label>
          <Select value={ty.style ?? 'normal'} onValueChange={(v) => update('style', v)}>
            <SelectTrigger className="h-7 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {['normal', 'italic'].map((w) => (
                <SelectItem key={w} value={w}>{w}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-[10px] text-muted-foreground">Line H.</Label>
          <Input
            type="text"
            value={ty.lineHeight ?? ''}
            onChange={(e) => update('lineHeight', e.target.value)}
            className="h-7 text-xs"
          />
        </div>
        <div>
          <Label className="text-[10px] text-muted-foreground">Letter Sp.</Label>
          <Input
            type="text"
            value={ty.letterSpacing ?? ''}
            onChange={(e) => update('letterSpacing', e.target.value)}
            className="h-7 text-xs"
          />
        </div>
      </div>
      <div>
        <Label className="text-[10px] text-muted-foreground">Font Family</Label>
        <Input
          type="text"
          value={ty.family ?? ''}
          onChange={(e) => update('family', e.target.value)}
          className="h-7 text-xs"
        />
      </div>
    </div>
  )
}
