import type { Spacing, Typography } from '@/lib/page-builder/types'

export function spacingStyle(s: Spacing | undefined, prop: 'padding' | 'margin'): React.CSSProperties {
  if (!s) return {}
  return {
    [prop]: `${s.top} ${s.right} ${s.bottom} ${s.left}`,
  } as React.CSSProperties
}

export function typographyStyle(t: Typography | undefined): React.CSSProperties {
  if (!t) return {}
  return {
    fontFamily: t.family,
    fontSize: t.size,
    fontWeight: t.weight,
    textTransform: t.transform,
    fontStyle: t.style,
    textDecoration: t.decoration,
    lineHeight: t.lineHeight,
    letterSpacing: t.letterSpacing,
  }
}
