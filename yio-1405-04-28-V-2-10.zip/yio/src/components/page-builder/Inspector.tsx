'use client'

import { useEditorStore } from '@/store/editorStore'
import { widgetMap } from '@/lib/page-builder/widgets'
import { findNode } from '@/lib/page-builder/tree'
import { Field } from './fields/Field'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { DynamicIcon } from './DynamicIcon'
import { MousePointer2, Sliders, Wrench, FileText } from 'lucide-react'
import type { FieldSchema } from '@/lib/page-builder/types'
import { useState, useMemo } from 'react'

export function Inspector() {
  const tree = useEditorStore((s) => s.tree)
  const selectedId = useEditorStore((s) => s.selectedId)
  const updateProps = useEditorStore((s) => s.updateProps)
  const pageName = useEditorStore((s) => s.pageName)
  const pageSlug = useEditorStore((s) => s.pageSlug)

  const [activeTab, setActiveTab] = useState('content')

  const selected = useMemo(
    () => (selectedId ? findNode(tree, selectedId).node : null),
    [tree, selectedId],
  )

  // Page settings (no selection)
  if (!selected) {
    return (
      <aside className="w-full lg:w-80 border-l bg-background flex flex-col shrink-0 h-full">
        <div className="p-3 border-b">
          <div className="flex items-center gap-2">
            <FileText className="h-4 w-4 text-muted-foreground" />
            <h2 className="text-sm font-semibold">Page Settings</h2>
          </div>
        </div>
        <ScrollArea className="flex-1">
          <div className="p-3 space-y-3">
            <div>
              <Label className="text-xs font-medium text-muted-foreground mb-1.5 block">Page Name</Label>
              <Input
                type="text"
                value={pageName}
                onChange={(e) => {
                  useEditorStore.setState({ pageName: e.target.value, isDirty: true })
                }}
                className="h-8 text-sm"
              />
            </div>
            <div>
              <Label className="text-xs font-medium text-muted-foreground mb-1.5 block">Slug</Label>
              <Input
                type="text"
                value={pageSlug}
                onChange={(e) => {
                  useEditorStore.setState({ pageSlug: e.target.value, isDirty: true })
                }}
                className="h-8 text-sm"
              />
            </div>
            <div className="rounded-md border bg-muted/30 p-3 text-xs text-muted-foreground leading-relaxed">
              Click an element on the canvas to edit its content and style, or drag a widget from the left palette onto the canvas.
            </div>
          </div>
        </ScrollArea>
      </aside>
    )
  }

  const def = selected.widget ? widgetMap[selected.widget] : null
  if (!def) return null

  const fieldsByGroup: Record<string, FieldSchema[]> = {
    content: def.fields.filter((f) => f.group === 'content'),
    style: def.fields.filter((f) => f.group === 'style'),
    advanced: def.fields.filter((f) => f.group === 'advanced'),
  }

  // Pick the active tab based on what's available
  const availableTabs = ['content', 'style', 'advanced'].filter((t) => fieldsByGroup[t]?.length)
  const currentTab = availableTabs.includes(activeTab) ? activeTab : availableTabs[0]

  return (
    <aside className="w-full lg:w-80 border-l bg-background flex flex-col shrink-0 h-full">
      {/* Element header */}
      <div className="p-3 border-b flex items-center gap-2">
        <div className="flex h-7 w-7 items-center justify-center rounded-md bg-primary/10 text-primary">
          <DynamicIcon name={def.icon} style={{ width: 14, height: 14 }} />
        </div>
        <div className="flex-1 min-w-0">
          <h2 className="text-sm font-semibold leading-tight">{def.name}</h2>
          <p className="text-[11px] text-muted-foreground leading-tight truncate">{def.description}</p>
        </div>
      </div>

      <Tabs value={currentTab} onValueChange={setActiveTab} className="flex-1 flex flex-col min-h-0">
        <TabsList className="grid w-full grid-cols-3 rounded-none border-b bg-transparent h-auto p-0">
          {availableTabs.includes('content') && (
            <TabsTrigger value="content" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent py-2 text-xs gap-1">
              <MousePointer2 className="h-3 w-3" /> Content
            </TabsTrigger>
          )}
          {availableTabs.includes('style') && (
            <TabsTrigger value="style" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent py-2 text-xs gap-1">
              <Sliders className="h-3 w-3" /> Style
            </TabsTrigger>
          )}
          {availableTabs.includes('advanced') && (
            <TabsTrigger value="advanced" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent py-2 text-xs gap-1">
              <Wrench className="h-3 w-3" /> Advanced
            </TabsTrigger>
          )}
        </TabsList>

        {availableTabs.map((tabKey) => (
          <TabsContent key={tabKey} value={tabKey} className="flex-1 mt-0 min-h-0">
            <ScrollArea className="h-full">
              <div className="p-3 space-y-3">
                {fieldsByGroup[tabKey].map((field) => (
                  <Field
                    key={field.key}
                    field={field}
                    value={selected.props[field.key]}
                    onChange={(v) => updateProps(selected.id, { [field.key]: v })}
                  />
                ))}
              </div>
            </ScrollArea>
          </TabsContent>
        ))}
      </Tabs>
    </aside>
  )
}
