// ماژول احراز هویت مشتری YIO
import { db } from '@/lib/db';
import { cookies } from 'next/headers';
import crypto from 'crypto';

const SESSION_DURATION = 30 * 24 * 60 * 60 * 1000; // ۳۰ روز

// هش رمز عبور
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
}

// بررسی رمز عبور
export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(':');
  if (!salt || !hash) return false;
  const newHash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return newHash === hash;
}

// ساخت توکن سشن
export function generateUserToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

// ساخت کد تایید ۶ رقمی
export function generateVerifyCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// ایجاد سشن کاربر
export async function createSession(userId: number, request?: any): Promise<string> {
  const token = generateUserToken();
  const expiresAt = new Date(Date.now() + SESSION_DURATION);

  // استخراج اطلاعات دستگاه از request
  let userAgent: string | undefined;
  let ipAddress: string | undefined;
  let deviceType: string | undefined;

  if (request) {
    try {
      // request می‌تواند NextRequest یا Request باشد
      const headers = request.headers;
      userAgent = headers.get('user-agent') || undefined;
      ipAddress = headers.get('x-forwarded-for')?.split(',')[0] || headers.get('x-real-ip') || undefined;

      // تشخیص نوع دستگاه
      if (userAgent) {
        if (/mobile/i.test(userAgent)) deviceType = 'mobile';
        else if (/tablet/i.test(userAgent)) deviceType = 'tablet';
        else deviceType = 'desktop';
      }
    } catch {}
  }

  await db.session.create({
    data: {
      userId,
      token,
      expiresAt,
      userAgent,
      ipAddress,
      deviceType,
    },
  });

  return token;
}

// بررسی اعتبار سشن کاربر
export async function getUserFromSession(): Promise<any | null> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('yio-user-token')?.value;
    if (!token) return null;

    const session = await db.session.findUnique({
      where: { token },
      include: { user: true },
    });

    if (!session) return null;
    if (session.expiresAt < new Date()) {
      await db.session.delete({ where: { id: session.id } });
      return null;
    }

    return session.user;
  } catch {
    return null;
  }
}

// دریافت توکن از کلاینت
export async function getUserToken(): Promise<string | undefined> {
  const cookieStore = await cookies();
  return cookieStore.get('yio-user-token')?.value;
}
