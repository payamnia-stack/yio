// سیستم broadcast اعلان‌ها به صورت real-time (مشابه stock-events)
export interface NotificationUpdate {
  userId: number;
  notification: {
    type: string;
    title: string;
    body?: string;
    link?: string;
    timestamp: number;
  };
}

type Subscriber = (update: NotificationUpdate) => void;

class NotificationEventEmitter {
  private subscribers = new Map<number, Set<Subscriber>>();

  subscribe(userId: number, callback: Subscriber): () => void {
    if (!this.subscribers.has(userId)) {
      this.subscribers.set(userId, new Set());
    }
    this.subscribers.get(userId)!.add(callback);
    return () => {
      this.subscribers.get(userId)?.delete(callback);
    };
  }

  broadcast(userId: number, notification: NotificationUpdate['notification']): void {
    const subs = this.subscribers.get(userId);
    if (!subs) return;
    for (const sub of subs) {
      try {
        sub({ userId, notification: { ...notification, timestamp: Date.now() } });
      } catch (e) {
        console.error('Notification subscriber error:', e);
      }
    }
  }
}

declare global {
  // eslint-disable-next-line no-var
  var __notifEmitter: NotificationEventEmitter | undefined;
}

export const notificationEmitter: NotificationEventEmitter =
  globalThis.__notifEmitter || (globalThis.__notifEmitter = new NotificationEventEmitter());

export function broadcastNotification(userId: number, notification: NotificationUpdate['notification']): void {
  notificationEmitter.broadcast(userId, notification);
}
