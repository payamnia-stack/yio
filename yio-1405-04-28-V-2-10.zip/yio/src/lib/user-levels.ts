// سیستم سطح‌بندی کاربران YIO
// 5 سطح: 1. ثبت‌نام اولیه | 2. اطلاعات تکمیلی | 3. خریدار فعال | 4. حرفه‌ای | 5. سازمانی

export interface UserLevelInfo {
  level: number;
  title: string;
  description: string;
  color: string;       // رنگ اصلی
  bgColor: string;     // رنگ پس‌زمینه برای badge
  icon: string;        // ایموجی
  perks: string[];     // مزایای این سطح
}

export const USER_LEVELS: UserLevelInfo[] = [
  {
    level: 1,
    title: 'تازه‌وارد',
    description: 'ثبت‌نام اولیه با موبایل یا ایمیل',
    color: 'text-gray-600',
    bgColor: 'bg-gray-100',
    icon: '🌱',
    perks: ['ثبت‌نام و ورود', 'افزودن به علاقه‌مندی‌ها', 'مشاهده محصولات'],
  },
  {
    level: 2,
    title: 'تکمیل‌شده',
    description: 'اطلاعات کامل برای سفارش و ارسال',
    color: 'text-blue-600',
    bgColor: 'bg-blue-100',
    icon: '📝',
    perks: ['ثبت سفارش', 'پیگیری سفارش', 'ذخیره آدرس'],
  },
  {
    level: 3,
    title: 'فعال',
    description: 'خرید انجام شده + ثبت نظر و رضایت',
    color: 'text-green-600',
    bgColor: 'bg-green-100',
    icon: '⭐',
    perks: ['امتیاز وفاداری', 'تخفیف ویژه', 'اولویت در پاسخگویی'],
  },
  {
    level: 4,
    title: 'حرفه‌ای',
    description: 'خریدار حرفه‌ای با سقف خرید قابل تنظیم',
    color: 'text-purple-600',
    bgColor: 'bg-purple-100',
    icon: '💎',
    perks: ['خرید اقساطی', 'سقف خرید بالا', 'تخفیف اختصاصی', 'پشتیبانی VIP'],
  },
  {
    level: 5,
    title: 'سازمانی',
    description: 'مشتری عمده و سازمانی',
    color: 'text-amber-600',
    bgColor: 'bg-amber-100',
    icon: '🏢',
    perks: ['قیمت عمده', 'تخفیف حجمی', 'فاکتور رسمی', 'نمایندگی'],
  },
];

export function getUserLevel(level: number): UserLevelInfo {
  return USER_LEVELS.find(l => l.level === level) || USER_LEVELS[0];
}

// محاسبه سطح کاربر بر اساس داده‌های او
// این تابع در API profile و در زمان آپدیت اطلاعات فراخوانی می‌شود
export interface UserLevelData {
  hasVerifiedContact: boolean;  // موبایل یا ایمیل تایید شده
  hasShippingInfo: boolean;     // اطلاعات ارسال کامل
  hasPurchase: boolean;         // حداقل یک سفارش موفق
  hasReview: boolean;           // حداقل یک نظر ثبت شده
  hasSatisfactionMedia: boolean; // عکس/ویدیو رضایت
  orderCount: number;
  totalSpent: number;
  isWholesale: boolean;
  installmentLimit?: number | null;
  companyName?: string | null;
  // تنظیمات قابل پیکربندی از پنل ادمین
  level4OrderThreshold?: number;  // حداقل تعداد سفارش برای سطح 4
  level4SpentThreshold?: number;  // حداقل مبلغ خرید برای سطح 4
  level4InstallmentLimit?: number; // سقف اقساط پیش‌فرض
}

export function calculateUserLevel(data: UserLevelData): number {
  // سطح 5: مشتری سازمانی
  if (data.isWholesale || data.companyName) {
    return 5;
  }

  // سطح 4: حرفه‌ای - دارای سقف خرید اقساطی یا تعداد خرید بالا
  if (
    data.installmentLimit ||
    (data.orderCount >= (data.level4OrderThreshold || 10) &&
     data.totalSpent >= (data.level4SpentThreshold || 5000000))
  ) {
    return 4;
  }

  // سطح 3: فعال - خرید + ثبت نظر/رضایت
  if (data.hasPurchase && (data.hasReview || data.hasSatisfactionMedia)) {
    return 3;
  }

  // سطح 2: تکمیل‌شده - اطلاعات ارسال کامل
  if (data.hasShippingInfo) {
    return 2;
  }

  // سطح 1: تازه‌وارد - فقط ثبت‌نام
  if (data.hasVerifiedContact) {
    return 1;
  }

  return 1;
}

// متن راهنما برای ارتقاء به سطح بعدی
export function getNextLevelHint(currentLevel: number): string | null {
  if (currentLevel >= 5) return null;

  const hints: Record<number, string> = {
    1: 'برای ارتقاء به سطح ۲، اطلاعات کامل خود (نام، آدرس، کد پستی) را در تب اطلاعات کاربری تکمیل کنید',
    2: 'برای ارتقاء به سطح ۳، اولین خرید خود را انجام دهید و نظر خود را درباره محصول ثبت کنید',
    3: 'برای ارتقاء به سطح ۴ (حرفه‌ای)، خریدهای بیشتری انجام دهید تا سقف خرید اقساطی فعال شود',
    4: 'برای ارتقاء به سطح ۵ (سازمانی)، با پشتیبانی تماس بگیرید تا حساب شما به حالت سازمانی تبدیل شود',
  };

  return hints[currentLevel] || null;
}

// درصد پیشرفت برای نمایش در اسلایدر
export function getLevelProgress(data: UserLevelData, currentLevel: number): number {
  if (currentLevel >= 5) return 100;

  const progressMap: Record<number, number> = {
    1: data.hasShippingInfo ? 100 : (data.hasVerifiedContact ? 30 : 0),
    2: data.hasPurchase ? 80 : (data.hasShippingInfo ? 40 : 0),
    3: data.hasReview || data.hasSatisfactionMedia ? 90 : (data.hasPurchase ? 50 : 0),
    4: data.installmentLimit ? 100 : Math.min(80, (data.orderCount / (data.level4OrderThreshold || 10)) * 100),
  };

  return Math.min(100, Math.max(0, progressMap[currentLevel] || 0));
}
