// سیستم کیف پول و تراکنش‌های مالی
import { db } from '@/lib/db';

// دریافت یا ساخت کیف پول برای کاربر
export async function getOrCreateWallet(userId: number) {
  let wallet = await db.wallet.findUnique({ where: { userId } });
  if (!wallet) {
    wallet = await db.wallet.create({ data: { userId, balance: 0 } });
  }
  return wallet;
}

// افزایش موجودی کیف پول
export async function creditWallet(
  userId: number,
  amount: number,
  type: string,
  description?: string,
  orderId?: number,
  referralUserId?: number
): Promise<{ balance: number; transaction: any }> {
  if (amount <= 0) throw new Error('مبلغ باید مثبت باشد');

  const wallet = await getOrCreateWallet(userId);
  const newBalance = wallet.balance + amount;

  const transaction = await db.walletTransaction.create({
    data: {
      walletId: wallet.id,
      userId,
      type,
      amount: amount, // مثبت
      balance: newBalance,
      description: description || null,
      orderId: orderId || null,
      referralUserId: referralUserId || null,
    },
  });

  await db.wallet.update({
    where: { id: wallet.id },
    data: { balance: newBalance },
  });

  return { balance: newBalance, transaction };
}

// کاهش موجودی کیف پول
export async function debitWallet(
  userId: number,
  amount: number,
  type: string,
  description?: string,
  orderId?: number
): Promise<{ balance: number; transaction: any }> {
  if (amount <= 0) throw new Error('مبلغ باید مثبت باشد');

  const wallet = await getOrCreateWallet(userId);
  if (wallet.balance < amount) {
    throw new Error('موجودی کیف پول کافی نیست');
  }

  const newBalance = wallet.balance - amount;

  const transaction = await db.walletTransaction.create({
    data: {
      walletId: wallet.id,
      userId,
      type,
      amount: -amount, // منفی
      balance: newBalance,
      description: description || null,
      orderId: orderId || null,
    },
  });

  await db.wallet.update({
    where: { id: wallet.id },
    data: { balance: newBalance },
  });

  return { balance: newBalance, transaction };
}

// پاداش ارجاع: وقتی کاربر جدیدی با کد ارجاع ثبت‌نام می‌کنه
// به معرفی‌کننده پاداش داده می‌شه
export async function processReferralBonus(
  referrerId: number,
  newUserId: number,
  bonusAmount: number = 50000 // ۵۰ هزار تومان پیش‌فرض
): Promise<void> {
  try {
    // پاداش به معرفی‌کننده
    await creditWallet(
      referrerId,
      bonusAmount,
      'referral_bonus',
      `پاداش دعوت دوست (کاربر جدید: ${newUserId})`,
      undefined,
      newUserId
    );

    // ایجاد اعلان برای معرفی‌کننده
    const { createNotification } = await import('@/lib/notifications');
    await createNotification({
      userId: referrerId,
      type: 'referral',
      title: '🎉 پاداش دعوت دوست!',
      body: `مبلغ ${bonusAmount.toLocaleString('fa-IR')} تومان به کیف پول شما اضافه شد.`,
      link: '/profile?tab=wallet',
      data: { bonusAmount, newUserId },
    });

    // پاداش به کاربر جدید هم (اختیاری)
    await creditWallet(
      newUserId,
      Math.floor(bonusAmount / 2), // نصف مبلغ برای کاربر جدید
      'referral_bonus',
      `پاداش ثبت‌نام با کد معرفی`,
      undefined,
      referrerId
    );
  } catch (error) {
    console.error('Referral bonus error:', error);
  }
}

// تولید کد ارجاع یکتا
export function generateReferralCode(name?: string): string {
  const prefix = name ? name.slice(0, 3).toUpperCase() : 'YIO';
  const random = Math.floor(1000 + Math.random() * 9000);
  return `${prefix}${random}`;
}
