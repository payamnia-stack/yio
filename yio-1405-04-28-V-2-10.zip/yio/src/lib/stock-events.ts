// سیستم broadcast آپدیت‌های موجودی به صورت real-time
// از Server-Sent Events (SSE) استفاده می‌کنیم

export interface StockUpdate {
  productId: number;
  stockQuantity: number;
  inStock: boolean;
  timestamp: number;
}

type Subscriber = (update: StockUpdate) => void;

class StockEventEmitter {
  private subscribers = new Set<Subscriber>();

  subscribe(callback: Subscriber): () => void {
    this.subscribers.add(callback);
    return () => {
      this.subscribers.delete(callback);
    };
  }

  broadcast(update: StockUpdate): void {
    // ارسال به همه subscriberها
    for (const sub of this.subscribers) {
      try {
        sub(update);
      } catch (e) {
        console.error('Stock event subscriber error:', e);
      }
    }
  }

  getSubscriberCount(): number {
    return this.subscribers.size;
  }
}

// در Next.js dev mode، module ممکن است reload شود.
// برای حفظ subscribers در طول session، از global استفاده می‌کنیم.
declare global {
  // eslint-disable-next-line no-var
  var __stockEmitter: StockEventEmitter | undefined;
}

export const stockEmitter: StockEventEmitter =
  globalThis.__stockEmitter || (globalThis.__stockEmitter = new StockEventEmitter());

// تابع کمکی برای broadcast آپدیت موجودی
export function broadcastStockUpdate(productId: number, stockQuantity: number): void {
  stockEmitter.broadcast({
    productId,
    stockQuantity,
    inStock: stockQuantity > 0,
    timestamp: Date.now(),
  });
}
