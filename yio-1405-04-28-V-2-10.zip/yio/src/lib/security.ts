// ماژول امنیتی YIO - رمزنگاری، Rate Limit، CSRF، Input Validation
import crypto from 'crypto';
import { db } from '@/lib/db';
import { headers } from 'next/headers';
import { NextRequest } from 'next/server';

// کلید رمزنگاری - در محیط تولید حتما در env ذخیره شود
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'yio-shop-encryption-key-32bytes!';
const ALGORITHM = 'aes-256-cbc';

// === رمزنگاری اطلاعات حساس ===
export function encrypt(text: string): string {
  try {
    const iv = crypto.randomBytes(16);
    const key = Buffer.from(ENCRYPTION_KEY.slice(0, 32), 'utf8');
    const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return iv.toString('hex') + ':' + encrypted;
  } catch (e) {
    console.error('Encryption error:', e);
    return text;
  }
}

export function decrypt(encryptedText: string): string {
  try {
    if (!encryptedText || !encryptedText.includes(':')) return encryptedText;
    const parts = encryptedText.split(':');
    const iv = Buffer.from(parts[0], 'hex');
    const encrypted = parts[1];
    const key = Buffer.from(ENCRYPTION_KEY.slice(0, 32), 'utf8');
    const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (e) {
    console.error('Decryption error:', e);
    return '';
  }
}

// ماسک کردن اطلاعات حساس برای نمایش
export function maskSensitive(value: string | null | undefined): string {
  if (!value) return '';
  const len = value.length;
  if (len <= 4) return '••••';
  return value.slice(0, 4) + '•'.repeat(Math.max(4, len - 8)) + value.slice(-4);
};

// === Rate Limiting ===
const RATE_LIMIT_WINDOW = 60 * 1000; // ۱ دقیقه
const RATE_LIMIT_MAX_REQUESTS = 30; // حداکثر ۳۰ درخواست در دقیقه

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetAt: Date;
  blocked: boolean;
}

// گرفتن IP واقعی کاربر
export async function getClientIP(): Promise<string> {
  const headersList = await headers();
  const forwarded = headersList.get('x-forwarded-for');
  const realIP = headersList.get('x-real-ip');
  const cfConnecting = headersList.get('cf-connecting-ip');

  if (cfConnecting) return cfConnecting;
  if (realIP) return realIP;
  if (forwarded) return forwarded.split(',')[0].trim();
  return 'unknown';
}

// بررسی Rate Limit
export async function checkRateLimit(
  identifier: string,
  maxRequests: number = RATE_LIMIT_MAX_REQUESTS,
  windowMs: number = RATE_LIMIT_WINDOW
): Promise<RateLimitResult> {
  const now = new Date();
  const windowStart = new Date(now.getTime() - windowMs);

  try {
    // پاکسازی رکوردهای قدیمی
    await db.rateLimitEntry.deleteMany({
      where: {
        windowStart: { lt: windowStart },
        blocked: false,
      },
    });

    // جستجوی رکورد موجود
    const existing = await db.rateLimitEntry.findFirst({
      where: {
        key: identifier,
        windowStart: { gte: windowStart },
      },
    });

    // اگر قبلاً بلاک شده
    if (existing?.blocked && existing.blockedUntil && existing.blockedUntil > now) {
      return {
        allowed: false,
        remaining: 0,
        resetAt: existing.blockedUntil,
        blocked: true,
      };
    }

    if (existing) {
      if (existing.count >= maxRequests) {
        // بلاک کردن برای ۱۵ دقیقه
        const blockedUntil = new Date(now.getTime() + 15 * 60 * 1000);
        await db.rateLimitEntry.update({
          where: { id: existing.id },
          data: { blocked: true, blockedUntil },
        });

        return {
          allowed: false,
          remaining: 0,
          resetAt: blockedUntil,
          blocked: true,
        };
      }

      // افزایش شمارنده
      await db.rateLimitEntry.update({
        where: { id: existing.id },
        data: { count: { increment: 1 } },
      });

      return {
        allowed: true,
        remaining: maxRequests - existing.count - 1,
        resetAt: new Date(existing.windowStart.getTime() + windowMs),
        blocked: false,
      };
    }

    // ایجاد رکورد جدید
    await db.rateLimitEntry.create({
      data: {
        key: identifier,
        count: 1,
        windowStart: now,
      },
    });

    return {
      allowed: true,
      remaining: maxRequests - 1,
      resetAt: new Date(now.getTime() + windowMs),
      blocked: false,
    };
  } catch (e) {
    // در صورت خطا، اجازه بده (fail-open) ولی لاگ کن
    console.error('Rate limit error:', e);
    return { allowed: true, remaining: 0, resetAt: now, blocked: false };
  }
}

// Rate limit برای endpoint حساس
export async function enforceRateLimit(
  request: NextRequest,
  endpoint: string,
  maxRequests: number = 30
): Promise<{ allowed: boolean; response?: any }> {
  const ip = await getClientIP();
  const identifier = `${ip}:${endpoint}`;

  const result = await checkRateLimit(identifier, maxRequests);

  if (!result.allowed) {
    return {
      allowed: false,
      response: new Response(
        JSON.stringify({
          error: 'درخواست‌های بیش از حد. لطفاً بعداً تلاش کنید.',
          retryAfter: Math.ceil((result.resetAt.getTime() - Date.now()) / 1000),
        }),
        {
          status: 429,
          headers: {
            'Content-Type': 'application/json',
            'Retry-After': String(Math.ceil((result.resetAt.getTime() - Date.now()) / 1000)),
          },
        }
      ),
    };
  }

  return { allowed: true };
}

// === CSRF Protection ===
// تولید توکن CSRF
export function generateCSRFToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

// هش CSRF برای مقایسه
export function hashCSRFToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

// === اعتبارسنجی ورودی ===
// پاکسازی HTML برای جلوگیری از XSS
export function sanitizeInput(input: any): string {
  if (typeof input !== 'string') return '';
  return input
    .replace(/<script[^>]*>.*?<\/script>/gi, '')
    .replace(/<iframe[^>]*>.*?<\/iframe>/gi, '')
    .replace(/<object[^>]*>.*?<\/object>/gi, '')
    .replace(/<embed[^>]*>/gi, '')
    .replace(/javascript:/gi, '')
    .replace(/on\w+\s*=\s*"[^"]*"/gi, '')
    .replace(/on\w+\s*=\s*'[^']*'/gi, '')
    .replace(/<[^>]+>/g, '')
    .trim();
}

// اعتبارسنجی شماره موبایل ایرانی
export function validateIranMobile(phone: string): boolean {
  return /^09\d{9}$/.test(phone);
}

// اعتبارسنجی ایمیل
export function validateEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
}

// اعتبارسنجی URL
export function validateURL(url: string): boolean {
  try {
    const u = new URL(url);
    return ['http:', 'https:'].includes(u.protocol);
  } catch {
    return false;
  }
}

// اعتبارسنجی عدد صحیح مثبت
export function validatePositiveInt(value: any, min = 0, max = Number.MAX_SAFE_INTEGER): number | null {
  const n = parseInt(value);
  if (isNaN(n) || n < min || n > max) return null;
  return n;
}

// اعتبارسنجی رشته با طول محدود
export function validateString(value: any, minLen = 1, maxLen = 1000): string | null {
  if (typeof value !== 'string') return null;
  if (value.trim().length < minLen || value.length > maxLen) return null;
  return value.trim();
}

// اعتبارسنجی شماره کارت بانکی (الگوریتم Luhn)
export function validateBankCard(cardNumber: string): boolean {
  const cleaned = cardNumber.replace(/\D/g, '');
  if (cleaned.length < 16 || cleaned.length > 19) return false;

  let sum = 0;
  let isEven = false;
  for (let i = cleaned.length - 1; i >= 0; i--) {
    let digit = parseInt(cleaned[i]);
    if (isEven) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
    isEven = !isEven;
  }
  return sum % 10 === 0;
}

// === بررسی امنیتی رمز عبور قوی ===
export function validateStrongPassword(password: string): { valid: boolean; message: string } {
  if (password.length < 8) return { valid: false, message: 'رمز باید حداقل ۸ کاراکتر باشد' };
  if (password.length > 128) return { valid: false, message: 'رمز بیش از حد طولانی است' };
  if (!/[a-z]/.test(password)) return { valid: false, message: 'رمز باید شامل حروف کوچک باشد' };
  if (!/[A-Z]/.test(password)) return { valid: false, message: 'رمز باید شامل حروف بزرگ باشد' };
  if (!/\d/.test(password)) return { valid: false, message: 'رمز باید شامل عدد باشد' };
  if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) return { valid: false, message: 'رمز باید شامل کاراکتر ویژه باشد' };
  return { valid: true, message: 'رمز قوی است' };
}

// === تشخیص الگوهای مشکوک ===
const SQL_INJECTION_PATTERNS = [
  /(\b(union|select|insert|update|delete|drop|create|alter|exec|execute)\b.*\b(from|into|table|database)\b)/i,
  /('|\")\s*(or|and)\s*('|\")?\s*\d+\s*=\s*\d+/i,
  /;\s*(drop|delete|update|insert|create|alter)/i,
  /--\s*$/m,
  /\/\*.*\*\//,
  /\bwaitfor\s+delay\b/i,
  /\bxp_cmdshell\b/i,
];

const XSS_PATTERNS = [
  /<script[^>]*>/i,
  /javascript:/i,
  /on\w+\s*=\s*['"]?[^'"]*['"]?/i,
  /<iframe[^>]*>/i,
  /<embed[^>]*>/i,
  /<object[^>]*>/i,
  /data:text\/html/i,
];

export function detectSQLInjection(input: string): boolean {
  if (typeof input !== 'string') return false;
  return SQL_INJECTION_PATTERNS.some(pattern => pattern.test(input));
}

export function detectXSS(input: string): boolean {
  if (typeof input !== 'string') return false;
  return XSS_PATTERNS.some(pattern => pattern.test(input));
}

// بررسی کلی امنیت ورودی
export function securityCheck(input: any): { safe: boolean; reason?: string } {
  if (typeof input === 'string') {
    if (detectSQLInjection(input)) {
      return { safe: false, reason: 'الگوی SQL Injection شناسایی شد' };
    }
    if (detectXSS(input)) {
      return { safe: false, reason: 'الگوی XSS شناسایی شد' };
    }
  }
  if (typeof input === 'object' && input !== null) {
    for (const key in input) {
      const result = securityCheck(input[key]);
      if (!result.safe) return result;
    }
  }
  return { safe: true };
}

// === ساخت توکن CSRF و تنظیم کوکی ===
export async function setCSRFToken(): Promise<string> {
  const token = generateCSRFToken();
  const hashedToken = hashCSRFToken(token);

  // در محیط واقعی باید در کوکی httpOnly ذخیره شود
  // در اینجا فقط توکن برمی‌گردد
  return token;
}

// === اعتبارسنجی Origin/Referer برای POST/PUT/DELETE ===
export async function validateOrigin(request: NextRequest): Promise<boolean> {
  const headersList = await headers();
  const origin = headersList.get('origin');
  const referer = headersList.get('referer');
  const host = headersList.get('host');

  if (!host) return false;

  const allowedOrigins = [`http://${host}`, `https://${host}`];

  // برای APIهای حساس، origin یا referer باید مطابقت داشته باشد
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    if (origin && !allowedOrigins.includes(origin)) {
      return false;
    }
    if (referer) {
      try {
        const refererUrl = new URL(referer);
        if (!allowedOrigins.includes(`${refererUrl.protocol}//${refererUrl.host}`)) {
          return false;
        }
      } catch {
        return false;
      }
    }
  }

  return true;
}
