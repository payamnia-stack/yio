// تایپ‌های مشترک فروشگاه YIO
export interface Product {
  id: number;
  title: string;
  brand: string;
  category: string;
  price: number;
  discountPrice?: number | null;
  discountPercent?: number | null;
  image: string;
  images?: string[] | string | null;
  videos?: string[] | string | null;
  rating: number;
  ratingCount: number;
  colors?: { name: string; code: string }[];
  inStock: boolean;
  stockQuantity?: number;
  fastDelivery?: boolean;
  isSpecial?: boolean;
  description?: string | null;
  woodType?: string | null;
  createdAt?: string;
  updatedAt?: string;
}

// اطلاعات Badge موجودی بر اساس تعداد
// 0 → قرمز (ناموجود) | 1 → نارنجی | 2-6 → زرد | 7+ → سبز
// استایل: فقط متن رنگی بدون پس‌زمینه (برای ظاهر تمیزتر)
export interface StockBadgeInfo {
  label: string;        // برچسب کوتاه (مثلا "موجود" یا "ناموجود")
  countLabel: string;   // برچسب با تعداد (مثلا "۳ عدد در انبار")
  textClass: string;    // رنگ متن اصلی
  dotClass: string;     // رنگ نقطه نشانگر (همرنگ متن)
  isOutOfStock: boolean;
}

export const getStockBadge = (stock: number | null | undefined): StockBadgeInfo => {
  const qty = typeof stock === 'number' ? stock : 0;

  if (qty <= 0) {
    return {
      label: 'ناموجود',
      countLabel: 'ناموجود',
      textClass: 'text-red-600',
      dotClass: 'bg-red-500',
      isOutOfStock: true,
    };
  }
  if (qty === 1) {
    return {
      label: 'آخرین موجودی',
      countLabel: 'تنها یک عدد در انبار باقی مانده است',
      textClass: 'text-orange-600',
      dotClass: 'bg-orange-500',
      isOutOfStock: false,
    };
  }
  if (qty <= 6) {
    return {
      label: 'موجودی محدود',
      countLabel: `تنها ${toFa(qty)} عدد در انبار باقی مانده است`,
      textClass: 'text-yellow-700',
      dotClass: 'bg-yellow-500',
      isOutOfStock: false,
    };
  }
  return {
    label: 'موجود',
    countLabel: 'موجود در انبار',
    textClass: 'text-green-600',
    dotClass: 'bg-green-500',
    isOutOfStock: false,
  };
};

// آیا محصول واقعاً موجود است؟ (بر اساس تعداد موجودی، نه فیلد inStock)
export const isProductAvailable = (product: Product): boolean => {
  const qty = typeof product.stockQuantity === 'number' ? product.stockQuantity : (product.inStock ? 999 : 0);
  return qty > 0;
};

export interface Category {
  id: number;
  title: string;
  icon: string;
  color: string;
  subcategories?: string[];
}

export interface Brand {
  id: number;
  name: string;
  logo: string;
}

// دسته‌بندی‌های محصولات چوبی YIO
export const categories: Category[] = [
  { id: 1, title: "اسباب‌بازی چوبی", icon: "🧸", color: "#f59e0b", subcategories: ["ماشین چوبی", "پازل چوبی", "بلوک چوبی", "خانه عروسکی"] },
  { id: 2, title: "ظروف آشپزخانه", icon: "🍽️", color: "#84cc16", subcategories: ["بشقاب چوبی", "قاشق و چنگال", "تخته برش", "کاسه چوبی"] },
  { id: 3, title: "مبلمان چوبی", icon: "🪑", color: "#8b5cf6", subcategories: ["صندلی", "میز", "تاب", "کمد"] },
  { id: 4, title: "دکوراسیون چوبی", icon: "🖼️", color: "#dc2626", subcategories: ["تابلو", "آینه", "ساعت", "جعبه"] },
  { id: 5, title: "لوازم کودک", icon: "👶", color: "#06b6d4", subcategories: ["کرسی کودک", "میز تحریر", "اسباب‌بازی آموزشی"] },
  { id: 6, title: "هدیه و صنایع دستی", icon: "🎁", color: "#ec4899", subcategories: ["جعبه هدیه", "ساعت رومیزی", "مجسمه"] },
  { id: 7, title: "نقاشی و هنر", icon: "🎨", color: "#7c3aed", subcategories: ["پالت نقاشی", "استند", "قاب عکس"] },
  { id: 8, title: "باغ و حیاط", icon: "🌳", color: "#10b981", subcategories: ["گلدان چوبی", "حصار", "نیمکت"] },
];

// برندها (YIO فقط)
export const brands: Brand[] = [
  { id: 1, name: "YIO", logo: "/yio-logo.png" },
];

// بنرهای اسلایدر - متناسب با محصولات چوبی
export const banners = [
  {
    id: 1,
    title: "دنیای چوب YIO",
    subtitle: "محصولات چوبی دست‌ساز با کیفیت برتر",
    image: "",
    bgColor: "linear-gradient(135deg, #8b5cf6 0%, #5d4037 100%)",
  },
  {
    id: 2,
    title: "اسباب‌بازی‌های چوبی",
    subtitle: "ایمن و دوست‌داشتنی برای کودکان شما",
    image: "",
    bgColor: "linear-gradient(135deg, #f59e0b 0%, #b45309 100%)",
  },
  {
    id: 3,
    title: "ظروف چوبی بامبو",
    subtitle: "طبیعی، ضدباکتری و زیبا برای آشپزخانه شما",
    image: "",
    bgColor: "linear-gradient(135deg, #84cc16 0%, #365314 100%)",
  },
];

// قالب‌بندی قیمت
export const formatPrice = (price: number): string => {
  return price.toLocaleString('fa-IR');
};

// قالب‌بندی اعداد فارسی
export const toFa = (n: number | string): string => {
  const faDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(n).replace(/\d/g, d => faDigits[+d]);
};

// پارس کردن رنگ‌ها از JSON
export const parseColors = (colorsJson: string | null | undefined): { name: string; code: string }[] => {
  if (!colorsJson) return [];
  try {
    const parsed = typeof colorsJson === 'string' ? JSON.parse(colorsJson) : colorsJson;
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

// پارس کردن لیست تصاویر از JSON
export const parseImages = (imagesJson: string | string[] | null | undefined): string[] => {
  if (!imagesJson) return [];
  try {
    const parsed = typeof imagesJson === 'string' ? JSON.parse(imagesJson) : imagesJson;
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

// پارس کردن لیست ویدیوها از JSON
export const parseVideos = (videosJson: string | string[] | null | undefined): string[] => {
  if (!videosJson) return [];
  try {
    const parsed = typeof videosJson === 'string' ? JSON.parse(videosJson) : videosJson;
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

// گرفتن همه تصاویر یک محصول (شامل تصویر اصلی)
export const getAllProductImages = (product: Product): string[] => {
  const images = parseImages(product.images);
  if (images.length === 0 && product.image) {
    return [product.image];
  }
  // تصویر اصلی رو هم اضافه می‌کنیم اگر داخل لیست نیست
  if (product.image && !images.includes(product.image)) {
    return [product.image, ...images];
  }
  return images;
};

// وضعیت‌های سفارش
export const orderStatuses = [
  { value: 'pending', label: 'در انتظار تأیید', color: 'bg-amber-100 text-amber-700', icon: '⏳' },
  { value: 'confirmed', label: 'تأیید شده', color: 'bg-blue-100 text-blue-700', icon: '✓' },
  { value: 'shipping', label: 'در حال ارسال', color: 'bg-purple-100 text-purple-700', icon: '🚚' },
  { value: 'delivered', label: 'تحویل داده شده', color: 'bg-green-100 text-green-700', icon: '📦' },
  { value: 'cancelled', label: 'لغو شده', color: 'bg-red-100 text-red-700', icon: '✗' },
];

export const getOrderStatusInfo = (status: string) => {
  return orderStatuses.find(s => s.value === status) || orderStatuses[0];
};
