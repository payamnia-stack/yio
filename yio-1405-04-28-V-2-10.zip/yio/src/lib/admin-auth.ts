// ماژول احراز هویت مدیر YIO
import { db } from '@/lib/db';
import { cookies } from 'next/headers';
import crypto from 'crypto';

// رمز عبور مدیر
// اولویت ۱: ADMIN_PASSWORD_HASH (هش شده با فرمت salt:hash از pbkdf2-SHA512) — توصیه می‌شود
// اولویت ۲: ADMIN_PASSWORD (متنی ساده) — فقط برای محیط توسعه
// اولویت ۳: مقدار پیش‌فرض فقط برای محیط توسعه
const ADMIN_PASSWORD_ENV = process.env.ADMIN_PASSWORD;
const ADMIN_PASSWORD_HASH = process.env.ADMIN_PASSWORD_HASH;
const DEV_DEFAULT_PASSWORD = 'yio-admin-1403';

const SESSION_DURATION = 24 * 60 * 60 * 1000; // ۲۴ ساعت

// تولید توکن امن
export function generateToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

// هش رمز عبور با pbkdf2-SHA512 (مشابه user-auth.ts)
// خروجی: "salt:hash"
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
}

// بررسی رمز عبور در برابر هش ذخیره شده
export function verifyPasswordHash(password: string, stored: string): boolean {
  try {
    const [salt, hash] = stored.split(':');
    if (!salt || !hash) return false;
    const newHash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
    // استفاده از compareSync برای جلوگیری از timing attack
    return crypto.timingSafeEqual(Buffer.from(newHash, 'hex'), Buffer.from(hash, 'hex'));
  } catch {
    return false;
  }
}

// بررسی رمز عبور — ساده‌سازی شده برای پشتیبانی از هر دو حالت هش و متن ساده
export function verifyPassword(password: string): boolean {
  // حالت ۱: اگر هش تنظیم شده باشد، فقط آن را بررسی می‌کنیم
  if (ADMIN_PASSWORD_HASH) {
    return verifyPasswordHash(password, ADMIN_PASSWORD_HASH);
  }

  // حالت ۲: اگر ADMIN_PASSWORD تنظیم شده باشد
  if (ADMIN_PASSWORD_ENV) {
    // مقایسه امن برای جلوگیری از timing attack
    try {
      const a = Buffer.from(password);
      const b = Buffer.from(ADMIN_PASSWORD_ENV);
      if (a.length !== b.length) return false;
      return crypto.timingSafeEqual(a, b);
    } catch {
      return false;
    }
  }

  // حالت ۳: مقدار پیش‌فرض — فقط در محیط توسعه مجاز است
  if (process.env.NODE_ENV === 'production') {
    console.error('🚨 CRITICAL: ADMIN_PASSWORD یا ADMIN_PASSWORD_HASH در محیط production تنظیم نشده است!');
    console.error('🚨 برای امنیت، ورود به پنل مدیریت در این حالت غیرفعال است.');
    return false;
  }

  try {
    const a = Buffer.from(password);
    const b = Buffer.from(DEV_DEFAULT_PASSWORD);
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

// ایجاد سشن
export async function createAdminSession(): Promise<string> {
  const token = generateToken();
  const expiresAt = new Date(Date.now() + SESSION_DURATION);

  await db.adminSession.create({
    data: {
      token,
      expiresAt,
    },
  });

  return token;
}

// بررسی اعتبار سشن
export async function verifyAdminSession(token: string | undefined): Promise<boolean> {
  if (!token) return false;

  const session = await db.adminSession.findUnique({
    where: { token },
  });

  if (!session) return false;
  if (session.expiresAt < new Date()) {
    // حذف سشن منقضی شده
    await db.adminSession.delete({ where: { id: session.id } });
    return false;
  }

  return true;
}

// حذف سشن (خروج)
export async function deleteAdminSession(token: string): Promise<void> {
  try {
    await db.adminSession.delete({ where: { token } });
  } catch {
    // ignore
  }
}

// پاکسازی سشن‌های منقضی شده (برای اجرای دوره‌ای)
export async function cleanupExpiredSessions(): Promise<void> {
  await db.adminSession.deleteMany({
    where: {
      expiresAt: { lt: new Date() },
    },
  });
}

// گرفتن توکن از کوکی (در server)
export async function getAdminToken(): Promise<string | undefined> {
  const cookieStore = await cookies();
  return cookieStore.get('yio-admin-token')?.value;
}
