// سرویس ارسال پیامک و ایمیل
// از تنظیمات دیتابیس استفاده می‌کند (قابل تنظیم از پنل ادمین)
import { db } from '@/lib/db';

interface SmsSettings {
  enabled: boolean;
  provider: string;
  apiKey: string;
  senderNumber: string;
  apiUrl: string;
  otpTemplate: string;
  welcomeTemplate: string;
  orderTemplate: string;
}

interface EmailSettings {
  enabled: boolean;
  smtpHost: string;
  smtpPort: number;
  smtpSecure: string; // none | ssl | tls
  smtpUser: string;
  smtpPassword: string;
  fromAddress: string;
  fromName: string;
  inboxRecipients: string[];
  otpTemplate: string;
}

async function getSmsSettings(): Promise<SmsSettings> {
  const settings = await db.siteSetting.findMany({ where: { category: 'sms' } });
  const obj: Record<string, string> = {};
  settings.forEach(s => { obj[s.key] = s.value; });
  return {
    enabled: obj.sms_enabled === 'true',
    provider: obj.sms_provider || 'kavenegar',
    apiKey: obj.sms_api_key || '',
    senderNumber: obj.sms_sender_number || '',
    apiUrl: obj.sms_api_url || '',
    otpTemplate: obj.sms_otp_template || 'کد تایید: {{code}}',
    welcomeTemplate: obj.sms_welcome_template || 'خوش آمدید',
    orderTemplate: obj.sms_order_template || 'سفارش {{orderNumber}}: {{status}}',
  };
}

async function getEmailSettings(): Promise<EmailSettings> {
  const settings = await db.siteSetting.findMany({ where: { category: 'email' } });
  const obj: Record<string, string> = {};
  settings.forEach(s => { obj[s.key] = s.value; });
  return {
    enabled: obj.email_enabled === 'true',
    smtpHost: obj.email_smtp_host || 'smtp.gmail.com',
    smtpPort: parseInt(obj.email_smtp_port) || 587,
    smtpSecure: obj.email_smtp_secure || 'tls',
    smtpUser: obj.email_smtp_user || '',
    smtpPassword: obj.email_smtp_password || '',
    fromAddress: obj.email_from_address || 'noreply@yio-shop.ir',
    fromName: obj.email_from_name || 'YIO',
    inboxRecipients: (obj.email_inbox_recipients || '').split('|').map(s => s.trim()).filter(Boolean),
    otpTemplate: obj.email_otp_template || 'کد تایید: {{code}}',
  };
}

// جایگزینی متغیرها در قالب
function fillTemplate(template: string, vars: Record<string, string>): string {
  let result = template;
  for (const [key, value] of Object.entries(vars)) {
    result = result.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), value || '');
  }
  return result;
}

// ===== ارسال پیامک =====
// در محیط توسعه، اگر SMS فعال نباشد، کد در لاگ چاپ می‌شود
export async function sendSms(to: string, message: string): Promise<{ success: boolean; error?: string }> {
  const settings = await getSmsSettings();

  if (!settings.enabled) {
    console.log(`[SMS_DISABLED] To: ${to}, Message: ${message}`);
    return { success: true, error: 'SMS غیرفعال است (تنظیمات پنل ادمین)' };
  }

  // نرمال‌سازی شماره موبایل به فرمت 98912...
  const normalizedPhone = to.startsWith('0')
    ? '98' + to.slice(1)
    : to.startsWith('+98')
    ? to.slice(1)
    : to;

  try {
    let response: Response;

    switch (settings.provider) {
      case 'kavenegar':
        // Kavenegar API: https://api.kavenegar.com/v1/{apiKey}/sms/send.json
        response = await fetch(
          `https://api.kavenegar.com/v1/${settings.apiKey}/sms/send.json`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({
              receptor: normalizedPhone,
              message,
              sender: settings.senderNumber,
            }),
          }
        );
        break;

      case 'melipayamak':
        // MeliPayamak API
        response = await fetch('https://rest.payamak-panel.com/api/SendSMS/SendSMS', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            username: settings.apiKey.split('|')[0] || '',
            password: settings.apiKey.split('|')[1] || '',
            to: normalizedPhone,
            from: settings.senderNumber,
            text: message,
          }),
        });
        break;

      case 'farapayamak':
        // FaraPayamak API
        response = await fetch('https://ippanel.com/api/select', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            op: 'send',
            uname: settings.apiKey.split('|')[0] || '',
            pass: settings.apiKey.split('|')[1] || '',
            from: settings.senderNumber,
            to: [normalizedPhone],
            message,
          }),
        });
        break;

      case 'smsir':
        // SMS.ir API
        response = await fetch('https://api.sms.ir/v1/send', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-API-KEY': settings.apiKey,
          },
          body: JSON.stringify({
            number: settings.senderNumber,
            message,
            mobile: normalizedPhone,
          }),
        });
        break;

      case 'custom':
        // ارائه‌گر سفارشی - URL با placeholders: {{phone}} و {{message}}
        if (!settings.apiUrl) {
          return { success: false, error: 'آدرس API سفارشی تنظیم نشده' };
        }
        const url = settings.apiUrl
          .replace('{{phone}}', encodeURIComponent(normalizedPhone))
          .replace('{{message}}', encodeURIComponent(message))
          .replace('{{apiKey}}', encodeURIComponent(settings.apiKey))
          .replace('{{sender}}', encodeURIComponent(settings.senderNumber));
        response = await fetch(url, { method: 'POST' });
        break;

      default:
        return { success: false, error: `ارائه‌گر ${settings.provider} پشتیبانی نمی‌شود` };
    }

    if (!response.ok) {
      const text = await response.text();
      return { success: false, error: `خطای API (${response.status}): ${text.slice(0, 200)}` };
    }

    return { success: true };
  } catch (error: any) {
    return { success: false, error: error.message || 'خطا در ارتباط با سرویس پیامک' };
  }
}

// ارسال کد تایید پیامکی
export async function sendOtpSms(phone: string, code: string, name?: string): Promise<{ success: boolean; error?: string }> {
  const settings = await getSmsSettings();
  const message = fillTemplate(settings.otpTemplate, { code, name: name || '', phone });
  return sendSms(phone, message);
}

// ===== ارسال ایمیل =====
// از fetch به SMTP gateway استفاده نمی‌کنیم (Next.js runtime آن را پشتیبانی نمی‌کند)
// در عوض، ایمیل‌ها را در دیتابیس ذخیره می‌کنیم تا ادمین ببیند
// برای ارسال واقعی، می‌توان از یک سرویس جانبی (مثل n8n) استفاده کرد
export async function sendEmail(
  to: string,
  subject: string,
  body: string,
  fromName?: string
): Promise<{ success: boolean; error?: string }> {
  const settings = await getEmailSettings();

  if (!settings.enabled) {
    console.log(`[EMAIL_DISABLED] To: ${to}, Subject: ${subject}`);
    // حتی اگر ایمیل غیرفعال است، در دیتابیس ذخیره می‌کنیم
    await db.incomingEmail.create({
      data: {
        fromEmail: settings.fromAddress,
        fromName: fromName || settings.fromName,
        toEmail: to,
        subject: `[OUTBOX] ${subject}`,
        body,
        category: 'outbox',
      },
    });
    return { success: true, error: 'ایمیل غیرفعال است اما در دیتابیس ذخیره شد' };
  }

  // در محیط واقعی، اینجا باید با SMTP واقعی ارسال کنیم
  // از آنجا که Next.js نمی‌تواند مستقیماً با SMTP صحبت کند،
  // ایمیل‌ها را در inbox با category=outbox ذخیره می‌کنیم
  // و یک سرویس جانبی (cron/n8n) آن‌ها را ارسال می‌کند
  try {
    await db.incomingEmail.create({
      data: {
        fromEmail: settings.fromAddress,
        fromName: fromName || settings.fromName,
        toEmail: to,
        subject: `[OUTBOX] ${subject}`,
        body,
        category: 'outbox',
      },
    });
    return { success: true };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}

// ارسال کد تایید ایمیلی
export async function sendOtpEmail(email: string, code: string, name?: string): Promise<{ success: boolean; error?: string }> {
  const settings = await getEmailSettings();
  const body = fillTemplate(settings.otpTemplate, { code, name: name || '', email });
  return sendEmail(email, `کد تایید فروشگاه YIO`, body);
}
