/**
 * Core type system for the Page Builder
 *
 * The canvas is a tree of ElementNodes. There are two kinds of nodes:
 *  - "container": a flexbox container that can hold other containers or widgets
 *  - "widget":    a leaf node rendered by a registered widget component
 *
 * Every node carries a `props` bag whose shape is defined by the widget's schema.
 */

export type DeviceMode = 'desktop' | 'tablet' | 'mobile'

export type ElementType = 'container' | 'widget'

/** A single inspector control descriptor. */
export interface FieldSchema {
  key: string
  label: string
  type:
    | 'text'
    | 'textarea'
    | 'number'
    | 'color'
    | 'slider'
    | 'select'
    | 'switch'
    | 'icon'
    | 'image'
    | 'url'
    | 'spacing' // { top, right, bottom, left }
    | 'typography' // { family, size, weight, transform, style, decoration, lineHeight, letterSpacing }
  /** For select fields. */
  options?: { label: string; value: string }[]
  /** For slider fields. */
  min?: number
  max?: number
  step?: number
  /** Which inspector tab the field belongs to. */
  group: 'content' | 'style' | 'advanced'
  default: unknown
  /** Optional helper text shown under the control. */
  hint?: string
  /** Show only on a specific device mode. */
  responsive?: boolean
}

export interface WidgetDefinition {
  type: string
  name: string
  description: string
  icon: string // lucide icon name
  category: 'basic' | 'media' | 'layout' | 'interactive' | 'marketing' | 'advanced'
  fields: FieldSchema[]
  /** Default props for a freshly inserted widget. */
  defaultProps: Record<string, unknown>
  /** Whether this widget can hold children (true only for container). */
  container?: boolean
}

export interface ElementNode {
  id: string
  type: ElementType
  /** For widget nodes, the widget type from the registry. */
  widget?: string
  /** Props for this node (shape depends on the widget's fields). */
  props: Record<string, unknown>
  /** Children (only for containers). */
  children: ElementNode[]
}

export interface PageDocument {
  id: string
  name: string
  slug: string
  content: ElementNode[]
  status: 'draft' | 'published'
  createdAt: string
  updatedAt: string
}

/* ---- Spacing / Typography helper types ---- */

export interface Spacing {
  top: string
  right: string
  bottom: string
  left: string
}

export interface Typography {
  family: string
  size: string
  weight: string
  transform: 'none' | 'uppercase' | 'lowercase' | 'capitalize'
  style: 'normal' | 'italic'
  decoration: 'none' | 'underline' | 'line-through'
  lineHeight: string
  letterSpacing: string
}

export const emptySpacing = (v = '0px'): Spacing => ({ top: v, right: v, bottom: v, left: v })

export const defaultTypography = (size = '16px'): Typography => ({
  family: 'Inter, sans-serif',
  size,
  weight: '400',
  transform: 'none',
  style: 'normal',
  decoration: 'none',
  lineHeight: '1.5',
  letterSpacing: '0px',
})
