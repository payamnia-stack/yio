import type { ElementNode } from './types'
import { widgetMap } from './widgets'

/** Generate a short unique id (good enough for client-side keys). */
export function uid(prefix = 'el'): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}`
}

/** Deep-clone an element tree. */
export function cloneTree(node: ElementNode): ElementNode {
  return {
    ...node,
    props: JSON.parse(JSON.stringify(node.props)),
    children: node.children.map(cloneTree),
  }
}

/** Find an element by id, returns { node, parent } so callers can mutate. */
export function findNode(
  tree: ElementNode[],
  id: string,
): { node: ElementNode | null; parent: ElementNode[] | null } {
  for (const node of tree) {
    if (node.id === id) return { node, parent: tree }
    if (node.children.length) {
      const found = findNode(node.children, id)
      if (found.node) return found
    }
  }
  return { node: null, parent: null }
}

/** Immutably update a node by id with a callback. */
export function updateNode(
  tree: ElementNode[],
  id: string,
  updater: (node: ElementNode) => ElementNode,
): ElementNode[] {
  return tree.map((node) => {
    if (node.id === id) return updater(node)
    if (node.children.length) return { ...node, children: updateNode(node.children, id, updater) }
    return node
  })
}

/** Immutably remove a node by id. */
export function removeNode(tree: ElementNode[], id: string): ElementNode[] {
  return tree
    .filter((n) => n.id !== id)
    .map((n) => (n.children.length ? { ...n, children: removeNode(n.children, id) } : n))
}

/** Immutably insert a node into a parent (or root if parentId is null). */
export function insertNode(
  tree: ElementNode[],
  parentId: string | null,
  index: number,
  node: ElementNode,
): ElementNode[] {
  if (parentId === null) {
    const next = [...tree]
    next.splice(index, 0, node)
    return next
  }
  return tree.map((n) => {
    if (n.id === parentId) {
      const next = [...n.children]
      next.splice(index, 0, node)
      return { ...n, children: next }
    }
    if (n.children.length) return { ...n, children: insertNode(n.children, parentId, index, node) }
    return n
  })
}

/** Immutably move a node: remove from old position, insert into new position. */
export function moveNode(
  tree: ElementNode[],
  dragId: string,
  targetParentId: string | null,
  targetIndex: number,
): ElementNode[] {
  const { node } = findNode(tree, dragId)
  if (!node) return tree
  const removed = removeNode(tree, dragId)
  return insertNode(removed, targetParentId, targetIndex, node)
}

/** Create a fresh element from a widget type. */
export function createElement(widgetType: string): ElementNode {
  const def = widgetMap[widgetType]
  if (!def) throw new Error(`Unknown widget type: ${widgetType}`)
  return {
    id: uid(widgetType),
    type: def.container ? 'container' : 'widget',
    widget: widgetType,
    props: JSON.parse(JSON.stringify(def.defaultProps)),
    children: def.container ? [] : [],
  }
}

/** Walk the tree; callback receives (node, depth). */
export function walkTree(tree: ElementNode[], cb: (node: ElementNode, depth: number) => void, depth = 0): void {
  for (const node of tree) {
    cb(node, depth)
    if (node.children.length) walkTree(node.children, cb, depth + 1)
  }
}

/** Count total nodes. */
export function countNodes(tree: ElementNode[]): number {
  let n = 0
  walkTree(tree, () => n++)
  return n
}
