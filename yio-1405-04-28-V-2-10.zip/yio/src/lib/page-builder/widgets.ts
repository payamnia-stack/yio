import type { WidgetDefinition } from './types'
import { defaultTypography, emptySpacing } from './types'

/* -------------------------------------------------------------------------- */
/*  CONTAINER                                                                 */
/* -------------------------------------------------------------------------- */

export const containerWidget: WidgetDefinition = {
  type: 'container',
  name: 'Container',
  description: 'A flexbox container that holds other elements.',
  icon: 'SquareStack',
  category: 'layout',
  container: true,
  fields: [
    {
      key: 'direction',
      label: 'Direction',
      type: 'select',
      group: 'style',
      default: 'row',
      options: [
        { label: 'Row', value: 'row' },
        { label: 'Column', value: 'column' },
        { label: 'Row Reverse', value: 'row-reverse' },
        { label: 'Column Reverse', value: 'column-reverse' },
      ],
    },
    {
      key: 'justify',
      label: 'Justify Content',
      type: 'select',
      group: 'style',
      default: 'flex-start',
      options: [
        { label: 'Start', value: 'flex-start' },
        { label: 'Center', value: 'center' },
        { label: 'End', value: 'flex-end' },
        { label: 'Space Between', value: 'space-between' },
        { label: 'Space Around', value: 'space-around' },
        { label: 'Space Evenly', value: 'space-evenly' },
      ],
    },
    {
      key: 'align',
      label: 'Align Items',
      type: 'select',
      group: 'style',
      default: 'stretch',
      options: [
        { label: 'Start', value: 'flex-start' },
        { label: 'Center', value: 'center' },
        { label: 'End', value: 'flex-end' },
        { label: 'Stretch', value: 'stretch' },
        { label: 'Baseline', value: 'baseline' },
      ],
    },
    {
      key: 'gap',
      label: 'Gap',
      type: 'text',
      group: 'style',
      default: '16px',
    },
    {
      key: 'wrap',
      label: 'Wrap',
      type: 'switch',
      group: 'style',
      default: false,
    },
    {
      key: 'minHeight',
      label: 'Min Height',
      type: 'text',
      group: 'style',
      default: 'auto',
    },
    {
      key: 'padding',
      label: 'Padding',
      type: 'spacing',
      group: 'style',
      default: emptySpacing('16px'),
    },
    {
      key: 'margin',
      label: 'Margin',
      type: 'spacing',
      group: 'style',
      default: emptySpacing('0px'),
    },
    {
      key: 'background',
      label: 'Background',
      type: 'color',
      group: 'style',
      default: 'transparent',
    },
    {
      key: 'borderRadius',
      label: 'Border Radius',
      type: 'text',
      group: 'style',
      default: '0px',
    },
    {
      key: 'borderWidth',
      label: 'Border Width',
      type: 'text',
      group: 'style',
      default: '0px',
    },
    {
      key: 'borderColor',
      label: 'Border Color',
      type: 'color',
      group: 'style',
      default: '#e5e7eb',
    },
  ],
  defaultProps: {
    direction: 'row',
    justify: 'flex-start',
    align: 'stretch',
    gap: '16px',
    wrap: false,
    minHeight: 'auto',
    padding: emptySpacing('16px'),
    margin: emptySpacing('0px'),
    background: 'transparent',
    borderRadius: '0px',
    borderWidth: '0px',
    borderColor: '#e5e7eb',
  },
}

/* -------------------------------------------------------------------------- */
/*  HEADING                                                                   */
/* -------------------------------------------------------------------------- */

export const headingWidget: WidgetDefinition = {
  type: 'heading',
  name: 'Heading',
  description: 'A section heading with H1–H6 support.',
  icon: 'Heading',
  category: 'basic',
  fields: [
    { key: 'text', label: 'Text', type: 'textarea', group: 'content', default: 'Add Your Heading Text Here' },
    {
      key: 'tag',
      label: 'HTML Tag',
      type: 'select',
      group: 'content',
      default: 'h2',
      options: [
        { label: 'H1', value: 'h1' },
        { label: 'H2', value: 'h2' },
        { label: 'H3', value: 'h3' },
        { label: 'H4', value: 'h4' },
        { label: 'H5', value: 'h5' },
        { label: 'H6', value: 'h6' },
      ],
    },
    { key: 'align', label: 'Alignment', type: 'select', group: 'style', default: 'left',
      options: [
        { label: 'Left', value: 'left' },
        { label: 'Center', value: 'center' },
        { label: 'Right', value: 'right' },
      ] },
    { key: 'color', label: 'Text Color', type: 'color', group: 'style', default: '#0f172a' },
    { key: 'typography', label: 'Typography', type: 'typography', group: 'style', default: defaultTypography('32px') },
    { key: 'padding', label: 'Padding', type: 'spacing', group: 'style', default: emptySpacing('0px') },
    { key: 'margin', label: 'Margin', type: 'spacing', group: 'style', default: emptySpacing('0px') },
  ],
  defaultProps: {
    text: 'Add Your Heading Text Here',
    tag: 'h2',
    align: 'left',
    color: '#0f172a',
    typography: defaultTypography('32px'),
    padding: emptySpacing('0px'),
    margin: emptySpacing('0px'),
  },
}

/* -------------------------------------------------------------------------- */
/*  TEXT                                                                      */
/* -------------------------------------------------------------------------- */

export const textWidget: WidgetDefinition = {
  type: 'text',
  name: 'Text',
  description: 'A paragraph of rich text.',
  icon: 'Type',
  category: 'basic',
  fields: [
    { key: 'text', label: 'Content', type: 'textarea', group: 'content', default: 'Add your paragraph text here. Edit the content to tell visitors about your business, products, or services.' },
    { key: 'align', label: 'Alignment', type: 'select', group: 'style', default: 'left',
      options: [
        { label: 'Left', value: 'left' },
        { label: 'Center', value: 'center' },
        { label: 'Right', value: 'right' },
        { label: 'Justify', value: 'justify' },
      ] },
    { key: 'color', label: 'Text Color', type: 'color', group: 'style', default: '#475569' },
    { key: 'typography', label: 'Typography', type: 'typography', group: 'style', default: defaultTypography('16px') },
    { key: 'padding', label: 'Padding', type: 'spacing', group: 'style', default: emptySpacing('0px') },
    { key: 'margin', label: 'Margin', type: 'spacing', group: 'style', default: emptySpacing('0px') },
  ],
  defaultProps: {
    text: 'Add your paragraph text here. Edit the content to tell visitors about your business, products, or services.',
    align: 'left',
    color: '#475569',
    typography: defaultTypography('16px'),
    padding: emptySpacing('0px'),
    margin: emptySpacing('0px'),
  },
}

/* -------------------------------------------------------------------------- */
/*  BUTTON                                                                    */
/* -------------------------------------------------------------------------- */

export const buttonWidget: WidgetDefinition = {
  type: 'button',
  name: 'Button',
  description: 'A clickable call-to-action button.',
  icon: 'MousePointerClick',
  category: 'marketing',
  fields: [
    { key: 'text', label: 'Label', type: 'text', group: 'content', default: 'Click Me' },
    { key: 'url', label: 'Link URL', type: 'url', group: 'content', default: '#' },
    { key: 'target', label: 'Open In', type: 'select', group: 'content', default: '_self',
      options: [
        { label: 'Same Tab', value: '_self' },
        { label: 'New Tab', value: '_blank' },
      ] },
    { key: 'align', label: 'Alignment', type: 'select', group: 'style', default: 'left',
      options: [
        { label: 'Left', value: 'left' },
        { label: 'Center', value: 'center' },
        { label: 'Right', value: 'right' },
      ] },
    { key: 'bgColor', label: 'Background', type: 'color', group: 'style', default: '#6366f1' },
    { key: 'textColor', label: 'Text Color', type: 'color', group: 'style', default: '#ffffff' },
    { key: 'hoverBgColor', label: 'Hover Background', type: 'color', group: 'style', default: '#4f46e5' },
    { key: 'typography', label: 'Typography', type: 'typography', group: 'style', default: defaultTypography('15px') },
    { key: 'padding', label: 'Padding', type: 'spacing', group: 'style', default: { top: '12px', right: '24px', bottom: '12px', left: '24px' } },
    { key: 'margin', label: 'Margin', type: 'spacing', group: 'style', default: emptySpacing('0px') },
    { key: 'borderRadius', label: 'Border Radius', type: 'text', group: 'style', default: '8px' },
    { key: 'width', label: 'Width', type: 'select', group: 'style', default: 'auto',
      options: [
        { label: 'Auto', value: 'auto' },
        { label: 'Full', value: '100%' },
      ] },
  ],
  defaultProps: {
    text: 'Click Me',
    url: '#',
    target: '_self',
    align: 'left',
    bgColor: '#6366f1',
    textColor: '#ffffff',
    hoverBgColor: '#4f46e5',
    typography: defaultTypography('15px'),
    padding: { top: '12px', right: '24px', bottom: '12px', left: '24px' },
    margin: emptySpacing('0px'),
    borderRadius: '8px',
    width: 'auto',
  },
}

/* -------------------------------------------------------------------------- */
/*  IMAGE                                                                     */
/* -------------------------------------------------------------------------- */

export const imageWidget: WidgetDefinition = {
  type: 'image',
  name: 'Image',
  description: 'A responsive image.',
  icon: 'Image',
  category: 'media',
  fields: [
    { key: 'src', label: 'Image URL', type: 'image', group: 'content', default: 'https://images.unsplash.com/photo-1707343843437-caacff5cfa74?w=1200&q=80' },
    { key: 'alt', label: 'Alt Text', type: 'text', group: 'content', default: 'Description' },
    { key: 'caption', label: 'Caption', type: 'text', group: 'content', default: '' },
    { key: 'align', label: 'Alignment', type: 'select', group: 'style', default: 'center',
      options: [
        { label: 'Left', value: 'left' },
        { label: 'Center', value: 'center' },
        { label: 'Right', value: 'right' },
      ] },
    { key: 'width', label: 'Width', type: 'text', group: 'style', default: '100%' },
    { key: 'maxWidth', label: 'Max Width', type: 'text', group: 'style', default: '100%' },
    { key: 'height', label: 'Height', type: 'text', group: 'style', default: 'auto' },
    { key: 'objectFit', label: 'Object Fit', type: 'select', group: 'style', default: 'cover',
      options: [
        { label: 'Cover', value: 'cover' },
        { label: 'Contain', value: 'contain' },
        { label: 'Fill', value: 'fill' },
        { label: 'None', value: 'none' },
      ] },
    { key: 'borderRadius', label: 'Border Radius', type: 'text', group: 'style', default: '0px' },
    { key: 'margin', label: 'Margin', type: 'spacing', group: 'style', default: emptySpacing('0px') },
  ],
  defaultProps: {
    src: 'https://images.unsplash.com/photo-1707343843437-caacff5cfa74?w=1200&q=80',
    alt: 'Description',
    caption: '',
    align: 'center',
    width: '100%',
    maxWidth: '100%',
    height: 'auto',
    objectFit: 'cover',
    borderRadius: '0px',
    margin: emptySpacing('0px'),
  },
}

/* -------------------------------------------------------------------------- */
/*  VIDEO                                                                     */
/* -------------------------------------------------------------------------- */

export const videoWidget: WidgetDefinition = {
  type: 'video',
  name: 'Video',
  description: 'Embed a YouTube/Vimeo or self-hosted video.',
  icon: 'Video',
  category: 'media',
  fields: [
    { key: 'url', label: 'Video URL', type: 'url', group: 'content', default: 'https://www.youtube.com/embed/dQw4w9WgXcQ' },
    { key: 'aspectRatio', label: 'Aspect Ratio', type: 'select', group: 'style', default: '16 / 9',
      options: [
        { label: '16:9', value: '16 / 9' },
        { label: '4:3', value: '4 / 3' },
        { label: '1:1', value: '1 / 1' },
        { label: '21:9', value: '21 / 9' },
      ] },
    { key: 'borderRadius', label: 'Border Radius', type: 'text', group: 'style', default: '8px' },
    { key: 'margin', label: 'Margin', type: 'spacing', group: 'style', default: emptySpacing('0px') },
  ],
  defaultProps: {
    url: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    aspectRatio: '16 / 9',
    borderRadius: '8px',
    margin: emptySpacing('0px'),
  },
}

/* -------------------------------------------------------------------------- */
/*  DIVIDER                                                                   */
/* -------------------------------------------------------------------------- */

export const dividerWidget: WidgetDefinition = {
  type: 'divider',
  name: 'Divider',
  description: 'A horizontal line separator.',
  icon: 'Minus',
  category: 'layout',
  fields: [
    { key: 'color', label: 'Color', type: 'color', group: 'style', default: '#e5e7eb' },
    { key: 'thickness', label: 'Thickness', type: 'text', group: 'style', default: '1px' },
    { key: 'width', label: 'Width', type: 'slider', group: 'style', min: 10, max: 100, step: 1, default: 100, hint: 'Percentage' },
    { key: 'align', label: 'Alignment', type: 'select', group: 'style', default: 'center',
      options: [
        { label: 'Left', value: 'flex-start' },
        { label: 'Center', value: 'center' },
        { label: 'Right', value: 'flex-end' },
      ] },
    { key: 'margin', label: 'Margin', type: 'spacing', group: 'style', default: { top: '16px', right: '0px', bottom: '16px', left: '0px' } },
  ],
  defaultProps: {
    color: '#e5e7eb',
    thickness: '1px',
    width: 100,
    align: 'center',
    margin: { top: '16px', right: '0px', bottom: '16px', left: '0px' },
  },
}

/* -------------------------------------------------------------------------- */
/*  SPACER                                                                    */
/* -------------------------------------------------------------------------- */

export const spacerWidget: WidgetDefinition = {
  type: 'spacer',
  name: 'Spacer',
  description: 'Adds vertical spacing between elements.',
  icon: 'StretchVertical',
  category: 'layout',
  fields: [
    { key: 'height', label: 'Height', type: 'text', group: 'style', default: '40px' },
  ],
  defaultProps: {
    height: '40px',
  },
}

/* -------------------------------------------------------------------------- */
/*  ICON                                                                      */
/* -------------------------------------------------------------------------- */

export const iconWidget: WidgetDefinition = {
  type: 'icon',
  name: 'Icon',
  description: 'A single Lucide icon.',
  icon: 'Star',
  category: 'basic',
  fields: [
    { key: 'icon', label: 'Icon', type: 'icon', group: 'content', default: 'Star' },
    { key: 'size', label: 'Size', type: 'text', group: 'style', default: '48px' },
    { key: 'color', label: 'Color', type: 'color', group: 'style', default: '#6366f1' },
    { key: 'align', label: 'Alignment', type: 'select', group: 'style', default: 'center',
      options: [
        { label: 'Left', value: 'flex-start' },
        { label: 'Center', value: 'center' },
        { label: 'Right', value: 'flex-end' },
      ] },
    { key: 'margin', label: 'Margin', type: 'spacing', group: 'style', default: emptySpacing('0px') },
  ],
  defaultProps: {
    icon: 'Star',
    size: '48px',
    color: '#6366f1',
    align: 'center',
    margin: emptySpacing('0px'),
  },
}

/* -------------------------------------------------------------------------- */
/*  ICON BOX                                                                  */
/* -------------------------------------------------------------------------- */

export const iconBoxWidget: WidgetDefinition = {
  type: 'icon-box',
  name: 'Icon Box',
  description: 'An icon with title and description.',
  icon: 'LayoutGrid',
  category: 'marketing',
  fields: [
    { key: 'icon', label: 'Icon', type: 'icon', group: 'content', default: 'Rocket' },
    { key: 'title', label: 'Title', type: 'text', group: 'content', default: 'Feature Title' },
    { key: 'description', label: 'Description', type: 'textarea', group: 'content', default: 'Describe the feature here in a sentence or two.' },
    { key: 'position', label: 'Icon Position', type: 'select', group: 'style', default: 'top',
      options: [
        { label: 'Top', value: 'top' },
        { label: 'Left', value: 'left' },
        { label: 'Right', value: 'right' },
      ] },
    { key: 'iconSize', label: 'Icon Size', type: 'text', group: 'style', default: '40px' },
    { key: 'iconColor', label: 'Icon Color', type: 'color', group: 'style', default: '#6366f1' },
    { key: 'titleColor', label: 'Title Color', type: 'color', group: 'style', default: '#0f172a' },
    { key: 'descColor', label: 'Description Color', type: 'color', group: 'style', default: '#64748b' },
    { key: 'align', label: 'Alignment', type: 'select', group: 'style', default: 'left',
      options: [
        { label: 'Left', value: 'left' },
        { label: 'Center', value: 'center' },
        { label: 'Right', value: 'right' },
      ] },
    { key: 'bgColor', label: 'Background', type: 'color', group: 'style', default: '#ffffff' },
    { key: 'padding', label: 'Padding', type: 'spacing', group: 'style', default: emptySpacing('20px') },
    { key: 'borderRadius', label: 'Border Radius', type: 'text', group: 'style', default: '12px' },
  ],
  defaultProps: {
    icon: 'Rocket',
    title: 'Feature Title',
    description: 'Describe the feature here in a sentence or two.',
    position: 'top',
    iconSize: '40px',
    iconColor: '#6366f1',
    titleColor: '#0f172a',
    descColor: '#64748b',
    align: 'left',
    bgColor: '#ffffff',
    padding: emptySpacing('20px'),
    borderRadius: '12px',
  },
}

/* -------------------------------------------------------------------------- */
/*  IMAGE BOX                                                                 */
/* -------------------------------------------------------------------------- */

export const imageBoxWidget: WidgetDefinition = {
  type: 'image-box',
  name: 'Image Box',
  description: 'An image with title and description.',
  icon: 'ImageIcon',
  category: 'marketing',
  fields: [
    { key: 'src', label: 'Image URL', type: 'image', group: 'content', default: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&q=80' },
    { key: 'title', label: 'Title', type: 'text', group: 'content', default: 'Card Title' },
    { key: 'description', label: 'Description', type: 'textarea', group: 'content', default: 'A short description that explains what this card is about.' },
    { key: 'imageHeight', label: 'Image Height', type: 'text', group: 'style', default: '200px' },
    { key: 'titleColor', label: 'Title Color', type: 'color', group: 'style', default: '#0f172a' },
    { key: 'descColor', label: 'Description Color', type: 'color', group: 'style', default: '#64748b' },
    { key: 'bgColor', label: 'Background', type: 'color', group: 'style', default: '#ffffff' },
    { key: 'padding', label: 'Padding', type: 'spacing', group: 'style', default: emptySpacing('0px') },
    { key: 'borderRadius', label: 'Border Radius', type: 'text', group: 'style', default: '12px' },
  ],
  defaultProps: {
    src: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&q=80',
    title: 'Card Title',
    description: 'A short description that explains what this card is about.',
    imageHeight: '200px',
    titleColor: '#0f172a',
    descColor: '#64748b',
    bgColor: '#ffffff',
    padding: emptySpacing('0px'),
    borderRadius: '12px',
  },
}

/* -------------------------------------------------------------------------- */
/*  CALL TO ACTION                                                            */
/* -------------------------------------------------------------------------- */

export const ctaWidget: WidgetDefinition = {
  type: 'cta',
  name: 'Call to Action',
  description: 'Eye-catching CTA block with title, text and button.',
  icon: 'Megaphone',
  category: 'marketing',
  fields: [
    { key: 'title', label: 'Title', type: 'text', group: 'content', default: 'Ready to Get Started?' },
    { key: 'description', label: 'Description', type: 'textarea', group: 'content', default: 'Join thousands of happy customers and transform your business today.' },
    { key: 'buttonText', label: 'Button Label', type: 'text', group: 'content', default: 'Sign Up Free' },
    { key: 'buttonUrl', label: 'Button URL', type: 'url', group: 'content', default: '#' },
    { key: 'align', label: 'Alignment', type: 'select', group: 'style', default: 'center',
      options: [
        { label: 'Left', value: 'left' },
        { label: 'Center', value: 'center' },
        { label: 'Right', value: 'right' },
      ] },
    { key: 'bgColor', label: 'Background', type: 'color', group: 'style', default: '#6366f1' },
    { key: 'titleColor', label: 'Title Color', type: 'color', group: 'style', default: '#ffffff' },
    { key: 'descColor', label: 'Description Color', type: 'color', group: 'style', default: '#e0e7ff' },
    { key: 'buttonBg', label: 'Button Background', type: 'color', group: 'style', default: '#ffffff' },
    { key: 'buttonText', label: 'Button Text Color', type: 'color', group: 'style', default: '#6366f1' },
    { key: 'padding', label: 'Padding', type: 'spacing', group: 'style', default: emptySpacing('48px') },
    { key: 'borderRadius', label: 'Border Radius', type: 'text', group: 'style', default: '16px' },
  ],
  defaultProps: {
    title: 'Ready to Get Started?',
    description: 'Join thousands of happy customers and transform your business today.',
    buttonText: 'Sign Up Free',
    buttonUrl: '#',
    align: 'center',
    bgColor: '#6366f1',
    titleColor: '#ffffff',
    descColor: '#e0e7ff',
    buttonBg: '#ffffff',
    buttonText: '#6366f1',
    padding: emptySpacing('48px'),
    borderRadius: '16px',
  },
}

/* -------------------------------------------------------------------------- */
/*  FLIP BOX                                                                  */
/* -------------------------------------------------------------------------- */

export const flipBoxWidget: WidgetDefinition = {
  type: 'flip-box',
  name: 'Flip Box',
  description: 'A card that flips on hover to reveal back content.',
  icon: 'FlipHorizontal2',
  category: 'advanced',
  fields: [
    { key: 'frontIcon', label: 'Front Icon', type: 'icon', group: 'content', default: 'Bulb' },
    { key: 'frontTitle', label: 'Front Title', type: 'text', group: 'content', default: 'Hover Me' },
    { key: 'frontDesc', label: 'Front Description', type: 'textarea', group: 'content', default: 'Hover to flip the box.' },
    { key: 'backTitle', label: 'Back Title', type: 'text', group: 'content', default: 'Surprise!' },
    { key: 'backDesc', label: 'Back Description', type: 'textarea', group: 'content', default: 'You found the back of the box.' },
    { key: 'backButtonText', label: 'Back Button Label', type: 'text', group: 'content', default: 'Learn More' },
    { key: 'backButtonUrl', label: 'Back Button URL', type: 'url', group: 'content', default: '#' },
    { key: 'height', label: 'Height', type: 'text', group: 'style', default: '300px' },
    { key: 'frontBg', label: 'Front Background', type: 'color', group: 'style', default: '#6366f1' },
    { key: 'backBg', label: 'Back Background', type: 'color', group: 'style', default: '#4f46e5' },
    { key: 'frontTextColor', label: 'Front Text Color', type: 'color', group: 'style', default: '#ffffff' },
    { key: 'backTextColor', label: 'Back Text Color', type: 'color', group: 'style', default: '#ffffff' },
    { key: 'borderRadius', label: 'Border Radius', type: 'text', group: 'style', default: '16px' },
  ],
  defaultProps: {
    frontIcon: 'Bulb',
    frontTitle: 'Hover Me',
    frontDesc: 'Hover to flip the box.',
    backTitle: 'Surprise!',
    backDesc: 'You found the back of the box.',
    backButtonText: 'Learn More',
    backButtonUrl: '#',
    height: '300px',
    frontBg: '#6366f1',
    backBg: '#4f46e5',
    frontTextColor: '#ffffff',
    backTextColor: '#ffffff',
    borderRadius: '16px',
  },
}

/* -------------------------------------------------------------------------- */
/*  TESTIMONIAL                                                               */
/* -------------------------------------------------------------------------- */

export const testimonialWidget: WidgetDefinition = {
  type: 'testimonial',
  name: 'Testimonial',
  description: 'A customer quote with avatar, name and role.',
  icon: 'Quote',
  category: 'marketing',
  fields: [
    { key: 'quote', label: 'Quote', type: 'textarea', group: 'content', default: 'This product completely transformed our workflow. We could not be happier with the results.' },
    { key: 'name', label: 'Name', type: 'text', group: 'content', default: 'Sarah Johnson' },
    { key: 'role', label: 'Role', type: 'text', group: 'content', default: 'CEO at Acme Inc.' },
    { key: 'avatar', label: 'Avatar URL', type: 'image', group: 'content', default: 'https://i.pravatar.cc/150?img=47' },
    { key: 'rating', label: 'Rating', type: 'slider', group: 'content', min: 0, max: 5, step: 1, default: 5 },
    { key: 'bgColor', label: 'Background', type: 'color', group: 'style', default: '#f8fafc' },
    { key: 'textColor', label: 'Quote Color', type: 'color', group: 'style', default: '#1e293b' },
    { key: 'nameColor', label: 'Name Color', type: 'color', group: 'style', default: '#0f172a' },
    { key: 'roleColor', label: 'Role Color', type: 'color', group: 'style', default: '#64748b' },
    { key: 'starColor', label: 'Star Color', type: 'color', group: 'style', default: '#f59e0b' },
    { key: 'align', label: 'Alignment', type: 'select', group: 'style', default: 'left',
      options: [
        { label: 'Left', value: 'left' },
        { label: 'Center', value: 'center' },
      ] },
    { key: 'padding', label: 'Padding', type: 'spacing', group: 'style', default: emptySpacing('32px') },
    { key: 'borderRadius', label: 'Border Radius', type: 'text', group: 'style', default: '16px' },
  ],
  defaultProps: {
    quote: 'This product completely transformed our workflow. We could not be happier with the results.',
    name: 'Sarah Johnson',
    role: 'CEO at Acme Inc.',
    avatar: 'https://i.pravatar.cc/150?img=47',
    rating: 5,
    bgColor: '#f8fafc',
    textColor: '#1e293b',
    nameColor: '#0f172a',
    roleColor: '#64748b',
    starColor: '#f59e0b',
    align: 'left',
    padding: emptySpacing('32px'),
    borderRadius: '16px',
  },
}

/* -------------------------------------------------------------------------- */
/*  ALERT                                                                     */
/* -------------------------------------------------------------------------- */

export const alertWidget: WidgetDefinition = {
  type: 'alert',
  name: 'Alert',
  description: 'A colored notification banner.',
  icon: 'BellRing',
  category: 'interactive',
  fields: [
    { key: 'title', label: 'Title', type: 'text', group: 'content', default: 'Heads up!' },
    { key: 'description', label: 'Description', type: 'textarea', group: 'content', default: 'This is an important message that needs your attention.' },
    { key: 'variant', label: 'Variant', type: 'select', group: 'style', default: 'info',
      options: [
        { label: 'Info', value: 'info' },
        { label: 'Success', value: 'success' },
        { label: 'Warning', value: 'warning' },
        { label: 'Error', value: 'error' },
      ] },
    { key: 'icon', label: 'Icon', type: 'icon', group: 'content', default: 'Info' },
    { key: 'padding', label: 'Padding', type: 'spacing', group: 'style', default: emptySpacing('16px') },
    { key: 'borderRadius', label: 'Border Radius', type: 'text', group: 'style', default: '8px' },
    { key: 'margin', label: 'Margin', type: 'spacing', group: 'style', default: emptySpacing('0px') },
  ],
  defaultProps: {
    title: 'Heads up!',
    description: 'This is an important message that needs your attention.',
    variant: 'info',
    icon: 'Info',
    padding: emptySpacing('16px'),
    borderRadius: '8px',
    margin: emptySpacing('0px'),
  },
}

/* -------------------------------------------------------------------------- */
/*  ACCORDION                                                                 */
/* -------------------------------------------------------------------------- */

export const accordionWidget: WidgetDefinition = {
  type: 'accordion',
  name: 'Accordion',
  description: 'Collapsible FAQ-style list.',
  icon: 'ChevronsDownUp',
  category: 'interactive',
  fields: [
    {
      key: 'items',
      label: 'Items (one per line, title | content)',
      type: 'textarea',
      group: 'content',
      default:
        'What is this?|This is a page builder built with Next.js.\nHow does it work?|Drag widgets onto the canvas and edit them in the inspector.\nCan I export?|Yes, use the Export button to download standalone HTML.',
      hint: 'Format: Title|Content — one item per line',
    },
    { key: 'firstOpen', label: 'First Item Open', type: 'switch', group: 'content', default: true },
    { key: 'bgColor', label: 'Background', type: 'color', group: 'style', default: '#ffffff' },
    { key: 'headerBgColor', label: 'Header Background', type: 'color', group: 'style', default: '#f1f5f9' },
    { key: 'headerTextColor', label: 'Header Text Color', type: 'color', group: 'style', default: '#0f172a' },
    { key: 'bodyTextColor', label: 'Body Text Color', type: 'color', group: 'style', default: '#475569' },
    { key: 'borderRadius', label: 'Border Radius', type: 'text', group: 'style', default: '8px' },
    { key: 'margin', label: 'Margin', type: 'spacing', group: 'style', default: emptySpacing('0px') },
  ],
  defaultProps: {
    items:
      'What is this?|This is a page builder built with Next.js.\nHow does it work?|Drag widgets onto the canvas and edit them in the inspector.\nCan I export?|Yes, use the Export button to download standalone HTML.',
    firstOpen: true,
    bgColor: '#ffffff',
    headerBgColor: '#f1f5f9',
    headerTextColor: '#0f172a',
    bodyTextColor: '#475569',
    borderRadius: '8px',
    margin: emptySpacing('0px'),
  },
}

/* -------------------------------------------------------------------------- */
/*  ANIMATED HEADLINE                                                         */
/* -------------------------------------------------------------------------- */

export const animatedHeadlineWidget: WidgetDefinition = {
  type: 'animated-headline',
  name: 'Animated Headline',
  description: 'Headline with rotating words.',
  icon: 'Sparkles',
  category: 'advanced',
  fields: [
    { key: 'before', label: 'Before Text', type: 'text', group: 'content', default: 'We build ' },
    { key: 'rotating', label: 'Rotating Words (comma-separated)', type: 'text', group: 'content', default: 'websites, apps, dashboards, brands' },
    { key: 'after', label: 'After Text', type: 'text', group: 'content', default: ' that delight.' },
    { key: 'tag', label: 'HTML Tag', type: 'select', group: 'content', default: 'h2',
      options: ['h1', 'h2', 'h3', 'h4'].map((v) => ({ label: v.toUpperCase(), value: v })) },
    { key: 'align', label: 'Alignment', type: 'select', group: 'style', default: 'center',
      options: [
        { label: 'Left', value: 'left' },
        { label: 'Center', value: 'center' },
        { label: 'Right', value: 'right' },
      ] },
    { key: 'textColor', label: 'Text Color', type: 'color', group: 'style', default: '#0f172a' },
    { key: 'highlightColor', label: 'Highlight Color', type: 'color', group: 'style', default: '#6366f1' },
    { key: 'typography', label: 'Typography', type: 'typography', group: 'style', default: defaultTypography('40px') },
    { key: 'margin', label: 'Margin', type: 'spacing', group: 'style', default: emptySpacing('0px') },
  ],
  defaultProps: {
    before: 'We build ',
    rotating: 'websites, apps, dashboards, brands',
    after: ' that delight.',
    tag: 'h2',
    align: 'center',
    textColor: '#0f172a',
    highlightColor: '#6366f1',
    typography: defaultTypography('40px'),
    margin: emptySpacing('0px'),
  },
}

/* -------------------------------------------------------------------------- */
/*  CODE HIGHLIGHT                                                            */
/* -------------------------------------------------------------------------- */

export const codeHighlightWidget: WidgetDefinition = {
  type: 'code-highlight',
  name: 'Code Highlight',
  description: 'A syntax-styled code block.',
  icon: 'Code2',
  category: 'advanced',
  fields: [
    { key: 'code', label: 'Code', type: 'textarea', group: 'content', default: "function hello(name) {\n  return `Hello, ${name}!`;\n}\n\nconsole.log(hello('world'));" },
    { key: 'language', label: 'Language', type: 'select', group: 'content', default: 'javascript',
      options: [
        { label: 'JavaScript', value: 'javascript' },
        { label: 'TypeScript', value: 'typescript' },
        { label: 'Python', value: 'python' },
        { label: 'Bash', value: 'bash' },
        { label: 'JSON', value: 'json' },
        { label: 'HTML', value: 'html' },
        { label: 'CSS', value: 'css' },
      ] },
    { key: 'theme', label: 'Theme', type: 'select', group: 'style', default: 'dark',
      options: [
        { label: 'Dark', value: 'dark' },
        { label: 'Light', value: 'light' },
      ] },
    { key: 'borderRadius', label: 'Border Radius', type: 'text', group: 'style', default: '8px' },
    { key: 'margin', label: 'Margin', type: 'spacing', group: 'style', default: emptySpacing('0px') },
  ],
  defaultProps: {
    code: "function hello(name) {\n  return `Hello, ${name}!`;\n}\n\nconsole.log(hello('world'));",
    language: 'javascript',
    theme: 'dark',
    borderRadius: '8px',
    margin: emptySpacing('0px'),
  },
}

/* -------------------------------------------------------------------------- */
/*  REGISTRY                                                                  */
/* -------------------------------------------------------------------------- */

export const widgetRegistry: WidgetDefinition[] = [
  containerWidget,
  headingWidget,
  textWidget,
  buttonWidget,
  imageWidget,
  videoWidget,
  dividerWidget,
  spacerWidget,
  iconWidget,
  iconBoxWidget,
  imageBoxWidget,
  ctaWidget,
  flipBoxWidget,
  testimonialWidget,
  alertWidget,
  accordionWidget,
  animatedHeadlineWidget,
  codeHighlightWidget,
]

export const widgetMap: Record<string, WidgetDefinition> = Object.fromEntries(
  widgetRegistry.map((w) => [w.type, w]),
)

export function getWidget(type: string): WidgetDefinition | undefined {
  return widgetMap[type]
}
