// سیستم اعلان‌ها (Notifications)
import { db } from '@/lib/db';

export type NotificationType =
  | 'order_status'
  | 'price_drop'
  | 'stock_available'
  | 'referral'
  | 'wallet'
  | 'admin'
  | 'review_reply'
  | 'return_request';

interface CreateNotificationParams {
  userId: number;
  type: NotificationType;
  title: string;
  body?: string;
  link?: string;
  data?: Record<string, any>;
}

// ساخت اعلان جدید برای کاربر
export async function createNotification({
  userId,
  type,
  title,
  body,
  link,
  data,
}: CreateNotificationParams): Promise<void> {
  try {
    await db.userNotification.create({
      data: {
        userId,
        type,
        title,
        body: body || null,
        link: link || null,
        data: data ? JSON.stringify(data) : null,
      },
    });

    // broadcast به SSE (در صورت وجود notification emitter)
    try {
      const { broadcastNotification } = await import('@/lib/notification-events');
      broadcastNotification(userId, { type, title, body, link });
    } catch {}
  } catch (error) {
    console.error('Create notification error:', error);
  }
}

// ساخت اعلان برای چند کاربر (مثلاً همه کاربران)
export async function createBulkNotification(
  userIds: number[],
  params: Omit<CreateNotificationParams, 'userId'>
): Promise<void> {
  try {
    await db.userNotification.createMany({
      data: userIds.map(userId => ({
        userId,
        type: params.type,
        title: params.title,
        body: params.body || null,
        link: params.link || null,
        data: params.data ? JSON.stringify(params.data) : null,
      })),
    });
  } catch (error) {
    console.error('Bulk notification error:', error);
  }
}

// آیکون هر نوع اعلان (برای نمایش در UI)
export function getNotificationIcon(type: NotificationType): string {
  const icons: Record<NotificationType, string> = {
    order_status: '📦',
    price_drop: '💰',
    stock_available: '✅',
    referral: '👥',
    wallet: '👛',
    admin: '📢',
    review_reply: '💬',
    return_request: '↩️',
  };
  return icons[type] || '🔔';
}

// رنگ هر نوع اعلان
export function getNotificationColor(type: NotificationType): string {
  const colors: Record<NotificationType, string> = {
    order_status: 'bg-blue-50 text-blue-600',
    price_drop: 'bg-green-50 text-green-600',
    stock_available: 'bg-green-50 text-green-600',
    referral: 'bg-purple-50 text-purple-600',
    wallet: 'bg-amber-50 text-amber-600',
    admin: 'bg-red-50 text-red-600',
    review_reply: 'bg-indigo-50 text-indigo-600',
    return_request: 'bg-orange-50 text-orange-600',
  };
  return colors[type] || 'bg-gray-50 text-gray-600';
}
