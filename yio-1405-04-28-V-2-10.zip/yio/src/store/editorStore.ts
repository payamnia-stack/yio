'use client'

import { create } from 'zustand'
import type { DeviceMode, ElementNode } from '@/lib/page-builder/types'
import {
  cloneTree,
  createElement,
  findNode,
  insertNode,
  moveNode,
  removeNode,
  updateNode,
} from '@/lib/page-builder/tree'

interface EditorState {
  /* Page meta */
  pageId: string | null
  pageName: string
  pageSlug: string

  /* The canvas tree (root level elements) */
  tree: ElementNode[]

  /* Currently selected element id (null = page settings) */
  selectedId: string | null

  /* Hovered element id (for highlight) */
  hoveredId: string | null

  /* Preview mode (disables editing interactions) */
  isPreview: boolean

  /* Device viewport mode */
  device: DeviceMode

  /* History stacks for undo/redo */
  past: ElementNode[][]
  future: ElementNode[][]

  /* Dirty flag (unsaved changes) */
  isDirty: boolean

  /* ---- Actions ---- */
  setPage: (page: { id: string; name: string; slug: string; content: ElementNode[] }) => void
  setDevice: (d: DeviceMode) => void
  setPreview: (p: boolean) => void
  select: (id: string | null) => void
  hover: (id: string | null) => void

  insertWidget: (widgetType: string, parentId: string | null, index: number) => void
  insertElement: (node: ElementNode, parentId: string | null, index: number) => void
  moveElement: (dragId: string, targetParentId: string | null, targetIndex: number) => void
  duplicateElement: (id: string) => void
  deleteElement: (id: string) => void
  updateProps: (id: string, props: Record<string, unknown>) => void

  undo: () => void
  redo: () => void
  markSaved: () => void
}

const MAX_HISTORY = 50

function pushHistory(state: EditorState): Partial<EditorState> {
  return {
    past: [...state.past, state.tree].slice(-MAX_HISTORY),
    future: [],
    isDirty: true,
  }
}

export const useEditorStore = create<EditorState>((set, get) => ({
  pageId: null,
  pageName: 'Untitled Page',
  pageSlug: 'untitled',
  tree: [],
  selectedId: null,
  hoveredId: null,
  isPreview: false,
  device: 'desktop',
  past: [],
  future: [],
  isDirty: false,

  setPage: (page) =>
    set({
      pageId: page.id,
      pageName: page.name,
      pageSlug: page.slug,
      tree: page.content,
      past: [],
      future: [],
      isDirty: false,
      selectedId: null,
      hoveredId: null,
    }),

  setDevice: (d) => set({ device: d }),
  setPreview: (p) => set({ isPreview: p, selectedId: p ? null : get().selectedId }),
  select: (id) => set({ selectedId: id }),
  hover: (id) => set({ hoveredId: id }),

  insertWidget: (widgetType, parentId, index) => {
    const state = get()
    const node = createElement(widgetType)
    set({
      ...pushHistory(state),
      tree: insertNode(state.tree, parentId, index, node),
      selectedId: node.id,
    })
  },

  insertElement: (node, parentId, index) => {
    const state = get()
    set({
      ...pushHistory(state),
      tree: insertNode(state.tree, parentId, index, node),
      selectedId: node.id,
    })
  },

  moveElement: (dragId, targetParentId, targetIndex) => {
    const state = get()
    // Don't allow dropping a node into its own descendant
    const { node } = findNode(state.tree, dragId)
    if (!node) return
    if (targetParentId === dragId) return
    // Check descendant
    const isDescendant = (parent: ElementNode | null, target: string): boolean => {
      if (!parent) return false
      if (parent.id === target) return true
      return parent.children.some((c) => isDescendant(c, target))
    }
    if (isDescendant(node, targetParentId)) return

    set({
      ...pushHistory(state),
      tree: moveNode(state.tree, dragId, targetParentId, targetIndex),
    })
  },

  duplicateElement: (id) => {
    const state = get()
    const { node, parent } = findNode(state.tree, id)
    if (!node || !parent) return
    const idx = parent.indexOf(node)
    const dup = cloneTree(node)
    dup.id = `${dup.id}_copy_${Math.random().toString(36).slice(2, 6)}`
    set({
      ...pushHistory(state),
      tree: insertNode(state.tree, findParentId(state.tree, id), idx + 1, dup),
      selectedId: dup.id,
    })
  },

  deleteElement: (id) => {
    const state = get()
    set({
      ...pushHistory(state),
      tree: removeNode(state.tree, id),
      selectedId: state.selectedId === id ? null : state.selectedId,
    })
  },

  updateProps: (id, props) => {
    const state = get()
    set({
      ...pushHistory(state),
      tree: updateNode(state.tree, id, (n) => ({
        ...n,
        props: { ...n.props, ...props },
      })),
    })
  },

  undo: () => {
    const { past, future, tree } = get()
    if (!past.length) return
    const previous = past[past.length - 1]
    set({
      tree: previous,
      past: past.slice(0, -1),
      future: [tree, ...future].slice(0, MAX_HISTORY),
      isDirty: true,
    })
  },

  redo: () => {
    const { past, future, tree } = get()
    if (!future.length) return
    const next = future[0]
    set({
      tree: next,
      future: future.slice(1),
      past: [...past, tree].slice(-MAX_HISTORY),
      isDirty: true,
    })
  },

  markSaved: () => set({ isDirty: false }),
}))

/** Find the parent id of a node, or null if it's at root. */
function findParentId(tree: ElementNode[], id: string): string | null {
  for (const node of tree) {
    if (node.children.some((c) => c.id === id)) return node.id
    if (node.children.length) {
      const found = findParentId(node.children, id)
      if (found) return found
    }
  }
  return null
}
