'use client';

import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Product } from '@/lib/shop-data';

interface CartItem extends Product {
  quantity: number;
  selectedColor?: string;
}

interface ShopState {
  cart: CartItem[];
  favorites: number[];
  isCartOpen: boolean;
  isWishlistOpen: boolean;
  isSearchOpen: boolean;
  isAuthed: boolean;
  addToCart: (product: Product, color?: string) => void;
  removeFromCart: (productId: number) => void;
  updateQuantity: (productId: number, quantity: number) => void;
  clearCart: () => void;
  toggleFavorite: (productId: number) => Promise<void>;
  setFavorites: (ids: number[]) => void;
  syncFavoritesFromServer: () => Promise<void>;
  setAuthed: (authed: boolean) => void;
  setCartOpen: (open: boolean) => void;
  setWishlistOpen: (open: boolean) => void;
  setSearchOpen: (open: boolean) => void;
  cartTotal: () => number;
  cartCount: () => number;
}

export const useShopStore = create<ShopState>()(
  persist(
    (set, get) => ({
      cart: [],
      favorites: [],
      isCartOpen: false,
      isWishlistOpen: false,
      isSearchOpen: false,
      isAuthed: false,

      setAuthed: (authed) => set({ isAuthed: authed }),

      setFavorites: (ids) => set({ favorites: ids }),

      // همگام‌سازی علاقه‌مندی‌ها از سرور (پس از ورود کاربر)
      syncFavoritesFromServer: async () => {
        try {
          const res = await fetch('/api/user/wishlist');
          if (!res.ok) return;
          const data = await res.json();
          set({ favorites: data.productIds || [] });
          set({ isAuthed: true });
        } catch {
          // خطا در همگام‌سازی — حالت محلی حفظ می‌شود
        }
      },

      addToCart: (product, color) => {
        const cart = get().cart;
        const existing = cart.find(item => item.id === product.id && item.selectedColor === color);

        if (existing) {
          set({
            cart: cart.map(item =>
              item.id === product.id && item.selectedColor === color
                ? { ...item, quantity: item.quantity + 1 }
                : item
            ),
          });
        } else {
          set({
            cart: [...cart, { ...product, quantity: 1, selectedColor: color }],
          });
        }
      },

      removeFromCart: (productId) => {
        set({ cart: get().cart.filter(item => item.id !== productId) });
      },

      updateQuantity: (productId, quantity) => {
        if (quantity <= 0) {
          set({ cart: get().cart.filter(item => item.id !== productId) });
          return;
        }
        set({
          cart: get().cart.map(item =>
            item.id === productId ? { ...item, quantity } : item
          ),
        });
      },

      clearCart: () => set({ cart: [] }),

      // toggleFavorite: اگر کاربر وارد شده باشد، با سرور همگام می‌شود؛ در غیر این‌صورت فقط محلی
      toggleFavorite: async (productId) => {
        const favorites = get().favorites;
        const isFav = favorites.includes(productId);

        // بهینه‌سازی تجربه کاربری: ابتدا state محلی را به‌روزرسانی می‌کنیم
        set({
          favorites: isFav
            ? favorites.filter(id => id !== productId)
            : [...favorites, productId],
        });

        // اگر کاربر وارد شده باشد، تغییر را به سرور می‌فرستیم
        // در صورت خطا، تغییر محلی برگردانده می‌شود
        try {
          if (isFav) {
            const res = await fetch(`/api/user/wishlist?productId=${productId}`, { method: 'DELETE' });
            if (res.status === 401) {
              // کاربر وارد نشده — حالت محلی حفظ می‌شود
              return;
            }
            if (!res.ok) throw new Error('DELETE failed');
          } else {
            const res = await fetch('/api/user/wishlist', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ productId }),
            });
            if (res.status === 401) {
              // کاربر وارد نشده — حالت محلی حفظ می‌شود
              return;
            }
            if (!res.ok) throw new Error('POST failed');
          }
        } catch (e) {
          // در صورت خطا، تغییر محلی را برگردان (rollback)
          set({ favorites });
        }
      },

      setCartOpen: (open) => set({ isCartOpen: open }),
      setWishlistOpen: (open) => set({ isWishlistOpen: open }),
      setSearchOpen: (open) => set({ isSearchOpen: open }),

      cartTotal: () => {
        return get().cart.reduce((sum, item) => {
          const price = item.discountPrice ?? item.price;
          return sum + price * item.quantity;
        }, 0);
      },

      cartCount: () => {
        return get().cart.reduce((sum, item) => sum + item.quantity, 0);
      },
    }),
    {
      name: 'digimarket-storage',
      partialize: (state) => ({ cart: state.cart, favorites: state.favorites }),
    }
  )
);
