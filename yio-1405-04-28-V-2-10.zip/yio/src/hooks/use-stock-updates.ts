'use client';

import { useEffect, useRef } from 'react';
import type { StockUpdate } from '@/lib/stock-events';

interface UseStockUpdatesOptions {
  onStockUpdate: (update: StockUpdate) => void;
  enabled?: boolean;
}

// Hook برای subscribtion به آپدیت‌های real-time موجودی محصولات
// از Server-Sent Events (SSE) استفاده می‌کند
export function useStockUpdates({ onStockUpdate, enabled = true }: UseStockUpdatesOptions) {
  const callbackRef = useRef(onStockUpdate);
  const eventSourceRef = useRef<EventSource | null>(null);

  // نگه‌داری آخرین callback بدون نیاز به re-subscribe
  useEffect(() => {
    callbackRef.current = onStockUpdate;
  }, [onStockUpdate]);

  useEffect(() => {
    if (!enabled) return;
    if (typeof window === 'undefined' || !window.EventSource) return;

    // اتصال به SSE endpoint
    const es = new EventSource('/api/shop/stock-stream');
    eventSourceRef.current = es;

    es.onmessage = (event) => {
      try {
        const update: StockUpdate = JSON.parse(event.data);
        callbackRef.current(update);
      } catch (e) {
        // پیام‌های heartbeat (شروع با :) قابل parse نیستند — نرمال است
      }
    };

    es.onerror = () => {
      // در صورت قطع اتصال، EventSource خودکار reconnect می‌کند
      // این رفتار پیش‌فرض مرورگر است
    };

    // پاکسازی هنگام unmount
    return () => {
      es.close();
      eventSourceRef.current = null;
    };
  }, [enabled]);

  return eventSourceRef.current;
}
