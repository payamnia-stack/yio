'use client';

import { useEffect, useRef, useState } from 'react';

interface NotificationData {
  type: string;
  title: string;
  body?: string;
  link?: string;
  timestamp: number;
}

// Hook برای اتصال به SSE اعلان‌ها
export function useNotificationStream(enabled: boolean = true) {
  const [notifications, setNotifications] = useState<NotificationData[]>([]);
  const eventSourceRef = useRef<EventSource | null>(null);

  useEffect(() => {
    if (!enabled) return;
    if (typeof window === 'undefined' || !window.EventSource) return;

    const es = new EventSource('/api/shop/notification-stream');
    eventSourceRef.current = es;

    es.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.notification) {
          setNotifications(prev => [data.notification, ...prev].slice(0, 10));
        }
      } catch {}
    };

    return () => {
      es.close();
      eventSourceRef.current = null;
    };
  }, [enabled]);

  const dismiss = (index: number) => {
    setNotifications(prev => prev.filter((_, i) => i !== index));
  };

  return { notifications, dismiss };
}
