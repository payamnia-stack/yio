'use client';

import { Building2, Send, ChevronLeft, Package, Phone, Clock, CheckCircle } from 'lucide-react';
import { useState } from 'react';
import { Header } from '@/components/shop/header';
import { Footer } from '@/components/shop/footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { categories } from '@/lib/shop-data';
import Link from 'next/link';

export default function WholesalePage() {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [formData, setFormData] = useState({
    companyName: '', contactPerson: '', phone: '', email: '',
    city: '', productCategory: '', quantity: '50', description: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^09\d{9}$/.test(formData.phone)) {
      toast.error('شماره موبایل نامعتبر');
      return;
    }
    if (parseInt(formData.quantity) < 10) {
      toast.error('حداقل تعداد ۱۰ عدد');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/wholesale', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      if (res.ok) {
        setSuccess(true);
        toast.success('درخواست ثبت شد');
      } else {
        const data = await res.json();
        toast.error(data.error || 'خطا');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
        <Header />
        <main className="flex-1 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md text-center">
            <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold mb-2">درخواست ثبت شد!</h1>
            <p className="text-gray-600 mb-6">کارشناسان ما ظرف ۲۴ ساعت کاری با شما تماس می‌گیرند.</p>
            <Link href="/">
              <Button className="bg-[#dc2626] hover:bg-[#b91c1c]">بازگشت به فروشگاه</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
          <Link href="/" className="hover:text-[#dc2626]">خانه</Link>
          <ChevronLeft className="w-4 h-4" />
          <span className="text-gray-700">سفارش عمده</span>
        </div>

        <div className="bg-gradient-to-l from-[#dc2626] to-[#991b1b] rounded-2xl p-8 mb-6 text-white">
          <Building2 className="w-12 h-12 mb-3" />
          <h1 className="text-3xl font-bold">سفارش عمده YIO</h1>
          <p className="opacity-90 mt-2 max-w-2xl">
            برای فروشگاه‌ها، شرکت‌ها و مشتریان عمده، تخفیف ویژه و قیمت استثنایی. درخواست خود را ثبت کنید تا کارشناسان ما با شما تماس بگیرند.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* مزایا */}
          <div className="space-y-3">
            <div className="bg-white rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <Package className="w-5 h-5 text-[#dc2626]" />
                <h3 className="font-bold">تخفیف ویژه</h3>
              </div>
              <p className="text-sm text-gray-600">برای خریدهای بالای ۵۰ عدد، تا ۳۰٪ تخفیف</p>
            </div>
            <div className="bg-white rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="w-5 h-5 text-[#dc2626]" />
                <h3 className="font-bold">پاسخ سریع</h3>
              </div>
              <p className="text-sm text-gray-600">ظرف ۲۴ ساعت کاری با شما تماس می‌گیریم</p>
            </div>
            <div className="bg-white rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <Phone className="w-5 h-5 text-[#dc2626]" />
                <h3 className="font-bold">پشتیبانی اختصاصی</h3>
              </div>
              <p className="text-sm text-gray-600">مشاوره تخصصی انتخاب محصولات</p>
            </div>
          </div>

          {/* فرم */}
          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit} className="bg-white rounded-xl p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>نام شرکت / فروشگاه *</Label>
                  <Input value={formData.companyName} onChange={e => setFormData({ ...formData, companyName: e.target.value })} required />
                </div>
                <div className="space-y-2">
                  <Label>نام شخص مسئول *</Label>
                  <Input value={formData.contactPerson} onChange={e => setFormData({ ...formData, contactPerson: e.target.value })} required />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>شماره موبایل *</Label>
                  <Input value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })} dir="ltr" placeholder="09121234567" required />
                </div>
                <div className="space-y-2">
                  <Label>ایمیل</Label>
                  <Input type="email" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} dir="ltr" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>شهر *</Label>
                  <Input value={formData.city} onChange={e => setFormData({ ...formData, city: e.target.value })} required />
                </div>
                <div className="space-y-2">
                  <Label>دسته‌بندی محصول *</Label>
                  <Select value={formData.productCategory} onValueChange={v => setFormData({ ...formData, productCategory: v })}>
                    <SelectTrigger><SelectValue placeholder="انتخاب" /></SelectTrigger>
                    <SelectContent>
                      {categories.map(c => <SelectItem key={c.id} value={c.title}>{c.icon} {c.title}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>تعداد تقریبی (حداقل ۱۰) *</Label>
                <Input type="number" min="10" value={formData.quantity} onChange={e => setFormData({ ...formData, quantity: e.target.value })} required />
              </div>

              <div className="space-y-2">
                <Label>توضیحات</Label>
                <Textarea value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} rows={3} />
              </div>

              <Button type="submit" disabled={loading} className="w-full bg-[#dc2626] hover:bg-[#b91c1c] h-12">
                <Send className="w-4 h-4 ml-2" />
                {loading ? 'در حال ارسال...' : 'ثبت درخواست'}
              </Button>
            </form>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
