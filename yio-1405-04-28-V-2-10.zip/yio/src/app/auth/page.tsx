'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { ArrowLeft, ShieldCheck, RefreshCw, Phone, Mail, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import Image from 'next/image';
import { Header } from '@/components/shop/header';
import { Footer } from '@/components/shop/footer';

export default function AuthPage() {
  const router = useRouter();
  const [step, setStep] = useState<'identifier' | 'verify'>('identifier');
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);

  const [identifier, setIdentifier] = useState('');
  const [identifierType, setIdentifierType] = useState<'phone' | 'email'>('phone');
  const [maskedIdentifier, setMaskedIdentifier] = useState('');
  const [verifyCode, setVerifyCode] = useState('');
  const [devCode, setDevCode] = useState('');

  // تایمر ارسال مجدد
  useEffect(() => {
    if (resendTimer <= 0) return;
    const t = setTimeout(() => setResendTimer(resendTimer - 1), 1000);
    return () => clearTimeout(t);
  }, [resendTimer]);

  // تشخیص خودکار نوع ورودی
  const detectType = (value: string): 'phone' | 'email' | 'invalid' => {
    const v = value.trim().toLowerCase();
    if (!v) return 'invalid';
    if (/^09\d{9}$/.test(v)) return 'phone';
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) return 'email';
    return 'invalid';
  };

  const handleIdentifierSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const type = detectType(identifier);
    if (type === 'invalid') {
      toast.error('شماره موبایل (09XXXXXXXXX) یا ایمیل معتبر وارد کنید');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/auth/otp-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier }),
      });

      const data = await res.json();

      if (res.ok) {
        setIdentifierType(data.method);
        setMaskedIdentifier(data.maskedIdentifier);
        if (data.verifyCode) setDevCode(data.verifyCode);
        setStep('verify');
        setResendTimer(60); // 60 ثانیه تا ارسال مجدد
        toast.success(`کد تایید به ${data.method === 'phone' ? 'موبایل' : 'ایمیل'} ارسال شد`);
      } else {
        toast.error(data.error || 'خطا');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifySubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (verifyCode.length !== 6) {
      toast.error('کد ۶ رقمی را وارد کنید');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch('/api/auth/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: verifyCode, identifier }),
      });

      const data = await res.json();

      if (res.ok) {
        toast.success(data.isNewUser ? 'خوش آمدید! حساب شما ایجاد شد' : 'خوش آمدید!');
        // اگر کاربر جدید است، به صفحه پروفایل برای تکمیل اطلاعات
        router.push(data.isNewUser ? '/profile?welcome=1' : '/');
        setTimeout(() => window.location.reload(), 500);
      } else {
        toast.error(data.error || 'خطا');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    if (resendTimer > 0) return;
    setLoading(true);
    try {
      const res = await fetch('/api/auth/otp-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ identifier }),
      });
      const data = await res.json();
      if (res.ok) {
        if (data.verifyCode) setDevCode(data.verifyCode);
        setResendTimer(60);
        toast.success('کد جدید ارسال شد');
      } else {
        toast.error(data.error || 'خطا');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setGoogleLoading(true);
    try {
      // در محیط واقعی، اینجا باید Google Identity Services استفاده شود
      // و ID Token از گوگل دریافت و verify شود
      // برای حالا، یک پیام نمایش می‌دهیم که قابلیت فعال است
      toast.info(
        'برای فعال‌سازی ورود با گوگل، باید Google Client ID را در تنظیمات سایت پیکربندی کنید.',
        { duration: 5000 }
      );

      // شبیه‌سازی ورود موفق برای تست (در محیط واقعی حذف شود)
      if (process.env.NODE_ENV === 'development') {
        const res = await fetch('/api/auth/google', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            googleId: 'test_google_' + Date.now(),
            email: 'googleuser@gmail.com',
            name: 'کاربر گوگل',
            avatar: null,
          }),
        });
        const data = await res.json();
        if (data.success) {
          toast.success('ورود با گوگل موفق بود');
          router.push('/');
          setTimeout(() => window.location.reload(), 500);
        }
      }
    } catch {
      toast.error('خطا در ورود با گوگل');
    }
    setGoogleLoading(false);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
      <Header />
      
      <main className="flex-1 flex items-center justify-center py-12 px-4">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            {/* هدر */}
            <div className="bg-gradient-to-l from-[#dc2626] to-[#991b1b] text-white p-6 text-center">
              <div className="w-16 h-16 mx-auto mb-2 relative">
                <Image src="/yio-logo.png" alt="YIO" fill sizes="64px" className="object-contain" />
              </div>
              <h1 className="text-xl font-bold">
                {step === 'verify' ? 'تایید کد' : 'ورود به YIO'}
              </h1>
              <p className="text-xs opacity-90 mt-1">
                {step === 'verify'
                  ? `کد ۶ رقمی ارسال شده به ${maskedIdentifier} را وارد کنید`
                  : 'با موبایل یا ایمیل'}
              </p>
            </div>

            <div className="p-6">
              {step === 'identifier' ? (
                <form onSubmit={handleIdentifierSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <div className="relative">
                      {/* آیکون تشخیص نوع */}
                      <div className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">
                        {detectType(identifier) === 'email' ? (
                          <Mail className="w-5 h-5" />
                        ) : (
                          <Phone className="w-5 h-5" />
                        )}
                      </div>
                      <Input
                        type="text"
                        value={identifier}
                        onChange={e => setIdentifier(e.target.value)}
                        placeholder="شماره موبایل یا پست الکترونیک"
                        dir="ltr"
                        className="pr-11 pl-4 h-12 text-left text-base"
                        autoFocus
                        required
                      />
                    </div>
                    <p className="text-xs text-gray-500">
                      مثال: 09121234567 یا you@example.com
                    </p>
                  </div>

                  <Button
                    type="submit"
                    disabled={loading || detectType(identifier) === 'invalid'}
                    className="w-full bg-[#dc2626] hover:bg-[#b91c1c] h-12 text-base font-bold"
                  >
                    {loading ? 'لطفا صبر کنید...' : 'ورود به YIO'}
                  </Button>

                  <p className="text-xs text-center text-gray-500 leading-5">
                    ورود شما به معنای پذیرش شرایط YIO و قوانین حریم‌خصوصی است
                  </p>

                  {/* جداکننده */}
                  <div className="flex items-center gap-2 py-2">
                    <div className="flex-1 h-px bg-gray-200"></div>
                    <span className="text-xs text-gray-400">یا</span>
                    <div className="flex-1 h-px bg-gray-200"></div>
                  </div>

                  {/* دکمه ورود با گوگل */}
                  <Button
                    type="button"
                    onClick={handleGoogleLogin}
                    disabled={googleLoading}
                    variant="outline"
                    className="w-full h-12 border-gray-300 hover:bg-gray-50"
                  >
                    {googleLoading ? (
                      <Loader2 className="w-5 h-5 ml-2 animate-spin" />
                    ) : (
                      <svg className="w-5 h-5 ml-2" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                      </svg>
                    )}
                    ورود با حساب گوگل
                  </Button>
                </form>
              ) : (
                <form onSubmit={handleVerifySubmit} className="space-y-4">
                  {devCode && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-800 text-center">
                      <p className="font-bold">🔧 محیط توسعه</p>
                      <p>کد تایید شما: <code className="bg-white px-2 py-0.5 rounded font-bold">{devCode}</code></p>
                      <p className="text-xs mt-1 opacity-75">
                        (در محیط واقعی به {identifierType === 'phone' ? 'موبایل' : 'ایمیل'} ارسال می‌شود)
                      </p>
                    </div>
                  )}

                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-gray-700">
                      کد تایید ۶ رقمی
                    </label>
                    <Input
                      value={verifyCode}
                      onChange={e => setVerifyCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                      placeholder="123456"
                      dir="ltr"
                      className="text-center text-2xl font-bold tracking-widest h-14"
                      maxLength={6}
                      autoFocus
                      required
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={loading || verifyCode.length !== 6}
                    className="w-full bg-[#dc2626] hover:bg-[#b91c1c] h-12 font-bold"
                  >
                    <ShieldCheck className="w-4 h-4 ml-2" />
                    {loading ? 'در حال تایید...' : 'تایید و ورود'}
                  </Button>

                  <div className="flex items-center justify-between text-xs">
                    <button
                      type="button"
                      onClick={() => { setStep('identifier'); setVerifyCode(''); setDevCode(''); }}
                      className="text-gray-500 hover:text-gray-700 flex items-center gap-1"
                    >
                      <ArrowLeft className="w-3 h-3" />
                      تغییر شماره/ایمیل
                    </button>

                    <button
                      type="button"
                      onClick={handleResend}
                      disabled={resendTimer > 0 || loading}
                      className="text-[#dc2626] hover:underline disabled:text-gray-400 disabled:no-underline flex items-center gap-1"
                    >
                      <RefreshCw className="w-3 h-3" />
                      {resendTimer > 0 ? `ارسال مجدد (${resendTimer}s)` : 'ارسال مجدد کد'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
