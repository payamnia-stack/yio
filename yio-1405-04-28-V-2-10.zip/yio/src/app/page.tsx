'use client';

import { useState, useEffect } from 'react';
import { Header } from '@/components/shop/header';
import { HeroSlider } from '@/components/shop/hero-slider';
import { CategoryCircles } from '@/components/shop/category-circles';
import { SpecialOffers } from '@/components/shop/special-offers';
import { ProductSection } from '@/components/shop/product-section';
import { PromoBanners } from '@/components/shop/promo-banners';
import { PopularBrands } from '@/components/shop/popular-brands';
import { ServiceFeatures } from '@/components/shop/service-features';
import { Footer } from '@/components/shop/footer';
import { CartDrawer } from '@/components/shop/cart-drawer';
import { AdminLogin } from '@/components/admin/admin-login';
import { AdminPanel } from '@/components/admin/admin-panel';
import { MobileAdminApp } from '@/components/admin/mobile-admin-app';

export default function Home() {
  const [adminMode, setAdminMode] = useState(false);
  const [authChecked, setAuthChecked] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  // تشخیص حالت ادمین از URL و موبایل بودن
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('admin') === '1') {
      setAdminMode(true);
      setAuthChecked(false);
      fetch('/api/admin/check')
        .then(r => r.json())
        .then(d => setIsAuthenticated(d.authenticated))
        .catch(() => setIsAuthenticated(false))
        .finally(() => setAuthChecked(true));
    }

    // تشخیص موبایل
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const handleAdminClick = async () => {
    setAdminMode(true);
    setAuthChecked(false);
    try {
      const res = await fetch('/api/admin/check');
      const data = await res.json();
      setIsAuthenticated(data.authenticated);
    } catch {
      setIsAuthenticated(false);
    } finally {
      setAuthChecked(true);
    }
  };

  const handleExitAdmin = () => {
    setAdminMode(false);
    setIsAuthenticated(false);
    // پاک کردن ?admin=1 از URL
    if (window.location.search.includes('admin=1')) {
      window.history.replaceState({}, '', '/');
    }
  };

  // حالت ادمین
  if (adminMode) {
    if (!authChecked) {
      return (
        <div className="fixed inset-0 bg-white flex items-center justify-center">
          <div className="text-center">
            <div className="inline-block w-12 h-12 border-4 border-gray-200 border-t-[#dc2626] rounded-full animate-spin mb-4"></div>
            <p className="text-gray-500">در حال بررسی دسترسی...</p>
          </div>
        </div>
      );
    }

    if (!isAuthenticated) {
      return <AdminLogin onSuccess={() => setIsAuthenticated(true)} onCancel={handleExitAdmin} />;
    }

    // در همه حالت‌ها (موبایل و دسکتاپ) از AdminPanel یکپارچه استفاده می‌شود
    // AdminPanel با drawer موبایل خودش responsive را مدیریت می‌کند
    return <AdminPanel onExit={handleExitAdmin} />;
  }

  // حالت عادی فروشگاه
  return (
    <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-4 md:py-6 space-y-4 md:space-y-6">
        <HeroSlider />
        <ServiceFeatures />
        <CategoryCircles />
        <SpecialOffers />
        <PromoBanners />

        <ProductSection
          title="پرفروش‌ترین محصولات چوبی"
          icon="🔥"
          endpoint="/api/shop/products?sort=rating&pageSize=5"
        />

        <section
          className="rounded-xl overflow-hidden p-6 md:p-10 text-white relative min-h-[200px] flex items-center"
          style={{ background: 'linear-gradient(135deg, #8b5cf6 0%, #5d4037 100%)' }}
        >
          <div className="relative z-10 max-w-lg">
            <h3 className="text-2xl md:text-3xl font-bold mb-3">محصولات دست‌ساز YIO</h3>
            <p className="text-base md:text-lg opacity-90 mb-5">
              هر محصول با دست‌های هنرمندان ایرانی و از چوب‌های طبیعی مرغوب ساخته می‌شود. کیفیت و ایمنی تضمین شده.
            </p>
            <button className="bg-white text-[#5d4037] font-bold px-6 py-2.5 rounded-lg hover:bg-gray-100">
              درباره ما بیشتر بدانید
            </button>
          </div>
          <div className="absolute left-8 text-9xl opacity-20">🪵</div>
        </section>

        <ProductSection
          title="جدیدترین محصولات"
          icon="✨"
          endpoint="/api/shop/products?sort=newest&pageSize=5"
        />

        <PopularBrands />
      </main>

      <Footer />
      <CartDrawer />
    </div>
  );
}
