'use client';

import { useState, useEffect } from 'react';
import { Info, ChevronLeft, Heart, Leaf, Award, Users, Truck } from 'lucide-react';
import { Header } from '@/components/shop/header';
import { Footer } from '@/components/shop/footer';
import Link from 'next/link';

export default function AboutPage() {
  const [settings, setSettings] = useState<Record<string, string>>({});

  useEffect(() => {
    fetch('/api/settings').then(r => r.json()).then(d => setSettings(d.settings || {})).catch(() => {});
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
          <Link href="/" className="hover:text-[#dc2626]">خانه</Link>
          <ChevronLeft className="w-4 h-4" />
          <span className="text-gray-700">درباره ما</span>
        </div>

        <div className="bg-gradient-to-l from-[#dc2626] to-[#991b1b] rounded-2xl p-8 mb-6 text-white text-center">
          <Info className="w-12 h-12 mx-auto mb-3" />
          <h1 className="text-3xl font-bold">{settings.about_title || 'درباره YIO'}</h1>
          <p className="opacity-90 mt-2">{settings.about_subtitle || 'محصولات چوبی دست‌ساز با عشق و هنر ایرانی'}</p>
        </div>

        <div className="bg-white rounded-xl p-6 md:p-8 mb-6 max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold mb-4 text-[#dc2626]">داستان ما</h2>
          <p className="text-gray-700 leading-8 mb-4 whitespace-pre-line">
            {settings.about_story || 'YIO با عشق به چوب و هنر دست‌ساز ایرانی شروع شد. ما باور داریم که چوب طبیعی نه تنها زیباست، بلکه دوست‌دار محیط زیست و ایمن برای کودکان و خانواده‌هاست. هر محصول YIO با دقت و هنر توسط صنعتگران ماهر ایرانی ساخته می‌شود.'}
          </p>
          <p className="text-gray-700 leading-8 whitespace-pre-line">
            {settings.about_mission || 'هدف ما این است که محصولات چوبی با کیفیت و زیبا را با قیمت منصفانه به دست شما برسانیم و در عین حال از هنر و صنعت ایرانی حمایت کنیم.'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl mx-auto mb-6">
          <div className="bg-white rounded-xl p-6 text-center">
            <Leaf className="w-10 h-10 text-green-600 mx-auto mb-3" />
            <h3 className="font-bold mb-2">۱۰۰٪ طبیعی</h3>
            <p className="text-sm text-gray-600">از چوب‌های طبیعی و مرغوب</p>
          </div>
          <div className="bg-white rounded-xl p-6 text-center">
            <Award className="w-10 h-10 text-amber-600 mx-auto mb-3" />
            <h3 className="font-bold mb-2">کیفیت تضمینی</h3>
            <p className="text-sm text-gray-600">ضمانت اصالت و کیفیت</p>
          </div>
          <div className="bg-white rounded-xl p-6 text-center">
            <Heart className="w-10 h-10 text-[#dc2626] mx-auto mb-3" />
            <h3 className="font-bold mb-2">دست‌ساز</h3>
            <p className="text-sm text-gray-600">ساخته دست هنرمندان ایرانی</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
          <div className="bg-white rounded-xl p-6">
            <Users className="w-8 h-8 text-[#dc2626] mb-3" />
            <h3 className="font-bold mb-2">تیم ما</h3>
            <p className="text-sm text-gray-600 leading-6">
              تیم YIO شامل صنعتگران چوب، طراحان و متخصصان فروش است که همه با عشق به چوب و هنر دست‌ساز گرد هم آمده‌اند.
            </p>
          </div>
          <div className="bg-white rounded-xl p-6">
            <Truck className="w-8 h-8 text-[#dc2626] mb-3" />
            <h3 className="font-bold mb-2">ارسال به سراسر کشور</h3>
            <p className="text-sm text-gray-600 leading-6">
              ما محصولاتمان را به تمام نقاط ایران ارسال می‌کنیم و تلاش می‌کنیم در کوتاه‌ترین زمان به دست شما برسد.
            </p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
