'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { SlidersHorizontal, Grid, List, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Header } from '@/components/shop/header';
import { Footer } from '@/components/shop/footer';
import { CartDrawer } from '@/components/shop/cart-drawer';
import { ProductCard } from '@/components/shop/product-card';
import { ProductDetailModal } from '@/components/shop/product-detail-modal';
import { Skeleton } from '@/components/ui/skeleton';
import { categories, toFa, type Product } from '@/lib/shop-data';
import Link from 'next/link';

export default function CategoryPage() {
  const params = useParams();
  const slug = decodeURIComponent(params.slug as string);

  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [sort, setSort] = useState('newest');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [inStockOnly, setInStockOnly] = useState(false);
  const [specialOnly, setSpecialOnly] = useState(false);
  const [fastDeliveryOnly, setFastDeliveryOnly] = useState(false);
  const [discountOnly, setDiscountOnly] = useState(false);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [showFilters, setShowFilters] = useState(false);
  // اطلاعات دسته‌بندی که از API برمی‌گردد (شامل نام فارسی به‌جای slug)
  const [categoryRecord, setCategoryRecord] = useState<any>(null);

  const categoryInfo = categoryRecord || categories.find(c => c.title === slug);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams({ sort, page: String(page) });
    if (minPrice) params.set('minPrice', minPrice);
    if (maxPrice) params.set('maxPrice', maxPrice);
    if (inStockOnly) params.set('inStock', 'true');
    if (specialOnly) params.set('isSpecial', 'true');
    if (fastDeliveryOnly) params.set('fastDelivery', 'true');
    if (discountOnly) params.set('hasDiscount', 'true');

    fetch(`/api/shop/category/${encodeURIComponent(slug)}?${params}`)
      .then(r => r.json())
      .then(data => {
        setProducts(data.products || []);
        setTotalPages(data.pagination?.totalPages || 1);
        setTotal(data.pagination?.total || 0);
        setCategoryRecord(data.category || null);
      })
      .finally(() => setLoading(false));
  }, [slug, sort, minPrice, maxPrice, inStockOnly, specialOnly, fastDeliveryOnly, discountOnly, page]);

  return (
    <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-6">
        {/* breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
          <Link href="/" className="hover:text-[#dc2626]">خانه</Link>
          <ChevronLeft className="w-4 h-4" />
          <span className="text-gray-700">{categoryInfo?.title || slug}</span>
        </div>

        {/* هدر دسته */}
        <div
          className="rounded-xl p-6 mb-4 text-white flex items-center justify-between"
          style={{ background: categoryInfo ? `linear-gradient(135deg, ${categoryInfo.color}, ${categoryInfo.color}dd)` : '#dc2626' }}
        >
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <span className="text-3xl">{categoryInfo?.icon || '📦'}</span>
              {categoryInfo?.title || slug}
            </h1>
            <p className="text-sm opacity-90 mt-1 fa-num">{toFa(total)} محصول</p>
          </div>
        </div>

        <div className="flex gap-4">
          {/* فیلتر سایدبار */}
          <aside className={`${showFilters ? 'block' : 'hidden'} md:block w-full md:w-64 shrink-0`}>
            <div className="bg-white rounded-xl p-4 sticky top-20">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold">فیلترها</h3>
                <button
                  onClick={() => { setMinPrice(''); setMaxPrice(''); setInStockOnly(false); setSpecialOnly(false); setFastDeliveryOnly(false); setDiscountOnly(false); }}
                  className="text-xs text-[#dc2626] hover:underline"
                >
                  پاک کردن
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">محدوده قیمت (تومان)</label>
                  <div className="flex gap-2">
                    <Input type="number" placeholder="از" value={minPrice} onChange={e => setMinPrice(e.target.value)} className="text-sm" />
                    <Input type="number" placeholder="تا" value={maxPrice} onChange={e => setMaxPrice(e.target.value)} className="text-sm" />
                  </div>
                </div>

                <div>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={inStockOnly}
                      onChange={e => setInStockOnly(e.target.checked)}
                      className="w-4 h-4 accent-[#dc2626]"
                    />
                    <span className="text-sm">فقط کالاهای موجود</span>
                  </label>
                </div>

                <div>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={specialOnly}
                      onChange={e => setSpecialOnly(e.target.checked)}
                      className="w-4 h-4 accent-[#dc2626]"
                    />
                    <span className="text-sm">فقط کالاهای فروش ویژه</span>
                  </label>
                </div>

                <div>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={fastDeliveryOnly}
                      onChange={e => setFastDeliveryOnly(e.target.checked)}
                      className="w-4 h-4 accent-[#dc2626]"
                    />
                    <span className="text-sm">فقط ارسال سریع</span>
                  </label>
                </div>

                <div>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={discountOnly}
                      onChange={e => setDiscountOnly(e.target.checked)}
                      className="w-4 h-4 accent-[#dc2626]"
                    />
                    <span className="text-sm">فقط کالاهای تخفیف‌دار</span>
                  </label>
                </div>
              </div>
            </div>
          </aside>

          {/* لیست محصولات */}
          <div className="flex-1">
            {/* نوار ابزار */}
            <div className="bg-white rounded-xl p-3 mb-4 flex items-center justify-between gap-3">
              <Button variant="outline" size="sm" onClick={() => setShowFilters(!showFilters)} className="md:hidden">
                <SlidersHorizontal className="w-4 h-4 ml-1" />
                فیلتر
              </Button>

              <span className="text-sm text-gray-500 fa-num hidden md:block">
                {toFa(products.length)} محصول از {toFa(total)}
              </span>

              <Select value={sort} onValueChange={v => { setSort(v); setPage(1); }}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">جدیدترین</SelectItem>
                  <SelectItem value="priceAsc">ارزان‌ترین</SelectItem>
                  <SelectItem value="priceDesc">گران‌ترین</SelectItem>
                  <SelectItem value="rating">محبوب‌ترین</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* محصولات */}
            {loading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
                {Array.from({ length: 8 }).map((_, i) => (
                  <div key={i} className="space-y-2">
                    <Skeleton className="aspect-square w-full" />
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                  </div>
                ))}
              </div>
            ) : products.length === 0 ? (
              <div className="bg-white rounded-xl p-12 text-center">
                <p className="text-gray-500 mb-4">محصولی در این دسته یافت نشد</p>
                <Link href="/" className="text-[#dc2626] hover:underline">بازگشت به فروشگاه</Link>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
                {products.map(p => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}

            {/* صفحه‌بندی */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-2 mt-6">
                <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>
                  <ChevronRight className="w-4 h-4" />
                </Button>
                {Array.from({ length: Math.min(totalPages, 5) }).map((_, idx) => {
                  const pn = idx + 1;
                  return (
                    <Button
                      key={pn}
                      variant={page === pn ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setPage(pn)}
                      className={page === pn ? 'bg-[#dc2626] hover:bg-[#b91c1c]' : ''}
                    >
                      <span className="fa-num">{toFa(pn)}</span>
                    </Button>
                  );
                })}
                <Button variant="outline" size="sm" disabled={page === totalPages} onClick={() => setPage(p => p + 1)}>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
      <CartDrawer />
    </div>
  );
}
