'use client';

import { useState, useEffect } from 'react';
import { Mail, Phone, MapPin, Send, ChevronLeft, Clock } from 'lucide-react';
import { Header } from '@/components/shop/header';
import { Footer } from '@/components/shop/footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import Link from 'next/link';

export default function ContactPage() {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [formData, setFormData] = useState({ name: '', phone: '', email: '', subject: '', message: '' });

  useEffect(() => {
    fetch('/api/settings').then(r => r.json()).then(d => setSettings(d.settings || {})).catch(() => {});
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^09\d{9}$/.test(formData.phone)) { toast.error('موبایل نامعتبر'); return; }

    setLoading(true);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      if (res.ok) { setSuccess(true); toast.success('پیام ارسال شد'); }
      else { const d = await res.json(); toast.error(d.error); }
    } catch { toast.error('خطا'); }
    finally { setLoading(false); }
  };

  if (success) {
    return (
      <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
        <Header />
        <main className="flex-1 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md text-center">
            <Send className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold mb-2">پیام ارسال شد!</h1>
            <p className="text-gray-600 mb-6">پاسخ شما در اولین فرصت داده می‌شود.</p>
            <Link href="/"><Button className="bg-[#dc2626] hover:bg-[#b91c1c]">بازگشت</Button></Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
          <Link href="/" className="hover:text-[#dc2626]">خانه</Link>
          <ChevronLeft className="w-4 h-4" />
          <span className="text-gray-700">تماس با ما</span>
        </div>

        <div className="bg-gradient-to-l from-[#dc2626] to-[#991b1b] rounded-2xl p-8 mb-6 text-white text-center">
          <Mail className="w-12 h-12 mx-auto mb-3" />
          <h1 className="text-3xl font-bold">تماس با ما</h1>
          <p className="opacity-90 mt-2">پشتیبانی همیشه در کنار شماست</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {/* اطلاعات تماس از دیتابیس */}
          <div className="space-y-3">
            <div className="bg-white rounded-xl p-4">
              <Phone className="w-5 h-5 text-[#dc2626] mb-2" />
              <p className="text-xs text-gray-500">تلفن پشتیبانی</p>
              <p className="font-bold fa-num" dir="ltr">{settings.contact_phone || '۰۲۱-۹۱۰۰۲۰۲۰'}</p>
            </div>
            <div className="bg-white rounded-xl p-4">
              <Mail className="w-5 h-5 text-[#dc2626] mb-2" />
              <p className="text-xs text-gray-500">ایمیل</p>
              <p className="font-bold text-sm" dir="ltr">{settings.contact_email || 'info@yio-shop.ir'}</p>
            </div>
            <div className="bg-white rounded-xl p-4">
              <MapPin className="w-5 h-5 text-[#dc2626] mb-2" />
              <p className="text-xs text-gray-500">آدرس</p>
              <p className="text-sm leading-6 whitespace-pre-line">{settings.contact_address || 'تهران، خیابان ولیعصر، کارگاه تولید چوب YIO'}</p>
            </div>
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
              <Clock className="w-5 h-5 text-amber-600 mb-2" />
              <p className="text-xs text-amber-800 whitespace-pre-line">{settings.contact_hours || 'شنبه تا چهارشنبه: ۹-۱۸\nپنجشنبه: ۹-۱۳\nجمعه: تعطیل'}</p>
            </div>
          </div>

          {/* فرم */}
          <form onSubmit={handleSubmit} className="lg:col-span-2 bg-white rounded-xl p-6 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="contact-name">نام و نام خانوادگی *</Label>
                <Input id="contact-name" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="مثلاً: محمد محمدی" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="contact-phone">شماره موبایل *</Label>
                <Input id="contact-phone" value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })} dir="ltr" placeholder="09121234567" required />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="contact-email">ایمیل</Label>
              <Input id="contact-email" type="email" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} dir="ltr" placeholder="example@email.com" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="contact-subject">موضوع *</Label>
              <Input id="contact-subject" value={formData.subject} onChange={e => setFormData({ ...formData, subject: e.target.value })} placeholder="موضوع پیام خود را وارد کنید" required />
            </div>
            <div className="space-y-2">
              <Label htmlFor="contact-message">پیام *</Label>
              <Textarea id="contact-message" value={formData.message} onChange={e => setFormData({ ...formData, message: e.target.value })} rows={5} placeholder="پیام خود را اینجا بنویسید..." required />
            </div>
            <Button type="submit" disabled={loading} className="w-full bg-[#dc2626] hover:bg-[#b91c1c] h-12">
              <Send className="w-4 h-4 ml-2" />
              {loading ? 'در حال ارسال...' : 'ارسال پیام'}
            </Button>
          </form>
        </div>
      </main>

      <Footer />
    </div>
  );
}
