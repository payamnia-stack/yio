'use client';

import Link from 'next/link';
import { Home, Search } from 'lucide-react';
import { Header } from '@/components/shop/header';
import { Footer } from '@/components/shop/footer';

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
      <Header />
      <main className="flex-1 flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="text-9xl font-bold text-[#dc2626] opacity-20 mb-4">۴۰۴</div>
          <h1 className="text-2xl font-bold mb-3">صفحه یافت نشد</h1>
          <p className="text-gray-500 mb-6">صفحه‌ای که به دنبال آن هستید وجود ندارد یا حذف شده است.</p>
          <div className="flex gap-3 justify-center">
            <Link href="/" className="bg-[#dc2626] text-white font-bold px-6 py-3 rounded-lg hover:bg-[#b91c1c] flex items-center gap-2">
              <Home className="w-4 h-4" /> صفحه اصلی
            </Link>
            <Link href="/search" className="border border-gray-300 font-bold px-6 py-3 rounded-lg hover:bg-gray-50 flex items-center gap-2">
              <Search className="w-4 h-4" /> جستجو
            </Link>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
