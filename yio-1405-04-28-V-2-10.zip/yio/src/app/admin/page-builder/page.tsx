'use client';

import dynamic from 'next/dynamic';

// بارگذاری Editor فقط در کلاینت (برای جلوگیری از SSR issues با @dnd-kit)
const Editor = dynamic(
  () => import('@/components/page-builder/Editor').then((m) => m.Editor),
  { ssr: false },
);

export default function PageBuilderPage() {
  return (
    <div className="fixed inset-0 z-50 bg-white">
      <Editor />
    </div>
  );
}
