'use client';

import { useState, useEffect } from 'react';
import { HelpCircle, ChevronLeft, ChevronDown } from 'lucide-react';
import { Header } from '@/components/shop/header';
import { Footer } from '@/components/shop/footer';
import Link from 'next/link';

const categoryLabels: Record<string, string> = {
  general: 'عمومی', products: 'محصولات', shipping: 'ارسال', payment: 'پرداخت', returns: 'بازگشت کالا',
};

export default function FAQPage() {
  const [grouped, setGrouped] = useState<Record<string, any[]>>({});
  const [loading, setLoading] = useState(true);
  const [openItems, setOpenItems] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetch('/api/faq')
      .then(r => r.json())
      .then(data => { setGrouped(data.grouped || {}); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const toggle = (id: string) => {
    setOpenItems(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
          <Link href="/" className="hover:text-[#dc2626]">خانه</Link>
          <ChevronLeft className="w-4 h-4" />
          <span className="text-gray-700">سؤالات متداول</span>
        </div>

        <div className="bg-gradient-to-l from-[#dc2626] to-[#991b1b] rounded-2xl p-8 mb-6 text-white text-center">
          <HelpCircle className="w-12 h-12 mx-auto mb-3" />
          <h1 className="text-3xl font-bold">سؤالات متداول</h1>
          <p className="opacity-90 mt-2">پاسخ سؤالات رایج شما</p>
        </div>

        <div className="max-w-3xl mx-auto">
          {loading ? (
            <div className="text-center py-8"><div className="inline-block w-8 h-8 border-4 border-gray-200 border-t-[#dc2626] rounded-full animate-spin"></div></div>
          ) : Object.keys(grouped).length === 0 ? (
            <p className="text-center text-gray-500 py-8">سؤالی ثبت نشده</p>
          ) : (
            <div className="space-y-6">
              {Object.entries(grouped).map(([category, faqs]) => (
                <div key={category}>
                  <h2 className="font-bold text-[#dc2626] mb-3 pb-2 border-b-2 border-red-100">{categoryLabels[category] || category}</h2>
                  <div className="space-y-2">
                    {faqs.map(faq => {
                      const isOpen = openItems.has(String(faq.id));
                      return (
                        <div key={faq.id} className="bg-white rounded-lg overflow-hidden">
                          <button onClick={() => toggle(String(faq.id))} className="w-full p-4 text-right flex items-center justify-between gap-2 hover:bg-gray-50">
                            <span className="font-medium">{faq.question}</span>
                            <ChevronDown className={`w-5 h-5 text-gray-400 shrink-0 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                          </button>
                          {isOpen && <div className="px-4 pb-4 text-gray-600 leading-7">{faq.answer}</div>}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
