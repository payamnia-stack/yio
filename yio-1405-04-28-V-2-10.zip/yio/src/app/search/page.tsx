'use client';

import { useState, useEffect } from 'react';
import { Search as SearchIcon, ChevronLeft } from 'lucide-react';
import { Header } from '@/components/shop/header';
import { Footer } from '@/components/shop/footer';
import { CartDrawer } from '@/components/shop/cart-drawer';
import { ProductCard } from '@/components/shop/product-card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { toFa, type Product } from '@/lib/shop-data';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';

export default function SearchPage() {
  const searchParams = useSearchParams();
  const initialQuery = searchParams.get('q') || '';

  const [query, setQuery] = useState(initialQuery);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [sort, setSort] = useState('newest');
  const [total, setTotal] = useState(0);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!query.trim()) {
      setProducts([]);
      return;
    }

    setLoading(true);
    const params = new URLSearchParams({ search: query, sort, pageSize: '24' });

    fetch(`/api/shop/products?${params}`)
      .then(r => r.json())
      .then(data => {
        setProducts(data.products || []);
        setTotal(data.pagination?.total || 0);
      })
      .finally(() => setLoading(false));
  }, [query, sort]);

  return (
    <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
          <Link href="/" className="hover:text-[#dc2626]">خانه</Link>
          <ChevronLeft className="w-4 h-4" />
          <span className="text-gray-700">جستجو</span>
        </div>

        <div className="bg-white rounded-xl p-4 mb-4">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <SearchIcon className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="جستجوی محصول..."
                className="pr-10"
                autoFocus
              />
            </div>
            <Select value={sort} onValueChange={setSort}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">جدیدترین</SelectItem>
                <SelectItem value="priceAsc">ارزان‌ترین</SelectItem>
                <SelectItem value="priceDesc">گران‌ترین</SelectItem>
                <SelectItem value="rating">محبوب‌ترین</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {query && (
            <p className="text-sm text-gray-500 mt-3 fa-num">
              {loading ? 'در حال جستجو...' : `${toFa(total)} نتیجه برای "${query}"`}
            </p>
          )}
        </div>

        {!query.trim() ? (
          <div className="bg-white rounded-xl p-12 text-center text-gray-500">
            <SearchIcon className="w-16 h-16 mx-auto mb-3 text-gray-300" />
            <p>برای جستجو کلمه‌ای را وارد کنید</p>
          </div>
        ) : loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="aspect-[3/4] w-full" />
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="bg-white rounded-xl p-12 text-center">
            <p className="text-gray-500 mb-4">نتیجه‌ای یافت نشد</p>
            <Link href="/" className="text-[#dc2626] hover:underline">بازگشت به فروشگاه</Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
            {products.map(p => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </main>

      <Footer />
      <CartDrawer />
    </div>
  );
}
