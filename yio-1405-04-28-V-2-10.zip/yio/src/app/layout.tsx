import type { Metadata, Viewport } from "next";
import { Vazirmatn } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { StockProvider } from "@/components/shop/stock-provider";

const vazirmatn = Vazirmatn({
  subsets: ["arabic", "latin"],
  variable: "--font-vazirmatn",
  display: "swap",
});

export const metadata: Metadata = {
  title: "YIO | محصولات چوبی دست‌ساز",
  description: "خرید اینترنتی اسباب‌بازی چوبی، ظروف آشپزخانه، مبلمان و دکوراسیون چوبی دست‌ساز با بهترین کیفیت و قیمت",
  keywords: ["YIO", "محصولات چوبی", "اسباب‌بازی چوبی", "ظروف چوبی", "مبلمان چوبی", "دکوراسیون چوبی", "دست‌ساز"],
  manifest: process.env.NODE_ENV === 'production' ? "/manifest.json" : undefined,
  icons: {
    icon: "/yio-logo.png",
    apple: "/yio-logo.png",
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: 'default',
    title: 'YIO Admin',
  },
};

export const viewport: Viewport = {
  themeColor: '#dc2626',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const isProd = process.env.NODE_ENV === 'production';

  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body
        className={`${vazirmatn.variable} font-sans antialiased bg-[#f0f0f1] text-foreground`}
        style={{ fontFamily: 'var(--font-vazirmatn), system-ui, sans-serif' }}
      >
        <StockProvider>
          {children}
        </StockProvider>
        <Toaster />
        <SonnerToaster position="top-center" dir="rtl" />
        <script
          dangerouslySetInnerHTML={{
            __html: isProd
              ? `// Production: ثبت Service Worker
              if ('serviceWorker' in navigator) {
                window.addEventListener('load', function() {
                  navigator.serviceWorker.register('/sw.js').then(function(registration) {
                    console.log('YIO SW registered:', registration.scope);
                  }).catch(function(err) {
                    console.log('YIO SW registration failed:', err);
                  });
                });
              }`
              : `// Development: پاک کردن Service Worker و کش
              if ('serviceWorker' in navigator) {
                window.addEventListener('load', function() {
                  // پاک کردن همه SW های قبلی
                  navigator.serviceWorker.getRegistrations().then(function(registrations) {
                    for (var registration of registrations) {
                      registration.unregister().then(function(success) {
                        if (success) console.log('SW unregistered (dev mode)');
                      });
                    }
                  });
                  // پاک کردن همه کش‌ها
                  if ('caches' in window) {
                    caches.keys().then(function(names) {
                      for (var name of names) {
                        caches.delete(name);
                      }
                    });
                  }
                });
              }`,
          }}
        />
      </body>
    </html>
  );
}
