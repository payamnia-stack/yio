'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import {
  User, Package, Heart, MapPin, Award, LogOut, Edit2, Plus, X, Save,
  ChevronLeft, Camera, Upload, Check, Mail, Phone, Lock, MapPin as MapPinIcon,
  Building, CreditCard, Wallet, Users, Bell, Clock, Star, Smartphone,
  Trash2, RotateCcw, FileText, Filter,
} from 'lucide-react';
import { Header } from '@/components/shop/header';
import { Footer } from '@/components/shop/footer';
import { CartDrawer } from '@/components/shop/cart-drawer';
import { OrderDetailsModal } from '@/components/shop/order-details-modal';
import { AvatarEditor } from '@/components/shop/avatar-editor';
import { UserLevelSlider } from '@/components/shop/user-level-slider';
import { OrderTimeline } from '@/components/shop/order-timeline';
import { WalletTab } from '@/components/shop/wallet-tab';
import { ReferralTab } from '@/components/shop/referral-tab';
import {
  RecentlyViewedTab, ReviewsTab, SessionsTab, CustomerPhotosTab,
  ReturnsTab, NotificationsTab, DeleteAccountTab,
} from '@/components/shop/profile-tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { LocationSelector } from '@/components/shop/location-selector';
import { formatPrice, toFa, getOrderStatusInfo } from '@/lib/shop-data';
import { toast } from 'sonner';
import Link from 'next/link';

type ProfileTab =
  | 'orders'
  | 'info'
  | 'wishlist'
  | 'points'
  | 'wallet'
  | 'referral'
  | 'notifications'
  | 'recent'
  | 'reviews'
  | 'sessions'
  | 'photos'
  | 'returns'
  | 'delete';

export default function ProfilePage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const isWelcome = searchParams.get('welcome') === '1';

  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<ProfileTab>(isWelcome ? 'info' : (searchParams.get('tab') as ProfileTab) || 'orders');
  const [selectedOrderId, setSelectedOrderId] = useState<number | null>(null);

  // فرم اطلاعات کاربری (شامل آدرس)
  const [profileForm, setProfileForm] = useState({
    name: '',
    email: '',
    phone: '',
    nationalCode: '',
    province: '',
    city: '',
    address: '',
    postalCode: '',
    companyName: '',
    password: '',
    currentPassword: '',
  });
  const [savingProfile, setSavingProfile] = useState(false);

  useEffect(() => {
    fetch('/api/user/profile').then(async r => {
      if (r.status === 401) { router.push('/auth'); return null; }
      try { return await r.json(); } catch { return null; }
    }).then(d => {
      if (d) {
        setData(d);
        const u = d.user || {};
        setProfileForm({
          name: u.name || '',
          email: u.email || '',
          phone: u.phone?.startsWith('nomail_') ? '' : (u.phone || ''),
          nationalCode: u.nationalCode || '',
          province: u.province || '',
          city: u.city || '',
          address: u.address || '',
          postalCode: u.postalCode || '',
          companyName: u.companyName || '',
          password: '',
          currentPassword: '',
        });
      }
    }).finally(() => setLoading(false));
  }, [router]);

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/');
    setTimeout(() => window.location.reload(), 500);
  };

  const refresh = () => {
    fetch('/api/user/profile').then(async r => {
      try { return await r.json(); } catch { return null; }
    }).then(d => {
      if (d) {
        setData(d);
        const u = d.user || {};
        setProfileForm({
          name: u.name || '',
          email: u.email || '',
          phone: u.phone?.startsWith('nomail_') ? '' : (u.phone || ''),
          nationalCode: u.nationalCode || '',
          province: u.province || '',
          city: u.city || '',
          address: u.address || '',
          postalCode: u.postalCode || '',
          companyName: u.companyName || '',
          password: '',
          currentPassword: '',
        });
      }
    });
  };

  const handleAvatarChange = (newAvatar: string) => {
    setData((prev: any) => prev ? { ...prev, user: { ...prev.user, avatar: newAvatar } } : prev);
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      const payload: any = {
        name: profileForm.name,
        email: profileForm.email,
        nationalCode: profileForm.nationalCode,
        province: profileForm.province,
        city: profileForm.city,
        address: profileForm.address,
        postalCode: profileForm.postalCode,
        companyName: profileForm.companyName,
      };
      if (profileForm.phone) payload.phone = profileForm.phone;
      if (profileForm.password) {
        payload.password = profileForm.password;
        if (data.user.hasPassword) payload.currentPassword = profileForm.currentPassword;
      }

      const res = await fetch('/api/user/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const result = await res.json();
      if (res.ok) {
        toast.success('اطلاعات ذخیره شد');
        setProfileForm({ ...profileForm, password: '', currentPassword: '' });
        refresh();
      } else {
        toast.error(result.error || 'خطا در ذخیره');
      }
    } catch {
      toast.error('خطا در ارتباط');
    } finally {
      setSavingProfile(false);
    }
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="w-12 h-12 border-4 border-gray-200 border-t-[#dc2626] rounded-full animate-spin"></div></div>;
  if (!data) return null;

  const user = data.user;
  const hasPassword = !!user.hasPassword;
  const level = user.level || 1;
  const levelInfo = user.levelInfo;
  const nextLevelHint = user.nextLevelHint;
  const levelProgress = user.levelProgress || 0;

  return (
    <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-6">
        {/* هدر پروفایل */}
        <div className="bg-gradient-to-l from-[#dc2626] to-[#991b1b] rounded-2xl p-6 text-white mb-4">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-4">
              {/* آواتار با آیکون مداد برای ویرایش */}
              <div className="relative">
                <AvatarEditor
                  currentAvatar={user.avatar}
                  userName={user.name}
                  size="lg"
                  onAvatarChange={handleAvatarChange}
                />
              </div>
              <div>
                <h1 className="text-2xl font-bold">{user.name || 'کاربر جدید'}</h1>
                {user.email && <p className="opacity-90 text-sm" dir="ltr">{user.email}</p>}
                {user.phone && !user.phone.startsWith('nomail_') && (
                  <p className="opacity-90 text-sm" dir="ltr">{user.phone}</p>
                )}
                {/* Badge سطح کاربر */}
                <div className="mt-2 inline-flex items-center gap-1.5 bg-white/20 backdrop-blur px-3 py-1 rounded-full text-xs font-bold">
                  <span>{levelInfo?.icon}</span>
                  <span>سطح {toFa(level)} - {levelInfo?.title}</span>
                </div>
              </div>
            </div>
            <div className="text-center">
              <div className="bg-white/20 rounded-xl px-4 py-2">
                <Award className="w-6 h-6 mx-auto mb-1" />
                <p className="text-2xl font-bold fa-num">{toFa(data.loyaltyPoints)}</p>
                <p className="text-xs opacity-90">امتیاز</p>
              </div>
            </div>
          </div>
        </div>

        {/* اسلایدر سطح کاربری */}
        <div className="mb-4">
          <UserLevelSlider
            level={level}
            progress={levelProgress}
            nextLevelHint={nextLevelHint}
          />
        </div>

        {/* پیام خوش‌آمدگویی برای کاربران جدید */}
        {isWelcome && (
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-4 flex items-start gap-3">
            <div className="text-2xl">🎉</div>
            <div>
              <h3 className="font-bold text-blue-900">خوش آمدید!</h3>
              <p className="text-sm text-blue-700 mt-1">
                حساب شما با موفقیت ایجاد شد. لطفاً اطلاعات خود را تکمیل کنید تا سطح کاربری شما ارتقا یابد و بتوانید سفارش ثبت کنید.
              </p>
              <Button
                onClick={() => setTab('info')}
                className="mt-3 bg-blue-600 hover:bg-blue-700"
                size="sm"
              >
                تکمیل اطلاعات
                <ChevronLeft className="w-4 h-4 mr-1" />
              </Button>
            </div>
          </div>
        )}

        {/* تب‌ها */}
        <div className="bg-white rounded-xl p-2 shadow-sm flex gap-1 mb-4 overflow-x-auto no-scrollbar">
          {[
            { key: 'orders', label: `سفارش‌ها`, icon: Package },
            { key: 'info', label: 'اطلاعات کاربری', icon: User },
            { key: 'wallet', label: 'کیف پول', icon: Wallet },
            { key: 'wishlist', label: `علاقه‌مندی‌ها`, icon: Heart },
            { key: 'recent', label: 'بازدید اخیر', icon: Clock },
            { key: 'reviews', label: 'نظرات من', icon: Star },
            { key: 'photos', label: 'عکس‌های من', icon: Camera },
            { key: 'returns', label: 'مرجوعی‌ها', icon: RotateCcw },
            { key: 'referral', label: 'دعوت دوستان', icon: Users },
            { key: 'notifications', label: 'اعلان‌ها', icon: Bell },
            { key: 'sessions', label: 'دستگاه‌ها', icon: Smartphone },
            { key: 'points', label: `امتیازات`, icon: Award },
            { key: 'delete', label: 'حذف حساب', icon: Trash2 },
          ].map(t => {
            const Icon = t.icon;
            return (
              <button key={t.key} onClick={() => setTab(t.key as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap ${tab === t.key ? 'bg-[#dc2626] text-white' : 'text-gray-600 hover:bg-gray-50'}`}>
                <Icon className="w-4 h-4" /> {t.label}
              </button>
            );
          })}
          <button onClick={handleLogout} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-red-600 hover:bg-red-50 mr-auto">
            <LogOut className="w-4 h-4" /> خروج
          </button>
        </div>

        {/* محتوای تب‌ها */}

        {/* تب سفارشات */}
        {tab === 'orders' && (
          <div className="space-y-2">
            {data.orders.length === 0 ? (
              <div className="bg-white rounded-xl p-8 text-center text-gray-500">
                <Package className="w-12 h-12 mx-auto mb-2 text-gray-200" />
                سفارشی ندارید
                <Link href="/" className="block mt-4 text-[#dc2626] font-medium hover:underline">شروع خرید</Link>
              </div>
            ) : (
              data.orders.map((order: any) => {
                const si = getOrderStatusInfo(order.status);
                const totalItems = order.items.reduce((sum: number, item: any) => sum + item.quantity, 0);
                return (
                  <button
                    key={order.id}
                    onClick={() => setSelectedOrderId(order.id)}
                    className="w-full bg-white rounded-xl p-4 border border-gray-100 hover:border-[#dc2626] hover:shadow-md transition-all text-right group"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2 flex-wrap">
                        <code className="font-bold text-[#dc2626]" dir="ltr">{order.orderNumber}</code>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${si.color}`}>
                          {si.icon} {si.label}
                        </span>
                      </div>
                      <span className="font-bold fa-num">{formatPrice(order.finalAmount)} ت</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex -space-x-2 rtl:space-x-reverse">
                        {order.items.slice(0, 4).map((item: any, idx: number) => (
                          <div key={idx} className="w-10 h-10 rounded-lg overflow-hidden border-2 border-white bg-gray-100 shrink-0">
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img src={item.productImage} alt={item.productTitle} className="w-full h-full object-cover" />
                          </div>
                        ))}
                        {order.items.length > 4 && (
                          <div className="w-10 h-10 rounded-lg bg-gray-100 border-2 border-white flex items-center justify-center text-[10px] font-bold text-gray-500 fa-num shrink-0">
                            +{toFa(order.items.length - 4)}
                          </div>
                        )}
                      </div>
                      <span className="text-xs text-gray-500 mr-2 fa-num">
                        {toFa(order.items.length)} کالا • {toFa(totalItems)} عدد
                      </span>
                      <div className="mr-auto flex items-center gap-1 text-[#dc2626] text-xs font-medium opacity-70 group-hover:opacity-100">
                        <span className="hidden sm:inline">مشاهده جزئیات</span>
                        <ChevronLeft className="w-4 h-4" />
                      </div>
                    </div>
                    <div className="flex items-center justify-between mt-3 pt-2 border-t border-gray-100 text-[10px] text-gray-400">
                      <span>
                        {new Intl.DateTimeFormat('fa-IR', { year: 'numeric', month: 'long', day: 'numeric' }).format(new Date(order.createdAt))}
                      </span>
                      {order.trackingCode && (
                        <span className="text-purple-600" dir="ltr">کد رهگیری: {order.trackingCode}</span>
                      )}
                    </div>
                  </button>
                );
              })
            )}
          </div>
        )}

        {/* تب اطلاعات کاربری (شامل آدرس) */}
        {tab === 'info' && (
          <form onSubmit={handleSaveProfile} className="bg-white rounded-xl p-6 shadow-sm space-y-5">
            <h3 className="font-bold flex items-center gap-2">
              <User className="w-5 h-5 text-[#dc2626]" />
              اطلاعات شخصی
            </h3>

            <div className="space-y-2">
              <Label htmlFor="name">نام و نام خانوادگی *</Label>
              <Input
                id="name"
                value={profileForm.name}
                onChange={e => setProfileForm({ ...profileForm, name: e.target.value })}
                placeholder="مثلا: محمد رضایی"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="email">ایمیل</Label>
                <div className="relative">
                  <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="email"
                    type="email"
                    value={profileForm.email}
                    onChange={e => setProfileForm({ ...profileForm, email: e.target.value })}
                    placeholder="you@example.com"
                    dir="ltr"
                    className="pr-10 text-left"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">شماره موبایل</Label>
                <div className="relative">
                  <Phone className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="phone"
                    value={profileForm.phone}
                    onChange={e => setProfileForm({ ...profileForm, phone: e.target.value })}
                    placeholder="09121234567"
                    dir="ltr"
                    className="pr-10 text-left"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="nationalCode">کد ملی</Label>
                <div className="relative">
                  <CreditCard className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="nationalCode"
                    value={profileForm.nationalCode}
                    onChange={e => setProfileForm({ ...profileForm, nationalCode: e.target.value })}
                    placeholder="کد ملی ۱۰ رقمی"
                    dir="ltr"
                    className="pr-10 text-left"
                    maxLength={10}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="companyName">نام شرکت (برای مشتریان سازمانی)</Label>
                <div className="relative">
                  <Building className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input
                    id="companyName"
                    value={profileForm.companyName}
                    onChange={e => setProfileForm({ ...profileForm, companyName: e.target.value })}
                    placeholder="اختیاری"
                  />
                </div>
              </div>
            </div>

            {/* بخش آدرس */}
            <div className="border-t border-gray-100 pt-4">
              <h4 className="font-bold mb-3 flex items-center gap-2">
                <MapPinIcon className="w-4 h-4 text-[#dc2626]" />
                آدرس ارسال
              </h4>

              <div className="space-y-3">
                <LocationSelector
                  province={profileForm.province}
                  city={profileForm.city}
                  onProvinceChange={v => setProfileForm({ ...profileForm, province: v })}
                  onCityChange={v => setProfileForm({ ...profileForm, city: v })}
                />

                <div className="space-y-2">
                  <Label htmlFor="address">آدرس کامل</Label>
                  <Textarea
                    id="address"
                    value={profileForm.address}
                    onChange={e => setProfileForm({ ...profileForm, address: e.target.value })}
                    placeholder="خیابان، کوچه، پلاک، واحد"
                    rows={2}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="postalCode">کد پستی</Label>
                  <Input
                    id="postalCode"
                    value={profileForm.postalCode}
                    onChange={e => setProfileForm({ ...profileForm, postalCode: e.target.value })}
                    placeholder="کد پستی ۱۰ رقمی"
                    dir="ltr"
                    className="text-left"
                    maxLength={10}
                  />
                </div>
              </div>
            </div>

            {/* بخش رمز عبور */}
            <div className="border-t border-gray-100 pt-4 space-y-3">
              <h4 className="font-bold text-sm flex items-center gap-2">
                <Lock className="w-4 h-4 text-gray-500" />
                {hasPassword ? 'تغییر رمز عبور' : 'تعیین رمز عبور (اختیاری)'}
              </h4>

              {hasPassword && (
                <div className="space-y-2">
                  <Label htmlFor="currentPassword">رمز عبور فعلی</Label>
                  <Input
                    id="currentPassword"
                    type="password"
                    value={profileForm.currentPassword}
                    onChange={e => setProfileForm({ ...profileForm, currentPassword: e.target.value })}
                    placeholder="••••••"
                    dir="ltr"
                    className="text-left"
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="password">
                  {hasPassword ? 'رمز عبور جدید' : 'رمز عبور (حداقل ۶ کاراکتر)'}
                </Label>
                <Input
                  id="password"
                  type="password"
                  value={profileForm.password}
                  onChange={e => setProfileForm({ ...profileForm, password: e.target.value })}
                  placeholder="••••••"
                  dir="ltr"
                  className="text-left"
                />
                {!hasPassword && (
                  <p className="text-xs text-gray-500">
                    💡 اگر رمز عبور تعیین کنید، می‌توانید علاوه بر OTP، با موبایل/ایمیل + رمز هم وارد شوید
                  </p>
                )}
              </div>
            </div>

            <Button
              type="submit"
              disabled={savingProfile}
              className="w-full bg-[#dc2626] hover:bg-[#b91c1c] h-12"
            >
              {savingProfile ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin ml-1"></div>
                  در حال ذخیره...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 ml-1" />
                  ذخیره تغییرات
                </>
              )}
            </Button>
          </form>
        )}

        {/* تب علاقه‌مندی‌ها */}
        {tab === 'wishlist' && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {data.wishlist.length === 0 ? (
              <div className="col-span-full bg-white rounded-xl p-8 text-center text-gray-500">علاقه‌مندی ندارید</div>
            ) : (
              data.wishlist.map((w: any) => (
                <Link key={w.id} href={`/products/${w.productId}`} className="bg-white rounded-lg border border-gray-100 overflow-hidden hover:shadow-md">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={w.product.image} alt={w.product.title} className="w-full aspect-square object-cover" />
                  <div className="p-2">
                    <p className="text-xs line-clamp-2">{w.product.title}</p>
                    <p className="font-bold text-[#dc2626] fa-num mt-1">{formatPrice(w.product.discountPrice || w.product.price)} ت</p>
                  </div>
                </Link>
              ))
            )}
          </div>
        )}

        {/* تب امتیازات */}
        {tab === 'points' && (
          <div className="space-y-4">
            <div className="bg-white rounded-xl p-8 text-center">
              <Award className="w-16 h-16 mx-auto mb-3 text-amber-500" />
              <p className="text-3xl font-bold fa-num text-[#dc2626]">{toFa(data.loyaltyPoints)}</p>
              <p className="text-gray-500 mt-2">امتیاز وفاداری شما</p>
              <p className="text-xs text-gray-400 mt-4">به ازای هر خرید، ۱ امتیاز به ازای هر ۱۰هزار تومان دریافت می‌کنید</p>
            </div>

            {/* آمار خرید */}
            {data.stats && (
              <div className="bg-white rounded-xl p-6">
                <h3 className="font-bold mb-4">آمار خرید شما</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <Package className="w-6 h-6 mx-auto mb-1 text-blue-500" />
                    <p className="text-xl font-bold fa-num">{toFa(data.stats.totalOrders)}</p>
                    <p className="text-xs text-gray-500">کل سفارش‌ها</p>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <Check className="w-6 h-6 mx-auto mb-1 text-green-500" />
                    <p className="text-xl font-bold fa-num">{toFa(data.stats.completedOrders)}</p>
                    <p className="text-xs text-gray-500">تکمیل شده</p>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <span className="text-2xl">💰</span>
                    <p className="text-sm font-bold fa-num mt-1">{formatPrice(data.stats.totalSpent)}</p>
                    <p className="text-xs text-gray-500">مجموع خرید</p>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <span className="text-2xl">⭐</span>
                    <p className="text-xl font-bold fa-num mt-1">{toFa(data.stats.reviewsCount)}</p>
                    <p className="text-xs text-gray-500">نظرات ثبت شده</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* تب کیف پول */}
        {tab === 'wallet' && <WalletTab />}

        {/* تب دعوت دوستان */}
        {tab === 'referral' && <ReferralTab />}

        {/* تب اعلان‌ها */}
        {tab === 'notifications' && <NotificationsTab />}

        {/* تب بازدیدهای اخیر */}
        {tab === 'recent' && <RecentlyViewedTab />}

        {/* تب نظرات من */}
        {tab === 'reviews' && <ReviewsTab />}

        {/* تب عکس‌های من */}
        {tab === 'photos' && <CustomerPhotosTab />}

        {/* تب مرجوعی‌ها */}
        {tab === 'returns' && <ReturnsTab />}

        {/* تب دستگاه‌های متصل */}
        {tab === 'sessions' && <SessionsTab />}

        {/* تب حذف حساب */}
        {tab === 'delete' && <DeleteAccountTab />}
      </main>
      <Footer />
      <CartDrawer />

      {/* مدال جزئیات سفارش */}
      <OrderDetailsModal orderId={selectedOrderId} onClose={() => setSelectedOrderId(null)} />
    </div>
  );
}
