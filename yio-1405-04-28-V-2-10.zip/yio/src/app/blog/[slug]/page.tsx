'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { Header } from '@/components/shop/header';
import { Footer } from '@/components/shop/footer';
import { Skeleton } from '@/components/ui/skeleton';
import Link from 'next/link';
import { ChevronLeft, Calendar, Eye, ArrowLeft } from 'lucide-react';

export default function BlogPostPage() {
  const params = useParams();
  const slug = params.slug as string;
  const [post, setPost] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/blog?slug=${slug}`).then(r => {
      if (!r.ok) throw new Error();
      return r.json();
    }).then(d => setPost(d.post)).catch(() => {}).finally(() => setLoading(false));
  }, [slug]);

  if (loading) return <div className="min-h-screen flex items-center justify-center"><Skeleton className="w-3/4 h-96" /></div>;
  if (!post) return <div className="min-h-screen flex items-center justify-center"><Link href="/blog" className="text-[#dc2626]">بازگشت به بلاگ</Link></div>;

  return (
    <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-6 max-w-3xl">
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
          <Link href="/" className="hover:text-[#dc2626]">خانه</Link>
          <ChevronLeft className="w-4 h-4" />
          <Link href="/blog" className="hover:text-[#dc2626]">بلاگ</Link>
          <ChevronLeft className="w-4 h-4" />
          <span className="text-gray-700 line-clamp-1">{post.title}</span>
        </div>

        <article className="bg-white rounded-2xl p-6 md:p-8 shadow-sm">
          {post.coverImage && <img src={post.coverImage} alt={post.title} className="w-full h-64 object-cover rounded-xl mb-4" />}
          <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded">{post.category}</span>
          <h1 className="text-3xl font-bold mt-2 mb-4">{post.title}</h1>
          <div className="flex items-center gap-4 text-sm text-gray-400 mb-6 pb-4 border-b border-gray-100">
            <span className="flex items-center gap-1"><Calendar className="w-4 h-4" /> {new Intl.DateTimeFormat('fa-IR', { dateStyle: 'full' }).format(new Date(post.createdAt))}</span>
            <span className="flex items-center gap-1"><Eye className="w-4 h-4" /> {post.views} بازدید</span>
          </div>
          <div className="prose max-w-none text-gray-700 leading-8 whitespace-pre-wrap">{post.content}</div>
        </article>

        <Link href="/blog" className="flex items-center gap-2 mt-6 text-[#dc2626] hover:underline">
          <ArrowLeft className="w-4 h-4" /> بازگشت به بلاگ
        </Link>
      </main>
      <Footer />
    </div>
  );
}
