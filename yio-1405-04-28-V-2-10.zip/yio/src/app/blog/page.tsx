'use client';

import { useState, useEffect } from 'react';
import { Header } from '@/components/shop/header';
import { Footer } from '@/components/shop/footer';
import { Skeleton } from '@/components/ui/skeleton';
import Link from 'next/link';
import { Calendar, Eye, ChevronLeft } from 'lucide-react';

export default function BlogPage() {
  const [posts, setPosts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/blog').then(r => r.json()).then(d => setPosts(d.posts || [])).finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
          <Link href="/" className="hover:text-[#dc2626]">خانه</Link>
          <ChevronLeft className="w-4 h-4" />
          <span className="text-gray-700">بلاگ</span>
        </div>

        <div className="bg-gradient-to-l from-[#dc2626] to-[#991b1b] rounded-2xl p-8 mb-6 text-white text-center">
          <h1 className="text-3xl font-bold">بلاگ YIO</h1>
          <p className="opacity-90 mt-2">آموزش‌ها، نکات مراقبت از چوب و اخبار</p>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-64 w-full" />)}
          </div>
        ) : posts.length === 0 ? (
          <div className="bg-white rounded-xl p-12 text-center text-gray-500">مقاله‌ای یافت نشد</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {posts.map(p => (
              <Link key={p.id} href={`/blog/${p.slug}`} className="bg-white rounded-xl overflow-hidden border border-gray-100 hover:shadow-md transition-all">
                {p.coverImage && <img src={p.coverImage} alt={p.title} className="w-full h-40 object-cover" />}
                <div className="p-4">
                  <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded">{p.category}</span>
                  <h3 className="font-bold mt-2 line-clamp-2">{p.title}</h3>
                  {p.excerpt && <p className="text-sm text-gray-500 mt-1 line-clamp-2">{p.excerpt}</p>}
                  <div className="flex items-center gap-3 text-xs text-gray-400 mt-3">
                    <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {new Intl.DateTimeFormat('fa-IR', { month: 'short', day: 'numeric' }).format(new Date(p.createdAt))}</span>
                    <span className="flex items-center gap-1"><Eye className="w-3 h-3" /> {p.views}</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}
