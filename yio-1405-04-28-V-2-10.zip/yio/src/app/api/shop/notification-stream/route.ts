import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession } from '@/lib/user-auth';
import { notificationEmitter } from '@/lib/notification-events';

// SSE endpoint برای اعلان‌های real-time کاربر
export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET(request: NextRequest) {
  const user = await getUserFromSession();
  if (!user) {
    return new Response('Unauthorized', { status: 401 });
  }

  const headers = new Headers({
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no',
  });

  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    start(controller) {
      // تأیید اتصال
      controller.enqueue(encoder.encode(': connected\n\n'));

      // heartbeat هر 30 ثانیه
      const heartbeat = setInterval(() => {
        try {
          controller.enqueue(encoder.encode(': heartbeat\n\n'));
        } catch {
          clearInterval(heartbeat);
        }
      }, 30000);

      // subscribe به اعلان‌های این کاربر
      const unsubscribe = notificationEmitter.subscribe(user.id, (update) => {
        try {
          const data = `data: ${JSON.stringify(update)}\n\n`;
          controller.enqueue(encoder.encode(data));
        } catch {}
      });

      // پاکسازی
      request.signal.addEventListener('abort', () => {
        clearInterval(heartbeat);
        unsubscribe();
        try { controller.close(); } catch {}
      });
    },
  });

  return new Response(stream, { headers });
}
