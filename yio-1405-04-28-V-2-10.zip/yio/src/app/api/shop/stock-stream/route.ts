import { NextRequest } from 'next/server';
import { stockEmitter, StockUpdate } from '@/lib/stock-events';

// SSE endpoint برای آپدیت آنلاین موجودی محصولات
// کاربران به این endpoint متصل می‌شوند و هر تغییری در موجودی
// (از پنل ادمین یا از n8n/Google Sheet) به صورت زنده دریافت می‌شود.
export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export async function GET(request: NextRequest) {
  // تنظیم headerهای SSE
  const headers = new Headers({
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no', // برای nginx
  });

  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    start(controller) {
      // ارسال پیام اولیه برای تأیید اتصال
      controller.enqueue(encoder.encode(': connected\n\n'));

      // ارسال heartbeat هر 30 ثانیه برای حفظ اتصال
      const heartbeat = setInterval(() => {
        try {
          controller.enqueue(encoder.encode(': heartbeat\n\n'));
        } catch {
          clearInterval(heartbeat);
        }
      }, 30000);

      // subscribe به آپدیت‌های موجودی
      const unsubscribe = stockEmitter.subscribe((update: StockUpdate) => {
        try {
          const data = `data: ${JSON.stringify(update)}\n\n`;
          controller.enqueue(encoder.encode(data));
        } catch {
          // connection بسته شده
        }
      });

      // پاکسازی وقتی کلاینت قطع می‌کند
      request.signal.addEventListener('abort', () => {
        clearInterval(heartbeat);
        unsubscribe();
        try {
          controller.close();
        } catch {}
      });
    },
  });

  return new Response(stream, { headers });
}
