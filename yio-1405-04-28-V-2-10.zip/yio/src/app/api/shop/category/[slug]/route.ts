import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET: محصولات یک دسته‌بندی با فیلتر چندگانه
export async function GET(
  request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;
    const categorySlug = decodeURIComponent(slug);

    // ابتدا slug را به نام فارسی دسته ترجمه می‌کنیم
    // (slug با خط تیره است، اما category در جدول Product با نام فارسی با نیم‌فاصله ذخیره می‌شود)
    const categoryRecord = await db.category.findUnique({
      where: { slug: categorySlug },
      select: { id: true, title: true, slug: true },
    });

    // اگر دسته در جدول Category یافت نشد، به‌عنوان fallback مستقیماً از slug استفاده می‌کنیم
    // (برای پشتیبانی از دسته‌های قدیمی که ممکن است در جدول Category ثبت نشده باشند)
    const category = categoryRecord?.title || categorySlug;

    const { searchParams } = new URL(request.url);
    const sort = searchParams.get('sort') || 'newest';
    const minPrice = searchParams.get('minPrice');
    const maxPrice = searchParams.get('maxPrice');
    const inStock = searchParams.get('inStock');
    const isSpecial = searchParams.get('isSpecial');
    const fastDelivery = searchParams.get('fastDelivery');
    const hasDiscount = searchParams.get('hasDiscount');
    const woodType = searchParams.get('woodType');
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = 12;

    const where: any = { category, isPublished: true };

    if (inStock === 'true') where.inStock = true;
    if (isSpecial === 'true') where.isSpecial = true;
    if (fastDelivery === 'true') where.fastDelivery = true;
    if (hasDiscount === 'true') where.discountPercent = { gt: 0 };
    if (woodType) where.woodType = woodType;

    if (minPrice || maxPrice) {
      where.price = {};
      if (minPrice) where.price.gte = parseInt(minPrice);
      if (maxPrice) where.price.lte = parseInt(maxPrice);
    }

    let orderBy: any = { createdAt: 'desc' };
    if (sort === 'priceAsc') orderBy = { price: 'asc' };
    else if (sort === 'priceDesc') orderBy = { price: 'desc' };
    else if (sort === 'rating') orderBy = { rating: 'desc' };

    const [total, products] = await Promise.all([
      db.product.count({ where }),
      db.product.findMany({
        where,
        orderBy,
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
    ]);

    // گرفتن لیست نوع چوب‌های موجود در این دسته برای فیلتر
    const woodTypes = await db.product.findMany({
      where: { category, woodType: { not: null } },
      select: { woodType: true },
      distinct: ['woodType'],
    });

    return NextResponse.json({
      products,
      pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
      woodTypes: woodTypes.map((w: any) => w.woodType).filter(Boolean),
      category: categoryRecord, // اطلاعات دسته (title, slug, icon, color) برای نمایش در UI
    });
  } catch (error) {
    console.error('Error fetching category products:', error);
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
