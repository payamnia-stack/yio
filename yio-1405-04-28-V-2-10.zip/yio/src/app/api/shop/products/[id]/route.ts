import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET: دریافت یک محصول با ID (عمومی)
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const productId = parseInt(id);

    if (isNaN(productId)) {
      return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });
    }

    const product = await db.product.findUnique({
      where: { id: productId },
    });

    if (!product) {
      return NextResponse.json({ error: 'محصول یافت نشد' }, { status: 404 });
    }

    // گرفتن محصولات مرتبط (همان دسته)
    const related = await db.product.findMany({
      where: {
        category: product.category,
        id: { not: product.id },
        inStock: true,
      },
      take: 4,
      orderBy: { rating: 'desc' },
    });

    return NextResponse.json({ product, related });
  } catch (error) {
    console.error('Error fetching product:', error);
    return NextResponse.json({ error: 'خطا در دریافت محصول' }, { status: 500 });
  }
}
