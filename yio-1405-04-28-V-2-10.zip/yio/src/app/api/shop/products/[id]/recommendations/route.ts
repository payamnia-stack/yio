import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET: محصولات پیشنهادی هوشمند
// الگوریتم: پیدا کردن سفارش‌هایی که شامل این محصول هستن،
// بعد گرفتن سایر محصولات اون سفارش‌ها
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const productId = parseInt(id);

    if (isNaN(productId)) {
      return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });
    }

    // ۱. پیدا کردن تمام سفارش‌هایی که این محصول در آن‌ها هست
    const orderItems = await db.orderItem.findMany({
      where: { productId },
      select: { orderId: true },
    });

    const orderIds = orderItems.map(oi => oi.orderId);

    if (orderIds.length === 0) {
      // ۲a. اگر سفارشی نبود، محصولات هم‌دسته را پیشنهاد بده
      const product = await db.product.findUnique({ where: { id: productId } });
      if (!product) return NextResponse.json({ recommendations: [] });

      const related = await db.product.findMany({
        where: {
          category: product.category,
          id: { not: productId },
          inStock: true,
        },
        orderBy: { rating: 'desc' },
        take: 5,
      });

      return NextResponse.json({
        recommendations: related,
        type: 'category',
        message: 'محصولات مشابه این دسته',
      });
    }

    // ۲. گرفتن تمام محصولات دیگر در همان سفارش‌ها
    const otherItems = await db.orderItem.findMany({
      where: {
        orderId: { in: orderIds },
        productId: { not: productId },
      },
      select: { productId: true, productTitle: true, productImage: true },
    });

    // ۳. شمارش تعداد دفعاتی که هر محصول همراه این محصول خرید شده
    const countMap: Record<number, { count: number; title: string; image: string }> = {};
    otherItems.forEach(item => {
      if (!countMap[item.productId]) {
        countMap[item.productId] = { count: 0, title: item.productTitle, image: item.productImage };
      }
      countMap[item.productId].count++;
    });

    // ۴. مرتب‌سازی بر اساس تعداد خرید مشترک
    const sortedIds = Object.entries(countMap)
      .sort((a, b) => b[1].count - a[1].count)
      .slice(0, 5)
      .map(([id]) => parseInt(id));

    if (sortedIds.length === 0) {
      // اگر محصول مشترکی نبود، محصولات هم‌دسته
      const product = await db.product.findUnique({ where: { id: productId } });
      if (!product) return NextResponse.json({ recommendations: [] });

      const related = await db.product.findMany({
        where: {
          category: product.category,
          id: { not: productId },
          inStock: true,
        },
        orderBy: { rating: 'desc' },
        take: 5,
      });

      return NextResponse.json({
        recommendations: related,
        type: 'category',
        message: 'محصولات مشابه این دسته',
      });
    }

    // ۵. گرفتن اطلاعات کامل محصولات پیشنهادی
    const recommendations = await db.product.findMany({
      where: {
        id: { in: sortedIds },
        inStock: true,
      },
    });

    // مرتب‌سازی بر اساس ترتیب sortedIds
    const sorted = sortedIds
      .map(id => recommendations.find(p => p.id === id))
      .filter(Boolean);

    return NextResponse.json({
      recommendations: sorted,
      type: 'smart',
      message: 'مشتریانی که این محصول را خریدند، این‌ها را هم خریدند',
    });
  } catch (error) {
    console.error('Smart recommendations error:', error);
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
