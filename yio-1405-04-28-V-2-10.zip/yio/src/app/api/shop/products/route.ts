import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// دریافت محصولات برای نمایش در فروشگاه (بدون نیاز به احراز هویت)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';
    const category = searchParams.get('category') || '';
    const sort = searchParams.get('sort') || 'newest';
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '12');
    const ids = searchParams.get('ids'); // برای دریافت محصولات خاص (مثلاً علاقه‌مندی‌ها)
    const includeOutOfStock = searchParams.get('includeOutOfStock') === 'true';

    // حالت دریافت بر اساس ids (برای علاقه‌مندی‌ها و...)
    if (ids) {
      const idArr = ids
        .split(',')
        .map(s => parseInt(s.trim()))
        .filter(n => !isNaN(n) && n > 0);

      if (idArr.length === 0) {
        return NextResponse.json({ products: [] });
      }

      // در این حالت، حتی محصولات ناموجود هم برگردانده می‌شوند
      const products = await db.product.findMany({
        where: { id: { in: idArr } },
        orderBy: { createdAt: 'desc' },
      });

      return NextResponse.json({
        products,
        pagination: {
          page: 1,
          pageSize: products.length,
          total: products.length,
          totalPages: 1,
        },
      });
    }

    // حالت عادی — نمایش همه محصولات منتشر شده (شامل ناموجودها)
    // محصولات ناموجود هم نمایش داده می‌شوند ولی دکمه خریدشان غیرفعال است
    const where: any = { isPublished: true };

    if (search) {
      where.OR = [
        { title: { contains: search } },
        { brand: { contains: search } },
        { woodType: { contains: search } },
      ];
    }

    if (category) {
      where.category = category;
    }

    // تعیین ترتیب
    let orderBy: any = { createdAt: 'desc' };
    if (sort === 'priceAsc') orderBy = { price: 'asc' };
    else if (sort === 'priceDesc') orderBy = { price: 'desc' };
    else if (sort === 'rating') orderBy = { rating: 'desc' };

    const total = await db.product.count({ where });

    const products = await db.product.findMany({
      where,
      orderBy,
      skip: (page - 1) * pageSize,
      take: pageSize,
    });

    return NextResponse.json({
      products,
      pagination: {
        page,
        pageSize,
        total,
        totalPages: Math.ceil(total / pageSize),
      },
    });
  } catch (error) {
    console.error('Error fetching shop products:', error);
    return NextResponse.json(
      { error: 'خطا در دریافت محصولات' },
      { status: 500 }
    );
  }
}
