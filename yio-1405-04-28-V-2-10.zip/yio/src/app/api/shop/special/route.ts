import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// دریافت محصولات فروش ویژه برای فروشگاه
export async function GET() {
  try {
    const products = await db.product.findMany({
      where: {
        isSpecial: true,
        isPublished: true,
      },
      orderBy: { discountPercent: 'desc' },
      take: 6,
    });

    return NextResponse.json({ products });
  } catch (error) {
    console.error('Error fetching special products:', error);
    return NextResponse.json(
      { error: 'خطا در دریافت محصولات فروش ویژه' },
      { status: 500 }
    );
  }
}
