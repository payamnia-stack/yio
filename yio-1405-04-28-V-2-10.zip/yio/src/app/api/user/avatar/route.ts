import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession, hashPassword, verifyPassword } from '@/lib/user-auth';
import { promises as fs } from 'fs';
import path from 'path';

const UPLOAD_DIR = path.join(process.cwd(), 'public', 'uploads');
const ALLOWED_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
const MAX_SIZE = 5 * 1024 * 1024; // 5MB

// POST: آپلود آواتار کاربر
export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const formData = await request.formData();
    const file = formData.get('avatar') as File | null;

    if (!file) {
      return NextResponse.json({ error: 'فایل ارسال نشده' }, { status: 400 });
    }

    if (file.size > MAX_SIZE) {
      return NextResponse.json({ error: 'حداکثر حجم ۵ مگابایت' }, { status: 400 });
    }

    const ext = path.extname(file.name).toLowerCase();
    if (!ALLOWED_EXTENSIONS.includes(ext)) {
      return NextResponse.json({ error: 'پسوند مجاز نیست (JPG, PNG, GIF, WebP)' }, { status: 400 });
    }

    // ساخت پوشه avatars در uploads
    const targetDir = path.join(UPLOAD_DIR, 'avatars');
    await fs.mkdir(targetDir, { recursive: true });

    // نام فایل یکتا
    const uniqueName = `user-${user.id}-${Date.now()}${ext}`;
    const fullPath = path.join(targetDir, uniqueName);

    // ذخیره فایل
    const buffer = Buffer.from(await file.arrayBuffer());
    await fs.writeFile(fullPath, buffer);

    const url = `/uploads/avatars/${uniqueName}`;

    // آپدیت آواتار کاربر
    await db.user.update({
      where: { id: user.id },
      data: { avatar: url },
    });

    return NextResponse.json({ success: true, avatar: url });
  } catch (error: any) {
    console.error('Avatar upload error:', error);
    return NextResponse.json({ error: 'خطا در آپلود' }, { status: 500 });
  }
}

// PATCH: انتخاب آواتار از بین مدل‌های پیش‌فرض
// body: { avatar: "/avatars/01-sunny.svg" }
export async function PATCH(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { avatar } = await request.json();

    if (!avatar || !avatar.startsWith('/avatars/')) {
      return NextResponse.json({ error: 'آواتار نامعتبر' }, { status: 400 });
    }

    await db.user.update({
      where: { id: user.id },
      data: { avatar },
    });

    return NextResponse.json({ success: true, avatar });
  } catch (error: any) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
