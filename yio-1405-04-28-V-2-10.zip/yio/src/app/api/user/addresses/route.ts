// API آدرس‌های کاربر
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession } from '@/lib/user-auth';
import { sanitizeInput, validateIranMobile } from '@/lib/security';

export async function GET() {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'وارد شوید' }, { status: 401 });
    const addresses = await db.address.findMany({ where: { userId: user.id }, orderBy: { isDefault: 'desc' } });
    return NextResponse.json({ addresses });
  } catch { return NextResponse.json({ error: 'خطا' }, { status: 500 }); }
}

export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'وارد شوید' }, { status: 401 });

    const body = await request.json();
    if (!body.recipientName || !body.phone || !body.province || !body.city || !body.address) {
      return NextResponse.json({ error: 'تمام فیلدها الزامی است' }, { status: 400 });
    }
    if (!validateIranMobile(body.phone)) return NextResponse.json({ error: 'موبایل نامعتبر' }, { status: 400 });

    // اگر پیش‌فرض است، بقیه را لغو کن
    if (body.isDefault) {
      await db.address.updateMany({ where: { userId: user.id }, data: { isDefault: false } });
    }

    const address = await db.address.create({
      data: {
        userId: user.id,
        title: sanitizeInput(body.title || 'خانه').slice(0, 50),
        recipientName: sanitizeInput(body.recipientName).slice(0, 100),
        phone: body.phone,
        province: body.province,
        city: body.city,
        address: sanitizeInput(body.address).slice(0, 500),
        postalCode: body.postalCode || null,
        isDefault: Boolean(body.isDefault ?? false),
      },
    });

    return NextResponse.json({ address, success: true });
  } catch { return NextResponse.json({ error: 'خطا' }, { status: 500 }); }
}
