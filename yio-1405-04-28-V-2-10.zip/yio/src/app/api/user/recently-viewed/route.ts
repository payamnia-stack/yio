import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession } from '@/lib/user-auth';

// GET: لیست بازدیدهای اخیر کاربر
export async function GET() {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const recent = await db.recentlyViewed.findMany({
      where: { userId: user.id },
      orderBy: { viewedAt: 'desc' },
      take: 20,
      include: {
        product: {
          select: {
            id: true,
            title: true,
            image: true,
            price: true,
            discountPrice: true,
            inStock: true,
            stockQuantity: true,
          },
        },
      },
    });

    return NextResponse.json({
      recentlyViewed: recent.map(r => r.product),
    });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// POST: ثبت بازدید از یک محصول
export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { productId } = await request.json();
    if (!productId) return NextResponse.json({ error: 'productId الزامی است' }, { status: 400 });

    const pid = parseInt(productId);
    if (isNaN(pid)) return NextResponse.json({ error: 'productId نامعتبر' }, { status: 400 });

    // upsert: اگر وجود دارد، viewedAt رو آپدیت کن؛ در غیر این صورت بساز
    await db.recentlyViewed.upsert({
      where: {
        userId_productId: {
          userId: user.id,
          productId: pid,
        },
      },
      update: {
        viewedAt: new Date(),
      },
      create: {
        userId: user.id,
        productId: pid,
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// DELETE: پاک کردن بازدیدهای اخیر
export async function DELETE() {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    await db.recentlyViewed.deleteMany({ where: { userId: user.id } });

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
