import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession } from '@/lib/user-auth';

// GET: لیست اعلان‌های کاربر
export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const onlyUnread = searchParams.get('unread') === 'true';
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: any = { userId: user.id };
    if (onlyUnread) where.isRead = false;

    const [notifications, unreadCount] = await Promise.all([
      db.userNotification.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: limit,
      }),
      db.userNotification.count({
        where: { userId: user.id, isRead: false },
      }),
    ]);

    return NextResponse.json({ notifications, unreadCount });
  } catch (error) {
    console.error('Fetch notifications error:', error);
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// PATCH: علامت‌گذاری اعلان به‌عنوان خوانده شده
export async function PATCH(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const body = await request.json();
    const { id, markAllRead } = body;

    if (markAllRead) {
      await db.userNotification.updateMany({
        where: { userId: user.id, isRead: false },
        data: { isRead: true, readAt: new Date() },
      });
      return NextResponse.json({ success: true });
    }

    if (id) {
      await db.userNotification.update({
        where: { id: parseInt(id), userId: user.id },
        data: { isRead: true, readAt: new Date() },
      });
      return NextResponse.json({ success: true });
    }

    return NextResponse.json({ error: 'id یا markAllRead الزامی است' }, { status: 400 });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// DELETE: حذف اعلان
export async function DELETE(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (id) {
      await db.userNotification.delete({
        where: { id: parseInt(id), userId: user.id },
      });
    } else {
      // حذف همه اعلان‌های خوانده شده
      await db.userNotification.deleteMany({
        where: { userId: user.id, isRead: true },
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
