import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession } from '@/lib/user-auth';
import { generateReferralCode } from '@/lib/wallet';

// GET: اطلاعات ارجاع کاربر
export async function GET() {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    // اگر کد ارجاع ندارد، یکی بساز
    let referralCode = user.referralCode;
    if (!referralCode) {
      referralCode = generateReferralCode(user.name || undefined);
      await db.user.update({
        where: { id: user.id },
        data: { referralCode },
      });
    }

    // کاربرانی که با کد این کاربر ثبت‌نام کرده‌اند
    const referrals = await db.user.findMany({
      where: { referredById: user.id },
      select: {
        id: true,
        name: true,
        createdAt: true,
        isVerified: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    // آمار
    const totalReferrals = referrals.length;
    const verifiedReferrals = referrals.filter(r => r.isVerified).length;

    return NextResponse.json({
      referralCode,
      referralLink: `${process.env.NEXT_PUBLIC_SITE_URL || ''}/auth?ref=${referralCode}`,
      referrals,
      stats: {
        total: totalReferrals,
        verified: verifiedReferrals,
      },
    });
  } catch (error) {
    console.error('Referral fetch error:', error);
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
