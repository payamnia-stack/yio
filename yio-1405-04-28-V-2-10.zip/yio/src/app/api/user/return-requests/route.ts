import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession } from '@/lib/user-auth';
import { createNotification } from '@/lib/notifications';

// GET: لیست درخواست‌های مرجوعی کاربر
export async function GET() {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const requests = await db.returnRequest.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      include: {
        order: {
          select: {
            id: true,
            orderNumber: true,
            finalAmount: true,
            createdAt: true,
          },
        },
      },
    });

    return NextResponse.json({ requests });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// POST: ثبت درخواست مرجوعی
export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const body = await request.json();
    const { orderId, orderItemId, reason, description, refundMethod } = body;

    if (!orderId || !reason) {
      return NextResponse.json({ error: 'orderId و reason الزامی است' }, { status: 400 });
    }

    // بررسی مالکیت سفارش
    const order = await db.order.findFirst({
      where: { id: parseInt(orderId), userId: user.id },
    });
    if (!order) {
      return NextResponse.json({ error: 'سفارش یافت نشد' }, { status: 404 });
    }

    // بررسی تکراری نبودن
    const existing = await db.returnRequest.findFirst({
      where: {
        orderId: parseInt(orderId),
        userId: user.id,
        status: { in: ['pending', 'approved'] },
      },
    });
    if (existing) {
      return NextResponse.json({ error: 'درخواست مرجوعی فعال برای این سفارش وجود دارد' }, { status: 400 });
    }

    const validReasons = ['defective', 'wrong_item', 'not_as_described', 'changed_mind', 'other'];
    if (!validReasons.includes(reason)) {
      return NextResponse.json({ error: 'دلیل نامعتبر' }, { status: 400 });
    }

    const returnRequest = await db.returnRequest.create({
      data: {
        userId: user.id,
        orderId: parseInt(orderId),
        orderItemId: orderItemId ? parseInt(orderItemId) : null,
        reason,
        description: description || null,
        refundMethod: refundMethod || 'wallet',
        status: 'pending',
      },
    });

    // ایجاد اعلان برای کاربر
    await createNotification({
      userId: user.id,
      type: 'return_request',
      title: 'درخواست مرجوعی ثبت شد',
      body: `درخواست مرجوعی برای سفارش ${order.orderNumber} ثبت شد. در حال بررسی است.`,
      link: '/profile?tab=returns',
      data: { requestId: returnRequest.id, orderId: order.id },
    });

    return NextResponse.json({ success: true, request: returnRequest });
  } catch (error) {
    console.error('Return request error:', error);
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
