import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession } from '@/lib/user-auth';

// GET: دریافت جزئیات یک سفارش خاص متعلق به کاربر وارد شده
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getUserFromSession();
    if (!user) {
      return NextResponse.json({ error: 'وارد شوید' }, { status: 401 });
    }

    const { id } = await params;
    const orderId = parseInt(id);

    if (isNaN(orderId)) {
      return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });
    }

    // فقط سفارشی که متعلق به این کاربر باشد (یا شماره تماس گیرنده همان کاربر باشد)
    const order = await db.order.findFirst({
      where: {
        AND: [
          { id: orderId },
          {
            OR: [
              { userId: user.id },
              { recipientPhone: user.phone },
            ],
          },
        ],
      },
      include: {
        items: true,
      },
    });

    if (!order) {
      return NextResponse.json({ error: 'سفارش یافت نشد' }, { status: 404 });
    }

    return NextResponse.json({ order });
  } catch (error) {
    console.error('User order detail error:', error);
    return NextResponse.json({ error: 'خطا در دریافت سفارش' }, { status: 500 });
  }
}
