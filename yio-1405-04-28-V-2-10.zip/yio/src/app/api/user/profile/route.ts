import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession, hashPassword, verifyPassword } from '@/lib/user-auth';
import { securityCheck, validateString, validateIranMobile } from '@/lib/security';
import { calculateUserLevel, getNextLevelHint, getLevelProgress, getUserLevel } from '@/lib/user-levels';

// GET: دریافت اطلاعات کامل پروفایل کاربر
export async function GET() {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'وارد شوید' }, { status: 401 });

    const [orders, wishlist, addresses, loyaltyPoints, reviews, wholesaleOrders] = await Promise.all([
      db.order.findMany({
        where: { userId: user.id },
        orderBy: { createdAt: 'desc' },
        take: 20,
        include: { items: true },
      }),
      db.wishlist.findMany({
        where: { userId: user.id },
        include: { product: true },
      }),
      db.address.findMany({ where: { userId: user.id } }),
      db.loyaltyPoint.groupBy({
        by: ['userId'],
        where: { userId: user.id },
        _sum: { points: true },
      }),
      db.review.count({ where: { userId: user.id } }),
      db.wholesaleOrder.count({ where: { phone: user.phone } }),
    ]);

    // محاسبه سطح کاربر
    const completedOrders = orders.filter(o => o.status === 'delivered');
    const totalSpent = completedOrders.reduce((sum, o) => sum + o.finalAmount, 0);

    // دریافت تنظیمات آستانه‌ها از دیتابیس
    let level4OrderThreshold = 10;
    let level4SpentThreshold = 5000000;
    try {
      const settings = await db.siteSetting.findMany({
        where: { key: { in: ['level4_order_threshold', 'level4_spent_threshold'] } },
      });
      const sMap: Record<string, string> = {};
      settings.forEach(s => sMap[s.key] = s.value);
      level4OrderThreshold = parseInt(sMap.level4_order_threshold) || 10;
      level4SpentThreshold = parseInt(sMap.level4_spent_threshold) || 5000000;
    } catch {}

    const hasShippingInfo = !!(user.name && user.province && user.city && user.address && user.postalCode);

    const calculatedLevel = calculateUserLevel({
      hasVerifiedContact: user.isVerified,
      hasShippingInfo,
      hasPurchase: completedOrders.length > 0,
      hasReview: reviews > 0,
      hasSatisfactionMedia: false, // TODO: وقتی مدیا بررسی شد
      orderCount: orders.length,
      totalSpent,
      isWholesale: user.isWholesale,
      installmentLimit: user.installmentLimit,
      companyName: user.companyName,
      level4OrderThreshold,
      level4SpentThreshold,
    });

    // آپدیت level در دیتابیس اگر تغییر کرده
    if (calculatedLevel !== user.level) {
      await db.user.update({
        where: { id: user.id },
        data: { level: calculatedLevel },
      });
    }

    const nextLevelHint = getNextLevelHint(calculatedLevel);
    const levelProgress = getLevelProgress({
      hasVerifiedContact: user.isVerified,
      hasShippingInfo,
      hasPurchase: completedOrders.length > 0,
      hasReview: reviews > 0,
      hasSatisfactionMedia: false,
      orderCount: orders.length,
      totalSpent,
      isWholesale: user.isWholesale,
      installmentLimit: user.installmentLimit,
      companyName: user.companyName,
      level4OrderThreshold,
      level4SpentThreshold,
    }, calculatedLevel);

    return NextResponse.json({
      user: {
        id: user.id,
        name: user.name,
        phone: user.phone,
        email: user.email,
        avatar: user.avatar,
        isVerified: user.isVerified,
        hasPassword: !!user.password,
        // اطلاعات سطح
        level: calculatedLevel,
        levelInfo: getUserLevel(calculatedLevel),
        nextLevelHint,
        levelProgress,
        // اطلاعات تکمیلی
        nationalCode: user.nationalCode,
        province: user.province,
        city: user.city,
        address: user.address,
        postalCode: user.postalCode,
        installmentLimit: user.installmentLimit,
        companyName: user.companyName,
        isWholesale: user.isWholesale,
        wholesaleDiscount: user.wholesaleDiscount,
      },
      orders,
      wishlist,
      addresses,
      loyaltyPoints: loyaltyPoints[0]?._sum.points || 0,
      stats: {
        totalOrders: orders.length,
        completedOrders: completedOrders.length,
        totalSpent,
        reviewsCount: reviews,
        wholesaleRequests: wholesaleOrders,
      },
    });
  } catch (error) {
    console.error('Profile fetch error:', error);
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// PUT: آپدیت اطلاعات پروفایل کاربر
// body: { name?, email?, phone?, password?, currentPassword?, nationalCode?, province?, city?, address?, postalCode?, companyName? }
export async function PUT(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const body = await request.json();
    const secCheck = securityCheck(body);
    if (!secCheck.safe) return NextResponse.json({ error: secCheck.reason }, { status: 400 });

    const updateData: any = {};

    // آپدیت نام
    if (body.name !== undefined) {
      const name = validateString(body.name, 2, 100);
      if (!name) {
        return NextResponse.json({ error: 'نام نامعتبر' }, { status: 400 });
      }
      updateData.name = name;
    }

    // آپدیت ایمیل
    if (body.email !== undefined) {
      const email = body.email ? String(body.email).toLowerCase().trim() : null;
      if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return NextResponse.json({ error: 'ایمیل نامعتبر' }, { status: 400 });
      }
      if (email) {
        // بررسی تکراری نبودن
        const existing = await db.user.findFirst({
          where: { email, NOT: { id: user.id } },
        });
        if (existing) {
          return NextResponse.json({ error: 'این ایمیل قبلا ثبت شده' }, { status: 400 });
        }
      }
      updateData.email = email;
    }

    // آپدیت شماره موبایل
    if (body.phone !== undefined && body.phone !== null) {
      const phone = validateString(body.phone, 11, 11);
      if (!phone || !validateIranMobile(phone)) {
        return NextResponse.json({ error: 'شماره موبایل نامعتبر' }, { status: 400 });
      }
      // بررسی تکراری نبودن
      const existing = await db.user.findFirst({
        where: { phone, NOT: { id: user.id } },
      });
      if (existing) {
        return NextResponse.json({ error: 'این شماره موبایل قبلا ثبت شده' }, { status: 400 });
      }
      updateData.phone = phone;
    }

    // آپدیت رمز عبور
    if (body.password !== undefined && body.password) {
      if (body.password.length < 6) {
        return NextResponse.json({ error: 'رمز عبور باید حداقل ۶ کاراکتر باشد' }, { status: 400 });
      }

      // اگر رمز قبلی دارد، باید currentPassword ارسال شود
      if (user.password) {
        if (!body.currentPassword) {
          return NextResponse.json({ error: 'رمز عبور فعلی را وارد کنید' }, { status: 400 });
        }
        if (!verifyPassword(body.currentPassword, user.password)) {
          return NextResponse.json({ error: 'رمز عبور فعلی اشتباه است' }, { status: 400 });
        }
      }

      updateData.password = hashPassword(body.password);
    }

    // آپدیت اطلاعات تکمیلی (آدرس، کد ملی، ...)
    if (body.nationalCode !== undefined) {
      updateData.nationalCode = body.nationalCode ? String(body.nationalCode).slice(0, 10) : null;
    }
    if (body.province !== undefined) {
      updateData.province = body.province ? String(body.province).slice(0, 50) : null;
    }
    if (body.city !== undefined) {
      updateData.city = body.city ? String(body.city).slice(0, 50) : null;
    }
    if (body.address !== undefined) {
      updateData.address = body.address ? String(body.address).slice(0, 500) : null;
    }
    if (body.postalCode !== undefined) {
      updateData.postalCode = body.postalCode ? String(body.postalCode).slice(0, 20) : null;
    }
    if (body.companyName !== undefined) {
      updateData.companyName = body.companyName ? String(body.companyName).slice(0, 200) : null;
    }

    const updatedUser = await db.user.update({
      where: { id: user.id },
      data: updateData,
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        avatar: true,
        isVerified: true,
        level: true,
        nationalCode: true,
        province: true,
        city: true,
        address: true,
        postalCode: true,
        companyName: true,
        isWholesale: true,
        wholesaleDiscount: true,
        installmentLimit: true,
      },
    });

    return NextResponse.json({ success: true, user: updatedUser });
  } catch (error: any) {
    console.error('Profile update error:', error);
    return NextResponse.json({ error: 'خطا در بروزرسانی' }, { status: 500 });
  }
}
