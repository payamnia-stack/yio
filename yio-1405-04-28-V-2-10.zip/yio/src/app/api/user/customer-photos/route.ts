import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession } from '@/lib/user-auth';
import { promises as fs } from 'fs';
import path from 'path';

const UPLOAD_DIR = path.join(process.cwd(), 'public', 'uploads', 'customer-photos');
const ALLOWED_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
const MAX_SIZE = 5 * 1024 * 1024; // 5MB

// GET: لیست عکس‌های کاربر
export async function GET() {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const photos = await db.customerPhoto.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      include: {
        product: {
          select: { id: true, title: true, image: true },
        },
      },
    });

    return NextResponse.json({ photos });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// POST: آپلود عکس جدید از محصول خریداری شده
export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const formData = await request.formData();
    const file = formData.get('photo') as File | null;
    const productId = formData.get('productId') as string;
    const orderId = formData.get('orderId') as string;
    const caption = formData.get('caption') as string;

    if (!file || !productId) {
      return NextResponse.json({ error: 'عکس و productId الزامی است' }, { status: 400 });
    }

    if (file.size > MAX_SIZE) {
      return NextResponse.json({ error: 'حداکثر حجم ۵ مگابایت' }, { status: 400 });
    }

    const ext = path.extname(file.name).toLowerCase();
    if (!ALLOWED_EXTENSIONS.includes(ext)) {
      return NextResponse.json({ error: 'پسوند مجاز نیست (JPG, PNG, GIF, WebP)' }, { status: 400 });
    }

    // بررسی مالکیت محصول (آیا کاربر این محصول را خریده است؟)
    if (orderId) {
      const order = await db.order.findFirst({
        where: {
          id: parseInt(orderId),
          userId: user.id,
          items: { some: { productId: parseInt(productId) } },
        },
      });
      if (!order) {
        return NextResponse.json({ error: 'برای آپلود عکس، باید این محصول را خریده باشید' }, { status: 403 });
      }
    }

    await fs.mkdir(UPLOAD_DIR, { recursive: true });
    const uniqueName = `user-${user.id}-prod-${productId}-${Date.now()}${ext}`;
    const fullPath = path.join(UPLOAD_DIR, uniqueName);
    const buffer = Buffer.from(await file.arrayBuffer());
    await fs.writeFile(fullPath, buffer);

    const url = `/uploads/customer-photos/${uniqueName}`;

    const photo = await db.customerPhoto.create({
      data: {
        userId: user.id,
        productId: parseInt(productId),
        orderId: orderId ? parseInt(orderId) : null,
        imageUrl: url,
        caption: caption || null,
        isApproved: false, // نیاز به تأیید مدیر
      },
    });

    return NextResponse.json({ success: true, photo });
  } catch (error: any) {
    console.error('Photo upload error:', error);
    return NextResponse.json({ error: 'خطا در آپلود' }, { status: 500 });
  }
}

// DELETE: حذف عکس
export async function DELETE(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) return NextResponse.json({ error: 'id الزامی است' }, { status: 400 });

    const photo = await db.customerPhoto.findUnique({ where: { id: parseInt(id) } });
    if (!photo || photo.userId !== user.id) {
      return NextResponse.json({ error: 'عکس یافت نشد' }, { status: 404 });
    }

    // حذف فایل فیزیکی
    try {
      const filePath = path.join(process.cwd(), 'public', photo.imageUrl);
      await fs.unlink(filePath);
    } catch {}

    await db.customerPhoto.delete({ where: { id: parseInt(id) } });

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
