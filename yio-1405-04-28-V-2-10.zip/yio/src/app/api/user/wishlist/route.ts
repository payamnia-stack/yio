import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession } from '@/lib/user-auth';

// GET: لیست علاقه‌مندی‌های کاربر وارد شده
export async function GET() {
  try {
    const user = await getUserFromSession();
    if (!user) {
      return NextResponse.json({ error: 'غیرمجاز. لطفاً وارد شوید.' }, { status: 401 });
    }

    const wishlist = await db.wishlist.findMany({
      where: { userId: user.id },
      include: {
        product: true,
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      wishlist,
      productIds: wishlist.map((w) => w.productId),
    });
  } catch (error) {
    console.error('Wishlist GET error:', error);
    return NextResponse.json({ error: 'خطا در دریافت علاقه‌مندی‌ها' }, { status: 500 });
  }
}

// POST: افزودن محصول به علاقه‌مندی‌ها
export async function POST(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) {
      return NextResponse.json({ error: 'غیرمجاز. لطفاً وارد شویدید.' }, { status: 401 });
    }

    const body = await request.json();
    const productId = parseInt(body.productId);

    if (isNaN(productId) || productId < 1) {
      return NextResponse.json({ error: 'شناسه محصول نامعتبر است' }, { status: 400 });
    }

    // بررسی وجود محصول
    const product = await db.product.findUnique({ where: { id: productId } });
    if (!product) {
      return NextResponse.json({ error: 'محصول یافت نشد' }, { status: 404 });
    }

    // بررسی تکراری نبودن (Unique constraint روی [userId, productId])
    const existing = await db.wishlist.findUnique({
      where: { userId_productId: { userId: user.id, productId } },
    });

    if (existing) {
      return NextResponse.json({ success: true, message: 'قبلاً اضافه شده', wishlist: existing });
    }

    const wishlist = await db.wishlist.create({
      data: { userId: user.id, productId },
    });

    return NextResponse.json({ success: true, wishlist });
  } catch (error) {
    console.error('Wishlist POST error:', error);
    return NextResponse.json({ error: 'خطا در افزودن به علاقه‌مندی‌ها' }, { status: 500 });
  }
}

// DELETE: حذف محصول از علاقه‌مندی‌ها
export async function DELETE(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) {
      return NextResponse.json({ error: 'غیرمجاز. لطفاً وارد شویدید.' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const productId = parseInt(searchParams.get('productId') || '0');

    if (isNaN(productId) || productId < 1) {
      return NextResponse.json({ error: 'شناسه محصول نامعتبر است' }, { status: 400 });
    }

    // حذف (اگر وجود نداشت، Prisma خطا می‌دهد — با try/catch مدیریت می‌کنیم)
    try {
      await db.wishlist.delete({
        where: { userId_productId: { userId: user.id, productId } },
      });
    } catch (e: any) {
      // اگر رکورد وجود نداشت، موفقیت‌آمیز فرض می‌کنیم
      if (e?.code !== 'P2025') throw e;
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Wishlist DELETE error:', error);
    return NextResponse.json({ error: 'خطا در حذف از علاقه‌مندی‌ها' }, { status: 500 });
  }
}
