import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession } from '@/lib/user-auth';
import { cookies } from 'next/headers';

// DELETE: حذف حساب کاربری (Soft Delete - GDPR Compliance)
export async function DELETE() {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    // Soft delete: تنظیم deletedAt به جای حذف واقعی
    // (برای حفظ تاریخچه سفارش‌ها و مالی)
    await db.user.update({
      where: { id: user.id },
      data: {
        deletedAt: new Date(),
        // پاک کردن اطلاعات حساس
        phone: `deleted_${user.id}_${user.phone}`,
        email: null,
        password: null,
        name: null,
        nationalCode: null,
        address: null,
        verifyCode: null,
        // غیرفعال کردن
        isVerified: false,
      },
    });

    // حذف همه نشست‌ها (خروج از همه دستگاه‌ها)
    await db.session.deleteMany({ where: { userId: user.id } });

    // پاک کردن کوکی
    const cookieStore = await cookies();
    cookieStore.delete('yio-user-token');

    return NextResponse.json({
      success: true,
      message: 'حساب شما حذف شد. داده‌های سفارش‌ها برای گزارش‌گیری حفظ شده‌اند.',
    });
  } catch (error) {
    console.error('Delete account error:', error);
    return NextResponse.json({ error: 'خطا در حذف حساب' }, { status: 500 });
  }
}
