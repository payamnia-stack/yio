import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession } from '@/lib/user-auth';
import { getOrCreateWallet } from '@/lib/wallet';

// GET: اطلاعات کیف پول + تراکنش‌ها
export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const wallet = await getOrCreateWallet(user.id);

    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const type = searchParams.get('type');

    const where: any = { userId: user.id };
    if (type) where.type = type;

    const transactions = await db.walletTransaction.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
    });

    // آمار
    const totalCredited = await db.walletTransaction.aggregate({
      where: { userId: user.id, amount: { gt: 0 } },
      _sum: { amount: true },
    });
    const totalDebited = await db.walletTransaction.aggregate({
      where: { userId: user.id, amount: { lt: 0 } },
      _sum: { amount: true },
    });

    return NextResponse.json({
      wallet: {
        id: wallet.id,
        balance: wallet.balance,
      },
      transactions,
      stats: {
        totalCredited: totalCredited._sum.amount || 0,
        totalDebited: Math.abs(totalDebited._sum.amount || 0),
      },
    });
  } catch (error) {
    console.error('Wallet fetch error:', error);
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
