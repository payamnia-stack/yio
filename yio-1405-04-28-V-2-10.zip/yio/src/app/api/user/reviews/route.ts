import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession } from '@/lib/user-auth';

// GET: لیست نظرات کاربر
export async function GET() {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const reviews = await db.review.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      include: {
        product: {
          select: {
            id: true,
            title: true,
            image: true,
          },
        },
      },
    });

    return NextResponse.json({ reviews });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// PATCH: ویرایش نظر
export async function PATCH(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const body = await request.json();
    const { id, rating, comment } = body;

    if (!id) return NextResponse.json({ error: 'id الزامی است' }, { status: 400 });

    const updateData: any = {};
    if (rating !== undefined) {
      const r = parseInt(rating);
      if (r < 1 || r > 5) return NextResponse.json({ error: 'امتیاز باید ۱ تا ۵ باشد' }, { status: 400 });
      updateData.rating = r;
    }
    if (comment !== undefined) {
      updateData.comment = String(comment).slice(0, 500);
    }

    // بررسی مالکیت
    const existing = await db.review.findUnique({ where: { id: parseInt(id) } });
    if (!existing || existing.userId !== user.id) {
      return NextResponse.json({ error: 'نظر یافت نشد' }, { status: 404 });
    }

    const review = await db.review.update({
      where: { id: parseInt(id) },
      data: updateData,
    });

    return NextResponse.json({ success: true, review });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// DELETE: حذف نظر
export async function DELETE(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) return NextResponse.json({ error: 'id الزامی است' }, { status: 400 });

    // بررسی مالکیت
    const existing = await db.review.findUnique({ where: { id: parseInt(id) } });
    if (!existing || existing.userId !== user.id) {
      return NextResponse.json({ error: 'نظر یافت نشد' }, { status: 404 });
    }

    await db.review.delete({ where: { id: parseInt(id) } });

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
