import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession } from '@/lib/user-auth';

// GET: لیست نشست‌های فعال کاربر
export async function GET(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    // دریافت توکن فعلی برای تشخیص نشست جاری
    const cookieStore = await import('next/headers').then(m => m.cookies());
    const currentToken = cookieStore.get('yio-user-token')?.value;

    const sessions = await db.session.findMany({
      where: {
        userId: user.id,
        expiresAt: { gt: new Date() },
      },
      orderBy: { lastActivity: 'desc' },
      select: {
        id: true,
        token: true,
        userAgent: true,
        ipAddress: true,
        deviceType: true,
        location: true,
        createdAt: true,
        lastActivity: true,
        expiresAt: true,
      },
    });

    // علامت‌گذاری نشست فعلی
    const sessionsWithCurrent = sessions.map(s => ({
      ...s,
      isCurrent: s.token === currentToken,
      // مخفی کردن توکن برای امنیت
      token: undefined,
    }));

    return NextResponse.json({
      sessions: sessionsWithCurrent,
      count: sessions.length,
    });
  } catch (error) {
    console.error('Sessions fetch error:', error);
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// DELETE: خروج از یک نشست خاص (یا همه نشست‌ها)
export async function DELETE(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const sessionId = searchParams.get('id');
    const all = searchParams.get('all') === 'true';

    const cookieStore = await import('next/headers').then(m => m.cookies());
    const currentToken = cookieStore.get('yio-user-token')?.value;

    if (all) {
      // خروج از همه نشست‌ها به جز نشست فعلی
      await db.session.deleteMany({
        where: {
          userId: user.id,
          NOT: { token: currentToken },
        },
      });
      return NextResponse.json({ success: true, message: 'از همه نشست‌های دیگر خارج شدید' });
    }

    if (sessionId) {
      const session = await db.session.findUnique({ where: { id: parseInt(sessionId) } });
      if (!session || session.userId !== user.id) {
        return NextResponse.json({ error: 'نشست یافت نشد' }, { status: 404 });
      }
      if (session.token === currentToken) {
        return NextResponse.json({ error: 'نمی‌توانید از نشست فعلی خارج شوید. از دکمه خروج استفاده کنید.' }, { status: 400 });
      }
      await db.session.delete({ where: { id: parseInt(sessionId) } });
      return NextResponse.json({ success: true });
    }

    return NextResponse.json({ error: 'id یا all الزامی است' }, { status: 400 });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
