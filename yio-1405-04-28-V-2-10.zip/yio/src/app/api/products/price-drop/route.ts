import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession } from '@/lib/user-auth';
import { enforceRateLimit, securityCheck } from '@/lib/security';

// POST: ثبت هشدار کاهش قیمت محصول
export async function POST(request: NextRequest) {
  try {
    const rateLimit = await enforceRateLimit(request, 'price-drop', 10);
    if (!rateLimit.allowed) return rateLimit.response!;

    const body = await request.json();
    const secCheck = securityCheck(body);
    if (!secCheck.safe) return NextResponse.json({ error: secCheck.reason }, { status: 400 });

    const { productId, targetPrice } = body;
    if (!productId) return NextResponse.json({ error: 'productId الزامی است' }, { status: 400 });

    const pid = parseInt(productId);
    const tp = parseInt(targetPrice);
    if (isNaN(pid) || isNaN(tp) || tp <= 0) {
      return NextResponse.json({ error: 'مقادیر نامعتبر' }, { status: 400 });
    }

    const product = await db.product.findUnique({ where: { id: pid } });
    if (!product) return NextResponse.json({ error: 'محصول یافت نشد' }, { status: 404 });

    const user = await getUserFromSession();

    // بررسی تکراری نبودن
    const existingWhere: any = { productId: pid, notified: false };
    if (user) {
      existingWhere.userId = user.id;
    } else if (body.phone) {
      existingWhere.phone = body.phone;
    } else if (body.email) {
      existingWhere.email = body.email;
    } else {
      return NextResponse.json({ error: 'برای ثبت هشدار باید وارد شوید یا شماره/ایمیل وارد کنید' }, { status: 400 });
    }

    const existing = await db.priceDropAlert.findFirst({ where: existingWhere });
    if (existing) {
      return NextResponse.json({ success: true, message: 'شما قبلا ثبت کرده‌اید' });
    }

    await db.priceDropAlert.create({
      data: {
        userId: user?.id || null,
        productId: pid,
        phone: body.phone || null,
        email: body.email || null,
        targetPrice: tp,
      },
    });

    return NextResponse.json({
      success: true,
      message: `هنگامی که قیمت به ${tp.toLocaleString('fa-IR')} تومان برسد، به شما اطلاع می‌دهیم`,
    });
  } catch (error) {
    console.error('Price drop alert error:', error);
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// GET: لیست هشدارهای قیمت کاربر
export async function GET() {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const alerts = await db.priceDropAlert.findMany({
      where: { userId: user.id },
      include: {
        product: {
          select: {
            id: true,
            title: true,
            image: true,
            price: true,
            discountPrice: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ alerts });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// DELETE: حذف هشدار قیمت
export async function DELETE(request: NextRequest) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (id) {
      await db.priceDropAlert.delete({
        where: { id: parseInt(id), userId: user.id },
      });
    } else {
      await db.priceDropAlert.deleteMany({ where: { userId: user.id } });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
