import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken, cleanupExpiredSessions } from '@/lib/admin-auth';

// دریافت لیست محصولات با فیلتر، جستجو، صفحه‌بندی
export async function GET(request: NextRequest) {
  try {
    // بررسی احراز هویت
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);

    if (!isAuth) {
      return NextResponse.json(
        { error: 'غیرمجاز. لطفاً وارد شوید.' },
        { status: 401 }
      );
    }

    // پاکسازی سشن‌های منقضی شده
    await cleanupExpiredSessions();

    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';
    const category = searchParams.get('category') || '';
    const inStock = searchParams.get('inStock');
    const isSpecial = searchParams.get('isSpecial');
    const sort = searchParams.get('sort') || 'newest';
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '10');

    // ساخت شرط WHERE
    const where: any = {};

    if (search) {
      where.OR = [
        { title: { contains: search } },
        { brand: { contains: search } },
        { woodType: { contains: search } },
        { description: { contains: search } },
      ];
    }

    if (category) {
      where.category = category;
    }

    if (inStock === 'true') where.inStock = true;
    if (inStock === 'false') where.inStock = false;
    if (isSpecial === 'true') where.isSpecial = true;
    if (isSpecial === 'false') where.isSpecial = false;

    // تعیین ترتیب
    let orderBy: any = { createdAt: 'desc' };
    if (sort === 'oldest') orderBy = { createdAt: 'asc' };
    else if (sort === 'priceAsc') orderBy = { price: 'asc' };
    else if (sort === 'priceDesc') orderBy = { price: 'desc' };
    else if (sort === 'rating') orderBy = { rating: 'desc' };
    else if (sort === 'title') orderBy = { title: 'asc' };

    // گرفتن تعداد کل
    const total = await db.product.count({ where });

    // گرفتن محصولات صفحه فعلی
    const products = await db.product.findMany({
      where,
      orderBy,
      skip: (page - 1) * pageSize,
      take: pageSize,
    });

    // آمار کلی برای داشبورد
    const stats = {
      total: await db.product.count(),
      inStock: await db.product.count({ where: { inStock: true } }),
      outOfStock: await db.product.count({ where: { inStock: false } }),
      special: await db.product.count({ where: { isSpecial: true } }),
      totalValue: await db.product.aggregate({ _sum: { price: true } }),
    };

    return NextResponse.json({
      products,
      pagination: {
        page,
        pageSize,
        total,
        totalPages: Math.ceil(total / pageSize),
      },
      stats,
    });
  } catch (error) {
    console.error('Error fetching products:', error);
    return NextResponse.json(
      { error: 'خطا در دریافت محصولات' },
      { status: 500 }
    );
  }
}

// ایجاد محصول جدید
export async function POST(request: NextRequest) {
  try {
    // بررسی احراز هویت
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);

    if (!isAuth) {
      return NextResponse.json(
        { error: 'غیرمجاز. لطفاً وارد شوید.' },
        { status: 401 }
      );
    }

    const body = await request.json();

    // اعتبارسنجی فیلدها
    if (!body.title || typeof body.title !== 'string' || body.title.trim().length < 3) {
      return NextResponse.json(
        { error: 'عنوان محصول باید حداقل ۳ کاراکتر باشد' },
        { status: 400 }
      );
    }

    if (!body.category || typeof body.category !== 'string') {
      return NextResponse.json(
        { error: 'دسته‌بندی الزامی است' },
        { status: 400 }
      );
    }

    if (!body.price || typeof body.price !== 'number' || body.price < 1000) {
      return NextResponse.json(
        { error: 'قیمت باید عددی بزرگتر از ۱۰۰۰ تومان باشد' },
        { status: 400 }
      );
    }

    if (!body.image || typeof body.image !== 'string' || !body.image.startsWith('http')) {
      return NextResponse.json(
        { error: 'آدرس تصویر معتبر نیست' },
        { status: 400 }
      );
    }

    // محاسبه درصد تخفیف اگر قیمت تخفیف داده شده
    let discountPercent = body.discountPercent;
    if (body.discountPrice && body.discountPrice < body.price && !discountPercent) {
      discountPercent = Math.round(((body.price - body.discountPrice) / body.price) * 100);
    }

    // پاکسازی ورودی‌ها برای جلوگیری از XSS
    const sanitize = (str: string) => str.replace(/<script[^>]*>.*?<\/script>/gi, '').replace(/<[^>]+>/g, '').trim();

    // اعتبارسنجی تصاویر و ویدیوهای اضافی
    const MAX_IMAGES = 10;
    const MAX_VIDEOS = 3;

    let imagesList: string[] = [];
    if (Array.isArray(body.images)) {
      imagesList = body.images
        .filter((img: any) => typeof img === 'string' && img.startsWith('http'))
        .slice(0, MAX_IMAGES);
    }

    let videosList: string[] = [];
    if (Array.isArray(body.videos)) {
      videosList = body.videos
        .filter((v: any) => typeof v === 'string' && v.startsWith('http'))
        .slice(0, MAX_VIDEOS);
    }

    // محاسبه خودکار inStock از روی stockQuantity
    // (این فیلد دیگر از کلاینت گرفته نمی‌شود — تعداد موجودی منبع حقیقی است)
    const stockQuantity = Math.max(0, parseInt(body.stockQuantity) || 0);

    const product = await db.product.create({
      data: {
        title: sanitize(body.title),
        brand: sanitize(body.brand || 'YIO'),
        category: sanitize(body.category),
        price: Math.floor(body.price),
        discountPrice: body.discountPrice ? Math.floor(body.discountPrice) : null,
        discountPercent: discountPercent || null,
        image: body.image.trim(),
        images: imagesList.length > 0 ? JSON.stringify(imagesList) : null,
        videos: videosList.length > 0 ? JSON.stringify(videosList) : null,
        rating: body.rating || 0,
        ratingCount: body.ratingCount || 0,
        inStock: stockQuantity > 0,
        fastDelivery: Boolean(body.fastDelivery ?? true),
        isSpecial: Boolean(body.isSpecial ?? false),
        isPublished: Boolean(body.isPublished ?? true),
        stockQuantity,
        description: body.description ? sanitize(body.description) : null,
        woodType: body.woodType ? sanitize(body.woodType) : null,
        colors: body.colors ? JSON.stringify(body.colors) : null,
      },
    });

    return NextResponse.json({ product, success: true });
  } catch (error) {
    console.error('Error creating product:', error);
    return NextResponse.json(
      { error: 'خطا در ایجاد محصول' },
      { status: 500 }
    );
  }
}
