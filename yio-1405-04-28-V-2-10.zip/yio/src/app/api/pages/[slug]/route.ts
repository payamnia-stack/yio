import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET: دریافت یک صفحه با slug (عمومی)
export async function GET(
  request: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;

    const page = await db.page.findUnique({
      where: { slug },
      include: {
        blocks: {
          where: { isActive: true },
          orderBy: { order: 'asc' },
        },
      },
    });

    if (!page || !page.isPublished) {
      return NextResponse.json({ error: 'صفحه یافت نشد' }, { status: 404 });
    }

    return NextResponse.json({ page });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
