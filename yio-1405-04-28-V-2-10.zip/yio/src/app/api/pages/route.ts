import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET: لیست صفحات منتشر شده (عمومی)
export async function GET() {
  try {
    const pages = await db.page.findMany({
      where: { isPublished: true, showInMenu: true },
      select: {
        id: true, slug: true, title: true, menuLabel: true, type: true, order: true,
      },
      orderBy: { order: 'asc' },
    });

    return NextResponse.json({ pages });
  } catch (error) {
    return NextResponse.json({ pages: [] }, { status: 500 });
  }
}
