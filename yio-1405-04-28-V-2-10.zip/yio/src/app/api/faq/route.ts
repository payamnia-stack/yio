import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET: لیست سؤالات متداول فعال (عمومی)
export async function GET() {
  try {
    const faqs = await db.fAQ.findMany({
      where: { isActive: true },
      orderBy: [{ order: 'asc' }, { createdAt: 'desc' }],
    });

    // گروه‌بندی بر اساس دسته
    const grouped: Record<string, any[]> = {};
    faqs.forEach(faq => {
      if (!grouped[faq.category]) grouped[faq.category] = [];
      grouped[faq.category].push(faq);
    });

    return NextResponse.json({ faqs, grouped });
  } catch (error) {
    console.error('Error fetching FAQs:', error);
    return NextResponse.json({ error: 'خطا در دریافت سؤالات' }, { status: 500 });
  }
}
