import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET: دسته‌بندی‌های فعال (عمومی - برای نمایش در سایت)
export async function GET() {
  try {
    const categories = await db.category.findMany({
      where: { isActive: true },
      orderBy: [{ order: 'asc' }, { title: 'asc' }],
    });

    // اگر هیچ دسته‌ای در دیتابیس نبود، از داده‌های پیش‌فرض استفاده کن
    if (categories.length === 0) {
      return NextResponse.json({
        categories: [
          { id: 1, title: 'اسباب‌بازی چوبی', icon: '🧸', color: '#f59e0b' },
          { id: 2, title: 'ظروف آشپزخانه', icon: '🍽️', color: '#84cc16' },
          { id: 3, title: 'مبلمان چوبی', icon: '🪑', color: '#8b5cf6' },
          { id: 4, title: 'دکوراسیون چوبی', icon: '🖼️', color: '#dc2626' },
          { id: 5, title: 'لوازم کودک', icon: '👶', color: '#06b6d4' },
          { id: 6, title: 'هدیه و صنایع دستی', icon: '🎁', color: '#ec4899' },
        ].map((c, i) => ({ ...c, slug: c.title, description: null, order: i, isActive: true })),
      });
    }

    return NextResponse.json({ categories });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
