import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { enforceRateLimit, securityCheck, validateIranMobile, validateString, sanitizeInput } from '@/lib/security';

// POST: ثبت درخواست سفارش عمده (عمومی)
export async function POST(request: NextRequest) {
  try {
    const rateLimit = await enforceRateLimit(request, 'wholesale', 5);
    if (!rateLimit.allowed) return rateLimit.response!;

    const body = await request.json();

    const secCheck = securityCheck(body);
    if (!secCheck.safe) {
      return NextResponse.json({ error: secCheck.reason }, { status: 400 });
    }

    const companyName = validateString(body.companyName, 2, 100);
    const contactPerson = validateString(body.contactPerson, 3, 100);
    const phone = validateString(body.phone, 11, 11);
    const city = validateString(body.city, 2, 50);
    const productCategory = validateString(body.productCategory, 2, 50);

    if (!companyName || !contactPerson || !phone || !city || !productCategory) {
      return NextResponse.json({ error: 'تمام فیلدهای ضروری را پر کنید' }, { status: 400 });
    }

    if (!validateIranMobile(phone)) {
      return NextResponse.json({ error: 'شماره موبایل نامعتبر است' }, { status: 400 });
    }

    const quantity = parseInt(body.quantity);
    if (isNaN(quantity) || quantity < 10) {
      return NextResponse.json({ error: 'حداقل تعداد برای سفارش عمده ۱۰ عدد است' }, { status: 400 });
    }

    const wholesale = await db.wholesaleOrder.create({
      data: {
        companyName: sanitizeInput(companyName),
        contactPerson: sanitizeInput(contactPerson),
        phone,
        email: body.email ? sanitizeInput(body.email).slice(0, 254) : null,
        city: sanitizeInput(city),
        productCategory: sanitizeInput(productCategory),
        quantity,
        description: body.description ? sanitizeInput(body.description).slice(0, 1000) : null,
      },
    });

    return NextResponse.json({ success: true, id: wholesale.id });
  } catch (error) {
    console.error('Error creating wholesale order:', error);
    return NextResponse.json({ error: 'خطا در ثبت درخواست' }, { status: 500 });
  }
}
