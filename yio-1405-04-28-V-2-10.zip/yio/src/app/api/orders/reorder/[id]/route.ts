import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession } from '@/lib/user-auth';
import { useShopStore } from '@/store/shop-store';

// POST: سفارش مجدد - اضافه کردن آیتم‌های یک سفارش قبلی به سبد خرید
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const orderId = parseInt(id);
    if (isNaN(orderId)) {
      return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });
    }

    // بررسی مالکیت سفارش
    const order = await db.order.findFirst({
      where: { id: orderId, userId: user.id },
      include: {
        items: {
          include: {
            product: {
              select: {
                id: true,
                title: true,
                brand: true,
                price: true,
                discountPrice: true,
                image: true,
                inStock: true,
                stockQuantity: true,
              },
            },
          },
        },
      },
    });

    if (!order) {
      return NextResponse.json({ error: 'سفارش یافت نشد' }, { status: 404 });
    }

    // فیلتر کردن آیتم‌هایی که هنوز موجود هستند
    const availableItems = order.items.filter(item => item.product && item.product.stockQuantity > 0);
    const unavailableItems = order.items.filter(item => !item.product || item.product.stockQuantity === 0);

    // آماده‌سازی آیتم‌ها برای response (کاربر در frontend به store اضافه می‌کند)
    const itemsToAdd = availableItems.map(item => ({
      id: item.product.id,
      title: item.product.title,
      brand: item.product.brand,
      price: item.product.discountPrice || item.product.price,
      image: item.product.image,
      quantity: item.quantity,
      selectedColor: item.color || undefined,
    }));

    return NextResponse.json({
      success: true,
      items: itemsToAdd,
      unavailableItems: unavailableItems.map(i => ({
        title: i.productTitle,
        reason: 'ناموجود',
      })),
      addedCount: itemsToAdd.length,
    });
  } catch (error) {
    console.error('Reorder error:', error);
    return NextResponse.json({ error: 'خطا در سفارش مجدد' }, { status: 500 });
  }
}
