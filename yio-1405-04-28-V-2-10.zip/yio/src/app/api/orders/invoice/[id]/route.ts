import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession } from '@/lib/user-auth';
import { formatPrice, toFa } from '@/lib/shop-data';

// GET: دانلود فاکتور PDF سفارش (HTML قابل چاپ)
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const orderId = parseInt(id);
    if (isNaN(orderId)) {
      return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });
    }

    const order = await db.order.findFirst({
      where: { id: orderId, userId: user.id },
      include: { items: true, customer: true },
    });

    if (!order) {
      return NextResponse.json({ error: 'سفارش یافت نشد' }, { status: 404 });
    }

    const settings = await db.siteSetting.findMany({
      where: { key: { in: ['site_title', 'contact_phone', 'contact_address'] } },
    });
    const sMap: Record<string, string> = {};
    settings.forEach(s => sMap[s.key] = s.value);

    const html = generateInvoiceHTML(order, sMap);

    return new NextResponse(html, {
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Content-Disposition': `inline; filename="invoice-${order.orderNumber}.html"`,
      },
    });
  } catch (error) {
    console.error('Invoice error:', error);
    return NextResponse.json({ error: 'خطا در تولید فاکتور' }, { status: 500 });
  }
}

function generateInvoiceHTML(order: any, settings: Record<string, string>): string {
  const siteName = settings.site_title || 'YIO';
  const phone = settings.contact_phone || '';
  const address = settings.contact_address || '';

  const itemsHTML = order.items.map((item: any, idx: number) => `
    <tr>
      <td style="padding: 8px; border: 1px solid #ddd; text-align: center;">${toFa(idx + 1)}</td>
      <td style="padding: 8px; border: 1px solid #ddd;">${item.productTitle}</td>
      <td style="padding: 8px; border: 1px solid #ddd; text-align: center;" class="fa-num">${toFa(item.quantity)}</td>
      <td style="padding: 8px; border: 1px solid #ddd; text-align: left;" class="fa-num">${formatPrice(item.price)} ت</td>
      <td style="padding: 8px; border: 1px solid #ddd; text-align: left;" class="fa-num">${formatPrice(item.price * item.quantity)} ت</td>
    </tr>
  `).join('');

  return `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>فاکتور ${order.orderNumber}</title>
  <style>
    body { font-family: 'Tahoma', 'Vazirmatn', sans-serif; padding: 20px; color: #333; max-width: 800px; margin: 0 auto; }
    .invoice-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; border-bottom: 3px solid #dc2626; padding-bottom: 15px; }
    .invoice-header h1 { color: #dc2626; margin: 0; font-size: 24px; }
    .invoice-info { display: flex; justify-content: space-between; margin-bottom: 20px; }
    .invoice-info div { font-size: 13px; line-height: 1.8; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 13px; }
    th { background: #dc2626; color: white; padding: 10px; border: 1px solid #dc2626; }
    .totals { width: 300px; margin-right: auto; margin-bottom: 30px; }
    .totals td { padding: 8px; border: 1px solid #ddd; font-size: 13px; }
    .totals .total-row { background: #fef2f2; font-weight: bold; color: #dc2626; }
    .footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 11px; color: #666; text-align: center; }
    .no-print { text-align: center; margin-bottom: 20px; }
    .print-btn { background: #dc2626; color: white; border: none; padding: 10px 30px; border-radius: 5px; cursor: pointer; font-size: 14px; }
    @media print { .no-print { display: none; } body { padding: 0; max-width: none; } }
  </style>
</head>
<body>
  <div class="no-print">
    <button class="print-btn" onclick="window.print()">🖨 چاپ / ذخیره PDF</button>
  </div>
  <div class="invoice-header">
    <div>
      <h1>${siteName}</h1>
      <div style="font-size: 12px; color: #666;">محصولات چوبی دست‌ساز</div>
    </div>
    <div style="text-align: left;">
      <div style="font-size: 14px; color: #666;"><strong>شماره فاکتور:</strong> ${order.orderNumber}</div>
      <div style="font-size: 14px; color: #666;"><strong>تاریخ:</strong> ${new Date(order.createdAt).toLocaleDateString('fa-IR')}</div>
    </div>
  </div>
  <div class="invoice-info">
    <div>
      <strong style="color: #dc2626;">مشتری:</strong><br>
      ${order.recipientName}<br>
      تلفن: <span dir="ltr">${order.recipientPhone}</span><br>
      ${order.shippingCity ? 'شهر: ' + order.shippingCity + '<br>' : ''}
      ${order.shippingAddress ? 'آدرس: ' + order.shippingAddress : ''}
    </div>
    <div>
      <strong style="color: #dc2626;">فروشنده:</strong><br>
      ${siteName}<br>
      ${phone ? 'تلفن: ' + phone + '<br>' : ''}
      ${address ? 'آدرس: ' + address : ''}
    </div>
  </div>
  <table>
    <thead>
      <tr>
        <th style="width: 40px;">ردیف</th>
        <th>محصول</th>
        <th style="width: 60px;">تعداد</th>
        <th style="width: 120px;">قیمت واحد</th>
        <th style="width: 140px;">مبلغ کل</th>
      </tr>
    </thead>
    <tbody>${itemsHTML}</tbody>
  </table>
  <table class="totals">
    <tr><td>جمع کالاها:</td><td class="fa-num" style="text-align: left;">${formatPrice(order.totalAmount)} ت</td></tr>
    <tr><td>هزینه ارسال:</td><td class="fa-num" style="text-align: left;">${order.shippingCost === 0 ? 'رایگان' : formatPrice(order.shippingCost) + ' ت'}</td></tr>
    <tr class="total-row"><td>مبلغ نهایی:</td><td class="fa-num" style="text-align: left;">${formatPrice(order.finalAmount)} ت</td></tr>
    <tr><td>روش پرداخت:</td><td style="text-align: left;">${order.paymentMethod === 'cod' ? 'پرداخت در محل' : 'آنلاین'}</td></tr>
  </table>
  <div class="footer">
    این فاکتور به صورت سیستمی تولید شده است.<br>
    ${siteName} - ${phone}
  </div>
  <script>
    // خودکار چاپ после لود اگر پارامتر print=true بود
    if (window.location.search.includes('print=1')) {
      setTimeout(() => window.print(), 500);
    }
  </script>
</body>
</html>`;
}
