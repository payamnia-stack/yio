import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';

// GET: دریافت یک سفارش با ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);

    if (!isAuth) {
      return NextResponse.json(
        { error: 'غیرمجاز. لطفاً وارد شوید.' },
        { status: 401 }
      );
    }

    const { id } = await params;
    const orderId = parseInt(id);

    if (isNaN(orderId)) {
      return NextResponse.json(
        { error: 'شناسه سفارش نامعتبر است' },
        { status: 400 }
      );
    }

    const order = await db.order.findUnique({
      where: { id: orderId },
      include: {
        customer: true,
        items: true,
      },
    });

    if (!order) {
      return NextResponse.json(
        { error: 'سفارش یافت نشد' },
        { status: 404 }
      );
    }

    return NextResponse.json({ order });
  } catch (error) {
    console.error('Error fetching order:', error);
    return NextResponse.json(
      { error: 'خطا در دریافت سفارش' },
      { status: 500 }
    );
  }
}

// PUT: به‌روزرسانی سفارش (تغییر وضعیت، کد رهگیری و...)
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);

    if (!isAuth) {
      return NextResponse.json(
        { error: 'غیرمجاز. لطفاً وارد شوید.' },
        { status: 401 }
      );
    }

    const { id } = await params;
    const orderId = parseInt(id);

    if (isNaN(orderId)) {
      return NextResponse.json(
        { error: 'شناسه سفارش نامعتبر است' },
        { status: 400 }
      );
    }

    const body = await request.json();

    const updateData: any = {};
    const validStatuses = ['pending', 'confirmed', 'shipping', 'delivered', 'cancelled'];
    if (body.status && validStatuses.includes(body.status)) {
      updateData.status = body.status;
    }
    const validPaymentStatuses = ['unpaid', 'paid', 'refunded'];
    if (body.paymentStatus && validPaymentStatuses.includes(body.paymentStatus)) {
      updateData.paymentStatus = body.paymentStatus;
    }
    if (body.trackingCode !== undefined) {
      updateData.trackingCode = String(body.trackingCode).trim() || null;
    }
    if (body.notes !== undefined) {
      const sanitize = (str: string) => str.replace(/<script[^>]*>.*?<\/script>/gi, '').replace(/<[^>]+>/g, '').trim();
      updateData.notes = body.notes ? sanitize(body.notes) : null;
    }

    const order = await db.order.update({
      where: { id: orderId },
      data: updateData,
      include: {
        customer: true,
        items: true,
      },
    });

    return NextResponse.json({ order, success: true });
  } catch (error) {
    console.error('Error updating order:', error);
    return NextResponse.json(
      { error: 'خطا در ویرایش سفارش' },
      { status: 500 }
    );
  }
}
