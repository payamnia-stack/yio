import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { enforceRateLimit, securityCheck, validateIranMobile, validateString, sanitizeInput } from '@/lib/security';

// POST: ثبت درخواست اطلاع‌نامه موجودی (عمومی)
export async function POST(request: NextRequest) {
  try {
    const rateLimit = await enforceRateLimit(request, 'notify-stock', 10);
    if (!rateLimit.allowed) return rateLimit.response!;

    const body = await request.json();

    const secCheck = securityCheck(body);
    if (!secCheck.safe) {
      return NextResponse.json({ error: secCheck.reason }, { status: 400 });
    }

    const productId = parseInt(body.productId);
    const phone = validateString(body.phone, 11, 11);

    if (isNaN(productId) || productId < 1) {
      return NextResponse.json({ error: 'محصول نامعتبر است' }, { status: 400 });
    }

    if (!phone || !validateIranMobile(phone)) {
      return NextResponse.json({ error: 'شماره موبایل نامعتبر است' }, { status: 400 });
    }

    // بررسی وجود محصول
    const product = await db.product.findUnique({ where: { id: productId } });
    if (!product) {
      return NextResponse.json({ error: 'محصول یافت نشد' }, { status: 404 });
    }

    // بررسی تکراری نبودن
    const existing = await db.notificationRequest.findFirst({
      where: { productId, phone, notified: false },
    });
    if (existing) {
      return NextResponse.json({ success: true, message: 'شما قبلا ثبت کرده‌اید' });
    }

    await db.notificationRequest.create({
      data: {
        productId,
        phone,
        email: body.email ? sanitizeInput(body.email).slice(0, 254) : null,
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error creating notification request:', error);
    return NextResponse.json({ error: 'خطا در ثبت درخواست' }, { status: 500 });
  }
}
