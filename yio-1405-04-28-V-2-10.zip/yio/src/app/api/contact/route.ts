import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { enforceRateLimit, securityCheck, validateIranMobile, validateString, validateEmail, sanitizeInput } from '@/lib/security';

// POST: ارسال پیام تماس (عمومی)
export async function POST(request: NextRequest) {
  try {
    const rateLimit = await enforceRateLimit(request, 'contact', 5);
    if (!rateLimit.allowed) return rateLimit.response!;

    const body = await request.json();

    const secCheck = securityCheck(body);
    if (!secCheck.safe) {
      return NextResponse.json({ error: secCheck.reason }, { status: 400 });
    }

    const name = validateString(body.name, 3, 100);
    const phone = validateString(body.phone, 11, 11);
    const subject = validateString(body.subject, 3, 200);
    const message = validateString(body.message, 10, 2000);

    if (!name || !phone || !subject || !message) {
      return NextResponse.json({ error: 'تمام فیلدها را پر کنید' }, { status: 400 });
    }

    if (!validateIranMobile(phone)) {
      return NextResponse.json({ error: 'شماره موبایل نامعتبر است' }, { status: 400 });
    }

    if (body.email && !validateEmail(body.email)) {
      return NextResponse.json({ error: 'ایمیل نامعتبر است' }, { status: 400 });
    }

    await db.contactMessage.create({
      data: {
        name: sanitizeInput(name),
        phone,
        email: body.email ? sanitizeInput(body.email).slice(0, 254) : null,
        subject: sanitizeInput(subject),
        message: sanitizeInput(message),
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error creating contact message:', error);
    return NextResponse.json({ error: 'خطا در ارسال پیام' }, { status: 500 });
  }
}
