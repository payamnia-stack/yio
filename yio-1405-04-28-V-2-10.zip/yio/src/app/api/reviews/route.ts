// API نظرات محصولات
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserFromSession } from '@/lib/user-auth';
import { enforceRateLimit, securityCheck, validateString, sanitizeInput } from '@/lib/security';

// GET: نظرات یک محصول
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const productId = parseInt(searchParams.get('productId') || '0');
    if (!productId) return NextResponse.json({ error: 'محصول نامعتبر' }, { status: 400 });

    const reviews = await db.review.findMany({
      where: { productId, isActive: true },
      include: { user: { select: { name: true } } },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({ reviews });
  } catch { return NextResponse.json({ error: 'خطا' }, { status: 500 }); }
}

// POST: ثبت نظر جدید
export async function POST(request: NextRequest) {
  try {
    const rateLimit = await enforceRateLimit(request, 'review', 5);
    if (!rateLimit.allowed) return rateLimit.response!;

    const user = await getUserFromSession();
    if (!user) return NextResponse.json({ error: 'برای ثبت نظر وارد شوید' }, { status: 401 });

    const body = await request.json();
    const secCheck = securityCheck(body);
    if (!secCheck.safe) return NextResponse.json({ error: secCheck.reason }, { status: 400 });

    const productId = parseInt(body.productId);
    const rating = parseInt(body.rating);
    const comment = body.comment ? validateString(body.comment, 5, 1000) : null;

    if (!productId || isNaN(rating) || rating < 1 || rating > 5) {
      return NextResponse.json({ error: 'اطلاعات نامعتبر' }, { status: 400 });
    }

    // بررسی خرید قبلی
    const hasPurchased = await db.order.findFirst({
      where: { userId: user.id, items: { some: { productId } } },
    });

    const review = await db.review.create({
      data: { userId: user.id, productId, rating, comment: comment ? sanitizeInput(comment) : null, isActive: hasPurchased ? true : false },
    });

    // امتیاز وفاداری برای نظر
    if (hasPurchased) {
      await db.loyaltyPoint.create({ data: { userId: user.id, points: 5, reason: 'review' } });
    }

    return NextResponse.json({ review, success: true, message: hasPurchased ? 'نظر شما ثبت شد' : 'نظر شما پس از تأیید مدیر نمایش داده می‌شود' });
  } catch { return NextResponse.json({ error: 'خطا' }, { status: 500 }); }
}
