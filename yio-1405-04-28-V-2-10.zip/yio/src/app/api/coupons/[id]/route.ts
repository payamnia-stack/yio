import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput, securityCheck } from '@/lib/security';

// PUT: ویرایش کوپن
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);

    if (!isAuth) {
      return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });
    }

    const { id } = await params;
    const couponId = parseInt(id);

    if (isNaN(couponId)) {
      return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });
    }

    const existing = await db.coupon.findUnique({ where: { id: couponId } });
    if (!existing) {
      return NextResponse.json({ error: 'کوپن یافت نشد' }, { status: 404 });
    }

    const body = await request.json();

    const secCheck = securityCheck(body);
    if (!secCheck.safe) {
      return NextResponse.json({ error: secCheck.reason }, { status: 400 });
    }

    const updateData: any = {};

    if (body.code !== undefined) {
      const code = body.code.trim().toUpperCase();
      if (code.length < 3 || code.length > 30) {
        return NextResponse.json({ error: 'کد کوپن باید بین ۳ تا ۳۰ کاراکتر باشد' }, { status: 400 });
      }
      if (!/^[A-Z0-9\-_]+$/.test(code)) {
        return NextResponse.json({ error: 'کد کوپن نامعتبر است' }, { status: 400 });
      }
      // بررسی تکراری نبودن (به جز خودش)
      const dup = await db.coupon.findFirst({ where: { code, NOT: { id: couponId } } });
      if (dup) {
        return NextResponse.json({ error: 'این کد قبلا ثبت شده' }, { status: 400 });
      }
      updateData.code = code;
    }

    if (body.description !== undefined) {
      updateData.description = body.description ? sanitizeInput(body.description).slice(0, 500) : null;
    }

    if (body.type !== undefined) {
      const validTypes = ['percent', 'fixed', 'free_shipping'];
      if (!validTypes.includes(body.type)) {
        return NextResponse.json({ error: 'نوع نامعتبر' }, { status: 400 });
      }
      updateData.type = body.type;
    }

    if (body.value !== undefined) {
      const value = parseInt(body.value);
      if (body.type === 'percent' && (isNaN(value) || value < 1 || value > 90)) {
        return NextResponse.json({ error: 'درصد باید بین ۱ تا ۹۰ باشد' }, { status: 400 });
      }
      if (body.type === 'fixed' && (isNaN(value) || value < 1000)) {
        return NextResponse.json({ error: 'مبلغ باید حداقل ۱۰۰۰ تومان باشد' }, { status: 400 });
      }
      updateData.value = body.type === 'free_shipping' ? 0 : value;
    }

    if (body.minPurchase !== undefined) {
      updateData.minPurchase = body.minPurchase ? parseInt(body.minPurchase) : null;
    }

    if (body.maxDiscount !== undefined) {
      updateData.maxDiscount = body.maxDiscount ? parseInt(body.maxDiscount) : null;
    }

    if (body.usageLimit !== undefined) {
      updateData.usageLimit = body.usageLimit ? parseInt(body.usageLimit) : null;
    }

    if (body.perUserLimit !== undefined) {
      const pul = parseInt(body.perUserLimit);
      if (pul < 1 || pul > 100) {
        return NextResponse.json({ error: 'حداکثر استفاده هر کاربر باید بین ۱ تا ۱۰۰ باشد' }, { status: 400 });
      }
      updateData.perUserLimit = pul;
    }

    if (body.validFrom !== undefined) {
      const d = new Date(body.validFrom);
      if (isNaN(d.getTime())) {
        return NextResponse.json({ error: 'تاریخ شروع نامعتبر' }, { status: 400 });
      }
      updateData.validFrom = d;
    }

    if (body.validUntil !== undefined) {
      const d = new Date(body.validUntil);
      if (isNaN(d.getTime())) {
        return NextResponse.json({ error: 'تاریخ پایان نامعتبر' }, { status: 400 });
      }
      updateData.validUntil = d;
    }

    if (body.isActive !== undefined) updateData.isActive = Boolean(body.isActive);
    if (body.firstOrderOnly !== undefined) updateData.firstOrderOnly = Boolean(body.firstOrderOnly);

    const coupon = await db.coupon.update({
      where: { id: couponId },
      data: updateData,
    });

    return NextResponse.json({ coupon, success: true });
  } catch (error) {
    console.error('Error updating coupon:', error);
    return NextResponse.json({ error: 'خطا در ویرایش' }, { status: 500 });
  }
}

// DELETE: حذف کوپن
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);

    if (!isAuth) {
      return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });
    }

    const { id } = await params;
    const couponId = parseInt(id);

    if (isNaN(couponId)) {
      return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });
    }

    const existing = await db.coupon.findUnique({ where: { id: couponId } });
    if (!existing) {
      return NextResponse.json({ error: 'یافت نشد' }, { status: 404 });
    }

    await db.coupon.delete({ where: { id: couponId } });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting coupon:', error);
    return NextResponse.json({ error: 'خطا در حذف' }, { status: 500 });
  }
}
