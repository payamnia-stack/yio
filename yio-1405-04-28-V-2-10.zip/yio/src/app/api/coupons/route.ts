import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput, securityCheck, enforceRateLimit } from '@/lib/security';

// GET: لیست کوپن‌ها (مدیر)
export async function GET(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);

    if (!isAuth) {
      return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';
    const isActive = searchParams.get('isActive');
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '20');

    const where: any = {};
    if (search) {
      where.OR = [
        { code: { contains: search } },
        { description: { contains: search } },
      ];
    }
    if (isActive === 'true') where.isActive = true;
    if (isActive === 'false') where.isActive = false;

    const total = await db.coupon.count({ where });
    const coupons = await db.coupon.findMany({
      where,
      include: {
        _count: { select: { usedBy: true } },
      },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    });

    const stats = {
      total: await db.coupon.count(),
      active: await db.coupon.count({ where: { isActive: true } }),
      expired: await db.coupon.count({ where: { validUntil: { lt: new Date() } } }),
      totalUsage: await db.couponUsage.count(),
      totalDiscount: await db.couponUsage.aggregate({ _sum: { discountAmount: true } }),
    };

    return NextResponse.json({
      coupons,
      pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
      stats,
    });
  } catch (error) {
    console.error('Error fetching coupons:', error);
    return NextResponse.json({ error: 'خطا در دریافت کوپن‌ها' }, { status: 500 });
  }
}

// POST: ایجاد کوپن جدید
export async function POST(request: NextRequest) {
  try {
    const rateLimit = await enforceRateLimit(request, 'coupons', 20);
    if (!rateLimit.allowed) return rateLimit.response!;

    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);

    if (!isAuth) {
      return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });
    }

    const body = await request.json();

    const secCheck = securityCheck(body);
    if (!secCheck.safe) {
      return NextResponse.json({ error: secCheck.reason }, { status: 400 });
    }

    // اعتبارسنجی کد کوپن
    if (!body.code || typeof body.code !== 'string') {
      return NextResponse.json({ error: 'کد کوپن الزامی است' }, { status: 400 });
    }

    const code = body.code.trim().toUpperCase();
    if (code.length < 3 || code.length > 30) {
      return NextResponse.json({ error: 'کد کوپن باید بین ۳ تا ۳۰ کاراکتر باشد' }, { status: 400 });
    }

    if (!/^[A-Z0-9\-_]+$/.test(code)) {
      return NextResponse.json({ error: 'کد کوپن فقط می‌تواند شامل حروف بزرگ انگلیسی، عدد، خط تیره و زیرخط باشد' }, { status: 400 });
    }

    // بررسی تکراری نبودن
    const existing = await db.coupon.findUnique({ where: { code } });
    if (existing) {
      return NextResponse.json({ error: 'این کد کوپن قبلا ثبت شده است' }, { status: 400 });
    }

    // اعتبارسنجی نوع و مقدار
    const validTypes = ['percent', 'fixed', 'free_shipping'];
    if (!body.type || !validTypes.includes(body.type)) {
      return NextResponse.json({ error: 'نوع تخفیف نامعتبر است' }, { status: 400 });
    }

    const value = parseInt(body.value);
    if (body.type === 'percent' && (isNaN(value) || value < 1 || value > 90)) {
      return NextResponse.json({ error: 'درصد تخفیف باید بین ۱ تا ۹۰ باشد' }, { status: 400 });
    }
    if (body.type === 'fixed' && (isNaN(value) || value < 1000)) {
      return NextResponse.json({ error: 'مبلغ تخفیف باید حداقل ۱۰۰۰ تومان باشد' }, { status: 400 });
    }

    // اعتبارسنجی تاریخ‌ها
    const validFrom = new Date(body.validFrom);
    const validUntil = new Date(body.validUntil);

    if (isNaN(validFrom.getTime()) || isNaN(validUntil.getTime())) {
      return NextResponse.json({ error: 'تاریخ شروع و پایان نامعتبر است' }, { status: 400 });
    }

    if (validUntil <= validFrom) {
      return NextResponse.json({ error: 'تاریخ پایان باید بعد از تاریخ شروع باشد' }, { status: 400 });
    }

    // اعتبارسنجی حداقل خرید و حداکثر تخفیف
    let minPurchase = null;
    if (body.minPurchase) {
      minPurchase = parseInt(body.minPurchase);
      if (isNaN(minPurchase) || minPurchase < 0) {
        return NextResponse.json({ error: 'حداقل خرید نامعتبر است' }, { status: 400 });
      }
    }

    let maxDiscount = null;
    if (body.type === 'percent' && body.maxDiscount) {
      maxDiscount = parseInt(body.maxDiscount);
      if (isNaN(maxDiscount) || maxDiscount < 1000) {
        return NextResponse.json({ error: 'حداکثر تخفیف نامعتبر است' }, { status: 400 });
      }
    }

    let usageLimit = null;
    if (body.usageLimit) {
      usageLimit = parseInt(body.usageLimit);
      if (isNaN(usageLimit) || usageLimit < 1) {
        return NextResponse.json({ error: 'حداکثر استفاده نامعتبر است' }, { status: 400 });
      }
    }

    const perUserLimit = parseInt(body.perUserLimit) || 1;
    if (perUserLimit < 1 || perUserLimit > 100) {
      return NextResponse.json({ error: 'حداکثر استفاده هر کاربر باید بین ۱ تا ۱۰۰ باشد' }, { status: 400 });
    }

    const coupon = await db.coupon.create({
      data: {
        code,
        description: body.description ? sanitizeInput(body.description).slice(0, 500) : null,
        type: body.type,
        value: body.type === 'free_shipping' ? 0 : value,
        minPurchase,
        maxDiscount,
        usageLimit,
        perUserLimit,
        validFrom,
        validUntil,
        isActive: Boolean(body.isActive ?? true),
        firstOrderOnly: Boolean(body.firstOrderOnly ?? false),
      },
    });

    return NextResponse.json({ coupon, success: true });
  } catch (error) {
    console.error('Error creating coupon:', error);
    return NextResponse.json({ error: 'خطا در ایجاد کوپن' }, { status: 500 });
  }
}
