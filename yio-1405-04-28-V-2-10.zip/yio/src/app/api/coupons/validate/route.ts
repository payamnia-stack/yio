import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { enforceRateLimit, securityCheck, validateIranMobile } from '@/lib/security';

// POST: اعتبارسنجی کوپن (برای مشتری - بدون احراز هویت)
export async function POST(request: NextRequest) {
  try {
    const rateLimit = await enforceRateLimit(request, 'validate-coupon', 10);
    if (!rateLimit.allowed) return rateLimit.response!;

    const body = await request.json();

    const secCheck = securityCheck(body);
    if (!secCheck.safe) {
      return NextResponse.json({ error: secCheck.reason }, { status: 400 });
    }

    const { code, cartTotal, customerPhone } = body;

    if (!code || typeof code !== 'string') {
      return NextResponse.json({ error: 'کد کوپن الزامی است' }, { status: 400 });
    }

    const couponCode = code.trim().toUpperCase();

    const cartTotalNum = parseInt(cartTotal);
    if (isNaN(cartTotalNum) || cartTotalNum < 0) {
      return NextResponse.json({ error: 'مبلغ سبد نامعتبر است' }, { status: 400 });
    }

    // پیدا کردن کوپن
    const coupon = await db.coupon.findUnique({
      where: { code: couponCode },
      include: {
        usedBy: customerPhone ? {
          where: { customerPhone },
        } : false,
      },
    });

    if (!coupon) {
      return NextResponse.json({ error: 'کد کوپن یافت نشد', valid: false }, { status: 404 });
    }

    // بررسی وضعیت فعال
    if (!coupon.isActive) {
      return NextResponse.json({ error: 'این کوپن غیرفعال است', valid: false }, { status: 400 });
    }

    // بررسی تاریخ اعتبار
    const now = new Date();
    if (now < coupon.validFrom) {
      return NextResponse.json({ error: 'این کوپن هنوز فعال نشده است', valid: false }, { status: 400 });
    }
    if (now > coupon.validUntil) {
      return NextResponse.json({ error: 'این کوپن منقضی شده است', valid: false }, { status: 400 });
    }

    // بررسی حداقل خرید
    if (coupon.minPurchase && cartTotalNum < coupon.minPurchase) {
      return NextResponse.json({
        error: `حداقل خرید برای این کوپن ${coupon.minPurchase.toLocaleString('fa-IR')} تومان است`,
        valid: false,
        minPurchase: coupon.minPurchase,
      }, { status: 400 });
    }

    // بررسی سقف استفاده کلی
    if (coupon.usageLimit && coupon.usedCount >= coupon.usageLimit) {
      return NextResponse.json({ error: 'این کوپن به حداکثر استفاده رسیده است', valid: false }, { status: 400 });
    }

    // بررسی سقف استفاده هر کاربر
    if (customerPhone && validateIranMobile(customerPhone)) {
      const userUsageCount = await db.couponUsage.count({
        where: { couponId: coupon.id, customerPhone },
      });
      if (userUsageCount >= coupon.perUserLimit) {
        return NextResponse.json({
          error: `شما قبلا ${userUsageCount} بار از این کوپن استفاده کرده‌اید (حداکثر ${coupon.perUserLimit} بار)`,
          valid: false,
        }, { status: 400 });
      }

      // بررسی اولین سفارش
      if (coupon.firstOrderOnly) {
        const hasOrders = await db.order.count({
          where: { recipientPhone: customerPhone },
        });
        if (hasOrders > 0) {
          return NextResponse.json({
            error: 'این کوپن فقط برای اولین سفارش قابل استفاده است',
            valid: false,
          }, { status: 400 });
        }
      }
    }

    // محاسبه مبلغ تخفیف
    let discountAmount = 0;
    let freeShipping = false;

    switch (coupon.type) {
      case 'percent':
        discountAmount = Math.round(cartTotalNum * (coupon.value / 100));
        if (coupon.maxDiscount && discountAmount > coupon.maxDiscount) {
          discountAmount = coupon.maxDiscount;
        }
        break;
      case 'fixed':
        discountAmount = Math.min(coupon.value, cartTotalNum);
        break;
      case 'free_shipping':
        freeShipping = true;
        discountAmount = 0;
        break;
    }

    // ثبت استفاده از کوپن (در صورت درخواست)
    if (body.markUsed && customerPhone && validateIranMobile(customerPhone)) {
      // بررسی مجدد سقف‌ها (race condition)
      if (coupon.usageLimit && coupon.usedCount >= coupon.usageLimit) {
        return NextResponse.json({ error: 'این کوپن به حداکثر استفاده رسیده است', valid: false }, { status: 400 });
      }

      const userUsageCount = await db.couponUsage.count({
        where: { couponId: coupon.id, customerPhone },
      });
      if (userUsageCount >= coupon.perUserLimit) {
        return NextResponse.json({
          error: 'شما به سقف استفاده از این کوپن رسیده‌اید',
          valid: false,
        }, { status: 400 });
      }

      // ثبت استفاده
      await db.$transaction([
        db.couponUsage.create({
          data: {
            couponId: coupon.id,
            orderId: body.orderId ? parseInt(body.orderId) : null,
            customerPhone,
            discountAmount,
          },
        }),
        db.coupon.update({
          where: { id: coupon.id },
          data: { usedCount: { increment: 1 } },
        }),
      ]);
    }

    return NextResponse.json({
      valid: true,
      coupon: {
        id: coupon.id,
        code: coupon.code,
        type: coupon.type,
        value: coupon.value,
        description: coupon.description,
      },
      discountAmount,
      freeShipping,
      newTotal: cartTotalNum - discountAmount,
    });
  } catch (error) {
    console.error('Error validating coupon:', error);
    return NextResponse.json({ error: 'خطا در بررسی کوپن' }, { status: 500 });
  }
}
