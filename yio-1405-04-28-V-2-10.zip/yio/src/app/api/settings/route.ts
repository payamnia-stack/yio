import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET: دریافت تنظیمات عمومی (بدون احراز هویت - برای نمایش در سایت)
// می‌تواند با پارامتر q یک کلید خاص را برگرداند
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const key = searchParams.get('q');

    if (key) {
      // برگرداندن یک کلید خاص
      const setting = await db.siteSetting.findUnique({ where: { key } });
      return NextResponse.json({ value: setting?.value || null });
    }

    // برگرداندن همه تنظیمات
    const settings = await db.siteSetting.findMany();
    const obj: Record<string, string> = {};
    settings.forEach(s => { obj[s.key] = s.value; });
    return NextResponse.json({ settings: obj });
  } catch (error) {
    return NextResponse.json({ settings: {} }, { status: 500 });
  }
}
