import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET: روش‌های پرداخت فعال برای نمایش در checkout (بدون اطلاعات حساس)
export async function GET() {
  try {
    const methods = await db.paymentMethod.findMany({
      where: { isActive: true },
      orderBy: [{ priority: 'asc' }, { name: 'asc' }],
      select: {
        id: true,
        name: true,
        type: true,
        bank: true,
        description: true,
        logo: true,
        isDefault: true,
        priority: true,
        // اطلاعات حساس مثل merchantId و apiKey برنمی‌گردد
      },
    });

    return NextResponse.json({ methods });
  } catch (error) {
    console.error('Error fetching active payment methods:', error);
    return NextResponse.json({ error: 'خطا در دریافت روش‌های پرداخت' }, { status: 500 });
  }
}
