import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { encrypt, sanitizeInput, validateURL, securityCheck } from '@/lib/security';

// PUT: ویرایش روش پرداخت
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);

    if (!isAuth) {
      return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });
    }

    const { id } = await params;
    const methodId = parseInt(id);

    if (isNaN(methodId)) {
      return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });
    }

    const body = await request.json();

    // بررسی امنیتی
    const secCheck = securityCheck(body);
    if (!secCheck.safe) {
      return NextResponse.json({ error: secCheck.reason }, { status: 400 });
    }

    const existing = await db.paymentMethod.findUnique({ where: { id: methodId } });
    if (!existing) {
      return NextResponse.json({ error: 'روش پرداخت یافت نشد' }, { status: 404 });
    }

    if (body.callbackUrl && !validateURL(body.callbackUrl)) {
      return NextResponse.json({ error: 'آدرس بازگشت نامعتبر است' }, { status: 400 });
    }
    if (body.logo && !validateURL(body.logo)) {
      return NextResponse.json({ error: 'آدرس لوگو نامعتبر است' }, { status: 400 });
    }

    // اگر پیش‌فرض می‌شود
    if (body.isDefault) {
      await db.paymentMethod.updateMany({
        where: { isDefault: true, id: { not: methodId } },
        data: { isDefault: false },
      });
    }

    const updateData: any = {};
    if (body.name !== undefined) updateData.name = sanitizeInput(body.name);
    if (body.type !== undefined) {
      const validTypes = ['cod', 'online', 'wallet', 'transfer'];
      if (!validTypes.includes(body.type)) {
        return NextResponse.json({ error: 'نوع پرداخت نامعتبر' }, { status: 400 });
      }
      updateData.type = body.type;
    }
    if (body.bank !== undefined) updateData.bank = body.bank ? sanitizeInput(body.bank) : null;
    if (body.merchantId !== undefined) {
      // فقط اگر مقدار جدید داده شده (نه ماسک شده)
      if (body.merchantId && !body.merchantId.startsWith('••••')) {
        updateData.merchantId = encrypt(body.merchantId);
      }
    }
    if (body.terminalId !== undefined) {
      if (body.terminalId && !body.terminalId.startsWith('••••')) {
        updateData.terminalId = encrypt(body.terminalId);
      }
    }
    if (body.apiKey !== undefined) {
      if (body.apiKey && !body.apiKey.startsWith('••••')) {
        updateData.apiKey = encrypt(body.apiKey);
      }
    }
    if (body.callbackUrl !== undefined) updateData.callbackUrl = body.callbackUrl || null;
    if (body.description !== undefined) updateData.description = body.description ? sanitizeInput(body.description) : null;
    if (body.logo !== undefined) updateData.logo = body.logo || null;
    if (body.isActive !== undefined) updateData.isActive = Boolean(body.isActive);
    if (body.isDefault !== undefined) updateData.isDefault = Boolean(body.isDefault);
    if (body.priority !== undefined) updateData.priority = parseInt(body.priority) || 0;

    const method = await db.paymentMethod.update({
      where: { id: methodId },
      data: updateData,
    });

    const safeMethod = {
      ...method,
      merchantId: method.merchantId ? maskValue(method.merchantId) : null,
      terminalId: method.terminalId ? maskValue(method.terminalId) : null,
      apiKey: method.apiKey ? maskValue(method.apiKey) : null,
    };

    return NextResponse.json({ method: safeMethod, success: true });
  } catch (error) {
    console.error('Error updating payment method:', error);
    return NextResponse.json({ error: 'خطا در ویرایش' }, { status: 500 });
  }
}

// DELETE: حذف روش پرداخت
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);

    if (!isAuth) {
      return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });
    }

    const { id } = await params;
    const methodId = parseInt(id);

    if (isNaN(methodId)) {
      return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });
    }

    const existing = await db.paymentMethod.findUnique({ where: { id: methodId } });
    if (!existing) {
      return NextResponse.json({ error: 'یافت نشد' }, { status: 404 });
    }

    await db.paymentMethod.delete({ where: { id: methodId } });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting payment method:', error);
    return NextResponse.json({ error: 'خطا در حذف' }, { status: 500 });
  }
}

function maskValue(encrypted: string): string {
  if (!encrypted) return '';
  const len = encrypted.length;
  if (len <= 8) return '••••';
  return '••••••••' + encrypted.slice(-4);
}
