import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { encrypt, sanitizeInput, validateURL, securityCheck, enforceRateLimit } from '@/lib/security';

// GET: لیست روش‌های پرداخت (مدیر - با اطلاعات کامل)
export async function GET(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);

    if (!isAuth) {
      return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });
    }

    const methods = await db.paymentMethod.findMany({
      orderBy: [{ priority: 'asc' }, { createdAt: 'desc' }],
    });

    // ماسک کردن اطلاعات حساس برای نمایش
    const safeMethods = methods.map(m => ({
      ...m,
      merchantId: m.merchantId ? maskValue(m.merchantId) : null,
      terminalId: m.terminalId ? maskValue(m.terminalId) : null,
      apiKey: m.apiKey ? maskValue(m.apiKey) : null,
    }));

    return NextResponse.json({ methods: safeMethods });
  } catch (error) {
    console.error('Error fetching payment methods:', error);
    return NextResponse.json({ error: 'خطا در دریافت روش‌های پرداخت' }, { status: 500 });
  }
}

function maskValue(encrypted: string): string {
  // اگر رمزنگاری شده، اول decrypt کن بعد ماسک کن
  // برای امنیت بیشتر، فقط چند کاراکتر آخر رو نشون می‌دیم
  if (!encrypted) return '';
  const len = encrypted.length;
  if (len <= 8) return '••••';
  return '••••••••' + encrypted.slice(-4);
}

// POST: افزودن روش پرداخت جدید
export async function POST(request: NextRequest) {
  try {
    // Rate limit
    const rateLimit = await enforceRateLimit(request, 'payment-methods', 20);
    if (!rateLimit.allowed) {
      return rateLimit.response;
    }

    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);

    if (!isAuth) {
      return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });
    }

    const body = await request.json();

    // بررسی امنیتی ورودی
    const secCheck = securityCheck(body);
    if (!secCheck.safe) {
      return NextResponse.json({ error: secCheck.reason }, { status: 400 });
    }

    // اعتبارسنجی فیلدها
    if (!body.name || typeof body.name !== 'string' || body.name.trim().length < 3) {
      return NextResponse.json({ error: 'نام روش پرداخت باید حداقل ۳ کاراکتر باشد' }, { status: 400 });
    }

    const validTypes = ['cod', 'online', 'wallet', 'transfer'];
    if (!body.type || !validTypes.includes(body.type)) {
      return NextResponse.json({ error: 'نوع پرداخت نامعتبر است' }, { status: 400 });
    }

    // اعتبارسنجی URL‌ها
    if (body.callbackUrl && !validateURL(body.callbackUrl)) {
      return NextResponse.json({ error: 'آدرس بازگشت نامعتبر است' }, { status: 400 });
    }
    if (body.logo && !validateURL(body.logo)) {
      return NextResponse.json({ error: 'آدرس لوگو نامعتبر است' }, { status: 400 });
    }

    // برای درگاه آنلاین، مرچنت کد الزامی است
    if (body.type === 'online' && !body.merchantId) {
      return NextResponse.json({ error: 'کد پذیرنده برای درگاه آنلاین الزامی است' }, { status: 400 });
    }

    // اگر قرار است پیش‌فرض باشد، بقیه پیش‌فرض‌ها را لغو کن
    if (body.isDefault) {
      await db.paymentMethod.updateMany({
        where: { isDefault: true },
        data: { isDefault: false },
      });
    }

    // رمزنگاری اطلاعات حساس
    const method = await db.paymentMethod.create({
      data: {
        name: sanitizeInput(body.name),
        type: body.type,
        bank: body.bank ? sanitizeInput(body.bank) : null,
        merchantId: body.merchantId ? encrypt(body.merchantId) : null,
        terminalId: body.terminalId ? encrypt(body.terminalId) : null,
        apiKey: body.apiKey ? encrypt(body.apiKey) : null,
        callbackUrl: body.callbackUrl || null,
        description: body.description ? sanitizeInput(body.description) : null,
        logo: body.logo || null,
        isActive: Boolean(body.isActive ?? true),
        isDefault: Boolean(body.isDefault ?? false),
        priority: parseInt(body.priority) || 0,
      },
    });

    // ماسک کردن برای پاسخ
    const safeMethod = {
      ...method,
      merchantId: method.merchantId ? maskValue(method.merchantId) : null,
      terminalId: method.terminalId ? maskValue(method.terminalId) : null,
      apiKey: method.apiKey ? maskValue(method.apiKey) : null,
    };

    return NextResponse.json({ method: safeMethod, success: true });
  } catch (error) {
    console.error('Error creating payment method:', error);
    return NextResponse.json({ error: 'خطا در ایجاد روش پرداخت' }, { status: 500 });
  }
}
