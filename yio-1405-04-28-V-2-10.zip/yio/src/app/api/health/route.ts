import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET: بررسی سلامت دیتابیس
export async function GET() {
  const checks: any = {};

  try {
    await db.product.count();
    checks.products = 'ok';
  } catch {
    checks.products = 'missing';
  }

  try {
    await db.user.count();
    checks.users = 'ok';
  } catch {
    checks.users = 'missing';
  }

  try {
    await db.category.count();
    checks.categories = 'ok';
  } catch {
    checks.categories = 'missing';
  }

  try {
    await db.siteSetting.count();
    checks.settings = 'ok';
  } catch {
    checks.settings = 'missing';
  }

  const allOk = Object.values(checks).every(v => v === 'ok');

  return NextResponse.json({
    healthy: allOk,
    checks,
    message: allOk ? 'دیتابیس سالم است' : 'برخی جداول موجود نیست. دستور npx prisma db push را اجرا کنید',
  });
}
