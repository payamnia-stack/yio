import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import type { ElementNode, Spacing, Typography } from '@/lib/page-builder/types'

function spacingCss(s: unknown, prop: string): string {
  const sp = s as Spacing | undefined
  if (!sp) return ''
  return `${prop}: ${sp.top} ${sp.right} ${sp.bottom} ${sp.left};`
}

function typographyCss(t: unknown): string {
  const ty = t as Typography | undefined
  if (!ty) return ''
  return [
    `font-family: ${ty.family}`,
    `font-size: ${ty.size}`,
    `font-weight: ${ty.weight}`,
    `text-transform: ${ty.transform}`,
    `font-style: ${ty.style}`,
    `text-decoration: ${ty.decoration}`,
    `line-height: ${ty.lineHeight}`,
    `letter-spacing: ${ty.letterSpacing}`,
  ].join('; ')
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}

function renderElement(node: ElementNode, depth = 0): string {
  const p = node.props as Record<string, unknown>
  const pad = '  '.repeat(depth)

  if (node.type === 'container' || node.widget === 'container') {
    const style = [
      'display: flex',
      `flex-direction: ${p.direction ?? 'row'}`,
      `justify-content: ${p.justify ?? 'flex-start'}`,
      `align-items: ${p.align ?? 'stretch'}`,
      `gap: ${p.gap ?? '16px'}`,
      `flex-wrap: ${(p.wrap as boolean) ? 'wrap' : 'nowrap'}`,
      `min-height: ${p.minHeight ?? 'auto'}`,
      spacingCss(p.padding, 'padding'),
      spacingCss(p.margin, 'margin'),
      `background: ${p.background ?? 'transparent'}`,
      `border-radius: ${p.borderRadius ?? '0px'}`,
      p.borderWidth && p.borderWidth !== '0px' ? `border: ${p.borderWidth} solid ${p.borderColor}` : '',
    ].filter(Boolean).join('; ')

    const children = node.children.map((c) => renderElement(c, depth + 1)).join('\n')
    return `${pad}<div style="${style}">\n${children}\n${pad}</div>`
  }

  switch (node.widget) {
    case 'heading': {
      const style = [
        'margin: 0',
        `text-align: ${p.align}`,
        `color: ${p.color}`,
        typographyCss(p.typography),
        spacingCss(p.padding, 'padding'),
        spacingCss(p.margin, 'margin'),
      ].filter(Boolean).join('; ')
      return `${pad}<${p.tag} style="${style}">${escapeHtml(String(p.text ?? ''))}</${p.tag}>`
    }
    case 'text': {
      const style = [
        'margin: 0',
        `text-align: ${p.align}`,
        `color: ${p.color}`,
        typographyCss(p.typography),
        spacingCss(p.padding, 'padding'),
        spacingCss(p.margin, 'margin'),
      ].filter(Boolean).join('; ')
      return `${pad}<p style="${style}">${escapeHtml(String(p.text ?? '')).replace(/\n/g, '<br/>')}</p>`
    }
    case 'button': {
      const wrapperStyle = `display:flex; justify-content:${p.align}; ${spacingCss(p.margin, 'margin')}`
      const btnStyle = [
        'display: inline-flex',
        'align-items: center',
        'justify-content: center',
        `text-decoration: none`,
        `background: ${p.bgColor}`,
        `color: ${p.textColor}`,
        typographyCss(p.typography),
        spacingCss(p.padding, 'padding'),
        `border-radius: ${p.borderRadius}`,
        `width: ${p.width}`,
        `border: none`,
        `cursor: pointer`,
        'transition: background .2s',
      ].join('; ')
      return `${pad}<div style="${wrapperStyle}"><a href="${p.url}" target="${p.target}" style="${btnStyle}" onmouseover="this.style.background='${p.hoverBgColor}'" onmouseout="this.style.background='${p.bgColor}'">${escapeHtml(String(p.text ?? ''))}</a></div>`
    }
    case 'image': {
      const wrapper = `text-align:${p.align}; ${spacingCss(p.margin, 'margin')}`
      const imgStyle = [
        `width: ${p.width}`,
        `max-width: ${p.maxWidth}`,
        `height: ${p.height}`,
        `object-fit: ${p.objectFit}`,
        `border-radius: ${p.borderRadius}`,
      ].join('; ')
      const cap = p.caption ? `<figcaption style="text-align:center; margin-top:8px; color:#64748b; font-size:14px;">${escapeHtml(String(p.caption))}</figcaption>` : ''
      return `${pad}<div style="${wrapper}"><figure style="margin:0; display:inline-block;"><img src="${p.src}" alt="${escapeHtml(String(p.alt ?? ''))}" style="${imgStyle}"/>${cap}</figure></div>`
    }
    case 'video': {
      const wrap = `position:relative; aspect-ratio:${p.aspectRatio}; border-radius:${p.borderRadius}; overflow:hidden; ${spacingCss(p.margin, 'margin')}`
      return `${pad}<div style="${wrap}"><iframe src="${p.url}" style="position:absolute; inset:0; width:100%; height:100%; border:0;" allowfullscreen></iframe></div>`
    }
    case 'divider': {
      const wrap = `display:flex; justify-content:${p.align}; ${spacingCss(p.margin, 'margin')}`
      return `${pad}<div style="${wrap}"><hr style="border:0; border-top:${p.thickness} solid ${p.color}; width:${p.width}%; margin:0;"/></div>`
    }
    case 'spacer': {
      return `${pad}<div style="height:${p.height};"></div>`
    }
    case 'icon': {
      const wrap = `display:flex; justify-content:${p.align}; ${spacingCss(p.margin, 'margin')}`
      // Inline SVG via lucide static is complex; use a unicode glyph fallback
      return `${pad}<div style="${wrap}"><span style="font-size:${p.size}; color:${p.color}; line-height:1;">★</span></div>`
    }
    case 'icon-box': {
      const flexDir = p.position === 'top' ? 'column' : p.position === 'right' ? 'row-reverse' : 'row'
      const style = [
        `display:flex`,
        `flex-direction:${flexDir}`,
        `align-items:center`,
        `gap:16px`,
        `text-align:${p.align}`,
        `background:${p.bgColor}`,
        spacingCss(p.padding, 'padding'),
        `border-radius:${p.borderRadius}`,
      ].join('; ')
      return `${pad}<div style="${style}"><span style="font-size:${p.iconSize}; color:${p.iconColor}; line-height:1;">★</span><div><h4 style="margin:0 0 6px; color:${p.titleColor}; font-size:18px; font-weight:600;">${escapeHtml(String(p.title))}</h4><p style="margin:0; color:${p.descColor}; font-size:14px;">${escapeHtml(String(p.description))}</p></div></div>`
    }
    case 'image-box': {
      const style = [
        'overflow:hidden',
        `background:${p.bgColor}`,
        `border-radius:${p.borderRadius}`,
        spacingCss(p.padding, 'padding'),
      ].join('; ')
      return `${pad}<div style="${style}"><img src="${p.src}" alt="" style="width:100%; height:${p.imageHeight}; object-fit:cover;"/><div style="padding:16px;"><h4 style="margin:0 0 6px; color:${p.titleColor}; font-size:18px; font-weight:600;">${escapeHtml(String(p.title))}</h4><p style="margin:0; color:${p.descColor}; font-size:14px;">${escapeHtml(String(p.description))}</p></div></div>`
    }
    case 'cta': {
      const style = [
        `text-align:${p.align}`,
        `background:${p.bgColor}`,
        spacingCss(p.padding, 'padding'),
        `border-radius:${p.borderRadius}`,
      ].join('; ')
      return `${pad}<div style="${style}"><h2 style="margin:0 0 12px; color:${p.titleColor}; font-size:32px;">${escapeHtml(String(p.title))}</h2><p style="margin:0 0 20px; color:${p.descColor}; font-size:16px;">${escapeHtml(String(p.description))}</p><a href="${p.buttonUrl}" style="display:inline-block; background:${p.buttonBg}; color:${p.buttonText}; padding:12px 28px; border-radius:8px; text-decoration:none; font-weight:600;">${escapeHtml(String(p.buttonText))}</a></div>`
    }
    case 'flip-box': {
      return `${pad}<div style="perspective:1000px; height:${p.height};"><div class="flip-card" style="position:relative; width:100%; height:100%; transition:transform .6s; transform-style:preserve-3d;"><div style="position:absolute; inset:0; backface-visibility:hidden; background:${p.frontBg}; color:${p.frontTextColor}; border-radius:${p.borderRadius}; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:24px;"><div style="font-size:48px;">💡</div><h3 style="margin:12px 0 8px;">${escapeHtml(String(p.frontTitle))}</h3><p>${escapeHtml(String(p.frontDesc))}</p></div><div style="position:absolute; inset:0; backface-visibility:hidden; transform:rotateY(180deg); background:${p.backBg}; color:${p.backTextColor}; border-radius:${p.borderRadius}; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:24px;"><h3 style="margin:0 0 8px;">${escapeHtml(String(p.backTitle))}</h3><p style="margin:0 0 16px;">${escapeHtml(String(p.backDesc))}</p><a href="${p.backButtonUrl}" style="display:inline-block; padding:8px 20px; border:2px solid currentColor; border-radius:6px; text-decoration:none;">${escapeHtml(String(p.backButtonText))}</a></div></div></div>
<style>.flip-card:hover{transform:rotateY(180deg);}</style>`
    }
    case 'testimonial': {
      const style = [
        `background:${p.bgColor}`,
        `text-align:${p.align}`,
        spacingCss(p.padding, 'padding'),
        `border-radius:${p.borderRadius}`,
      ].join('; ')
      const stars = '★'.repeat(Number(p.rating || 0)) + '☆'.repeat(5 - Number(p.rating || 0))
      return `${pad}<div style="${style}"><div style="color:${p.starColor}; font-size:18px; margin-bottom:12px;">${stars}</div><blockquote style="margin:0 0 16px; color:${p.textColor}; font-size:16px; font-style:italic;">"${escapeHtml(String(p.quote))}"</blockquote><div style="display:flex; align-items:center; gap:12px; justify-content:${p.align === 'center' ? 'center' : 'flex-start'};"><img src="${p.avatar}" alt="" style="width:48px; height:48px; border-radius:50%; object-fit:cover;"/><div><div style="color:${p.nameColor}; font-weight:600;">${escapeHtml(String(p.name))}</div><div style="color:${p.roleColor}; font-size:13px;">${escapeHtml(String(p.role))}</div></div></div></div>`
    }
    case 'alert': {
      const colors: Record<string, { bg: string; border: string; text: string }> = {
        info: { bg: '#eff6ff', border: '#3b82f6', text: '#1e40af' },
        success: { bg: '#ecfdf5', border: '#10b981', text: '#065f46' },
        warning: { bg: '#fffbeb', border: '#f59e0b', text: '#92400e' },
        error: { bg: '#fef2f2', border: '#ef4444', text: '#991b1b' },
      }
      const v = colors[String(p.variant)] || colors.info
      const style = [
        `display:flex`,
        `gap:12px`,
        `align-items:flex-start`,
        `background:${v.bg}`,
        `border-left:4px solid ${v.border}`,
        `color:${v.text}`,
        spacingCss(p.padding, 'padding'),
        `border-radius:${p.borderRadius}`,
        spacingCss(p.margin, 'margin'),
      ].join('; ')
      return `${pad}<div style="${style}"><span style="font-size:20px; line-height:1.25;">ℹ</span><div><strong style="display:block; margin-bottom:4px;">${escapeHtml(String(p.title))}</strong><span style="font-size:14px;">${escapeHtml(String(p.description))}</span></div></div>`
    }
    case 'accordion': {
      const items = String(p.items ?? '')
        .split('\n')
        .map((l) => l.split('|'))
        .filter((p) => p.length >= 2)
      const blocks = items
        .map((it, i) => {
          const title = escapeHtml(it[0].trim())
          const body = escapeHtml(it.slice(1).join('|').trim())
          const open = (p.firstOpen as boolean) && i === 0
          return `<details${open ? ' open' : ''} style="margin-bottom:8px; border-radius:${p.borderRadius}; overflow:hidden;"><summary style="background:${p.headerBgColor}; color:${p.headerTextColor}; padding:14px 18px; cursor:pointer; font-weight:500; list-style:none;">${title}</summary><div style="background:${p.bgColor}; color:${p.bodyTextColor}; padding:14px 18px; font-size:14px;">${body}</div></details>`
        })
        .join('')
      return `${pad}<div style="${spacingCss(p.margin, 'margin')}">${blocks}</div>`
    }
    case 'animated-headline': {
      const words = String(p.rotating ?? '').split(',').map((w) => w.trim()).filter(Boolean)
      const style = [
        'margin: 0',
        `text-align:${p.align}`,
        `color:${p.textColor}`,
        typographyCss(p.typography),
        spacingCss(p.margin, 'margin'),
      ].filter(Boolean).join('; ')
      const wordsHtml = words
        .map((w, i) => `<span style="color:${p.highlightColor}; display:none;" data-i="${i}">${escapeHtml(w)}</span>`)
        .join('')
      return `${pad}<${p.tag} style="${style}">${escapeHtml(String(p.before))}<span class="ah-rotator" style="position:relative; display:inline-block;">${wordsHtml}</span>${escapeHtml(String(p.after))}</${p.tag}>
<script>(function(){var r=document.currentScript.previousElementSibling;var ws=r.querySelectorAll('span[data-i]');if(!ws.length)return;var i=0;ws[0].style.display='inline';setInterval(function(){ws[i].style.display='none';i=(i+1)%ws.length;ws[i].style.display='inline';},2000);})();</script>`
    }
    case 'code-highlight': {
      const bg = p.theme === 'light' ? '#f8fafc' : '#1e1e1e'
      const fg = p.theme === 'light' ? '#0f172a' : '#d4d4d4'
      return `${pad}<pre style="background:${bg}; color:${fg}; padding:18px; border-radius:${p.borderRadius}; overflow:auto; ${spacingCss(p.margin, 'margin')}"><code data-lang="${p.language}">${escapeHtml(String(p.code ?? ''))}</code></pre>`
    }
    default:
      return ''
  }
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params
  const pages = await db.$queryRawUnsafe(`SELECT * FROM PageBuilderPage WHERE id = ?`, id) as any[]
  if (!pages || pages.length === 0) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  const page = pages[0]

  const tree: ElementNode[] = JSON.parse(page.content)
  const body = tree.map((n) => renderElement(n, 1)).join('\n')

  const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>${escapeHtml(page.name)}</title>
<style>
  *{box-sizing:border-box;}
  body{margin:0; font-family:Inter, system-ui, sans-serif; line-height:1.5;}
  img{max-width:100%;}
</style>
</head>
<body>
${body}
</body>
</html>`

  return new NextResponse(html, {
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Content-Disposition': `attachment; filename="${page.slug}.html"`,
    },
  })
}
