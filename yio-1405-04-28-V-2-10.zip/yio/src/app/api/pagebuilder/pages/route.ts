import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';

// GET: لیست صفحات page builder
export async function GET() {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    // استفاده از جدول Page موجود، با یک فیلد content برای JSON
    // چون جدول Page فعلی blocks دارد، یک جدول جداگانه می‌سازیم
    const pages = await db.$queryRaw`
      SELECT id, name, slug, content, status, createdAt, updatedAt
      FROM PageBuilderPage
      ORDER BY updatedAt DESC
    ` as any[];

    return NextResponse.json({ pages: pages || [] });
  } catch (error) {
    // اگر جدول وجود نداشت، لیست خالی برگردان
    return NextResponse.json({ pages: [] });
  }
}

// POST: ایجاد صفحه جدید
export async function POST(req: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const name = (body.name as string) || 'صفحه جدید';
    const slug = body.slug || name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'untitled';
    const content = JSON.stringify(body.content ?? []);

    // Ensure slug uniqueness
    const existing = await db.$queryRaw`SELECT id FROM PageBuilderPage WHERE slug = ${slug}` as any[];
    const finalSlug = existing && existing.length > 0 ? `${slug}-${Date.now().toString(36)}` : slug;

    const result = await db.$executeRaw`
      INSERT INTO PageBuilderPage (id, name, slug, content, status, createdAt, updatedAt)
      VALUES (${crypto.randomUUID()}, ${name}, ${finalSlug}, ${content}, 'draft', datetime('now'), datetime('now'))
    `;

    // برگرداندن صفحه ایجاد شده
    const pages = await db.$queryRaw`SELECT * FROM PageBuilderPage WHERE slug = ${finalSlug}` as any[];
    const page = pages[0];
    if (page) {
      page.content = JSON.parse(page.content || '[]');
    }

    return NextResponse.json({ page });
  } catch (error) {
    console.error('Create page error:', error);
    return NextResponse.json({ error: 'خطا در ایجاد صفحه' }, { status: 500 });
  }
}
