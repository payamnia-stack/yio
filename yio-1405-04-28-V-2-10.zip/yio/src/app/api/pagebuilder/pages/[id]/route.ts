import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';

// GET: دریافت یک صفحه با id
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const pages = await db.$queryRaw`SELECT * FROM PageBuilderPage WHERE id = ${id}` as any[];
    if (!pages || pages.length === 0) {
      return NextResponse.json({ error: 'یافت نشد' }, { status: 404 });
    }
    const page = pages[0];
    page.content = JSON.parse(page.content || '[]');
    return NextResponse.json({ page });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// PUT: به‌روزرسانی صفحه
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const body = await req.json().catch(() => ({}));

    const data: string[] = [];
    if (typeof body.name === 'string') data.push(`name = '${body.name.replace(/'/g, "''")}'`);
    if (typeof body.slug === 'string') data.push(`slug = '${body.slug.replace(/'/g, "''")}'`);
    if (Array.isArray(body.content)) data.push(`content = '${JSON.stringify(body.content).replace(/'/g, "''")}'`);
    if (typeof body.status === 'string') data.push(`status = '${body.status}'`);
    data.push(`updatedAt = datetime('now')`);

    if (data.length > 1) {
      await db.$executeRawUnsafe(`UPDATE PageBuilderPage SET ${data.join(', ')} WHERE id = ?`, id);
    }

    const pages = await db.$queryRawUnsafe(`SELECT * FROM PageBuilderPage WHERE id = ?`, id) as any[];
    const page = pages[0];
    if (page) {
      page.content = JSON.parse(page.content || '[]');
    }
    return NextResponse.json({ page });
  } catch (error) {
    console.error('Update page error:', error);
    return NextResponse.json({ error: 'خطا در به‌روزرسانی' }, { status: 500 });
  }
}

// DELETE: حذف صفحه
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    await db.$executeRawUnsafe(`DELETE FROM PageBuilderPage WHERE id = ?`, id);
    return NextResponse.json({ ok: true });
  } catch (error) {
    return NextResponse.json({ error: 'خطا در حذف' }, { status: 500 });
  }
}
