import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { enforceRateLimit, securityCheck, validateIranMobile } from '@/lib/security';

// POST: پیگیری سفارش (عمومی - بدون احراز هویت مدیر)
export async function POST(request: NextRequest) {
  try {
    const rateLimit = await enforceRateLimit(request, 'order-tracking', 10);
    if (!rateLimit.allowed) return rateLimit.response!;

    const body = await request.json();

    const secCheck = securityCheck(body);
    if (!secCheck.safe) {
      return NextResponse.json({ error: secCheck.reason }, { status: 400 });
    }

    const { orderNumber, phone } = body;

    if (!orderNumber || typeof orderNumber !== 'string') {
      return NextResponse.json({ error: 'شماره سفارش الزامی است' }, { status: 400 });
    }

    if (!phone || !validateIranMobile(phone)) {
      return NextResponse.json({ error: 'شماره موبایل نامعتبر است' }, { status: 400 });
    }

    const order = await db.order.findFirst({
      where: {
        orderNumber: orderNumber.trim().toUpperCase(),
        recipientPhone: phone,
      },
      include: {
        items: true,
      },
    });

    if (!order) {
      return NextResponse.json({ error: 'سفارشی با این اطلاعات یافت نشد' }, { status: 404 });
    }

    // اطلاعات محدود برای مشتری (بدون اطلاعات حساس)
    return NextResponse.json({
      order: {
        orderNumber: order.orderNumber,
        status: order.status,
        finalAmount: order.finalAmount,
        createdAt: order.createdAt,
        trackingCode: order.trackingCode,
        paymentStatus: order.paymentStatus,
        itemsCount: order.items.length,
        items: order.items.map(item => ({
          title: item.productTitle,
          image: item.productImage,
          quantity: item.quantity,
          price: item.price,
        })),
      },
    });
  } catch (error) {
    console.error('Error tracking order:', error);
    return NextResponse.json({ error: 'خطا در پیگیری سفارش' }, { status: 500 });
  }
}
