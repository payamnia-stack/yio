import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth'
import type { ElementNode } from '@/lib/page-builder/types'

function slugify(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '') || 'untitled'
}

// GET: لیست همه صفحات Page Builder
export async function GET() {
  try {
    const token = await getAdminToken()
    const isAuth = await verifyAdminSession(token)
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 })

    const pages = await db.pBPage.findMany({
      orderBy: { updatedAt: 'desc' },
      select: { id: true, name: true, slug: true, status: true, updatedAt: true },
    })
    return NextResponse.json({ pages })
  } catch (error) {
    console.error('PB pages GET error:', error)
    return NextResponse.json({ error: 'خطا' }, { status: 500 })
  }
}

// POST: ایجاد صفحه جدید
export async function POST(req: NextRequest) {
  try {
    const token = await getAdminToken()
    const isAuth = await verifyAdminSession(token)
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 })

    const body = await req.json().catch(() => ({}))
    const name = (body.name as string) || 'صفحه جدید'
    const slug = body.slug ? slugify(body.slug) : slugify(name) + '-' + Math.random().toString(36).slice(2, 6)
    const content: ElementNode[] = body.content ?? []

    // Ensure slug uniqueness
    const existing = await db.pBPage.findUnique({ where: { slug } })
    const finalSlug = existing ? `${slug}-${Date.now().toString(36)}` : slug

    const page = await db.pBPage.create({
      data: { name, slug: finalSlug, content: JSON.stringify(content) },
    })
    return NextResponse.json({ page: { ...page, content: JSON.parse(page.content) } })
  } catch (error) {
    console.error('PB pages POST error:', error)
    return NextResponse.json({ error: 'خطا در ایجاد صفحه' }, { status: 500 })
  }
}
