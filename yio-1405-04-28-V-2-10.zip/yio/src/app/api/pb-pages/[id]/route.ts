import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth'

// GET: دریافت یک صفحه با ID
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const token = await getAdminToken()
    const isAuth = await verifyAdminSession(token)
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 })

    const { id } = await params
    const page = await db.pBPage.findUnique({ where: { id } })
    if (!page) return NextResponse.json({ error: 'یافت نشد' }, { status: 404 })
    return NextResponse.json({
      page: { ...page, content: JSON.parse(page.content) },
    })
  } catch (error) {
    console.error('PB page GET error:', error)
    return NextResponse.json({ error: 'خطا' }, { status: 500 })
  }
}

// PUT: به‌روزرسانی صفحه
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const token = await getAdminToken()
    const isAuth = await verifyAdminSession(token)
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 })

    const { id } = await params
    const body = await req.json().catch(() => ({}))
    const data: Record<string, unknown> = {}
    if (typeof body.name === 'string') data.name = body.name
    if (typeof body.slug === 'string') data.slug = body.slug
    if (Array.isArray(body.content)) data.content = JSON.stringify(body.content)
    if (typeof body.status === 'string') data.status = body.status

    const page = await db.pBPage.update({ where: { id }, data })
    return NextResponse.json({
      page: { ...page, content: JSON.parse(page.content) },
    })
  } catch (error) {
    console.error('PB page PUT error:', error)
    return NextResponse.json({ error: 'خطا در به‌روزرسانی' }, { status: 500 })
  }
}

// DELETE: حذف صفحه
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const token = await getAdminToken()
    const isAuth = await verifyAdminSession(token)
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 })

    const { id } = await params
    await db.pBPage.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('PB page DELETE error:', error)
    return NextResponse.json({ error: 'خطا در حذف' }, { status: 500 })
  }
}
