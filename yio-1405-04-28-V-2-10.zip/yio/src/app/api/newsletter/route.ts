// API خبرنامه
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { enforceRateLimit, validateEmail, securityCheck } from '@/lib/security';

export async function POST(request: NextRequest) {
  try {
    const rateLimit = await enforceRateLimit(request, 'newsletter', 3);
    if (!rateLimit.allowed) return rateLimit.response!;

    const body = await request.json();
    const secCheck = securityCheck(body);
    if (!secCheck.safe) return NextResponse.json({ error: secCheck.reason }, { status: 400 });

    const email = body.email;
    if (!email || !validateEmail(email)) return NextResponse.json({ error: 'ایمیل نامعتبر' }, { status: 400 });

    const existing = await db.newsletter.findUnique({ where: { email } });
    if (existing) return NextResponse.json({ success: true, message: 'قبلا ثبت شده' });

    await db.newsletter.create({ data: { email } });
    return NextResponse.json({ success: true });
  } catch { return NextResponse.json({ error: 'خطا' }, { status: 500 }); }
}
