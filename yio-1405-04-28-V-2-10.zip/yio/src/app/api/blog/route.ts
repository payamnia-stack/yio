// API بلاگ عمومی
import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const slug = searchParams.get('slug');

    if (slug) {
      const post = await db.blogPost.findUnique({ where: { slug } });
      if (!post || !post.isPublished) return NextResponse.json({ error: 'یافت نشد' }, { status: 404 });
      await db.blogPost.update({ where: { id: post.id }, data: { views: { increment: 1 } } });
      return NextResponse.json({ post });
    }

    const posts = await db.blogPost.findMany({
      where: { isPublished: true },
      orderBy: { createdAt: 'desc' },
      select: { id: true, title: true, slug: true, excerpt: true, coverImage: true, category: true, createdAt: true, views: true },
    });

    return NextResponse.json({ posts });
  } catch { return NextResponse.json({ error: 'خطا' }, { status: 500 }); }
}
