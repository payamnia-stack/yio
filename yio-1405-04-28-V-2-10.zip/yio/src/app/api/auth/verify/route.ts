import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { createSession, getUserFromSession } from '@/lib/user-auth';
import { enforceRateLimit, validateString, securityCheck } from '@/lib/security';
import { cookies } from 'next/headers';

// POST: تایید کد OTP و ورود به حساب
// body: { code: "123456", identifier?: "09123456789" }
// اگر identifier ارسال شود، کاربر بر اساس آن پیدا می‌شود (برای ورود از صفحه auth)
// در غیر این صورت، از session فعلی استفاده می‌شود (برای تایید بعد از ثبت‌نام قدیمی)
export async function POST(request: NextRequest) {
  try {
    const rateLimit = await enforceRateLimit(request, 'verify-code', 10);
    if (!rateLimit.allowed) return rateLimit.response!;

    const body = await request.json();
    const secCheck = securityCheck(body);
    if (!secCheck.safe) return NextResponse.json({ error: secCheck.reason }, { status: 400 });

    const code = validateString(body.code, 6, 6);
    if (!code) {
      return NextResponse.json({ error: 'کد تایید نامعتبر' }, { status: 400 });
    }

    // پیدا کردن کاربر: اول با identifier، بعد با session
    let user = null;
    const identifier = (body.identifier || '').toString().trim().toLowerCase();

    if (identifier) {
      const isPhone = /^09\d{9}$/.test(identifier);
      const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(identifier);

      if (isPhone) {
        user = await db.user.findUnique({ where: { phone: identifier } });
      } else if (isEmail) {
        user = await db.user.findFirst({ where: { email: identifier } });
      }
    } else {
      // fallback به session فعلی
      const sessionUser = await getUserFromSession();
      if (sessionUser) user = sessionUser;
    }

    if (!user) {
      return NextResponse.json({ error: 'کاربر یافت نشد. دوباره درخواست کد بدهید.' }, { status: 404 });
    }

    if (!user.verifyCode || !user.verifyExpiry) {
      return NextResponse.json({ error: 'کد تایید صادر نشده است. دوباره درخواست کنید.' }, { status: 400 });
    }

    if (user.verifyExpiry < new Date()) {
      return NextResponse.json({ error: 'کد تایید منقضی شده است. دوباره درخواست کنید.' }, { status: 400 });
    }

    if (user.verifyCode !== code) {
      return NextResponse.json({ error: 'کد تایید اشتباه است' }, { status: 400 });
    }

    // تایید موفق — آپدیت کاربر
    await db.user.update({
      where: { id: user.id },
      data: {
        isVerified: true,
        verifyCode: null,
        verifyExpiry: null,
      },
    });

    // پردازش کد ارجاع (referral) — فقط برای کاربران جدید
    const refCode = body.referralCode;
    if (refCode && !user.referredById) {
      const referrer = await db.user.findUnique({
        where: { referralCode: refCode },
        select: { id: true },
      });
      if (referrer && referrer.id !== user.id) {
        // ثبت ارجاع
        await db.user.update({
          where: { id: user.id },
          data: { referredById: referrer.id },
        });
        // پاداش ارجاع
        const { processReferralBonus } = await import('@/lib/wallet');
        await processReferralBonus(referrer.id, user.id);
      }
    }

    // ایجاد سشن (اگر قبلاً سشن نداشت)
    const existingSession = await getUserFromSession();
    if (!existingSession || existingSession.id !== user.id) {
      const token = await createSession(user.id, request);
      const cookieStore = await cookies();
      cookieStore.set('yio-user-token', token, {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'lax',
        path: '/',
        maxAge: 30 * 24 * 60 * 60,
      });
    }

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        phone: user.phone,
        email: user.email,
        name: user.name,
        avatar: user.avatar,
        isVerified: true,
      },
      isNewUser: !user.name, // اگر نام نداشت، یعنی جدید است
    });
  } catch (error) {
    console.error('Verify error:', error);
    return NextResponse.json({ error: 'خطا در تایید' }, { status: 500 });
  }
}
