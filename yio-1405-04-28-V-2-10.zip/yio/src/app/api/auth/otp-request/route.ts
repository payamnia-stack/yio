import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { generateVerifyCode } from '@/lib/user-auth';
import { enforceRateLimit, securityCheck, validateIranMobile } from '@/lib/security';
import { sendOtpSms, sendOtpEmail } from '@/lib/messaging';

// POST: درخواست کد تایید (تشخیص خودکار موبایل یا ایمیل)
// body: { identifier: "09123456789" | "user@example.com" }
export async function POST(request: NextRequest) {
  try {
    const rateLimit = await enforceRateLimit(request, 'otp-request', 5);
    if (!rateLimit.allowed) return rateLimit.response!;

    const body = await request.json();
    const secCheck = securityCheck(body);
    if (!secCheck.safe) return NextResponse.json({ error: secCheck.reason }, { status: 400 });

    const identifier = (body.identifier || '').toString().trim().toLowerCase();
    if (!identifier) {
      return NextResponse.json({ error: 'شماره موبایل یا ایمیل را وارد کنید' }, { status: 400 });
    }

    // تشخیص خودکار نوع: موبایل یا ایمیل
    const isPhone = /^09\d{9}$/.test(identifier);
    const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(identifier);

    if (!isPhone && !isEmail) {
      return NextResponse.json({
        error: 'فرمت نامعتبر است. شماره موبایل (09XXXXXXXXX) یا ایمیل معتبر وارد کنید',
      }, { status: 400 });
    }

    // تولید کد تایید
    const verifyCode = generateVerifyCode();
    const verifyExpiry = new Date(Date.now() + 10 * 60 * 1000); // ۱۰ دقیقه

    // پیدا کردن کاربر موجود (با phone یا email)
    let user;
    if (isPhone) {
      user = await db.user.findUnique({ where: { phone: identifier } });
    } else {
      user = await db.user.findFirst({ where: { email: identifier } });
    }

    if (user) {
      // کاربر موجود — آپدیت کد تایید
      await db.user.update({
        where: { id: user.id },
        data: { verifyCode, verifyExpiry },
      });
    } else {
      // کاربر جدید — ساخت رکورد با OTP (بدون password)
      const phoneForCreate = isPhone
        ? identifier
        : `nomail_${Date.now()}_${Math.floor(Math.random() * 10000)}`;

      user = await db.user.create({
        data: {
          phone: phoneForCreate,
          email: isEmail ? identifier : null,
          password: null, // کاربران OTP-only پسورد ندارند
          verifyCode,
          verifyExpiry,
          isVerified: false,
        },
      });
    }

    // ارسال کد تایید
    const exposeVerifyCode = process.env.EXPOSE_VERIFY_CODE === 'true';
    let sendResult: { success: boolean; error?: string } = { success: true };

    if (!exposeVerifyCode) {
      if (isPhone) {
        sendResult = await sendOtpSms(identifier, verifyCode, user.name || undefined);
      } else {
        sendResult = await sendOtpEmail(identifier, verifyCode, user.name || undefined);
      }
    }

    if (!sendResult.success) {
      console.warn('خطا در ارسال کد تایید:', sendResult.error);
    }

    return NextResponse.json({
      success: true,
      method: isPhone ? 'phone' : 'email',
      maskedIdentifier: isPhone
        ? identifier.slice(0, 4) + '***' + identifier.slice(-3)
        : identifier.slice(0, 2) + '***@' + identifier.split('@')[1],
      verifyCode: exposeVerifyCode ? verifyCode : undefined,
      message: exposeVerifyCode
        ? `کد تایید: ${verifyCode} (در محیط واقعی به ${isPhone ? 'موبایل' : 'ایمیل'} ارسال می‌شود)`
        : `کد تایید به ${isPhone ? 'موبایل' : 'ایمیل'} ارسال شد`,
      isNewUser: !user.isVerified,
    });
  } catch (error: any) {
    console.error('OTP request error:', error);
    return NextResponse.json(
      { error: error.message || 'خطا در ارسال کد تایید' },
      { status: 500 }
    );
  }
}
