import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { createSession } from '@/lib/user-auth';
import { cookies } from 'next/headers';

// POST: ورود/ثبت‌نام با Google OAuth
// body: { googleId, email, name, avatar }
// در محیط واقعی، کلاینت Google ID Token را از Google دریافت می‌کند
// و اینجا ما آن را verify و کاربر را پیدا/ساخت می‌کنیم
// برای سادگی، اینجا مستقیماً googleId, email, name را می‌پذیریم
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { googleId, email, name, avatar } = body;

    if (!googleId || !email) {
      return NextResponse.json({ error: 'اطلاعات گوگل ناقص است' }, { status: 400 });
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: 'ایمیل نامعتبر' }, { status: 400 });
    }

    // 1. جستجوی کاربر با googleId
    let user = await db.user.findFirst({ where: { googleId } });

    // 2. اگر پیدا نشد، جستجو با email
    if (!user) {
      user = await db.user.findFirst({ where: { email } });
    }

    // 3. اگر هنوز کاربری نیست، کاربر جدید بساز
    if (!user) {
      // ساخت phone موقت (چون فیلد unique است)
      const tempPhone = `google_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
      user = await db.user.create({
        data: {
          phone: tempPhone,
          email,
          name: name || 'کاربر گوگل',
          avatar: avatar || null,
          googleId,
          password: null, // کاربران گوگل رمز عبور ندارند
          isVerified: true, // ایمیلشان از گوگل تأیید شده
        },
      });
    } else {
      // اگر کاربر وجود داشت ولی googleId نداشت، اضافه کن
      if (!user.googleId) {
        user = await db.user.update({
          where: { id: user.id },
          data: {
            googleId,
            avatar: avatar || user.avatar,
            isVerified: true,
          },
        });
      }
    }

    // ایجاد سشن
    const token = await createSession(user.id, request);
    const cookieStore = await cookies();
    cookieStore.set('yio-user-token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: 30 * 24 * 60 * 60,
    });

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        avatar: user.avatar,
        isVerified: user.isVerified,
      },
    });
  } catch (error: any) {
    console.error('Google login error:', error);
    return NextResponse.json({ error: 'خطا در ورود با گوگل' }, { status: 500 });
  }
}
