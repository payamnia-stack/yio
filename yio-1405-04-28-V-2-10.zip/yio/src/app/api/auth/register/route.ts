import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { hashPassword, createSession, generateVerifyCode } from '@/lib/user-auth';
import { enforceRateLimit, securityCheck, validateIranMobile, validateString } from '@/lib/security';
import { sendOtpSms, sendOtpEmail } from '@/lib/messaging';
import { cookies } from 'next/headers';

// POST: ثبت‌نام با موبایل یا ایمیل + رمز عبور
export async function POST(request: NextRequest) {
  try {
    const rateLimit = await enforceRateLimit(request, 'register', 5);
    if (!rateLimit.allowed) return rateLimit.response!;

    const body = await request.json();
    const secCheck = securityCheck(body);
    if (!secCheck.safe) return NextResponse.json({ error: secCheck.reason }, { status: 400 });

    const phone = body.phone ? validateString(body.phone, 11, 11) : null;
    const email = body.email ? validateString(String(body.email).toLowerCase(), 5, 200) : null;
    const password = validateString(body.password, 6, 100);
    const name = body.name ? validateString(body.name, 2, 100) : null;

    if (!password) {
      return NextResponse.json({ error: 'رمز عبور الزامی است' }, { status: 400 });
    }

    if (!phone && !email) {
      return NextResponse.json({ error: 'شماره موبایل یا ایمیل الزامی است' }, { status: 400 });
    }

    if (phone && !validateIranMobile(phone)) {
      return NextResponse.json({ error: 'شماره موبایل نامعتبر است (مثال: 09121234567)' }, { status: 400 });
    }

    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: 'ایمیل نامعتبر است' }, { status: 400 });
    }

    if (password.length < 6) {
      return NextResponse.json({ error: 'رمز عبور باید حداقل ۶ کاراکتر باشد' }, { status: 400 });
    }

    // بررسی تکراری نبودن
    if (phone) {
      const existingByPhone = await db.user.findUnique({ where: { phone } });
      if (existingByPhone) {
        return NextResponse.json({ error: 'این شماره موبایل قبلا ثبت شده است. وارد شوید.' }, { status: 400 });
      }
    }
    if (email) {
      const existingByEmail = await db.user.findFirst({ where: { email } });
      if (existingByEmail) {
        return NextResponse.json({ error: 'این ایمیل قبلا ثبت شده است. وارد شوید.' }, { status: 400 });
      }
    }

    // ساخت کد تایید
    const verifyCode = generateVerifyCode();
    const verifyExpiry = new Date(Date.now() + 10 * 60 * 1000); // ۱۰ دقیقه

    // ساخت کاربر — phone یا email می‌تواند null باشد
    // برای unique constraint، اگر phone نباشد یک مقدار یکتا می‌سازیم
    const userPhone = phone || `nomail_${Date.now()}_${Math.floor(Math.random() * 10000)}`;

    const user = await db.user.create({
      data: {
        phone: userPhone,
        email: email || null,
        name,
        password: hashPassword(password),
        verifyCode,
        verifyExpiry,
      },
    });

    // ارسال کد تایید
    const exposeVerifyCode = process.env.EXPOSE_VERIFY_CODE === 'true';
    let sendResult: { success: boolean; error?: string } = { success: true };

    if (phone && !exposeVerifyCode) {
      sendResult = await sendOtpSms(phone, verifyCode, name || undefined);
    } else if (email && !exposeVerifyCode) {
      sendResult = await sendOtpEmail(email, verifyCode, name || undefined);
    }

    if (!sendResult.success) {
      console.warn('خطا در ارسال کد تایید:', sendResult.error);
      // کاربر ساخته شده ولی کد ارسال نشد — در محیط توسعه کد نمایش داده می‌شود
    }

    // ایجاد سشن
    const token = await createSession(user.id);

    const cookieStore = await cookies();
    cookieStore.set('yio-user-token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: 30 * 24 * 60 * 60,
    });

    return NextResponse.json({
      success: true,
      user: { id: user.id, phone: user.phone, email: user.email, name: user.name },
      verifyCode: exposeVerifyCode ? verifyCode : undefined,
      message: exposeVerifyCode
        ? `کد تایید: ${verifyCode} (در محیط واقعی به ${phone ? 'موبایل' : 'ایمیل'} ارسال می‌شود)`
        : `کد تایید به ${phone ? 'موبایل' : 'ایمیل'} ارسال شد`,
    });
  } catch (error: any) {
    console.error('Register error:', error);

    let errorMsg = 'خطا در ثبت‌نام';
    if (error?.code === 'P2021') {
      errorMsg = 'جدول کاربران در دیتابیس وجود ندارد. لطفاً دستور npx prisma db push را اجرا کنید';
    } else if (error?.code === 'P2002') {
      errorMsg = 'این شماره موبایل یا ایمیل قبلا ثبت شده است';
    } else if (error?.message?.includes('no such table')) {
      errorMsg = 'دیتابیس تنظیم نشده. دستور npx prisma db push را اجرا کنید';
    }

    return NextResponse.json({ error: errorMsg }, { status: 500 });
  }
}
