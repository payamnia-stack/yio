import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getUserToken } from '@/lib/user-auth';
import { cookies } from 'next/headers';

// POST: خروج
export async function POST() {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('yio-user-token')?.value;

    if (token) {
      await db.session.deleteMany({ where: { token } }).catch(() => {});
    }

    cookieStore.delete('yio-user-token');

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Logout error:', error);
    return NextResponse.json({ error: 'خطا در خروج' }, { status: 500 });
  }
}
