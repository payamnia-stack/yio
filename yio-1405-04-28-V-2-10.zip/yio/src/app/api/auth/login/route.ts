import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyPassword, createSession } from '@/lib/user-auth';
import { enforceRateLimit, securityCheck, validateIranMobile, validateString } from '@/lib/security';
import { cookies } from 'next/headers';

// POST: ورود با موبایل یا ایمیل + رمز عبور
export async function POST(request: NextRequest) {
  try {
    const rateLimit = await enforceRateLimit(request, 'login-user', 5);
    if (!rateLimit.allowed) return rateLimit.response!;

    const body = await request.json();
    const secCheck = securityCheck(body);
    if (!secCheck.safe) return NextResponse.json({ error: secCheck.reason }, { status: 400 });

    const phone = body.phone ? validateString(body.phone, 11, 11) : null;
    const email = body.email ? validateString(String(body.email).toLowerCase(), 5, 200) : null;
    const password = validateString(body.password, 1, 100);

    if (!password) {
      return NextResponse.json({ error: 'رمز عبور الزامی است' }, { status: 400 });
    }

    if (!phone && !email) {
      return NextResponse.json({ error: 'شماره موبایل یا ایمیل الزامی است' }, { status: 400 });
    }

    if (phone && !validateIranMobile(phone)) {
      return NextResponse.json({ error: 'شماره موبایل نامعتبر است' }, { status: 400 });
    }

    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: 'ایمیل نامعتبر است' }, { status: 400 });
    }

    // پیدا کردن کاربر با phone یا email
    let user;
    if (phone) {
      user = await db.user.findUnique({ where: { phone } });
    } else if (email) {
      user = await db.user.findFirst({ where: { email } });
    }

    if (!user || !verifyPassword(password, user.password)) {
      await new Promise(r => setTimeout(r, 1000)); // ضد timing attack
      return NextResponse.json({ error: 'موبایل/ایمیل یا رمز عبور اشتباه است' }, { status: 401 });
    }

    const token = await createSession(user.id);

    const cookieStore = await cookies();
    cookieStore.set('yio-user-token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: 30 * 24 * 60 * 60,
    });

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        phone: user.phone,
        email: user.email,
        name: user.name,
        isVerified: user.isVerified,
      },
    });
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json({ error: 'خطا در ورود' }, { status: 500 });
  }
}
