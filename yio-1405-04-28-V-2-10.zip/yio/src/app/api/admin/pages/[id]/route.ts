import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput } from '@/lib/security';

// GET: دریافت یک صفحه با بلوک‌های آن
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const pageId = parseInt(id);
    if (isNaN(pageId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    const page = await db.page.findUnique({
      where: { id: pageId },
      include: { blocks: { orderBy: { order: 'asc' } } },
    });

    if (!page) return NextResponse.json({ error: 'صفحه یافت نشد' }, { status: 404 });

    return NextResponse.json({ page });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// PUT: ویرایش صفحه یا مدیریت بلوک‌ها
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const pageId = parseInt(id);
    if (isNaN(pageId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    const body = await request.json();

    // اگر action اضافه شده برای بلوک‌ها
    if (body.action === 'addBlock') {
      const block = await db.block.create({
        data: {
          pageId,
          type: body.blockType || 'text',
          title: body.title ? sanitizeInput(body.title).slice(0, 200) : null,
          content: body.content ? JSON.stringify(body.content) : null,
          order: body.order || 0,
          isActive: true,
        },
      });
      return NextResponse.json({ block, success: true });
    }

    if (body.action === 'updateBlock') {
      const blockId = parseInt(body.blockId);
      if (isNaN(blockId)) return NextResponse.json({ error: 'شناسه بلوک نامعتبر' }, { status: 400 });

      const updateData: any = {};
      if (body.title !== undefined) updateData.title = body.title ? sanitizeInput(body.title).slice(0, 200) : null;
      if (body.content !== undefined) updateData.content = body.content ? JSON.stringify(body.content) : null;
      if (body.order !== undefined) updateData.order = parseInt(body.order) || 0;
      if (body.isActive !== undefined) updateData.isActive = Boolean(body.isActive);

      const block = await db.block.update({ where: { id: blockId }, data: updateData });
      return NextResponse.json({ block, success: true });
    }

    if (body.action === 'deleteBlock') {
      const blockId = parseInt(body.blockId);
      if (isNaN(blockId)) return NextResponse.json({ error: 'شناسه بلوک نامعتبر' }, { status: 400 });

      await db.block.delete({ where: { id: blockId } });
      return NextResponse.json({ success: true });
    }

    if (body.action === 'reorderBlocks') {
      const orders: any[] = body.orders || [];
      for (const item of orders) {
        await db.block.update({
          where: { id: parseInt(item.id) },
          data: { order: item.order },
        });
      }
      return NextResponse.json({ success: true });
    }

    // ویرایش خود صفحه
    const updateData: any = {};
    if (body.title !== undefined) updateData.title = sanitizeInput(body.title).slice(0, 200);
    if (body.slug !== undefined) {
      const slug = body.slug.trim().replace(/\s+/g, '-').replace(/[^\w\u0600-\u06FF\-]/g, '').toLowerCase();
      updateData.slug = slug;
    }
    if (body.description !== undefined) updateData.description = body.description ? sanitizeInput(body.description).slice(0, 500) : null;
    if (body.isPublished !== undefined) updateData.isPublished = Boolean(body.isPublished);
    if (body.showInMenu !== undefined) updateData.showInMenu = Boolean(body.showInMenu);
    if (body.menuLabel !== undefined) updateData.menuLabel = body.menuLabel ? sanitizeInput(body.menuLabel).slice(0, 50) : null;
    if (body.order !== undefined) updateData.order = parseInt(body.order) || 0;

    const page = await db.page.update({ where: { id: pageId }, data: updateData });
    return NextResponse.json({ page, success: true });
  } catch (error) {
    console.error('Page update error:', error);
    return NextResponse.json({ error: 'خطا در ویرایش' }, { status: 500 });
  }
}

// DELETE: حذف صفحه
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const pageId = parseInt(id);
    if (isNaN(pageId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    const page = await db.page.findUnique({ where: { id: pageId } });
    if (!page) return NextResponse.json({ error: 'یافت نشد' }, { status: 404 });
    if (page.type === 'home') return NextResponse.json({ error: 'صفحه اصلی قابل حذف نیست' }, { status: 400 });

    await db.page.delete({ where: { id: pageId } });
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'خطا در حذف' }, { status: 500 });
  }
}
