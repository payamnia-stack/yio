import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput, securityCheck } from '@/lib/security';

// GET: لیست همه صفحات
export async function GET() {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const pages = await db.page.findMany({
      include: { _count: { select: { blocks: true } } },
      orderBy: [{ type: 'asc' }, { createdAt: 'desc' }],
    });

    return NextResponse.json({ pages });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// POST: ایجاد صفحه جدید
export async function POST(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const body = await request.json();
    const secCheck = securityCheck(body);
    if (!secCheck.safe) return NextResponse.json({ error: secCheck.reason }, { status: 400 });

    if (!body.title || body.title.trim().length < 3) {
      return NextResponse.json({ error: 'عنوان صفحه باید حداقل ۳ کاراکتر باشد' }, { status: 400 });
    }

    const slug = (body.slug || body.title).trim()
      .replace(/\s+/g, '-')
      .replace(/[^\w\u0600-\u06FF\-]/g, '')
      .toLowerCase();

    if (slug.length < 2) {
      return NextResponse.json({ error: 'آدرس صفحه نامعتبر است' }, { status: 400 });
    }

    const existing = await db.page.findUnique({ where: { slug } });
    if (existing) {
      return NextResponse.json({ error: 'این آدرس صفحه قبلا استفاده شده' }, { status: 400 });
    }

    const page = await db.page.create({
      data: {
        slug,
        title: sanitizeInput(body.title).slice(0, 200),
        description: body.description ? sanitizeInput(body.description).slice(0, 500) : null,
        type: body.type || 'custom',
        isPublished: Boolean(body.isPublished ?? true),
        showInMenu: Boolean(body.showInMenu ?? false),
        menuLabel: body.menuLabel ? sanitizeInput(body.menuLabel).slice(0, 50) : null,
        order: parseInt(body.order) || 0,
      },
    });

    return NextResponse.json({ page, success: true });
  } catch (error) {
    console.error('Create page error:', error);
    return NextResponse.json({ error: 'خطا در ایجاد صفحه' }, { status: 500 });
  }
}
