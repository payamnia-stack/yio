import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';

// GET: دریافت لیست ایمیل‌های ورودی
export async function GET(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category') || 'all';
    const search = searchParams.get('search') || '';
    const onlyUnread = searchParams.get('unread') === 'true';

    const where: any = {};
    if (category !== 'all') where.category = category;
    if (onlyUnread) where.isRead = false;
    if (search) {
      where.OR = [
        { subject: { contains: search } },
        { fromEmail: { contains: search } },
        { fromName: { contains: search } },
        { body: { contains: search } },
      ];
    }

    const [emails, total, unreadCount] = await Promise.all([
      db.incomingEmail.findMany({
        where,
        orderBy: { receivedAt: 'desc' },
        take: 100,
      }),
      db.incomingEmail.count({ where }),
      db.incomingEmail.count({ where: { isRead: false } }),
    ]);

    return NextResponse.json({
      emails,
      total,
      unreadCount,
    });
  } catch (error) {
    console.error('Error fetching emails:', error);
    return NextResponse.json({ error: 'خطا در دریافت ایمیل‌ها' }, { status: 500 });
  }
}

// POST: ثبت ایمیل جدید (برای تست یا دریافت از webhook)
export async function POST(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const body = await request.json();
    const { fromEmail, fromName, toEmail, subject, body: emailBody, category } = body;

    if (!fromEmail || !subject) {
      return NextResponse.json({ error: 'fromEmail و subject الزامی است' }, { status: 400 });
    }

    const email = await db.incomingEmail.create({
      data: {
        fromEmail,
        fromName: fromName || null,
        toEmail: toEmail || 'inbox@yio-shop.ir',
        subject,
        body: emailBody || null,
        category: category || 'inbox',
      },
    });

    return NextResponse.json({ success: true, email });
  } catch (error) {
    console.error('Error creating email:', error);
    return NextResponse.json({ error: 'خطا در ثبت ایمیل' }, { status: 500 });
  }
}
