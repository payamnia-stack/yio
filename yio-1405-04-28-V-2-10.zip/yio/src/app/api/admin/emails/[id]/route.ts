import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';

// PATCH: آپدیت وضعیت ایمیل (خوانده شده / ستاره / دسته‌بندی)
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const emailId = parseInt(id);
    if (isNaN(emailId)) {
      return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });
    }

    const body = await request.json();
    const updateData: any = {};

    if (body.isRead !== undefined) updateData.isRead = Boolean(body.isRead);
    if (body.isStarred !== undefined) updateData.isStarred = Boolean(body.isStarred);
    if (body.category !== undefined) updateData.category = body.category;

    const email = await db.incomingEmail.update({
      where: { id: emailId },
      data: updateData,
    });

    return NextResponse.json({ success: true, email });
  } catch (error) {
    console.error('Error updating email:', error);
    return NextResponse.json({ error: 'خطا در بروزرسانی ایمیل' }, { status: 500 });
  }
}

// DELETE: حذف ایمیل
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const emailId = parseInt(id);
    if (isNaN(emailId)) {
      return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });
    }

    await db.incomingEmail.delete({ where: { id: emailId } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting email:', error);
    return NextResponse.json({ error: 'خطا در حذف ایمیل' }, { status: 500 });
  }
}
