import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput } from '@/lib/security';

// PUT: تغییر وضعیت درخواست عمده
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const orderId = parseInt(id);
    if (isNaN(orderId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    const body = await request.json();
    const validStatuses = ['pending', 'contacted', 'approved', 'rejected'];
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json({ error: 'وضعیت نامعتبر' }, { status: 400 });
    }

    const updateData: any = {};
    if (body.status) updateData.status = body.status;
    if (body.notes !== undefined) updateData.notes = body.notes ? sanitizeInput(body.notes).slice(0, 500) : null;

    const order = await db.wholesaleOrder.update({
      where: { id: orderId },
      data: updateData,
    });

    return NextResponse.json({ order, success: true });
  } catch (error) {
    console.error('Error updating wholesale order:', error);
    return NextResponse.json({ error: 'خطا در ویرایش' }, { status: 500 });
  }
}

// DELETE: حذف درخواست
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const orderId = parseInt(id);
    if (isNaN(orderId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    await db.wholesaleOrder.delete({ where: { id: orderId } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting wholesale order:', error);
    return NextResponse.json({ error: 'خطا در حذف' }, { status: 500 });
  }
}
