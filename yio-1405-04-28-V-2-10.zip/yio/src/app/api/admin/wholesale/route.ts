import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';

// GET: لیست درخواست‌های سفارش عمده
export async function GET(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = 20;

    const where: any = {};
    if (status) where.status = status;

    const [total, orders] = await Promise.all([
      db.wholesaleOrder.count({ where }),
      db.wholesaleOrder.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
    ]);

    const stats = {
      total: await db.wholesaleOrder.count(),
      pending: await db.wholesaleOrder.count({ where: { status: 'pending' } }),
      contacted: await db.wholesaleOrder.count({ where: { status: 'contacted' } }),
      approved: await db.wholesaleOrder.count({ where: { status: 'approved' } }),
    };

    return NextResponse.json({
      orders,
      pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
      stats,
    });
  } catch (error) {
    console.error('Error fetching wholesale orders:', error);
    return NextResponse.json({ error: 'خطا در دریافت' }, { status: 500 });
  }
}
