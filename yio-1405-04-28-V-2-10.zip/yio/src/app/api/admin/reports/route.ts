// API گزارش فروش پیشرفته
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';

export async function GET(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const days = parseInt(searchParams.get('days') || '30');
    const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

    // آمار کلی
    const [totalRevenue, totalOrders, totalProducts, totalUsers] = await Promise.all([
      db.order.aggregate({ _sum: { finalAmount: true }, where: { paymentStatus: 'paid', createdAt: { gte: startDate } } }),
      db.order.count({ where: { createdAt: { gte: startDate } } }),
      db.product.count(),
      db.user.count({ where: { createdAt: { gte: startDate } } }),
    ]);

    // فروش روزانه
    const orders = await db.order.findMany({
      where: { createdAt: { gte: startDate }, paymentStatus: 'paid' },
      select: { finalAmount: true, createdAt: true, status: true },
      orderBy: { createdAt: 'asc' },
    });

    const dailySales: Record<string, { revenue: number; count: number }> = {};
    orders.forEach(o => {
      const date = new Intl.DateTimeFormat('fa-IR', { month: 'short', day: 'numeric' }).format(o.createdAt);
      if (!dailySales[date]) dailySales[date] = { revenue: 0, count: 0 };
      dailySales[date].revenue += o.finalAmount;
      dailySales[date].count++;
    });

    // پرفروش‌ترین محصولات
    const topProducts = await db.orderItem.groupBy({
      by: ['productId', 'productTitle', 'productImage'],
      _sum: { quantity: true },
      _count: true,
      orderBy: { _sum: { quantity: 'desc' } },
      take: 10,
    });

    // وضعیت سفارش‌ها
    const statusCounts = await db.order.groupBy({
      by: ['status'],
      _count: true,
    });

    // دسته‌بندی‌های پرفروش
    const categorySales = await db.orderItem.groupBy({
      by: ['productId'],
      _sum: { quantity: true },
    });

    return NextResponse.json({
      summary: {
        totalRevenue: totalRevenue._sum.finalAmount || 0,
        totalOrders,
        totalProducts,
        totalUsers,
        avgOrderValue: totalOrders > 0 ? Math.round((totalRevenue._sum.finalAmount || 0) / totalOrders) : 0,
      },
      dailySales: Object.entries(dailySales).map(([date, data]) => ({ date, ...data })),
      topProducts: topProducts.map(p => ({
        title: p.productTitle,
        image: p.productImage,
        quantity: p._sum.quantity,
        orders: p._count,
      })),
      statusCounts: statusCounts.map(s => ({ status: s.status, count: s._count })),
    });
  } catch (error) {
    console.error('Reports error:', error);
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
