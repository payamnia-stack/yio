import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput } from '@/lib/security';

// GET: لیست کامل FAQها (برای مدیریت)
export async function GET(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const faqs = await db.fAQ.findMany({
      orderBy: [{ order: 'asc' }, { createdAt: 'desc' }],
    });

    return NextResponse.json({ faqs });
  } catch (error) {
    console.error('Error fetching FAQs:', error);
    return NextResponse.json({ error: 'خطا در دریافت' }, { status: 500 });
  }
}

// PUT: ویرایش FAQ
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const faqId = parseInt(id);
    if (isNaN(faqId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    const body = await request.json();

    const updateData: any = {};
    if (body.question !== undefined) updateData.question = sanitizeInput(body.question).slice(0, 500);
    if (body.answer !== undefined) updateData.answer = sanitizeInput(body.answer).slice(0, 2000);
    if (body.category !== undefined) {
      const validCategories = ['general', 'products', 'shipping', 'payment', 'returns'];
      updateData.category = validCategories.includes(body.category) ? body.category : 'general';
    }
    if (body.order !== undefined) updateData.order = parseInt(body.order) || 0;
    if (body.isActive !== undefined) updateData.isActive = Boolean(body.isActive);

    const faq = await db.fAQ.update({
      where: { id: faqId },
      data: updateData,
    });

    return NextResponse.json({ faq, success: true });
  } catch (error) {
    console.error('Error updating FAQ:', error);
    return NextResponse.json({ error: 'خطا در ویرایش' }, { status: 500 });
  }
}

// DELETE: حذف FAQ
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const faqId = parseInt(id);
    if (isNaN(faqId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    await db.fAQ.delete({ where: { id: faqId } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting FAQ:', error);
    return NextResponse.json({ error: 'خطا در حذف' }, { status: 500 });
  }
}
