import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput, securityCheck } from '@/lib/security';

// GET: لیست کامل FAQها (برای مدیریت - شامل غیرفعال‌ها)
export async function GET(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const faqs = await db.fAQ.findMany({
      orderBy: [{ order: 'asc' }, { createdAt: 'desc' }],
    });

    return NextResponse.json({ faqs });
  } catch (error) {
    console.error('Error fetching FAQs:', error);
    return NextResponse.json({ error: 'خطا در دریافت' }, { status: 500 });
  }
}

// POST: ایجاد FAQ جدید
export async function POST(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const body = await request.json();
    const secCheck = securityCheck(body);
    if (!secCheck.safe) return NextResponse.json({ error: secCheck.reason }, { status: 400 });

    if (!body.question || body.question.trim().length < 5) {
      return NextResponse.json({ error: 'سؤال باید حداقل ۵ کاراکتر باشد' }, { status: 400 });
    }
    if (!body.answer || body.answer.trim().length < 10) {
      return NextResponse.json({ error: 'پاسخ باید حداقل ۱۰ کاراکتر باشد' }, { status: 400 });
    }

    const validCategories = ['general', 'products', 'shipping', 'payment', 'returns'];
    const category = validCategories.includes(body.category) ? body.category : 'general';

    const faq = await db.fAQ.create({
      data: {
        question: sanitizeInput(body.question).slice(0, 500),
        answer: sanitizeInput(body.answer).slice(0, 2000),
        category,
        order: parseInt(body.order) || 0,
        isActive: Boolean(body.isActive ?? true),
      },
    });

    return NextResponse.json({ faq, success: true });
  } catch (error) {
    console.error('Error creating FAQ:', error);
    return NextResponse.json({ error: 'خطا در ایجاد' }, { status: 500 });
  }
}
