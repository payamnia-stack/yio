import { NextRequest, NextResponse } from 'next/server';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sendSms } from '@/lib/messaging';

// POST: ارسال پیامک تست
export async function POST(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { phone } = await request.json();
    if (!phone || !/^09\d{9}$/.test(phone)) {
      return NextResponse.json({ error: 'شماره موبایل نامعتبر' }, { status: 400 });
    }

    const result = await sendSms(phone, 'پیامک تست از فروشگاه YIO ✅');

    if (result.success) {
      return NextResponse.json({
        success: true,
        message: 'پیامک ارسال شد',
        note: result.error,
      });
    } else {
      return NextResponse.json({
        success: false,
        error: result.error || 'خطا در ارسال پیامک',
      }, { status: 400 });
    }
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'خطا' }, { status: 500 });
  }
}
