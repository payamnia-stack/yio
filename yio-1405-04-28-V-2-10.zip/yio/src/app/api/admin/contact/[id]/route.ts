import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput } from '@/lib/security';

// PUT: تغییر وضعیت / پاسخ به پیام
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const msgId = parseInt(id);
    if (isNaN(msgId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    const body = await request.json();
    const validStatuses = ['new', 'read', 'replied', 'closed'];
    if (body.status && !validStatuses.includes(body.status)) {
      return NextResponse.json({ error: 'وضعیت نامعتبر' }, { status: 400 });
    }

    const updateData: any = {};
    if (body.status) updateData.status = body.status;
    if (body.reply !== undefined) updateData.reply = body.reply ? sanitizeInput(body.reply).slice(0, 1000) : null;

    const msg = await db.contactMessage.update({
      where: { id: msgId },
      data: updateData,
    });

    return NextResponse.json({ message: msg, success: true });
  } catch (error) {
    console.error('Error updating contact message:', error);
    return NextResponse.json({ error: 'خطا در ویرایش' }, { status: 500 });
  }
}

// DELETE: حذف پیام
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const msgId = parseInt(id);
    if (isNaN(msgId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    await db.contactMessage.delete({ where: { id: msgId } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting contact message:', error);
    return NextResponse.json({ error: 'خطا در حذف' }, { status: 500 });
  }
}
