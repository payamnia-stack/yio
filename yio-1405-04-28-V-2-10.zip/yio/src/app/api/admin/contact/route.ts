import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';

// GET: لیست پیام‌های تماس
export async function GET(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = 20;

    const where: any = {};
    if (status) where.status = status;

    const [total, messages] = await Promise.all([
      db.contactMessage.count({ where }),
      db.contactMessage.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
    ]);

    const stats = {
      total: await db.contactMessage.count(),
      new: await db.contactMessage.count({ where: { status: 'new' } }),
      read: await db.contactMessage.count({ where: { status: 'read' } }),
      replied: await db.contactMessage.count({ where: { status: 'replied' } }),
    };

    return NextResponse.json({
      messages,
      pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
      stats,
    });
  } catch (error) {
    console.error('Error fetching contact messages:', error);
    return NextResponse.json({ error: 'خطا در دریافت' }, { status: 500 });
  }
}
