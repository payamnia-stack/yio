import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { verifyPassword, createAdminSession } from '@/lib/admin-auth';
import { enforceRateLimit, securityCheck, validateString } from '@/lib/security';

// ورود به پنل مدیریت
export async function POST(request: NextRequest) {
  try {
    // Rate limit - فقط ۵ تلاش در دقیقه برای ورود
    const rateLimit = await enforceRateLimit(request, 'admin-login', 5);
    if (!rateLimit.allowed) {
      return rateLimit.response!;
    }

    const body = await request.json();

    // بررسی امنیتی ورودی
    const secCheck = securityCheck(body);
    if (!secCheck.safe) {
      return NextResponse.json(
        { error: secCheck.reason },
        { status: 400 }
      );
    }

    const { password } = body;

    // اعتبارسنجی ورودی
    const validPassword = validateString(password, 1, 256);
    if (!validPassword) {
      return NextResponse.json(
        { error: 'رمز عبور نامعتبر است' },
        { status: 400 }
      );
    }

    // بررسی رمز عبور
    if (!verifyPassword(validPassword)) {
      // تاخیر اضافی برای جلوگیری از timing attack
      await new Promise(resolve => setTimeout(resolve, 1500));
      return NextResponse.json(
        { error: 'رمز عبور اشتباه است' },
        { status: 401 }
      );
    }

    // ایجاد سشن
    const token = await createAdminSession();

    // تنظیم کوکی httpOnly امن
    const cookieStore = await cookies();
    cookieStore.set('yio-admin-token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      path: '/',
      maxAge: 24 * 60 * 60, // ۲۴ ساعت
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json(
      { error: 'خطا در ورود' },
      { status: 500 }
    );
  }
}
