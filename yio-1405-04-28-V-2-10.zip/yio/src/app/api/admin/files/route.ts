import { NextRequest, NextResponse } from 'next/server';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { promises as fs } from 'fs';
import path from 'path';

const UPLOAD_DIR = path.join(process.cwd(), 'public', 'uploads');
const ALLOWED_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.mp4', '.webm', '.pdf', '.zip'];
const MAX_SIZE = 10 * 1024 * 1024; // 10MB

// اطمینان از مسیر امن (path traversal prevention)
function getSafePath(subPath: string): string {
  const safe = path.normalize(subPath).replace(/^(\.\.[/\\])+/, '');
  const fullPath = path.join(UPLOAD_DIR, safe);
  if (!fullPath.startsWith(UPLOAD_DIR)) {
    throw new Error('مسیر نامعتبر');
  }
  return fullPath;
}

// GET: لیست فایل‌ها و پوشه‌ها
export async function GET(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const subPath = searchParams.get('path') || '';

    const targetPath = getSafePath(subPath);

    // ساخت پوشه اگر وجود ندارد
    try {
      await fs.access(targetPath);
    } catch {
      await fs.mkdir(targetPath, { recursive: true });
    }

    const entries = await fs.readdir(targetPath, { withFileTypes: true });

    const items = await Promise.all(entries.map(async (entry) => {
      const fullPath = path.join(targetPath, entry.name);
      const stats = await fs.stat(fullPath);
      const relativePath = path.relative(UPLOAD_DIR, fullPath).split(path.sep).join('/');

      return {
        name: entry.name,
        type: entry.isDirectory() ? 'folder' : 'file',
        size: stats.size,
        modified: stats.mtime,
        path: relativePath,
        url: entry.isFile() ? `/uploads/${relativePath}` : null,
        ext: entry.isFile() ? path.extname(entry.name).toLowerCase() : null,
      };
    }));

    // مرتب‌سازی: پوشه‌ها اول، بعد فایل‌ها، الفبایی
    items.sort((a, b) => {
      if (a.type !== b.type) return a.type === 'folder' ? -1 : 1;
      return a.name.localeCompare(b.name, 'fa');
    });

    // آمار
    const totalSize = items.filter(i => i.type === 'file').reduce((sum, i) => sum + i.size, 0);
    const totalFiles = items.filter(i => i.type === 'file').length;
    const totalFolders = items.filter(i => i.type === 'folder').length;

    return NextResponse.json({
      items,
      currentPath: subPath,
      stats: { totalFiles, totalFolders, totalSize },
    });
  } catch (error) {
    console.error('File manager error:', error);
    return NextResponse.json({ error: 'خطا در دریافت فایل‌ها' }, { status: 500 });
  }
}

// DELETE: حذف فایل یا پوشه
export async function DELETE(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const filePath = searchParams.get('path');

    if (!filePath) return NextResponse.json({ error: 'مسیر الزامی است' }, { status: 400 });

    const fullPath = getSafePath(filePath);
    const stats = await fs.stat(fullPath);

    if (stats.isDirectory()) {
      await fs.rmdir(fullPath, { recursive: true });
    } else {
      await fs.unlink(fullPath);
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete error:', error);
    return NextResponse.json({ error: 'خطا در حذف' }, { status: 500 });
  }
}

// POST: ساخت پوشه جدید یا تغییر نام
export async function POST(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const body = await request.json();
    const { action, path: filePath, name, newPath } = body;

    if (action === 'mkdir') {
      if (!name || name.length < 1 || name.length > 100) {
        return NextResponse.json({ error: 'نام پوشه نامعتبر' }, { status: 400 });
      }
      const safeName = name.replace(/[/\\]/g, '');
      const fullPath = getSafePath(path.join(filePath || '', safeName));
      await fs.mkdir(fullPath, { recursive: true });
      return NextResponse.json({ success: true });
    }

    if (action === 'rename') {
      if (!filePath || !newPath) return NextResponse.json({ error: 'مسیر الزامی' }, { status: 400 });
      const oldPath = getSafePath(filePath);
      const newSafePath = getSafePath(newPath);
      await fs.rename(oldPath, newSafePath);
      return NextResponse.json({ success: true });
    }

    return NextResponse.json({ error: 'action نامعتبر' }, { status: 400 });
  } catch (error) {
    console.error('File action error:', error);
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
