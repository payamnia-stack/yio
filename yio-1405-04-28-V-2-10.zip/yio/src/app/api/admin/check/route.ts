import { NextResponse } from 'next/server';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';

// بررسی وضعیت احراز هویت
export async function GET() {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);

    return NextResponse.json({ authenticated: isAuth });
  } catch (error) {
    console.error('Auth check error:', error);
    return NextResponse.json(
      { authenticated: false },
      { status: 500 }
    );
  }
}
