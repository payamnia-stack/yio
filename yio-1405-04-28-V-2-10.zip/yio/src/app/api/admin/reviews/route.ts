// API مدیریت نظرات
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';

export async function GET(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');

    const where: any = {};
    if (status === 'pending') where.isActive = false;
    if (status === 'approved') where.isActive = true;

    const reviews = await db.review.findMany({
      where,
      include: { user: { select: { name: true, phone: true } }, product: { select: { title: true } } },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });

    const stats = {
      total: await db.review.count(),
      pending: await db.review.count({ where: { isActive: false } }),
      approved: await db.review.count({ where: { isActive: true } }),
    };

    return NextResponse.json({ reviews, stats });
  } catch { return NextResponse.json({ error: 'خطا' }, { status: 500 }); }
}
