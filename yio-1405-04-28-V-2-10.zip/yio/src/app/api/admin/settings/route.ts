import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput, securityCheck } from '@/lib/security';

// GET: دریافت همه تنظیمات (مدیر)
export async function GET() {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const settings = await db.siteSetting.findMany({ orderBy: { category: 'asc' } });
    return NextResponse.json({ settings });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// PUT: به‌روزرسانی یک یا چند تنظیم
export async function PUT(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const body = await request.json();
    const secCheck = securityCheck(body);
    if (!secCheck.safe) return NextResponse.json({ error: secCheck.reason }, { status: 400 });

    // body می‌تواند شامل چندین key-value باشد
    const updates = body.settings || body;
    if (!updates || typeof updates !== 'object') {
      return NextResponse.json({ error: 'فرمت نامعتبر' }, { status: 400 });
    }

    for (const [key, value] of Object.entries(updates)) {
      if (typeof value !== 'string') continue;
      const sanitized = sanitizeInput(value).slice(0, 5000);
      const category = body.category || 'general';

      await db.siteSetting.upsert({
        where: { key },
        update: { value: sanitized },
        create: { key, value: sanitized, category },
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Settings update error:', error);
    return NextResponse.json({ error: 'خطا در ذخیره' }, { status: 500 });
  }
}

// POST: ایجاد تنظیم جدید
export async function POST(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const body = await request.json();
    if (!body.key || typeof body.key !== 'string') {
      return NextResponse.json({ error: 'کلید الزامی است' }, { status: 400 });
    }

    const setting = await db.siteSetting.create({
      data: {
        key: body.key.trim().toLowerCase(),
        value: sanitizeInput(body.value || '').slice(0, 5000),
        category: body.category || 'general',
      },
    });

    return NextResponse.json({ setting, success: true });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
