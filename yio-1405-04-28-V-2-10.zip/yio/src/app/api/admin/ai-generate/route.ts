import { NextRequest, NextResponse } from 'next/server';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput } from '@/lib/security';

// POST: تولید توضیح محصول با AI (متنی یا از روی عکس)
export async function POST(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const body = await request.json();
    const { title, category, woodType, brand, price, discountPrice, image, mode } = body;

    if (!title || title.trim().length < 3) {
      return NextResponse.json({ error: 'عنوان محصول الزامی است' }, { status: 400 });
    }

    let description = '';

    try {
      const ZAI = (await import('z-ai-web-dev-sdk')).default;
      const zai = await ZAI.create();

      // اگر عکس محصول موجود باشه و mode = 'vision' باشه، از Vision AI استفاده کن
      if (image && mode === 'vision') {
        // تبدیل عکس به base64 اگر URL نیست
        let imageUrl = image;

        // اگر عکس لوکال هست (مثلا /uploads/...)، به URL کامل تبدیل کن
        if (image.startsWith('/')) {
          const baseUrl = request.headers.get('host') || 'localhost:3000';
          const protocol = request.headers.get('x-forwarded-proto') || 'http';
          imageUrl = `${protocol}://${baseUrl}${image}`;
        }

        const visionPrompt = `این عکس را بررسی کن و یک توضیح جذاب و حرفه‌ای فارسی برای این محصول بنویس (حداکثر ۲۰۰ کلمه).

اطلاعات محصول:
- عنوان: ${sanitizeInput(title)}
- دسته‌بندی: ${category || 'نامشخص'}
- برند: ${brand || 'YIO'}
${woodType ? `- نوع چوب: ${woodType}` : ''}
${price ? `- قیمت: ${price.toLocaleString('fa-IR')} تومان` : ''}

نکات:
- توضیحات را بر اساس آنچه در عکس می‌بینی بنویس
- به رنگ، شکل، طراحی و جزئیات محصول اشاره کن
- به کیفیت چوب و دست‌ساز بودن اشاره کن
- لحن دوستانه اما حرفه‌ای
- فقط متن توضیح، بدون عنوان`;

        const response = await zai.chat.completions.createVision({
          messages: [
            {
              role: 'user',
              content: [
                { type: 'text', text: visionPrompt },
                { type: 'image_url', image_url: { url: imageUrl } },
              ],
            },
          ],
          temperature: 0.7,
          max_tokens: 500,
        });

        description = response.choices[0]?.message?.content || '';
      } else {
        // حالت متنی (بدون عکس)
        const textPrompt = `یک توضیح جذاب و حرفه‌ای فارسی برای محصول زیر بنویس (حداکثر ۲۰۰ کلمه):

محصول: ${sanitizeInput(title)}
دسته‌بندی: ${category || 'نامشخص'}
برند: ${brand || 'YIO'}
${woodType ? `نوع چوب: ${woodType}` : ''}
${price ? `قیمت: ${price.toLocaleString('fa-IR')} تومان` : ''}
${discountPrice ? `قیمت با تخفیف: ${discountPrice.toLocaleString('fa-IR')} تومان` : ''}

نکات:
- لحن دوستانه اما حرفه‌ای
- به کیفیت چوب و دست‌ساز بودن اشاره کن
- مزایای محصول را برجسته کن
- مناسب برای فروشگاه اینترنتی
- فقط متن توضیح، بدون عنوان و بدون کد`;

        const response = await zai.chat.completions.create({
          messages: [
            { role: 'system', content: 'تو یک دستیار فروش هستی که توضیحات محصولات چوبی دست‌ساز می‌نویسی. همیشه فارسی روان و جذاب بنویس.' },
            { role: 'user', content: textPrompt },
          ],
          temperature: 0.7,
          max_tokens: 500,
        });

        description = response.choices[0]?.message?.content || '';
      }
    } catch (aiError) {
      console.error('AI error:', aiError);
      // fallback
      description = `${sanitizeInput(title)} یک محصول دست‌ساز و باکیفیت از برند ${brand || 'YIO'} است. ` +
        `${woodType ? `این محصول از ${woodType} مرغوب ساخته شده و ` : ''}` +
        `با دقت و هنر توسط صنعتگران ایرانی تولید شده است. ` +
        `${category ? `در دسته‌بندی ${category}، ` : ''}` +
        `این محصول با طراحی زیبا و کیفیت بالا، انتخابی عالی برای شماست.`;
    }

    description = description.trim();

    return NextResponse.json({
      description,
      success: true,
      source: image && mode === 'vision' ? 'ai-vision' : 'ai-text',
    });
  } catch (error) {
    console.error('AI generate error:', error);
    return NextResponse.json({ error: 'خطا در تولید توضیح' }, { status: 500 });
  }
}
