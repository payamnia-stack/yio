// API ویرایش/حذف بلاگ
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput } from '@/lib/security';

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const postId = parseInt(id);
    if (isNaN(postId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    const body = await request.json();
    const updateData: any = {};
    if (body.title !== undefined) updateData.title = sanitizeInput(body.title).slice(0, 200);
    if (body.content !== undefined) updateData.content = sanitizeInput(body.content).slice(0, 50000);
    if (body.excerpt !== undefined) updateData.excerpt = body.excerpt ? sanitizeInput(body.excerpt).slice(0, 500) : null;
    if (body.coverImage !== undefined) updateData.coverImage = body.coverImage || null;
    if (body.category !== undefined) updateData.category = body.category;
    if (body.isPublished !== undefined) updateData.isPublished = Boolean(body.isPublished);

    const post = await db.blogPost.update({ where: { id: postId }, data: updateData });
    return NextResponse.json({ post, success: true });
  } catch { return NextResponse.json({ error: 'خطا' }, { status: 500 }); }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const postId = parseInt(id);
    if (isNaN(postId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    await db.blogPost.delete({ where: { id: postId } });
    return NextResponse.json({ success: true });
  } catch { return NextResponse.json({ error: 'خطا' }, { status: 500 }); }
}
