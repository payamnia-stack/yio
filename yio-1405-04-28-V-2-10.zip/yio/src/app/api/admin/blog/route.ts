// API مدیریت بلاگ
import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput, securityCheck } from '@/lib/security';

export async function GET() {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const posts = await db.blogPost.findMany({ orderBy: { createdAt: 'desc' } });
    return NextResponse.json({ posts });
  } catch { return NextResponse.json({ error: 'خطا' }, { status: 500 }); }
}

export async function POST(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const body = await request.json();
    const secCheck = securityCheck(body);
    if (!secCheck.safe) return NextResponse.json({ error: secCheck.reason }, { status: 400 });

    if (!body.title || body.title.trim().length < 5) return NextResponse.json({ error: 'عنوان حداقل ۵ کاراکتر' }, { status: 400 });
    if (!body.content || body.content.trim().length < 50) return NextResponse.json({ error: 'محتوا حداقل ۵۰ کاراکتر' }, { status: 400 });

    const slug = (body.slug || body.title).trim().replace(/\s+/g, '-').replace(/[^\w\u0600-\u06FF\-]/g, '');

    const post = await db.blogPost.create({
      data: {
        title: sanitizeInput(body.title).slice(0, 200),
        slug,
        excerpt: body.excerpt ? sanitizeInput(body.excerpt).slice(0, 500) : null,
        content: sanitizeInput(body.content).slice(0, 50000),
        coverImage: body.coverImage || null,
        category: body.category || 'عمومی',
        tags: body.tags || null,
        isPublished: Boolean(body.isPublished ?? true),
      },
    });

    return NextResponse.json({ post, success: true });
  } catch { return NextResponse.json({ error: 'خطا' }, { status: 500 }); }
}
