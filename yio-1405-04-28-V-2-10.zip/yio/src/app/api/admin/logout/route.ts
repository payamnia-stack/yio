import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { deleteAdminSession } from '@/lib/admin-auth';

// خروج از پنل مدیریت
export async function POST() {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get('yio-admin-token')?.value;

    if (token) {
      await deleteAdminSession(token);
    }

    cookieStore.delete('yio-admin-token');

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Logout error:', error);
    return NextResponse.json(
      { error: 'خطا در خروج' },
      { status: 500 }
    );
  }
}
