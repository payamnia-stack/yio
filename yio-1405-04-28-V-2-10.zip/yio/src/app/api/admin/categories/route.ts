import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput, securityCheck } from '@/lib/security';

// GET: لیست دسته‌بندی‌ها (مدیر)
export async function GET() {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const categories = await db.category.findMany({ orderBy: [{ order: 'asc' }, { title: 'asc' }] });
    return NextResponse.json({ categories });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// POST: ایجاد دسته‌بندی جدید
export async function POST(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const body = await request.json();
    const secCheck = securityCheck(body);
    if (!secCheck.safe) return NextResponse.json({ error: secCheck.reason }, { status: 400 });

    if (!body.title || typeof body.title !== 'string' || body.title.trim().length < 2) {
      return NextResponse.json({ error: 'عنوان دسته‌بندی باید حداقل ۲ کاراکتر باشد' }, { status: 400 });
    }

    // ساخت slug از عنوان
    const slug = body.slug || body.title.trim().replace(/\s+/g, '-');

    // بررسی تکراری نبودن
    const existing = await db.category.findFirst({
      where: { OR: [{ title: body.title.trim() }, { slug }] },
    });
    if (existing) {
      return NextResponse.json({ error: 'این دسته‌بندی قبلا ثبت شده' }, { status: 400 });
    }

    const category = await db.category.create({
      data: {
        title: sanitizeInput(body.title).slice(0, 100),
        slug,
        icon: body.icon || '📦',
        color: body.color || '#dc2626',
        description: body.description ? sanitizeInput(body.description).slice(0, 500) : null,
        order: parseInt(body.order) || 0,
        isActive: Boolean(body.isActive ?? true),
      },
    });

    return NextResponse.json({ category, success: true });
  } catch (error) {
    console.error('Create category error:', error);
    return NextResponse.json({ error: 'خطا در ایجاد' }, { status: 500 });
  }
}
