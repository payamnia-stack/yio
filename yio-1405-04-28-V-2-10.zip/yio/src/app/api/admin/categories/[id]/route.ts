import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput } from '@/lib/security';

// PUT: ویرایش دسته‌بندی
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const catId = parseInt(id);
    if (isNaN(catId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    const body = await request.json();

    const updateData: any = {};
    if (body.title !== undefined) {
      updateData.title = sanitizeInput(body.title).slice(0, 100);
      updateData.slug = body.slug || body.title.trim().replace(/\s+/g, '-');
    }
    if (body.icon !== undefined) updateData.icon = body.icon;
    if (body.color !== undefined) updateData.color = body.color;
    if (body.description !== undefined) updateData.description = body.description ? sanitizeInput(body.description).slice(0, 500) : null;
    if (body.order !== undefined) updateData.order = parseInt(body.order) || 0;
    if (body.isActive !== undefined) updateData.isActive = Boolean(body.isActive);

    const category = await db.category.update({ where: { id: catId }, data: updateData });
    return NextResponse.json({ category, success: true });
  } catch (error) {
    return NextResponse.json({ error: 'خطا در ویرایش' }, { status: 500 });
  }
}

// DELETE: حذف دسته‌بندی
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const catId = parseInt(id);
    if (isNaN(catId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    await db.category.delete({ where: { id: catId } });
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'خطا در حذف' }, { status: 500 });
  }
}
