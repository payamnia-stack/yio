import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput } from '@/lib/security';

// GET: دریافت جزئیات کامل یک کاربر (شامل آدرس‌ها، سفارشات، علاقه‌مندی‌ها)
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const userId = parseInt(id);
    if (isNaN(userId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    const user = await db.user.findUnique({
      where: { id: userId },
      select: {
        id: true, phone: true, name: true, email: true,
        isVerified: true, createdAt: true, updatedAt: true,
        addresses: {
          orderBy: [{ isDefault: 'desc' }, { createdAt: 'desc' }],
        },
        orders: {
          orderBy: { createdAt: 'desc' },
          take: 20,
          select: {
            id: true, orderNumber: true, status: true,
            finalAmount: true, paymentStatus: true, paymentMethod: true,
            createdAt: true, trackingCode: true,
            items: { select: { id: true, productTitle: true, quantity: true, price: true } },
          },
        },
        wishlist: {
          include: {
            product: {
              select: {
                id: true, title: true, price: true, discountPrice: true,
                image: true, inStock: true,
              },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
        reviews: {
          orderBy: { createdAt: 'desc' },
          take: 10,
          select: {
            id: true, rating: true, comment: true, isActive: true, createdAt: true,
            product: { select: { id: true, title: true } },
          },
        },
        loyaltyPoints: {
          orderBy: { createdAt: 'desc' },
          take: 10,
          select: { id: true, points: true, reason: true, orderId: true, createdAt: true },
        },
        _count: { select: { orders: true, reviews: true, wishlist: true, loyaltyPoints: true } },
      },
    });

    if (!user) return NextResponse.json({ error: 'کاربر یافت نشد' }, { status: 404 });

    // محاسبه مجموع امتیازات وفاداری
    const totalPoints = await db.loyaltyPoint.aggregate({
      _sum: { points: true },
      where: { userId },
    });

    return NextResponse.json({
      user,
      totalLoyaltyPoints: totalPoints._sum.points || 0,
    });
  } catch (error) {
    console.error('Admin user detail error:', error);
    return NextResponse.json({ error: 'خطا در دریافت اطلاعات' }, { status: 500 });
  }
}

// PUT: ویرایش کاربر
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const userId = parseInt(id);
    if (isNaN(userId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    const body = await request.json();
    const updateData: any = {};

    if (body.name !== undefined) updateData.name = body.name ? sanitizeInput(body.name).slice(0, 100) : null;
    if (body.email !== undefined) updateData.email = body.email ? sanitizeInput(body.email).slice(0, 254) : null;
    if (body.isVerified !== undefined) updateData.isVerified = Boolean(body.isVerified);

    const user = await db.user.update({ where: { id: userId }, data: updateData });
    return NextResponse.json({ user, success: true });
  } catch (error) {
    return NextResponse.json({ error: 'خطا در ویرایش' }, { status: 500 });
  }
}

// DELETE: حذف کاربر
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const userId = parseInt(id);
    if (isNaN(userId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    // حذف سشن‌ها
    await db.session.deleteMany({ where: { userId } });
    await db.user.delete({ where: { id: userId } });
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'خطا در حذف' }, { status: 500 });
  }
}
