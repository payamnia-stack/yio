import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput, validateIranMobile } from '@/lib/security';

// GET: لیست آدرس‌های یک کاربر
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const userId = parseInt(id);
    if (isNaN(userId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    const addresses = await db.address.findMany({
      where: { userId },
      orderBy: [{ isDefault: 'desc' }, { createdAt: 'desc' }],
    });

    return NextResponse.json({ addresses });
  } catch (error) {
    return NextResponse.json({ error: 'خطا در دریافت آدرس‌ها' }, { status: 500 });
  }
}

// POST: افزودن آدرس جدید برای کاربر
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id } = await params;
    const userId = parseInt(id);
    if (isNaN(userId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    const body = await request.json();

    // اعتبارسنجی فیلدها
    const title = sanitizeInput(String(body.title || '').slice(0, 50));
    const recipientName = sanitizeInput(String(body.recipientName || '').slice(0, 100));
    const phone = String(body.phone || '').trim();
    const province = sanitizeInput(String(body.province || '').slice(0, 50));
    const city = sanitizeInput(String(body.city || '').slice(0, 50));
    const address = sanitizeInput(String(body.address || '').slice(0, 500));
    const postalCode = body.postalCode ? sanitizeInput(String(body.postalCode).slice(0, 20)) : null;
    const isDefault = Boolean(body.isDefault);

    if (!title || !recipientName || !phone || !province || !city || !address) {
      return NextResponse.json({ error: 'همه فیلدهای الزامی را پر کنید' }, { status: 400 });
    }

    if (!validateIranMobile(phone)) {
      return NextResponse.json({ error: 'شماره موبایل نامعتبر است' }, { status: 400 });
    }

    // اگر این آدرس پیش‌فرض است، بقیه را غیر پیش‌فرض کن
    if (isDefault) {
      await db.address.updateMany({
        where: { userId },
        data: { isDefault: false },
      });
    }

    const newAddress = await db.address.create({
      data: {
        userId,
        title,
        recipientName,
        phone,
        province,
        city,
        address,
        postalCode,
        isDefault,
      },
    });

    return NextResponse.json({ address: newAddress, success: true });
  } catch (error) {
    console.error('Create address error:', error);
    return NextResponse.json({ error: 'خطا در افزودن آدرس' }, { status: 500 });
  }
}
