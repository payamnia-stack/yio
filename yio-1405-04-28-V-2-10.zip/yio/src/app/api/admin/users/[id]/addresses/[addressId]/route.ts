import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput, validateIranMobile } from '@/lib/security';

// PUT: ویرایش آدرس
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; addressId: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id, addressId } = await params;
    const userId = parseInt(id);
    const addrId = parseInt(addressId);
    if (isNaN(userId) || isNaN(addrId)) {
      return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });
    }

    const body = await request.json();

    const updateData: any = {};
    if (body.title !== undefined) updateData.title = sanitizeInput(String(body.title).slice(0, 50));
    if (body.recipientName !== undefined) updateData.recipientName = sanitizeInput(String(body.recipientName).slice(0, 100));
    if (body.phone !== undefined) {
      const phone = String(body.phone).trim();
      if (!validateIranMobile(phone)) {
        return NextResponse.json({ error: 'شماره موبایل نامعتبر است' }, { status: 400 });
      }
      updateData.phone = phone;
    }
    if (body.province !== undefined) updateData.province = sanitizeInput(String(body.province).slice(0, 50));
    if (body.city !== undefined) updateData.city = sanitizeInput(String(body.city).slice(0, 50));
    if (body.address !== undefined) updateData.address = sanitizeInput(String(body.address).slice(0, 500));
    if (body.postalCode !== undefined) {
      updateData.postalCode = body.postalCode ? sanitizeInput(String(body.postalCode).slice(0, 20)) : null;
    }
    if (body.isDefault !== undefined) {
      // اگر پیش‌فرض می‌شود، بقیه را غیر پیش‌فرض کن
      if (Boolean(body.isDefault)) {
        await db.address.updateMany({
          where: { userId, id: { not: addrId } },
          data: { isDefault: false },
        });
      }
      updateData.isDefault = Boolean(body.isDefault);
    }

    const updated = await db.address.update({
      where: { id: addrId },
      data: updateData,
    });

    return NextResponse.json({ address: updated, success: true });
  } catch (error) {
    console.error('Update address error:', error);
    return NextResponse.json({ error: 'خطا در ویرایش آدرس' }, { status: 500 });
  }
}

// DELETE: حذف آدرس
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; addressId: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { id, addressId } = await params;
    const addrId = parseInt(addressId);
    if (isNaN(addrId)) return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });

    await db.address.delete({ where: { id: addrId } });
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'خطا در حذف آدرس' }, { status: 500 });
  }
}
