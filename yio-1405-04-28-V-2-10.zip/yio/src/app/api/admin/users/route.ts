import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { hashPassword } from '@/lib/user-auth';
import { validateIranMobile } from '@/lib/security';

// GET: لیست کاربران
export async function GET(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = 20;

    const where: any = {};
    if (search) {
      where.OR = [
        { phone: { contains: search } },
        { name: { contains: search } },
        { email: { contains: search } },
      ];
    }

    const [total, users] = await Promise.all([
      db.user.count({ where }),
      db.user.findMany({
        where,
        select: {
          id: true, phone: true, name: true, email: true, avatar: true,
          level: true, isVerified: true, createdAt: true,
          province: true, city: true, isWholesale: true,
          _count: { select: { orders: true, reviews: true, wishlist: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
    ]);

    const stats = {
      total: await db.user.count(),
      verified: await db.user.count({ where: { isVerified: true } }),
      unverified: await db.user.count({ where: { isVerified: false } }),
      newThisMonth: await db.user.count({
        where: { createdAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) } },
      }),
    };

    return NextResponse.json({
      users,
      pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
      stats,
    });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// POST: ساخت کاربر جدید از سمت ادمین
// body: { name, phone, email?, password?, level?, isVerified?, ... }
export async function POST(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const body = await request.json();
    const { name, phone, email, password, level, isVerified } = body;

    // اعتبارسنجی
    if (!phone || !validateIranMobile(phone)) {
      return NextResponse.json({ error: 'شماره موبایل معتبر وارد کنید (09XXXXXXXXX)' }, { status: 400 });
    }
    if (!name || name.trim().length < 2) {
      return NextResponse.json({ error: 'نام را کامل وارد کنید' }, { status: 400 });
    }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json({ error: 'ایمیل نامعتبر' }, { status: 400 });
    }

    // بررسی تکراری نبودن
    const existing = await db.user.findUnique({ where: { phone } });
    if (existing) {
      return NextResponse.json({ error: 'این شماره موبایل قبلا ثبت شده' }, { status: 400 });
    }
    if (email) {
      const existingEmail = await db.user.findFirst({ where: { email } });
      if (existingEmail) {
        return NextResponse.json({ error: 'این ایمیل قبلا ثبت شده' }, { status: 400 });
      }
    }

    // ساخت کاربر
    const user = await db.user.create({
      data: {
        phone,
        name: name.trim(),
        email: email || null,
        password: password ? hashPassword(password) : null,
        level: level && level >= 1 && level <= 5 ? level : 1,
        isVerified: isVerified !== false,
      },
      select: {
        id: true, phone: true, name: true, email: true, level: true, isVerified: true, createdAt: true,
      },
    });

    return NextResponse.json({ success: true, user });
  } catch (error: any) {
    console.error('Create user error:', error);
    if (error?.code === 'P2002') {
      return NextResponse.json({ error: 'این شماره موبایل قبلا ثبت شده' }, { status: 400 });
    }
    return NextResponse.json({ error: 'خطا در ساخت کاربر' }, { status: 500 });
  }
}
