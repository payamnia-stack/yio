import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// middleware برای بررسی API Key
async function verifyApiKey(req: NextRequest) {
  const authHeader = req.headers.get('authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return false;
  }
  const token = authHeader.replace('Bearer ', '');

  // دریافت API Key از تنظیمات سایت
  const setting = await db.siteSetting.findUnique({ where: { key: 'api_key' } });
  if (!setting || !setting.value) return false;

  return token === setting.value;
}

// GET: آمار فروش و سفارشات برای n8n
export async function GET(request: NextRequest) {
  const isAuth = await verifyApiKey(request);
  if (!isAuth) {
    return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const action = searchParams.get('action') || 'stats';

  try {
    switch (action) {
      case 'stats': {
        const [totalOrders, pendingOrders, totalRevenue, totalProducts, lowStock] = await Promise.all([
          db.order.count(),
          db.order.count({ where: { status: 'pending' } }),
          db.order.aggregate({ _sum: { finalAmount: true }, where: { paymentStatus: 'paid' } }),
          db.product.count(),
          db.product.count({ where: { inStock: false } }),
        ]);

        return NextResponse.json({
          totalOrders,
          pendingOrders,
          totalRevenue: totalRevenue._sum.finalAmount || 0,
          totalProducts,
          lowStockProducts: lowStock,
        });
      }

      case 'orders': {
        const limit = parseInt(searchParams.get('limit') || '5');
        const orders = await db.order.findMany({
          take: limit,
          orderBy: { createdAt: 'desc' },
          include: {
            items: { select: { productTitle: true, quantity: true, price: true } },
          },
        });

        return NextResponse.json({
          orders: orders.map(o => ({
            id: o.id,
            orderNumber: o.orderNumber,
            status: o.status,
            finalAmount: o.finalAmount,
            paymentStatus: o.paymentStatus,
            recipientName: o.recipientName,
            recipientPhone: o.recipientPhone,
            createdAt: o.createdAt,
            itemsCount: o.items.length,
            items: o.items,
          })),
        });
      }

      case 'products': {
        const products = await db.product.findMany({
          select: {
            id: true,
            title: true,
            price: true,
            discountPrice: true,
            inStock: true,
            isPublished: true,
            stockQuantity: true,
            category: true,
            woodType: true,
          },
          orderBy: { createdAt: 'desc' },
        });

        return NextResponse.json({
          totalProducts: products.length,
          inStock: products.filter(p => p.inStock).length,
          outOfStock: products.filter(p => !p.inStock).length,
          products,
        });
      }

      case 'search': {
        const q = searchParams.get('q') || '';
        if (!q) return NextResponse.json({ products: [] });

        const products = await db.product.findMany({
          where: {
            OR: [
              { title: { contains: q } },
              { brand: { contains: q } },
              { woodType: { contains: q } },
            ],
          },
          take: 10,
          select: {
            id: true,
            title: true,
            price: true,
            discountPrice: true,
            inStock: true,
            category: true,
          },
        });

        return NextResponse.json({ products });
      }

      case 'customers': {
        const [totalUsers, verifiedUsers, newThisMonth] = await Promise.all([
          db.user.count(),
          db.user.count({ where: { isVerified: true } }),
          db.user.count({
            where: {
              createdAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
            },
          }),
        ]);

        return NextResponse.json({
          totalUsers,
          verifiedUsers,
          newThisMonth,
        });
      }

      default:
        return NextResponse.json({ error: 'action نامعتبر' }, { status: 400 });
    }
  } catch (error) {
    console.error('API n8n error:', error);
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// POST: به‌روزرسانی موجودی و قیمت محصول
export async function POST(request: NextRequest) {
  const isAuth = await verifyApiKey(request);
  if (!isAuth) {
    return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { action } = body;

    switch (action) {
      case 'updateStock': {
        const { productId, inStock } = body;
        if (!productId) return NextResponse.json({ error: 'productId الزامی است' }, { status: 400 });

        const product = await db.product.update({
          where: { id: parseInt(productId) },
          data: { inStock: Boolean(inStock) },
        });

        return NextResponse.json({ success: true, product: { id: product.id, title: product.title, inStock: product.inStock } });
      }

      case 'updateStockQuantity': {
        const { productId, stockQuantity } = body;
        if (!productId) return NextResponse.json({ error: 'productId الزامی است' }, { status: 400 });

        const qty = Math.max(0, parseInt(stockQuantity) || 0);
        const product = await db.product.update({
          where: { id: parseInt(productId) },
          data: {
            stockQuantity: qty,
            inStock: qty > 0,
          },
        });

        // broadcast آپدیت به همه کلاینت‌های متصل (real-time)
        const { broadcastStockUpdate } = await import('@/lib/stock-events');
        broadcastStockUpdate(product.id, product.stockQuantity);

        return NextResponse.json({ success: true, product: { id: product.id, title: product.title, stockQuantity: product.stockQuantity, inStock: product.inStock } });
      }

      case 'updatePublishStatus': {
        const { productId, isPublished } = body;
        if (!productId) return NextResponse.json({ error: 'productId الزامی است' }, { status: 400 });

        const product = await db.product.update({
          where: { id: parseInt(productId) },
          data: { isPublished: Boolean(isPublished) },
        });

        return NextResponse.json({ success: true, product: { id: product.id, title: product.title, isPublished: product.isPublished } });
      }

      case 'updatePrice': {
        const { productId, price, discountPrice } = body;
        if (!productId) return NextResponse.json({ error: 'productId الزامی است' }, { status: 400 });

        const updateData: any = {};
        if (price !== undefined) updateData.price = parseInt(price);
        if (discountPrice !== undefined) updateData.discountPrice = parseInt(discountPrice);

        const product = await db.product.update({
          where: { id: parseInt(productId) },
          data: updateData,
        });

        return NextResponse.json({ success: true, product: { id: product.id, title: product.title, price: product.price, discountPrice: product.discountPrice } });
      }

      case 'bulkUpdateStock': {
        const { items } = body;
        if (!Array.isArray(items)) return NextResponse.json({ error: 'items باید آرایه باشد' }, { status: 400 });

        const { broadcastStockUpdate } = await import('@/lib/stock-events');
        let updated = 0;
        for (const item of items) {
          if (item.productId) {
            const updateData: any = {};
            if (item.inStock !== undefined) updateData.inStock = Boolean(item.inStock);
            if (item.stockQuantity !== undefined) {
              const qty = Math.max(0, parseInt(item.stockQuantity) || 0);
              updateData.stockQuantity = qty;
              updateData.inStock = qty > 0;
            }
            if (item.isPublished !== undefined) updateData.isPublished = Boolean(item.isPublished);
            if (Object.keys(updateData).length > 0) {
              const updated_product = await db.product.update({
                where: { id: parseInt(item.productId) },
                data: updateData,
              });
              // broadcast هر آپدیت به‌صورت جداگانه
              if (item.stockQuantity !== undefined) {
                broadcastStockUpdate(updated_product.id, updated_product.stockQuantity);
              }
              updated++;
            }
          }
        }

        return NextResponse.json({ success: true, updated });
      }

      case 'createProduct': {
        const { title, price, category, description, woodType, brand, stockQuantity, images, videos } = body;
        if (!title || !price) return NextResponse.json({ error: 'title و price الزامی است' }, { status: 400 });

        const product = await db.product.create({
          data: {
            title: String(title),
            price: parseInt(price),
            category: String(category || 'عمومی'),
            brand: String(brand || 'YIO'),
            description: description ? String(description) : null,
            woodType: woodType ? String(woodType) : null,
            stockQuantity: Math.max(0, parseInt(stockQuantity) || 0),
            inStock: (parseInt(stockQuantity) || 0) > 0,
            image: Array.isArray(images) && images.length > 0 ? images[0] : '',
            images: Array.isArray(images) && images.length > 0 ? JSON.stringify(images) : null,
            videos: Array.isArray(videos) && videos.length > 0 ? JSON.stringify(videos) : null,
            isPublished: false, // محصولات جدید به‌صورت پیش‌فرض منتشر نیستند
          },
        });

        return NextResponse.json({ success: true, product: { id: product.id, title: product.title } });
      }

      default:
        return NextResponse.json({ error: 'action نامعتبر' }, { status: 400 });
    }
  } catch (error) {
    console.error('API n8n POST error:', error);
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
