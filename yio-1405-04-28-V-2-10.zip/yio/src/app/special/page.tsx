'use client';

import { useState, useEffect } from 'react';
import { Flame, ChevronLeft } from 'lucide-react';
import { Header } from '@/components/shop/header';
import { Footer } from '@/components/shop/footer';
import { CartDrawer } from '@/components/shop/cart-drawer';
import { ProductCard } from '@/components/shop/product-card';
import { Skeleton } from '@/components/ui/skeleton';
import { toFa, type Product } from '@/lib/shop-data';
import Link from 'next/link';

export default function SpecialPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/shop/special')
      .then(r => r.json())
      .then(data => setProducts(data.products || []))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
          <Link href="/" className="hover:text-[#dc2626]">خانه</Link>
          <ChevronLeft className="w-4 h-4" />
          <span className="text-gray-700">فروش ویژه</span>
        </div>

        <div className="bg-gradient-to-l from-[#dc2626] to-[#991b1b] rounded-2xl p-8 mb-6 text-white text-center">
          <Flame className="w-12 h-12 mx-auto mb-3" />
          <h1 className="text-3xl font-bold">فروش ویژه YIO</h1>
          <p className="opacity-90 mt-2 fa-num">
            {loading ? '' : `${toFa(products.length)} محصول با بهترین تخفیف‌ها`}
          </p>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="aspect-[3/4] w-full" />
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="bg-white rounded-xl p-12 text-center text-gray-500">
            در حال حاضر محصول فروش ویژه موجود نیست
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
            {products.map(p => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </main>

      <Footer />
      <CartDrawer />
    </div>
  );
}
