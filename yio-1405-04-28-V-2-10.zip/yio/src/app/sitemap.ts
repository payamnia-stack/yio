import type { MetadataRoute } from 'next';
import { db } from '@/lib/db';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'https://yio-shop.ir';

  const staticPages = [
    { url: '', lastModified: new Date(), priority: 1 },
    { url: '/special', lastModified: new Date(), priority: 0.9 },
    { url: '/blog', lastModified: new Date(), priority: 0.8 },
    { url: '/about', lastModified: new Date(), priority: 0.7 },
    { url: '/contact', lastModified: new Date(), priority: 0.7 },
    { url: '/faq', lastModified: new Date(), priority: 0.6 },
    { url: '/wholesale', lastModified: new Date(), priority: 0.6 },
    { url: '/auth', lastModified: new Date(), priority: 0.5 },
  ];

  let products: any[] = [];
  let blogPosts: any[] = [];

  try {
    [products, blogPosts] = await Promise.all([
      db.product.findMany({ where: { inStock: true }, select: { id: true, updatedAt: true } }),
      db.blogPost.findMany({ where: { isPublished: true }, select: { slug: true, updatedAt: true } }),
    ]);
  } catch {}

  return [
    ...staticPages.map(p => ({ url: `${baseUrl}${p.url}`, lastModified: p.lastModified, changeFrequency: 'weekly' as const, priority: p.priority })),
    ...products.map((p: any) => ({ url: `${baseUrl}/products/${p.id}`, lastModified: p.updatedAt, changeFrequency: 'weekly' as const, priority: 0.8 })),
    ...blogPosts.map((p: any) => ({ url: `${baseUrl}/blog/${p.slug}`, lastModified: p.updatedAt, changeFrequency: 'monthly' as const, priority: 0.7 })),
  ];
}
