'use client';

import { useState, useEffect } from 'react';
import { Header } from '@/components/shop/header';
import { Footer } from '@/components/shop/footer';
import { CartDrawer } from '@/components/shop/cart-drawer';
import { Button } from '@/components/ui/button';
import { X, GitCompare, Check, Minus } from 'lucide-react';
import { formatPrice, toFa, parseColors } from '@/lib/shop-data';
import Link from 'next/link';
import { toast } from 'sonner';

export default function ComparePage() {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    // خواندن از localStorage
    const ids = JSON.parse(localStorage.getItem('compareList') || '[]');
    if (ids.length === 0) { setLoading(false); return; }

    Promise.all(ids.map((id: number) => fetch(`/api/shop/products/${id}`).then(r => r.json())))
      .then(results => {
        setProducts(results.filter(r => r.product).map(r => r.product));
        setLoading(false);
      });
  }, []);

  const removeFromCompare = (id: number) => {
    const ids = JSON.parse(localStorage.getItem('compareList') || '[]').filter((x: number) => x !== id);
    localStorage.setItem('compareList', JSON.stringify(ids));
    setProducts(products.filter(p => p.id !== id));
    toast.success('حذف شد');
  };

  const features = [
    { key: 'price', label: 'قیمت', render: (p: any) => `${formatPrice(p.discountPrice || p.price)} ت` },
    { key: 'brand', label: 'برند', render: (p: any) => p.brand },
    { key: 'category', label: 'دسته‌بندی', render: (p: any) => p.category },
    { key: 'woodType', label: 'نوع چوب', render: (p: any) => p.woodType || '-' },
    { key: 'rating', label: 'امتیاز', render: (p: any) => `${toFa(p.rating.toFixed(1))} (${toFa(p.ratingCount)})` },
    { key: 'fastDelivery', label: 'ارسال سریع', render: (p: any) => p.fastDelivery ? <Check className="w-4 h-4 text-green-500" /> : <Minus className="w-4 h-4 text-gray-300" /> },
    { key: 'inStock', label: 'موجودی', render: (p: any) => p.inStock ? <Check className="w-4 h-4 text-green-500" /> : <X className="w-4 h-4 text-red-500" /> },
    { key: 'discount', label: 'تخفیف', render: (p: any) => p.discountPercent ? `${toFa(p.discountPercent)}٪` : 'بدون تخفیف' },
    { key: 'colors', label: 'رنگ‌ها', render: (p: any) => {
      const colors = parseColors(p.colors);
      return colors.length > 0 ? (
        <div className="flex gap-1 justify-center">
          {colors.slice(0, 5).map((c: any, i: number) => <div key={i} className="w-4 h-4 rounded-full border border-gray-200" style={{ backgroundColor: c.code }} />)}
        </div>
      ) : '-';
    }},
  ];

  return (
    <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-6">
        <h1 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <GitCompare className="w-6 h-6 text-[#dc2626]" /> مقایسه محصولات
        </h1>

        {loading ? (
          <div className="text-center py-12"><div className="inline-block w-8 h-8 border-4 border-gray-200 border-t-[#dc2626] rounded-full animate-spin"></div></div>
        ) : products.length === 0 ? (
          <div className="bg-white rounded-xl p-12 text-center">
            <GitCompare className="w-16 h-16 mx-auto mb-3 text-gray-300" />
            <p className="text-gray-500 mb-4">محصولی برای مقایسه وجود ندارد</p>
            <Link href="/"><Button className="bg-[#dc2626] hover:bg-[#b91c1c]">شروع خرید</Button></Link>
          </div>
        ) : (
          <div className="bg-white rounded-xl shadow-sm overflow-x-auto">
            <table className="w-full min-w-[600px]">
              <thead>
                <tr className="border-b-2 border-gray-100">
                  <th className="p-3 text-right text-sm text-gray-500 w-32">ویژگی</th>
                  {products.map(p => (
                    <th key={p.id} className="p-3 text-center min-w-[180px]">
                      <button onClick={() => removeFromCompare(p.id)} className="float-left text-red-500 hover:bg-red-50 p-1 rounded">
                        <X className="w-4 h-4" />
                      </button>
                      <Link href={`/products/${p.id}`}>
                        <img src={p.image} alt={p.title} className="w-20 h-20 object-cover rounded-lg mx-auto mb-2" />
                        <p className="text-xs font-medium line-clamp-2">{p.title}</p>
                      </Link>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {features.map(f => (
                  <tr key={f.key} className="border-b border-gray-50 hover:bg-gray-50">
                    <td className="p-3 text-sm font-medium text-gray-600">{f.label}</td>
                    {products.map(p => (
                      <td key={p.id} className="p-3 text-center text-sm">{f.render(p)}</td>
                    ))}
                  </tr>
                ))}
                <tr>
                  <td className="p-3"></td>
                  {products.map(p => (
                    <td key={p.id} className="p-3 text-center">
                      <Link href={`/products/${p.id}`}>
                        <Button size="sm" className="bg-[#dc2626] hover:bg-[#b91c1c]">مشاهده</Button>
                      </Link>
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </main>
      <Footer />
      <CartDrawer />
    </div>
  );
}
