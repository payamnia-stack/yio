'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import { Header } from '@/components/shop/header';
import { Footer } from '@/components/shop/footer';
import { CartDrawer } from '@/components/shop/cart-drawer';
import { ProductCard } from '@/components/shop/product-card';
import { CategoryCircles } from '@/components/shop/category-circles';
import { Skeleton } from '@/components/ui/skeleton';
import Link from 'next/link';
import { toFa } from '@/lib/shop-data';

export default function CustomPage() {
  const params = useParams();
  const slug = params.slug as string;

  const [page, setPage] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/pages/${slug}`)
      .then(r => {
        if (!r.ok) throw new Error('not found');
        return r.json();
      })
      .then(data => setPage(data.page))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [slug]);

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
        <Header />
        <main className="flex-1 container mx-auto px-4 py-12">
          <Skeleton className="h-12 w-64 mb-4" />
          <Skeleton className="h-64 w-full" />
        </main>
        <Footer />
      </div>
    );
  }

  if (!page) {
    return (
      <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <p className="text-2xl font-bold text-gray-400 mb-4">۴۰۴</p>
            <p className="text-gray-500 mb-4">صفحه یافت نشد</p>
            <Link href="/" className="text-[#dc2626] hover:underline">بازگشت به خانه</Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
      <Header />
      <main className="flex-1 container mx-auto px-4 py-6 space-y-4">
        {page.blocks?.map((block: any) => (
          <BlockRenderer key={block.id} block={block} />
        ))}
      </main>
      <Footer />
      <CartDrawer />
    </div>
  );
}

function BlockRenderer({ block }: { block: any }) {
  let content: any = {};
  try { content = JSON.parse(block.content || '{}'); } catch {}

  switch (block.type) {
    case 'hero':
      return (
        <div
          className="rounded-xl p-8 md:p-12 text-white text-center"
          style={{ background: content.bgColor || 'linear-gradient(135deg, #dc2626, #991b1b)' }}
        >
          {block.title && <h1 className="text-3xl md:text-4xl font-bold mb-3">{block.title}</h1>}
          {content.subtitle && <p className="text-lg opacity-90 mb-5">{content.subtitle}</p>}
          {content.link && (
            <Link href={content.link} className="inline-block bg-white text-[#dc2626] font-bold px-6 py-2.5 rounded-lg hover:bg-gray-100">
              {content.buttonText || 'مشاهده'}
            </Link>
          )}
        </div>
      );

    case 'banner':
      return (
        <div
          className="rounded-xl p-6 flex items-center justify-between"
          style={{ background: content.bgColor || '#dc2626' }}
        >
          <div className="text-white">
            {block.title && <h3 className="text-xl font-bold mb-1">{block.title}</h3>}
            {content.text && <p className="text-sm opacity-90">{content.text}</p>}
          </div>
          {content.link && (
            <Link href={content.link} className="bg-white text-[#dc2626] font-bold px-4 py-2 rounded-lg hover:bg-gray-100 shrink-0">
              {content.buttonText || 'مشاهده'}
            </Link>
          )}
        </div>
      );

    case 'text':
      return (
        <div className="bg-white rounded-xl p-6">
          {block.title && <h2 className="text-xl font-bold mb-3">{block.title}</h2>}
          <p className="text-gray-700 leading-7">{content.text || block.title}</p>
        </div>
      );

    case 'cta':
      return (
        <div className="bg-white rounded-xl p-6 text-center">
          {block.title && <h3 className="text-lg font-bold mb-3">{block.title}</h3>}
          {content.link && (
            <Link href={content.link} className="inline-block bg-[#dc2626] text-white font-bold px-6 py-3 rounded-lg hover:bg-[#b91c1c]">
              {content.buttonText || 'کلیک کنید'}
            </Link>
          )}
        </div>
      );

    case 'categories':
      return <CategoryCircles />;

    default:
      return (
        <div className="bg-white rounded-xl p-6">
          <p className="text-gray-400 text-sm">بلوک نوع {block.type}</p>
        </div>
      );
  }
}
