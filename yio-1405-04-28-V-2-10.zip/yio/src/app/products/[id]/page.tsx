'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import {
  Star, Truck, ShieldCheck, ChevronRight, ChevronLeft,
  Heart, ShoppingCart, Share2, Package, Image as ImageIcon, Video,
  Play, CheckCircle2, ArrowLeft, Plus, Minus,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { Header } from '@/components/shop/header';
import { Footer } from '@/components/shop/footer';
import { CartDrawer } from '@/components/shop/cart-drawer';
import { DiscountTimer } from '@/components/shop/discount-timer';
import { useShopStore } from '@/store/shop-store';
import { formatPrice, toFa, parseColors, parseImages, parseVideos, getStockBadge, isProductAvailable, type Product } from '@/lib/shop-data';
import { useStockContext } from '@/components/shop/stock-provider';
import Link from 'next/link';

export default function ProductPage() {
  const params = useParams();
  const router = useRouter();
  const productId = params.id as string;

  const [product, setProduct] = useState<Product | null>(null);
  const [related, setRelated] = useState<Product[]>([]);
  const [smartRecs, setSmartRecs] = useState<{ products: Product[]; message: string }>({ products: [], message: '' });
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'images' | 'videos'>('images');
  const [currentIdx, setCurrentIdx] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState<string | undefined>();

  const addToCart = useShopStore(s => s.addToCart);
  const toggleFavorite = useShopStore(s => s.toggleFavorite);
  const favorites = useShopStore(s => s.favorites);
  const setCartOpen = useShopStore(s => s.setCartOpen);
  const { getStock } = useStockContext();

  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    fetch(`/api/shop/products/${productId}`)
      .then(r => r.json())
      .then(data => {
        if (data.product) {
          setProduct(data.product);
          setRelated(data.related || []);
          const colors = parseColors(data.product.colors as any);
          if (colors[0]) setSelectedColor(colors[0].name);
        } else {
          setNotFound(true);
        }
      })
      .catch(() => setNotFound(true))
      .finally(() => setLoading(false));

    // دریافت پیشنهاد هوشمند
    fetch(`/api/shop/products/${productId}/recommendations`)
      .then(r => r.json())
      .then(data => {
        if (data.recommendations && data.recommendations.length > 0) {
          setSmartRecs({ products: data.recommendations, message: data.message || 'پیشنهاد هوشمند' });
        }
      })
      .catch(() => {});
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productId]);

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="inline-block w-12 h-12 border-4 border-gray-200 border-t-[#dc2626] rounded-full animate-spin mb-4"></div>
            <p className="text-gray-500">در حال بارگذاری...</p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (notFound || !product) {
    return (
      <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
        <Header />
        <main className="flex-1 flex items-center justify-center px-4">
          <div className="text-center max-w-md">
            <div className="text-7xl mb-4">🔍</div>
            <h1 className="text-2xl font-bold text-gray-800 mb-2">محصول یافت نشد</h1>
            <p className="text-gray-500 mb-6">متأسفانه محصول مورد نظر شما وجود ندارد یا حذف شده است.</p>
            <Link href="/" className="inline-flex items-center gap-2 bg-[#dc2626] hover:bg-[#b91c1c] text-white px-6 py-3 rounded-lg font-medium transition-colors">
              <ArrowLeft className="w-4 h-4" />
              بازگشت به فروشگاه
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!product) return null;

  const allImages = parseImages(product.images);
  const finalImages = product.image && !allImages.includes(product.image)
    ? [product.image, ...allImages]
    : allImages.length > 0 ? allImages : [product.image];
  const videos = parseVideos(product.videos);
  const colors = parseColors(product.colors as any);
  const isFavorite = favorites.includes(product.id);

  const finalPrice = product.discountPrice ?? product.price;
  const total = finalPrice * quantity;
  // دریافت موجودی real-time (اگر آپدیتی از SSE آمده باشد)
  const realtimeStock = getStock(product.id, product.stockQuantity);
  const stockInfo = getStockBadge(realtimeStock);
  const available = realtimeStock === undefined
    ? isProductAvailable(product)
    : realtimeStock > 0;

  // schema.org JSON-LD برای سئو
  const productSchema = {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: product.title,
    image: finalImages,
    description: product.description || product.title,
    brand: { '@type': 'Brand', name: product.brand },
    category: product.category,
    offers: {
      '@type': 'Offer',
      price: (product.discountPrice ?? product.price).toString(),
      priceCurrency: 'IRR',
      availability: available ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
    },
    aggregateRating: product.ratingCount > 0 ? {
      '@type': 'AggregateRating',
      ratingValue: product.rating,
      reviewCount: product.ratingCount,
    } : undefined,
  };

  const handleAddToCart = () => {
    if (!available) {
      toast.error('این محصول در حال حاضر ناموجود است');
      return;
    }
    addToCart(product as any, selectedColor);
    toast.success('به سبد خرید اضافه شد');
    setCartOpen(true);
  };

  const handleFavorite = () => {
    toggleFavorite(product.id);
    toast.success(isFavorite ? 'از علاقه‌مندی‌ها حذف شد' : 'به علاقه‌مندی‌ها اضافه شد');
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({ title: product.title, url: window.location.href });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast.success('لینک کپی شد');
    }
  };

  const nextItem = () => {
    const max = activeTab === 'images' ? finalImages.length : videos.length;
    setCurrentIdx(prev => (prev + 1) % max);
  };

  const prevItem = () => {
    const max = activeTab === 'images' ? finalImages.length : videos.length;
    setCurrentIdx(prev => (prev - 1 + max) % max);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#f0f0f1]">
      {/* schema.org برای سئو */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(productSchema) }}
      />
      <Header />

      <main className="flex-1 container mx-auto px-4 py-6">
        {/* breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
          <Link href="/" className="hover:text-[#dc2626]">خانه</Link>
          <ChevronLeft className="w-4 h-4" />
          <Link href={`/category/${encodeURIComponent(product.category)}`} className="hover:text-[#dc2626]">
            {product.category}
          </Link>
          <ChevronLeft className="w-4 h-4" />
          <span className="text-gray-700 line-clamp-1">{product.title}</span>
        </div>

        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 p-4 md:p-6">
            {/* بخش تصاویر */}
            <div className="space-y-3">
              <div className="relative aspect-square bg-gray-100 rounded-xl overflow-hidden">
                {activeTab === 'images' ? (
                  <img
                    src={finalImages[currentIdx]}
                    alt={product.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <video
                    src={videos[currentIdx]}
                    className="w-full h-full object-cover"
                    controls
                    autoPlay
                    playsInline
                  />
                )}

                {((activeTab === 'images' && finalImages.length > 1) || (activeTab === 'videos' && videos.length > 1)) && (
                  <>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={prevItem}
                      className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white"
                    >
                      <ChevronRight className="w-6 h-6" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={nextItem}
                      className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white"
                    >
                      <ChevronLeft className="w-6 h-6" />
                    </Button>
                  </>
                )}

                <div className="absolute bottom-2 left-2 bg-black/60 text-white text-xs px-2 py-1 rounded fa-num">
                  {toFa(currentIdx + 1)} / {toFa(activeTab === 'images' ? finalImages.length : videos.length)}
                </div>

                {product.discountPercent && (
                  <div className="absolute top-3 right-3 bg-[#dc2626] text-white text-sm font-bold px-3 py-1.5 rounded-lg fa-num">
                    {toFa(product.discountPercent)}٪ تخفیف
                  </div>
                )}
              </div>

              {/* تب‌ها */}
              {videos.length > 0 && (
                <div className="flex gap-2">
                  <button
                    onClick={() => { setActiveTab('images'); setCurrentIdx(0); }}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm ${
                      activeTab === 'images' ? 'bg-[#dc2626] text-white' : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    <ImageIcon className="w-4 h-4" />
                    تصاویر ({toFa(finalImages.length)})
                  </button>
                  <button
                    onClick={() => { setActiveTab('videos'); setCurrentIdx(0); }}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm ${
                      activeTab === 'videos' ? 'bg-[#dc2626] text-white' : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    <Video className="w-4 h-4" />
                    ویدیوها ({toFa(videos.length)})
                  </button>
                </div>
              )}

              {/* تصاویر کوچک */}
              {activeTab === 'images' && finalImages.length > 1 && (
                <div className="grid grid-cols-5 gap-2">
                  {finalImages.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setCurrentIdx(idx)}
                      className={`aspect-square rounded-lg overflow-hidden border-2 ${
                        currentIdx === idx ? 'border-[#dc2626]' : 'border-transparent opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}

              {activeTab === 'videos' && videos.length > 1 && (
                <div className="grid grid-cols-3 gap-2">
                  {videos.map((video, idx) => (
                    <button
                      key={idx}
                      onClick={() => setCurrentIdx(idx)}
                      className={`aspect-video rounded-lg overflow-hidden border-2 relative bg-gray-900 ${
                        currentIdx === idx ? 'border-[#dc2626]' : 'border-transparent opacity-60'
                      }`}
                    >
                      <video src={video} className="w-full h-full object-cover" muted preload="metadata" />
                      <Play className="w-6 h-6 text-white absolute inset-0 m-auto" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* بخش اطلاعات */}
            <div className="space-y-4">
              <div className="flex flex-wrap gap-2">
                <span className="bg-gray-100 text-gray-700 text-xs px-3 py-1 rounded-full">{product.brand}</span>
                {product.woodType && (
                  <span className="bg-amber-50 text-amber-700 text-xs px-3 py-1 rounded-full">🪵 {product.woodType}</span>
                )}
                <span className="bg-gray-100 text-gray-700 text-xs px-3 py-1 rounded-full">{product.category}</span>
              </div>

              <h1 className="text-2xl font-bold text-gray-900">{product.title}</h1>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 bg-amber-50 px-3 py-1.5 rounded-lg">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span className="font-bold fa-num">{toFa(product.rating.toFixed(1))}</span>
                </div>
                <span className="text-sm text-gray-500 fa-num">({toFa(product.ratingCount)} نظر)</span>
              </div>

              {/* قیمت */}
              <div className="bg-gradient-to-l from-red-50 to-transparent p-4 rounded-xl">
                {product.discountPercent ? (
                  <div className="flex items-end gap-3">
                    <div>
                      <span className="text-sm text-gray-400 line-through fa-num block">
                        {formatPrice(product.price)} ت
                      </span>
                      <span className="text-3xl font-bold text-[#dc2626] fa-num">
                        {formatPrice(finalPrice)}
                        <span className="text-base mr-1">تومان</span>
                      </span>
                    </div>
                    <span className="bg-[#dc2626] text-white text-sm px-2 py-1 rounded fa-num mb-2">
                      {toFa(product.discountPercent)}٪
                    </span>
                  </div>
                ) : (
                  <span className="text-3xl font-bold text-gray-900 fa-num">
                    {formatPrice(finalPrice)}
                    <span className="text-base mr-1">تومان</span>
                  </span>
                )}
              </div>

              {/* رنگ‌ها */}
              {colors.length > 0 && (
                <div className="space-y-2">
                  <label className="text-sm font-medium">رنگ: {selectedColor}</label>
                  <div className="flex gap-2">
                    {colors.map(color => (
                      <button
                        key={color.name}
                        onClick={() => setSelectedColor(color.name)}
                        className={`w-10 h-10 rounded-full border-2 transition-all ${
                          selectedColor === color.name ? 'border-[#dc2626] scale-110' : 'border-gray-200'
                        }`}
                        style={{ backgroundColor: color.code }}
                        title={color.name}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* تعداد */}
              <div className="space-y-2">
                <label className="text-sm font-medium">تعداد</label>
                <div className="flex items-center gap-2 bg-gray-100 rounded-lg p-1 w-fit">
                  <button onClick={() => setQuantity(q => Math.min(99, q + 1))} className="w-9 h-9 flex items-center justify-center hover:bg-white rounded">
                    <Plus className="w-4 h-4" />
                  </button>
                  <span className="w-12 text-center font-bold fa-num">{toFa(quantity)}</span>
                  <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="w-9 h-9 flex items-center justify-center hover:bg-white rounded">
                    <Minus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* مجموع */}
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm text-gray-600">مجموع:</span>
                <span className="text-xl font-bold text-[#dc2626] fa-num">{formatPrice(total)} ت</span>
              </div>

              {/* تایمر تخفیف */}
              {product.discountPercent && (
                <DiscountTimer endDate={product.updatedAt ? new Date(new Date(product.updatedAt).getTime() + 7 * 24 * 60 * 60 * 1000).toISOString() : null} />
              )}

              {/* Badge موجودی — متن رنگی بدون پس‌زمینه */}
              <div className={`inline-flex items-center gap-2 ${stockInfo.textClass} text-sm font-bold w-fit fa-num`}>
                <span className={`w-2 h-2 rounded-full ${stockInfo.dotClass} ${stockInfo.isOutOfStock ? 'animate-pulse' : ''}`}></span>
                {stockInfo.countLabel}
              </div>

              {/* دکمه‌ها */}
              <div className="flex gap-2">
                <Button
                  onClick={handleAddToCart}
                  disabled={!available}
                  className={`flex-1 ${available ? 'bg-[#dc2626] hover:bg-[#b91c1c]' : 'bg-gray-300 hover:bg-gray-300 cursor-not-allowed'} h-12 text-base`}
                >
                  <ShoppingCart className="w-5 h-5 ml-2" />
                  {available ? 'افزودن به سبد' : 'ناموجود'}
                </Button>
                <Button
                  onClick={handleFavorite}
                  variant="outline"
                  size="icon"
                  className="h-12 w-12 border-[#dc2626]"
                >
                  <Heart className={`w-5 h-5 ${isFavorite ? 'fill-[#dc2626] text-[#dc2626]' : 'text-[#dc2626]'}`} />
                </Button>
                <Button
                  onClick={handleShare}
                  variant="outline"
                  size="icon"
                  className="h-12 w-12"
                >
                  <Share2 className="w-5 h-5" />
                </Button>
              </div>

              {/* ویژگی‌ها */}
              <div className="grid grid-cols-3 gap-2 pt-2">
                <div className="bg-green-50 rounded-lg p-3 text-center">
                  <Truck className="w-5 h-5 text-green-600 mx-auto mb-1" />
                  <p className="text-xs text-green-700">{product.fastDelivery ? 'ارسال سریع' : 'ارسال عادی'}</p>
                </div>
                <div className="bg-blue-50 rounded-lg p-3 text-center">
                  <ShieldCheck className="w-5 h-5 text-blue-600 mx-auto mb-1" />
                  <p className="text-xs text-blue-700">ضمانت اصالت</p>
                </div>
                <div className="bg-purple-50 rounded-lg p-3 text-center">
                  <Package className="w-5 h-5 text-purple-600 mx-auto mb-1" />
                  <p className="text-xs text-purple-700">{available ? 'موجود' : 'ناموجود'}</p>
                </div>
              </div>
            </div>
          </div>

          {/* توضیحات */}
          {product.description && (
            <div className="p-4 md:p-6 border-t border-gray-100">
              <h2 className="font-bold text-lg mb-3">توضیحات محصول</h2>
              <p className="text-gray-700 leading-7">{product.description}</p>
            </div>
          )}
        </div>

        {/* محصولات مرتبط */}
        {related.length > 0 && (
          <div className="mt-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold">محصولات مرتبط</h2>
              <Link href={`/category/${encodeURIComponent(product.category)}`} className="text-[#dc2626] text-sm hover:underline">
                مشاهده همه
              </Link>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
              {related.map(p => (
                <Link key={p.id} href={`/products/${p.id}`} className="bg-white rounded-lg border border-gray-100 hover:shadow-md transition-all overflow-hidden">
                  <div className="aspect-square bg-gray-50 overflow-hidden">
                    <img src={p.image} alt={p.title} className="w-full h-full object-cover hover:scale-105 transition-transform" />
                  </div>
                  <div className="p-3">
                    <h3 className="text-sm font-medium line-clamp-2 mb-2">{p.title}</h3>
                    <p className="font-bold text-[#dc2626] fa-num">{formatPrice(p.discountPrice || p.price)} ت</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* پیشنهاد هوشمند */}
        {smartRecs.products.length > 0 && (
          <div className="mt-8">
            <div className="flex items-center gap-2 mb-4">
              <span className="bg-purple-100 text-purple-700 text-xs px-3 py-1 rounded-full flex items-center gap-1">
                🧠 هوشمند
              </span>
              <h2 className="text-xl font-bold">{smartRecs.message}</h2>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              {smartRecs.products.map(p => (
                <Link key={p.id} href={`/products/${p.id}`} className="bg-white rounded-lg border border-gray-100 hover:shadow-md transition-all overflow-hidden">
                  <div className="aspect-square bg-gray-50 overflow-hidden">
                    <img src={p.image} alt={p.title} className="w-full h-full object-cover hover:scale-105 transition-transform" />
                  </div>
                  <div className="p-2">
                    <h3 className="text-xs font-medium line-clamp-2 mb-1">{p.title}</h3>
                    <p className="font-bold text-[#dc2626] fa-num text-sm">{formatPrice(p.discountPrice || p.price)} ت</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </main>

      <Footer />
      <CartDrawer />
    </div>
  );
}
