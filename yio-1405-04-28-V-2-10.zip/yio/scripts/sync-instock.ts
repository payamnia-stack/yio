// Sync inStock field with stockQuantity for all products
// (one-time fix for legacy data)
import { db } from '../src/lib/db';

async function main() {
  console.log('همگام‌سازی inStock با stockQuantity...');
  const products = await db.product.findMany({ select: { id: true, stockQuantity: true, inStock: true } });
  let updated = 0;
  for (const p of products) {
    const shouldBeInStock = (p.stockQuantity || 0) > 0;
    if (p.inStock !== shouldBeInStock) {
      await db.product.update({
        where: { id: p.id },
        data: { inStock: shouldBeInStock },
      });
      console.log(`  ✓ Product ${p.id}: stockQuantity=${p.stockQuantity} → inStock=${shouldBeInStock}`);
      updated++;
    }
  }
  console.log(`\n✅ ${updated} محصول از ${products.length} محصول آپدیت شد`);
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());
