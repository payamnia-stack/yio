import { db } from '@/lib/db';
async function main() {
  const categories = await db.category.findMany({ select: { id: true, title: true, slug: true } });
  console.log('Categories:', JSON.stringify(categories, null, 2));
  const products = await db.product.groupBy({ by: ['category'], _count: true });
  console.log('Products by category:', JSON.stringify(products, null, 2));
  await db.$disconnect();
}
main();
