// تولید API Key برای اتصال n8n به سایت YIO
import { db } from '@/lib/db';
import crypto from 'crypto';

async function main() {
  const apiKey = crypto.randomBytes(24).toString('hex');

  // ذخیره در دیتابیس
  const existing = await db.siteSetting.findUnique({ where: { key: 'api_key' } });
  if (existing) {
    await db.siteSetting.update({ where: { key: 'api_key' }, data: { value: apiKey } });
    console.log('✅ API Key به‌روزرسانی شد');
  } else {
    await db.siteSetting.create({ data: { key: 'api_key', value: apiKey, category: 'security' } });
    console.log('✅ API Key جدید ساخته شد');
  }

  console.log('');
  console.log('📋 API KEY شما:');
  console.log(apiKey);
  console.log('');
  console.log('🔗 آدرس API سایت شما:');
  console.log('http://130.185.78.113/api/external');
  console.log('');
  console.log('📌 نحوه استفاده در n8n:');
  console.log('در نود HTTP Request، در بخش Headers این را اضافه کنید:');
  console.log('Name: Authorization');
  console.log('Value: Bearer ' + apiKey);

  await db.$disconnect();
}

main();
