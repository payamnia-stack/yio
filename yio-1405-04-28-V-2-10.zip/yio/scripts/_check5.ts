import { db } from '@/lib/db';
async function main() {
  // The actual category name in products
  const sampleProduct = await db.product.findFirst({ select: { title: true, category: true } });
  console.log('Sample product:', JSON.stringify(sampleProduct, null, 2));
  console.log('Category codepoints:', sampleProduct ? Array.from(sampleProduct.category).map(c => c.charCodeAt(0).toString(16)).join(',') : 'n/a');
  
  // Try to query
  const testCat1 = 'اسباب-بازی-چوبی';  // with hyphen
  const testCat2 = 'اسباب‌بازی چوبی';  // with ZWNJ and space
  
  const count1 = await db.product.count({ where: { category: testCat1 } });
  const count2 = await db.product.count({ where: { category: testCat2 } });
  
  console.log(`Count for "${testCat1}": ${count1}`);
  console.log(`Count for "${testCat2}": ${count2}`);
  
  await db.$disconnect();
}
main();
