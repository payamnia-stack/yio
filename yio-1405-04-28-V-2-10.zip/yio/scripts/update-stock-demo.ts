// Update product stockQuantity to demonstrate the 4 badge colors
// 0=red, 1-3=orange, 4-6=yellow, 7+=green
// IDs are now resolved dynamically (since deleteMany resets IDs)
import { db } from '../src/lib/db';

async function main() {
  console.log('Updating stock quantities...');

  // Get all products ordered by id
  const products = await db.product.findMany({
    select: { id: true },
    orderBy: { id: 'asc' },
  });

  if (products.length === 0) {
    console.log('⚠️  هیچ محصولی یافت نشد. ابتدا seed.ts را اجرا کنید.');
    process.exit(0);
  }

  // Distribution pattern (cycling through colors):
  // green=7+, yellow=4-6, orange=1-3, red=0
  const stockValues = [
    15, // green
    10, // green
    8,  // green
    5,  // yellow
    6,  // yellow
    4,  // yellow
    3,  // orange
    2,  // orange
    1,  // orange
    0,  // red (ناموجود)
    25, // green
    12, // green
    5,  // yellow
    3,  // orange
    0,  // red
    7,  // green
    4,  // yellow
    2,  // orange
    0,  // red
    9,  // green
  ];

  for (let i = 0; i < products.length; i++) {
    const product = products[i];
    const qty = stockValues[i % stockValues.length];
    await db.product.update({
      where: { id: product.id },
      data: {
        stockQuantity: qty,
        inStock: qty > 0,
      },
    });
    const color = qty === 0 ? '🔴 red' : qty <= 3 ? '🟠 orange' : qty <= 6 ? '🟡 yellow' : '🟢 green';
    console.log(`  Product ${product.id.toString().padStart(2)} → qty=${qty.toString().padStart(2)}  ${color}`);
  }

  console.log(`\n✅ Done! Updated ${products.length} products`);
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());
