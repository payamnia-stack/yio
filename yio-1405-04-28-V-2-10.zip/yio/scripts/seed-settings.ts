// Seed site settings and categories
import { db } from '../src/lib/db';

const defaultSettings = [
  // اطلاعات تماس
  { key: 'contact_phone', value: '۰۲۱-۹۱۰۰۲۰۲۰', category: 'contact' },
  { key: 'contact_email', value: 'info@yio-shop.ir', category: 'contact' },
  { key: 'contact_address', value: 'تهران، خیابان ولیعصر، کارگاه تولید چوب YIO', category: 'contact' },
  { key: 'contact_hours', value: 'شنبه تا چهارشنبه: ۹ تا ۱۸\nپنجشنبه: ۹ تا ۱۳\nجمعه: تعطیل', category: 'contact' },

  // درباره ما
  { key: 'about_title', value: 'درباره YIO', category: 'about' },
  { key: 'about_subtitle', value: 'محصولات چوبی دست‌ساز با عشق و هنر ایرانی', category: 'about' },
  { key: 'about_story', value: 'YIO با عشق به چوب و هنر دست‌ساز ایرانی شروع شد. ما باور داریم که چوب طبیعی نه تنها زیباست، بلکه دوست‌دار محیط زیست و ایمن برای کودکان و خانواده‌هاست. هر محصول YIO با دقت و هنر توسط صنعتگران ماهر ایرانی ساخته می‌شود.', category: 'about' },
  { key: 'about_mission', value: 'هدف ما این است که محصولات چوبی با کیفیت و زیبا را با قیمت منصفانه به دست شما برسانیم و در عین حال از هنر و صنعت ایرانی حمایت کنیم.', category: 'about' },

  // فوتر
  { key: 'footer_description', value: 'YIO برند تخصصی محصولات چوبی دست‌ساز. ما با بهره‌گیری از چوب‌های طبیعی و مرغوب، اسباب‌بازی، ظروف آشپزخانه، مبلمان و دکوراسیون چوبی با کیفیت و ایمن تولید می‌کنیم.', category: 'footer' },
  { key: 'footer_copyright', value: 'کلیه حقوق این سایت متعلق به YIO می‌باشد © ۱۴۰۳', category: 'footer' },

  // شبکه‌های اجتماعی
  { key: 'social_instagram', value: 'https://instagram.com/yio_shop', category: 'social' },
  { key: 'social_telegram', value: 'https://t.me/yio_shop', category: 'social' },
  { key: 'social_whatsapp', value: 'https://wa.me/989120000000', category: 'social' },

  // عمومی
  { key: 'site_title', value: 'YIO | محصولات چوبی دست‌ساز', category: 'general' },
  { key: 'site_description', value: 'خرید اینترنتی اسباب‌بازی چوبی، ظروف آشپزخانه، مبلمان و دکوراسیون چوبی دست‌ساز', category: 'general' },
  { key: 'free_shipping_threshold', value: '500000', category: 'general' },
  { key: 'shipping_cost', value: '89000', category: 'general' },
];

const defaultCategories = [
  { title: 'اسباب‌بازی چوبی', icon: '🧸', color: '#f59e0b', order: 1 },
  { title: 'ظروف آشپزخانه', icon: '🍽️', color: '#84cc16', order: 2 },
  { title: 'مبلمان چوبی', icon: '🪑', color: '#8b5cf6', order: 3 },
  { title: 'دکوراسیون چوبی', icon: '🖼️', color: '#dc2626', order: 4 },
  { title: 'لوازم کودک', icon: '👶', color: '#06b6d4', order: 5 },
  { title: 'هدیه و صنایع دستی', icon: '🎁', color: '#ec4899', order: 6 },
  { title: 'نقاشی و هنر', icon: '🎨', color: '#7c3aed', order: 7 },
  { title: 'باغ و حیاط', icon: '🌳', color: '#10b981', order: 8 },
];

async function main() {
  console.log('افزودن تنظیمات سایت...');

  for (const s of defaultSettings) {
    await db.siteSetting.upsert({
      where: { key: s.key },
      update: { value: s.value },
      create: s,
    });
  }
  console.log(`✅ ${defaultSettings.length} تنظیم پیش‌فرض اضافه شد`);

  console.log('افزودن دسته‌بندی‌ها...');
  for (const c of defaultCategories) {
    const slug = c.title.replace(/\s+/g, '-');
    await db.category.upsert({
      where: { slug },
      update: {},
      create: { ...c, slug },
    });
  }
  console.log(`✅ ${defaultCategories.length} دسته‌بندی اضافه شد`);
}

main()
  .catch(e => { console.error('خطا:', e); process.exit(1); })
  .finally(async () => { await db.$disconnect(); });
