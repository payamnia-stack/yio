import { db } from '@/lib/db';
async function main() {
  // Reset all to non-default, then set only one to default
  await db.paymentMethod.updateMany({ where: { isDefault: true }, data: { isDefault: false } });
  await db.paymentMethod.updateMany({ where: { type: 'cod' }, data: { isDefault: true } });
  const methods = await db.paymentMethod.findMany({ select: { id: true, name: true, isDefault: true } });
  console.log(JSON.stringify(methods, null, 2));
  await db.$disconnect();
}
main();
