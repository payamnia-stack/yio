// Seed SMS panel and Email SMTP settings + create IncomingEmail table
import { db } from '../src/lib/db';

const defaultSettings = [
  // ===== تنظیمات پنل پیامکی =====
  {
    key: 'sms_enabled',
    value: 'false',
    category: 'sms',
  },
  {
    key: 'sms_provider',
    value: 'kavenegar', // kavenegar | melipayamak | farapayamak | smsir | custom
    category: 'sms',
  },
  {
    key: 'sms_api_key',
    value: '',
    category: 'sms',
  },
  {
    key: 'sms_sender_number',
    value: '',
    category: 'sms',
  },
  {
    key: 'sms_api_url',
    value: '', // برای custom provider
    category: 'sms',
  },
  {
    // قالب پیامک تایید (متغیر {{code}} جایگزین می‌شود)
    key: 'sms_otp_template',
    value: 'YIO\nکد تایید شما: {{code}}\nاین کد تا ۱۰ دقیقه معتبر است.',
    category: 'sms',
  },
  {
    // قالب پیامک خوش‌آمدگویی
    key: 'sms_welcome_template',
    value: 'YIO\n{{name}} عزیز، به خانواده YIO خوش آمدید!',
    category: 'sms',
  },
  {
    // قالب پیامک وضعیت سفارش
    key: 'sms_order_template',
    value: 'YIO\nسفارش {{orderNumber}} شما وضعیت «{{status}}» گرفت.',
    category: 'sms',
  },

  // ===== تنظیمات SMTP ایمیل =====
  {
    key: 'email_enabled',
    value: 'false',
    category: 'email',
  },
  {
    key: 'email_smtp_host',
    value: 'smtp.gmail.com',
    category: 'email',
  },
  {
    key: 'email_smtp_port',
    value: '587',
    category: 'email',
  },
  {
    // none | ssl | tls
    key: 'email_smtp_secure',
    value: 'tls',
    category: 'email',
  },
  {
    key: 'email_smtp_user',
    value: '',
    category: 'email',
  },
  {
    key: 'email_smtp_password',
    value: '',
    category: 'email',
  },
  {
    key: 'email_from_address',
    value: 'noreply@yio-shop.ir',
    category: 'email',
  },
  {
    key: 'email_from_name',
    value: 'YIO فروشگاه چوب',
    category: 'email',
  },
  {
    // ایمیل‌هایی که پیام‌های ورودی به آن‌ها ارسال می‌شود (با | جدا شوند)
    key: 'email_inbox_recipients',
    value: 'admin@yio-shop.ir',
    category: 'email',
  },
  {
    // قالب ایمیل تایید
    key: 'email_otp_template',
    value: 'سلام {{name}}،\n\nکد تایید شما در فروشگاه YIO: {{code}}\nاین کد تا ۱۰ دقیقه معتبر است.\n\nبا احترام،\nتیم YIO',
    category: 'email',
  },

  // ===== تنظیمات ورود سریع =====
  {
    // آیا کپچا در ورود سریع فعال باشد؟
    key: 'captcha_enabled',
    value: 'true',
    category: 'auth',
  },
  {
    // نوع کپچا: math (ریاضی ساده) | recaptcha | none
    key: 'captcha_type',
    value: 'math',
    category: 'auth',
  },
];

async function main() {
  console.log('افزودن تنظیمات پنل پیامکی و ایمیل...');
  for (const s of defaultSettings) {
    await db.siteSetting.upsert({
      where: { key: s.key },
      update: {},
      create: s,
    });
    console.log(`  ✓ ${s.key} = ${s.value.slice(0, 50)}${s.value.length > 50 ? '...' : ''}`);
  }

  // ساخت جدول IncomingEmail اگر وجود ندارد
  console.log('\nبررسی جدول IncomingEmail...');
  try {
    await db.$executeRaw`
      CREATE TABLE IF NOT EXISTS IncomingEmail (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fromEmail TEXT NOT NULL,
        fromName TEXT,
        toEmail TEXT NOT NULL,
        subject TEXT NOT NULL,
        body TEXT,
        isRead INTEGER DEFAULT 0,
        isStarred INTEGER DEFAULT 0,
        category TEXT DEFAULT 'inbox',
        receivedAt DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `;
    console.log('  ✓ جدول IncomingEmail ایجاد شد');
  } catch (e: any) {
    if (e.message.includes('already exists')) {
      console.log('  ✓ جدول IncomingEmail از قبل وجود دارد');
    } else {
      console.error('  ✗ خطا در ساخت جدول:', e.message);
    }
  }

  // ساخت ایندکس‌ها
  try {
    await db.$executeRaw`CREATE INDEX IF NOT EXISTS idx_incoming_email_isRead ON IncomingEmail(isRead)`;
    await db.$executeRaw`CREATE INDEX IF NOT EXISTS idx_incoming_email_receivedAt ON IncomingEmail(receivedAt)`;
    await db.$executeRaw`CREATE INDEX IF NOT EXISTS idx_incoming_email_category ON IncomingEmail(category)`;
  } catch (e: any) {
    console.log('  (ایندکس‌ها از قبل وجود دارند)');
  }

  console.log('\n✅ تنظیمات پیامک و ایمیل با موفقیت اضافه شد');
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());
