import { db } from '@/lib/db';
async function main() {
  const cats = await db.category.findMany({ select: { title: true, slug: true } });
  for (const c of cats) {
    console.log(`Title: "${c.title}" (length=${c.title.length}, codepoints=[${Array.from(c.title).map(ch => ch.charCodeAt(0).toString(16)).join(',')}])`);
    console.log(`Slug: "${c.slug}" (length=${c.slug.length}, codepoints=[${Array.from(c.slug).map(ch => ch.charCodeAt(0).toString(16)).join(',')}])`);
    console.log('---');
  }
  await db.$disconnect();
}
main();
