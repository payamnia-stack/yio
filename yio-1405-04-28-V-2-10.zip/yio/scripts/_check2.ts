import { db } from '@/lib/db';
async function main() {
  // Get all category slugs
  const cats = await db.category.findMany({ select: { title: true, slug: true } });
  console.log('Categories:', JSON.stringify(cats, null, 2));
  
  // Test: if I look up by slug, what do I get?
  const testSlug = 'اسباب-بازی-چوبی';
  const match = cats.find(c => c.title === testSlug);
  console.log('Match for slug-as-title:', match);
  
  const matchBySlug = cats.find(c => c.slug === testSlug);
  console.log('Match by slug:', matchBySlug);
  
  await db.$disconnect();
}
main();
