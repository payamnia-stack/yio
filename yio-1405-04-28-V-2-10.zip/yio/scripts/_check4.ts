async function main() {
  // The URL-encoded slug from browser
  const url = 'http://localhost:3000/category/%D8%A7%D8%B3%D8%A8%D8%A7%D8%A8%E2%80%8C%D8%A8%D8%A7%D8%B2%DB%8C-%DA%86%D9%88%D8%A8%DB%8C';
  const urlObj = new URL(url);
  const slug = decodeURIComponent(urlObj.pathname.split('/').pop() || '');
  console.log('Decoded slug:', JSON.stringify(slug));
  console.log('Codepoints:', Array.from(slug).map(c => c.charCodeAt(0).toString(16)).join(','));
  
  // The DB slug
  const dbSlug = 'اسباب‌بازی-چوبی';
  console.log('DB slug:', JSON.stringify(dbSlug));
  console.log('DB Codepoints:', Array.from(dbSlug).map(c => c.charCodeAt(0).toString(16)).join(','));
  
  console.log('Equal?', slug === dbSlug);
}
main();
