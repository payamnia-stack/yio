import { db } from '@/lib/db';
async function main() {
  const orders = await db.order.findMany({ select: { id: true, orderNumber: true, recipientPhone: true }, take: 3 });
  console.log(JSON.stringify(orders, null, 2));
  await db.$disconnect();
}
main();
