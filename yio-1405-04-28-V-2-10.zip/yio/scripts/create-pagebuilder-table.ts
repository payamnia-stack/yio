// ساخت جدول PageBuilderPage برای صفحه‌ساز حرفه‌ای
// اجرا: bun run scripts/create-pagebuilder-table.ts
import { db } from '@/lib/db';

async function main() {
  console.log('📝 ساخت جدول PageBuilderPage...');

  try {
    await db.$executeRaw`
      CREATE TABLE IF NOT EXISTS "PageBuilderPage" (
          "id" TEXT PRIMARY KEY,
          "name" TEXT NOT NULL,
          "slug" TEXT NOT NULL UNIQUE,
          "content" TEXT NOT NULL DEFAULT '[]',
          "status" TEXT NOT NULL DEFAULT 'draft',
          "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
          "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      )
    `;
    console.log('✅ جدول PageBuilderPage ساخته شد');

    await db.$executeRaw`
      CREATE INDEX IF NOT EXISTS "PageBuilderPage_slug_idx" ON "PageBuilderPage"("slug")
    `;
    console.log('✅ ایندکس slug ساخته شد');

    // بررسی اینکه جدول ساخته شده
    const result = await db.$queryRaw`
      SELECT name FROM sqlite_master WHERE type='table' AND name='PageBuilderPage'
    `;
    if (Array.isArray(result) && result.length > 0) {
      console.log('✅ تأیید: جدول PageBuilderPage وجود دارد');
    } else {
      console.log('❌ خطا: جدول ساخته نشد');
    }
  } catch (error) {
    console.error('❌ خطا:', error);
  }

  await db.$disconnect();
}

main();
