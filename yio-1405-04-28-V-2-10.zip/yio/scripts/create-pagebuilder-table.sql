-- ساخت جدول PageBuilderPage برای صفحه‌ساز حرفه‌ای
CREATE TABLE IF NOT EXISTS "PageBuilderPage" (
    "id" TEXT PRIMARY KEY,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL UNIQUE,
    "content" TEXT NOT NULL DEFAULT '[]',
    "status" TEXT NOT NULL DEFAULT 'draft',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS "PageBuilderPage_slug_idx" ON "PageBuilderPage"("slug");
