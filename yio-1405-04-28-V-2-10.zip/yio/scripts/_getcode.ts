import { db } from '@/lib/db';
async function main() {
  const u = await db.user.findFirst({ orderBy: { id: 'desc' }, select: { id: true, phone: true, verifyCode: true } });
  console.log(JSON.stringify(u));
  await db.$disconnect();
}
main();
