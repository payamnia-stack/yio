// ایجاد صفحات سیستم پیش‌فرض
import { db } from '@/lib/db';

const systemPages = [
  { slug: 'home', title: 'صفحه اصلی', type: 'home', isPublished: true, showInMenu: false, menuLabel: null, order: 0 },
  { slug: 'about', title: 'درباره ما', type: 'about', isPublished: true, showInMenu: false, menuLabel: null, order: 1 },
  { slug: 'contact', title: 'تماس با ما', type: 'contact', isPublished: true, showInMenu: false, menuLabel: null, order: 2 },
  { slug: 'faq', title: 'سؤالات متداول', type: 'faq', isPublished: true, showInMenu: false, menuLabel: null, order: 3 },
  { slug: 'blog', title: 'بلاگ', type: 'custom', isPublished: true, showInMenu: false, menuLabel: null, order: 4 },
  { slug: 'special', title: 'شگفت‌انگیزها', type: 'custom', isPublished: true, showInMenu: false, menuLabel: null, order: 5 },
  { slug: 'wholesale', title: 'سفارش عمده', type: 'custom', isPublished: true, showInMenu: false, menuLabel: null, order: 6 },
  { slug: 'compare', title: 'مقایسه محصولات', type: 'custom', isPublished: true, showInMenu: false, menuLabel: null, order: 7 },
];

async function main() {
  console.log('ساخت صفحات سیستم...');
  
  for (const page of systemPages) {
    const existing = await db.page.findUnique({ where: { slug: page.slug } });
    if (!existing) {
      await db.page.create({ data: page });
      console.log(`✅ صفحه "${page.title}" ایجاد شد`);
    } else {
      console.log(`⚠️ صفحه "${page.title}" از قبل وجود دارد`);
    }
  }

  const total = await db.page.count();
  console.log(`\n📊 مجموع صفحات: ${total}`);
  await db.$disconnect();
}

main().catch(console.error);
