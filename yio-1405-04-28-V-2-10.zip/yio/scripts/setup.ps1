# ============================================================
# راه‌اندازی فروشگاه YIO روی ویندوز
# ============================================================
# استفاده: PowerShell را باز کنید و این فایل را اجرا کنید:
#   .\setup.ps1
# یا اگر خطای Execution Policy گرفتید:
#   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
#   .\setup.ps1
# ============================================================

$ErrorActionPreference = "Stop"
$Host.UI.RawUI.WindowTitle = "YIO Shop - نصب خودکار"

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "   نصب فروشگاه YIO" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# ============================================================
# مرحله ۱: بررسی فایل .env
# ============================================================
if (-not (Test-Path ".env")) {
    Write-Host "[!] فایل .env یافت نشد." -ForegroundColor Yellow
    Write-Host "    در حال ساخت فایل .env با مقادیر پیش‌فرض..." -ForegroundColor Yellow

    $envContent = @"
DATABASE_URL=file:./db/custom.db
EXPOSE_VERIFY_CODE=true
"@
    $envContent | Out-File -FilePath ".env" -Encoding utf8 -NoNewline
    Write-Host "[OK] فایل .env ساخته شد." -ForegroundColor Green
} else {
    Write-Host "[OK] فایل .env از قبل وجود دارد." -ForegroundColor Green

    # بررسی محتوای فایل — اگر مسیر Linux داشت، اصلاح می‌کنیم
    $envContent = Get-Content ".env" -Raw
    if ($envContent -match "/home/z/") {
        Write-Host "[!] مسیر Linux در فایل .env شناسایی شد. در حال اصلاح..." -ForegroundColor Yellow
        $newContent = @"
DATABASE_URL=file:./db/custom.db
EXPOSE_VERIFY_CODE=true
"@
        $newContent | Out-File -FilePath ".env" -Encoding utf8 -NoNewline
        Write-Host "[OK] فایل .env اصلاح شد." -ForegroundColor Green
    }
}
Write-Host ""

# ============================================================
# مرحله ۲: انتخاب runtime (Bun یا Node)
# ============================================================
$runner = $null
$seedCmd = $null
$prismaCmd = $null

if (Get-Command bun -ErrorAction SilentlyContinue) {
    $runner = "bun"
    $seedCmd = "bun run"
    $prismaCmd = "bunx prisma"
    Write-Host "[OK] Bun پیدا شد. از Bun استفاده می‌شود." -ForegroundColor Green
} elseif (Get-Command npm -ErrorAction SilentlyContinue) {
    $runner = "npm"
    $seedCmd = "npx tsx"
    $prismaCmd = "npx prisma"
    Write-Host "[INFO] Bun پیدا نشد. از npm استفاده می‌شود." -ForegroundColor Yellow
    Write-Host "       برای نصب Bun:" -ForegroundColor DarkGray
    Write-Host "       powershell -c `"irm bun.sh/install.ps1 | iex`"" -ForegroundColor DarkGray
} else {
    Write-Host "[X] نه Bun و نه npm پیدا نشد!" -ForegroundColor Red
    Write-Host "    لطفاً Node.js را از https://nodejs.org نصب کنید." -ForegroundColor Red
    Read-Host "برای خروج Enter را بزنید"
    exit 1
}
Write-Host ""

# ============================================================
# مرحله ۳: نصب وابستگی‌ها
# ============================================================
Write-Host "[1/5] نصب وابستگی‌ها..." -ForegroundColor Cyan
& $runner install
if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "[X] خطا در نصب وابستگی‌ها!" -ForegroundColor Red
    Read-Host "برای خروج Enter را بزنید"
    exit 1
}
Write-Host "[OK] وابستگی‌ها نصب شدند." -ForegroundColor Green
Write-Host ""

# ============================================================
# مرحله ۴: ساخت پوشه دیتابیس و اجرای db push
# ============================================================
Write-Host "[2/5] ساخت پوشه دیتابیس..." -ForegroundColor Cyan
if (-not (Test-Path "db")) {
    New-Item -ItemType Directory -Path "db" | Out-Null
    Write-Host "[OK] پوشه db ساخته شد." -ForegroundColor Green
} else {
    Write-Host "[OK] پوشه db از قبل وجود دارد." -ForegroundColor Green
}
Write-Host ""

Write-Host "[3/5] ساخت دیتابیس..." -ForegroundColor Cyan
Invoke-Expression "$prismaCmd db push"
if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "[X] خطا در ساخت دیتابیس!" -ForegroundColor Red
    Write-Host "    مطمئن شوید فایل .env با محتوای زیر وجود دارد:" -ForegroundColor Yellow
    Write-Host "      DATABASE_URL=file:./db/custom.db" -ForegroundColor DarkGray
    Read-Host "برای خروج Enter را بزنید"
    exit 1
}
Write-Host "[OK] دیتابیس ساخته شد." -ForegroundColor Green
Write-Host ""

# ============================================================
# مرحله ۵: تولید Prisma Client
# ============================================================
Write-Host "[4/5] تولید Prisma Client..." -ForegroundColor Cyan
Invoke-Expression "$prismaCmd generate"
Write-Host "[OK] Prisma Client تولید شد." -ForegroundColor Green
Write-Host ""

# ============================================================
# مرحله ۶: بارگذاری داده‌های اولیه
# ============================================================
Write-Host "[5/5] افزودن محصولات و داده‌های پیش‌فرض..." -ForegroundColor Cyan

$seedFiles = @("scripts/seed.ts", "scripts/seed-faq.ts", "scripts/seed-settings.ts")
foreach ($seedFile in $seedFiles) {
    if (Test-Path $seedFile) {
        Invoke-Expression "$seedCmd $seedFile"
    } else {
        Write-Host "[!] فایل $seedFile یافت نشد — رد شد." -ForegroundColor Yellow
    }
}
Write-Host "[OK] داده‌های اولیه بارگذاری شدند." -ForegroundColor Green
Write-Host ""

# ============================================================
# پایان
# ============================================================
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "   نصب کامل شد!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "   آدرس سایت:    http://localhost:3000" -ForegroundColor White
Write-Host "   رمز مدیریت:    yio-admin-1403" -ForegroundColor White
Write-Host ""
Write-Host "برای اجرای سرور، دستور زیر را بزنید:" -ForegroundColor Yellow
Write-Host "   $runner run dev" -ForegroundColor White
Write-Host ""
Write-Host "برای توضیحات بیشتر، فایل README-WINDOWS.md را بخوانید." -ForegroundColor DarkGray
Write-Host ""
Read-Host "برای خروج Enter را بزنید"
