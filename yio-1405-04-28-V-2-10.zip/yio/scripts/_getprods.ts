import { db } from '@/lib/db';
async function main() {
  const products = await db.product.findMany({ select: { id: true, title: true }, take: 5 });
  console.log(JSON.stringify(products, null, 2));
  await db.$disconnect();
}
main();
