@echo off
chcp 65001 >nul
title YIO Shop - نصب خودکار

echo ========================================
echo   نصب فروشگاه YIO
echo ========================================
echo.

REM بررسی وجود فایل .env
if not exist ".env" (
    echo [!] فایل .env یافت نشد. ساختن فایل .env با مقادیر پیش‌فرض...
    (
        echo DATABASE_URL=file:./db/custom.db
        echo EXPOSE_VERIFY_CODE=true
    ) > .env
    echo [OK] فایل .env ساخته شد.
    echo.
)

REM بررسی وجود bun
where bun >nul 2>&1
if %errorlevel% equ 0 (
    set RUNNER=bun
    set SEED_CMD=bun run
    set PRISMA_CMD=bunx prisma
    echo [OK] Bun پیدا شد. از Bun استفاده می‌شود.
) else (
    set RUNNER=npm
    set SEED_CMD=npx tsx
    set PRISMA_CMD=npx prisma
    echo [INFO] Bun پیدا نشد. از npm استفاده می‌شود.
    echo        برای نصب Bun: powershell -c "irm bun.sh/install.ps1 | iex"
)
echo.

echo [1/6] نصب وابستگی‌ها...
%RUNNER% install
if %errorlevel% neq 0 (
    echo.
    echo [X] خطا در نصب وابستگی‌ها!
    pause
    exit /b 1
)
echo [OK] وابستگی‌ها نصب شدند.
echo.

echo [2/6] ساخت پوشه دیتابیس...
if not exist "db" mkdir db
echo [OK] پوشه db آماده است.
echo.

echo [3/6] ساخت دیتابیس...
%PRISMA_CMD% db push
if %errorlevel% neq 0 (
    echo.
    echo [X] خطا در ساخت دیتابیس!
    echo مطمئن شوید فایل .env با محتوای زیر وجود دارد:
    echo   DATABASE_URL=file:./db/custom.db
    pause
    exit /b 1
)
echo [OK] دیتابیس ساخته شد.
echo.

echo [4/6] تولید Prisma Client...
%PRISMA_CMD% generate
echo [OK] Prisma Client تولید شد.
echo.

echo [5/6] افزودن محصولات و داده‌های پیش‌فرض...
%SEED_CMD% scripts/seed.ts
%SEED_CMD% scripts/seed-faq.ts
%SEED_CMD% scripts/seed-settings.ts
echo [OK] داده‌های اولیه بارگذاری شدند.
echo.

echo [6/6] آماده برای اجرا!
echo.
echo ========================================
echo   نصب کامل شد!
echo ========================================
echo.
echo   آدرس سایت:    http://localhost:3000
echo   رمز مدیریت:    yio-admin-1403
echo.
echo برای اجرای سرور، دستور زیر را بزنید:
echo   %RUNNER% run dev
echo.
echo برای توضیحات بیشتر، فایل README-WINDOWS.md را بخوانید.
echo.
pause
