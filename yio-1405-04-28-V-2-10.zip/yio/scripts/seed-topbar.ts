// Seed top bar settings for admin-configurable red banner
import { db } from '../src/lib/db';

const defaultTopBarSettings = [
  // تنظیمات نوار قرمز بالای صفحه
  {
    key: 'topbar_enabled',
    value: 'true',
    category: 'topbar',
  },
  {
    key: 'topbar_height',
    value: '36',
    category: 'topbar',
  },
  {
    key: 'topbar_bg_color',
    value: '#dc2626',
    category: 'topbar',
  },
  {
    key: 'topbar_text_color',
    value: '#ffffff',
    category: 'topbar',
  },
  {
    // حالت نمایش: 'text' (متن ساده), 'image' (تصویر/گیف), 'mixed' (متن + تصویر)
    key: 'topbar_mode',
    value: 'text',
    category: 'topbar',
  },
  {
    // متن‌های نوار (با | جدا می‌شوند تا به‌صورت آیتم جدا نمایش داده شوند)
    key: 'topbar_text_right',
    value: 'ارسال به: تهران|پشتیبانی ۲۴ ساعته: ۰۲۱-۹۱۰۰۲۰۲۰',
    category: 'topbar',
  },
  {
    key: 'topbar_text_left',
    value: 'ضمانت اصالت کالا|ارسال به سراسر کشور|پرداخت در محل',
    category: 'topbar',
  },
  {
    // آدرس تصویر/گیف نوار (در حالت image یا mixed)
    key: 'topbar_image_url',
    value: '',
    category: 'topbar',
  },
  {
    // لینک تصویر (اختیاری - اگر کلیک شود به کجا برود)
    key: 'topbar_image_link',
    value: '',
    category: 'topbar',
  },
  {
    // ارتفاع تصویر داخل نوار (px)
    key: 'topbar_image_height',
    value: '28',
    category: 'topbar',
  },
];

async function main() {
  console.log('افزودن تنظیمات نوار قرمز بالای صفحه...');
  for (const s of defaultTopBarSettings) {
    await db.siteSetting.upsert({
      where: { key: s.key },
      update: {}, // اگر وجود دارد، تغییر نده
      create: s,
    });
    console.log(`  ✓ ${s.key} = ${s.value.slice(0, 60)}${s.value.length > 60 ? '...' : ''}`);
  }
  console.log('\n✅ تنظیمات نوار قرمز با موفقیت اضافه شد');
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());
