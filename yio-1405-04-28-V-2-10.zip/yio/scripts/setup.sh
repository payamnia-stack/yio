#!/bin/bash
echo "========================================"
echo "  نصب فروشگاه YIO"
echo "========================================"
echo ""

echo "[1/5] نصب وابستگی‌ها..."
npm install || { echo "خطا در نصب!"; exit 1; }

echo ""
echo "[2/5] ساخت دیتابیس..."
npx prisma db push || { echo "خطا در دیتابیس!"; exit 1; }

echo ""
echo "[3/5] تولید Prisma Client..."
npx prisma generate

echo ""
echo "[4/5] افزودن داده‌های پیش‌فرض..."
node scripts/seed.js
node scripts/seed-faq.js
node scripts/seed-settings.js

echo ""
echo "[5/5] راه‌اندازی سرور..."
echo ""
echo "========================================"
echo "  نصب کامل شد!"
echo "  سایت روی http://localhost:3000 اجرا می‌شود"
echo "  رمز پنل مدیریت: yio-admin-1403"
echo "========================================"
echo ""
echo "برای اجرای مجدد: npm run dev"
