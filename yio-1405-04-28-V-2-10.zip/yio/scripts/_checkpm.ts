import { db } from '@/lib/db';
async function main() {
  const methods = await db.paymentMethod.findMany({ select: { id: true, name: true, isDefault: true, isActive: true } });
  console.log(JSON.stringify(methods, null, 2));
  await db.$disconnect();
}
main();
