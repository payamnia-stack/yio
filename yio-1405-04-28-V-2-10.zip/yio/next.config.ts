import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // هدرهای امنیتی
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Frame-Options', value: 'DENY' }, // جلوگیری از clickjacking
          { key: 'X-Content-Type-Options', value: 'nosniff' }, // جلوگیری از MIME sniffing
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' }, // محدود کردن referrer
          { key: 'X-XSS-Protection', value: '1; mode=block' }, // فیلتر XSS مرورگر
          { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=(), interest-cohort=()' }, // محدود کردن دسترسی‌ها
          // HSTS - اجبار به HTTPS
          { key: 'Strict-Transport-Security', value: 'max-age=31536000; includeSubDomains; preload' },
          // Content Security Policy - محدود کردن منابع
          {
            key: 'Content-Security-Policy',
            value: [
              "default-src 'self'",
              "script-src 'self' 'unsafe-inline' 'unsafe-eval'",
              "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
              "font-src 'self' data:",
              "img-src 'self' data: https: blob:",
              "media-src 'self' https:",
              "connect-src 'self' https:",
              "frame-ancestors 'none'",
              "base-uri 'self'",
              "form-action 'self'",
            ].join('; ')
          },
          // Cross-Origin Policies
          { key: 'Cross-Origin-Opener-Policy', value: 'same-origin' },
          { key: 'Cross-Origin-Resource-Policy', value: 'same-site' },
        ],
      },
    ];
  },
  // محدود کردن اندازه بدنه درخواست
  experimental: {
    serverActions: {
      bodySizeLimit: '10mb',
    },
  },
  // غیرفعال کردن x-powered-by header
  poweredByHeader: false,
};

export default nextConfig;
