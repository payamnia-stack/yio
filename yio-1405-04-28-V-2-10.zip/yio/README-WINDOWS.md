# راه‌اندازی فروشگاه YIO روی ویندوز

## پیش‌نیازها

1. **Node.js 18+** — از [nodejs.org](https://nodejs.org) دانلود کنید
2. **Bun** (توصیه شده) — از [bun.sh](https://bun.sh) نصب کنید
   - یا از PowerShell: `powershell -c "irm bun.sh/install.ps1 | iex"`
3. **Git** — برای استخراج فایل‌ها (اختیاری)

---

## مراحل نصب

### ۱. استخراج فایل ZIP

فایل ZIP را در مسیر دلخواه استخراج کنید، مثلاً: `C:\Projects\yio`

### ۲. باز کردن PowerShell در پوشه پروژه

```powershell
cd C:\Projects\yio
```

### ۳. بررسی فایل `.env`

مطمئن شوید فایل `.env` در پوشه اصلی پروژه وجود دارد:

```powershell
dir -Force
```

باید فایل `.env` را در لیست ببینید. اگر نبود، آن را بسازید:

```powershell
@'
DATABASE_URL=file:./db/custom.db
EXPOSE_VERIFY_CODE=true
'@ | Out-File -FilePath .env -Encoding utf8 -NoNewline
```

### ۴. نصب وابستگی‌ها

```powershell
bun install
```

اگر Bun ندارید، می‌توانید از npm استفاده کنید:

```powershell
npm install
```

### ۵. ساخت پایگاه داده

```powershell
bun run db:push
```

یا با npm:

```powershell
npx prisma db push
```

### ۶. بارگذاری داده‌های اولیه

```powershell
bun run scripts/seed.ts
bun run scripts/seed-faq.ts
bun run scripts/seed-settings.ts
bun run scripts/seed-pages.ts
```

یا با npm:

```powershell
node scripts/seed.js
node scripts/seed-faq.js
node scripts/seed-settings.js
node scripts/seed-pages.js
```

> **نکته:** اگر اسکریپت‌های `.js` وجود ندارند، ابتدا `npx tsx scripts/seed.ts` را اجرا کنید.

### ۷. اجرای سرور

```powershell
bun run dev
```

یا با npm:

```powershell
npm run dev
```

### ۸. باز کردن در مرورگر

به آدرس `http://localhost:3000` بروید.

---

## رمز پنل مدیریت

رمز پیش‌فرض: `yio-admin-1403`

**برای محیط production**، رمز را در فایل `.env` تغییر دهید:

```env
ADMIN_PASSWORD=رمز-جدید-شما
```

یا بهتر، از هش استفاده کنید:

```env
ADMIN_PASSWORD_HASH=salt:hash
```

---

## حل مشکلات رایج

### مشکل: `Environment variable not found: DATABASE_URL`

فایل `.env` وجود ندارد یا پسوند `.txt` دارد. راه‌حل:

```powershell
# بررسی فایل‌های .env
Get-ChildItem -Force | Where-Object { $_.Name -like ".env*" }

# اگر .env.txt وجود داشت:
Rename-Item .env.txt .env

# اگر هیچ فایلی نبود:
@'
DATABASE_URL=file:./db/custom.db
EXPOSE_VERIFY_CODE=true
'@ | Out-File -FilePath .env -Encoding utf8 -NoNewline
```

### مشکل: `Can't resolve 'tailwindcss'`

کش Next.js قدیمی است. پاک کنید و دوباره اجرا:

```powershell
Remove-Item -Recurse -Force .next
bun run dev
```

### مشکل: `port 3000 already in use`

پورت دیگری استفاده کنید:

```powershell
bun run dev -- -p 3001
```

### مشکل: خطای Prisma `Database does not exist`

ابتدا پایگاه داده را بسازید:

```powershell
bun run db:push
bun run db:generate
```

### مشکل: خطای `node_modules` یا وابستگی‌ها

```powershell
Remove-Item -Recurse -Force node_modules
Remove-Item -Force bun.lock
bun install
```

---

## ساختار پروژه

```
yio/
├── .env                    # متغیرهای محیطی
├── package.json            # وابستگی‌ها
├── prisma/
│   └── schema.prisma       # ساختار پایگاه داده
├── scripts/
│   ├── seed.ts             # داده‌های اولیه محصولات
│   ├── seed-faq.ts         # سؤالات متداول
│   └── seed-settings.ts    # تنظیمات سایت
├── src/
│   ├── app/                # صفحات Next.js
│   ├── components/         # کامپوننت‌های React
│   ├── lib/                # توابع کمکی
│   └── store/              # state management
└── public/                 # فایل‌های استاتیک
```

---

## دستورات مفید

| دستور | توضیح |
|------|-------|
| `bun run dev` | اجرای سرور توسعه |
| `bun run build` | ساخت نسخه production |
| `bun run db:push` | اعمال تغییرات schema روی DB |
| `bun run db:generate` | تولید Prisma Client |
| `bun run db:reset` | پاک کردن و بازنشانی DB |

---

## پشتیبانی

اگر مشکلی داشتید، لاگ خطا را بررسی کنید:

```powershell
# مشاهده لاگ سرور
Get-Content server.log -Wait
```
