// Service Worker برای YIO Admin PWA
const CACHE_NAME = 'yio-admin-v1';
const STATIC_CACHE = 'yio-static-v1';

// فایل‌های استاتیک برای کش
const STATIC_FILES = [
  '/',
  '/yio-logo.png',
  '/manifest.json',
];

// نصب Service Worker
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => {
      return cache.addAll(STATIC_FILES).catch(() => {
        // اگر کش شکست خورد، مهم نیست
        return Promise.resolve();
      });
    })
  );
  self.skipWaiting();
});

// فعال‌سازی Service Worker
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== STATIC_CACHE && name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      );
    })
  );
  self.clients.claim();
});

// استراتژی Network First برای API، Cache First برای استاتیک
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // فقط GET رو کش کن
  if (request.method !== 'GET') return;

  // API ها - Network First
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(request)
        .then((response) => {
          // کش کن اگر موفق بود
          if (response.ok) {
            const responseClone = response.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(request, responseClone);
            });
          }
          return response;
        })
        .catch(() => {
          // اگر آفلاین بود، از کش استفاده کن
          return caches.match(request);
        })
    );
    return;
  }

  // فایل‌های استاتیک - Cache First
  event.respondWith(
    caches.match(request).then((cached) => {
      if (cached) return cached;
      return fetch(request).then((response) => {
        if (response.ok && response.type === 'basic') {
          const responseClone = response.clone();
          caches.open(STATIC_CACHE).then((cache) => {
            cache.put(request, responseClone);
          });
        }
        return response;
      });
    })
  );
});
