import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { getUserFromSession } from '@/lib/user-auth';
import { enforceRateLimit, securityCheck, validateIranMobile, validateString, sanitizeInput } from '@/lib/security';

// لیست سفارش‌ها (مدیر) یا ثبت سفارش (مشتری)

// GET: لیست سفارش‌ها برای پنل مدیریت
export async function GET(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);

    if (!isAuth) {
      return NextResponse.json(
        { error: 'غیرمجاز. لطفاً وارد شوید.' },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search') || '';
    const status = searchParams.get('status') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '10');

    const where: any = {};
    if (status) where.status = status;
    if (search) {
      where.OR = [
        { orderNumber: { contains: search } },
        { recipientName: { contains: search } },
        { recipientPhone: { contains: search } },
        { trackingCode: { contains: search } },
      ];
    }

    const total = await db.order.count({ where });
    const orders = await db.order.findMany({
      where,
      include: {
        customer: true,
        items: true,
      },
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
    });

    // آمار سفارش‌ها
    const stats = {
      total: await db.order.count(),
      pending: await db.order.count({ where: { status: 'pending' } }),
      confirmed: await db.order.count({ where: { status: 'confirmed' } }),
      shipping: await db.order.count({ where: { status: 'shipping' } }),
      delivered: await db.order.count({ where: { status: 'delivered' } }),
      cancelled: await db.order.count({ where: { status: 'cancelled' } }),
      totalRevenue: await db.order.aggregate({
        _sum: { finalAmount: true },
        where: { paymentStatus: 'paid' },
      }),
      pendingRevenue: await db.order.aggregate({
        _sum: { finalAmount: true },
        where: { paymentStatus: 'unpaid', status: { not: 'cancelled' } },
      }),
    };

    return NextResponse.json({
      orders,
      pagination: {
        page,
        pageSize,
        total,
        totalPages: Math.ceil(total / pageSize),
      },
      stats,
    });
  } catch (error) {
    console.error('Error fetching orders:', error);
    return NextResponse.json(
      { error: 'خطا در دریافت سفارش‌ها' },
      { status: 500 }
    );
  }
}

// POST: ثبت سفارش جدید (بدون احراز هویت - برای مشتری)
export async function POST(request: NextRequest) {
  try {
    // Rate limit - 10 سفارش در ساعت از یک IP
    const rateLimit = await enforceRateLimit(request, 'create-order', 10);
    if (!rateLimit.allowed) {
      return rateLimit.response!;
    }

    const body = await request.json();

    // بررسی امنیتی ورودی (XSS، SQL Injection)
    const secCheck = securityCheck(body);
    if (!secCheck.safe) {
      return NextResponse.json(
        { error: secCheck.reason },
        { status: 400 }
      );
    }

    // اعتبارسنجی
    if (!body.customer || !body.items || !Array.isArray(body.items) || body.items.length === 0) {
      return NextResponse.json(
        { error: 'اطلاعات سفارش ناقص است' },
        { status: 400 }
      );
    }

    // محدود کردن تعداد اقلام در یک سفارش
    if (body.items.length > 50) {
      return NextResponse.json(
        { error: 'تعداد اقلام بیش از حد مجاز است' },
        { status: 400 }
      );
    }

    const { customer, items, shippingAddress, shippingCity, postalCode, notes, paymentMethod } = body;

    // اعتبارسنجی فیلدها
    const validName = validateString(customer.name, 3, 100);
    const validPhone = validateString(customer.phone, 11, 11);
    const validAddress = validateString(shippingAddress, 10, 500);

    if (!validName || !validPhone || !validAddress) {
      return NextResponse.json(
        { error: 'نام، تلفن و آدرس الزامی است' },
        { status: 400 }
      );
    }

    // اعتبارسنجی شماره موبایل
    if (!validateIranMobile(validPhone)) {
      return NextResponse.json(
        { error: 'شماره موبایل نامعتبر است (مثال: 09121234567)' },
        { status: 400 }
      );
    }

    // بررسی محصولات و محاسبه قیمت کل
    let totalAmount = 0;
    const orderItems = [];

    for (const item of items) {
      // اعتبارسنجی productId
      const productId = parseInt(item.productId);
      if (isNaN(productId) || productId < 1) {
        return NextResponse.json(
          { error: 'شناسه محصول نامعتبر' },
          { status: 400 }
        );
      }

      const product = await db.product.findUnique({ where: { id: productId } });
      if (!product || !product.inStock) {
        return NextResponse.json(
          { error: `محصول مورد نظر موجود نیست` },
          { status: 400 }
        );
      }

      const price = product.discountPrice || product.price;
      const qty = Math.max(1, Math.min(99, parseInt(item.quantity) || 1));
      totalAmount += price * qty;

      orderItems.push({
        productId: product.id,
        productTitle: product.title,
        productImage: product.image,
        price,
        quantity: qty,
        color: item.color ? sanitizeInput(String(item.color).slice(0, 50)) : null,
      });
    }

    // بررسی مبلغ کل (حداکثر ۱۰۰ میلیون)
    if (totalAmount > 100000000) {
      return NextResponse.json(
        { error: 'مبلغ سفارش بیش از حد مجاز است' },
        { status: 400 }
      );
    }

    // محاسبه هزینه ارسال
    const shippingCost = totalAmount > 500000 ? 0 : 89000;
    const finalAmount = totalAmount + shippingCost;

    // پیدا کردن یا ایجاد مشتری
    let customerRecord = await db.customer.findFirst({
      where: { phone: validPhone },
    });

    if (!customerRecord) {
      customerRecord = await db.customer.create({
        data: {
          name: validName,
          phone: validPhone,
          email: customer.email ? sanitizeInput(String(customer.email).slice(0, 254)) : null,
          address: validAddress,
          postalCode: postalCode ? sanitizeInput(String(postalCode).slice(0, 20)) : null,
          city: shippingCity ? sanitizeInput(String(shippingCity).slice(0, 50)) : null,
        },
      });
    }

    // دریافت کاربر وارد شده (برای اتصال سفارش به حساب کاربری)
    const sessionUser = await getUserFromSession();
    const userId = sessionUser?.id ?? null;

    if (userId) {
      try {
        const cityValue = shippingCity ? String(shippingCity) : '';
        const parts = cityValue.split(' - ');
        await db.user.update({
          where: { id: userId },
          data: {
            name: validName,
            phone: validPhone,
            address: validAddress,
            city: parts.length > 1 ? parts[1] : cityValue,
            postalCode: postalCode || null,
          },
        });
      } catch (e) {
        console.error('User profile update error:', e);
      }
    }

    // تولید شماره سفارش
    const orderCount = await db.order.count();
    const orderNumber = `YIO-${1000 + orderCount + 1}`;

    // ایجاد سفارش
    const order = await db.order.create({
      data: {
        orderNumber,
        customerId: customerRecord.id,
        userId, // ← اتصال به حساب کاربر (در صورت ورود)
        status: 'pending',
        totalAmount,
        shippingCost,
        finalAmount,
        paymentMethod: ['cod', 'online', 'wallet', 'transfer'].includes(paymentMethod) ? paymentMethod : 'cod',
        paymentStatus: 'unpaid',
        shippingAddress: validAddress,
        shippingCity: shippingCity ? sanitizeInput(String(shippingCity).slice(0, 50)) : null,
        postalCode: postalCode ? sanitizeInput(String(postalCode).slice(0, 20)) : null,
        recipientName: validName,
        recipientPhone: validPhone,
        notes: notes ? sanitizeInput(String(notes).slice(0, 500)) : null,
        items: {
          create: orderItems,
        },
      },
      include: {
        items: true,
        customer: true,
      },
    });

    // افزودن امتیاز وفاداری در صورت ورود کاربر (۱ امتیاز به ازای هر ۱۰۰ هزار تومان)
    if (userId) {
      try {
        await db.loyaltyPoint.create({
          data: {
            userId,
            points: Math.max(1, Math.floor(finalAmount / 100000)),
            reason: 'purchase',
            orderId: order.id,
          },
        });
      } catch (e) {
        // در صورت خطا در ثبت امتیاز، سفارش همچنان موفق است
        console.error('Loyalty point error:', e);
      }
    }

    // اطلاع‌رسانی سفارش جدید به n8n (بدون مسدود کردن پاسخ)
    try {
      fetch('http://127.0.0.1:5678/webhook/new-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ order }),
      }).catch(() => {});
    } catch {}

    return NextResponse.json({ order, success: true });
  } catch (error) {
    console.error('Error creating order:', error);
    return NextResponse.json(
      { error: 'خطا در ثبت سفارش' },
      { status: 500 }
    );
  }
}
