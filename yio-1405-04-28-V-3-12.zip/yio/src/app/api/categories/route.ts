import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET: دسته‌بندی‌های فعال (عمومی - برای نمایش در سایت)
export async function GET() {
  try {
    let categories = await db.category.findMany({
      where: { isActive: true },
      orderBy: [{ order: 'asc' }, { title: 'asc' }],
    });

    // اگر دیتابیس خالی است، دسته‌های پایه را یک‌بار در PostgreSQL ایجاد می‌کنیم.
    // بنابراین Header، صفحه اصلی و پنل مدیریت همگی از یک منبع واحد استفاده می‌کنند.
    if (categories.length === 0) {
      const defaults = [
        ['اسباب‌بازی چوبی', 'asbab-bazi-choobi', '🧸', '#f59e0b'],
        ['ظروف آشپزخانه', 'zorof-ashpazkhaneh', '🍽️', '#84cc16'],
        ['مبلمان چوبی', 'mobleman-choobi', '🪑', '#8b5cf6'],
        ['دکوراسیون چوبی', 'dekorasion-choobi', '🖼️', '#dc2626'],
        ['لوازم کودک', 'lavazem-koodak', '👶', '#06b6d4'],
        ['هدیه و صنایع دستی', 'hediye-sanaye-dasti', '🎁', '#ec4899'],
        ['نقاشی و هنر', 'naghashi-honar', '🎨', '#7c3aed'],
        ['باغ و حیاط', 'bagh-hayat', '🌳', '#10b981'],
      ] as const;

      await db.category.createMany({
        data: defaults.map(([title, slug, icon, color], order) => ({
          title, slug, icon, color, order, isActive: true,
        })),
        skipDuplicates: true,
      });

      categories = await db.category.findMany({
        where: { isActive: true },
        orderBy: [{ order: 'asc' }, { title: 'asc' }],
      });
    }

    return NextResponse.json({ categories });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}
