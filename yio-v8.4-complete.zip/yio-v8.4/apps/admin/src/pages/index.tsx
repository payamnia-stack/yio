// ============================================================
// YIO Admin Panel — Dashboard Page
// ============================================================
// پنل مدیریت سیستم
// ============================================================

import React from 'react';
import { PanelLayout, KpiCard, Card, Table, StatusBadge, Button, PageContainer, SPACING, COLORS } from '@yio/ui';
import { formatCurrency, formatDate, toPersianDigits } from '@yio/ui';

const NAV_ITEMS = [
  { label: 'داشبورد', icon: '📊', active: true },
  { label: 'کاربران', icon: '👥', children: [
    { label: 'لیست کاربران' },
    { label: 'نقش‌ها' },
    { label: 'دسترسی‌ها' },
  ]},
  { label: 'Tenantها', icon: '🏢' },
  { label: 'محصولات', icon: '🛍️' },
  { label: 'صفحات', icon: '📄', children: [
    { label: 'صفحات سفارشی' },
    { label: 'بلاگ' },
    { label: 'FAQ' },
  ]},
  { label: 'تنظیمات', icon: '⚙️', children: [
    { label: 'تنظیمات سایت' },
    { label: 'روش‌های پرداخت' },
    { label: 'قالب‌ها' },
  ]},
  { label: 'لاگ‌ها', icon: '📜', children: [
    { label: 'Audit Log' },
    { label: 'خطاها' },
    { label: 'Webhookها' },
  ]},
  { label: 'پشتیبانی', icon: '💬', children: [
    { label: 'پیام‌ها' },
    { label: 'تیکت‌ها' },
  ]},
];

export default function AdminDashboard() {
  const recentUsers = [
    { id: 1, name: 'محمد محمدی', phone: '09120000001', level: 0, isVerified: true, createdAt: new Date() },
    { id: 2, name: 'فاطمه احمدی', phone: '09120000002', level: 0, isVerified: true, createdAt: new Date() },
    { id: 3, name: 'علی رضایی', phone: '09120000003', level: 2, isVerified: true, createdAt: new Date() },
  ];

  const auditLogs = [
    { id: 1, action: 'POST:/api/v1/products', user: 'مدیر سیستم', entity: 'Product', timestamp: new Date() },
    { id: 2, action: 'DELETE:/api/v1/users/5', user: 'مدیر سیستم', entity: 'User', timestamp: new Date() },
    { id: 3, action: 'PUT:/api/v1/orders/12', user: 'فاطمه احمدی', entity: 'Order', timestamp: new Date() },
  ];

  return (
    <PanelLayout
      theme="admin"
      title="YIO Admin"
      navItems={NAV_ITEMS}
      user={{ name: 'مدیر سیستم', role: 'Super Admin' }}
      notifications={8}
    >
      <PageContainer
        title="داشبورد مدیریت سیستم"
        actions={
          <>
            <Button variant="outline" size="sm">پشتیبان‌گیری</Button>
            <Button variant="primary" size="sm">کاربر جدید</Button>
          </>
        }
      >
        {/* KPIs */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: SPACING.md,
          marginBottom: SPACING.xl,
        }}>
          <KpiCard title="تعداد کاربران" value={toPersianDigits(1248)} unit="نفر" icon="👥" />
          <KpiCard title="محصولات فعال" value={toPersianDigits(87)} unit="محصول" icon="🛍️" />
          <KpiCard title="سفارش‌های امروز" value={toPersianDigits(34)} unit="سفارش" icon="📦" />
          <KpiCard title="بازدید امروز" value={toPersianDigits(3420)} icon="👁️" trend={{ value: 12, isPositive: true }} />
        </div>

        {/* System Status */}
        <Card style={{ marginBottom: SPACING.xl }}>
          <h3 style={{ marginBottom: SPACING.md, fontWeight: 600 }}>وضعیت سیستم</h3>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: SPACING.md,
          }}>
            <SystemStatusItem name="API Server" status="operational" uptime="99.98%" />
            <SystemStatusItem name="Database" status="operational" uptime="100%" />
            <SystemStatusItem name="Redis Cache" status="operational" uptime="99.95%" />
            <SystemStatusItem name="File Storage" status="operational" uptime="100%" />
            <SystemStatusItem name="SMS Gateway" status="degraded" uptime="98.5%" />
            <SystemStatusItem name="Email Service" status="operational" uptime="99.9%" />
          </div>
        </Card>

        {/* Recent Users */}
        <Card style={{ marginBottom: SPACING.xl }}>
          <h3 style={{ marginBottom: SPACING.md, fontWeight: 600 }}>کاربران اخیر</h3>
          <Table
            columns={[
              { key: 'name', title: 'نام' },
              { key: 'phone', title: 'تلفن' },
              { key: 'level', title: 'سطح', render: (row) => (
                <StatusBadge status={row.level === 3 ? 'confirmed' : row.level === 2 ? 'shipping' : 'pending'} />
              )},
              { key: 'isVerified', title: 'تأیید شده', render: (row) => row.isVerified ? '✅' : '❌' },
              { key: 'createdAt', title: 'تاریخ عضویت', render: (row) => formatDate(row.createdAt) },
              { key: 'actions', title: '', render: () => <Button size="sm" variant="ghost">مشاهده</Button> },
            ]}
            data={recentUsers}
          />
        </Card>

        {/* Audit Logs */}
        <Card>
          <h3 style={{ marginBottom: SPACING.md, fontWeight: 600 }}>لاگ تغییرات اخیر</h3>
          <Table
            columns={[
              { key: 'action', title: 'عملیات' },
              { key: 'user', title: 'کاربر' },
              { key: 'entity', title: 'موجودیت' },
              { key: 'timestamp', title: 'زمان', render: (row) => formatDate(row.timestamp, true) },
            ]}
            data={auditLogs}
          />
        </Card>
      </PageContainer>
    </PanelLayout>
  );
}

function SystemStatusItem({ name, status, uptime }: { name: string; status: string; uptime: string }) {
  const colors = {
    operational: COLORS.success[500],
    degraded: COLORS.warning[500],
    down: COLORS.danger[500],
  };
  return (
    <div style={{
      padding: SPACING.md,
      borderRadius: '8px',
      backgroundColor: COLORS.gray[50],
      border: `1px solid ${COLORS.gray[200]}`,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.sm, marginBottom: SPACING.xs }}>
        <div style={{
          width: '8px',
          height: '8px',
          borderRadius: '50%',
          backgroundColor: colors[status as keyof typeof colors],
        }} />
        <strong style={{ fontSize: '0.875rem' }}>{name}</strong>
      </div>
      <p style={{ fontSize: '0.75rem', color: COLORS.gray[500] }}>
        {status === 'operational' ? 'عملیاتی' : status === 'degraded' ? 'کند' : 'قطع'} — {uptime}
      </p>
    </div>
  );
}
