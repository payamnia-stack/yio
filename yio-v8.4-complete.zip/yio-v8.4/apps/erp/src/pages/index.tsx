// ============================================================
// YIO ERP Panel — Dashboard Page
// ============================================================
// پنل مدیریت تولید و انبار
// ============================================================

import React from 'react';
import { PanelLayout, KpiCard, Card, Table, StatusBadge, Button, PageContainer, SPACING } from '@yio/ui';
import { formatCurrency, toPersianDigits } from '@yio/ui';

const NAV_ITEMS = [
  { label: 'داشبورد', icon: '📊', active: true },
  { label: 'دستورات کار', icon: '📋', badge: '۸' },
  { label: 'تولید', icon: '🏭', children: [
    { label: 'خط تولید' },
    { label: 'کنترل کیفیت' },
    { label: 'ضایعات' },
  ]},
  { label: 'انبار', icon: '📦', children: [
    { label: 'چوب خام' },
    { label: 'رنگ و مواد' },
    { label: 'محصول تمام‌شده' },
    { label: 'بسته‌بندی' },
  ]},
  { label: 'خرید', icon: '🛒', children: [
    { label: 'سفارشات خرید' },
    { label: 'تأمین‌کنندگان' },
  ]},
  { label: 'ماشین‌آلات', icon: '⚙️' },
  { label: 'نیروی انسانی', icon: '👷' },
  { label: 'گزارش‌ها', icon: '📈' },
];

export default function ERPDashboard() {
  const workOrders = [
    { id: 1, woNumber: 'WO-20260727-001', product: 'مایل ۱۰۰ تایی', qty: 50, status: 'in_progress', priority: 'high' },
    { id: 2, woNumber: 'WO-20260727-002', product: 'پازل حیوانات', qty: 100, status: 'planned', priority: 'normal' },
    { id: 3, woNumber: 'WO-20260727-003', product: 'دستکش عروسکی', qty: 30, status: 'completed', priority: 'low' },
  ];

  const lowStockItems = [
    { id: 1, name: 'چوب فینلاندی ۱۸mm', quantity: 5, unit: 'm²', threshold: 10 },
    { id: 2, name: 'رنگ پلی‌اورتان شفاف', quantity: 3, unit: 'لیتر', threshold: 5 },
    { id: 3, name: 'سمباده نرم ۱۲۰', quantity: 8, unit: 'عدد', threshold: 20 },
  ];

  return (
    <PanelLayout
      theme="erp"
      title="YIO ERP"
      navItems={NAV_ITEMS}
      user={{ name: 'مدیر تولید', role: 'Production Manager' }}
      notifications={3}
    >
      <PageContainer
        title="داشبورد تولید و انبار"
        actions={
          <>
            <Button variant="outline" size="sm">گزارش تولید</Button>
            <Button variant="primary" size="sm">دستور کار جدید</Button>
          </>
        }
      >
        {/* KPIs */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: SPACING.md,
          marginBottom: SPACING.xl,
        }}>
          <KpiCard title="دستورات کار فعال" value={toPersianDigits(8)} unit="عدد" icon="📋" color="#10b981" />
          <KpiCard title="تولید امروز" value={toPersianDigits(142)} unit="عدد" icon="🏭" color="#10b981" trend={{ value: 15, isPositive: true }} />
          <KpiCard title="اقلام کم‌موجودی" value={toPersianDigits(12)} unit="قلم" icon="⚠️" color="#f59e0b" />
          <KpiCard title="بازدهی تولید" value="۹۲٪" icon="📈" color="#10b981" trend={{ value: 2, isPositive: true }} />
        </div>

        {/* Work Orders */}
        <Card style={{ marginBottom: SPACING.xl }}>
          <h3 style={{ marginBottom: SPACING.md, fontWeight: 600 }}>دستورات کار اخیر</h3>
          <Table
            columns={[
              { key: 'woNumber', title: 'شماره دستور' },
              { key: 'product', title: 'محصول' },
              { key: 'qty', title: 'تعداد', render: (row) => toPersianDigits(row.qty) },
              { key: 'priority', title: 'اولویت', render: (row) => <StatusBadge status={row.priority} /> },
              { key: 'status', title: 'وضعیت', render: (row) => <StatusBadge status={row.status} /> },
              { key: 'actions', title: '', render: () => <Button size="sm" variant="ghost">مشاهده</Button> },
            ]}
            data={workOrders}
          />
        </Card>

        {/* Low Stock */}
        <Card>
          <h3 style={{ marginBottom: SPACING.md, fontWeight: 600 }}>هشدار کم‌موجودی</h3>
          <Table
            columns={[
              { key: 'name', title: 'مواد' },
              { key: 'quantity', title: 'موجودی', render: (row) => `${toPersianDigits(row.quantity)} ${row.unit}` },
              { key: 'threshold', title: 'حد آستانه', render: (row) => `${toPersianDigits(row.threshold)} ${row.unit}` },
              { key: 'status', title: 'وضعیت', render: () => <StatusBadge status="warning" /> },
              { key: 'actions', title: '', render: () => <Button size="sm" variant="outline">سفارش خرید</Button> },
            ]}
            data={lowStockItems}
          />
        </Card>
      </PageContainer>
    </PanelLayout>
  );
}
