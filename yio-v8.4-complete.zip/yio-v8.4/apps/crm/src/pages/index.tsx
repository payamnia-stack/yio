// ============================================================
// YIO CRM Panel — Dashboard Page
// ============================================================
// پنل مدیریت فروش و ارتباط با مشتریان
// ============================================================

import React from 'react';
import { PanelLayout } from '@yio/ui';
import { KpiCard, Card, Table, StatusBadge, Button, PageContainer, SPACING } from '@yio/ui';
import { formatCurrency, formatDate, toPersianDigits } from '@yio/ui';

const NAV_ITEMS = [
  { label: 'داشبورد', icon: '📊', active: true },
  { label: 'سفارشات', icon: '📦', badge: '۱۲' },
  { label: 'مشتریان', icon: '👥' },
  { label: 'محصولات', icon: '🛍️' },
  { label: 'بازاریابی', icon: '📣', children: [
    { label: 'کمپین‌ها' },
    { label: 'کدهای تخفیف' },
    { label: 'خبرنامه' },
  ]},
  { label: 'گزارش‌ها', icon: '📈' },
  { label: 'تنظیمات', icon: '⚙️' },
];

export default function CRMDashboard() {
  const recentOrders = [
    { id: 1, orderNumber: 'YIO-20260727-0001', customer: 'محمد محمدی', amount: 789000, status: 'pending', date: new Date() },
    { id: 2, orderNumber: 'YIO-20260727-0002', customer: 'فاطمه احمدی', amount: 350000, status: 'confirmed', date: new Date() },
    { id: 3, orderNumber: 'YIO-20260727-0003', customer: 'علی رضایی', amount: 1200000, status: 'shipping', date: new Date() },
    { id: 4, orderNumber: 'YIO-20260727-0004', customer: 'زهرا کریمی', amount: 450000, status: 'delivered', date: new Date() },
  ];

  const topCustomers = [
    { id: 1, name: 'محمد محمدی', phone: '09120000001', orders: 23, totalSpent: 8500000 },
    { id: 2, name: 'فاطمه احمدی', phone: '09120000002', orders: 18, totalSpent: 6200000 },
    { id: 3, name: 'علی رضایی', phone: '09120000003', orders: 15, totalSpent: 4800000 },
  ];

  return (
    <PanelLayout
      theme="crm"
      title="YIO CRM"
      navItems={NAV_ITEMS}
      user={{ name: 'مدیر فروش', role: 'Sales Manager' }}
      notifications={5}
    >
      <PageContainer
        title="داشبورد فروش"
        actions={
          <>
            <Button variant="outline" size="sm">دریافت گزارش</Button>
            <Button variant="primary" size="sm">سفارش جدید</Button>
          </>
        }
      >
        {/* KPIs */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: SPACING.md,
          marginBottom: SPACING.xl,
        }}>
          <KpiCard title="فروش امروز" value={formatCurrency(2840000)} icon="💰" trend={{ value: 12, isPositive: true }} />
          <KpiCard title="سفارش‌های امروز" value={toPersianDigits(15)} unit="عدد" icon="📦" trend={{ value: 8, isPositive: true }} />
          <KpiCard title="مشتریان جدید" value={toPersianDigits(7)} unit="نفر" icon="👤" trend={{ value: 5, isPositive: true }} />
          <KpiCard title="متوسط ارزش سفارش" value={formatCurrency(189000)} icon="📊" trend={{ value: 3, isPositive: false }} />
        </div>

        {/* Recent Orders */}
        <Card style={{ marginBottom: SPACING.xl }}>
          <h3 style={{ marginBottom: SPACING.md, fontWeight: 600 }}>سفارش‌های اخیر</h3>
          <Table
            columns={[
              { key: 'orderNumber', title: 'شماره سفارش' },
              { key: 'customer', title: 'مشتری' },
              { key: 'amount', title: 'مبلغ', render: (row) => formatCurrency(row.amount) },
              { key: 'status', title: 'وضعیت', render: (row) => <StatusBadge status={row.status} /> },
              { key: 'date', title: 'تاریخ', render: (row) => formatDate(row.date, true) },
              { key: 'actions', title: 'عملیات', render: () => <Button size="sm" variant="ghost">مشاهده</Button> },
            ]}
            data={recentOrders}
          />
        </Card>

        {/* Top Customers */}
        <Card>
          <h3 style={{ marginBottom: SPACING.md, fontWeight: 600 }}>برترین مشتریان</h3>
          <Table
            columns={[
              { key: 'name', title: 'نام' },
              { key: 'phone', title: 'تلفن' },
              { key: 'orders', title: 'تعداد سفارش', render: (row) => toPersianDigits(row.orders) },
              { key: 'totalSpent', title: 'مجموع خرید', render: (row) => formatCurrency(row.totalSpent) },
            ]}
            data={topCustomers}
          />
        </Card>
      </PageContainer>
    </PanelLayout>
  );
}
