// ============================================================
// YIO V7 — Shared Theme (Design System)
// ============================================================
// پالت رنگ، تایپوگرافی و استایل مشترک برای همه پنل‌ها
// ============================================================

export const COLORS = {
  // ===== Primary (YIO Brand) =====
  primary: {
    50: '#fef3e2',
    100: '#fde4bf',
    200: '#fac88a',
    300: '#f7ab54',
    400: '#f48e1f',
    500: '#d4730a',  // Brand color (wood orange)
    600: '#a85a08',
    700: '#7d4206',
    800: '#522b04',
    900: '#271502',
  },

  // ===== Neutrals =====
  gray: {
    50: '#f9fafb',
    100: '#f3f4f6',
    200: '#e5e7eb',
    300: '#d1d5db',
    400: '#9ca3af',
    500: '#6b7280',
    600: '#4b5563',
    700: '#374151',
    800: '#1f2937',
    900: '#111827',
  },

  // ===== Semantic =====
  success: { 50: '#ecfdf5', 500: '#10b981', 700: '#047857' },
  warning: { 50: '#fffbeb', 500: '#f59e0b', 700: '#b45309' },
  danger: { 50: '#fef2f2', 500: '#ef4444', 700: '#b91c1c' },
  info: { 50: '#eff6ff', 500: '#3b82f6', 700: '#1d4ed8' },

  // ===== Panel-Specific Accents =====
  shop: '#d4730a',     // Wood orange (warm, friendly)
  crm: '#3b82f6',      // Blue (sales, trust)
  erp: '#10b981',      // Green (production, growth)
  finance: '#8b5cf6',  // Purple (money, premium)
  admin: '#374151',    // Dark gray (authority)
} as const;

export const TYPOGRAPHY = {
  fontFamily: {
    sans: '"Vazirmatn", "Inter", system-ui, -apple-system, sans-serif',
    mono: '"Fira Code", "Consolas", monospace',
  },
  fontSize: {
    xs: '0.75rem',    // 12px
    sm: '0.875rem',   // 14px
    base: '1rem',     // 16px
    lg: '1.125rem',   // 18px
    xl: '1.25rem',    // 20px
    '2xl': '1.5rem',  // 24px
    '3xl': '1.875rem',// 30px
    '4xl': '2.25rem', // 36px
  },
  fontWeight: {
    normal: 400,
    medium: 500,
    semibold: 600,
    bold: 700,
  },
  lineHeight: {
    tight: 1.25,
    normal: 1.5,
    relaxed: 1.75,
  },
} as const;

export const SPACING = {
  xs: '0.25rem',  // 4px
  sm: '0.5rem',   // 8px
  md: '1rem',     // 16px
  lg: '1.5rem',   // 24px
  xl: '2rem',     // 32px
  '2xl': '3rem',  // 48px
  '3xl': '4rem',  // 64px
} as const;

export const SHADOWS = {
  sm: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
  md: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.05)',
  lg: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.05)',
  xl: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.05)',
} as const;

export const RADII = {
  sm: '0.25rem',
  md: '0.375rem',
  lg: '0.5rem',
  xl: '0.75rem',
  full: '9999px',
} as const;

export const TRANSITIONS = {
  fast: '150ms ease-in-out',
  base: '250ms ease-in-out',
  slow: '350ms ease-in-out',
} as const;

// ===== Theme Variants for Each Panel =====
export type PanelTheme = 'shop' | 'crm' | 'erp' | 'finance' | 'admin';

export interface ThemeConfig {
  primary: string;
  primaryLight: string;
  primaryDark: string;
  bg: string;
  surface: string;
  text: string;
  textMuted: string;
  border: string;
  sidebarBg: string;
  sidebarActive: string;
  sidebarText: string;
}

export const THEMES: Record<PanelTheme, ThemeConfig> = {
  shop: {
    primary: COLORS.primary[500],
    primaryLight: COLORS.primary[100],
    primaryDark: COLORS.primary[700],
    bg: '#ffffff',
    surface: '#f9fafb',
    text: COLORS.gray[900],
    textMuted: COLORS.gray[500],
    border: COLORS.gray[200],
    sidebarBg: '#ffffff',
    sidebarActive: COLORS.primary[500],
    sidebarText: COLORS.gray[700],
  },
  crm: {
    primary: COLORS.crm,
    primaryLight: '#dbeafe',
    primaryDark: '#1e40af',
    bg: '#f8fafc',
    surface: '#ffffff',
    text: COLORS.gray[900],
    textMuted: COLORS.gray[500],
    border: COLORS.gray[200],
    sidebarBg: '#1e293b',
    sidebarActive: COLORS.crm,
    sidebarText: '#e2e8f0',
  },
  erp: {
    primary: COLORS.erp,
    primaryLight: '#d1fae5',
    primaryDark: '#065f46',
    bg: '#f0fdf4',
    surface: '#ffffff',
    text: COLORS.gray[900],
    textMuted: COLORS.gray[500],
    border: COLORS.gray[200],
    sidebarBg: '#064e3b',
    sidebarActive: COLORS.erp,
    sidebarText: '#d1fae5',
  },
  finance: {
    primary: COLORS.finance,
    primaryLight: '#ede9fe',
    primaryDark: '#5b21b6',
    bg: '#faf5ff',
    surface: '#ffffff',
    text: COLORS.gray[900],
    textMuted: COLORS.gray[500],
    border: COLORS.gray[200],
    sidebarBg: '#4c1d95',
    sidebarActive: COLORS.finance,
    sidebarText: '#ede9fe',
  },
  admin: {
    primary: COLORS.admin,
    primaryLight: COLORS.gray[200],
    primaryDark: COLORS.gray[800],
    bg: '#f9fafb',
    surface: '#ffffff',
    text: COLORS.gray[900],
    textMuted: COLORS.gray[500],
    border: COLORS.gray[200],
    sidebarBg: COLORS.gray[900],
    sidebarActive: COLORS.gray[700],
    sidebarText: COLORS.gray[300],
  },
};

// ===== Status Colors =====
export const STATUS_COLORS: Record<string, { bg: string; text: string; label: string }> = {
  // Order Status
  pending: { bg: COLORS.warning[50], text: COLORS.warning[700], label: 'در انتظار' },
  confirmed: { bg: COLORS.info[50], text: COLORS.info[700], label: 'تأیید شده' },
  shipping: { bg: COLORS.info[50], text: COLORS.info[700], label: 'در حال ارسال' },
  delivered: { bg: COLORS.success[50], text: COLORS.success[700], label: 'تحویل شده' },
  cancelled: { bg: COLORS.danger[50], text: COLORS.danger[700], label: 'لغو شده' },

  // Production Status
  planned: { bg: COLORS.gray[100], text: COLORS.gray[700], label: 'برنامه‌ریزی شده' },
  in_progress: { bg: COLORS.info[50], text: COLORS.info[700], label: 'در حال انجام' },
  paused: { bg: COLORS.warning[50], text: COLORS.warning[700], label: 'متوقف شده' },
  completed: { bg: COLORS.success[50], text: COLORS.success[700], label: 'تکمیل شده' },

  // Payment Status
  unpaid: { bg: COLORS.danger[50], text: COLORS.danger[700], label: 'پرداخت‌نشده' },
  paid: { bg: COLORS.success[50], text: COLORS.success[700], label: 'پرداخت‌شده' },
  refunded: { bg: COLORS.warning[50], text: COLORS.warning[700], label: 'بازگشت‌داده شده' },

  // Quality
  pass: { bg: COLORS.success[50], text: COLORS.success[700], label: 'قبول' },
  fail: { bg: COLORS.danger[50], text: COLORS.danger[700], label: 'رد' },
  rework: { bg: COLORS.warning[50], text: COLORS.warning[700], label: 'اصلاح' },
};
