// ============================================================
// YIO V7 — Shared UI Components
// ============================================================
// کامپوننت‌های مشترک برای همه پنل‌ها
// ============================================================

import React from 'react';
import { COLORS, SPACING, SHADOWS, RADII, TRANSITIONS, STATUS_COLORS, ThemeConfig } from '../theme';

// ===== Button =====
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger' | 'success';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  icon?: React.ReactNode;
  fullWidth?: boolean;
}

export function Button({
  variant = 'primary',
  size = 'md',
  loading = false,
  icon,
  fullWidth = false,
  children,
  style,
  ...props
}: ButtonProps) {
  const sizes = {
    sm: { padding: `${SPACING.xs} ${SPACING.md}`, fontSize: '0.875rem' },
    md: { padding: `${SPACING.sm} ${SPACING.lg}`, fontSize: '1rem' },
    lg: { padding: `${SPACING.md} ${SPACING.xl}`, fontSize: '1.125rem' },
  };

  const variants = {
    primary: { backgroundColor: COLORS.primary[500], color: '#fff', border: 'none' },
    secondary: { backgroundColor: COLORS.gray[100], color: COLORS.gray[900], border: `1px solid ${COLORS.gray[200]}` },
    outline: { backgroundColor: 'transparent', color: COLORS.primary[500], border: `1px solid ${COLORS.primary[500]}` },
    ghost: { backgroundColor: 'transparent', color: COLORS.gray[700], border: 'none' },
    danger: { backgroundColor: COLORS.danger[500], color: '#fff', border: 'none' },
    success: { backgroundColor: COLORS.success[500], color: '#fff', border: 'none' },
  };

  return (
    <button
      style={{
        ...sizes[size],
        ...variants[variant],
        borderRadius: RADII.md,
        fontWeight: 500,
        cursor: loading ? 'wait' : 'pointer',
        opacity: loading ? 0.7 : 1,
        width: fullWidth ? '100%' : 'auto',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: SPACING.sm,
        transition: TRANSITIONS.fast,
        boxShadow: SHADOWS.sm,
        ...style,
      }}
      disabled={loading || props.disabled}
      {...props}
    >
      {loading && <Spinner size={size === 'lg' ? 'md' : 'sm'} />}
      {icon && !loading && icon}
      {children}
    </button>
  );
}

// ===== Spinner =====
export function Spinner({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const sizes = { sm: '16px', md: '24px', lg: '32px' };
  return (
    <div
      style={{
        width: sizes[size],
        height: sizes[size],
        border: `2px solid ${COLORS.gray[200]}`,
        borderTopColor: COLORS.primary[500],
        borderRadius: '50%',
        animation: 'spin 0.8s linear infinite',
      }}
    />
  );
}

// ===== Card =====
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  hoverable?: boolean;
  padding?: 'sm' | 'md' | 'lg';
}

export function Card({ hoverable = false, padding = 'md', children, style, ...props }: CardProps) {
  const paddings = {
    sm: SPACING.md,
    md: SPACING.lg,
    lg: SPACING.xl,
  };

  return (
    <div
      style={{
        backgroundColor: '#fff',
        borderRadius: RADII.lg,
        padding: paddings[padding],
        boxShadow: SHADOWS.md,
        transition: TRANSITIONS.base,
        cursor: hoverable ? 'pointer' : 'default',
        ...style,
      }}
      onMouseEnter={hoverable ? (e) => { e.currentTarget.style.boxShadow = SHADOWS.lg; } : undefined}
      onMouseLeave={hoverable ? (e) => { e.currentTarget.style.boxShadow = SHADOWS.md; } : undefined}
      {...props}
    >
      {children}
    </div>
  );
}

// ===== Badge =====
export interface BadgeProps {
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'info';
  size?: 'sm' | 'md';
  children: React.ReactNode;
}

export function Badge({ variant = 'default', size = 'md', children }: BadgeProps) {
  const variants = {
    default: { backgroundColor: COLORS.gray[100], color: COLORS.gray[700] },
    success: { backgroundColor: COLORS.success[50], color: COLORS.success[700] },
    warning: { backgroundColor: COLORS.warning[50], color: COLORS.warning[700] },
    danger: { backgroundColor: COLORS.danger[50], color: COLORS.danger[700] },
    info: { backgroundColor: COLORS.info[50], color: COLORS.info[700] },
  };

  const sizes = {
    sm: { padding: '2px 6px', fontSize: '0.75rem' },
    md: { padding: '4px 10px', fontSize: '0.875rem' },
  };

  return (
    <span
      style={{
        ...variants[variant],
        ...sizes[size],
        borderRadius: RADII.full,
        fontWeight: 500,
        display: 'inline-flex',
        alignItems: 'center',
      }}
    >
      {children}
    </span>
  );
}

// ===== Status Badge =====
export function StatusBadge({ status }: { status: string }) {
  const config = STATUS_COLORS[status] || { bg: COLORS.gray[100], text: COLORS.gray[700], label: status };
  return (
    <span
      style={{
        backgroundColor: config.bg,
        color: config.text,
        padding: '4px 10px',
        borderRadius: RADII.full,
        fontSize: '0.875rem',
        fontWeight: 500,
      }}
    >
      {config.label}
    </span>
  );
}

// ===== Input =====
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  icon?: React.ReactNode;
}

export function Input({ label, error, icon, style, ...props }: InputProps) {
  return (
    <div style={{ marginBottom: SPACING.md }}>
      {label && (
        <label style={{ display: 'block', marginBottom: SPACING.xs, fontWeight: 500, color: COLORS.gray[700] }}>
          {label}
        </label>
      )}
      <div style={{ position: 'relative' }}>
        {icon && (
          <div style={{ position: 'absolute', right: SPACING.md, top: '50%', transform: 'translateY(-50%)', color: COLORS.gray[400] }}>
            {icon}
          </div>
        )}
        <input
          style={{
            width: '100%',
            padding: `${SPACING.sm} ${SPACING.md}`,
            paddingRight: icon ? '2.5rem' : SPACING.md,
            borderRadius: RADII.md,
            border: `1px solid ${error ? COLORS.danger[500] : COLORS.gray[300]}`,
            fontSize: '1rem',
            outline: 'none',
            transition: TRANSITIONS.fast,
            ...style,
          }}
          onFocus={(e) => { e.currentTarget.style.borderColor = COLORS.primary[500]; }}
          onBlur={(e) => { e.currentTarget.style.borderColor = error ? COLORS.danger[500] : COLORS.gray[300]; }}
          {...props}
        />
      </div>
      {error && <p style={{ marginTop: SPACING.xs, color: COLORS.danger[500], fontSize: '0.875rem' }}>{error}</p>}
    </div>
  );
}

// ===== Modal =====
export interface ModalProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  footer?: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export function Modal({ open, onClose, title, children, footer, size = 'md' }: ModalProps) {
  if (!open) return null;

  const sizes = {
    sm: '400px',
    md: '600px',
    lg: '800px',
    xl: '1000px',
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 1000,
        padding: SPACING.lg,
      }}
      onClick={onClose}
    >
      <div
        style={{
          backgroundColor: '#fff',
          borderRadius: RADII.lg,
          boxShadow: SHADOWS.xl,
          width: '100%',
          maxWidth: sizes[size],
          maxHeight: '90vh',
          overflow: 'auto',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {title && (
          <div style={{ padding: SPACING.lg, borderBottom: `1px solid ${COLORS.gray[200]}`, fontWeight: 600, fontSize: '1.125rem' }}>
            {title}
          </div>
        )}
        <div style={{ padding: SPACING.lg }}>{children}</div>
        {footer && (
          <div style={{ padding: SPACING.lg, borderTop: `1px solid ${COLORS.gray[200]}`, display: 'flex', gap: SPACING.sm, justifyContent: 'flex-end' }}>
            {footer}
          </div>
        )}
      </div>
    </div>
  );
}

// ===== Empty State =====
export function EmptyState({ title, description, icon, action }: {
  title: string;
  description?: string;
  icon?: React.ReactNode;
  action?: React.ReactNode;
}) {
  return (
    <div style={{ textAlign: 'center', padding: SPACING['3xl'], color: COLORS.gray[500] }}>
      {icon && <div style={{ marginBottom: SPACING.lg, fontSize: '3rem' }}>{icon}</div>}
      <h3 style={{ color: COLORS.gray[700], marginBottom: SPACING.sm }}>{title}</h3>
      {description && <p style={{ marginBottom: SPACING.lg }}>{description}</p>}
      {action}
    </div>
  );
}

// ===== KPI Card (for dashboards) =====
export function KpiCard({ title, value, unit, trend, icon, color }: {
  title: string;
  value: string | number;
  unit?: string;
  trend?: { value: number; isPositive: boolean };
  icon?: React.ReactNode;
  color?: string;
}) {
  return (
    <Card>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <p style={{ color: COLORS.gray[500], fontSize: '0.875rem', marginBottom: SPACING.xs }}>{title}</p>
          <p style={{ fontSize: '1.5rem', fontWeight: 700, color: COLORS.gray[900] }}>
            {value}
            {unit && <span style={{ fontSize: '0.875rem', color: COLORS.gray[500], marginRight: SPACING.xs }}>{unit}</span>}
          </p>
          {trend && (
            <p style={{ marginTop: SPACING.xs, fontSize: '0.875rem', color: trend.isPositive ? COLORS.success[700] : COLORS.danger[700] }}>
              {trend.isPositive ? '▲' : '▼'} {Math.abs(trend.value)}%
            </p>
          )}
        </div>
        {icon && (
          <div style={{
            backgroundColor: color || COLORS.primary[100],
            color: color || COLORS.primary[500],
            padding: SPACING.sm,
            borderRadius: RADII.md,
            fontSize: '1.5rem',
          }}>
            {icon}
          </div>
        )}
      </div>
    </Card>
  );
}

// ===== Table =====
export interface TableProps {
  columns: Array<{ key: string; title: string; width?: string; render?: (row: any) => React.ReactNode }>;
  data: any[];
  loading?: boolean;
  emptyText?: string;
  onRowClick?: (row: any) => void;
}

export function Table({ columns, data, loading = false, emptyText = 'داده‌ای یافت نشد', onRowClick }: TableProps) {
  if (loading) {
    return (
      <div style={{ padding: SPACING.xl, textAlign: 'center' }}>
        <Spinner size="lg" />
      </div>
    );
  }

  if (data.length === 0) {
    return <EmptyState title={emptyText} />;
  }

  return (
    <div style={{ overflowX: 'auto', borderRadius: RADII.lg, border: `1px solid ${COLORS.gray[200]}` }}>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ backgroundColor: COLORS.gray[50] }}>
            {columns.map((col) => (
              <th
                key={col.key}
                style={{
                  padding: `${SPACING.sm} ${SPACING.md}`,
                  textAlign: 'right',
                  fontWeight: 600,
                  color: COLORS.gray[700],
                  borderBottom: `2px solid ${COLORS.gray[200]}`,
                  width: col.width,
                }}
              >
                {col.title}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row, i) => (
            <tr
              key={i}
              onClick={() => onRowClick?.(row)}
              style={{
                cursor: onRowClick ? 'pointer' : 'default',
                transition: TRANSITIONS.fast,
              }}
              onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = COLORS.gray[50]; }}
              onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'transparent'; }}
            >
              {columns.map((col) => (
                <td
                  key={col.key}
                  style={{
                    padding: `${SPACING.sm} ${SPACING.md}`,
                    borderBottom: `1px solid ${COLORS.gray[100]}`,
                    color: COLORS.gray[700],
                  }}
                >
                  {col.render ? col.render(row) : row[col.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ===== Pagination =====
export function Pagination({ page, pageSize, total, onPageChange }: {
  page: number;
  pageSize: number;
  total: number;
  onPageChange: (page: number) => void;
}) {
  const totalPages = Math.ceil(total / pageSize);
  if (totalPages <= 1) return null;

  const pages: number[] = [];
  const start = Math.max(1, page - 2);
  const end = Math.min(totalPages, page + 2);
  for (let i = start; i <= end; i++) pages.push(i);

  return (
    <div style={{ display: 'flex', gap: SPACING.xs, justifyContent: 'center', marginTop: SPACING.lg }}>
      <Button size="sm" variant="outline" disabled={page === 1} onClick={() => onPageChange(page - 1)}>
        قبلی
      </Button>
      {pages.map((p) => (
        <Button
          key={p}
          size="sm"
          variant={p === page ? 'primary' : 'outline'}
          onClick={() => onPageChange(p)}
        >
          {p}
        </Button>
      ))}
      <Button size="sm" variant="outline" disabled={page === totalPages} onClick={() => onPageChange(page + 1)}>
        بعدی
      </Button>
    </div>
  );
}

// ===== Page Container =====
export function PageContainer({ title, actions, children }: {
  title?: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div style={{ padding: SPACING.xl }}>
      {(title || actions) && (
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: SPACING.xl }}>
          {title && <h1 style={{ fontSize: '1.5rem', fontWeight: 700, color: COLORS.gray[900] }}>{title}</h1>}
          {actions && <div style={{ display: 'flex', gap: SPACING.sm }}>{actions}</div>}
        </div>
      )}
      {children}
    </div>
  );
}

// ===== Alert =====
export function Alert({ type = 'info', title, message, onClose }: {
  type?: 'info' | 'success' | 'warning' | 'danger';
  title?: string;
  message: string;
  onClose?: () => void;
}) {
  const types = {
    info: { bg: COLORS.info[50], border: COLORS.info[500], icon: 'ℹ️' },
    success: { bg: COLORS.success[50], border: COLORS.success[500], icon: '✅' },
    warning: { bg: COLORS.warning[50], border: COLORS.warning[500], icon: '⚠️' },
    danger: { bg: COLORS.danger[50], border: COLORS.danger[500], icon: '❌' },
  };

  const config = types[type];

  return (
    <div
      style={{
        backgroundColor: config.bg,
        border: `1px solid ${config.border}`,
        borderRadius: RADII.md,
        padding: SPACING.md,
        display: 'flex',
        alignItems: 'flex-start',
        gap: SPACING.sm,
      }}
    >
      <span style={{ fontSize: '1.25rem' }}>{config.icon}</span>
      <div style={{ flex: 1 }}>
        {title && <p style={{ fontWeight: 600, marginBottom: SPACING.xs }}>{title}</p>}
        <p style={{ color: COLORS.gray[700] }}>{message}</p>
      </div>
      {onClose && (
        <button
          onClick={onClose}
          style={{
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            fontSize: '1.25rem',
            color: COLORS.gray[500],
          }}
        >
          ×
        </button>
      )}
    </div>
  );
}

// ===== Export All =====
export { COLORS, SPACING, SHADOWS, RADII, TRANSITIONS, STATUS_COLORS } from '../theme';

// ===== Panel Layout (V8.2 Fix — was missing export) =====
export * from './panel-layout';
