// ============================================================
// YIO V7 — Shared Panel Layout
// ============================================================
// چیدمان مشترک برای پنل‌های مدیریت (CRM, ERP, Finance, Admin)
// شامل: Sidebar, Header, Content Area
// ============================================================

import React, { useState } from 'react';
import { COLORS, SPACING, SHADOWS, RADII, TRANSITIONS, THEMES, PanelTheme } from '../theme';
import { Button, Badge } from '../components';

export interface NavItem {
  label: string;
  icon?: React.ReactNode;
  href?: string;
  badge?: string | number;
  active?: boolean;
  onClick?: () => void;
  children?: NavItem[];
}

export interface PanelLayoutProps {
  theme: PanelTheme;
  title: string;
  navItems: NavItem[];
  user?: { name: string; role: string; avatar?: string };
  notifications?: number;
  onLogout?: () => void;
  onSearch?: (query: string) => void;
  children: React.ReactNode;
}

export function PanelLayout({
  theme,
  title,
  navItems,
  user,
  notifications = 0,
  onLogout,
  onSearch,
  children,
}: PanelLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const themeConfig = THEMES[theme];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch?.(searchQuery);
  };

  return (
    <div style={{ display: 'flex', minHeight: '100vh', backgroundColor: themeConfig.bg, direction: 'rtl' }}>
      {/* ===== Sidebar ===== */}
      <aside
        style={{
          width: sidebarOpen ? '260px' : '60px',
          backgroundColor: themeConfig.sidebarBg,
          color: themeConfig.sidebarText,
          transition: TRANSITIONS.base,
          display: 'flex',
          flexDirection: 'column',
          position: 'sticky',
          top: 0,
          height: '100vh',
          overflow: 'hidden',
          flexShrink: 0,
        }}
      >
        {/* Logo */}
        <div
          style={{
            padding: SPACING.lg,
            display: 'flex',
            alignItems: 'center',
            gap: SPACING.sm,
            borderBottom: `1px solid ${themeConfig.sidebarActive}33`,
            cursor: 'pointer',
          }}
          onClick={() => setSidebarOpen(!sidebarOpen)}
        >
          <div
            style={{
              width: '32px',
              height: '32px',
              borderRadius: RADII.md,
              backgroundColor: themeConfig.sidebarActive,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 700,
              flexShrink: 0,
            }}
          >
            {title.charAt(0)}
          </div>
          {sidebarOpen && <span style={{ fontWeight: 700, fontSize: '1.125rem' }}>{title}</span>}
        </div>

        {/* Navigation */}
        <nav style={{ flex: 1, padding: SPACING.md, overflowY: 'auto' }}>
          {navItems.map((item, i) => (
            <NavItemComponent
              key={i}
              item={item}
              themeConfig={themeConfig}
              expanded={sidebarOpen}
            />
          ))}
        </nav>

        {/* User */}
        {user && sidebarOpen && (
          <div
            style={{
              padding: SPACING.md,
              borderTop: `1px solid ${themeConfig.sidebarActive}33`,
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.sm, marginBottom: SPACING.sm }}>
              <div
                style={{
                  width: '40px',
                  height: '40px',
                  borderRadius: '50%',
                  backgroundColor: themeConfig.sidebarActive,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: 600,
                }}
              >
                {user.name.charAt(0)}
              </div>
              <div>
                <p style={{ fontWeight: 600, fontSize: '0.875rem' }}>{user.name}</p>
                <p style={{ fontSize: '0.75rem', opacity: 0.7 }}>{user.role}</p>
              </div>
            </div>
            {onLogout && (
              <button
                onClick={onLogout}
                style={{
                  width: '100%',
                  padding: `${SPACING.xs} ${SPACING.sm}`,
                  backgroundColor: 'transparent',
                  color: themeConfig.sidebarText,
                  border: `1px solid ${themeConfig.sidebarActive}33`,
                  borderRadius: RADII.md,
                  cursor: 'pointer',
                  fontSize: '0.875rem',
                  transition: TRANSITIONS.fast,
                }}
              >
                خروج
              </button>
            )}
          </div>
        )}
      </aside>

      {/* ===== Main Content ===== */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        {/* Header */}
        <header
          style={{
            backgroundColor: '#fff',
            padding: `${SPACING.sm} ${SPACING.xl}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            borderBottom: `1px solid ${COLORS.gray[200]}`,
            position: 'sticky',
            top: 0,
            zIndex: 10,
          }}
        >
          {/* Search */}
          {onSearch && (
            <form onSubmit={handleSearch} style={{ flex: 1, maxWidth: '400px' }}>
              <input
                type="text"
                placeholder="جستجو..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{
                  width: '100%',
                  padding: `${SPACING.sm} ${SPACING.md}`,
                  borderRadius: RADII.md,
                  border: `1px solid ${COLORS.gray[300]}`,
                  fontSize: '0.875rem',
                  outline: 'none',
                }}
              />
            </form>
          )}

          <div style={{ display: 'flex', alignItems: 'center', gap: SPACING.md }}>
            {/* Notifications */}
            <button
              style={{
                position: 'relative',
                padding: SPACING.sm,
                borderRadius: RADII.md,
                border: 'none',
                backgroundColor: 'transparent',
                cursor: 'pointer',
                fontSize: '1.25rem',
              }}
            >
              🔔
              {notifications > 0 && (
                <span
                  style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    backgroundColor: COLORS.danger[500],
                    color: '#fff',
                    borderRadius: '50%',
                    width: '18px',
                    height: '18px',
                    fontSize: '0.75rem',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  {notifications > 9 ? '۹+' : notifications}
                </span>
              )}
            </button>

            {/* Quick Actions */}
            <Button variant="ghost" size="sm">⚙️</Button>
          </div>
        </header>

        {/* Content */}
        <main style={{ flex: 1, padding: SPACING.xl, overflowY: 'auto' }}>
          {children}
        </main>
      </div>
    </div>
  );
}

// ===== Nav Item Component =====
function NavItemComponent({
  item,
  themeConfig,
  expanded,
}: {
  item: NavItem;
  themeConfig: typeof THEMES.shop;
  expanded: boolean;
}) {
  const [open, setOpen] = useState(false);

  return (
    <div style={{ marginBottom: SPACING.xs }}>
      <button
        onClick={() => item.children ? setOpen(!open) : item.onClick?.()}
        style={{
          width: '100%',
          padding: `${SPACING.sm} ${SPACING.md}`,
          display: 'flex',
          alignItems: 'center',
          gap: SPACING.sm,
          backgroundColor: item.active ? themeConfig.sidebarActive : 'transparent',
          color: item.active ? '#fff' : themeConfig.sidebarText,
          border: 'none',
          borderRadius: RADII.md,
          cursor: 'pointer',
          fontSize: '0.875rem',
          fontWeight: item.active ? 600 : 400,
          transition: TRANSITIONS.fast,
          textAlign: 'right',
        }}
        onMouseEnter={(e) => { if (!item.active) e.currentTarget.style.backgroundColor = `${themeConfig.sidebarActive}22`; }}
        onMouseLeave={(e) => { if (!item.active) e.currentTarget.style.backgroundColor = 'transparent'; }}
      >
        {item.icon && <span style={{ flexShrink: 0 }}>{item.icon}</span>}
        {expanded && (
          <>
            <span style={{ flex: 1 }}>{item.label}</span>
            {item.badge && (
              <Badge variant="default" size="sm">{item.badge}</Badge>
            )}
            {item.children && (
              <span style={{ transform: open ? 'rotate(90deg)' : 'none' }}>›</span>
            )}
          </>
        )}
      </button>

      {/* Children */}
      {item.children && open && expanded && (
        <div style={{ paddingInlineStart: SPACING.lg, marginTop: SPACING.xs }}>
          {item.children.map((child, i) => (
            <NavItemComponent key={i} item={child} themeConfig={themeConfig} expanded={expanded} />
          ))}
        </div>
      )}
    </div>
  );
}
