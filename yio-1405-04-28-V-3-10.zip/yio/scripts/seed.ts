// Seed script for YIO wooden products shop - with multiple images and videos
import { db } from '../src/lib/db';
import { encrypt } from '../src/lib/security';

const sampleImages = {
  toy1: [
    "https://images.unsplash.com/photo-1558877385-81a1c7e67d72?w=600&h=600&fit=crop",
    "https://images.unsplash.com/photo-1558877385-81a1c7e67d72?w=600&h=600&fit=crop&sat=-100",
    "https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?w=600&h=600&fit=crop",
    "https://images.unsplash.com/photo-1587654780291-39c9404d746b?w=600&h=600&fit=crop",
  ],
  kitchen1: [
    "https://images.unsplash.com/photo-1584346133934-a3a4db9c3b06?w=600&h=600&fit=crop",
    "https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?w=600&h=600&fit=crop",
    "https://images.unsplash.com/photo-1610701596007-11502861dcfa?w=600&h=600&fit=crop",
  ],
  chair1: [
    "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?w=600&h=600&fit=crop",
    "https://images.unsplash.com/photo-1503602642458-232111445657?w=600&h=600&fit=crop",
    "https://images.unsplash.com/photo-1593062096033-9a26b09da705?w=600&h=600&fit=crop",
  ],
};

const sampleVideos = [
  "https://www.w3schools.com/html/mov_bbb.mp4",
  "https://www.w3schools.com/html/movie.mp4",
];

const woodenProducts = [
  {
    title: "اسباب‌بازی چوبی ماشین باربری مدل کلاسیک",
    brand: "YIO",
    category: "اسباب‌بازی چوبی",
    price: 285000,
    salePrice: 228000,
    image: sampleImages.toy1[0],
    images: JSON.stringify(sampleImages.toy1),
    videos: JSON.stringify([sampleVideos[0]]),
    rating: 4.8,
    ratingCount: 124,
    inStock: true,
    fastDelivery: true,
    isSpecial: true,
    description: "ماشین باربری چوبی دست‌ساز با چوب راش طبیعی، رنگ‌های غیرسمی و مناسب برای کودکان ۳ سال به بالا",
    woodType: "چوب راش",
    colors: '[{"name":"قرمز","code":"#dc2626"},{"name":"آبی","code":"#2563eb"}]',
  },
  {
    title: "ست ظروف آشپزخانه چوبی ۶ تکه",
    brand: "YIO",
    category: "ظروف آشپزخانه",
    price: 450000,
    salePrice: 382000,
    image: sampleImages.kitchen1[0],
    images: JSON.stringify(sampleImages.kitchen1),
    videos: JSON.stringify([sampleVideos[1]]),
    rating: 4.9,
    ratingCount: 256,
    inStock: true,
    fastDelivery: true,
    isSpecial: true,
    description: "ست ۶ تکه ظروف آشپزخانه چوبی شامل بشقاب، کاسه و قاشق، ساخته شده از چوب بامبو ضدآب",
    woodType: "چوب بامبو",
    colors: '[{"name":"طبیعی","code":"#d4a373"}]',
  },
  {
    title: "صندلی چوبی راحتی مدل اسکاندیناوی",
    brand: "YIO",
    category: "مبلمان چوبی",
    price: 2850000,
    salePrice: 2422000,
    image: sampleImages.chair1[0],
    images: JSON.stringify(sampleImages.chair1),
    videos: JSON.stringify([sampleVideos[0], sampleVideos[1]]),
    rating: 4.7,
    ratingCount: 89,
    inStock: true,
    fastDelivery: false,
    isSpecial: true,
    description: "صندلی راحتی چوبی با طراحی اسکاندیناوی، ساخته شده از چوب بلوط با رویه پارچه‌ای",
    woodType: "چوب بلوط",
    colors: '[{"name":"طبیعی","code":"#d4a373"},{"name":"قهوه‌ای","code":"#8b5cf6"}]',
  },
  {
    title: "پازل چوبی حروف الفبا فارسی",
    brand: "YIO",
    category: "اسباب‌بازی چوبی",
    price: 195000,
    salePrice: 156000,
    image: "https://images.unsplash.com/photo-1587654780291-39c9404d746b?w=400&h=400&fit=crop",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1587654780291-39c9404d746b?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1558877385-81a1c7e67d72?w=600&h=600&fit=crop",
    ]),
    videos: JSON.stringify([sampleVideos[0]]),
    rating: 4.6,
    ratingCount: 342,
    inStock: true,
    fastDelivery: true,
    isSpecial: true,
    description: "پازل چوبی آموزشی حروف الفبا فارسی با ۳۲ قطعه، رنگ‌های زیبا و مناسب برای کودکان ۳ سال به بالا",
    woodType: "چوب MDF",
    colors: '[{"name":"رنگارنگ","code":"#f59e0b"}]',
  },
  {
    title: "تخته برش چوبی بامبو مدل آشپز",
    brand: "YIO",
    category: "ظروف آشپزخانه",
    price: 320000,
    salePrice: 256000,
    image: "https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?w=400&h=400&fit=crop",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1556228453-efd6c1ff04f6?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1584346133934-a3a4db9c3b06?w=600&h=600&fit=crop",
    ]),
    videos: null,
    rating: 4.8,
    ratingCount: 178,
    inStock: true,
    fastDelivery: true,
    isSpecial: true,
    description: "تخته برش چوبی بامبو با ابعاد ۴۰×۳۰ سانتی‌متر، ضدباکتری و مقاوم در برابر رطوبت",
    woodType: "چوب بامبو",
    colors: '[{"name":"طبیعی","code":"#d4a373"}]',
  },
  {
    title: "میز ناهارخوری چوبی ۶ نفره مدل کلاسیک",
    brand: "YIO",
    category: "مبلمان چوبی",
    price: 8500000,
    salePrice: 7650000,
    image: "https://images.unsplash.com/photo-1577140917170-285929fb55b7?w=400&h=400&fit=crop",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1577140917170-285929fb55b7?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1532372576444-dda954194ad0?w=600&h=600&fit=crop",
    ]),
    videos: null,
    rating: 4.9,
    ratingCount: 67,
    inStock: true,
    fastDelivery: false,
    isSpecial: true,
    description: "میز ناهارخوری چوبی ۶ نفره با طراحی کلاسیک، ساخته شده از چوب گردو مرغوب",
    woodType: "چوب گردو",
    colors: '[{"name":"گردویی","code":"#5d4037"}]',
  },
  {
    title: "اسباب‌بازی چوبی خانه عروسکی ۳ طبقه",
    brand: "YIO",
    category: "اسباب‌بازی چوبی",
    price: 1250000,
    salePrice: 1000000,
    image: "https://images.unsplash.com/photo-1589556243405-b0c6b1e9a2a3?w=400&h=400&fit=crop",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1589556243405-b0c6b1e9a2a3?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1587654780291-39c9404d746b?w=600&h=600&fit=crop",
    ]),
    videos: JSON.stringify([sampleVideos[0]]),
    rating: 4.8,
    ratingCount: 145,
    inStock: true,
    fastDelivery: true,
    isSpecial: true,
    description: "خانه عروسکی چوبی ۳ طبقه با اثاثیه کامل، طراحی زیبا و رنگ‌های شاد، مناسب کودکان ۵ سال به بالا",
    woodType: "چوب راش",
    colors: '[{"name":"صورتی","code":"#ec4899"},{"name":"آبی","code":"#2563eb"}]',
  },
  {
    title: "قاشق و چنگال چوبی ست ۱۲ تکه",
    brand: "YIO",
    category: "ظروف آشپزخانه",
    price: 180000,
    salePrice: 144000,
    image: "https://images.unsplash.com/photo-1610701596007-11502861dcfa?w=400&h=400&fit=crop",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1610701596007-11502861dcfa?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1604335399105-a0c585fd81a1?w=600&h=600&fit=crop",
    ]),
    videos: null,
    rating: 4.7,
    ratingCount: 423,
    inStock: true,
    fastDelivery: true,
    isSpecial: false,
    description: "ست ۱۲ تکه قاشق و چنگال چوبی بامبو، سبک و بادوام، مناسب برای سالاد و پاستا",
    woodType: "چوب بامبو",
    colors: '[{"name":"طبیعی","code":"#d4a373"}]',
  },
  {
    title: "صندلی چوبی کودک مدل حیوانات",
    brand: "YIO",
    category: "مبلمان چوبی",
    price: 680000,
    salePrice: 544000,
    image: "https://images.unsplash.com/photo-1580169936270-b8d6b6c5c5e1?w=400&h=400&fit=crop",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1580169936270-b8d6b6c5c5e1?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?w=600&h=600&fit=crop",
    ]),
    videos: null,
    rating: 4.6,
    ratingCount: 89,
    inStock: true,
    fastDelivery: true,
    isSpecial: false,
    description: "صندلی چوبی کودک با طرح حیوانات دوست‌داشتنی، رنگ‌های غیرسمی و پایه‌های محکم",
    woodType: "چوب راش",
    colors: '[{"name":"خرس","code":"#8b5cf6"},{"name":"گربه","code":"#f59e0b"}]',
  },
  {
    title: "تاب چوبی حیاطی مدل کلاسیک",
    brand: "YIO",
    category: "مبلمان چوبی",
    price: 1850000,
    salePrice: 1480000,
    image: "https://images.unsplash.com/photo-1593062096033-9a26b09da705?w=400&h=400&fit=crop",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1593062096033-9a26b09da705?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1503602642458-232111445657?w=600&h=600&fit=crop",
    ]),
    videos: null,
    rating: 4.8,
    ratingCount: 56,
    inStock: true,
    fastDelivery: false,
    isSpecial: false,
    description: "تاب چوبی حیاطی با تیرهای فولادی و نشیمن پارچه‌ای، تحمل وزن تا ۱۲۰ کیلوگرم",
    woodType: "چوب بلوط",
    colors: '[{"name":"طبیعی","code":"#d4a373"}]',
  },
  {
    title: "اسباب‌بازی چوبی قطار سریع‌السیر",
    brand: "YIO",
    category: "اسباب‌بازی چوبی",
    price: 395000,
    salePrice: 316000,
    image: "https://images.unsplash.com/photo-1566576912321-d58ddd7a6088?w=400&h=400&fit=crop",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1566576912321-d58ddd7a6088?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1558877385-81a1c7e67d72?w=600&h=600&fit=crop",
    ]),
    videos: JSON.stringify([sampleVideos[0]]),
    rating: 4.7,
    ratingCount: 267,
    inStock: true,
    fastDelivery: true,
    isSpecial: false,
    description: "ست قطار چوبی شامل موتور، ۳ واگن و ریل، طراحی شده برای توسعه مهارت‌های حرکتی کودکان",
    woodType: "چوب راش",
    colors: '[{"name":"قرمز","code":"#dc2626"},{"name":"آبی","code":"#2563eb"}]',
  },
  {
    title: "ست ملاقه و کفگیر چوبی ۵ تکه",
    brand: "YIO",
    category: "ظروف آشپزخانه",
    price: 245000,
    salePrice: 196000,
    image: "https://images.unsplash.com/photo-1604335399105-a0c585fd81a1?w=400&h=400&fit=crop",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1604335399105-a0c585fd81a1?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1610701596007-11502861dcfa?w=600&h=600&fit=crop",
    ]),
    videos: null,
    rating: 4.7,
    ratingCount: 198,
    inStock: true,
    fastDelivery: true,
    isSpecial: false,
    description: "ست ۵ تکه ملاقه و کفگیر چوبی برای پخت و پز، با دسته‌های راحت و ضدخش",
    woodType: "چوب راش",
    colors: '[{"name":"طبیعی","code":"#d4a373"}]',
  },
  {
    title: "میز کنار مبل چوبی مدل مینیمال",
    brand: "YIO",
    category: "مبلمان چوبی",
    price: 980000,
    salePrice: 784000,
    image: "https://images.unsplash.com/photo-1532372576444-dda954194ad0?w=400&h=400&fit=crop",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1532372576444-dda954194ad0?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1577140917170-285929fb55b7?w=600&h=600&fit=crop",
    ]),
    videos: null,
    rating: 4.6,
    ratingCount: 78,
    inStock: true,
    fastDelivery: false,
    isSpecial: false,
    description: "میز کنار مبل چوبی با طراحی مینیمال و پایه‌های متقاطع، مناسب برای دکوراسیون مدرن",
    woodType: "چوب گردو",
    colors: '[{"name":"گردویی","code":"#5d4037"}]',
  },
  {
    title: "بلوک‌های ساختمانی چوبی ۱۰۰ تکه",
    brand: "YIO",
    category: "اسباب‌بازی چوبی",
    price: 550000,
    salePrice: 440000,
    image: "https://images.unsplash.com/photo-1587654780291-39c9404d746b?w=400&h=400&fit=crop",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1587654780291-39c9404d746b?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1558877385-81a1c7e67d72?w=600&h=600&fit=crop",
    ]),
    videos: JSON.stringify([sampleVideos[0]]),
    rating: 4.9,
    ratingCount: 512,
    inStock: true,
    fastDelivery: true,
    isSpecial: false,
    description: "ست ۱۰۰ تکه بلوک‌های ساختمانی چوبی رنگارنگ برای توسعه خلاقیت و مهارت‌های کودکان",
    woodType: "چوب راش",
    colors: '[{"name":"رنگارنگ","code":"#f59e0b"}]',
  },
  {
    title: "ظرف میوه چوبی دست‌ساز مدل تزئینی",
    brand: "YIO",
    category: "ظروف آشپزخانه",
    price: 380000,
    salePrice: 304000,
    image: "https://images.unsplash.com/photo-1610701596061-2ecf227e85b2?w=400&h=400&fit=crop",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1610701596061-2ecf227e85b2?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1584346133934-a3a4db9c3b06?w=600&h=600&fit=crop",
    ]),
    videos: null,
    rating: 4.8,
    ratingCount: 134,
    inStock: true,
    fastDelivery: true,
    isSpecial: false,
    description: "ظرف میوه چوبی دست‌ساز با طراحی تزئینی، مناسب برای میز پذیرایی و دکوراسیون",
    woodType: "چوب گردو",
    colors: '[{"name":"گردویی","code":"#5d4037"}]',
  },
  {
    title: "آینه دستی چوبی تزئینی مدل کلاسیک",
    brand: "YIO",
    category: "دکوراسیون چوبی",
    price: 420000,
    salePrice: 336000,
    image: "https://images.unsplash.com/photo-1610701596007-11502861dcfa?w=400&h=400&fit=crop",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1610701596007-11502861dcfa?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1605518216938-7c31b7b14ad0?w=600&h=600&fit=crop",
    ]),
    videos: null,
    rating: 4.7,
    ratingCount: 67,
    inStock: true,
    fastDelivery: true,
    isSpecial: false,
    description: "آینه دستی چوبی تزئینی با قاب چوبی منبت‌کاری شده، مناسب برای دکوراسیون کلاسیک",
    woodType: "چوب گردو",
    colors: '[{"name":"گردویی","code":"#5d4037"}]',
  },
  {
    title: "تابلو چوبی نقشه ایران دست‌ساز",
    brand: "YIO",
    category: "دکوراسیون چوبی",
    price: 680000,
    salePrice: 544000,
    image: "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=400&h=400&fit=crop",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1524678606370-a47ad25cb82a?w=600&h=600&fit=crop",
    ]),
    videos: JSON.stringify([sampleVideos[1]]),
    rating: 4.9,
    ratingCount: 89,
    inStock: true,
    fastDelivery: true,
    isSpecial: false,
    description: "تابلو چوبی نقشه ایران با لیزری برش دقیق، ابعاد ۶۰×۴۰ سانتی‌متر، مناسب برای دیوار",
    woodType: "چوب MDF",
    colors: '[{"name":"طبیعی","code":"#d4a373"}]',
  },
  {
    title: "ست قفسه چوبی دیواری ۳ طبقه",
    brand: "YIO",
    category: "دکوراسیون چوبی",
    price: 750000,
    salePrice: 600000,
    image: "https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=400&h=400&fit=crop",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1595428774223-ef52624120d2?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1532372576444-dda954194ad0?w=600&h=600&fit=crop",
    ]),
    videos: null,
    rating: 4.6,
    ratingCount: 145,
    inStock: true,
    fastDelivery: false,
    isSpecial: false,
    description: "ست قفسه چوبی دیواری ۳ طبقه با نصب آسان، مناسب برای کتاب و اشیای تزئینی",
    woodType: "چوب راش",
    colors: '[{"name":"طبیعی","code":"#d4a373"},{"name":"سفید","code":"#ffffff"}]',
  },
  {
    title: "جعبه جواهرات چوبی منبت‌کاری شده",
    brand: "YIO",
    category: "دکوراسیون چوبی",
    price: 580000,
    salePrice: 464000,
    image: "https://images.unsplash.com/photo-1605518216938-7c31b7b14ad0?w=400&h=400&fit=crop",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1605518216938-7c31b7b14ad0?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1610701596007-11502861dcfa?w=600&h=600&fit=crop",
    ]),
    videos: JSON.stringify([sampleVideos[0]]),
    rating: 4.8,
    ratingCount: 178,
    inStock: true,
    fastDelivery: true,
    isSpecial: false,
    description: "جعبه جواهرات چوبی با منبت‌کاری دستی، دارای چندین بخش و آینه داخلی",
    woodType: "چوب گردو",
    colors: '[{"name":"گردویی","code":"#5d4037"}]',
  },
  {
    title: "ساعت دیواری چوبی مدل رومیزی",
    brand: "YIO",
    category: "دکوراسیون چوبی",
    price: 490000,
    salePrice: 392000,
    image: "https://images.unsplash.com/photo-1524678606370-a47ad25cb82a?w=400&h=400&fit=crop",
    images: JSON.stringify([
      "https://images.unsplash.com/photo-1524678606370-a47ad25cb82a?w=600&h=600&fit=crop",
      "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=600&h=600&fit=crop",
    ]),
    videos: null,
    rating: 4.7,
    ratingCount: 156,
    inStock: true,
    fastDelivery: true,
    isSpecial: false,
    description: "ساعت دیواری چوبی با طراحی مدرن و عقربه‌های چوبی، ابعاد ۳۵ سانتی‌متر",
    woodType: "چوب MDF",
    colors: '[{"name":"طبیعی","code":"#d4a373"},{"name":"مشکی","code":"#1a1a1a"}]',
  },
];

async function main() {
  console.log('شروع seed محصولات چوبی YIO با تصاویر چندگانه...');

  // حذف جداول وابسته اول (ترتیب مهم است - از فرزند به پدر)
  // تا foreign key constraint نقض نشود
  await db.orderItem.deleteMany({});
  await db.notificationRequest.deleteMany({});
  await db.wishlist.deleteMany({});
  await db.review.deleteMany({});
  await db.order.deleteMany({});
  await db.customer.deleteMany({});
  await db.product.deleteMany({});

  for (const product of woodenProducts) {
    await db.product.create({ data: product });
  }

  const count = await db.product.count();
  console.log(`✅ ${count} محصول با تصاویر و ویدیوهای چندگانه اضافه شد`);

  // اضافه کردن چند سفارش نمونه
  const customer1 = await db.customer.create({
    data: {
      name: "محمد رضایی",
      phone: "09121234567",
      email: "mohammad@example.com",
      address: "تهران، خیابان ولیعصر، پلاک ۱۲۳",
      postalCode: "1234567890",
      city: "تهران",
    },
  });

  const customer2 = await db.customer.create({
    data: {
      name: "فاطمه احمدی",
      phone: "09127654321",
      email: "fateme@example.com",
      address: "اصفهان، خیابان چهارباغ، کوچه گل، پلاک ۴۵",
      postalCode: "9876543210",
      city: "اصفهان",
    },
  });

  const customer3 = await db.customer.create({
    data: {
      name: "علی محمدی",
      phone: "09120000003",
      address: "شیراز، بلوار زند، پلاک ۷۸",
      city: "شیراز",
    },
  });

  const products = await db.product.findMany();

  const order1 = await db.order.create({
    data: {
      orderNumber: "YIO-1001",
      customerId: customer1.id,
      status: "delivered",
      totalAmount: 285000 + 195000,
      shippingCost: 0,
      finalAmount: 285000 + 195000,
      paymentMethod: "cod",
      paymentStatus: "paid",
      shippingAddress: customer1.address,
      shippingCity: customer1.city,
      postalCode: customer1.postalCode,
      recipientName: customer1.name,
      recipientPhone: customer1.phone,
      trackingCode: "TRK12345678",
      items: {
        create: [
          {
            productId: products[0].id,
            productTitle: products[0].title,
            productImage: products[0].image,
            price: products[0].discountPrice || products[0].price,
            quantity: 1,
          },
          {
            productId: products[3].id,
            productTitle: products[3].title,
            productImage: products[3].image,
            price: products[3].discountPrice || products[3].price,
            quantity: 1,
          },
        ],
      },
    },
  });

  const order2 = await db.order.create({
    data: {
      orderNumber: "YIO-1002",
      customerId: customer2.id,
      status: "shipping",
      totalAmount: 450000,
      shippingCost: 89000,
      finalAmount: 539000,
      paymentMethod: "online",
      paymentStatus: "paid",
      shippingAddress: customer2.address,
      shippingCity: customer2.city,
      postalCode: customer2.postalCode,
      recipientName: customer2.name,
      recipientPhone: customer2.phone,
      trackingCode: "TRK12345679",
      items: {
        create: [
          {
            productId: products[1].id,
            productTitle: products[1].title,
            productImage: products[1].image,
            price: products[1].discountPrice || products[1].price,
            quantity: 1,
          },
        ],
      },
    },
  });

  const order3 = await db.order.create({
    data: {
      orderNumber: "YIO-1003",
      customerId: customer3.id,
      status: "pending",
      totalAmount: 2850000,
      shippingCost: 0,
      finalAmount: 2850000,
      paymentMethod: "cod",
      paymentStatus: "unpaid",
      shippingAddress: customer3.address,
      shippingCity: customer3.city,
      recipientName: customer3.name,
      recipientPhone: customer3.phone,
      items: {
        create: [
          {
            productId: products[2].id,
            productTitle: products[2].title,
            productImage: products[2].image,
            price: products[2].discountPrice || products[2].price,
            quantity: 1,
          },
        ],
      },
    },
  });

  console.log(`✅ ۳ سفارش نمونه ایجاد شد: ${order1.orderNumber}, ${order2.orderNumber}, ${order3.orderNumber}`);

  // === افزودن روش‌های پرداخت پیش‌فرض ===
  console.log('افزودن روش‌های پرداخت پیش‌فرض...');

  // پاک کردن روش‌های پرداخت قبلی
  await db.paymentMethod.deleteMany({});

  await db.paymentMethod.create({
    data: {
      name: 'پرداخت در محل',
      type: 'cod',
      description: 'پرداخت نقدی هنگام تحویل کالا',
      isActive: true,
      isDefault: true,
      priority: 1,
    },
  });

  await db.paymentMethod.create({
    data: {
      name: 'درگاه زرین‌پال',
      type: 'online',
      bank: 'زرین‌پال',
      merchantId: encrypt('xxxxxxxx-1234-1234-1234-123456789012'),
      terminalId: encrypt('12345678'),
      apiKey: encrypt('sample-api-key-for-demo'),
      callbackUrl: 'https://yio-shop.ir/api/payment/callback',
      description: 'پرداخت آنلاین با تمام کارت‌های بانکی',
      isActive: true,
      isDefault: false,
      priority: 2,
    },
  });

  await db.paymentMethod.create({
    data: {
      name: 'انتقال بانکی',
      type: 'transfer',
      description: 'بانک ملت - شماره کارت: ۶۱۰۴-۳۳۷8-xxxx-xxxx به نام شرکت YIO',
      isActive: true,
      isDefault: false,
      priority: 3,
    },
  });

  console.log('✅ ۳ روش پرداخت پیش‌فرض اضافه شد');

  // === افزودن کوپن‌های تخفیف پیش‌فرض ===
  console.log('افزودن کوپن‌های تخفیف پیش‌فرض...');

  // پاک کردن کوپن‌های قبلی و استفاده‌های آن‌ها (foreign key constraint)
  await db.couponUsage.deleteMany({});
  await db.coupon.deleteMany({});

  const now = new Date();
  const nextMonth = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
  const nextWeek = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

  await db.coupon.create({
    data: {
      code: 'WELCOME',
      description: 'کد تخفیف ویژه مشتریان جدید - ارسال رایگان',
      type: 'free_shipping',
      value: 0,
      perUserLimit: 1,
      validFrom: now,
      validUntil: nextMonth,
      isActive: true,
      firstOrderOnly: true,
    },
  });

  await db.coupon.create({
    data: {
      code: 'YIO10',
      description: '۱۰٪ تخفیف برای همه خریدها',
      type: 'percent',
      value: 10,
      maxDiscount: 100000,
      minPurchase: 200000,
      usageLimit: 100,
      perUserLimit: 5,
      validFrom: now,
      validUntil: nextMonth,
      isActive: true,
    },
  });

  await db.coupon.create({
    data: {
      code: 'BULK50',
      description: '۵۰ هزار تومان تخفیف برای خریدهای بالای ۵۰۰ هزار تومان',
      type: 'fixed',
      value: 50000,
      minPurchase: 500000,
      usageLimit: 50,
      perUserLimit: 3,
      validFrom: now,
      validUntil: nextMonth,
      isActive: true,
    },
  });

  console.log('✅ ۳ کوپن تخفیف پیش‌فرض اضافه شد: WELCOME, YIO10, BULK50');

  // === افزودن پیام‌های تماس نمونه ===
  console.log('افزودن پیام‌های تماس نمونه...');

  // پاک کردن پیام‌های تماس قبلی
  await db.contactMessage.deleteMany({});

  await db.contactMessage.create({
    data: {
      name: 'مریم حسینی',
      phone: '09121111111',
      email: 'maryam@example.com',
      subject: 'سؤال درباره مواد رنگ استفاده شده',
      message: 'سلام، آیا رنگ‌های استفاده شده در اسباب‌بازی‌های چوبی برای کودکان ایمن هستند؟ مادرم برای نوه‌اش می‌خواد.',
      status: 'new',
    },
  });

  await db.contactMessage.create({
    data: {
      name: 'رضا کریمی',
      phone: '09122222222',
      subject: 'زمان ارسال به شهرستان',
      message: 'سلام، من از شیراز هستم. می‌خواستم بدونم ارسال به شیراز چند روز طول می‌کشه؟',
      status: 'read',
    },
  });

  console.log('✅ ۲ پیام تماس نمونه اضافه شد');

  // === افزودن درخواست سفارش عمده نمونه ===
  console.log('افزودن درخواست سفارش عمده نمونه...');

  // پاک کردن درخواست‌های عمده قبلی
  await db.wholesaleOrder.deleteMany({});

  await db.wholesaleOrder.create({
    data: {
      companyName: 'فروشگاه игрушки جدید',
      contactPerson: 'آقای محمدی',
      phone: '09123333333',
      email: 'info@toys-new.ir',
      city: 'تهران',
      productCategory: 'اسباب‌بازی چوبی',
      quantity: 100,
      description: 'برای فروشگاه زنجیره‌ای، به ۱۰۰ عدد اسباب‌بازی چوبی نیاز داریم. لطفاً قیمت عمده را ارسال کنید.',
      status: 'pending',
    },
  });

  await db.wholesaleOrder.create({
    data: {
      companyName: 'رستوران چوب‌بر',
      contactPerson: 'خانم احمدی',
      phone: '09124444444',
      city: 'اصفهان',
      productCategory: 'ظروف آشپزخانه',
      quantity: 50,
      description: 'برای رستورانمون ظروف چوبی نیاز داریم',
      status: 'contacted',
    },
  });

  console.log('✅ ۲ درخواست سفارش عمده نمونه اضافه شد');

  // === آمار نهایی ===
  const productCount = await db.product.count();
  const orderCount = await db.order.count();
  const customerCount = await db.customer.count();
  const couponCount = await db.coupon.count();
  const paymentCount = await db.paymentMethod.count();
  const faqCount = await db.fAQ.count();
  const contactCount = await db.contactMessage.count();
  const wholesaleCount = await db.wholesaleOrder.count();

  console.log('\n📊 === آمار نهایی داده‌های پیش‌فرض ===');
  console.log(`   محصولات: ${productCount}`);
  console.log(`   سفارش‌ها: ${orderCount}`);
  console.log(`   مشتریان: ${customerCount}`);
  console.log(`   کوپن‌های تخفیف: ${couponCount}`);
  console.log(`   روش‌های پرداخت: ${paymentCount}`);
  console.log(`   سؤالات متداول: ${faqCount}`);
  console.log(`   پیام‌های تماس: ${contactCount}`);
  console.log(`   درخواست‌های عمده: ${wholesaleCount}`);
  console.log('================================\n');
}

main()
  .catch((e) => {
    console.error('خطا در seed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
