import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const products = await db.product.findMany({
    select: {
      id: true,
      price: true,
      salePrice: true,
      discountPrice: true,
      discountPercent: true,
      image: true,
      images: true,
      videos: true,
      colors: true,
    },
  });

  const failures: string[] = [];

  for (const product of products) {
    if (product.salePrice != null && product.salePrice >= product.price) {
      failures.push(`Product ${product.id}: salePrice must be lower than price`);
    }

    // Legacy data must already be migrated before this final cleanup.
    if (product.image || product.images || product.videos || product.colors) {
      failures.push(`Product ${product.id}: legacy media/color data still exists`);
    }

    if (product.discountPrice != null || product.discountPercent != null) {
      failures.push(`Product ${product.id}: legacy discount data still exists`);
    }
  }

  if (failures.length) {
    console.error("Final product schema migration aborted.");
    console.error(failures.join("\n"));
    process.exit(1);
  }

  console.log(`Preflight passed for ${products.length} products.`);
  console.log("Run the generated Prisma migration to drop legacy Product columns.");
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
