import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

function parseArray(value: string | null | undefined): unknown[] {
  if (!value) return [];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

async function main() {
  const products = await db.product.findMany({
    select: {
      id: true,
      image: true,
      images: true,
      videos: true,
      colors: true,
      price: true,
      salePrice: true,
      discountPrice: true,
    },
  });

  let imageCount = 0;
  let videoCount = 0;
  let colorCount = 0;
  let priceCount = 0;

  for (const product of products) {
    // --- Images: combine primary `image` + JSON `images` array ---
    const images = parseArray(product.images).filter(
      (x): x is string => typeof x === "string",
    );
    const allImages = [product.image, ...images].filter(
      (x): x is string => typeof x === "string" && x.length > 0,
    );

    // Skip if normalized images already exist for this product (idempotent reruns).
    const existingImages = await db.productImage.count({
      where: { productId: product.id },
    });

    if (existingImages === 0 && allImages.length > 0) {
      for (let i = 0; i < allImages.length; i++) {
        await db.productImage.create({
          data: {
            productId: product.id,
            url: allImages[i],
            sortOrder: i,
            isPrimary: i === 0,
          },
        });
        imageCount++;
      }
    }

    // --- Videos ---
    const videos = parseArray(product.videos).filter(
      (x): x is string => typeof x === "string",
    );

    const existingVideos = await db.productVideo.count({
      where: { productId: product.id },
    });

    if (existingVideos === 0 && videos.length > 0) {
      for (let i = 0; i < videos.length; i++) {
        await db.productVideo.create({
          data: { productId: product.id, url: videos[i], sortOrder: i },
        });
        videoCount++;
      }
    }

    // --- Colors ---
    const colors = parseArray(product.colors).filter(
      (x): x is { name?: unknown; code?: unknown } =>
        !!x && typeof x === "object",
    );

    for (let i = 0; i < colors.length; i++) {
      const color = colors[i];
      if (typeof color.name !== "string" || typeof color.code !== "string") {
        continue;
      }
      // upsert by unique (productId, name) — safe to rerun.
      await db.productColor.upsert({
        where: {
          productId_name: { productId: product.id, name: color.name },
        },
        update: { code: color.code, sortOrder: i },
        create: {
          productId: product.id,
          name: color.name,
          code: color.code,
          sortOrder: i,
        },
      });
      colorCount++;
    }

    // --- Pricing: backfill salePrice from legacy discountPrice ---
    if (product.salePrice == null && product.discountPrice != null) {
      await db.product.update({
        where: { id: product.id },
        data: { salePrice: product.discountPrice },
      });
      priceCount++;
    }
  }

  console.log(`Migrated ${products.length} products.`);
  console.log(
    `  images: ${imageCount}, videos: ${videoCount}, colors: ${colorCount}, salePrice backfills: ${priceCount}`,
  );
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
