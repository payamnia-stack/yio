// ساخت جدول PageBuilderPage برای PostgreSQL
// اجرا: bun run db:pagebuilder
import { db } from '@/lib/db';

async function main() {
  console.log('📝 ساخت جدول PageBuilderPage...');

  try {
    await db.$executeRaw`
      CREATE TABLE IF NOT EXISTS "PageBuilderPage" (
        "id" TEXT PRIMARY KEY,
        "name" TEXT NOT NULL,
        "slug" TEXT NOT NULL UNIQUE,
        "content" TEXT NOT NULL DEFAULT '[]',
        "status" TEXT NOT NULL DEFAULT 'draft',
        "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
      )
    `;

    await db.$executeRaw`
      CREATE INDEX IF NOT EXISTS "PageBuilderPage_slug_idx"
      ON "PageBuilderPage"("slug")
    `;

    const result = await db.$queryRaw<Array<{ table_name: string }>>`
      SELECT table_name
      FROM information_schema.tables
      WHERE table_schema = 'public'
        AND table_name = 'PageBuilderPage'
    `;

    if (result.length > 0) {
      console.log('✅ جدول PageBuilderPage با موفقیت ایجاد/تأیید شد');
    } else {
      throw new Error('جدول PageBuilderPage پیدا نشد');
    }
  } catch (error) {
    console.error('❌ خطا:', error);
    process.exitCode = 1;
  } finally {
    await db.$disconnect();
  }
}

main();
