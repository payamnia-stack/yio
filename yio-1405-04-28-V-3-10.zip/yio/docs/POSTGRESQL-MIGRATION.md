# PostgreSQL migration and data-model hardening

This version prepares YIO for PostgreSQL and introduces stronger data modeling.

## Important

The Prisma datasource is now `postgresql`. Do **not** point this version at the old SQLite file directly.

Recommended production sequence:

1. Provision PostgreSQL.
2. Set `DATABASE_URL` to the PostgreSQL connection string.
3. Run `npx prisma generate`.
4. Run `npx prisma migrate dev --name postgresql-hardening` in a development database.
5. Validate the migration and run the product backfill script:
   `npx tsx scripts/migrate-product-data.ts`
6. Verify order, coupon, wallet, admin, and checkout flows.
7. Only then migrate production data.

## Product data

The new normalized tables are:

- `ProductImage`
- `ProductVideo`
- `ProductColor`
- `ProductVariant`

The legacy JSON fields remain temporarily for backward compatibility. New code should prefer the normalized relations. After all reads/writes have been migrated, the legacy `images`, `videos`, and `colors` columns can be removed in a follow-up migration.

## Pricing

The canonical model is:

- `price`: base/list price
- `salePrice`: effective sale price, nullable

`discountPercent` is derived and should not be persisted as a second source of truth. The legacy `discountPrice` and `discountPercent` columns are retained temporarily to make the migration safer; use `src/lib/pricing.ts` for new code.

## Enums

The following business-critical fields are now typed enums:

- `OrderStatus`
- `PaymentStatus`
- `PaymentMethodType`
- `CouponType`
- `ReturnStatus`
- `WholesaleOrderStatus`

This prevents typo-based state corruption at the database layer.

## Production recommendation

Do not switch a live store from SQLite to PostgreSQL by simply changing `DATABASE_URL`. Use a controlled data migration, backup, staging verification, and a short maintenance window.
