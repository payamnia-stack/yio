# Final Product schema cleanup

This is the final migration step after all API and Frontend code has been moved to:

- `ProductImage`
- `ProductVideo`
- `ProductColor`
- `ProductVariant`
- `Product.salePrice`

## Required order

1. Back up PostgreSQL.
2. Deploy the version that writes all new data only to the normalized tables.
3. Run the legacy data migration/backfill.
4. Verify all Product APIs and Frontend pages use the normalized relations and `salePrice`.
5. Run:

   `npm run finalize:product-schema`

6. If preflight passes, apply the Prisma migration:

   `npx prisma migrate deploy`

7. Run:

   `npx prisma generate`

The preflight intentionally aborts if any Product still contains legacy media/color or legacy discount data.

## Dropped columns

- `Product.image`
- `Product.images`
- `Product.videos`
- `Product.colors`
- `Product.discountPrice`
- `Product.discountPercent`

## Important

This migration is destructive for the listed columns. Keep a PostgreSQL backup until the new application version has been validated in production.
