/**
 * Canonical product pricing helpers.
 *
 * `price` is the base/list price.
 * `salePrice` is the effective discounted price when a sale is active.
 * `discountPercent` is derived and is never persisted.
 */
export function getEffectiveProductPrice(product: {
  price: number;
  salePrice?: number | null;
}): number {
  const salePrice = product.salePrice ?? null;
  return salePrice !== null && salePrice >= 0 && salePrice < product.price
    ? salePrice
    : product.price;
}

export function getDiscountPercent(product: {
  price: number;
  salePrice?: number | null;
}): number | null {
  const effective = getEffectiveProductPrice(product);
  if (effective >= product.price || product.price <= 0) return null;
  return Math.round(((product.price - effective) / product.price) * 100);
}

export function validateProductPricing(input: {
  price: number;
  salePrice?: number | null;
}): void {
  if (!Number.isInteger(input.price) || input.price < 0) {
    throw new Error("Product price must be a non-negative integer");
  }
  if (input.salePrice !== null && input.salePrice !== undefined) {
    if (!Number.isInteger(input.salePrice) || input.salePrice < 0) {
      throw new Error("Product salePrice must be a non-negative integer");
    }
    if (input.salePrice >= input.price) {
      throw new Error("Product salePrice must be lower than the base price");
    }
  }
}
