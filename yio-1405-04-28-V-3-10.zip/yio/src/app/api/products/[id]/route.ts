import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';

// دریافت یک محصول با ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);

    if (!isAuth) {
      return NextResponse.json(
        { error: 'غیرمجاز. لطفاً وارد شوید.' },
        { status: 401 }
      );
    }

    const { id } = await params;
    const productId = parseInt(id);

    if (isNaN(productId)) {
      return NextResponse.json(
        { error: 'شناسه محصول نامعتبر است' },
        { status: 400 }
      );
    }

    const product = await db.product.findUnique({
      where: { id: productId },
      include: {
        productImages: { orderBy: { sortOrder: 'asc' } },
        productVideos: { orderBy: { sortOrder: 'asc' } },
        productColors: { orderBy: { sortOrder: 'asc' } },
        productVariants: { where: { isActive: true }, orderBy: { createdAt: 'asc' } },
      },
    });

    if (!product) {
      return NextResponse.json(
        { error: 'محصول یافت نشد' },
        { status: 404 }
      );
    }

    const normalizedProduct = {
      ...product,
      image: product.productImages.find(i => i.isPrimary)?.url || product.productImages[0]?.url || product.image,
      images: product.productImages.length ? JSON.stringify(product.productImages.map(i => i.url)) : product.images,
      videos: product.productVideos.length ? JSON.stringify(product.productVideos.map(v => v.url)) : product.videos,
      colors: product.productColors.length ? JSON.stringify(product.productColors.map(c => ({ name: c.name, code: c.code }))) : product.colors,
    };

    return NextResponse.json({ product: normalizedProduct });
  } catch (error) {
    console.error('Error fetching product:', error);
    return NextResponse.json(
      { error: 'خطا در دریافت محصول' },
      { status: 500 }
    );
  }
}

// ویرایش محصول
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);

    if (!isAuth) {
      return NextResponse.json(
        { error: 'غیرمجاز. لطفاً وارد شوید.' },
        { status: 401 }
      );
    }

    const { id } = await params;
    const productId = parseInt(id);

    if (isNaN(productId)) {
      return NextResponse.json(
        { error: 'شناسه محصول نامعتبر است' },
        { status: 400 }
      );
    }

    const body = await request.json();

    // بررسی وجود محصول
    const existing = await db.product.findUnique({ where: { id: productId } });
    if (!existing) {
      return NextResponse.json(
        { error: 'محصول یافت نشد' },
        { status: 404 }
      );
    }

    // اعتبارسنجی
    if (body.title !== undefined && (typeof body.title !== 'string' || body.title.trim().length < 3)) {
      return NextResponse.json(
        { error: 'عنوان محصول باید حداقل ۳ کاراکتر باشد' },
        { status: 400 }
      );
    }

    if (body.price !== undefined && (typeof body.price !== 'number' || body.price < 1000)) {
      return NextResponse.json(
        { error: 'قیمت باید عددی بزرگتر از ۱۰۰۰ تومان باشد' },
        { status: 400 }
      );
    }

    // محاسبه درصد تخفیف
    let discountPercent = body.discountPercent;
    if (body.discountPrice && body.price && body.discountPrice < body.price && !discountPercent) {
      discountPercent = Math.round(((body.price - body.discountPrice) / body.price) * 100);
    }

    // پاکسازی ورودی‌ها
    const sanitize = (str: string) =>
      str.replace(/<script[^>]*>.*?<\/script>/gi, '').replace(/<[^>]+>/g, '').trim();

    const updateData: any = {};
    if (body.title !== undefined) updateData.title = sanitize(body.title);
    if (body.brand !== undefined) updateData.brand = sanitize(body.brand || 'YIO');
    if (body.category !== undefined) updateData.category = sanitize(body.category);
    if (body.price !== undefined) updateData.price = Math.floor(body.price);
    if (body.discountPrice !== undefined) updateData.discountPrice = body.discountPrice ? Math.floor(body.discountPrice) : null;
    if (discountPercent !== undefined) updateData.discountPercent = discountPercent || null;
    if (body.image !== undefined) updateData.image = body.image.trim();
    if (body.rating !== undefined) updateData.rating = body.rating;
    if (body.ratingCount !== undefined) updateData.ratingCount = body.ratingCount;
    // inStock به‌صورت خودکار از stockQuantity محاسبه می‌شود
    // کلاینت نباید این فیلد را مستقیم تنظیم کند
    if (body.fastDelivery !== undefined) updateData.fastDelivery = Boolean(body.fastDelivery);
    if (body.isSpecial !== undefined) updateData.isSpecial = Boolean(body.isSpecial);
    if (body.isPublished !== undefined) updateData.isPublished = Boolean(body.isPublished);
    if (body.stockQuantity !== undefined) {
      const qty = Math.max(0, parseInt(body.stockQuantity) || 0);
      updateData.stockQuantity = qty;
      updateData.inStock = qty > 0; // همگام‌سازی خودکار
    }
    if (body.description !== undefined) updateData.description = body.description ? sanitize(body.description) : null;
    if (body.woodType !== undefined) updateData.woodType = body.woodType ? sanitize(body.woodType) : null;
    if (body.colors !== undefined) updateData.colors = body.colors ? JSON.stringify(body.colors) : null;

    // تصاویر و ویدیوهای چندگانه
    const MAX_IMAGES = 10;
    const MAX_VIDEOS = 3;
    if (body.images !== undefined) {
      const imgs = Array.isArray(body.images)
        ? body.images.filter((img: any) => typeof img === 'string' && (img.startsWith('http://') || img.startsWith('https://') || img.startsWith('/'))).slice(0, MAX_IMAGES)
        : [];
      updateData.images = imgs.length > 0 ? JSON.stringify(imgs) : null;
    }
    if (body.videos !== undefined) {
      const vids = Array.isArray(body.videos)
        ? body.videos.filter((v: any) => typeof v === 'string' && (v.startsWith('http://') || v.startsWith('https://') || v.startsWith('/'))).slice(0, MAX_VIDEOS)
        : [];
      updateData.videos = vids.length > 0 ? JSON.stringify(vids) : null;
    }

    const product = await db.product.update({
      where: { id: productId },
      data: updateData,
    });

    // اگر موجودی تغییر کرده، به همه کلاینت‌ها broadcast کن (real-time)
    if (body.stockQuantity !== undefined) {
      const { broadcastStockUpdate } = await import('@/lib/stock-events');
      broadcastStockUpdate(product.id, product.stockQuantity);
    }

    return NextResponse.json({ product, success: true });
  } catch (error) {
    console.error('Error updating product:', error);
    return NextResponse.json(
      { error: 'خطا در ویرایش محصول' },
      { status: 500 }
    );
  }
}

// حذف محصول
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);

    if (!isAuth) {
      return NextResponse.json(
        { error: 'غیرمجاز. لطفاً وارد شوید.' },
        { status: 401 }
      );
    }

    const { id } = await params;
    const productId = parseInt(id);

    if (isNaN(productId)) {
      return NextResponse.json(
        { error: 'شناسه محصول نامعتبر است' },
        { status: 400 }
      );
    }

    const existing = await db.product.findUnique({ where: { id: productId } });
    if (!existing) {
      return NextResponse.json(
        { error: 'محصول یافت نشد' },
        { status: 404 }
      );
    }

    await db.product.delete({ where: { id: productId } });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting product:', error);
    return NextResponse.json(
      { error: 'خطا در حذف محصول' },
      { status: 500 }
    );
  }
}
