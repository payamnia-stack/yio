import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';
import { sanitizeInput, securityCheck } from '@/lib/security';

// GET: لیست دسته‌بندی‌ها (مدیر)
export async function GET() {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    let categories = await db.category.findMany({ orderBy: [{ order: 'asc' }, { title: 'asc' }] });

    // همگام‌سازی اولیه: اگر جدول Category خالی است، دسته‌های پیش‌فرض فروشگاه را
    // یک‌بار در PostgreSQL ایجاد می‌کنیم تا پنل مدیریت و سایت دقیقاً از یک منبع استفاده کنند.
    if (categories.length === 0) {
      const defaults = [
        ['اسباب‌بازی چوبی', 'asbab-bazi-choobi', '🧸', '#f59e0b'],
        ['ظروف آشپزخانه', 'zorof-ashpazkhaneh', '🍽️', '#84cc16'],
        ['مبلمان چوبی', 'mobleman-choobi', '🪑', '#8b5cf6'],
        ['دکوراسیون چوبی', 'dekorasion-choobi', '🖼️', '#dc2626'],
        ['لوازم کودک', 'lavazem-koodak', '👶', '#06b6d4'],
        ['هدیه و صنایع دستی', 'hediye-sanaye-dasti', '🎁', '#ec4899'],
        ['نقاشی و هنر', 'naghashi-honar', '🎨', '#7c3aed'],
        ['باغ و حیاط', 'bagh-hayat', '🌳', '#10b981'],
      ] as const;

      await db.category.createMany({
        data: defaults.map(([title, slug, icon, color], order) => ({
          title, slug, icon, color, order, isActive: true,
        })),
        skipDuplicates: true,
      });

      categories = await db.category.findMany({
        orderBy: [{ order: 'asc' }, { title: 'asc' }],
      });
    }

    return NextResponse.json({ categories });
  } catch (error) {
    return NextResponse.json({ error: 'خطا' }, { status: 500 });
  }
}

// POST: ایجاد دسته‌بندی جدید
export async function POST(request: NextRequest) {
  try {
    const token = await getAdminToken();
    const isAuth = await verifyAdminSession(token);
    if (!isAuth) return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });

    const body = await request.json();
    const secCheck = securityCheck(body);
    if (!secCheck.safe) return NextResponse.json({ error: secCheck.reason }, { status: 400 });

    if (!body.title || typeof body.title !== 'string' || body.title.trim().length < 2) {
      return NextResponse.json({ error: 'عنوان دسته‌بندی باید حداقل ۲ کاراکتر باشد' }, { status: 400 });
    }

    // ساخت slug از عنوان
    const slug = body.slug || body.title.trim().replace(/\s+/g, '-');

    // بررسی تکراری نبودن
    const existing = await db.category.findFirst({
      where: { OR: [{ title: body.title.trim() }, { slug }] },
    });
    if (existing) {
      return NextResponse.json({ error: 'این دسته‌بندی قبلا ثبت شده' }, { status: 400 });
    }

    const category = await db.category.create({
      data: {
        title: sanitizeInput(body.title).slice(0, 100),
        slug,
        icon: body.icon || '📦',
        color: body.color || '#dc2626',
        description: body.description ? sanitizeInput(body.description).slice(0, 500) : null,
        order: parseInt(body.order) || 0,
        isActive: Boolean(body.isActive ?? true),
      },
    });

    return NextResponse.json({ category, success: true });
  } catch (error) {
    console.error('Create category error:', error);
    return NextResponse.json({ error: 'خطا در ایجاد' }, { status: 500 });
  }
}
