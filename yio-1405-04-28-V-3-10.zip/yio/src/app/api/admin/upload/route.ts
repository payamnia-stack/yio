import { NextRequest, NextResponse } from 'next/server';
import { mkdir, writeFile } from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import { verifyAdminSession, getAdminToken } from '@/lib/admin-auth';

export const runtime = 'nodejs';

const ALLOWED_EXTENSIONS = new Set([
  '.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.mp4', '.webm',
]);

export async function POST(request: NextRequest) {
  try {
    const token = await getAdminToken();
    if (!(await verifyAdminSession(token))) {
      return NextResponse.json({ error: 'غیرمجاز' }, { status: 401 });
    }

    const formData = await request.formData();
    const file = formData.get('file');
    const folderValue = String(formData.get('path') || 'products');

    if (!(file instanceof File)) {
      return NextResponse.json({ error: 'فایل ارسال نشده است' }, { status: 400 });
    }

    const folder = folderValue
      .replace(/\\/g, '/')
      .split('/')
      .filter(Boolean)
      .filter(part => part !== '.' && part !== '..')
      .join('/');

    const ext = path.extname(file.name).toLowerCase();
    if (!ALLOWED_EXTENSIONS.has(ext)) {
      return NextResponse.json({ error: 'فرمت فایل مجاز نیست' }, { status: 400 });
    }

    if (file.size > 10 * 1024 * 1024) {
      return NextResponse.json({ error: 'حداکثر حجم فایل ۱۰ مگابایت است' }, { status: 400 });
    }

    const safeFolder = folder || 'products';
    const uploadDir = path.join(process.cwd(), 'public', 'uploads', safeFolder);
    await mkdir(uploadDir, { recursive: true });

    const filename = `${Date.now()}-${crypto.randomBytes(6).toString('hex')}${ext}`;
    const filepath = path.join(uploadDir, filename);
    const buffer = Buffer.from(await file.arrayBuffer());
    await writeFile(filepath, buffer);

    const url = `/uploads/${safeFolder}/${filename}`;
    return NextResponse.json({
      success: true,
      file: {
        name: filename,
        path: `${safeFolder}/${filename}`,
        url,
        type: 'file',
        ext,
        size: file.size,
      },
    });
  } catch (error) {
    console.error('Upload error:', error);
    return NextResponse.json({ error: 'خطا در آپلود فایل' }, { status: 500 });
  }
}
