import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET: دریافت یک محصول با ID (عمومی)
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const productId = parseInt(id);

    if (isNaN(productId)) {
      return NextResponse.json({ error: 'شناسه نامعتبر' }, { status: 400 });
    }

    const product = await db.product.findUnique({
      where: { id: productId },
      include: {
        productImages: { orderBy: { sortOrder: 'asc' } },
        productVideos: { orderBy: { sortOrder: 'asc' } },
        productColors: { orderBy: { sortOrder: 'asc' } },
        productVariants: { where: { isActive: true }, orderBy: { createdAt: 'asc' } },
      },
    });

    if (!product) {
      return NextResponse.json({ error: 'محصول یافت نشد' }, { status: 404 });
    }

    const normalizedProduct = {
      ...product,
      image: product.productImages.find(i => i.isPrimary)?.url || product.productImages[0]?.url || product.image,
      images: product.productImages.length ? JSON.stringify(product.productImages.map(i => i.url)) : product.images,
      videos: product.productVideos.length ? JSON.stringify(product.productVideos.map(v => v.url)) : product.videos,
      colors: product.productColors.length ? JSON.stringify(product.productColors.map(c => ({ name: c.name, code: c.code }))) : product.colors,
    };

    // گرفتن محصولات مرتبط (همان دسته)
    const related = await db.product.findMany({
      where: {
        category: product.category,
        id: { not: product.id },
        inStock: true,
      },
      take: 4,
      orderBy: { rating: 'desc' },
    });

    return NextResponse.json({ product: normalizedProduct, related });
  } catch (error) {
    console.error('Error fetching product:', error);
    return NextResponse.json({ error: 'خطا در دریافت محصول' }, { status: 500 });
  }
}
