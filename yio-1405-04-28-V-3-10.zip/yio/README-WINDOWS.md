# راه‌اندازی فروشگاه YIO روی ویندوز با PostgreSQL

این نسخه برای **PostgreSQL** تنظیم شده است. SQLite دیگر دیتابیس پشتیبانی‌شده پروژه نیست.

## پیش‌نیازها
1. Node.js 20+
2. Bun (توصیه‌شده) یا npm
3. PostgreSQL 15+
4. Git (اختیاری)

## 1) ساخت دیتابیس
در PostgreSQL دیتابیسی با نام `yio` بسازید:

```sql
CREATE DATABASE yio;
```

## 2) ساخت `.env`
در ریشه پروژه:

```env
DATABASE_URL="postgresql://postgres:YOUR_PASSWORD@localhost:5432/yio?schema=public"
EXPOSE_VERIFY_CODE=true
```

`YOUR_PASSWORD` را با رمز PostgreSQL خود جایگزین کنید.

## 3) نصب وابستگی‌ها

با Bun:
```powershell
bun install
bun run db:generate
```

یا با npm:
```powershell
npm install
npx prisma generate
```

## 4) ساخت/همگام‌سازی دیتابیس Local

```powershell
bun run db:push
```

یا:
```powershell
npx prisma db push
```

این نسخه برای راه‌اندازی سریع Local از `prisma db push` استفاده می‌کند.

> اگر دیتابیس قبلی دارید، قبل از `db:push` از آن Backup بگیرید.

## 5) داده‌های نمونه

```powershell
bun run seed
bun run seed:faq
bun run seed:settings
bun run seed:pages
```

## 6) اجرای سایت

```powershell
bun run dev
```

سپس:
`http://localhost:3000`

## ساختار دیتابیس محصولات

مدل‌های نرمال‌شده محصول شامل:
- `ProductImage`
- `ProductVideo`
- `ProductColor`
- `ProductVariant`

و `salePrice` منبع اصلی قیمت فروش ویژه است.

برای سازگاری با نسخه‌های قبلی، فیلدهای Legacy مربوط به Product فعلاً در Schema باقی مانده‌اند؛ بنابراین در این نسخه حذف آن‌ها انجام نمی‌شود تا API، پنل مدیریت و Seed فعلی دچار شکست نشوند. این تصمیم عمداً برای راه‌اندازی پایدار Local گرفته شده است.

## صفحه‌ساز

```powershell
bun run db:pagebuilder
```

این اسکریپت با PostgreSQL سازگار است و از `sqlite_master` استفاده نمی‌کند.

## دستورات مهم

| دستور | توضیح |
|---|---|
| `bun run dev` | اجرای توسعه |
| `bun run build` | ساخت production |
| `bun run start` | اجرای production |
| `bun run db:push` | همگام‌سازی Schema با PostgreSQL |
| `bun run db:generate` | تولید Prisma Client |
| `bun run db:migrate` | Migration توسعه |
| `bun run db:reset` | بازنشانی دیتابیس توسعه |
| `bun run db:pagebuilder` | ساخت جدول Page Builder |
| `bun run seed` | محصولات نمونه |
| `bun run seed:faq` | FAQ |
| `bun run seed:settings` | تنظیمات |
| `bun run seed:pages` | صفحات اولیه |

## خطاهای رایج

### `Environment variable not found: DATABASE_URL`
فایل `.env` را در ریشه پروژه بررسی کنید.

### `P1001: Can't reach database server`
مطمئن شوید PostgreSQL در حال اجراست و پورت `5432` در دسترس است.

### `P1003: Database does not exist`
ابتدا:
```sql
CREATE DATABASE yio;
```

### خطای Prisma بعد از تغییر Schema
```powershell
bun run db:generate
bun run db:push
```

### خطای پورت 3000
```powershell
bun run dev -- -p 3001
```

### پاک‌سازی Next.js
```powershell
Remove-Item -Recurse -Force .next
bun run dev
```

## انتقال اطلاعات SQLite قدیمی

این نسخه برای **راه‌اندازی PostgreSQL جدید از ابتدا** آماده شده است. اگر اطلاعات واقعی شما فقط در SQLite قدیمی است، آن داده‌ها باید با اسکریپت مهاجرت به PostgreSQL منتقل شوند.

برای دیتابیس Local جدید:
1. PostgreSQL را نصب و اجرا کنید.
2. Database با نام `yio` بسازید.
3. `.env` را تنظیم کنید.
4. `bun install`
5. `bun run db:generate`
6. `bun run db:push`
7. Seedها را اجرا کنید.
8. `bun run dev`
