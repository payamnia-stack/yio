# YIO V-3-10 — اصلاح تصاویر و دسته‌بندی‌ها

## اصلاحات این نسخه
- API عمومی محصولات اکنون ProductImage/ProductVideo/ProductColor/ProductVariant را می‌خواند و به فرمت سازگار با Frontend قدیمی normalize می‌کند.
- API جزئیات محصول نیز تصاویر و ویدیوهای مدل‌های جدید را برمی‌گرداند.
- API مدیریت محصولات نیز داده‌های مدل‌های جدید را در پاسخ برمی‌گرداند.
- URLهای محلی مانند `/uploads/products/file.jpg` دیگر توسط API محصول رد نمی‌شوند.
- مسیر `/api/admin/upload` اضافه شد و فایل‌های تصویری/ویدیویی را در `public/uploads` ذخیره می‌کند.
- اگر جدول Category خالی باشد، دسته‌های پایه یک‌بار در PostgreSQL ایجاد می‌شوند.
- Header و پنل مدیریت اکنون پس از همگام‌سازی دسته‌ها از همان Categoryهای PostgreSQL استفاده می‌کنند.

## اجرای نسخه
```powershell
npm.cmd install
npx.cmd prisma generate
npx.cmd prisma db push
npm.cmd run dev
```

Seed را دوباره اجرا نکنید مگر اینکه دیتابیس را از نو ساخته باشید.
