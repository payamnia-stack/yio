# Changelog

## [0.3.0] — V-3-5 — Hotfix release

This release fixes three bugs that were shipped in V-2-10-final-product-schema-cleanup.
No new features were added — the goal is a working, deployable version of the
schema-cleanup migration.

### Fixed

#### 1. `src/components/shop/checkout-modal.tsx` — Syntax error + undefined ref

The OTP request headers block had a missing comma and referenced an undefined
`orderIdempotencyKey.current` ref that was never declared anywhere in the file.
Both TypeScript and runtime would fail.

Before (broken):

```tsx
headers: { 'Content-Type': 'application/json'
'idempotency-key': orderIdempotencyKey.current,},
```

After (restored to the original working version):

```tsx
headers: { 'Content-Type': 'application/json' },
```

The backend `/api/auth/otp-request` route does not read an `idempotency-key`
header, so dropping the line is safe.

#### 2. `prisma/schema.prisma` — Missing legacy columns

V-2-10-final-product-schema-cleanup removed three columns from the Prisma
`Product` model even though the migration guide explicitly says they should be
retained temporarily for backward compatibility:

- `Product.colors`
- `Product.discountPrice`
- `Product.discountPercent`

Because these fields were missing from the generated Prisma client:

- `scripts/migrate-product-data.ts` failed at runtime
  (`product.colors` and `product.discountPrice` were `undefined`).
- `scripts/finalize-product-schema.ts` failed at runtime
  (`select: { discountPrice: true, discountPercent: true, colors: true }`
  is rejected by Prisma client as unknown fields).
- 30+ frontend/admin files that still read `discountPrice`, `discountPercent`,
  and `colors` would have produced `undefined` values everywhere.
- TypeScript compilation of the project would fail.

Fix: re-added the three columns to the `Product` model as deprecated
compatibility fields, with a clear comment block explaining they will be
dropped by the finalize-product-schema migration once all reads/writes are
migrated to the normalized relations and `salePrice`.

#### 3. `scripts/migrate-product-data.ts` — Broken upsert pattern

The image migration used:

```ts
await db.productImage.upsert({
  where: { id: -1 },     // never matches
  update: {},
  create: { ... },
}).catch(async () => {
  await db.productImage.create({ ... });
});
```

`where: { id: -1 }` can never match an existing row, so every call always
throws "record not found", falls into `.catch`, and runs `create` anyway.
Worse, on rerun it would duplicate every image because the upsert never
actually checked for existing data.

Fix: rewrote the image and video loops to first `count` existing rows for
the product, and only insert when none exist (idempotent reruns). Colors
already used a proper unique-key upsert and were left intact.

The script now also prints per-resource migration counts at the end so the
operator can verify the backfill.

### Changed

- `package.json` version bumped `0.2.0 → 0.3.0`.
- Added this `CHANGELOG.md`.

### Migration steps from V-2-10-final-product-schema-cleanup

If you already tried to run V-2-10-final-product-schema-cleanup:

1. Replace the source tree with this V-3-5 release.
2. Re-run `npx prisma generate` (the Prisma client will now include
   `colors`, `discountPrice`, `discountPercent` again).
3. If your database is missing the legacy columns (because a previous
   `prisma migrate dev` already dropped them), restore them from your
   PostgreSQL backup before continuing.
4. Proceed with the standard migration sequence documented in
   `docs/POSTGRESQL-MIGRATION.md` and `docs/FINAL-PRODUCT-SCHEMA-CLEANUP.md`.

### Migration steps from V-2-10 (SQLite)

Follow `docs/POSTGRESQL-MIGRATION.md` from the beginning. Do not point this
version at the old SQLite file — the datasource provider is now `postgresql`.
