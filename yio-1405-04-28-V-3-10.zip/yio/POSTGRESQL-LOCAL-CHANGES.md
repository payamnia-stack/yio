# تغییرات نسخه PostgreSQL Local

- تنظیم `DATABASE_URL` از SQLite به PostgreSQL در راهنمای Windows و اسکریپت‌های setup
- اضافه شدن `.env.example` مخصوص PostgreSQL
- حذف Migration ناقص `finalize-product-schema` که فقط ستون‌ها را حذف می‌کرد و برای دیتابیس تازه مناسب نبود
- نگه‌داشتن فیلدهای Legacy Product برای جلوگیری از شکستن API/پنل فعلی
- اصلاح اسکریپت Page Builder برای PostgreSQL (`information_schema` به جای `sqlite_master`)
- اصلاح `build` و `start` برای اجرای سازگارتر روی Windows (`next build` / `next start`)
- اضافه شدن Scriptهای Seed به `package.json`

## نکته
این نسخه برای راه‌اندازی Local با PostgreSQL آماده شده است. حذف نهایی فیلدهای Legacy محصول عمداً به نسخه بعدی موکول شده تا ابتدا تمام APIها، پنل مدیریت و Frontend به مدل‌های نرمال‌شده `ProductImage/ProductVideo/ProductColor/ProductVariant` متصل شوند.
